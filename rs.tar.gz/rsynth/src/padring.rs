//! Pad ring (wire-bond IO), bond pads, seal ring and IO / ESD rule checks.
//!
//!  create_pad_ring -order_file f | -pad_ring_order_config_file f
//!      [-corner_cell C] [-corner_orientation {ll N lr FN ul FS ur S}] [-filler_cells {...}]
//!      [-bond_pad_cell B] [-bond_style inline|staggered] [-stagger_gap um]
//!      [-pad_spacing um] [-distribute even|abut] [-ring_offset um] [-no_insert]
//!  report_pad_ring
//!  check_bond_pads [-min_pitch um] [-min_row_pitch um]
//!  check_esd [-max_clamp_distance um] [-max_signals_per_supply n] [-clamp_cells {..}] [-breaker_cells {..}]
//!  create_seal_ring -width w [-height h] -layers {..} [-offset um] [-chamfer um] [-net SEALRING]
//!
//! Pad order file (one object per line, '#' comments):
//!    corner_cell PCORNER | filler_cells PFILL20 PFILL10 ... | bond_pad_cell BONDPAD
//!    bond_style inline|staggered | pad_spacing 2 | distribute even|abut
//!    corner ll|lr|ul|ur [orient=N] [cell=PCORNER]
//!    <top|bottom|left|right> <instance> <cell> [port=<port>] [domain=<io domain>] [kind=...]
//!  bottom / top pads are listed left -> right, left / right pads bottom -> top.
//!  kind: signal | power | ground | io_power | io_ground | clamp | breaker (default from the cell)

use crate::chipfp::{fr, Rect};
use crate::netlist::*;
use crate::phys::{BondPad, IoPad, SpecialShape};
use crate::session::{args, Session};
use crate::tcl::{err, split_list, Flow, R};
use std::collections::HashMap;

#[derive(Clone, Debug, Default)]
struct OrderEntry {
    side: String,
    inst: String,
    cell: String,
    port: Option<String>,
    domain: String,
    kind: String,
}

#[derive(Clone, Debug)]
struct OrderFile {
    entries: Vec<OrderEntry>,
    corners: Vec<(String, String, String)>, // (corner, orient, cell)
    opts: HashMap<String, Vec<String>>,
}

fn parse_order(text: &str) -> Result<OrderFile, String> {
    let mut of = OrderFile { entries: vec![], corners: vec![], opts: HashMap::new() };
    for (ln, line) in text.lines().enumerate() {
        let l = line.split('#').next().unwrap_or("").trim();
        if l.is_empty() {
            continue;
        }
        let t: Vec<&str> = l.split_whitespace().collect();
        let kv = |k: &str| t.iter().find_map(|x| x.strip_prefix(&format!("{}=", k))).map(|s| s.to_string());
        match t[0] {
            "corner" => {
                let c = t.get(1).ok_or(format!("line {}: corner needs ll|lr|ul|ur", ln + 1))?.to_string();
                if !["ll", "lr", "ul", "ur"].contains(&c.as_str()) {
                    return Err(format!("line {}: corner '{}' must be ll, lr, ul or ur", ln + 1, c));
                }
                of.corners.push((c, kv("orient").unwrap_or_default(), kv("cell").unwrap_or_default()));
            }
            "top" | "bottom" | "left" | "right" => {
                if t.len() < 3 {
                    return Err(format!("line {}: '<side> <instance> <cell> [port=..] [domain=..] [kind=..]'", ln + 1));
                }
                of.entries.push(OrderEntry { side: t[0].into(), inst: t[1].into(), cell: t[2].into(), port: kv("port"), domain: kv("domain").unwrap_or_default(), kind: kv("kind").unwrap_or_default() });
            }
            k => {
                of.opts.insert(k.to_string(), t[1..].iter().map(|s| s.to_string()).collect());
            }
        }
    }
    Ok(of)
}

/// default pad kind from the cell name / LEF class
fn pad_kind(cell: &str, class: &str) -> String {
    let c = cell.to_uppercase();
    if c.contains("BRK") || c.contains("BREAK") { "breaker" }
    else if c.contains("CLAMP") || c.contains("ESD") { "clamp" }
    else if c.contains("VDDIO") || c.contains("DVDD") { "io_power" }
    else if c.contains("VSSIO") || c.contains("DVSS") { "io_ground" }
    else if c.contains("VDD") { "power" }
    else if c.contains("VSS") || c.contains("GND") { "ground" }
    else if class.contains("SPACER") { "filler" }
    else { "signal" }.to_string()
}

impl Session {
    pub fn padring_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "create_pad_ring" | "create_io_ring" | "place_io_pads" => self.c_pad_ring(a),
            "report_pad_ring" | "report_io_ring" => self.c_report_ring(a),
            "check_bond_pads" | "check_wire_bond" => self.c_check_bond(a),
            "check_esd" | "check_io_ring" => self.c_check_esd(a),
            "create_seal_ring" => self.c_seal_ring(a),
            _ => return self.flipchip_cmd(name, a),
        })
    }

    /// create (or find) a cell instance of master `cell`; pins from Liberty, else LEF
    pub(crate) fn make_inst(&mut self, inst: &str, cell: &str) -> Result<CellId, Flow> {
        let nl = self.nl.as_mut().ok_or_else(|| Flow::Err("no design".into()))?;
        if let Some(c) = nl.cell_by_name(inst) {
            return Ok(c);
        }
        let lib = self.libs.iter().find_map(|l| l.cells.get(cell));
        let pins: Vec<(String, Dir)> = match lib {
            Some(lc) => lc.pins.iter().map(|p| (p.name.clone(), p.dir.unwrap_or(Dir::In))).collect(),
            None => match self.lef.get(cell) {
                Some(m) => m.pins.iter().map(|p| (p.name.clone(), match p.dir.as_str() { "OUTPUT" => Dir::Out, "INOUT" => Dir::InOut, _ => Dir::In })).collect(),
                None => return Err(Flow::Err(format!("cell '{}' is in no library or LEF (IO-201)", cell))),
            },
        };
        let pr: Vec<(&str, Dir)> = pins.iter().map(|(n, d)| (n.as_str(), *d)).collect();
        let kind = if lib.is_some() { Kind::Lib(cell.to_string()) } else { Kind::BlackBox(cell.to_string()) };
        Ok(nl.add_cell(inst, kind, &pr))
    }

    /// insert pad `inst` on top-level port `port`: PAD pin on the port net, core pin on a new
    /// `<port>_core` net that takes over the core-side connections. Returns false if the port
    /// is already padded.
    pub(crate) fn insert_pad(&mut self, port: &str, c: CellId) -> Result<bool, Flow> {
        let nl = self.nl.as_mut().unwrap();
        let p = nl.port_by_name(port).ok_or_else(|| Flow::Err(format!("port '{}' not found (IO-202)", port)))?;
        let n = match nl.ports[p].net { Some(n) => n, None => { let n = nl.add_net(port); nl.connect_port(p, n); n } };
        let cl = nl.cell(c).clone();
        if cl.pins.iter().any(|q| q.net == Some(n)) {
            return Ok(false);
        }
        let pad_pin = cl.pins.iter().position(|q| q.name == "PAD").ok_or_else(|| Flow::Err(format!("pad cell '{}' has no PAD pin (IO-203)", cl.name)))?;
        // core-side pin: the pad output (C / Y) for an input port, the pad input (I / A) for an
        // output port (bidirectional pads such as GPIO have both)
        let pdir = nl.ports[p].dir;
        let core_ok = |q: &Pin| q.name != "PAD" && q.net.is_none() && (q.name == "C" || q.name == "I" || q.name == "Y" || q.name == "A");
        let by_dir = |out: bool| cl.pins.iter().position(|q| core_ok(q) && (q.dir == Dir::Out) == out);
        let core_pin = match pdir { Dir::In => by_dir(true), Dir::Out => by_dir(false), Dir::InOut => None }
            .or_else(|| cl.pins.iter().position(|q| core_ok(q)))
            .ok_or_else(|| Flow::Err(format!("pad cell '{}' has no core-side pin (C / I / Y / A) (IO-203)", cl.name)))?;
        let cn = nl.add_net(&format!("{}_core", port.replace(['[', ']'], "_")));
        // everything on the port net except the port itself moves to the core net
        let conns: Vec<PinRef> = nl.net(n).conns.clone();
        for q in conns {
            if let PinRef::Cell(cc, i) = q {
                nl.disconnect(cc, i);
                nl.connect(cc, i, cn);
            }
        }
        nl.connect(c, pad_pin, n);
        nl.connect(c, core_pin, cn);
        // bidirectional pads: tie the enables for the port direction (OE / IE), pulls off
        if cl.pins.iter().any(|q| q.name == "OE" || q.name == "IE") && pdir != Dir::InOut {
            let mut tied = vec![];
            for (i, q) in cl.pins.iter().enumerate() {
                if q.net.is_some() || i == core_pin || i == pad_pin { continue; }
                let v = match q.name.as_str() { "OE" => pdir == Dir::Out, "IE" => pdir == Dir::In, "PU" | "PD" => false, _ => continue };
                let tn = crate::genopt::const_net(nl, v);
                nl.connect(c, i, tn);
                tied.push(format!("{}={}", q.name, v as u8));
            }
            if !tied.is_empty() {
                crate::info!("IO-206", "Pad {} ({}) used as {}: tied {}", cl.name, port, if pdir == Dir::In { "input" } else { "output" }, tied.join(" "));
            }
        }
        Ok(true)
    }

    fn lef_size(&self, cell: &str) -> Result<(f64, f64), Flow> {
        self.lef.get(cell).map(|m| (m.w, m.h)).ok_or_else(|| Flow::Err(format!("no LEF abstract for '{}' (read_lef) (IO-204)", cell)))
    }

    fn c_pad_ring(&mut self, a: &[String]) -> R {
        let x = args(a, &["-order_file", "-pad_ring_order_config_file", "-corner_cell", "-corner_orientation", "-filler_cells", "-bond_pad_cell",
            "-bond_style", "-stagger_gap", "-pad_spacing", "-distribute", "-ring_offset"]);
        let f = x.get("-order_file").or(x.get("-pad_ring_order_config_file")).ok_or_else(|| Flow::Err("create_pad_ring: -order_file required (CMD-001)".into()))?;
        let txt = std::fs::read_to_string(f).map_err(|e| Flow::Err(format!("create_pad_ring: {}: {} (IO-200)", f, e)))?;
        let of = parse_order(&txt).map_err(|e| Flow::Err(format!("create_pad_ring: {}: {} (IO-200)", f, e)))?;
        let fp = self.fp.clone().ok_or_else(|| Flow::Err("create_pad_ring: no floorplan (FP-001)".into()))?;
        let opt = |k: &str, o: &str| -> Option<String> { x.get(o).cloned().or_else(|| of.opts.get(k).map(|v| v.join(" "))) };
        let corner_cell = opt("corner_cell", "-corner_cell");
        let fillers: Vec<String> = opt("filler_cells", "-filler_cells").map(|s| split_list(&s)).unwrap_or_default();
        let bond = opt("bond_pad_cell", "-bond_pad_cell");
        let style = opt("bond_style", "-bond_style").unwrap_or("inline".into());
        if !["inline", "staggered"].contains(&style.as_str()) {
            return err(&format!("create_pad_ring: -bond_style '{}': inline or staggered (IO-205)", style));
        }
        let spacing: f64 = opt("pad_spacing", "-pad_spacing").and_then(|s| s.parse().ok()).unwrap_or(0.0);
        let distribute = opt("distribute", "-distribute").unwrap_or("even".into());
        let mut corient: HashMap<String, String> = [("ll", "N"), ("lr", "FN"), ("ul", "FS"), ("ur", "S")].iter().map(|(a, b)| (a.to_string(), b.to_string())).collect();
        if let Some(s) = x.get("-corner_orientation") {
            let v = split_list(s);
            for k in v.chunks(2) {
                if k.len() == 2 { corient.insert(k[0].clone(), k[1].clone()); }
            }
        }
        // ---- ring: inside the seal ring
        let seal = fp.special.iter().filter(|s| s.kind == "seal_ring").map(|s| s.bbox()).collect::<Vec<_>>();
        let seal_in = seal.iter().map(|b| {
            // inner extent of a bar touching the die edge
            if (b.0 - fp.die.0) < 1e-6 + 50.0 && (b.2 - b.0) < (b.3 - b.1) { b.2 - fp.die.0 }
            else if (b.1 - fp.die.1) < 50.0 && (b.3 - b.1) < (b.2 - b.0) { b.3 - fp.die.1 }
            else { 0.0 }
        }).fold(0.0f64, f64::max);
        let roff: f64 = x.num("-ring_offset").unwrap_or(0.0) + seal_in;
        let ring: Rect = (fp.die.0 + roff, fp.die.1 + roff, fp.die.2 - roff, fp.die.3 - roff);
        // ---- corners
        let cc = corner_cell.clone().or_else(|| of.corners.iter().find(|c| !c.2.is_empty()).map(|c| c.2.clone()));
        let csz = match &cc { Some(c) => self.lef_size(c)?.0, None => 0.0 };
        let mut created = 0usize;
        let mut inserted = 0usize;
        let mut io_pads: Vec<IoPad> = vec![];
        let mut plan: Vec<(String, String, (f64, f64), String)> = vec![]; // inst, cell, ll, orient
        if let Some(c) = &cc {
            for k in ["ll", "lr", "ul", "ur"] {
                let o = of.corners.iter().find(|e| e.0 == k).map(|e| if e.1.is_empty() { corient[k].clone() } else { e.1.clone() }).unwrap_or_else(|| corient[k].clone());
                let cellk = of.corners.iter().find(|e| e.0 == k && !e.2.is_empty()).map(|e| e.2.clone()).unwrap_or(c.clone());
                let ll = match k { "ll" => (ring.0, ring.1), "lr" => (ring.2 - csz, ring.1), "ul" => (ring.0, ring.3 - csz), _ => (ring.2 - csz, ring.3 - csz) };
                plan.push((format!("corner_{}", k), cellk, ll, o));
                io_pads.push(IoPad { inst: format!("corner_{}", k), side: k.into(), order: 0, domain: String::new(), kind: "corner".into() });
            }
        }
        // ---- pads per side
        let mut depth: f64 = 0.0;
        let mut gaps: Vec<(String, f64, f64)> = vec![]; // side, start, len (along the side)
        let mut fill_plan: Vec<(String, f64, f64)> = vec![];
        for side in ["bottom", "right", "top", "left"] {
            let list: Vec<&OrderEntry> = of.entries.iter().filter(|e| e.side == side).collect();
            let along_h = side == "bottom" || side == "top";
            let (s0, s1) = if along_h { (ring.0 + csz, ring.2 - csz) } else { (ring.1 + csz, ring.3 - csz) };
            let len = s1 - s0;
            let mut ws = vec![];
            for e in &list {
                let (w, h) = self.lef_size(&e.cell)?;
                depth = depth.max(h);
                ws.push(w);
            }
            let tot: f64 = ws.iter().sum();
            let n = list.len();
            if tot + spacing * n.saturating_sub(1) as f64 > len + 1e-6 {
                return err(&format!("create_pad_ring: {} side needs {:.1} um of pads, {:.1} um available (IO-210)", side, tot + spacing * n.saturating_sub(1) as f64, len));
            }
            let min_fill = fillers.iter().filter_map(|f| self.lef.get(f).map(|m| m.w)).fold(f64::MAX, f64::min);
            let unit = if min_fill.is_finite() && min_fill < f64::MAX { min_fill } else { 0.001 };
            // gap between pads: even distribution (rounded down to the filler unit) or abutted
            let g = if distribute == "abut" || n == 0 { spacing } else { (((len - tot) / (n + 1) as f64) / unit).floor() * unit };
            let g = g.max(spacing);
            let lead = if distribute == "abut" { ((len - tot - spacing * n.saturating_sub(1) as f64) / 2.0 / unit).floor() * unit } else { g };
            let mut cur = s0 + lead;
            if lead > 1e-9 { fill_plan.push((side.into(), s0, lead)); }
            for (k, e) in list.iter().enumerate() {
                let (w, h) = self.lef_size(&e.cell)?;
                let (orient, ll) = match side {
                    "bottom" => ("N", (cur, ring.1)),
                    "top" => ("S", (cur, ring.3 - h)),
                    "left" => ("E", (ring.0, cur)),
                    _ => ("W", (ring.2 - h, cur)),
                };
                plan.push((e.inst.clone(), e.cell.clone(), ll, orient.into()));
                let class = self.lef.get(&e.cell).map(|m| m.class.clone()).unwrap_or_default();
                let kind = if e.kind.is_empty() { pad_kind(&e.cell, &class) } else { e.kind.clone() };
                io_pads.push(IoPad { inst: e.inst.clone(), side: side.into(), order: k, domain: e.domain.clone(), kind });
                cur += w;
                let next_gap = if k + 1 < n { g } else { s1 - cur };
                if next_gap > 1e-9 { fill_plan.push((side.into(), cur, next_gap)); }
                cur += if k + 1 < n { g } else { 0.0 };
            }
            if n == 0 && len > 0.0 { fill_plan.push((side.into(), s0, len)); }
        }
        // ---- previous ring: drop IO fillers and unlisted unconnected pads
        {
            let keep: std::collections::HashSet<&String> = plan.iter().map(|p| &p.0).collect();
            let nl = self.nl.as_mut().unwrap();
            let mut gone = 0;
            for c in nl.cell_ids() {
                let cl = nl.cell(c);
                if !cl.attrs.iter().any(|a| a == "io_pad") || keep.contains(&cl.name) { continue; }
                let filler = cl.attrs.iter().any(|a| a == "io_kind:filler");
                if filler || cl.pins.iter().all(|p| p.net.is_none()) {
                    nl.remove_cell(c);
                    if !filler { gone += 1; }
                }
            }
            if gone > 0 {
                crate::info!("IO-221", "Removed {} unconnected pad instance(s) not in the new pad order", gone);
            }
        }
        // ---- create + place pads and corners
        for (inst, cell, ll, orient) in &plan {
            let existed = self.nl.as_ref().unwrap().cell_by_name(inst).is_some();
            let c = self.make_inst(inst, cell)?;
            if !existed { created += 1; }
            let e = of.entries.iter().find(|e| e.inst == *inst);
            if let (Some(e), false) = (e, x.has("-no_insert")) {
                if let Some(p) = &e.port {
                    if self.insert_pad(p, c)? { inserted += 1; }
                }
            }
            let io = io_pads.iter().find(|p| p.inst == *inst).cloned().unwrap_or_default();
            let cl = self.nl.as_mut().unwrap().cell_mut(c);
            cl.loc = Some(*ll);
            cl.fixed = true;
            cl.attrs.retain(|a| !a.starts_with("orient:") && !a.starts_with("io_"));
            cl.attrs.push(format!("orient:{}", orient));
            cl.attrs.push("io_pad".into());
            cl.attrs.push(format!("io_side:{}", io.side));
            cl.attrs.push(format!("io_kind:{}", io.kind));
            if !io.domain.is_empty() { cl.attrs.push(format!("io_domain:{}", io.domain)); }
        }
        // ---- chip-level ports sit on the PAD pins of their pads
        {
            let lef = self.lef.clone();
            let nl = self.nl.as_mut().unwrap();
            let fpm = self.fp.as_mut().unwrap();
            for e in &of.entries {
                let (Some(p), Some(c)) = (e.port.as_ref().and_then(|p| nl.port_by_name(p)), nl.cell_by_name(&e.inst)) else { continue };
                let sh = crate::lef::pin_shapes(&lef, nl.cell(c), "PAD");
                let Some((ly, r)) = sh.first() else { continue };
                // DEF pin point on the outer edge of the PAD shape, shape (width along the edge, depth)
                let (loc, wd) = match e.side.as_str() {
                    "bottom" => (((r.0 + r.2) / 2.0, r.1), (r.2 - r.0, r.3 - r.1)),
                    "top" => (((r.0 + r.2) / 2.0, r.3), (r.2 - r.0, r.3 - r.1)),
                    "left" => ((r.0, (r.1 + r.3) / 2.0), (r.3 - r.1, r.2 - r.0)),
                    _ => ((r.2, (r.1 + r.3) / 2.0), (r.3 - r.1, r.2 - r.0)),
                };
                nl.ports[p].loc = Some(loc);
                let pn = nl.ports[p].name.clone();
                fpm.pin_info.insert(pn.clone(), (e.side.clone(), ly.clone(), "pad".into()));
                fpm.fixed_ports.insert(pn.clone());
                fpm.pin_shapes.insert(pn, wd);
            }
        }
        // ---- IO fillers in the gaps (largest first)
        let mut fws: Vec<(String, f64)> = fillers.iter().filter_map(|f| self.lef.get(f).map(|m| (f.clone(), m.w))).collect();
        fws.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
        let mut nfill = 0usize;
        let mut k = 0usize;
        for (side, start, len) in fill_plan {
            let mut cur = start;
            let end = start + len;
            for (fc, fw) in &fws {
                while cur + fw <= end + 1e-6 {
                    let (h, orient, ll) = {
                        let h = self.lef.get(fc).map(|m| m.h).unwrap_or(depth);
                        match side.as_str() { "bottom" => (h, "N", (cur, ring.1)), "top" => (h, "S", (cur, ring.3 - h)), "left" => (h, "E", (ring.0, cur)), _ => (h, "W", (ring.2 - h, cur)) }
                    };
                    let _ = h;
                    k += 1;
                    let nm = format!("iofill_{}_{}", side, k);
                    let c = self.make_inst(&nm, fc)?;
                    let cl = self.nl.as_mut().unwrap().cell_mut(c);
                    cl.loc = Some(ll);
                    cl.fixed = true;
                    cl.attrs.retain(|a| !a.starts_with("orient:"));
                    cl.attrs.push(format!("orient:{}", orient));
                    cl.attrs.push("io_pad".into());
                    cl.attrs.push(format!("io_side:{}", side));
                    cl.attrs.push("io_kind:filler".into());
                    io_pads.push(IoPad { inst: nm, side: side.clone(), order: usize::MAX, domain: String::new(), kind: "filler".into() });
                    nfill += 1;
                    cur += fw;
                }
            }
            if end - cur > 1e-6 {
                gaps.push((side.clone(), cur, end - cur));
            }
        }
        // ---- bond pads
        let mut bps: Vec<BondPad> = vec![];
        if let Some(bc) = &bond {
            let (bw, bh) = self.lef_size(bc)?;
            let sg = x.num("-stagger_gap").unwrap_or(4.0);
            let nl = self.nl.as_ref().unwrap();
            for p in io_pads.iter().filter(|p| !matches!(p.kind.as_str(), "corner" | "filler" | "breaker" | "clamp")) {
                let Some(c) = nl.cell_by_name(&p.inst) else { continue };
                let cl = nl.cell(c);
                let Some(m) = crate::lef::phys(&self.lef, cl) else { continue };
                let row = if style == "staggered" { p.order % 2 } else { 0 };
                let y0 = if row == 0 { 0.0 } else { bh + sg };
                if y0 + bh > m.h + 1e-6 {
                    return err(&format!("create_pad_ring: staggered bond pads need {:.1} um, pad '{}' is {:.1} um deep (IO-211)", y0 + bh, p.inst, m.h));
                }
                let local = (m.w / 2.0 - bw / 2.0, y0, m.w / 2.0 + bw / 2.0, y0 + bh);
                let r = crate::lef::place_rect(local, m.w, m.h, crate::lef::orient_of(cl), cl.loc.unwrap());
                bps.push(BondPad { name: format!("bp_{}", p.inst.replace('/', "_")), pad: p.inst.clone(), cell: bc.clone(), rect: r, row });
            }
        }
        // ---- core clearance
        if let Some(core) = fp.core {
            let inner = (ring.0 + depth, ring.1 + depth, ring.2 - depth, ring.3 - depth);
            if core.0 < inner.0 - 1e-6 || core.1 < inner.1 - 1e-6 || core.2 > inner.2 + 1e-6 || core.3 > inner.3 + 1e-6 {
                crate::warn!("IO-212", "Core {} overlaps the pad ring (inner edge {})", fr(&core), fr(&inner));
            }
        }
        let fpm = self.fp.as_mut().unwrap();
        fpm.io.pads = io_pads.clone();
        fpm.io.bond_pads = bps.clone();
        fpm.io.ring = Some(ring);
        fpm.io.pad_depth = depth;
        fpm.io.style = style.clone();
        for (s, st, l) in &gaps {
            crate::warn!("IO-213", "Pad ring gap on the {} side at {:.3}: {:.3} um not filled (no filler that small)", s, st, l);
        }
        let npads = io_pads.iter().filter(|p| !matches!(p.kind.as_str(), "corner" | "filler")).count();
        crate::info!("IO-220", "Pad ring {}: {} pad(s) ({} port(s) padded, {} new instance(s)), {} corner(s), {} IO filler(s), {} {} bond pad(s), pad depth {:.1} um, {} gap(s)",
            fr(&ring), npads, inserted, created, io_pads.iter().filter(|p| p.kind == "corner").count(), nfill, bps.len(), style, depth, gaps.len());
        Ok(npads.to_string())
    }

    fn c_report_ring(&mut self, _a: &[String]) -> R {
        let fp = self.fp.as_ref().ok_or_else(|| Flow::Err("no floorplan (FP-001)".into()))?;
        let nl = self.nl()?;
        crate::out!("****************************************\nReport : pad_ring ({} bond pads)\n****************************************", fp.io.style);
        crate::out!("{:<6} {:<22} {:<10} {:<10} {:<10} {:<6} {:>20}", "Side", "Instance", "Cell", "Kind", "Domain", "Orient", "Location");
        for side in ["ll", "bottom", "lr", "right", "ur", "top", "ul", "left"] {
            let mut v: Vec<&IoPad> = fp.io.pads.iter().filter(|p| p.side == side && p.kind != "filler").collect();
            v.sort_by_key(|p| p.order);
            for p in v {
                let (cell, ori, loc) = nl.cell_by_name(&p.inst).map(|c| {
                    let cl = nl.cell(c);
                    (crate::lef::master(cl).unwrap_or("?").to_string(), crate::lef::orient_of(cl).to_string(), cl.loc.map(|l| format!("({:.1},{:.1})", l.0, l.1)).unwrap_or_default())
                }).unwrap_or_default();
                crate::out!("{:<6} {:<22} {:<10} {:<10} {:<10} {:<6} {:>20}", p.side, p.inst, cell, p.kind, p.domain, ori, loc);
            }
        }
        let nf = fp.io.pads.iter().filter(|p| p.kind == "filler").count();
        crate::out!("{} IO filler(s), {} bond pad(s)", nf, fp.io.bond_pads.len());
        Ok(String::new())
    }

    fn c_check_bond(&mut self, a: &[String]) -> R {
        let x = args(a, &["-min_pitch", "-min_row_pitch"]);
        let fp = self.fp.as_ref().ok_or_else(|| Flow::Err("no floorplan (FP-001)".into()))?;
        if fp.io.bond_pads.is_empty() {
            return err("check_bond_pads: no bond pads (create_pad_ring -bond_pad_cell) (BOND-000)");
        }
        let min_pitch = x.num("-min_pitch").unwrap_or(40.0);
        // staggered: pads of the same row need the full pitch, neighbours only the reduced one
        let row_pitch = x.num("-min_row_pitch").unwrap_or(min_pitch);
        let mut viol: Vec<String> = vec![];
        let mut minp: HashMap<(String, usize), f64> = HashMap::new();
        let mut min_adj = f64::MAX;
        let side_of = |pad: &str| fp.io.pads.iter().find(|p| p.inst == pad).map(|p| p.side.clone()).unwrap_or_default();
        for side in ["bottom", "right", "top", "left"] {
            let along_h = side == "bottom" || side == "top";
            let mut v: Vec<(f64, usize, String, Rect)> = fp.io.bond_pads.iter().filter(|b| side_of(&b.pad) == side)
                .map(|b| (if along_h { (b.rect.0 + b.rect.2) / 2.0 } else { (b.rect.1 + b.rect.3) / 2.0 }, b.row, b.name.clone(), b.rect)).collect();
            v.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
            for w in v.windows(2) {
                let d = w[1].0 - w[0].0;
                min_adj = min_adj.min(d);
                if fp.io.style == "inline" && d < min_pitch - 1e-6 {
                    viol.push(format!("BOND-001 {} side: bond pads {} and {} at pitch {:.2} < {:.2} um", side, w[0].2, w[1].2, d, min_pitch));
                }
                let (a0, b0) = (&w[0].3, &w[1].3);
                if a0.0 < b0.2 - 1e-6 && b0.0 < a0.2 - 1e-6 && a0.1 < b0.3 - 1e-6 && b0.1 < a0.3 - 1e-6 {
                    viol.push(format!("BOND-004 {} side: bond pads {} and {} overlap", side, w[0].2, w[1].2));
                }
            }
            for row in 0..2 {
                let r: Vec<&(f64, usize, String, Rect)> = v.iter().filter(|e| e.1 == row).collect();
                for w in r.windows(2) {
                    let d = w[1].0 - w[0].0;
                    let e = minp.entry((side.to_string(), row)).or_insert(f64::MAX);
                    *e = e.min(d);
                    if fp.io.style == "staggered" && d < min_pitch - 1e-6 {
                        viol.push(format!("BOND-001 {} side row {}: bond pads {} and {} at pitch {:.2} < {:.2} um", side, row, w[0].2, w[1].2, d, min_pitch));
                    }
                }
            }
            if fp.io.style == "staggered" {
                for w in v.windows(2) {
                    if w[1].1 == w[0].1 && w[1].0 - w[0].0 < row_pitch - 1e-6 {
                        viol.push(format!("BOND-005 {} side: consecutive pads {} and {} on the same row", side, w[0].2, w[1].2));
                    }
                }
            }
        }
        for b in &fp.io.bond_pads {
            let d = fp.die;
            if b.rect.0 < d.0 - 1e-6 || b.rect.1 < d.1 - 1e-6 || b.rect.2 > d.2 + 1e-6 || b.rect.3 > d.3 + 1e-6 {
                viol.push(format!("BOND-002 bond pad {} outside the die", b.name));
            }
        }
        for p in fp.io.pads.iter().filter(|p| !matches!(p.kind.as_str(), "corner" | "filler" | "breaker" | "clamp")) {
            if !fp.io.bond_pads.iter().any(|b| b.pad == p.inst) {
                viol.push(format!("BOND-003 pad {} has no bond pad", p.inst));
            }
        }
        let mut rows: Vec<String> = minp.iter().map(|((s, r), v)| format!("{} r{} {:.1}", s, r, v)).collect();
        rows.sort();
        for v in viol.iter().take(30) {
            crate::out!("  {}", v);
        }
        crate::info!("BOND-100", "Wire-bond check ({}): {} bond pad(s), min neighbour pitch {:.2} um, min same-row pitch [{}], {} violation(s)",
            fp.io.style, fp.io.bond_pads.len(), if min_adj < f64::MAX { min_adj } else { 0.0 }, rows.join(", "), viol.len());
        Ok(viol.len().to_string())
    }

    fn c_check_esd(&mut self, a: &[String]) -> R {
        let x = args(a, &["-max_clamp_distance", "-max_signals_per_supply", "-clamp_cells", "-breaker_cells"]);
        let fp = self.fp.as_ref().ok_or_else(|| Flow::Err("no floorplan (FP-001)".into()))?;
        let nl = self.nl()?;
        if fp.io.pads.is_empty() {
            return err("check_esd: no pad ring (create_pad_ring) (ESD-000)");
        }
        let maxd = x.num("-max_clamp_distance").unwrap_or(400.0);
        let maxs = x.num("-max_signals_per_supply").unwrap_or(4.0);
        let clamp_p: Vec<String> = x.get("-clamp_cells").map(|s| split_list(s)).unwrap_or_default();
        let brk_p: Vec<String> = x.get("-breaker_cells").map(|s| split_list(s)).unwrap_or_default();
        let ring = fp.io.ring.unwrap_or(fp.die);
        let (w, h) = (ring.2 - ring.0, ring.3 - ring.1);
        let per = 2.0 * (w + h);
        // ring objects in counter-clockwise order: (t0, t1, inst, kind, domain)
        let mut objs: Vec<(f64, f64, String, String, String)> = vec![];
        for p in &fp.io.pads {
            let Some(c) = nl.cell_by_name(&p.inst) else { continue };
            let cl = nl.cell(c);
            let Some(r) = crate::lef::cell_rect(&self.lef, cl) else { continue };
            let m = crate::lef::master(cl).unwrap_or("");
            let mut kind = p.kind.clone();
            if clamp_p.iter().any(|q| glob(q, m)) { kind = "clamp".into(); }
            if brk_p.iter().any(|q| glob(q, m)) { kind = "breaker".into(); }
            let (t0, t1) = match p.side.as_str() {
                "bottom" => (r.0 - ring.0, r.2 - ring.0),
                "right" => (w + r.1 - ring.1, w + r.3 - ring.1),
                "top" => (w + h + ring.2 - r.2, w + h + ring.2 - r.0),
                "left" => (2.0 * w + h + ring.3 - r.3, 2.0 * w + h + ring.3 - r.1),
                "ll" => (0.0, r.2 - ring.0),
                "lr" => (r.0 - ring.0, w + r.3 - ring.1),
                "ur" => (w + r.1 - ring.1, w + h + ring.2 - r.0),
                _ => (w + h + ring.2 - r.2, 2.0 * w + h + ring.3 - r.1),
            };
            objs.push((t0, t1, p.inst.clone(), kind, p.domain.clone()));
        }
        objs.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
        let mut viol: Vec<String> = vec![];
        // ESD-001 corners
        for k in ["ll", "lr", "ul", "ur"] {
            if !fp.io.pads.iter().any(|p| p.side == k && p.kind == "corner") {
                viol.push(format!("ESD-001 missing corner cell at {}", k));
            }
        }
        // ESD-002 continuity of the ring (pad power rails)
        for wdw in objs.windows(2) {
            let gap = wdw[1].0 - wdw[0].1;
            if gap > 1e-3 {
                viol.push(format!("ESD-002 ring gap of {:.3} um between {} and {}", gap, wdw[0].2, wdw[1].2));
            } else if gap < -1e-3 {
                viol.push(format!("ESD-009 {} and {} overlap by {:.3} um", wdw[0].2, wdw[1].2, -gap));
            }
        }
        // segments between breakers (circular)
        let bidx: Vec<usize> = objs.iter().enumerate().filter(|(_, o)| o.3 == "breaker").map(|(i, _)| i).collect();
        let n = objs.len();
        let mut segs: Vec<Vec<usize>> = vec![];
        if bidx.is_empty() {
            segs.push((0..n).collect());
        } else {
            for (k, &b) in bidx.iter().enumerate() {
                let e = bidx[(k + 1) % bidx.len()];
                let mut v = vec![];
                let mut i = (b + 1) % n;
                while i != e {
                    v.push(i);
                    i = (i + 1) % n;
                }
                segs.push(v);
            }
        }
        let pos = |i: usize| (objs[i].0 + objs[i].1) / 2.0;
        let ring_dist = |a: f64, b: f64| { let d = (a - b).abs(); d.min(per - d) };
        let mut summary = vec![];
        for (si, sg) in segs.iter().enumerate() {
            let pads: Vec<usize> = sg.iter().copied().filter(|i| !matches!(objs[*i].3.as_str(), "filler" | "corner")).collect();
            let mut doms: Vec<String> = pads.iter().map(|i| objs[*i].4.clone()).filter(|d| !d.is_empty()).collect();
            doms.sort();
            doms.dedup();
            if doms.len() > 1 {
                viol.push(format!("ESD-003 IO domains {} adjoin without a breaker cell (segment {})", doms.join(" / "), si));
            }
            let dom = if doms.is_empty() { "-".to_string() } else { doms.join("+") };
            let clamps: Vec<usize> = pads.iter().copied().filter(|i| objs[*i].3 == "clamp").collect();
            let sig: Vec<usize> = pads.iter().copied().filter(|i| objs[*i].3 == "signal").collect();
            let iop = pads.iter().filter(|i| objs[**i].3 == "io_power").count();
            let iog = pads.iter().filter(|i| objs[**i].3 == "io_ground").count();
            if !sig.is_empty() && clamps.is_empty() {
                viol.push(format!("ESD-004 domain {} (segment {}): {} signal pad(s) but no power clamp cell", dom, si, sig.len()));
            }
            if !sig.is_empty() && (iop == 0 || iog == 0) {
                viol.push(format!("ESD-005 domain {} (segment {}): missing IO {} pad", dom, si, if iop == 0 { "power" } else { "ground" }));
            }
            let mut worst = 0.0f64;
            for &s in &sig {
                let d = clamps.iter().map(|c| ring_dist(pos(s), pos(*c))).fold(f64::MAX, f64::min);
                if d < f64::MAX { worst = worst.max(d); }
                if d < f64::MAX && d > maxd {
                    viol.push(format!("ESD-006 signal pad {} is {:.1} um from the nearest power clamp (max {:.1})", objs[s].2, d, maxd));
                }
            }
            let pairs = iop.min(iog).max(1);
            if sig.len() as f64 / pairs as f64 > maxs + 1e-9 {
                viol.push(format!("ESD-007 domain {} (segment {}): {} signal pads per IO supply pair (max {}) (SSO)", dom, si, sig.len() as f64 / pairs as f64, maxs));
            }
            summary.push(format!("{}: {} signal, {} clamp, {} VDDIO, {} VSSIO, worst clamp distance {:.1} um", dom, sig.len(), clamps.len(), iop, iog, worst));
        }
        // ESD-008: breakers between identical domains
        for &b in &bidx {
            let dom_at = |dir: i64| -> Option<String> {
                let mut i = b as i64;
                for _ in 0..n {
                    i = (i + dir).rem_euclid(n as i64);
                    let o = &objs[i as usize];
                    if !o.4.is_empty() && !matches!(o.3.as_str(), "filler" | "corner" | "breaker") { return Some(o.4.clone()); }
                }
                None
            };
            if let (Some(l), Some(r)) = (dom_at(-1), dom_at(1)) {
                if l == r {
                    viol.push(format!("ESD-008 breaker {} separates the same domain {} (warning)", objs[b].2, l));
                }
            }
        }
        crate::out!("****************************************\nReport : check_esd (pad ring ESD / IO rules)\n****************************************");
        for s in &summary {
            crate::out!("  segment {}", s);
        }
        for v in viol.iter().take(40) {
            crate::out!("  {}", v);
        }
        let errs = viol.iter().filter(|v| !v.contains("(warning)")).count();
        crate::info!("ESD-100", "IO ring checks: {} object(s), {} domain segment(s), {} violation(s), {} warning(s)", objs.len(), segs.len(), errs, viol.len() - errs);
        Ok(errs.to_string())
    }

    fn c_seal_ring(&mut self, a: &[String]) -> R {
        let x = args(a, &["-width", "-height", "-layers", "-offset", "-chamfer", "-net"]);
        let w = x.num("-width").ok_or_else(|| Flow::Err("create_seal_ring: -width required (CMD-001)".into()))?;
        let h = x.num("-height").unwrap_or(w);
        if w <= 0.0 || h <= 0.0 {
            return err("create_seal_ring: -width / -height must be positive (SEAL-001)");
        }
        let fp = self.fp.as_mut().ok_or_else(|| Flow::Err("create_seal_ring: no floorplan (FP-001)".into()))?;
        let layers: Vec<String> = x.get("-layers").map(|s| split_list(s)).unwrap_or_else(|| fp.layers.iter().map(|l| l.name.clone()).collect());
        for l in &layers {
            if !fp.layers.iter().any(|y| y.name == *l) && l != "AP" {
                return err(&format!("create_seal_ring: layer '{}' unknown (SEAL-002)", l));
            }
        }
        let o = x.num("-offset").unwrap_or(0.0);
        let ch = x.num("-chamfer").unwrap_or(0.0);
        let d = fp.die;
        let (x0, y0, x1, y1) = (d.0 + o, d.1 + o, d.2 - o, d.3 - o);
        if x1 - x0 < 4.0 * w || y1 - y0 < 4.0 * h {
            return err("create_seal_ring: the die is too small for the ring (SEAL-003)");
        }
        let net = x.get("-net").cloned().unwrap_or("SEALRING".into());
        fp.special.retain(|s| s.kind != "seal_ring");
        let mut n = 0;
        for l in &layers {
            // four bars, shortened by the chamfer; 45-degree corner pieces when chamfered
            let c = ch.max(0.0);
            let bars = [
                (x0, y0 + c, x0 + w, y1 - c),       // left
                (x1 - w, y0 + c, x1, y1 - c),       // right
                (x0 + c, y0, x1 - c, y0 + h),       // bottom
                (x0 + c, y1 - h, x1 - c, y1),       // top
            ];
            for (k, b) in bars.iter().enumerate() {
                fp.special.push(SpecialShape { name: format!("seal_{}_{}", l, k), net: net.clone(), layer: l.clone(), kind: "seal_ring".into(), width: 0.0, pts: vec![(b.0, b.1), (b.2, b.3)], rect: Some(*b), ..Default::default() });
                n += 1;
            }
            if c > 0.0 {
                let wd = w.min(h);
                let hw = wd / 2.0;
                // centre lines of the corner pieces (45 degrees)
                let pieces = [
                    [(x0 + hw, y0 + c), (x0 + c, y0 + hw)],
                    [(x1 - c, y0 + hw), (x1 - hw, y0 + c)],
                    [(x1 - hw, y1 - c), (x1 - c, y1 - hw)],
                    [(x0 + c, y1 - hw), (x0 + hw, y1 - c)],
                ];
                for (k, p) in pieces.iter().enumerate() {
                    fp.special.push(SpecialShape { name: format!("seal_{}_c{}", l, k), net: net.clone(), layer: l.clone(), kind: "seal_ring".into(), width: wd, pts: p.to_vec(), rect: None, ..Default::default() });
                    n += 1;
                }
            }
        }
        crate::info!("SEAL-100", "Seal ring on {} layer(s) [{}]: {} shape(s), bars {:.2} um (left/right) x {:.2} um (top/bottom), offset {:.2} um{}",
            layers.len(), layers.join(" "), n, w, h, o, if ch > 0.0 { format!(", {:.1} um 45-degree chamfers", ch) } else { String::new() });
        // objects that cross the ring
        let inner = (x0 + w, y0 + h, x1 - w, y1 - h);
        if let Some(nl) = self.nl.as_ref() {
            let mut bad = 0;
            for c in nl.cell_ids() {
                if let Some(r) = crate::lef::cell_rect(&self.lef, nl.cell(c)) {
                    if r.0 < inner.0 - 1e-6 || r.1 < inner.1 - 1e-6 || r.2 > inner.2 + 1e-6 || r.3 > inner.3 + 1e-6 { bad += 1; }
                }
            }
            if bad > 0 {
                crate::warn!("SEAL-101", "{} placed macro / pad instance(s) cross the seal ring {}", bad, fr(&inner));
            }
        }
        Ok(n.to_string())
    }
}
