//! Chip / block floorplanning commands.
//!
//!  read_lef files...                         report_lef [pattern]
//!  initialize_floorplan  -die_width/-die_height | -die_size {w h} | -boundary {{..}}
//!                        -core_width/-core_height | -core_size {w h} | -core_boundary {{..}}
//!                        -core_utilization u  -aspect_ratio h/w
//!                        -core2die_spacing {s} | {left bottom right top}  (alias -core_offset)
//!                        -row_height h  [-no_pins]
//!  place_io_pins [-ports pats] [-bus_name pat] [-auto_group_bus] [-direction {top left ..}]
//!                [-layer L] [-width w] [-depth d] [-track_pitch n] [-offset um] [-spacing um]
//!                [-refine] [-random_place [-seed n]]
//!  snap_pins_to_tracks [-ports pats]
//!  move_objects -objects {..} (-to {x y} | -delta {dx dy}) [-orientation o] [-fixed true|false]
//!  snap_macros_to_grid [-cells pats] [-grid {gx gy}] [-origin core|die]
//!  place_macros [-cells pats] [-group_by module|none] [-spacing um] [-halo um] [-channel um]
//!  report_flylines [-cells pats]

use crate::fpcmd::parse_rect;
use crate::netlist::*;
use crate::phys::Floorplan;
use crate::session::{args, Session};
use crate::tcl::{err, split_list, Flow, R};
use std::collections::{HashMap, HashSet};

pub type Rect = (f64, f64, f64, f64);

pub fn nums(s: &str) -> Vec<f64> {
    s.split(|c: char| c.is_whitespace() || c == '{' || c == '}' || c == ',').filter_map(|x| x.parse().ok()).collect()
}
pub fn fr(r: &Rect) -> String {
    format!("({:.2},{:.2})-({:.2},{:.2})", r.0, r.1, r.2, r.3)
}
fn pats(s: &str) -> Vec<String> {
    split_list(s).into_iter().map(|x| crate::cons::Obj::parse(&x).map(|o| o.name().to_string()).unwrap_or(x)).collect()
}
fn bool_opt(v: Option<&String>) -> Option<bool> {
    v.map(|s| matches!(s.to_lowercase().as_str(), "true" | "1" | "on" | "yes"))
}
pub fn bus_key_pub(n: &str) -> (String, i64) {
    bus_key(n)
}
/// natural order: bus bits by index
fn bus_key(n: &str) -> (String, i64) {
    if let Some(i) = n.rfind('[') {
        if let Ok(k) = n[i + 1..].trim_end_matches(']').parse::<i64>() {
            return (n[..i].to_string(), k);
        }
    }
    (n.to_string(), -1)
}
fn rect_overlap(a: &Rect, b: &Rect) -> bool {
    a.0 < b.2 - 1e-6 && b.0 < a.2 - 1e-6 && a.1 < b.3 - 1e-6 && b.1 < a.3 - 1e-6
}
/// tiny deterministic generator
pub struct Lcg(pub u64);
impl Lcg {
    pub fn next(&mut self) -> u64 {
        self.0 = self.0.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        self.0 >> 33
    }
    pub fn below(&mut self, n: usize) -> usize {
        if n == 0 { 0 } else { (self.next() % n as u64) as usize }
    }
}

/// segments (a,b) and (c,d) properly intersect
pub fn seg_cross(a: (f64, f64), b: (f64, f64), c: (f64, f64), d: (f64, f64)) -> bool {
    let o = |p: (f64, f64), q: (f64, f64), r: (f64, f64)| (q.0 - p.0) * (r.1 - p.1) - (q.1 - p.1) * (r.0 - p.0);
    let (d1, d2, d3, d4) = (o(c, d, a), o(c, d, b), o(a, b, c), o(a, b, d));
    ((d1 > 1e-9 && d2 < -1e-9) || (d1 < -1e-9 && d2 > 1e-9)) && ((d3 > 1e-9 && d4 < -1e-9) || (d3 < -1e-9 && d4 > 1e-9))
}

impl Session {
    pub fn chipfp_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "read_lef" | "read_physical_library" => self.c_read_lef(a),
            "report_lef" => self.c_report_lef(a),
            "place_io_pins" | "place_ios" => self.c_place_io_pins(a),
            "snap_pins_to_tracks" | "align_pins_to_tracks" => self.c_snap_pins(a),
            "move_objects" | "move_cell" | "set_cell_location" => self.c_move_objects(a),
            "snap_macros_to_grid" | "align_macros_to_grid" => self.c_snap_macros(a),
            "place_macros" | "create_macro_placement" => self.c_place_macros(a),
            "report_flylines" => self.c_report_flylines(a).map(|v| format!("{} {:.1}", v.0, v.1)),
            _ => return self.padring_cmd(name, a),
        })
    }

    // ------------------------------------------------------------------ LEF
    fn c_read_lef(&mut self, a: &[String]) -> R {
        let x = args(a, &[]);
        let files: Vec<String> = x.pos.iter().flat_map(|p| split_list(p)).collect();
        if files.is_empty() {
            return err("read_lef: file name(s) required (CMD-001)");
        }
        for f in files {
            let txt = std::fs::read_to_string(&f).map_err(|e| Flow::Err(format!("read_lef: {}: {} (LEF-001)", f, e)))?;
            let (ms, ls) = crate::lef::parse(&txt, &f).map_err(|e| Flow::Err(format!("read_lef: {} (LEF-002)", e)))?;
            let mut cls: HashMap<String, usize> = HashMap::new();
            for m in &ms {
                *cls.entry(m.class.split_whitespace().next().unwrap_or("?").to_string()).or_default() += 1;
            }
            let mut cl: Vec<String> = cls.iter().map(|(k, v)| format!("{} {}", v, k)).collect();
            cl.sort();
            crate::info!("LEF-100", "Read LEF '{}': {} macro(s) ({}), {} layer(s)", f, ms.len(), cl.join(", "), ls.len());
            for m in ms {
                self.lef.insert(m.name.clone(), m);
            }
            let vr = crate::lef::parse_via_rules(&txt);
            if !vr.is_empty() { crate::info!("LEF-101", "{} via generation rule(s) ({})", vr.len(), vr.iter().map(|r| r.name.clone()).collect::<Vec<_>>().join(" ")); }
            for r in vr { self.pgx.via_rules.retain(|o| o.name != r.name); self.pgx.via_rules.push(r); }
            for l in ls {
                self.lef_layers.retain(|o| o.name != l.name);
                self.lef_layers.push(l);
            }
        }
        Ok(String::new())
    }

    fn c_report_lef(&mut self, a: &[String]) -> R {
        let x = args(a, &[]);
        let pat = x.pos.first().cloned().unwrap_or("*".into());
        let mut v: Vec<&crate::lef::LefMacro> = self.lef.values().filter(|m| glob(&pat, &m.name)).collect();
        v.sort_by(|a, b| a.name.cmp(&b.name));
        crate::out!("{:<18} {:<18} {:>9} {:>9} {:>5} {:>4}", "Macro", "Class", "Width", "Height", "Pins", "OBS");
        for m in &v {
            crate::out!("{:<18} {:<18} {:>9.3} {:>9.3} {:>5} {:>4}", m.name, m.class, m.w, m.h, m.pins.len(), m.obs.len());
        }
        Ok(v.len().to_string())
    }

    // ------------------------------------------------------------------ initialize_floorplan
    pub(crate) fn c_init_fp(&mut self, a: &[String]) -> R {
        let x = args(a, &["-boundary", "-core_boundary", "-core_utilization", "-aspect_ratio", "-row_height", "-core_offset", "-core2die_spacing",
            "-die_width", "-die_height", "-core_width", "-core_height", "-die_size", "-core_size", "-site_width"]);
        let nl = self.nl()?;
        let row_h = x.num("-row_height").unwrap_or(1.6);
        let site = x.num("-site_width").unwrap_or_else(|| self.site_w());
        let cell_area: f64 = nl.cell_ids().iter().filter_map(|c| nl.cell(*c).lib()).filter_map(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|c| c.area).sum::<f64>().max(100.0);
        let pair = |k: &str| x.get(k).map(|s| nums(s)).filter(|v| v.len() >= 2).map(|v| (v[0], v[1]));
        let die_wh = pair("-die_size").or_else(|| match (x.num("-die_width"), x.num("-die_height")) {
            (Some(w), Some(h)) => Some((w, h)),
            _ => None,
        });
        if (x.num("-die_width").is_some()) != (x.num("-die_height").is_some()) {
            return err("initialize_floorplan: -die_width and -die_height must be given together (FP-111)");
        }
        let mut core_wh = pair("-core_size").or_else(|| match (x.num("-core_width"), x.num("-core_height")) {
            (Some(w), Some(h)) => Some((w, h)),
            (Some(w), None) => x.num("-aspect_ratio").map(|ar| (w, w * ar)),
            (None, Some(h)) => x.num("-aspect_ratio").map(|ar| (h / ar, h)),
            _ => None,
        });
        let sp: Option<(f64, f64, f64, f64)> = x.get("-core2die_spacing").or(x.get("-core_offset")).map(|s| nums(s)).and_then(|v| match v.len() {
            0 => None,
            1 => Some((v[0], v[0], v[0], v[0])),
            2 => Some((v[0], v[1], v[0], v[1])),
            _ => Some((v[0], v[1], v[2], v[3.min(v.len() - 1)])),
        });
        let die_box = x.get("-boundary").and_then(|b| parse_rect(b));
        let core_box = x.get("-core_boundary").and_then(|b| parse_rect(b));
        let explicit = die_wh.is_some() || core_wh.is_some() || sp.is_some() || core_box.is_some();
        if let Some(u) = x.num("-core_utilization") {
            if !(0.01..=1.0).contains(&u) {
                return err(&format!("initialize_floorplan: -core_utilization {} must be in (0, 1] (FP-112)", u));
            }
        }
        let (die, core) = if !explicit {
            // legacy: rows cover the die
            let die = match die_box {
                Some(r) => r,
                None => {
                    let u = x.num("-core_utilization").unwrap_or(0.6).clamp(0.05, 0.95);
                    let ar = x.num("-aspect_ratio").unwrap_or(1.0);
                    let w = (cell_area / u / ar).sqrt();
                    (0.0, 0.0, w, w * ar)
                }
            };
            (die, None)
        } else {
            let die_r = die_box.or(die_wh.map(|(w, h)| (0.0, 0.0, w, h)));
            if core_wh.is_none() && core_box.is_none() {
                if let (Some(d), Some(s)) = (die_r, sp) {
                    core_wh = Some((d.2 - d.0 - s.0 - s.2, d.3 - d.1 - s.1 - s.3));
                } else if die_r.is_none() || x.num("-core_utilization").is_some() {
                    let u = x.num("-core_utilization").unwrap_or(0.6);
                    let ar = x.num("-aspect_ratio").unwrap_or(1.0);
                    let w = (cell_area / u / ar).sqrt();
                    core_wh = Some((w, w * ar));
                } else {
                    return err("initialize_floorplan: with -die_width/-die_height give -core_width/-core_height, -core2die_spacing or -core_utilization (FP-113)");
                }
            }
            // snap the core to whole sites and rows
            let (mut cw, mut ch) = core_box.map(|c| (c.2 - c.0, c.3 - c.1)).or(core_wh).unwrap();
            cw = (cw / site + 1e-6).floor() * site;
            ch = (ch / row_h + 1e-6).floor() * row_h;
            if cw <= 0.0 || ch <= 0.0 {
                return err("initialize_floorplan: the core has no area (FP-114)");
            }
            let die = match die_r {
                Some(d) => d,
                None => {
                    let s = sp.unwrap_or((0.0, 0.0, 0.0, 0.0));
                    (0.0, 0.0, cw + s.0 + s.2, ch + s.1 + s.3)
                }
            };
            let (cx0, cy0) = match (core_box, sp) {
                (Some(c), _) => (c.0, c.1),
                (None, Some(s)) => (die.0 + s.0, die.1 + s.1),
                (None, None) => (die.0 + ((die.2 - die.0 - cw) / 2.0 / site).floor() * site, die.1 + ((die.3 - die.1 - ch) / 2.0 / row_h).floor() * row_h),
            };
            let core = (cx0, cy0, cx0 + cw, cy0 + ch);
            if core.0 < die.0 - 1e-6 || core.1 < die.1 - 1e-6 || core.2 > die.2 + 1e-6 || core.3 > die.3 + 1e-6 {
                return err(&format!("initialize_floorplan: core {} does not fit in die {} (FP-110)", fr(&core), fr(&die)));
            }
            (die, Some(core))
        };
        let mut fp = Floorplan { dbu: 1000.0, die, core, layers: crate::fplan::lef_route_layers(&self.lef_layers).unwrap_or_else(crate::fplan::default_layers), row_h, design: nl.name.clone(), ..Default::default() };
        if fp.layers.len() >= 4 && !fp.layers.iter().any(|l| l.name == "M3") {
            // block pins default to the 3rd / 4th routing layers of the technology
            fp.block_pins.layers = vec![fp.layers[2].name.clone(), fp.layers[3].name.clone()];
        }
        let reg = fp.place_region();
        fp.rows = ((reg.3 - reg.1) / row_h + 1e-6) as usize;
        if let Some(old) = &self.fp {
            let keep_core = fp.core;
            fp.merge_user(old);
            fp.core = keep_core;
        }
        let util = cell_area / ((reg.2 - reg.0) * (reg.3 - reg.1)).max(1e-9);
        match core {
            Some(c) => crate::info!("FP-100", "Initialized floorplan: die {} ({:.1} x {:.1} um), core {} ({:.1} x {:.1} um, aspect {:.3}), core-to-die spacing L {:.2} B {:.2} R {:.2} T {:.2}, {} rows, utilization {:.1}%",
                fr(&die), die.2 - die.0, die.3 - die.1, fr(&c), c.2 - c.0, c.3 - c.1, (c.3 - c.1) / (c.2 - c.0), c.0 - die.0, c.1 - die.1, die.2 - c.2, die.3 - c.3, fp.rows, 100.0 * util),
            None => crate::info!("FP-100", "Initialized floorplan {} ({:.1} x {:.1} um, {} rows)", crate::fpcmd::fmt_r(&die), die.2 - die.0, die.3 - die.1, fp.rows),
        }
        if util > 1.0 {
            crate::warn!("FP-115", "Standard-cell area {:.1} um^2 exceeds the core area ({:.0}% utilization)", cell_area, 100.0 * util);
        }
        self.fp = Some(fp);
        if !x.has("-no_pins") {
            self.auto_pins();
        }
        Ok(if core.is_some() { format!("{:.4}", util) } else { String::new() })
    }

    // ------------------------------------------------------------------ IO pins
    /// placed positions of the objects connected to a port
    fn port_centroid(&self, p: PortId) -> Option<(f64, f64)> {
        let nl = self.nl.as_ref()?;
        let n = nl.ports[p].net?;
        let mut s = (0.0, 0.0, 0usize);
        for q in Session::leaf_conns(nl, n) {
            if let PinRef::Cell(c, _) = q {
                if nl.cell(c).is_hport() { continue; }
                if let Some(l) = nl.cell(c).loc {
                    s.0 += l.0; s.1 += l.1; s.2 += 1;
                }
            }
        }
        if s.2 == 0 { None } else { Some((s.0 / s.2 as f64, s.1 / s.2 as f64)) }
    }

    fn io_wirelength(&self, ports: &[PortId]) -> f64 {
        let nl = self.nl.as_ref().unwrap();
        ports.iter().filter_map(|p| Some((nl.ports[*p].loc?, self.port_centroid(*p)?))).map(|(a, b)| (a.0 - b.0).abs() + (a.1 - b.1).abs()).sum::<f64>() + 0.0
    }

    fn c_place_io_pins(&mut self, a: &[String]) -> R {
        let x = args(a, &["-ports", "-bus_name", "-direction", "-layer", "-width", "-depth", "-track_pitch", "-offset", "-spacing", "-seed", "-sides"]);
        let fp = self.fp.clone().ok_or_else(|| Flow::Err("place_io_pins: no floorplan (FP-001)".into()))?;
        let nl = self.nl()?;
        // ---- selection
        let pp: Vec<String> = x.get("-ports").map(|s| pats(s)).unwrap_or_default();
        let bp: Vec<String> = x.get("-bus_name").map(|s| pats(s)).unwrap_or_default();
        let mut sel: Vec<PortId> = nl.port_ids().into_iter().filter(|p| {
            let n = &nl.ports[*p].name;
            let base = bus_key(n).0;
            if pp.is_empty() && bp.is_empty() { return true; }
            pp.iter().any(|q| glob(q, n)) || bp.iter().any(|q| glob(q, &base) || glob(q, n))
        }).collect();
        if sel.is_empty() {
            return err("place_io_pins: no port matches (IO-101)");
        }
        sel.sort_by(|a, b| bus_key(&nl.ports[*a].name).cmp(&bus_key(&nl.ports[*b].name)));
        let sides: Vec<String> = x.get("-direction").or(x.get("-sides")).map(|s| split_list(s)).unwrap_or_else(|| vec!["left".into(), "top".into(), "right".into(), "bottom".into()]);
        for s in &sides {
            if !["top", "bottom", "left", "right"].contains(&s.as_str()) {
                return err(&format!("place_io_pins: -direction '{}': expected top, bottom, left or right (IO-102)", s));
            }
        }
        let group_bus = x.has("-auto_group_bus") || !bp.is_empty();
        // ---- units (bus groups or single pins)
        let mut units: Vec<Vec<PortId>> = vec![];
        if group_bus {
            let mut m: Vec<(String, Vec<PortId>)> = vec![];
            for p in &sel {
                let k = bus_key(&nl.ports[*p].name).0;
                match m.iter_mut().find(|e| e.0 == k) {
                    Some(e) => e.1.push(*p),
                    None => m.push((k, vec![*p])),
                }
            }
            units = m.into_iter().map(|e| e.1).collect();
        } else {
            units = sel.iter().map(|p| vec![*p]).collect();
        }
        let before = self.io_wirelength(&sel);
        let die = fp.die;
        let layer_for = |side: &str| -> String {
            if let Some(l) = x.get("-layer") { return l.clone(); }
            let want_h = side == "left" || side == "right";
            fp.layers.iter().skip(2).find(|l| l.horiz == want_h).or(fp.layers.iter().find(|l| l.horiz == want_h)).map(|l| l.name.clone()).unwrap_or("M3".into())
        };
        let pitch_of = |l: &str| fp.layers.iter().find(|y| y.name == l).map(|y| y.pitch).unwrap_or(0.2);
        if let Some(l) = x.get("-layer") {
            if !fp.layers.iter().any(|y| y.name == *l) {
                return err(&format!("place_io_pins: layer '{}' is not a routing layer (IO-103)", l));
            }
        }
        let tp = x.num("-track_pitch").unwrap_or(1.0).max(1.0);
        let refine = x.has("-refine");
        let random = x.has("-random_place");
        let mut rng = Lcg(x.get("-seed").and_then(|s| s.parse().ok()).unwrap_or(7));
        // ---- side per unit
        let centroid = |u: &Vec<PortId>| -> Option<(f64, f64)> {
            let v: Vec<(f64, f64)> = u.iter().filter_map(|p| self.port_centroid(*p)).collect();
            if v.is_empty() { None } else { Some((v.iter().map(|q| q.0).sum::<f64>() / v.len() as f64, v.iter().map(|q| q.1).sum::<f64>() / v.len() as f64)) }
        };
        let side_dist = |s: &str, c: (f64, f64)| -> f64 {
            match s { "left" => c.0 - die.0, "right" => die.2 - c.0, "bottom" => c.1 - die.1, _ => die.3 - c.1 }
        };
        let mut assign: HashMap<String, Vec<(usize, Option<(f64, f64)>)>> = HashMap::new();
        let mut load: HashMap<String, usize> = sides.iter().map(|s| (s.clone(), 0)).collect();
        for (k, u) in units.iter().enumerate() {
            let c = centroid(u);
            let s = if sides.len() == 1 { sides[0].clone() } else if random {
                sides[rng.below(sides.len())].clone()
            } else if let (true, Some(c)) = (refine, c) {
                sides.iter().min_by(|a, b| side_dist(a, c).partial_cmp(&side_dist(b, c)).unwrap()).unwrap().clone()
            } else {
                sides.iter().min_by_key(|s| load[*s]).unwrap().clone()
            };
            *load.get_mut(&s).unwrap() += u.len();
            assign.entry(s).or_default().push((k, c));
        }
        // ---- slots per side, excluding pins of other (unselected) ports
        let selset: HashSet<PortId> = sel.iter().copied().collect();
        let mut placed: Vec<(PortId, (f64, f64), String, String)> = vec![];
        let mut fails = vec![];
        for side in &sides {
            let Some(list) = assign.get(side) else { continue };
            let layer = layer_for(side);
            let pitch = pitch_of(&layer);
            let along_h = side == "top" || side == "bottom";
            let (lo, hi) = if along_h { (die.0, die.2) } else { (die.1, die.3) };
            let step = x.num("-spacing").map(|s| (s / pitch).round().max(1.0) * pitch).unwrap_or(tp * pitch);
            let off = x.num("-offset").unwrap_or(2.0 * pitch).max(pitch);
            // tracks at lo + pitch*(k+1)
            let k0 = ((off / pitch) - 1.0).ceil().max(0.0) as i64;
            let kmax = (((hi - lo - off) / pitch) - 1.0).floor() as i64;
            let stride = (step / pitch).round().max(1.0) as i64;
            let mut slots: Vec<f64> = vec![];
            let mut k = k0;
            while k <= kmax {
                slots.push(lo + pitch * (k + 1) as f64);
                k += stride;
            }
            let taken: Vec<f64> = nl.port_ids().into_iter().filter(|p| !selset.contains(p)).filter_map(|p| {
                let l = nl.ports[p].loc?;
                let (s, ly, _) = fp.pin_info.get(&nl.ports[p].name).cloned().unwrap_or_default();
                if s == *side && ly == layer { Some(if along_h { l.0 } else { l.1 }) } else { None }
            }).collect();
            let mut free: Vec<f64> = slots.into_iter().filter(|v| !taken.iter().any(|t| (t - v).abs() < pitch * 0.5)).collect();
            let need: usize = list.iter().map(|(k, _)| units[*k].len()).sum();
            if need > free.len() {
                fails.push(format!("{}: {} pin(s), {} free slot(s) on {} (pitch {} x {:.3} um)", side, need, free.len(), layer, stride, pitch));
                continue;
            }
            let mut order: Vec<(usize, Option<(f64, f64)>)> = list.clone();
            if random {
                for i in (1..order.len()).rev() { let j = rng.below(i + 1); order.swap(i, j); }
                // random slots, kept in increasing order for buses
                let mut idx: Vec<usize> = (0..free.len()).collect();
                for i in (1..idx.len()).rev() { let j = rng.below(i + 1); idx.swap(i, j); }
                let mut pick: Vec<usize> = idx[..need].to_vec();
                pick.sort();
                free = pick.into_iter().map(|i| free[i]).collect();
            } else if refine {
                order.sort_by(|a, b| {
                    let pa = a.1.map(|c| if along_h { c.0 } else { c.1 }).unwrap_or(f64::MAX);
                    let pb = b.1.map(|c| if along_h { c.0 } else { c.1 }).unwrap_or(f64::MAX);
                    pa.partial_cmp(&pb).unwrap()
                });
            }
            // walk slots in order; with -refine start each unit near its target projection
            let total = free.len();
            // plain placement: the group is centred on the side
            let mut cur = if !refine && !random { (total - need) / 2 } else { 0 };
            let mut remaining = need;
            for (k, c) in &order {
                let u = &units[*k];
                if refine && !random {
                    if let Some(c) = c {
                        let t = if along_h { c.0 } else { c.1 };
                        let want = free.iter().position(|v| *v >= t).unwrap_or(total).saturating_sub(u.len() / 2);
                        // never leave fewer slots than the remaining pins need
                        let maxs = total - remaining;
                        cur = cur.max(want.min(maxs));
                    }
                }
                for (i, p) in u.iter().enumerate() {
                    let v = free[cur + i];
                    let loc = match side.as_str() { "top" => (v, die.3), "bottom" => (v, die.1), "left" => (die.0, v), _ => (die.2, v) };
                    placed.push((*p, loc, side.clone(), layer.clone()));
                }
                cur += u.len();
                remaining -= u.len();
            }
        }
        if !fails.is_empty() {
            return err(&format!("place_io_pins: not enough pin slots: {} (IO-104)", fails.join("; ")));
        }
        let w = x.num("-width");
        let d = x.num("-depth");
        let nlm = self.nl.as_mut().unwrap();
        let fpm = self.fp.as_mut().unwrap();
        for (p, loc, side, layer) in &placed {
            nlm.ports[*p].loc = Some(*loc);
            let n = nlm.ports[*p].name.clone();
            fpm.pin_info.insert(n.clone(), (side.clone(), layer.clone(), "io_pins".into()));
            fpm.fixed_ports.insert(n.clone());
            if w.is_some() || d.is_some() {
                let (dw, dd) = crate::fplan::pin_shape(&fpm.block_pins, &fpm.layers, layer);
                fpm.pin_shapes.insert(n, (w.unwrap_or(dw), d.unwrap_or(dd)));
            }
        }
        let after = self.io_wirelength(&sel);
        let mut per: Vec<String> = sides.iter().map(|s| format!("{} {}", s, placed.iter().filter(|p| p.2 == *s).count())).collect();
        per.retain(|s| !s.ends_with(" 0"));
        crate::info!("IO-100", "Placed {} IO pin(s) in {} group(s) [{}]{}{}{}; pin-to-logic wirelength {:.1} -> {:.1} um",
            placed.len(), units.len(), per.join(", "), if group_bus { ", buses grouped" } else { "" }, if refine { ", refined" } else { "" },
            if random { ", random" } else { "" }, before, after);
        Ok(placed.len().to_string())
    }

    fn c_snap_pins(&mut self, a: &[String]) -> R {
        let x = args(a, &["-ports"]);
        let pp: Vec<String> = x.get("-ports").map(|s| pats(s)).unwrap_or_else(|| vec!["*".into()]);
        let fp = self.fp.clone().ok_or_else(|| Flow::Err("snap_pins_to_tracks: no floorplan (FP-001)".into()))?;
        let die = fp.die;
        let nl = self.nl.as_mut().ok_or_else(|| Flow::Err("no design".into()))?;
        let mut moved = 0;
        let mut maxd: f64 = 0.0;
        let mut used: HashSet<(String, String, i64)> = HashSet::new();
        let mut conflicts = 0;
        let mut ids = nl.port_ids();
        ids.sort_by(|a, b| nl.ports[*a].name.cmp(&nl.ports[*b].name));
        for p in ids {
            let n = nl.ports[p].name.clone();
            if !pp.iter().any(|q| glob(q, &n)) { continue; }
            let Some(l) = nl.ports[p].loc else { continue };
            let (side0, layer, _) = fp.pin_info.get(&n).cloned().unwrap_or_default();
            let side = if side0.is_empty() {
                let d = [("left", l.0 - die.0), ("right", die.2 - l.0), ("bottom", l.1 - die.1), ("top", die.3 - l.1)];
                d.iter().min_by(|a, b| a.1.partial_cmp(&b.1).unwrap()).unwrap().0.to_string()
            } else { side0 };
            let layer = if layer.is_empty() { if side == "top" || side == "bottom" { "M4".to_string() } else { "M3".to_string() } } else { layer };
            let pitch = fp.layers.iter().find(|y| y.name == layer).map(|y| y.pitch).unwrap_or(0.2);
            let along_h = side == "top" || side == "bottom";
            let (lo, v) = if along_h { (die.0, l.0) } else { (die.1, l.1) };
            let mut k = ((v - lo) / pitch - 1.0).round() as i64;
            let k0 = k;
            let mut step = 1i64;
            while used.contains(&(side.clone(), layer.clone(), k)) {
                k = k0 + if step % 2 == 1 { (step + 1) / 2 } else { -(step / 2) };
                step += 1;
            }
            if k != k0 { conflicts += 1; }
            used.insert((side.clone(), layer.clone(), k));
            let nv = lo + pitch * (k + 1) as f64;
            let nl_ = match side.as_str() { "top" => (nv, die.3), "bottom" => (nv, die.1), "left" => (die.0, nv), _ => (die.2, nv) };
            let dd = (nl_.0 - l.0).abs() + (nl_.1 - l.1).abs();
            if dd > 1e-9 {
                moved += 1;
                maxd = maxd.max(dd);
                nl.ports[p].loc = Some(nl_);
            }
        }
        crate::info!("IO-110", "Snapped IO pins to routing tracks: {} moved (max {:.3} um), {} track conflict(s) resolved", moved, maxd, conflicts);
        Ok(moved.to_string())
    }

    // ------------------------------------------------------------------ manual edits
    fn c_move_objects(&mut self, a: &[String]) -> R {
        let x = args(a, &["-objects", "-to", "-delta", "-orientation", "-fixed", "-cells"]);
        let objs: Vec<String> = x.get("-objects").or(x.get("-cells")).map(|s| pats(s)).or_else(|| if x.pos.is_empty() { None } else { Some(x.pos.iter().flat_map(|p| pats(p)).collect()) })
            .ok_or_else(|| Flow::Err("move_objects: -objects required (CMD-001)".into()))?;
        let to = x.get("-to").map(|s| nums(s)).filter(|v| v.len() >= 2).map(|v| (v[0], v[1]));
        let dl = x.get("-delta").map(|s| nums(s)).filter(|v| v.len() >= 2).map(|v| (v[0], v[1]));
        let ori = x.get("-orientation").cloned();
        if let Some(o) = &ori {
            if !["N", "S", "E", "W", "FN", "FS", "FE", "FW", "R0", "R90", "R180", "R270", "MX", "MY", "mirror", "flip"].contains(&o.as_str()) {
                return err(&format!("move_objects: orientation '{}' (FP-152)", o));
            }
        }
        let ori = ori.map(|o| match o.as_str() { "R0" => "N".to_string(), "R90" => "W".into(), "R180" => "S".into(), "R270" => "E".into(), "MX" => "FS".into(), "MY" => "FN".into(), _ => o });
        let fixed = bool_opt(x.get("-fixed"));
        if to.is_none() && dl.is_none() && ori.is_none() && fixed.is_none() {
            return err("move_objects: give -to, -delta, -orientation or -fixed (CMD-001)");
        }
        let die = self.fp.as_ref().map(|f| f.die);
        let nl = self.nl.as_mut().ok_or_else(|| Flow::Err("no design".into()))?;
        let mut n = 0;
        let mut kinds: HashMap<&str, usize> = HashMap::new();
        for c in nl.cell_ids() {
            let name = nl.cell(c).name.clone();
            if !objs.iter().any(|q| glob(q, &name)) || nl.cell(c).is_hport() { continue; }
            let cur = nl.cell(c).loc;
            let nloc = match (to, dl, cur) {
                (Some(t), _, _) => Some(t),
                (None, Some(d), Some(l)) => Some((l.0 + d.0, l.1 + d.1)),
                _ => cur,
            };
            let cl = nl.cell_mut(c);
            cl.loc = nloc;
            if let Some(o) = &ori {
                // mirror / flip: same footprint, mirrored about the cell's own axis
                let o = if o == "mirror" || o == "flip" {
                    let cur = cl.attrs.iter().find_map(|a| a.strip_prefix("orient:")).unwrap_or("N").to_string();
                    match cur.as_str() { "N" => "FN", "FN" => "N", "S" => "FS", "FS" => "S", "E" => "FE", "FE" => "E", "W" => "FW", _ => "W" }.to_string()
                } else { o.clone() };
                cl.attrs.retain(|a| !a.starts_with("orient:"));
                cl.attrs.push(format!("orient:{}", o));
            }
            if let Some(f) = fixed { cl.fixed = f; }
            let k = if crate::lef::phys(&self.lef, nl.cell(c)).map(|m| m.is_pad() || m.is_corner()).unwrap_or(false) { "pad" }
                else if matches!(nl.cell(c).kind, Kind::BlackBox(_)) || crate::lef::phys(&self.lef, nl.cell(c)).map(|m| m.is_block()).unwrap_or(false) { "macro" } else { "cell" };
            *kinds.entry(k).or_default() += 1;
            n += 1;
        }
        for p in nl.port_ids() {
            let name = nl.ports[p].name.clone();
            if !objs.iter().any(|q| glob(q, &name)) { continue; }
            let cur = nl.ports[p].loc;
            nl.ports[p].loc = match (to, dl, cur) { (Some(t), _, _) => Some(t), (None, Some(d), Some(l)) => Some((l.0 + d.0, l.1 + d.1)), _ => cur };
            if let (Some(l), Some(d), Some(fp)) = (nl.ports[p].loc, die, self.fp.as_mut()) {
                let dd = [("left", l.0 - d.0), ("right", d.2 - l.0), ("bottom", l.1 - d.1), ("top", d.3 - l.1)];
                let side = dd.iter().min_by(|a, b| a.1.abs().partial_cmp(&b.1.abs()).unwrap()).unwrap().0.to_string();
                let e = fp.pin_info.entry(name.clone()).or_insert((side.clone(), "M3".into(), "location".into()));
                e.0 = side;
                if fixed != Some(false) { fp.fixed_ports.insert(name.clone()); } else { fp.fixed_ports.remove(&name); }
            }
            *kinds.entry("port").or_default() += 1;
            n += 1;
        }
        if n == 0 {
            return err("move_objects: no object matches (FP-151)");
        }
        let mut k: Vec<String> = kinds.iter().map(|(k, v)| format!("{} {}", v, k)).collect();
        k.sort();
        crate::info!("FP-150", "Moved {} object(s) ({}){}{}", n, k.join(", "), ori.map(|o| format!(", orientation {}", o)).unwrap_or_default(),
            match fixed { Some(true) => ", fixed", Some(false) => ", unfixed", None => "" });
        Ok(n.to_string())
    }

    /// macro cells: (cell, w, h, LEF-placed)
    fn macro_cells(&self, pats_: &[String]) -> Vec<(CellId, f64, f64, bool)> {
        let Some(nl) = self.nl.as_ref() else { return vec![] };
        let msz = { let m = self.appf("place.macro_default_size"); if m > 0.0 { m } else { 16.0 } };
        nl.cell_ids().into_iter().filter_map(|c| {
            let cl = nl.cell(c);
            if !pats_.is_empty() && !pats_.iter().any(|q| glob(q, &cl.name)) { return None; }
            match crate::lef::phys(&self.lef, cl) {
                Some(m) if m.is_block() => Some((c, m.w, m.h, true)),
                Some(_) => None,
                None if matches!(cl.kind, Kind::BlackBox(_)) => {
                    let a = cl.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|x| x.area).unwrap_or(0.0);
                    let s = if a > 4.0 { a.sqrt() } else { msz };
                    Some((c, s, s, false))
                }
                None => None,
            }
        }).collect()
    }

    fn c_snap_macros(&mut self, a: &[String]) -> R {
        let x = args(a, &["-cells", "-grid", "-origin"]);
        let ps: Vec<String> = x.get("-cells").map(|s| pats(s)).unwrap_or_default();
        let fp = self.fp.clone().ok_or_else(|| Flow::Err("snap_macros_to_grid: no floorplan (FP-001)".into()))?;
        let g = x.get("-grid").map(|s| nums(s)).filter(|v| !v.is_empty()).map(|v| (v[0], *v.get(1).unwrap_or(&v[0]))).unwrap_or((self.site_w(), self.row_h()));
        let org = if x.get("-origin").map(|s| s == "die").unwrap_or(false) { (fp.die.0, fp.die.1) } else { let r = fp.place_region(); (r.0, r.1) };
        let ms = self.macro_cells(&ps);
        if ms.is_empty() {
            return err("snap_macros_to_grid: no macro matches (FP-160)");
        }
        let lef = self.lef.clone();
        let nl = self.nl.as_mut().unwrap();
        let (mut n, mut maxd) = (0, 0.0f64);
        let mut boxes = vec![];
        for (c, w, h, lefp) in &ms {
            let Some(l) = nl.cell(*c).loc else { continue };
            // lower-left of the footprint
            let ll = if *lefp { l } else { (l.0 - w / 2.0, l.1 - h / 2.0) };
            let s = (org.0 + ((ll.0 - org.0) / g.0).round() * g.0, org.1 + ((ll.1 - org.1) / g.1).round() * g.1);
            let d = (s.0 - ll.0).abs() + (s.1 - ll.1).abs();
            nl.cell_mut(*c).loc = Some(if *lefp { s } else { (s.0 + w / 2.0, s.1 + h / 2.0) });
            if d > 1e-9 { n += 1; maxd = maxd.max(d); }
            let r = crate::lef::cell_rect(&lef, nl.cell(*c)).unwrap_or((s.0, s.1, s.0 + w, s.1 + h));
            boxes.push((nl.cell(*c).name.clone(), r));
        }
        let mut ov = 0;
        for i in 0..boxes.len() {
            for j in i + 1..boxes.len() {
                if rect_overlap(&boxes[i].1, &boxes[j].1) {
                    ov += 1;
                    crate::warn!("FP-162", "Macros '{}' and '{}' overlap after snapping", boxes[i].0, boxes[j].0);
                }
            }
        }
        crate::info!("FP-161", "Snapped {} of {} macro(s) to the {:.3} x {:.3} um placement grid (max move {:.3} um), {} overlap(s)", n, ms.len(), g.0, g.1, maxd, ov);
        Ok(n.to_string())
    }

    /// flylines touching macros: (from, to) centre points
    fn flylines(&self, ms: &[(CellId, f64, f64, bool)]) -> Vec<((f64, f64), (f64, f64))> {
        let nl = self.nl.as_ref().unwrap();
        let mset: HashMap<CellId, (f64, f64)> = ms.iter().filter_map(|(c, w, h, lp)| {
            let l = nl.cell(*c).loc?;
            Some((*c, if *lp { (l.0 + w / 2.0, l.1 + h / 2.0) } else { l }))
        }).collect();
        let mut out = vec![];
        let mut seen = HashSet::new();
        for (c, ctr) in &mset {
            for p in &nl.cell(*c).pins {
                let Some(n) = p.net else { continue };
                if !seen.insert((n, *c)) { continue; }
                // one flyline per net from the macro to the centroid of the other objects
                let mut s = (0.0, 0.0, 0usize);
                for q in Session::leaf_conns(nl, n) {
                    match q {
                        PinRef::Cell(o, _) if o != *c && !nl.cell(o).is_hport() => {
                            if let Some(m) = mset.get(&o) { s.0 += m.0; s.1 += m.1; s.2 += 1; }
                            else if let Some(l) = nl.cell(o).loc { s.0 += l.0; s.1 += l.1; s.2 += 1; }
                        }
                        PinRef::Port(pt) => if let Some(l) = nl.ports[pt].loc { s.0 += l.0; s.1 += l.1; s.2 += 1; },
                        _ => {}
                    }
                }
                if s.2 > 0 {
                    out.push((*ctr, (s.0 / s.2 as f64, s.1 / s.2 as f64)));
                }
            }
        }
        out
    }

    pub(crate) fn c_report_flylines(&mut self, a: &[String]) -> Result<(usize, f64), Flow> {
        let x = args(a, &["-cells"]);
        let ps: Vec<String> = x.get("-cells").map(|s| pats(s)).unwrap_or_default();
        let ms = self.macro_cells(&ps);
        let fl = self.flylines(&ms);
        let mut cr = 0;
        for i in 0..fl.len() {
            for j in i + 1..fl.len() {
                if seg_cross(fl[i].0, fl[i].1, fl[j].0, fl[j].1) { cr += 1; }
            }
        }
        let wl: f64 = fl.iter().map(|(a, b)| (a.0 - b.0).abs() + (a.1 - b.1).abs()).sum::<f64>() + 0.0;
        crate::info!("FP-170", "Flylines of {} macro(s): {} flyline(s), {} crossing(s), length {:.1} um", ms.len(), fl.len(), cr, wl);
        Ok((cr, wl))
    }

    fn apply_macro_plan(&mut self, plan: &[(CellId, (f64, f64), String, f64, f64)]) {
        let lef = self.lef.clone();
        let nlm = self.nl.as_mut().unwrap();
        for (c, ll, orient, mw, mh) in plan {
            let has_lef = crate::lef::phys(&lef, nlm.cell(*c)).is_some();
            let cl = nlm.cell_mut(*c);
            cl.attrs.retain(|a| !a.starts_with("orient:"));
            cl.attrs.push(format!("orient:{}", orient));
            let (fw, fh) = crate::lef::oriented_size(*mw, *mh, orient);
            cl.loc = Some(if has_lef { *ll } else { (ll.0 + fw / 2.0, ll.1 + fh / 2.0) });
            cl.fixed = true;
        }
    }

    fn c_place_macros(&mut self, a: &[String]) -> R {
        let x = args(a, &["-cells", "-group_by", "-spacing", "-halo", "-channel"]);
        let ps: Vec<String> = x.get("-cells").map(|s| pats(s)).unwrap_or_default();
        let fp = self.fp.clone().ok_or_else(|| Flow::Err("place_macros: no floorplan (FP-001)".into()))?;
        let ms: Vec<(CellId, f64, f64, bool)> = self.macro_cells(&ps).into_iter().filter(|m| !self.nl.as_ref().unwrap().cell(m.0).fixed || x.has("-force")).collect();
        if ms.is_empty() {
            return err("place_macros: no unfixed macro (FP-171)");
        }
        let (cr0, wl0) = self.c_report_flylines(&[])?;
        let spacing = x.num("-spacing").unwrap_or(2.0);
        let halo = x.num("-halo").unwrap_or(0.0);
        let by_module = x.get("-group_by").map(|s| s != "none").unwrap_or(true);
        let core = fp.place_region();
        let ctr = ((core.0 + core.2) / 2.0, (core.1 + core.3) / 2.0);
        let nl = self.nl.as_ref().unwrap();
        // ---- attraction point of every macro: connected ports and placed cells (not macros)
        let mset: HashSet<CellId> = ms.iter().map(|m| m.0).collect();
        let attract = |c: CellId| -> (f64, f64) {
            let mut s = (0.0, 0.0, 0usize);
            for p in &nl.cell(c).pins {
                let Some(n) = p.net else { continue };
                for q in Session::leaf_conns(nl, n) {
                    match q {
                        PinRef::Port(pt) => if let Some(l) = nl.ports[pt].loc { s.0 += l.0; s.1 += l.1; s.2 += 1; },
                        PinRef::Cell(o, _) if !mset.contains(&o) && !nl.cell(o).is_hport() => if let Some(l) = nl.cell(o).loc { s.0 += l.0; s.1 += l.1; s.2 += 1; },
                        _ => {}
                    }
                }
            }
            if s.2 == 0 { ctr } else { (s.0 / s.2 as f64, s.1 / s.2 as f64) }
        };
        // perimeter parameter of the core boundary point nearest the direction of p
        // (counter-clockwise from the lower-left corner)
        let (w, h) = (core.2 - core.0, core.3 - core.1);
        let per = 2.0 * (w + h);
        let param = |p: (f64, f64)| -> f64 {
            let (dx, dy) = (p.0 - ctr.0, p.1 - ctr.1);
            if dx.abs() < 1e-9 && dy.abs() < 1e-9 { return 0.0; }
            // ray from the centre to the boundary
            let tx = if dx.abs() > 1e-12 { (w / 2.0) / dx.abs() } else { f64::MAX };
            let ty = if dy.abs() > 1e-12 { (h / 2.0) / dy.abs() } else { f64::MAX };
            let t = tx.min(ty);
            let (bx, by) = (ctr.0 + dx * t, ctr.1 + dy * t);
            if (by - core.1).abs() < 1e-6 { bx - core.0 }
            else if (bx - core.2).abs() < 1e-6 { w + (by - core.1) }
            else if (by - core.3).abs() < 1e-6 { w + h + (core.2 - bx) }
            else { 2.0 * w + h + (core.3 - by) }
        };
        // ---- clusters
        let mut clusters: Vec<(String, Vec<(CellId, f64, f64, bool, f64)>, f64)> = vec![];
        for (c, mw, mh, lp) in &ms {
            let nm = &nl.cell(*c).name;
            let key = if by_module { nm.rsplit_once('/').map(|x| x.0.to_string()).unwrap_or_else(|| "(top)".into()) } else { nm.clone() };
            let t = param(attract(*c));
            match clusters.iter_mut().find(|k| k.0 == key) {
                Some(k) => k.1.push((*c, *mw, *mh, *lp, t)),
                None => clusters.push((key, vec![(*c, *mw, *mh, *lp, t)], 0.0)),
            }
        }
        for k in clusters.iter_mut() {
            // circular mean of the members' perimeter parameters
            let (sx, sy) = k.1.iter().fold((0.0, 0.0), |a, m| { let th = m.4 / per * std::f64::consts::TAU; (a.0 + th.cos(), a.1 + th.sin()) });
            let th = sy.atan2(sx).rem_euclid(std::f64::consts::TAU);
            k.2 = th / std::f64::consts::TAU * per;
            k.1.sort_by(|a, b| a.4.partial_cmp(&b.4).unwrap());
        }
        clusters.sort_by(|a, b| a.2.partial_cmp(&b.2).unwrap());
        let total: f64 = clusters.iter().flat_map(|k| k.1.iter()).map(|m| m.1 + spacing + 2.0 * halo).sum();
        // ---- walk the perimeter; corners are skipped so a macro never straddles one
        let edge_of = |t: f64| -> (usize, f64) {
            let t = t.rem_euclid(per);
            if t < w { (0, t) } else if t < w + h { (1, t - w) } else if t < 2.0 * w + h { (2, t - w - h) } else { (3, t - 2.0 * w - h) }
        };
        let edge_len = |e: usize| if e % 2 == 0 { w } else { h };
        let mut ring = 0usize;
        let dcorner = ms.iter().map(|m| m.2).fold(0.0f64, f64::max) + 2.0 * halo + spacing;
        let mut cursor = clusters.first().map(|k| (k.2 - k.1.iter().map(|m| m.1 + spacing).sum::<f64>() / 2.0).max(0.0)).unwrap_or(0.0);
        let start = cursor;
        let mut used_len = 0.0;
        let mut plan: Vec<(CellId, (f64, f64), String, f64, f64)> = vec![];
        let mut overflow = 0;
        for k in &clusters {
            let want = k.2 - k.1.iter().map(|m| m.1 + spacing).sum::<f64>() / 2.0;
            // move forward to the cluster's preferred start, never backwards past the cursor
            if want > cursor && want < start + per - (total - used_len) {
                used_len += want - cursor;
                cursor = want;
            }
            for (c, mw, mh, _lp, _) in &k.1 {
                let need = mw + 2.0 * halo;
                let (mut e, mut off) = edge_of(cursor);
                // corners are kept free to the depth of the deepest macro, so macros on two
                // adjacent edges never meet in a corner
                if off < dcorner - 1e-9 {
                    let k = dcorner - off;
                    cursor += k; used_len += k; off = dcorner;
                }
                if off + need > edge_len(e) - dcorner + 1e-9 {
                    // jump to the next edge, past its corner zone
                    let skip = edge_len(e) - off + dcorner;
                    cursor += skip;
                    used_len += skip;
                    let n = edge_of(cursor);
                    e = n.0; off = n.1;
                }
                if used_len + need > per + 1e-6 || ring > 0 {
                    overflow += 1;
                }
                let depth = mh + halo;
                // orientation: the macro's north (pin) edge faces the core centre
                let (orient, ll) = match e {
                    0 => ("N", (core.0 + off + halo, core.1 + halo)),
                    1 => ("W", (core.2 - depth, core.1 + off + halo)),
                    2 => ("S", (core.2 - off - halo - mw, core.3 - depth)),
                    _ => ("E", (core.0 + halo, core.3 - off - halo - mw)),
                };
                let _ = depth;
                plan.push((*c, ll, orient.into(), *mw, *mh));
                cursor += need + spacing;
                used_len += need + spacing;
            }
            let _ = &mut ring;
        }
        if overflow > 0 {
            return err(&format!("place_macros: {} macro(s) do not fit along the core boundary (total {:.1} of {:.1} um); enlarge the core or reduce -spacing/-halo (FP-172)", overflow, total, per));
        }
        let was_placed = ms.iter().all(|m| self.nl.as_ref().unwrap().cell(m.0).loc.is_some());
        self.apply_macro_plan(&plan);
        // ---- flyline untangling: swap equal-footprint macros while crossings (then length) drop
        let quiet = |s: &Session, ms: &[(CellId, f64, f64, bool)]| -> (usize, f64) {
            let fl = s.flylines(ms);
            let mut cr = 0;
            for i in 0..fl.len() { for j in i + 1..fl.len() { if seg_cross(fl[i].0, fl[i].1, fl[j].0, fl[j].1) { cr += 1; } } }
            (cr, fl.iter().map(|(a, b)| (a.0 - b.0).abs() + (a.1 - b.1).abs()).sum::<f64>() + 0.0)
        };
        let (cr_init, _) = quiet(self, &ms);
        let mut best = quiet(self, &ms);
        let mut swaps = 0;
        for _pass in 0..4 {
            let mut improved = false;
            for i in 0..plan.len() {
                for j in i + 1..plan.len() {
                    if (plan[i].3 - plan[j].3).abs() > 1e-6 || (plan[i].4 - plan[j].4).abs() > 1e-6 { continue; }
                    let (li, oi) = (plan[i].1, plan[i].2.clone());
                    plan[i].1 = plan[j].1; plan[i].2 = plan[j].2.clone();
                    plan[j].1 = li; plan[j].2 = oi;
                    self.apply_macro_plan(&plan);
                    let q = quiet(self, &ms);
                    if q.0 < best.0 || (q.0 == best.0 && q.1 < best.1 - 1e-6) {
                        best = q; swaps += 1; improved = true;
                    } else {
                        let (li, oi) = (plan[i].1, plan[i].2.clone());
                        plan[i].1 = plan[j].1; plan[i].2 = plan[j].2.clone();
                        plan[j].1 = li; plan[j].2 = oi;
                    }
                }
            }
            if !improved { break; }
        }
        self.apply_macro_plan(&plan);
        let nlm = self.nl.as_mut().unwrap();
        if halo > 0.0 {
            let fpm = self.fp.as_mut().unwrap();
            for (c, ll, orient, mw, mh) in &plan {
                let (fw, fh) = crate::lef::oriented_size(*mw, *mh, orient);
                let n = format!("halo_{}", nlm.cell(*c).name.replace('/', "_"));
                fpm.pblk.retain(|b| b.name != n);
                fpm.pblk.push(crate::fplan::PBlockage { name: n, rect: (ll.0 - halo, ll.1 - halo, ll.0 + fw + halo, ll.1 + fh + halo), kind: crate::fplan::PbKind::Hard, source: "macro_halo".into() });
            }
        }
        let (cr1, wl1) = self.c_report_flylines(&[])?;
        crate::info!("FP-173", "Placed {} macro(s) in {} group(s) along the core boundary (pins facing the core); {} untangling swap(s), flyline crossings {} -> {}{}, flyline length {:.1} um",
            plan.len(), clusters.len(), swaps, cr_init, cr1, if was_placed { format!(" (before placement: {} crossing(s), {:.1} um)", cr0, wl0) } else { String::new() }, wl1);
        Ok(format!("{} {}", plan.len(), cr1))
    }
}
