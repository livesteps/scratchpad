# ---------------------------------------------------------------------------
# Floorplan / IO planning / place_opt flow (all commands honored after read_def)
# ---------------------------------------------------------------------------
create_mode func ; create_corner ss ; create_corner ff
read_lib -corner ss lib/rs28_ss_0p72v_125c.lib
read_lib -corner ff lib/rs28_ff_0p88v_m40c.lib
create_scenario -name func_ss -mode func -corner ss
create_scenario -name func_ff -mode func -corner ff
set_scenario_status func_ss -hold false
set_scenario_status func_ff -setup false -hold true
analyze -format sverilog {rtl/soc_pkg.sv rtl/bus_if.sv rtl/lane.sv rtl/arbiter.sv rtl/core.sv rtl/soc_top.sv}
analyze -format vhdl rtl/checksum.vhd
elaborate soc_top
current_mode func ; read_sdc func.sdc
compile_fusion -to logic_opto

# ---- floorplan: DEF provides die, rows, fixed macro, pins, blockages, a fence region/group
read_def floorplan2.def

# ---- floorplan edits (honored by placement, pin placement and global routing)
create_placement_blockage -name halo_left  -boundary {{25 0} {35 30}} -type soft
create_placement_blockage -name keepout    -boundary {{55 70} {70 85}} -type hard
create_routing_blockage   -name rb_m3m4    -boundary {{40 20} {48 60}} -layers {M3 M4}
create_route_guide        -name rg_reset   -boundary {{0 45} {120 55}} -nets {rst_n*}
create_route_guide        -name rg_limit   -boundary {{60 0} {80 40}} -track_utilization 50
create_bound -name b_lane0 -type hard      -boundary {{5 55} {40 95}}  {u_core/g_lane[0].u_lane}
create_bound -name b_arb   -type exclusive -boundary {{48 8} {72 34}}  {u_core/u_arb}
create_bound -name b_lane23 -type soft     -dimensions {40 36}         {u_core/g_lane[2].u_lane u_core/g_lane[3].u_lane}

# ---- IO pin planning
set_block_pin_constraints -allowed_layers {M3 M4 M5 M6} -sides {1 2 3 4} -pin_spacing 0.8 -corner_keepout_distance 3
create_bundle -name din01 [get_ports {din0* din1*}]
set_bundle_pin_constraints -bundles din01 -sides left -offset 10
create_bundle -name din23 -order interleave [get_ports {din2* din3*}]
set_bundle_pin_constraints -bundles din23 -sides bottom
create_bundle -name dout_bus [get_ports {dout* dout_vld dout_id*}]
set_bundle_pin_constraints -bundles dout_bus -sides right -offset 15
set_individual_pin_constraints -ports {iso_en save restore scan_en} -sides top
set_individual_pin_constraints -ports dbg_sel -location {0 80}
place_pins
check_pin_placement
report_floorplan

