# IO pin placement with layer assignment, check_pin_assignment, write_def sections
source fp_flow_setup.tcl
puts "=== IO"
check_pin_assignment
set_block_pin_constraints -layer_assignment balanced -pin_spacing 0.4
place_pins -replace_fixed
puts "=== IO BALANCED"
check_pin_assignment
report_pin_placement
# deliberate problems: a pin on a routing blockage + off-track location + vertical layer on left side
create_routing_blockage -name rb_pin -boundary {{0 78} {3 82}} -layers {M3 M5}
set_individual_pin_constraints -ports dbg_sel -location {0 80.13} -allowed_layers M4
place_pins
puts "=== IO VIOL"
check_pin_assignment -verbose
file mkdir out
write_def -floorplan out/batch_fp.def
write_def -sections {netlist} out/batch_netlist.def
write_def -sections {pins tracks blockages} out/batch_pins.def
write_def -exclude {nets routing} out/batch_noNets.def
write_def -scanchain -sections {components} out/batch_scan.def
catch {write_def -sections {bogus} out/batch_x.def} m ; puts "BAD $m"
