# ---------------------------------------------------------------------------
# Path-based timing ECO driven by timing path collections (PrimeTime / FC style)
#   1. collect violating paths  (report_timing -collection / get_timing_paths)
#   2. walk paths and points with get_attribute, decide the fix in Tcl
#   3. apply ECO commands (eco_sizecell, size_cell, insert_buffer, ...)
#   4. write the replayable ECO script (write_eco_changes)
# Replay on the original netlist: timing_eco_replay.tcl
# (runs on the logic_opto netlist of the floorplan setup, where sizing headroom remains)
# ---------------------------------------------------------------------------
source fp_flow_setup.tcl
reset_eco_changes
report_qor -summary

# ---- setup: upsize the slowest not-yet-touched cell on each violating path --------
proc slowest_cell {path touched} {
    set best "" ; set bd -1
    foreach_in_collection pt [get_attribute $path points] {
        # output pins carry the cell-arc delay (they have a load capacitance)
        if {[get_attribute $pt capacitance] eq ""} continue
        set c [get_attribute $pt cell]
        if {$c eq "" || [get_attribute $c is_sequential] eq "true"} continue
        set n [get_object_name $c]
        if {[lsearch -exact $touched $n] >= 0} continue
        set d [get_attribute $pt incr]
        if {$d > $bd} { set bd $d ; set best $n }
    }
    return $best
}

set touched {}
for {set pass 1} {$pass <= 4} {incr pass} {
    set viol [report_timing -collection -setup -scenarios func_ss -group clk \
                 -max_paths 40 -nworst 1 -slack_lesser_than 0]
    if {[sizeof_collection $viol] == 0} break
    puts "ECO pass $pass: [sizeof_collection $viol] violating clk paths, worst [get_attribute [index_collection $viol 0] slack]"
    foreach_in_collection p $viol {
        set c [slowest_cell $p $touched]
        if {$c eq ""} continue
        # faster Vt first (no extra input load), stronger drive only when already LVT
        set ref [get_attribute [get_cells $c] ref_name]
        set lvt [string map {_HVT _SVT _SVT _LVT} $ref]
        if {$lvt ne $ref} {
            size_cell $c $lvt
        } else {
            catch {eco_sizecell -inst $c -autoup}
        }
        lappend touched $c
    }
}

# ---- paths through a specific stage, launched by clk and captured by clk ----------
set thr [report_timing -collection -setup -scenarios func_ss -clock_from clk -clock_to clk \
            -through [get_pins -hier u_core/g_lane*/U*/Y] -max_paths 5 -nworst 2]
foreach_in_collection p $thr {
    puts [format "  %-42s -> %-42s %8.4f  levels %s" [get_object_name [get_attribute $p startpoint]] \
          [get_object_name [get_attribute $p endpoint]] [get_attribute $p slack] [get_attribute $p num_logic_levels]]
}

# ---- hold margin: pad endpoints whose hold slack is under 0.1ns, but only where the
#      setup side of the same endpoint can absorb a delay cell ----------------------
set hw [get_timing_paths -hold -scenarios func_ff]
puts "worst hold path: [get_attribute $hw slack] at [get_object_name [get_attribute $hw endpoint]]"
set hold [get_timing_paths -hold -scenarios func_ff -max_paths 4 -slack_lesser_than 0.1]
foreach_in_collection p $hold {
    set ep [get_attribute $p endpoint]
    set s  [get_timing_paths -setup -scenarios func_ss -to $ep]
    if {[sizeof_collection $s] && [get_attribute $s slack] < 0.3} {
        puts "  skip [get_object_name $ep]: setup slack [get_attribute $s slack]"
        continue
    }
    puts "  hold pad at [get_object_name $ep] (hold slack [get_attribute $p slack])"
    insert_buffer $ep DLY4_X1_SVT
}

# ---- let the tool finish the rest; its changes are recorded as an exact diff ------
fix_eco_timing -type setup -max_iterations 2

report_qor -summary
report_eco_changes
file mkdir out
write_eco_changes out/timing_eco.tcl
verify_equivalence -cycles 2000 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1}
