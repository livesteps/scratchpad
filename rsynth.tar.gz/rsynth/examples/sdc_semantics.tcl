# SDC/object-constraint semantics regression: set_dont_use, set_dont_touch (hierarchical), set_size_only, set_sense, unsupported SDC
# ---------------------------------------------------------------------------
# RSynth reference flow: MMMC + UPF + DEF-driven physical synthesis + DFT
# ---------------------------------------------------------------------------
set_app_options -name hdlin.elaborate.empty_module_as_blackbox -value true
set_app_options -name compile.clockgate.enable -value true
set_app_options -name opt.tie_cell.max_fanout -value 6
set_app_options -name opt.hfn.threshold -value 24

# ---- MMMC setup ----------------------------------------------------------
create_mode func
create_mode test
foreach c {ss tt ff} { create_corner $c }
read_lib -corner ss lib/rs28_ss_0p72v_125c.lib
read_lib -corner tt lib/rs28_tt_0p80v_25c.lib
read_lib -corner ff lib/rs28_ff_0p88v_m40c.lib
set_timing_derate -late  1.05 -corners ss
set_timing_derate -early 0.95 -corners ff
set_parasitic_parameters -corner ss -r_scale 1.10 -c_scale 1.05
set_parasitic_parameters -corner ff -r_scale 0.90 -c_scale 0.95
create_scenario -name func_ss -mode func -corner ss
create_scenario -name func_ff -mode func -corner ff
create_scenario -name func_tt -mode func -corner tt
create_scenario -name test_ss -mode test -corner ss
set_scenario_status func_ss -setup true  -hold false -leakage_power false
set_scenario_status func_ff -setup false -hold true  -leakage_power false -dynamic_power false
set_scenario_status func_tt -setup false -hold false -leakage_power true  -dynamic_power true
set_scenario_status test_ss -setup true  -hold true
set_dont_use [get_lib_cells */*X8_HVT]

# ---- design input --------------------------------------------------------
analyze -format sverilog {rtl/soc_pkg.sv rtl/bus_if.sv rtl/lane.sv rtl/arbiter.sv rtl/core.sv rtl/soc_top.sv}
analyze -format vhdl rtl/checksum.vhd
elaborate soc_top
link_block
check_design

# ---- constraints, floorplan, power intent --------------------------------
current_mode func ; read_sdc func.sdc
current_mode test ; read_sdc test.sdc
read_def floorplan.def
load_upf power.upf
report_power_domains
check_timing -scenarios func_ss

# ---- synthesis -------------------------------------------------------------
set_dont_use [get_lib_cells {*/ICG_X1_SVT */DLY4_X1_SVT */ISO_AND_X1_SVT */SDFFR_X1_SVT */NAND2_X1_SVT}]
puts "DT=[set_dont_touch [get_cells u_core/u_csum]]"
compile_fusion -to initial_map
proc snap {pat} { set r {} ; foreach c [get_cells -hier $pat] { lappend r "[get_attribute $c full_name]:[get_attribute $c ref_name]" } ; return [lsort $r] }
set before [snap u_core/u_csum/*]
set so [lindex [get_cells -hier u_core/g_lane\[2\].u_lane/*] 5] ; set so_n [get_attribute $so full_name] ; set_size_only $so ; puts "SO $so_n [get_attribute $so ref_name]"
compile_fusion -from logic_opto -to initial_opto

# ---- DFT ------------------------------------------------------------------
set_dft_signal -view existing_dft -type ScanEnable -port scan_en -active_state 1
set_scan_configuration -chain_count 4 -clock_mixing no_mix
create_test_protocol
dft_drc
insert_dft
compile_fusion -from final_place -to final_opto

# ---- signoff-style reports -------------------------------------------------
check_mv_design
report_qor
report_timing -scenarios func_ss -max_paths 1 -transition_time -capacitance
report_timing -delay_type min -scenarios func_ff -max_paths 1
report_constraints -all_violators
report_area -hierarchy
report_power -verbose
report_threshold_voltage_group
report_clock_gating
report_scan_chains

# ---- outputs ----------------------------------------------------------------
file mkdir out/sdc
write_verilog out/sdc/soc_top.mapped.v
set after [snap u_core/u_csum/*] ; foreach x $after { if {[lsearch -exact $before $x] < 0} { puts "ADDED $x" } } ; foreach x $before { if {[lsearch -exact $after $x] < 0} { puts "GONE $x" } } ; puts "DT_PRESERVED [expr {$before eq $after}] ([llength $before] cells)"
puts "SO_AFTER $so_n [get_attribute [get_cells $so_n] ref_name]"
foreach c {ICG_X1_SVT DLY4_X1_SVT ISO_AND_X1_SVT SDFFR_X1_SVT NAND2_X1_SVT} { puts "PROBE $c [sizeof_collection [get_cells -hier -filter ref_name==$c]]" }
puts "SENSE [set_sense -type clock -stop_propagation [get_pins u_core/u_arb/*/CK]]"
catch {set_sense -type data -positive [get_pins u_core/u_arb/*/CK]} m
write_parasitics -format SPEF -output out/sdc/soc_top
write_def out/sdc/soc_top.def
write_sdc -mode func out/sdc/func.sdc
save_upf out/sdc/soc_top.upf
write_scan_def out/sdc/soc_top.scandef

# ---- functional verification of the final netlist vs. elaborated RTL ------
verify_equivalence -cycles 3000 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1 test_si0 0 test_si1 0 test_si2 0 test_si3 0}
set_max_time_borrow 0.1 [get_clocks *]
report_constraints -max_delay
