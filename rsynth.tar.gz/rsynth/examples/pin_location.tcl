# Pin location / layer: after routing, every pin location must be a wired point of its net on that layer
source fp_flow_setup.tcl
place_opt
legalize_placement
route_auto
file mkdir out
write_def out/pin_location.def
puts "=== PIN LOCATIONS"
set k 0
foreach_in_collection n [get_nets -hier *] {
  set pins [get_property $n leafpins]
  set ports [get_property $n leaf_ports]
  if {[llength $pins] < 2} continue
  foreach p [concat $pins $ports] {
    puts "PIN [lindex [get_object_name $n] 0] [lindex [get_object_name $p] 0] [get_property $p location] [get_property $p layer]"
  }
  incr k
  if {$k >= 150} break
}
set pt [index_collection [all_inputs] 1]
puts "PORT [get_object_name $pt] loc [get_property $pt location] layer [get_property $pt layer] x [get_property $pt x_coordinate]"
set q [index_collection [get_pins -hier */Q] 0]
puts "Q [get_object_name $q] loc [get_property $q location] layer [get_property $q layer] cell_loc [get_attribute [get_cells -of_objects $q] location] db [dbGet [dbGetInstTermByName [get_object_name $q]].pt] [dbGet [dbGetInstTermByName [get_object_name $q]].layer]"
