# Scan/test mode
create_clock -name tclk -period 4.0 [get_ports clk]
set_clock_uncertainty 0.1 [get_clocks tclk]
set_case_analysis 1 [get_ports scan_en]
set_input_delay 1.0 -clock tclk [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay 1.0 -clock tclk [all_outputs]
set_max_transition 0.45 [current_design]
