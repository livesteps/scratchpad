#!/usr/bin/env python3
"""Generate a fictional multi-corner, multi-Vt Liberty library family ("rs28")
for exercising RSynth: NLDM tables (+ CCS / ECSM / CCSN groups on some arcs for
parser coverage), flops, scan flops, latch, ICG, tie, iso, level shifter,
retention flop, always-on buffer, delay cell, wire-load model."""
import sys, os

CORNERS = {  # name: (delay scale, voltage, temp, process, leakage scale)
    "ss_0p72v_125c": (1.38, 0.72, 125, 1.2, 2.5),
    "tt_0p80v_25c": (1.00, 0.80, 25, 1.0, 1.0),
    "ff_0p88v_m40c": (0.74, 0.88, -40, 0.8, 0.35),
}
VTS = {"HVT": (1.22, 0.25, 1.0), "SVT": (1.0, 1.0, 1.0), "LVT": (0.84, 3.8, 1.0)}  # delay, leakage, area
TR = [0.01, 0.08, 0.30, 0.60]
CAP = [0.0005, 0.004, 0.016, 0.060]

def tbl(name, f, tmpl="delay_t4"):
    rows = []
    for t in TR:
        rows.append('"' + ", ".join("%.5f" % f(t, c) for c in CAP) + '"')
    return "        %s(%s) {\n          values(%s);\n        }\n" % (name, tmpl, ", \\\n                 ".join(rows))

def ctbl(name, v):
    return "        %s(constr_t2) {\n          values(\"%.4f, %.4f\", \"%.4f, %.4f\");\n        }\n" % (name, v, v * 1.1, v * 1.15, v * 1.25)

def arc(rel, sense, intr, drive, ds, ttype=None, extra=""):
    k = 0.9 / drive
    s = "      timing() {\n        related_pin : \"%s\";\n        timing_sense : %s;\n" % (rel, sense)
    if ttype:
        s += "        timing_type : %s;\n" % ttype
    s += tbl("cell_rise", lambda t, c: ds * (intr + k * c * 9.0 + 0.22 * t))
    s += tbl("cell_fall", lambda t, c: ds * (intr * 0.9 + k * c * 8.0 + 0.20 * t))
    s += tbl("rise_transition", lambda t, c: ds * (0.012 + k * c * 14.0 + 0.10 * t))
    s += tbl("fall_transition", lambda t, c: ds * (0.010 + k * c * 12.0 + 0.09 * t))
    s += extra
    s += "      }\n"
    return s

def power(drive, vs):
    e = 0.0009 * drive * vs
    return ("      internal_power() {\n" + tbl("rise_power", lambda t, c: e * (1 + t + 5 * c), "power_t4") +
            tbl("fall_power", lambda t, c: e * 0.9 * (1 + t + 5 * c), "power_t4") + "      }\n")

CCS = "        output_current_rise() {\n          vector(ccs_t) { reference_time : 0.01; index_1(\"0.01\"); index_2(\"0.001\"); index_3(\"0.01, 0.02\"); values(\"0.1, 0.05\"); }\n        }\n"
ECSM = "        ecsm_waveform_set(ecsm_t) {\n          ecsm_waveform() { index_1(\"0.01\"); values(\"0.1, 0.2\"); }\n        }\n"

def pin_in(n, cap, extra=""):
    return "    pin(%s) {\n      direction : input;\n      capacitance : %.5f;\n%s    }\n" % (n, cap, extra)

def comb(name, ins, func, sense, drive, area, leak, ds, vs, intr=0.025, pin_skew=None, ccs=False, extra_cell=""):
    s = "  cell(%s) {\n    area : %.4f;\n    cell_leakage_power : %.4f;\n%s" % (name, area, leak, extra_cell)
    for i, p in enumerate(ins):
        rx = ""
        if ccs and i == 0:
            rx = "      receiver_capacitance() { receiver_capacitance1_rise(rc_t) { values(\"%.5f\"); } }\n      ccsn_first_stage() { is_needed : true; }\n" % (0.0011 * drive)
        s += pin_in(p, 0.0010 * drive * (1.0 + 0.05 * i), rx)
    s += "    pin(Y) {\n      direction : output;\n      function : \"%s\";\n      max_capacitance : %.4f;\n      max_transition : 0.45;\n" % (func, 0.035 * drive)
    for i, p in enumerate(ins):
        skew = 1.0 + (pin_skew or 0.0) * i
        sen = sense if not isinstance(sense, dict) else sense[p]
        s += arc(p, sen, intr * skew, drive, ds, extra=(CCS if ccs and i == 0 else "") + (ECSM if ccs and i == 1 else ""))
    s += power(drive, vs)
    s += "    }\n  }\n"
    return s

def ff(name, drive, area, leak, ds, vs, clear=False, preset=False, scan=False, ret=False):
    nxt = "(D&!SE)|(SI&SE)" if scan else "D"
    s = "  cell(%s) {\n    area : %.4f;\n    cell_leakage_power : %.4f;\n" % (name, area, leak)
    if ret:
        s += "    retention_cell : \"rff\";\n"
    s += "    ff(IQ, IQN) {\n      next_state : \"%s\";\n      clocked_on : \"CK\";\n" % nxt
    if clear: s += "      clear : \"!RN\";\n"
    if preset: s += "      preset : \"!SN\";\n"
    s += "    }\n"
    if scan:
        s += "    test_cell() {\n      pin(D) { direction : input; }\n      pin(SI) { direction : input; signal_type : test_scan_in; }\n      pin(SE) { direction : input; signal_type : test_scan_enable; }\n      pin(CK) { direction : input; }\n      ff(IQ,IQN) { next_state : \"D\"; clocked_on : \"CK\"; }\n      pin(Q) { direction : output; function : \"IQ\"; signal_type : test_scan_out; }\n    }\n"
    dpins = ["D"] + (["SI", "SE"] if scan else [])
    for p in dpins:
        nt = {"SI": "      nextstate_type : scan_in;\n", "SE": "      nextstate_type : scan_enable;\n"}.get(p, "      nextstate_type : data;\n")
        s += "    pin(%s) {\n      direction : input;\n      capacitance : %.5f;\n%s" % (p, 0.0011, nt)
        s += "      timing() { related_pin : \"CK\"; timing_type : setup_rising;\n" + ctbl("rise_constraint", 0.035 * ds) + ctbl("fall_constraint", 0.045 * ds) + "      }\n"
        s += "      timing() { related_pin : \"CK\"; timing_type : hold_rising;\n" + ctbl("rise_constraint", 0.012 * ds) + ctbl("fall_constraint", 0.010 * ds) + "      }\n"
        s += "    }\n"
    s += "    pin(CK) {\n      direction : input;\n      clock : true;\n      capacitance : 0.0012;\n      min_pulse_width_high : %.4f;\n      min_pulse_width_low : %.4f;\n      min_period : %.4f;\n    }\n" % (0.05 * ds, 0.05 * ds, 0.14 * ds)
    for p, kind in (("RN", clear), ("SN", preset)):
        if kind:
            s += "    pin(%s) {\n      direction : input;\n      capacitance : 0.0011;\n" % p
            s += "      timing() { related_pin : \"CK\"; timing_type : recovery_rising;\n" + ctbl("rise_constraint", 0.05 * ds) + "      }\n"
            s += "      timing() { related_pin : \"CK\"; timing_type : removal_rising;\n" + ctbl("rise_constraint", 0.02 * ds) + "      }\n"
            s += "    }\n"
    if ret:
        s += "    pin(SAVE) {\n      direction : input;\n      capacitance : 0.0009;\n      retention_pin (save, \"1\");\n    }\n"
        s += "    pin(RESTORE) {\n      direction : input;\n      capacitance : 0.0009;\n      retention_pin (restore, \"1\");\n    }\n"
    for q, f in (("Q", "IQ"), ("QN", "IQN")):
        s += "    pin(%s) {\n      direction : output;\n      function : \"%s\";\n      max_capacitance : %.4f;\n      max_transition : 0.45;\n" % (q, f, 0.035 * drive)
        s += arc("CK", "non_unate", 0.07, drive, ds, "rising_edge")
        if clear:
            s += arc("RN", "positive_unate" if q == "QN" else "negative_unate", 0.05, drive, ds, "clear")
        if preset:
            s += arc("SN", "negative_unate" if q == "QN" else "positive_unate", 0.05, drive, ds, "preset")
        s += power(drive, vs)
        s += "    }\n"
    s += "  }\n"
    return s

def lib(corner):
    ds0, v, temp, proc, ls = CORNERS[corner]
    o = []
    o.append('/* rs28 fictional demo library — generated by gen_lib.py — corner %s */\n' % corner)
    o.append('library(rs28_%s) {\n  delay_model : table_lookup;\n  time_unit : "1ns";\n  voltage_unit : "1V";\n  current_unit : "1mA";\n  leakage_power_unit : "1nW";\n  capacitive_load_unit(1, pf);\n  pulling_resistance_unit : "1kohm";\n' % corner)
    o.append('  nom_process : %.2f;\n  nom_voltage : %.2f;\n  nom_temperature : %d;\n  default_max_transition : 0.50;\n  default_max_fanout : 24;\n  default_fanout_load : 1.0;\n  default_wire_load : "wl_small";\n' % (proc, v, temp))
    o.append('  operating_conditions(%s) { process : %.2f; voltage : %.2f; temperature : %d; }\n  default_operating_conditions : %s;\n' % (corner, proc, v, temp, corner))
    o.append('  lu_table_template(delay_t4) {\n    variable_1 : input_net_transition;\n    variable_2 : total_output_net_capacitance;\n    index_1("%s");\n    index_2("%s");\n  }\n' % (", ".join(map(str, TR)), ", ".join(map(str, CAP))))
    o.append('  power_lut_template(power_t4) {\n    variable_1 : input_transition_time;\n    variable_2 : total_output_net_capacitance;\n    index_1("%s");\n    index_2("%s");\n  }\n' % (", ".join(map(str, TR)), ", ".join(map(str, CAP))))
    o.append('  lu_table_template(constr_t2) {\n    variable_1 : related_pin_transition;\n    variable_2 : constrained_pin_transition;\n    index_1("0.02, 0.4");\n    index_2("0.02, 0.4");\n  }\n')
    o.append('  output_current_template(ccs_t) { variable_1 : input_net_transition; variable_2 : total_output_net_capacitance; variable_3 : time; }\n')
    o.append('  wire_load("wl_small") {\n    resistance : 0.0025;\n    capacitance : 0.00018;\n    area : 0.0;\n    slope : 6.0;\n    fanout_length(1, 4.0);\n    fanout_length(2, 9.0);\n    fanout_length(4, 18.0);\n    fanout_length(8, 40.0);\n  }\n')
    for vt, (dv, lv, av) in VTS.items():
        ds = ds0 * dv
        L = lambda base: base * lv * ls
        sfx = "_" + vt
        for d in (1, 2, 4, 8):
            o.append(comb("INV_X%d%s" % (d, sfx), ["A"], "!A", "negative_unate", d, 0.4 + 0.25 * d, L(1.2 * d), ds, v, 0.018, ccs=(d == 1 and vt == "SVT"), extra_cell='    threshold_voltage_group : "%s";\n    cell_footprint : "inv";\n' % vt))
            o.append(comb("BUF_X%d%s" % (d, sfx), ["A"], "A", "positive_unate", d, 0.6 + 0.3 * d, L(1.6 * d), ds, v, 0.035, extra_cell='    threshold_voltage_group : "%s";\n' % vt))
        for d in (1, 2, 4):
            o.append(comb("NAND2_X%d%s" % (d, sfx), ["A1", "A2"], "!(A1&A2)", "negative_unate", d, 0.6 + 0.3 * d, L(1.8 * d), ds, v, 0.024, pin_skew=0.18, ccs=(d == 1 and vt == "SVT")))
            o.append(comb("NOR2_X%d%s" % (d, sfx), ["A1", "A2"], "!(A1|A2)", "negative_unate", d, 0.6 + 0.3 * d, L(1.9 * d), ds, v, 0.030, pin_skew=0.18))
        for d in (1, 2):
            o.append(comb("AND2_X%d%s" % (d, sfx), ["A1", "A2"], "A1&A2", "positive_unate", d, 0.9 + 0.3 * d, L(2.2 * d), ds, v, 0.042, pin_skew=0.12))
            o.append(comb("OR2_X%d%s" % (d, sfx), ["A1", "A2"], "A1|A2", "positive_unate", d, 0.9 + 0.3 * d, L(2.3 * d), ds, v, 0.046, pin_skew=0.12))
            o.append(comb("XOR2_X%d%s" % (d, sfx), ["A1", "A2"], "A1^A2", "non_unate", d, 1.4 + 0.4 * d, L(3.0 * d), ds, v, 0.055))
            o.append(comb("XNOR2_X%d%s" % (d, sfx), ["A1", "A2"], "!(A1^A2)", "non_unate", d, 1.4 + 0.4 * d, L(3.0 * d), ds, v, 0.055))
            o.append(comb("MUX2_X%d%s" % (d, sfx), ["A", "B", "S"], "(A&!S)|(B&S)", {"A": "positive_unate", "B": "positive_unate", "S": "non_unate"}, d, 1.6 + 0.4 * d, L(3.2 * d), ds, v, 0.060))
            o.append(comb("AOI21_X%d%s" % (d, sfx), ["A1", "A2", "B"], "!((A1&A2)|B)", "negative_unate", d, 0.9 + 0.3 * d, L(2.4 * d), ds, v, 0.034, pin_skew=0.1))
            o.append(comb("OAI21_X%d%s" % (d, sfx), ["A1", "A2", "B"], "!((A1|A2)&B)", "negative_unate", d, 0.9 + 0.3 * d, L(2.4 * d), ds, v, 0.034, pin_skew=0.1))
            o.append(comb("NAND3_X%d%s" % (d, sfx), ["A1", "A2", "A3"], "!(A1&A2&A3)", "negative_unate", d, 0.9 + 0.35 * d, L(2.4 * d), ds, v, 0.036, pin_skew=0.12))
            o.append(comb("NOR3_X%d%s" % (d, sfx), ["A1", "A2", "A3"], "!(A1|A2|A3)", "negative_unate", d, 0.9 + 0.35 * d, L(2.5 * d), ds, v, 0.044, pin_skew=0.12))
            o.append(comb("AOI22_X%d%s" % (d, sfx), ["A1", "A2", "B1", "B2"], "!((A1&A2)|(B1&B2))", "negative_unate", d, 1.1 + 0.4 * d, L(2.9 * d), ds, v, 0.040, pin_skew=0.08))
        for d in (1, 2):
            o.append(ff("DFF_X%d%s" % (d, sfx), d, 4.0 + 0.6 * d, L(6.0 * d), ds, v))
            o.append(ff("DFFR_X%d%s" % (d, sfx), d, 4.6 + 0.6 * d, L(6.6 * d), ds, v, clear=True))
            o.append(ff("DFFS_X%d%s" % (d, sfx), d, 4.6 + 0.6 * d, L(6.6 * d), ds, v, preset=True))
            o.append(ff("SDFF_X%d%s" % (d, sfx), d, 5.2 + 0.6 * d, L(7.2 * d), ds, v, scan=True))
            o.append(ff("SDFFR_X%d%s" % (d, sfx), d, 5.8 + 0.6 * d, L(7.8 * d), ds, v, clear=True, scan=True))
            o.append(ff("SDFFS_X%d%s" % (d, sfx), d, 5.8 + 0.6 * d, L(7.8 * d), ds, v, preset=True, scan=True))
        ds = ds0
    # single-Vt special cells (SVT)
    ds = ds0
    L = lambda base: base * ls
    o.append(ff("RDFFR_X1_SVT", 1, 7.4, L(9.0), ds, v, clear=True, ret=True))
    o.append('  cell(DLH_X1_SVT) {\n    area : 3.2;\n    cell_leakage_power : %.4f;\n    latch(IQ, IQN) {\n      enable : "G";\n      data_in : "D";\n    }\n' % L(4.5))
    o.append(pin_in("D", 0.0010, "      timing() { related_pin : \"G\"; timing_type : setup_falling;\n" + ctbl("rise_constraint", 0.03 * ds) + ctbl("fall_constraint", 0.03 * ds) + "      }\n      timing() { related_pin : \"G\"; timing_type : hold_falling;\n" + ctbl("rise_constraint", 0.01 * ds) + ctbl("fall_constraint", 0.01 * ds) + "      }\n"))
    o.append("    pin(G) {\n      direction : input;\n      clock : true;\n      capacitance : 0.0011;\n    }\n")
    o.append("    pin(Q) {\n      direction : output;\n      function : \"IQ\";\n      max_capacitance : 0.035;\n" + arc("D", "positive_unate", 0.05, 1, ds) + arc("G", "non_unate", 0.06, 1, ds, "rising_edge") + "    }\n  }\n")
    # ICG
    o.append('  cell(ICG_X1_SVT) {\n    area : 4.4;\n    cell_leakage_power : %.4f;\n    clock_gating_integrated_cell : "latch_posedge_precontrol";\n    statetable("CK E SE", "IQ") { table : "L L L : - : L, L L H : - : H, L H L : - : H, L H H : - : H, H - - : - : N"; }\n' % L(5.0))
    o.append("    pin(CK) {\n      direction : input;\n      clock : true;\n      clock_gate_clock_pin : true;\n      capacitance : 0.0014;\n      min_pulse_width_high : %.4f;\n    }\n" % (0.05 * ds))
    for p, role in (("E", "clock_gate_enable_pin"), ("SE", "clock_gate_test_pin")):
        o.append("    pin(%s) {\n      direction : input;\n      %s : true;\n      capacitance : 0.0010;\n      timing() { related_pin : \"CK\"; timing_type : setup_rising;\n%s      }\n      timing() { related_pin : \"CK\"; timing_type : hold_rising;\n%s      }\n    }\n" % (p, role, ctbl("rise_constraint", 0.04 * ds), ctbl("rise_constraint", 0.01 * ds)))
    o.append("    pin(GCK) {\n      direction : output;\n      clock_gate_out_pin : true;\n      state_function : \"CK & IQ\";\n      max_capacitance : 0.12;\n" + arc("CK", "positive_unate", 0.05, 4, ds) + "    }\n  }\n")
    # tie cells
    for n, f in (("TIEHI_X1_SVT", "1"), ("TIELO_X1_SVT", "0")):
        o.append('  cell(%s) {\n    area : 0.6;\n    cell_leakage_power : %.4f;\n    pin(Y) {\n      direction : output;\n      function : "%s";\n      max_fanout : 8;\n    }\n  }\n' % (n, L(0.5), f))
    # isolation cells
    o.append('  cell(ISO_AND_X1_SVT) {\n    area : 1.2;\n    cell_leakage_power : %.4f;\n    is_isolation_cell : true;\n' % L(2.0) + pin_in("A", 0.001) + '    pin(ISO) {\n      direction : input;\n      capacitance : 0.001;\n      isolation_cell_enable_pin : true;\n    }\n    pin(Y) {\n      direction : output;\n      function : "A&!ISO";\n      max_capacitance : 0.035;\n' + arc("A", "positive_unate", 0.04, 1, ds) + arc("ISO", "negative_unate", 0.04, 1, ds) + "    }\n  }\n")
    o.append('  cell(ISO_OR_X1_SVT) {\n    area : 1.2;\n    cell_leakage_power : %.4f;\n    is_isolation_cell : true;\n' % L(2.0) + pin_in("A", 0.001) + '    pin(ISO) {\n      direction : input;\n      capacitance : 0.001;\n      isolation_cell_enable_pin : true;\n    }\n    pin(Y) {\n      direction : output;\n      function : "A|ISO";\n      max_capacitance : 0.035;\n' + arc("A", "positive_unate", 0.04, 1, ds) + arc("ISO", "positive_unate", 0.04, 1, ds) + "    }\n  }\n")
    # level shifters
    for n, t in (("LS_LH_X1_SVT", "LH"), ("LS_HL_X1_SVT", "HL")):
        o.append('  cell(%s) {\n    area : 2.4;\n    cell_leakage_power : %.4f;\n    is_level_shifter : true;\n    level_shifter_type : %s;\n' % (n, L(3.0), t) + pin_in("A", 0.0012) + '    pin(Y) {\n      direction : output;\n      function : "A";\n      max_capacitance : 0.035;\n' + arc("A", "positive_unate", 0.07, 1, ds) + "    }\n  }\n")
    # always-on buffer, delay cell
    o.append(comb("AONBUF_X2_SVT", ["A"], "A", "positive_unate", 2, 1.6, L(3.0), ds, v, 0.04, extra_cell="    always_on : true;\n"))
    o.append(comb("DLY4_X1_SVT", ["A"], "A", "positive_unate", 1, 1.8, L(1.0), ds, v, 0.16))
    o.append("}\n")
    return "".join(o)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    os.makedirs(out, exist_ok=True)
    for c in CORNERS:
        p = os.path.join(out, "rs28_%s.lib" % c)
        open(p, "w").write(lib(c))
        print("wrote", p)
