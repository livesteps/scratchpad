// scaling test: NL lanes of W-bit MAC + reduction tree
module mac #(parameter W = 16) (input logic clk, rst_n, input logic [W-1:0] a, b, output logic [W-1:0] acc);
  logic [W-1:0] pa, pb;
  logic [W-1:0] prod;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin pa <= '0; pb <= '0; acc <= '0; prod <= '0; end
    else begin pa <= a; pb <= b; prod <= pa * pb; acc <= acc + prod; end
endmodule
module big #(parameter NL = 16, parameter W = 16) (input logic clk, rst_n, input logic [W-1:0] a [NL], b [NL], output logic [W-1:0] sum);
  logic [W-1:0] acc [NL];
  for (genvar i = 0; i < NL; i++) begin : g
    mac #(.W(W)) u (.clk, .rst_n, .a(a[i]), .b(b[i]), .acc(acc[i]));
  end
  always_comb begin
    sum = '0;
    for (int i = 0; i < NL; i++) sum = sum ^ acc[i];
  end
endmodule
