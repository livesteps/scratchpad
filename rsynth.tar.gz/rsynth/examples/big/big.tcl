read_lib lib/rs28_ss_0p72v_125c.lib
analyze -format sverilog big/big.sv
elaborate big -parameters "NL=16,W=16"
create_clock -period 2.5 [get_ports clk]
set_input_delay 0.2 -clock clk [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay 0.2 -clock clk [all_outputs]
compile_fusion
report_qor
verify_equivalence -cycles 300 -resets {rst_n}
