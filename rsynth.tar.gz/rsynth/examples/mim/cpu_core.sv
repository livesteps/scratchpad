// Tiny 8-bit accumulator CPU core: 4-entry register file, 3-stage pipeline
// (fetch/decode register, execute, write-back). Every core of the cluster is the
// same module with the same parameters, so it can be implemented once (MIM).
module cpu_core #(parameter int W = 8) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          stall,
  input  logic [11:0]   instr,      // [11:9] op, [8:7] rd, [6:5] rs, [4:0] imm
  input  logic [W-1:0]  din,
  output logic [W-1:0]  dout,
  output logic          dvalid,
  output logic [3:0]    flags
);
  logic [W-1:0] rf [4];
  logic [11:0]  ir;
  logic [W-1:0] opa, opb, res;
  logic [2:0]   op_x;
  logic [1:0]   rd_x;
  logic         we_x;
  // fetch/decode register
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) ir <= '0;
    else if (!stall) ir <= instr;
  // operand read + execute register
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin
      opa <= '0; opb <= '0; op_x <= '0; rd_x <= '0; we_x <= 1'b0;
    end else if (!stall) begin
      opa  <= rf[ir[6:5]];
      opb  <= (ir[11:9] == 3'd5) ? din : {{(W-5){ir[4]}}, ir[4:0]};
      op_x <= ir[11:9];
      rd_x <= ir[8:7];
      we_x <= ir[11:9] != 3'd7;
    end
  always_comb
    case (op_x)
      3'd0: res = opa + opb;
      3'd1: res = opa - opb;
      3'd2: res = opa & opb;
      3'd3: res = opa | opb;
      3'd4: res = opa ^ opb;
      3'd5: res = opb;
      3'd6: res = {opa[W-2:0], opa[W-1]};
      default: res = opa;
    endcase
  // write-back
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin
      for (int i = 0; i < 4; i++) rf[i] <= '0;
      dout <= '0; dvalid <= 1'b0; flags <= '0;
    end else if (!stall) begin
      if (we_x) rf[rd_x] <= res;
      dout   <= res;
      dvalid <= op_x == 3'd7;
      flags  <= {res == '0, res[W-1], ^res, we_x};
    end
endmodule
