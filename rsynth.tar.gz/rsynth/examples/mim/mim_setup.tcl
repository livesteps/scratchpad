# Quad-core cluster: MMMC set-up, RTL, constraints
create_mode func ; create_corner ss ; create_corner ff
read_lib -corner ss ../lib/rs28_ss_0p72v_125c.lib
read_lib -corner ff ../lib/rs28_ff_0p88v_m40c.lib
create_scenario -name func_ss -mode func -corner ss
create_scenario -name func_ff -mode func -corner ff
set_scenario_status func_ss -hold false
set_scenario_status func_ff -setup false -hold true
analyze -format sverilog {cpu_core.sv mc_top.sv}
elaborate mc_top
current_mode func ; read_sdc mim.sdc
