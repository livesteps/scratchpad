# MIM preconditions are enforced
source mim_setup.tcl
set_boundary_optimization [get_cells {g_cpu[*].u_core}] false
compile_fusion -to logic_opto
initialize_floorplan -boundary {{0 0} {130 120}}
create_bound -name r0 -type exclusive -boundary {{5 4.8} {55 52.8}}   {g_cpu[0].u_core}
create_bound -name r1 -type exclusive -boundary {{75 4.8} {120 52.8}} {g_cpu[1].u_core}
puts "R2 [catch {create_partition -name c -bounds {r0 r1} {g_cpu[0].u_core g_cpu[1].u_core}} m] $m"
puts "R3 [catch {create_partition -name c -orientations {FN N} {g_cpu[0].u_core g_cpu[1].u_core}} m] $m"
puts "R4 [catch {create_partition -name c -bounds {r0} {g_cpu[0].u_core g_cpu[1].u_core}} m] $m"
puts "R6 [catch {create_partition -name c {g_cpu[0].u_core g_cpu[0].u_core/u_x}} m] $m"
