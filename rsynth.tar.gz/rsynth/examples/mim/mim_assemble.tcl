# The assembled design: four instances of the ONE implemented cpu_blk netlist (after block
# place / CTS / route / route_opt) plus the top-level logic, verified against the RTL
source mim_setup.tcl
analyze -format verilog {out/mim_impl/cpu_blk.v out/mim_parts/mc_top.top.v}
elaborate mc_top -keep_reference
report_hierarchy
verify_equivalence -cycles 3000 -resets {rst_n}
