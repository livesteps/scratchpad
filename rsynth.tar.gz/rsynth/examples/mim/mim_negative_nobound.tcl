# MIM needs preserved boundaries: optimized-across instances are refused
source mim_setup.tcl
compile_fusion -to logic_opto
puts "R1 [catch {create_partition -name c [get_cells {g_cpu[*].u_core}]} m] $m"
