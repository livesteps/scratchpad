// Quad-core cluster: four identical cpu_core instances, an instruction broadcast
// with per-core rotation, and a round-robin result arbiter
module mc_top (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        stall,
  input  logic [11:0] instr,
  input  logic [7:0]  din,
  output logic [7:0]  dout,
  output logic        dvalid,
  output logic [1:0]  core_id,
  output logic [15:0] flags
);
  logic [7:0]  c_dout [4];
  logic [3:0]  c_dv;
  logic [11:0] c_instr [4];
  logic [1:0]  rr;
  for (genvar i = 0; i < 4; i++) begin : g_cpu
    // each core sees the instruction with its register fields rotated
    assign c_instr[i] = {instr[11:9], instr[8:7] + 2'(i), instr[6:0]};
    cpu_core #(.W(8)) u_core (.clk, .rst_n, .stall, .instr(c_instr[i]), .din(din ^ 8'(i * 17)),
                              .dout(c_dout[i]), .dvalid(c_dv[i]), .flags(flags[i*4 +: 4]));
  end
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin
      rr <= '0; dout <= '0; dvalid <= 1'b0; core_id <= '0;
    end else begin
      rr      <= rr + 2'd1;
      dout    <= c_dout[rr];
      dvalid  <= c_dv[rr];
      core_id <= rr;
    end
endmodule
