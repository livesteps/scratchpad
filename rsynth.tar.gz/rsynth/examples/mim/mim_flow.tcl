# Multiply instantiated module (MIM) flow on a quad-core cluster:
# one cpu_core block implemented once and reused by four instances (N, FN, FS, S)
source mim_setup.tcl
# every core keeps its module boundary (no cross-boundary optimization), a requirement for MIM
set_boundary_optimization [get_cells {g_cpu[*].u_core}] false
compile_fusion -to logic_opto

# floorplan: four equal regions, row aligned
initialize_floorplan -boundary {{0 0} {130 120}}
create_bound -name r_core0 -type exclusive -boundary {{5 4.8} {55 52.8}}    {g_cpu[0].u_core}
create_bound -name r_core1 -type exclusive -boundary {{75 4.8} {125 52.8}}  {g_cpu[1].u_core}
create_bound -name r_core2 -type exclusive -boundary {{5 67.2} {55 115.2}}  {g_cpu[2].u_core}
create_bound -name r_core3 -type exclusive -boundary {{75 67.2} {125 115.2}} {g_cpu[3].u_core}
place_pins

puts "=== MIM DEFINE"
create_partition -name cpu_blk -bounds {r_core0 r_core1 r_core2 r_core3} -orientations {N FN FS S} [get_cells {g_cpu[*].u_core}]
report_partitions

place_opt
puts "=== MIM BEFORE COMMIT"
report_mim -partition cpu_blk -resets rst_n
puts "=== MIM COMMIT"
commit_mim -partition cpu_blk -resets rst_n
puts "=== MIM AFTER COMMIT"
report_mim -partition cpu_blk -resets rst_n
check_legality
verify_equivalence -cycles 2000 -resets {rst_n}
file mkdir out
write_def out/mim_flat.def

puts "=== MIM ECO"
# an ECO on the master (here: upsizing a buffer) reaches every instance through commit_mim
set b [index_collection [get_cells -filter {ref_name =~ BUF_X1*} {g_cpu[0].u_core/*}] 0]
set rel [string range [lindex [get_object_name $b] 0] [string length {g_cpu[0].u_core/}] end]
size_cell $b BUF_X4_SVT
report_mim -partition cpu_blk -resets rst_n -no_timing
commit_mim -partition cpu_blk -resets rst_n
set n0 "g_cpu\[0\].u_core/$rel"
set n3 "g_cpu\[3\].u_core/$rel"
puts "ECO_REF [get_attribute [get_cells $n3] ref_name] [get_attribute [get_cells $n0] ref_name]"
report_mim -partition cpu_blk -resets rst_n -no_timing
# a functional change in one instance is refused (unless -force restores it from the master)
set g [index_collection [get_cells -filter {ref_name =~ AND2_X1*} {g_cpu[2].u_core/*}] 0]
eco_change_cell -inst [get_object_name $g] -cell OR2_X1_SVT -force
report_mim -partition cpu_blk -resets rst_n -no_timing
puts "REFUSED [catch {commit_mim -partition cpu_blk -resets rst_n} m] $m"
commit_mim -partition cpu_blk -resets rst_n -force
report_mim -partition cpu_blk -resets rst_n -no_timing
verify_equivalence -cycles 2000 -resets {rst_n}

puts "=== MIM BUDGET"
compute_budget_constraints
report_budget -partition cpu_blk
file mkdir out
write_partitions -output out/mim_parts
puts "=== MIM IMPL"
implement_partitions -input_dir out/mim_parts -output_dir out/mim_impl -jobs 2
puts "=== MIM VERIFY"
verify_block_abstracts -tolerance 0.015 -hold_tolerance 0.010

puts "=== MIM GDS"
write_cell_gds -cells {*_SVT *_LVT *_HVT} -output out/mim_impl/stdcells.gds
assemble_hier_gds -output out/mim_impl/mc_top.gds -merge out/mim_impl/stdcells.gds
