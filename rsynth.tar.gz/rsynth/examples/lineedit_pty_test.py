#!/usr/bin/env python3
# Drives the rsynth shell through a pseudo-terminal: Tab completion and Emacs keys.
# usage: lineedit_pty_test.py path/to/rsynth
import os, pty, time, select, re, sys
import tempfile
os.environ['HOME']=tempfile.mkdtemp()
EXE = os.path.abspath(sys.argv[1])
os.chdir(os.path.dirname(os.path.abspath(__file__)))
pid, fd = pty.fork()
if pid == 0:
    os.execv(EXE, ['rsynth'])
def rd(t=0.6):
    out=b''; end=time.time()+t
    while time.time()<end:
        r,_,_=select.select([fd],[],[],0.05)
        if r:
            try: out+=os.read(fd,65536)
            except OSError: break
    return out.decode(errors='replace')
def clean(s): return re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',s).replace('\r','')
def send(b, t=0.5):
    os.write(fd, b); return rd(t)
rd(3.0)
res={}
o=send(b'place_io_pi\t'); res['cmd_tab']='place_io_pins ' in clean(o)
o=send(b'-dir\t'); res['opt_tab']='-direction ' in clean(o)
send(b'\x01'); o=send(b'\x0b'); res['ctrlK']=clean(o).rstrip().endswith('rsynth>')
send(b'garbage'); o=send(b'\x15'); res['ctrlU']=clean(o).rstrip().endswith('rsynth>')
send(b'uts hello'); send(b'\x01p'); o=send(b'\x05\r',1.0); res['ctrlA_E']='hello' in clean(o).split('puts hello')[-1]
o=send(b'report_t\t'); o+=send(b'\t'); res['tabtab_list']='report_timing' in clean(o) and 'report_timing_derate' in clean(o)
send(b'\x15')
o=send(b'\x0c'); res['ctrlL']='\x1b[2J' in o
o=send(b'set design_name abc\r',0.8); o=send(b'puts $design_n\t'); res['var_tab']='$design_name ' in clean(o)
o=send(b'\r',0.8); res['var_val']='abc' in clean(o)
o=send(b'\x10\x10\x10'); o=send(b'\r',0.8); res['history_ctrlP']='hello' in clean(o)
o=send(b'\x12hel'); o=send(b'\r',0.8); res['ctrlR']='hello' in clean(o)
o=send(b'puts "a b"\x1b[D\x1b[D\x14\r',1.2); res['ctrlT_arrows']='\nab \n' in clean(o)
o=send(b'source lineedit_pty_t\t'); res['file_tab']='lineedit_pty_test.py ' in clean(o)
send(b'\x15'); o=send(b'help write_gd\t'); res['help_arg_tab']='write_gds ' in clean(o)
send(b'\x15'); o=send(b'puts abcXYZdef' + b'\x02'*6 + b'\x04\x04\x04\r', 1.0); res['ctrlD_fwd_delete']='\nabcdef\n' in clean(o)
send(b'\x15'); o=send(b'echo x\x03'); res['ctrlC']='^C' in o
import fcntl, termios, struct
fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack('HHHH', 24, 40, 0, 0))
send(b'\x15'); o=send(b'puts ' + b'x'*90 + b'\x01\x06\x06\x06\x06\x06"\x05"\r', 1.0); res['long_line']=('x'*90) in clean(o).replace('\n','')
o=send(b'exit\r',1.0)
print(res)
print('ALL OK' if all(res.values()) else 'FAIL')
