# =============================================================================
# RSynth MMMC (multi-mode multi-corner) configuration template
# -----------------------------------------------------------------------------
# Edit the four tables below (corners, modes, scenarios, analysis), then:
#
#   source mmmc/mmmc_config.tcl
#   mmmc_setup_libraries        ;# 1) before reading the design: corners, libraries,
#                               ;#    PVT, RC scaling, OCV tables, modes, scenarios
#   analyze ... ; elaborate TOP
#   mmmc_read_constraints       ;# 2) after elaboration: one SDC per mode, derates
#   ... compile_fusion / place_opt / clock_opt / route_auto ...
#   mmmc_read_parasitics        ;# 3) optional: per-corner SPEF (sign-off / ECO)
#   mmmc_report                 ;# summary of modes, corners, scenarios
#
# Paths are relative to the directory the tool is started in.
# =============================================================================

# -----------------------------------------------------------------------------
# 1. CORNERS (delay corners = library set + PVT + RC)
#    name  libraries  temperature(C)  voltage(V)  process  R-scale  C-scale  OCV-table  SPEF
#    - libraries : Tcl list of Liberty files for this corner (the first is the
#                  target library for mapping)
#    - R/C scale : multipliers on extracted / estimated wire R and C (1.0 = as is)
#    - OCV-table : AOCV / POCV side file for the corner, or "" for none
#    - SPEF      : parasitics for the corner (read by mmmc_read_parasitics), or ""
# -----------------------------------------------------------------------------
set MMMC_CORNERS {
    {ss  {lib/rs28_ss_0p72v_125c.lib}  125  0.72  ss  1.10  1.10  ""  ""}
    {tt  {lib/rs28_tt_0p80v_25c.lib}    25  0.80  tt  1.00  1.00  ""  ""}
    {ff  {lib/rs28_ff_0p88v_m40c.lib}  -40  0.88  ff  0.90  0.90  ""  ""}
}

# -----------------------------------------------------------------------------
# 2. MODES (constraint modes = one SDC each)
#    name  SDC-files
# -----------------------------------------------------------------------------
set MMMC_MODES {
    {func  {func.sdc}}
    {test  {test.sdc}}
}

# -----------------------------------------------------------------------------
# 3. SCENARIOS (analysis views = mode x corner) and what each one checks
#    name  mode  corner  active  setup  hold  leakage  dynamic  max_tran  max_cap
#    A typical sign-off set: setup at the slow corner, hold at the fast corner,
#    leakage at the hot corner, dynamic power at typical.
# -----------------------------------------------------------------------------
set MMMC_SCENARIOS {
    {func_ss  func  ss  true  true   false  true   false  true   true}
    {func_tt  func  tt  true  false  false  false  true   false  false}
    {func_ff  func  ff  true  false  true   false  false  false  false}
    {test_ss  test  ss  true  true   false  false  false  false  false}
    {test_ff  test  ff  true  false  true   false  false  false  false}
}

# -----------------------------------------------------------------------------
# 4. ANALYSIS
#    type  : ocv (default) | single_corner | min_max
#    min_max uses MMMC_MAX_CORNER for setup and MMMC_MIN_CORNER for hold
#    DERATES: {corner  late-data  early-data  late-clock  early-clock}
#             1.0 = no derate; leave the list empty for none
#    CURRENT_SCENARIO: the scenario reports and get_timing_paths default to
# -----------------------------------------------------------------------------
set MMMC_ANALYSIS_TYPE ocv
set MMMC_MAX_CORNER    ss
set MMMC_MIN_CORNER    ff
set MMMC_DERATES {
    {ss  1.03  0.97  1.05  0.95}
    {ff  1.03  0.97  1.05  0.95}
}
set MMMC_CURRENT_SCENARIO func_ss

# =============================================================================
# Procedures (normally no need to edit below this line)
# =============================================================================

proc mmmc_setup_libraries {} {
    global MMMC_CORNERS MMMC_MODES MMMC_SCENARIOS
    foreach c $MMMC_CORNERS {
        lassign $c name libs temp volt proc rs cs ocv spef
        create_corner $name
        foreach l $libs {
            read_lib -corner $name $l
        }
        set_temperature $temp -corners $name
        set_voltage $volt -corners $name
        set_process_label $proc -corners $name
        set_parasitic_parameters -corners $name -r_scale $rs -c_scale $cs
        if {$ocv ne ""} {
            read_ocvm -corners $name $ocv
        }
    }
    foreach m $MMMC_MODES {
        create_mode [lindex $m 0]
    }
    foreach s $MMMC_SCENARIOS {
        lassign $s name mode corner active setup hold leak dyn mtran mcap
        create_scenario -name $name -mode $mode -corner $corner
        set_scenario_status $name -active $active -setup $setup -hold $hold \
            -leakage_power $leak -dynamic_power $dyn -max_transition $mtran -max_capacitance $mcap
    }
    puts "MMMC: [llength $MMMC_CORNERS] corner(s), [llength $MMMC_MODES] mode(s), [llength $MMMC_SCENARIOS] scenario(s)"
}

proc mmmc_read_constraints {} {
    global MMMC_MODES MMMC_DERATES MMMC_ANALYSIS_TYPE MMMC_MAX_CORNER MMMC_MIN_CORNER MMMC_CURRENT_SCENARIO
    foreach m $MMMC_MODES {
        lassign $m mode sdcs
        current_mode $mode
        foreach f $sdcs {
            read_sdc $f
        }
    }
    foreach d $MMMC_DERATES {
        lassign $d corner ld ed lc ec
        set_timing_derate -late  $ld -data  -corners $corner
        set_timing_derate -early $ed -data  -corners $corner
        set_timing_derate -late  $lc -clock -corners $corner
        set_timing_derate -early $ec -clock -corners $corner
    }
    switch $MMMC_ANALYSIS_TYPE {
        single_corner { set_analysis_type -single_corner }
        min_max       { set_analysis_type -min_max -max_corner $MMMC_MAX_CORNER -min_corner $MMMC_MIN_CORNER }
        default       { set_analysis_type -ocv }
    }
    current_scenario $MMMC_CURRENT_SCENARIO
}

proc mmmc_read_parasitics {} {
    global MMMC_CORNERS
    foreach c $MMMC_CORNERS {
        set name [lindex $c 0]
        set spef [lindex $c 8]
        if {$spef ne ""} {
            read_parasitics -corner $name $spef
        }
    }
}

proc mmmc_report {} {
    report_scenarios
    report_analysis_type
    report_timing_derate
}
