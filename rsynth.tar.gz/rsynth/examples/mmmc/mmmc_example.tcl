# Example use of the MMMC template on the demo SoC (run from examples/)
source mmmc/mmmc_config.tcl
mmmc_setup_libraries
analyze -format sverilog {rtl/soc_pkg.sv rtl/bus_if.sv rtl/lane.sv rtl/arbiter.sv rtl/core.sv rtl/soc_top.sv}
analyze -format vhdl rtl/checksum.vhd
elaborate soc_top
mmmc_read_constraints
compile_fusion
mmmc_report
report_qor -summary
