#!/usr/bin/env python3
"""Generate the rs28 IO-pad and gate-array (post-mask ECO) libraries from the standard-cell
libraries (timing arcs reused from comparable cells), plus their LEF abstracts.

  rs28_io_<corner>.lib   PADIN PADOUT (signal pads), PVDD PVSS PVDDIO PVSSIO (supply pads),
                         PCLAMP (ESD power clamp), PBRK (IO-domain breaker), PCORNER,
                         PFILL1/5/10/20 (IO fillers), AIO_IN / AIO_OUT (flip-chip area-IO buffers)
  rs28_ga_<corner>.lib   GINV GBUF GNAND2 GNOR2 GAND2 GOR2 GXOR2 GDFF GSDFF and GFILL1/2/4:
                         gate-array base cells, all on a 0.8 um x 1.6 um base-unit grid so that
                         a GFILL run can be metal-programmed into any G cell of the same width
  rs28_io.lef            pad / corner / filler / bond-pad / bump / area-IO abstracts
  rs28_ga.lef            gate-array cell abstracts
  rs28_macros.lef        SRAM_SP_2KX32 hard macro (pins on its north edge, OBS M1-M4)
"""
import re, os
HERE = os.path.dirname(os.path.abspath(__file__))
CORNERS = ['tt_0p80v_25c', 'ss_0p72v_125c', 'ff_0p88v_m40c']

def cells(text):
    out = {}
    for m in re.finditer(r'^  cell\((\w+)\) \{', text, re.M):
        s = m.start(); depth = 0; i = text.index('{', s)
        for j in range(i, len(text)):
            if text[j] == '{': depth += 1
            elif text[j] == '}':
                depth -= 1
                if depth == 0:
                    out[m.group(1)] = text[s:j + 1]; break
    return out

def header(text, name):
    h = text[:text.index('  cell(')]
    return re.sub(r'library\(\w+\)', 'library(%s)' % name, h, count=1)

def rename(block, old, new, area, pins=None):
    b = block.replace('cell(%s)' % old, 'cell(%s)' % new, 1)
    b = re.sub(r'area : [0-9.]+;', 'area : %.4f;' % area, b, count=1)
    for a, z in (pins or {}).items():
        b = re.sub(r'pin\(%s\)' % a, 'pin(%s)' % z, b)
        b = b.replace('related_pin : "%s"' % a, 'related_pin : "%s"' % z)
        b = re.sub(r'(function : "[^"]*)\b%s\b' % a, r'\g<1>%s' % z, b)
    return b

def simple(name, area, attrs=''):
    return '  cell(%s) {\n    area : %.4f;\n    dont_touch : true;\n    dont_use : true;%s\n  }' % (name, area, attrs)

BASE_W, ROW_H = 0.8, 1.6
GA = [('GINV_X1', 'INV_X1_SVT', 2), ('GBUF_X1', 'BUF_X1_SVT', 2), ('GNAND2_X1', 'NAND2_X1_SVT', 2),
      ('GNOR2_X1', 'NOR2_X1_SVT', 2), ('GAND2_X1', 'AND2_X1_SVT', 3), ('GOR2_X1', 'OR2_X1_SVT', 3),
      ('GXOR2_X1', 'XOR2_X1_SVT', 4), ('GDFF_X1', 'DFF_X1_SVT', 7), ('GSDFF_X1', 'SDFF_X1_SVT', 9)]
GFILL = [('GFILL1', 1), ('GFILL2', 2), ('GFILL4', 4)]
PAD_W, PAD_H = 30.0, 80.0

for c in CORNERS:
    src = open(os.path.join(HERE, 'rs28_%s.lib' % c)).read()
    cl = cells(src)
    # ---------------- gate array
    out = [header(src, 'rs28_ga_%s' % c)]
    for g, s, u in GA:
        out.append(rename(cl[s], s, g, u * BASE_W * ROW_H))
    for g, u in GFILL:
        out.append(simple(g, u * BASE_W * ROW_H, '\n    /* gate-array base filler: metal-programmable into G* cells */'))
    open(os.path.join(HERE, 'rs28_ga_%s.lib' % c), 'w').write('\n'.join(out) + '\n}\n')
    # ---------------- IO pads (timing from the X8 buffer)
    out = [header(src, 'rs28_io_%s' % c)]
    pin_pad = '    pin(PAD) { direction : input; capacitance : 0.002; is_pad : true; }\n'
    b = rename(cl['BUF_X8_SVT'], 'BUF_X8_SVT', 'PADIN', PAD_W * PAD_H, {'A': 'PAD', 'Y': 'C'})
    out.append(b.replace('dont_touch', 'dont_touch').replace('area', 'pad_cell : true;\n    dont_touch : true;\n    dont_use : true;\n    area', 1))
    b = rename(cl['BUF_X8_SVT'], 'BUF_X8_SVT', 'PADOUT', PAD_W * PAD_H, {'A': 'I', 'Y': 'PAD'})
    out.append(b.replace('area', 'pad_cell : true;\n    dont_touch : true;\n    dont_use : true;\n    area', 1))
    b = rename(cl['BUF_X4_SVT'], 'BUF_X4_SVT', 'AIO_IN', 900.0, {'A': 'PAD', 'Y': 'C'})
    out.append(b.replace('area', 'pad_cell : true;\n    dont_touch : true;\n    dont_use : true;\n    area', 1))
    b = rename(cl['BUF_X4_SVT'], 'BUF_X4_SVT', 'AIO_OUT', 900.0, {'A': 'I', 'Y': 'PAD'})
    out.append(b.replace('area', 'pad_cell : true;\n    dont_touch : true;\n    dont_use : true;\n    area', 1))
    for n, w in [('PVDD', PAD_W), ('PVSS', PAD_W), ('PVDDIO', PAD_W), ('PVSSIO', PAD_W), ('PCLAMP', PAD_W), ('PBRK', 10.0),
                 ('PCORNER', PAD_H), ('PFILL1', 1.0), ('PFILL5', 5.0), ('PFILL10', 10.0), ('PFILL20', 20.0)]:
        out.append(simple(n, w * PAD_H, '\n    pad_cell : true;'))
    open(os.path.join(HERE, 'rs28_io_%s.lib' % c), 'w').write('\n'.join(out) + '\n}\n')

# ---------------- LEF
def macro(name, cls, w, h, pins, obs=None, sym='X Y', site=None):
    s = 'MACRO %s\n  CLASS %s ;\n  ORIGIN 0 0 ;\n  SIZE %.3f BY %.3f ;\n  SYMMETRY %s ;\n' % (name, cls, w, h, sym)
    if site: s += '  SITE %s ;\n' % site
    for p, d, u, ly, r in pins:
        s += '  PIN %s\n    DIRECTION %s ;\n    USE %s ;\n    PORT\n      LAYER %s ;\n        RECT %.3f %.3f %.3f %.3f ;\n    END\n  END %s\n' % (p, d, u, ly, r[0], r[1], r[2], r[3], p)
    if obs:
        s += '  OBS\n' + ''.join('    LAYER %s ;\n      RECT %.3f %.3f %.3f %.3f ;\n' % (ly, r[0], r[1], r[2], r[3]) for ly, r in obs) + '  END\n'
    return s + 'END %s\n\n' % name

HDR = 'VERSION 5.8 ;\nBUSBITCHARS "[]" ;\nDIVIDERCHAR "/" ;\nUNITS\n  DATABASE MICRONS 1000 ;\nEND UNITS\n\n'
# pads: outer (bond) edge at y = 0, core-side pins at the top edge (y = PAD_H)
L = HDR
L += 'LAYER AP\n  TYPE ROUTING ;\n  DIRECTION HORIZONTAL ;\n  PITCH 10.0 ;\n  WIDTH 5.0 ;\nEND AP\n\n'
core_pin = lambda x: (x - 0.5, PAD_H - 1.0, x + 0.5, PAD_H)
pad_obs = [('M1', (0, 0, PAD_W, PAD_H - 2.0)), ('M2', (0, 0, PAD_W, PAD_H - 2.0)), ('M3', (0, 0, PAD_W, PAD_H - 2.0))]
L += macro('PADIN', 'PAD INPUT', PAD_W, PAD_H, [('PAD', 'INPUT', 'SIGNAL', 'M4', (5, 0, 25, 20)), ('C', 'OUTPUT', 'SIGNAL', 'M2', core_pin(15))], pad_obs, 'X Y R90')
L += macro('PADOUT', 'PAD OUTPUT', PAD_W, PAD_H, [('PAD', 'OUTPUT', 'SIGNAL', 'M4', (5, 0, 25, 20)), ('I', 'INPUT', 'SIGNAL', 'M2', core_pin(15))], pad_obs, 'X Y R90')
for n, cls in [('PVDD', 'PAD POWER'), ('PVSS', 'PAD POWER'), ('PVDDIO', 'PAD POWER'), ('PVSSIO', 'PAD POWER'), ('PCLAMP', 'PAD POWER')]:
    L += macro(n, cls, PAD_W, PAD_H, [], pad_obs, 'X Y R90')
L += macro('PBRK', 'PAD SPACER', 10.0, PAD_H, [], [('M1', (0, 0, 10, PAD_H - 2))], 'X Y R90')
for w in (1, 5, 10, 20):
    L += macro('PFILL%d' % w, 'PAD SPACER', float(w), PAD_H, [], None, 'X Y R90')
L += macro('PCORNER', 'ENDCAP BOTTOMLEFT', PAD_H, PAD_H, [], [('M1', (0, 0, PAD_H, PAD_H))], 'X Y R90')
L += macro('BONDPAD', 'COVER', 24.0, 30.0, [('PAD', 'INOUT', 'SIGNAL', 'M6', (1, 1, 23, 29))], None, 'X Y R90')
L += macro('BUMP60', 'COVER BUMP', 60.0, 60.0, [('PAD', 'INOUT', 'SIGNAL', 'AP', (5, 5, 55, 55))], None, 'X Y R90')
L += macro('BUMP40', 'COVER BUMP', 40.0, 40.0, [('PAD', 'INOUT', 'SIGNAL', 'AP', (4, 4, 36, 36))], None, 'X Y R90')
L += macro('AIO_IN', 'BLOCK', 30.0, 30.0, [('PAD', 'INPUT', 'SIGNAL', 'M6', (12, 12, 18, 18)), ('C', 'OUTPUT', 'SIGNAL', 'M2', (14.5, 0, 15.5, 1))], [('M1', (0, 2, 30, 30)), ('M2', (0, 2, 30, 30))])
L += macro('AIO_OUT', 'BLOCK', 30.0, 30.0, [('PAD', 'OUTPUT', 'SIGNAL', 'M6', (12, 12, 18, 18)), ('I', 'INPUT', 'SIGNAL', 'M2', (14.5, 0, 15.5, 1))], [('M1', (0, 2, 30, 30)), ('M2', (0, 2, 30, 30))])
open(os.path.join(HERE, 'rs28_io.lef'), 'w').write(L + 'END LIBRARY\n')

G = HDR
for g, s, u in GA:
    pins = []
    G += macro(g, 'CORE', u * BASE_W, ROW_H, pins, None, 'X Y', 'coreSite')
for g, u in GFILL:
    G += macro(g, 'CORE SPACER', u * BASE_W, ROW_H, [], None, 'X Y', 'coreSite')
open(os.path.join(HERE, 'rs28_ga.lef'), 'w').write(G + 'END LIBRARY\n')

M = HDR
pins = []
names = ['CLK', 'CE', 'WE'] + ['A[%d]' % i for i in range(11)] + ['D[%d]' % i for i in range(8)] + ['Q[%d]' % i for i in range(8)]
W, H = 80.0, 60.0
for k, p in enumerate(names):
    x = 2.0 + k * (W - 4.0) / len(names)
    d = 'OUTPUT' if p.startswith('Q') else 'INPUT'
    pins.append((p, d, 'SIGNAL', 'M3', (x, H - 1.0, x + 0.4, H)))
M += macro('SRAM_SP_2KX32', 'BLOCK', W, H, pins, [('M1', (0, 0, W, H - 1.5)), ('M2', (0, 0, W, H - 1.5)), ('M3', (0, 0, W, H - 1.5)), ('M4', (0, 0, W, H))])
open(os.path.join(HERE, 'rs28_macros.lef'), 'w').write(M + 'END LIBRARY\n')
print('generated IO / gate-array libraries and LEF')
