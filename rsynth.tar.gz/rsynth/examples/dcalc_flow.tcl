# ---------------------------------------------------------------------------
# Delay calculation: global-route timing engine (Steiner RC trees, Elmore / D2M / AWE),
# post-route RC extraction (fast / detailed with coupling), AWE + effective capacitance,
# checks against a transient reference and global-route vs extraction correlation.
#   run from examples/:  rsynth -f dcalc_flow.tcl
# ---------------------------------------------------------------------------
source fp_flow_setup.tcl
place_opt
report_delay_calculation

puts "== QOR (lumped length-based wire estimates)"
report_qor -summary

# ---- global-route timing engine --------------------------------------------
set_delay_calculation -global_route_parasitics true -model elmore -layer_thresholds {50 200}
report_delay_calculation
puts "== QOR (global-route RC trees, Elmore)"
report_qor -summary
set_delay_calculation -model awe -ceff true
puts "== QOR (global-route RC trees, AWE + Ceff)"
report_qor -summary
check_delay_calculation -nets 40 -input_slew 0
check_delay_calculation -nets 40 -input_slew 0.05
report_delay_calculation -worst -input_slew 0.08 -reference

# ---- CTS, detailed routing ---------------------------------------------------
set_clock_tree_options -target_skew 0.05 -max_fanout 16
set_lib_cell_purpose -include cts [get_lib_cells {*/BUF_X4_SVT */BUF_X8_SVT}]
clock_opt -from build_clock -to route_clock
route_auto

# ---- post-route extraction ---------------------------------------------------
extract_rc -mode fast
puts "== QOR (extracted, fast)"
report_qor -summary
extract_rc -mode detailed
report_delay_calculation
puts "== QOR (extracted, detailed + coupling, AWE + Ceff, Miller 1)"
report_qor -summary
set_delay_calculation -miller 2.0
puts "== QOR (Miller 2: opposite-switching aggressors)"
report_qor -summary
set_delay_calculation -miller 1.0
report_rc_correlation -nets 5
check_delay_calculation -nets 60 -input_slew 0
check_delay_calculation -nets 60 -input_slew 0.05
report_delay_calculation -worst -input_slew 0.05 -reference

# ---- SPEF with coupling: write and read back --------------------------------
file mkdir out
write_parasitics -output out/dcalc
read_parasitics -corner ss out/dcalc.ss.spef
read_parasitics -corner ff out/dcalc.ff.spef
report_delay_calculation
puts "== QOR (read back from SPEF)"
report_qor -summary

# ---- option checks ------------------------------------------------------------
puts "NEG1 [catch {set_delay_calculation -model spice} m] $m"
puts "NEG2 [catch {set_delay_calculation -miller 9} m] $m"
puts "NEG3 [catch {extract_rc -mode turbo} m] $m"
