# Optimization controls of place_opt / clock_opt / route_opt:
#   -setup -hold -drv -power   which fixes run
#   -incremental               keep placement / trees / routes, fix what is left
#   -endpoints <file>          only the paths to the listed endpoints; the others are guarded
#   -effort low|medium|high
source fp_flow_setup.tcl
puts "=== OPT ERRORS"
puts "E1 [catch {place_opt -incremental} m] $m"
puts "E5 [catch {route_opt -incremental} m] $m"
puts "E4 [catch {clock_opt -incremental} m] $m"
place_opt
file mkdir out
# tighten the clock so that there is work left after place_opt
set_clock_uncertainty -setup 0.25 [get_clocks clk]
proc worst_eps {n f} {
  set fh [open $f w]
  puts $fh "# the $n worst setup endpoints"
  foreach_in_collection p [get_timing_paths -max_paths $n -nworst 1 -scenarios func_ss] {
    puts $fh [lindex [get_object_name [get_attribute $p endpoint]] 0]
  }
  close $fh
}
worst_eps 6 out/focus_eps.txt
set fh [open out/bad_eps.txt w] ; puts $fh "no_such_pin/D" ; close $fh
puts "E2 [catch {place_opt -incremental -endpoints out/bad_eps.txt} m] $m"
puts "E3 [catch {place_opt -effort extreme} m] $m"

puts "=== PLACE_OPT FOCUS"
place_opt -incremental -setup -endpoints out/focus_eps.txt -effort high
check_legality
puts "=== PLACE_OPT DRV"
set_max_transition 0.2 [current_design]
place_opt -incremental -drv -effort low
set_max_transition 0.35 [current_design]

puts "=== CLOCK_OPT"
clock_opt -from build_clock -to route_clock
clock_opt -incremental -setup -hold -endpoints out/focus_eps.txt
check_legality
puts "=== CLOCK_OPT HOLD"
set fh [open out/hold_eps.txt w]
foreach_in_collection p [get_timing_paths -delay_type min -max_paths 3 -nworst 1 -scenarios func_ff] { puts $fh [lindex [get_object_name [get_attribute $p endpoint]] 0] }
close $fh
clock_opt -incremental -hold -endpoints out/hold_eps.txt

puts "=== ROUTE_OPT"
route_auto
worst_eps 6 out/focus_eps2.txt
route_opt -incremental -setup -endpoints out/focus_eps2.txt -effort medium
check_routes
check_legality
verify_equivalence -cycles 1500 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1}
