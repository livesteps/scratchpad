# Round-trip: RTL reference vs. re-imported mapped netlist written by write_verilog
foreach c {ss tt ff} { create_corner $c }
read_lib -corner tt lib/rs28_tt_0p80v_25c.lib
analyze -format sverilog {rtl/soc_pkg.sv rtl/bus_if.sv rtl/lane.sv rtl/arbiter.sv rtl/core.sv rtl/soc_top.sv}
analyze -format vhdl rtl/checksum.vhd
elaborate soc_top
analyze -format verilog out/soc_top.mapped.v
elaborate soc_top -keep_reference
report_design
verify_equivalence -cycles 3000 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1 test_si0 0 test_si1 0 test_si2 0 test_si3 0}
