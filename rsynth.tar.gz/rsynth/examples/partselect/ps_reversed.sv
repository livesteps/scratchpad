module ps2 (input [15:0] i, output [6:0] a);
  assign a = i[3:9];      // reversed range on a descending vector
endmodule
