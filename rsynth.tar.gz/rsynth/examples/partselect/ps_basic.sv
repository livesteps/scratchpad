module ps (input [15:0] i, input [0:15] j, input [3:0] s, output [6:0] a, output [6:0] b, output [3:0] c, output [3:0] d, output [6:0] e, output [3:0] f);
  assign a = i[9:3];      // descending vector, descending select
  assign b = j[3:9];      // ascending vector, ascending select
  assign c = i[s +: 4];   // indexed part-select
  assign d = j[s +: 4];
  wire [0:6] t = i[9:3];
  assign e = t;
  assign f = i[15 -: 4];
endmodule
