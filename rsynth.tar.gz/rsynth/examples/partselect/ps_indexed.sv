module ps4 (input clk, input [3:0] s, input [0:15] j, input [15:0] i, input [7:0] x, input [23:8] m, input [8:23] n,
            output [3:0] a, output [3:0] b, output [3:0] c, output [3:0] d, output [3:0] e, output [3:0] f, output [3:0] g, output [3:0] h,
            output reg [15:0] o1, output reg [0:15] o2, output reg [0:15] o3);
  assign a = j[s +: 4];
  assign b = j[s -: 4];
  assign c = i[s +: 4];
  assign d = i[s -: 4];
  assign e = m[s+8 +: 4];
  assign f = n[s+8 +: 4];
  assign g = n[s+11 -: 4];
  assign h = m[s+11 -: 4];
  always @(posedge clk) begin
    o1 <= 16'h0; o2 <= 16'h0; o3 <= 16'h0;
    o1[s +: 4] <= x[3:0];
    o2[s +: 4] <= x[3:0];
    o3[s[2:0] +: 8] <= x;
  end
endmodule
