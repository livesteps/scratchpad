module sub (input [6:0] x, output [6:0] y); assign y = ~x; endmodule
module ps3 #(parameter LO = 3, HI = 9) (input clk, input [0:15] i, input [15:0] k, output reg [0:15] o, output [0:15] p, output [13:0] q, output [6:0] r, output [6:0] u, output [3:0] v);
  reg [0:15] mem [0:3];
  always @(posedge clk) begin
    o[3:9] <= i[LO:HI];
    o[0:2] <= i[0:2];
    o[10:15] <= {i[10:12], i[13:15]};
    mem[1][3:9] <= i[3:9];
  end
  assign p[3:9] = i[3:9] + 7'd1;
  assign p[0:2] = 3'b0;
  assign p[10:15] = 6'b0;
  assign q = {i[3:9], k[9:3]};
  sub u0 (.x(i[3:9]), .y(r));
  assign u = mem[1][3:9];
  assign v = i[3:9] >> 3;
endmodule
