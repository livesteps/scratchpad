#!/usr/bin/env python3
"""Simulate RTL against the RSynth generic netlist with iverilog: eqv.py rtl.sv top netlist.v"""
import re, subprocess, sys, os
rtl, top, net = sys.argv[1:4]
src = open(rtl).read()
ref = re.sub(r'\bmodule (\w+)', r'module ref_\1', src)
ref = re.sub(r'^(\s*)(sub) (u\w+)', r'\1ref_\2 \3', ref, flags=re.M)
open('out/ref_%s.sv' % top, 'w').write(ref)
m = re.search(r'module ref_%s\s*(#\(.*?\))?\s*\((.*?)\);' % top, ref, re.S)
decl = []
for d in re.split(r',(?![^\[]*\])', m.group(2)):
    d = d.strip()
    mm = re.match(r'(input|output)\s*(reg|wire)?\s*(\[[^\]]+\])?\s*(\w+)', d)
    if mm:
        decl.append((mm.group(1), mm.group(3) or '', mm.group(4)))
    else:
        mm = re.match(r'(\[[^\]]+\])?\s*(\w+)', d)
        decl.append((decl[-1][0], mm.group(1) or decl[-1][1], mm.group(2)))
tb = ['`timescale 1ns/1ps', 'module tb;',
      '  function automatic bit neq(input logic [127:0] a, input logic [127:0] b); for (int t=0;t<128;t++) if ((a[t]===1\'b0 || a[t]===1\'b1) && a[t]!==b[t]) return 1; return 0; endfunction']
for d, w, n in decl:
    tb.append('  reg %s %s;' % (w, n) if d == 'input' else '  wire %s r_%s, g_%s;' % (w, n, n))
conn = lambda pre: ', '.join('.%s(%s)' % (n, n if d == 'input' else pre + n) for d, w, n in decl)
tb += ['  ref_%s R (%s);' % (top, conn('r_')), '  %s G (%s);' % (top, conn('g_')), '  integer kk, bad; initial begin bad=0;', '    for (kk=0;kk<500;kk=kk+1) begin']
for d, w, n in decl:
    if d == 'input' and n != 'clk':
        tb.append('      %s = {$random,$random,$random};' % n)
tb.append('      clk=0; #1 clk=1; #1;' if any(n == 'clk' for _, _, n in decl) else '      #1;')
for d, w, n in decl:
    if d == 'output':
        tb.append('      if (kk>2 && neq(r_%s, g_%s)) begin bad=bad+1; if (bad<8) $display("MISMATCH %s ref=%%b gate=%%b", r_%s, g_%s); end' % (n, n, n, n, n))
tb += ['    end', '    $display("RESULT %0d mismatches", bad); $finish; end', 'endmodule']
open('out/tb_%s.v' % top, 'w').write('\n'.join(tb) + '\n')
r = subprocess.run(['iverilog', '-g2012', '-o', 'out/sim_%s' % top, 'out/tb_%s.v' % top, 'out/ref_%s.sv' % top, net], capture_output=True, text=True)
if r.returncode:
    print(r.stdout + r.stderr); sys.exit(1)
print(subprocess.run(['vvp', 'out/sim_%s' % top], capture_output=True, text=True).stdout.strip().splitlines()[-2])
