# Part-selects: ascending / descending vectors, constant, reversed and indexed (+: / -:)
# selects as rvalues and lvalues (incl. variable start), hierarchy port ranges.
file mkdir out
foreach {f top} {ps_basic.sv ps ps_ascending.sv ps3 ps_indexed.sv ps4 ps_reversed.sv ps2} {
  remove_design -all
  analyze -format sverilog $f
  elaborate $top
  write_verilog out/${top}_gen.v
  puts "DONE $top"
}
