# change_names with the verilog rules (hierarchy, buses), equivalence after renaming
source flow.tcl
puts "=== CN"
report_qor -summary
write_verilog out/pre_names.v
set n [report_names -rules verilog]
puts "DRYRUN $n"
change_names -rules verilog -hierarchy -verbose -log_changes out/names.log
report_names -rules verilog -hierarchy
write_verilog out/soc_top.names.v
write_verilog -flat out/soc_top.names_flat.v
report_qor -summary
puts "ALIAS [get_object_name [get_cells -quiet {u_core/g_lane[0].u_lane/m.valid_reg}]] [sizeof_collection [get_cells -quiet u_core/g_lane_0__u_lane/*]]"
verify_equivalence -cycles 3000 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1 test_si0 0 test_si1 0 test_si2 0 test_si3 0}
report_scan_chains
puts "=== FLATTEN"
ungroup -all -flatten
change_names -rules verilog
write_verilog -flat out/soc_top.flat_names.v
verify_equivalence -cycles 3000 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1 test_si0 0 test_si1 0 test_si2 0 test_si3 0}
