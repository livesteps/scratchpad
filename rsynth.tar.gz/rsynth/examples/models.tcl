# timing models: ETM (extract_model), ILM, NDM-style bundle, QTM, write_lib from a stub
source fp_flow_setup.tcl
puts "=== MODELS"
file mkdir out/models
extract_model -output out/models/soc_top_etm.lib -scenario func_ss
write_ilm -output out/models/soc_top_ilm.v
write_ndm -output out/models/soc_top.ndm
# full-design setup slack of one input, to compare with the model
set p [get_timing_paths -from [get_ports {din1[3]}] -scenarios func_ss]
puts "FULL din1\[3\] slack [get_attribute $p slack] startpoint [get_object_name [get_attribute $p startpoint]]"
# QTM
create_qtm_model blk_qtm
create_qtm_port {ck} -type clock
create_qtm_port {a b} -type input
create_qtm_port {y q} -type output
set_qtm_port_load -value 0.004 {a b}
create_qtm_constraint_arc -setup -from ck -to {a b} -value 0.12
create_qtm_constraint_arc -hold  -from ck -to {a b} -value 0.03
create_qtm_delay_arc -from ck -to q -value 0.31
create_qtm_delay_arc -from {a b} -to y -value 0.22
set_qtm_area 42
report_qtm_model
save_qtm_model -output out/models/blk_qtm
remove_design -all
analyze -format verilog models/stub.v
elaborate pll_ip
write_lib -output out/models/pll_ip.lib -clock ref_clk -setup 0.08 -hold 0.02 -clk_to_q 0.35 -input_cap 0.003 -max_transition 0.3 -area 1200 -comb_arcs -delay 0.4
puts "=== READBACK"
foreach f {out/models/soc_top_etm.lib out/models/blk_qtm.lib out/models/pll_ip.lib} { read_lib $f }
