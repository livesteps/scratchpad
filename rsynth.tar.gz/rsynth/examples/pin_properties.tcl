# Per-pin timing properties (setup/hold slack, rise/fall, arrival, required, transition, load)
# checked against the path search, on every pin of the worst setup and hold paths
source fp_flow_setup.tcl
puts "=== PIN PROPERTIES"
set ss func_ss ; set ff func_ff
set w [get_timing_paths -scenarios $ss]
set ep [get_attribute $w endpoint]
puts "EP [get_object_name $ep] path [get_attribute $w slack] pin.slack_max [get_property $ep slack_max -view $ss] rise [get_property $ep slack_max_rise -view $ss] fall [get_property $ep slack_max_fall -view $ss]"
# every pin on the worst path: pin slack must equal the worst path through it (GBA)
set bad 0 ; set n 0
foreach_in_collection pt [get_attribute $w points] {
  set pin [get_attribute $pt object]
  set s [get_property $pin slack_max -view $ss]
  set t [get_attribute [get_timing_paths -through $pin -scenarios $ss] slack]
  if {abs($s - $t) > 1e-4} { incr bad; puts "  MISMATCH [get_object_name $pin] pin $s thr $t" }
  set tr [get_property $pin slew_max -view $ss]
  if {abs($tr - [get_attribute $pt transition]) > 1e-4} { incr bad; puts "  SLEW [get_object_name $pin] $tr vs [get_attribute $pt transition]" }
  if {[get_attribute $pt capacitance] ne ""} {
     if {abs([get_property $pin load -view $ss] - [get_attribute $pt capacitance]) > 1e-6} { incr bad ; puts "  LOAD [get_object_name $pin]" }
  }
  incr n
}
puts "WORSTPATH_PINS $n BAD $bad"
# hold
set h [get_timing_paths -hold -scenarios $ff]
set hep [get_attribute $h endpoint]
puts "HOLD [get_object_name $hep] path [get_attribute $h slack] pin.slack_min [get_property $hep slack_min -view $ff]"
set hbad 0
foreach_in_collection pt [get_attribute $h points] {
  set pin [get_attribute $pt object]
  set s [get_property $pin slack_min -view $ff]
  set t [get_attribute [get_timing_paths -hold -through $pin -scenarios $ff] slack]
  if {abs($s - $t) > 1e-4} { incr hbad; puts "  HMISMATCH [get_object_name $pin] pin $s thr $t" }
}
puts "HOLDPATH BAD $hbad"
# merged (all scenarios) vs per-view
puts "MERGED slack_max [get_property $ep slack_max] slack_min [get_property $ep slack_min] slew_max [get_property $ep slew_max] slew_min [get_property $ep slew_min]"
set u [get_cells -of_objects $ep]
set q $ep
puts "PINPROPS D: cap [get_property $q pin_capacitance] arr_max_r [get_property $q arrival_max_rise] arr_min_f [get_property $q arrival_min_fall] req_max [get_property $q required_max]"
# all pins
set t0 [clock milliseconds]
set all [get_pins -hier *]
set sl [get_property $all slack_max]
set t1 [clock milliseconds]
set tr [get_property $all slew_max]
set ld [get_property $all load]
set mn [get_property $all slack_min]
set t2 [clock milliseconds]
puts "ALLPINS [sizeof_collection $all] values [llength $sl] [llength $tr] [llength $ld] [llength $mn] first_ms [expr {$t1-$t0}] next3_ms [expr {$t2-$t1}]"
set neg [filter_collection $all "slack_max < 0"]
puts "NEG [sizeof_collection $neg]"
# ECO invalidates the cache
set c [get_object_name [get_attribute [index_collection [get_attribute $w points] 3] cell]]
set p3 [get_attribute [index_collection [get_attribute $w points] 3] object]
set before [get_property $p3 slew_max -view $ss]
size_cell $c [string map {_X1_ _X2_ _SVT _LVT} [get_attribute [get_cells $c] ref_name]]
puts "ECO $c slew $before -> [get_property $p3 slew_max -view $ss]"
puts "DB [dbGet [dbGetInstTermByName [get_object_name $ep]].slack_max]"
