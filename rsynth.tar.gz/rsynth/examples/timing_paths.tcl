# Timing path collection checks: exactness, ordering, -nworst, -through, hold, filter/sort, attributes
source fp_flow_setup.tcl
puts "=== TP"
report_qor -summary
set w [index_collection [get_timing_paths -scenarios func_ss] 0]
puts "WORST [get_attribute $w slack] [get_object_name [get_attribute $w startpoint]] -> [get_object_name [get_attribute $w endpoint]] levels [get_attribute $w num_logic_levels]"
# arrival consistency: sum of increments + launch = arrival
set sum 0.0
foreach_in_collection pt [get_attribute $w points] { set sum [expr {$sum + [get_attribute $pt incr]}] }
puts "SUMINCR $sum ARR [get_attribute $w arrival] OPEN [get_attribute $w startpoint_clock_open_edge_value] LAT [get_attribute $w startpoint_clock_latency]"
set ps [report_timing -collection -setup -scenarios func_ss -max_paths 40 -nworst 4]
puts "N [sizeof_collection $ps]"
set prev -1e9 ; set ok 1
foreach_in_collection p $ps { set s [get_attribute $p slack]; if {$s < $prev - 1e-9} {set ok 0}; set prev $s }
puts "SORTED $ok"
# per-endpoint nworst
set ep [get_attribute $w endpoint]
set pe [report_timing -collection -to $ep -nworst 5 -max_paths 5 -scenarios func_ss]
foreach_in_collection p $pe { puts "  EPW [get_attribute $p slack] from [get_object_name [get_attribute $p startpoint]]" }
# through a mid point of the 3rd worst path
set p3 [index_collection $ps 7]
set pts [get_attribute $p3 points]
set mid [get_attribute [index_collection $pts 4] object]
puts "THROUGH_PIN [get_object_name $mid]"
set pt [report_timing -collection -through $mid -max_paths 10 -nworst 2 -scenarios func_ss]
set allin 1
foreach_in_collection p $pt {
  set hit 0
  foreach_in_collection q [get_attribute $p points] { if {[get_attribute $q object] eq $mid} {set hit 1} }
  if {!$hit} {set allin 0}
}
puts "THR_N [sizeof_collection $pt] ALL_THROUGH $allin FIRST [get_attribute [index_collection $pt 0] slack]"
set h [get_timing_paths -hold -scenarios func_ff -max_paths 3]
foreach_in_collection p $h { puts "  HOLD [get_attribute $p slack] [get_attribute $p path_type] crpr [get_attribute $p crpr_value]" }
set v [filter_collection $ps "slack < -0.4"]
puts "FILTER [sizeof_collection $v]"
set s [sort_collection -descending $ps slack]
puts "SORTDESC [get_attribute [index_collection $s 0] slack]"
puts "GROUP [get_attribute $w path_group] CLK [get_object_name [get_attribute $w startpoint_clock]] -> [get_object_name [get_attribute $w endpoint_clock]]"
# clock / group / exclude filters
puts "CLKFILT [sizeof_collection [get_timing_paths -clock_from vclk -max_paths 50 -scenarios func_ss]] [sizeof_collection [get_timing_paths -group vclk -max_paths 50 -scenarios func_ss]]"
set ex [report_timing -collection -exclude $mid -max_paths 30 -nworst 3 -scenarios func_ss]
set none 1
foreach_in_collection p $ex { foreach_in_collection q [get_attribute $p points] { if {[get_attribute $q object] eq $mid} {set none 0} } }
puts "EXCLUDED $none"
report_timing -scenarios func_ss -nworst 2 -max_paths 2 -path_type summary
