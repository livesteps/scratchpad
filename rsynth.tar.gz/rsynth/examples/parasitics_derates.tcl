# multi-corner SPEF, annotated parasitics/delays, object derates, path_adjust, analysis types, DRV limits
source fp_flow_setup.tcl
place_opt
legalize_placement
route_auto
file mkdir out
write_parasitics -output out/tc_rt
puts "=== TC"
proc wns {s} { return [get_attribute [get_timing_paths -scenarios $s] slack] }
proc whs {s} { return [get_attribute [get_timing_paths -hold -scenarios $s] slack] }
set w0 [wns func_ss] ; set h0 [whs func_ff]
puts "EXTRACTED wns $w0 whs $h0"
read_parasitics -corner ss out/tc_rt.ss.spef
read_parasitics -scenario func_ff out/tc_rt.ff.spef
report_annotated_parasitics
set w1 [wns func_ss] ; set h1 [whs func_ff]
puts "SPEF wns $w1 whs $h1"
# annotated delay on the worst path's 4th point cell arc
set p [get_timing_paths -scenarios func_ss]
set pts [get_attribute $p points]
set k 0
foreach_in_collection q $pts { if {[get_attribute $q capacitance] ne "" && $k > 1} {set outp [get_attribute $q object]; break}; incr k }
set inp [get_attribute [index_collection $pts [expr {$k-1}]] object]
puts "ARC [get_object_name $inp] -> [get_object_name $outp] incr_before [get_attribute [index_collection $pts $k] incr]"
set_annotated_delay -cell -from $inp -to $outp 0.5
set p2 [get_timing_paths -through $outp -scenarios func_ss]
foreach_in_collection q [get_attribute $p2 points] { if {[get_attribute $q object] eq $outp} { puts "ANN incr [get_attribute $q incr] slack [get_attribute $p2 slack]" } }
report_annotated_delay
remove_annotated_delay -all
puts "ANN_REMOVED [wns func_ss]"
# object derate on that cell (ss corner)
set cl [get_cells -of_objects $outp]
set_timing_derate -late -cell 1.5 $cl -corners ss
set p3 [get_timing_paths -through $outp -scenarios func_ss]
foreach_in_collection q [get_attribute $p3 points] { if {[get_attribute $q object] eq $outp} { puts "DERATED incr [get_attribute $q incr]" } }
set_timing_derate -early -net -data 0.9 -corners ff
set_timing_derate -late -net -clock 1.05 -corners ss
report_timing_derate
reset_timing_derate
puts "DERATE_RESET [wns func_ss]"
# path_adjust
set ep [get_attribute [get_timing_paths -scenarios func_ss] endpoint]
path_adjust -delay 0.1 -to $ep -setup
puts "ADJUST [get_attribute [get_timing_paths -to $ep -scenarios func_ss] slack]"
report_path_adjust
reset_path_adjust
# analysis types
set_timing_derate -late 1.1 -corners ss
puts "OCV [wns func_ss]"
set_analysis_type -single_corner
puts "SINGLE [wns func_ss]"
report_analysis_type
set_analysis_type -min_max -max_corner ss -min_corner ff
report_analysis_type
set_analysis_type -ocv
reset_timing_derate
# DRV limits on the design
set_max_transition 0.06 [current_design]
set_max_fanout 4 [current_design]
report_constraint -all_violators -drv_violation_type {max_transition max_fanout} -scenarios func_ss
set nn [get_object_name [get_attribute [index_collection [get_attribute $p points] 2] net]]
report_constraint -drv_violation_type max_fanout -verbose -scenarios func_ss [get_nets $nn]
catch {report_constraint -drv_violation_type max_bogus} m ; puts "BADTYPE $m"
