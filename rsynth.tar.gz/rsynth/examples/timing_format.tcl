# report_timing_format: column selection for timing reports
source fp_flow_setup.tcl
puts "=== RF"
report_timing -scenarios func_ss
report_timing_format {instance cell fanout cap trans incr path edge location}
report_timing -scenarios func_ss
report_timing -scenarios func_ss -format {point net fanout incr path required slack}
report_timing_format -reset
report_timing -scenarios func_ss -capacitance -transition_time -nets
report_timing_format -help
# pin transition, output-pin load capacitance and output-pin fanout columns
puts "=== TCF"
report_timing_format -reset
report_timing_format -transition -capacitance -fanout
report_timing -scenarios func_ss
report_timing_format -fanout -remove
puts "=== TCF2"
report_timing -scenarios func_ss
report_timing_format -reset
catch {report_timing -format {point bogus}} m ; puts "BAD $m"
