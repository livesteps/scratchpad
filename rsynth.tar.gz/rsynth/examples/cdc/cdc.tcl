read_lib ../lib/rs28_ss_0p72v_125c.lib
analyze -format verilog cdc.v
elaborate cdc
read_sdc cdc.sdc
compile_fusion -to initial_opto
report_clocks
report_clocks -skew
report_clock_crossing
report_clock_crossing -from clka -to clkb -verbose
