// Clock-domain-crossing test: clka -> clkb (asynchronous), clka -> clka_div2 (generated, synchronous)
module cdc (input clka, input clkb, input rst_n, input [3:0] din, input sel,
            output reg [3:0] q_sync, output reg q_bad, output reg q_comb, output reg [3:0] q_div);
  reg [3:0] a_reg;            // launch registers in clka
  reg       a_flag;
  always @(posedge clka or negedge rst_n) if (!rst_n) begin a_reg <= 0; a_flag <= 0; end else begin a_reg <= din; a_flag <= sel; end
  // (1) proper 2-FF synchronizer on a_flag
  reg s1, s2;
  always @(posedge clkb or negedge rst_n) if (!rst_n) begin s1 <= 0; s2 <= 0; end else begin s1 <= a_flag; s2 <= s1; end
  // (2) unsynchronized multi-bit capture of a_reg
  reg [3:0] b_bad;
  always @(posedge clkb) begin b_bad <= a_reg; q_bad <= ^b_bad; q_sync <= {4{s2}} & b_bad; end
  // (3) combinational logic before a synchronizer
  reg c1, c2;
  always @(posedge clkb) begin c1 <= a_reg[0] & a_reg[1]; c2 <= c1; q_comb <= c2; end
  // (4) divided clock (synchronous to clka)
  reg div;
  always @(posedge clka or negedge rst_n) if (!rst_n) div <= 0; else div <= ~div;
  always @(posedge div) q_div <= a_reg;
endmodule
