create_clock -name clka -period 2.0 [get_ports clka]
create_clock -name clkb -period 3.0 -waveform {0 1.2} [get_ports clkb]
create_generated_clock -name clka_div2 -source [get_ports clka] -divide_by 2 [get_pins div_reg/Q]
set_clock_groups -asynchronous -group {clka clka_div2} -group {clkb}
set_clock_uncertainty -setup 0.05 [get_clocks clka]
set_clock_latency -source 0.1 [get_clocks clkb]
set_input_delay 0.2 -clock clka [get_ports {din sel}]
set_output_delay 0.2 -clock clkb [get_ports {q_sync q_bad q_comb}]
set_output_delay 0.2 -clock clka_div2 [get_ports q_div]
