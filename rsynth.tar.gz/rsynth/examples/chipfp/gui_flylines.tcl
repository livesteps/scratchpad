# ---------------------------------------------------------------------------
# GUI data: pin-level flylines of selected macros, schematic views, the complete
# command help / list. Interactive: rsynth -f macro_fp.tcl -gtk_gui
# ---------------------------------------------------------------------------
source macro_fp.tcl
# flylines of every pin of one macro to all level-1 connected pins (cells, macros, ports)
gui_show_flylines -cells {u_bank0/u_ram0} -exclude_nets {}
gui_show_flylines -all_macros -exclude_nets {clk rst_n}
gui_show_flylines -all_macros -macro_to_macro -color_by macro
gui_show_flylines -all_macros -all_connections -color_by net
# standard cells too: the macro plus all registers of bank 0
gui_show_flylines -cells {u_bank0/u_ram0} -exclude_nets {}
gui_show_flylines -add -cells {u_bank0/*reg*}
gui_show_flylines -all_std_cells -max_fanout 8
gui_show_flylines -cells {u_bank0/u_ram0} -max_fanout 0
# view request for the GTK GUI
gui_zoom -rect {10 10 90 70}
# schematic: cone around a macro, then the whole design
gui_show_schematic -cells {u_bank0/u_ram0} -depth 1
gui_show_schematic -all
gui_write_state out/gui_flylines.json
if {[catch {write_schematic out/schematic.svg -cells {u_bank1/*} -depth 1} m]} { puts "schematic image: $m" }
if {[catch {gui_write_image out/layout.png} m]} { puts "layout image: $m" }
# complete command help / list
help write_gds
help gui_show
help *flyline*
write_command_list out/commands.csv
write_command_list out/commands.md
puts "commands: [llength [list_commands]]"
gui_deselect_all
