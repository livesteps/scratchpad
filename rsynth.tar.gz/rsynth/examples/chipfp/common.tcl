# libraries shared by the chip-level examples
create_mode func ; create_corner tt
read_lib -corner tt ../lib/rs28_tt_0p80v_25c.lib
read_lib -corner tt ../lib/rs28_io_tt_0p80v_25c.lib
read_lib -corner tt ../lib/rs28_ga_tt_0p80v_25c.lib
create_scenario -name func_tt -mode func -corner tt
read_lef ../lib/rs28_tech.lef ../lib/rs28_io.lef ../lib/rs28_macros.lef ../lib/rs28_ga.lef
report_lef
set_app_options -name hdlin.elaborate.empty_module_as_blackbox -value true
