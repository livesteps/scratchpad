# ---------------------------------------------------------------------------
# Block floorplan with hard macros: die / core from width, height and spacing,
# IO pins with bus grouping, refinement, layer / width / depth / track pitch,
# snapping to routing tracks, module-grouped macro placement along the core
# boundary (no flyline crossings), manual macro edits and placement-grid snap.
# ---------------------------------------------------------------------------
source common.tcl
analyze -format sverilog rtl/mem_sys.sv
elaborate mem_sys
create_clock -name clk -period 2.0 [get_ports clk]
compile_fusion -to logic_opto
report_lef SRAM*

# core 300 x 240 um, 12 um core-to-die spacing (left bottom right top)
initialize_floorplan -core_width 300 -core_height 240 -core2die_spacing {12 12 12 12} -row_height 1.6 -no_pins
# alternative forms (die from utilization + aspect ratio, explicit die + core)
initialize_floorplan -core_utilization 0.05 -aspect_ratio 0.8 -core2die_spacing 10 -no_pins
initialize_floorplan -die_width 324 -die_height 264 -core_width 300 -core_height 240 -no_pins

# ---- IO pins: buses grouped, each group on its side, refined later
place_io_pins -bus_name {addr wdata} -direction {left} -layer M3 -width 0.2 -depth 0.8 -track_pitch 2
place_io_pins -ports {rdata*} -auto_group_bus -direction {right} -layer M3 -track_pitch 4
place_io_pins -ports {clk rst_n we bsel} -direction {top} -layer M4 -width 0.2 -depth 0.6
# randomised placement for exploration, then the deterministic one back
place_io_pins -ports {clk rst_n we bsel} -direction {top bottom} -random_place -seed 3
place_io_pins -ports {clk rst_n we bsel} -direction {top} -layer M4

# ---- macros: grouped by module (bank0 / bank1), pins facing the core, 3 um halo
report_flylines
place_macros -group_by module -spacing 4 -halo 3
report_flylines
# manual edit: nudge one macro, rotate it, then snap all macros to the placement grid
move_objects -objects {u_bank1/u_ram1} -delta {0.37 0.55}
move_objects -objects {u_bank1/u_ram1} -orientation mirror
snap_macros_to_grid -grid {0.2 1.6}
report_flylines

# ---- spare cells per module (u_bank0, u_bank1), pre-placed in each module's region
insert_spare_cells -cells {INV_X1_SVT 2 NAND2_X1_SVT 2 NOR2_X1_SVT 1 DFF_X1_SVT 1} -groups_per_module 2

# ---- standard cells, then refine IO pins against the placed logic and snap to tracks
place_opt
report_spare_cells
place_io_pins -bus_name {addr wdata} -direction {left top} -auto_group_bus -refine -layer M3 -track_pitch 2
move_objects -objects {we} -delta {0.13 0}
snap_pins_to_tracks
check_legality
file mkdir out
write_def out/mem_sys_fp.def
export_gds -gds_map_file ../gds/rs28.map -output out/mem_sys_fp.gds -no_routing
