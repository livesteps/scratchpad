// Macro design: two memory banks, each with two SRAM_SP_2KX32 hard macros (empty module ->
// black box, LEF abstract in lib/rs28_macros.lef) and its own address / data logic.
module SRAM_SP_2KX32 (input CLK, input CE, input WE, input [10:0] A, input [7:0] D, output [7:0] Q);
endmodule

module mem_bank (
  input  logic        clk, rst_n, we,
  input  logic [10:0] addr,
  input  logic [7:0]  wdata,
  output logic [7:0]  rdata
);
  logic [10:0] a_q;
  logic [7:0]  d_q, q0, q1;
  logic        sel;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin a_q <= '0; d_q <= '0; sel <= 1'b0; end
    else begin a_q <= addr; d_q <= wdata ^ {addr[7:0]}; sel <= addr[10]; end
  SRAM_SP_2KX32 u_ram0 (.CLK(clk), .CE(~a_q[10]), .WE(we), .A(a_q), .D(d_q), .Q(q0));
  SRAM_SP_2KX32 u_ram1 (.CLK(clk), .CE(a_q[10]),  .WE(we), .A(a_q), .D(~d_q), .Q(q1));
  always_ff @(posedge clk) rdata <= sel ? q1 : q0;
endmodule

module mem_sys (
  input  logic        clk, rst_n, we,
  input  logic [10:0] addr,
  input  logic [7:0]  wdata,
  input  logic        bsel,
  output logic [7:0]  rdata
);
  logic [7:0] r0, r1;
  mem_bank u_bank0 (.clk, .rst_n, .we(we & ~bsel), .addr, .wdata, .rdata(r0));
  mem_bank u_bank1 (.clk, .rst_n, .we(we & bsel),  .addr(~addr), .wdata(~wdata), .rdata(r1));
  always_ff @(posedge clk) rdata <= bsel ? r1 : r0;
endmodule
