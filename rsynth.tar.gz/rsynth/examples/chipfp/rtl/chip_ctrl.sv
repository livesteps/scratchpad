// Small control core used by the chip-level floorplan, pad-ring, flip-chip, route-edit
// and ECO examples: an accumulator / CRC datapath with a bus-wide input and output.
module chip_ctrl (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [7:0] din,
  input  logic [1:0] mode,
  input  logic       en,
  output logic [7:0] dout,
  output logic       valid,
  output logic       err
);
  logic [7:0] acc, crc, pipe;
  logic [2:0] cnt;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      acc <= '0; crc <= 8'hff; pipe <= '0; cnt <= '0; valid <= 1'b0; err <= 1'b0;
    end else if (en) begin
      case (mode)
        2'd0: acc <= acc + din;
        2'd1: acc <= acc ^ din;
        2'd2: acc <= {acc[6:0], acc[7]} & din;
        default: acc <= ~acc;
      endcase
      crc   <= {crc[6:0], 1'b0} ^ (crc[7] ? 8'h07 : 8'h00) ^ din;
      pipe  <= acc ^ crc;
      cnt   <= cnt + 3'd1;
      valid <= &cnt;
      err   <= (crc == 8'h00) & valid;
    end
  end
  assign dout = pipe;
endmodule
