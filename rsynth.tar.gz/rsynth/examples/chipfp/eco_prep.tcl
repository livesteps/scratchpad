# ---------------------------------------------------------------------------
# ECO preparation: implement the base design, then write the functional ECO
# target netlist (inverted err / valid outputs, an extra buffer on dout[0]).
# ---------------------------------------------------------------------------
source common.tcl
source eco_flow_base.tcl
file mkdir out
write_verilog out/chip_eco_base.v
insert_buffer [get_nets err]   INV_X1_SVT
insert_buffer [get_nets valid] INV_X1_SVT
insert_buffer [get_ports {dout[0]}] BUF_X1_SVT
write_verilog out/chip_eco_v2.v
