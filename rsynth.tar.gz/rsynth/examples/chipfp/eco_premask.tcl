# ---------------------------------------------------------------------------
# Pre-mask ECO: netlist diff against the ECO target (connectivity based),
# apply, ECO placement and routing, then verify the result is the target.
# ---------------------------------------------------------------------------
source common.tcl
# the ECO target netlist is the verification reference
read_verilog out/chip_eco_v2.v
elaborate chip_ctrl
source eco_flow_base.tcl
eco_netlist -by_verilog_file out/chip_eco_v2.v
eco_netlist -by_verilog_file out/chip_eco_v2.v -apply
eco_place
legalize_placement -incremental
route_eco
check_routes
check_legality
# a second diff finds nothing left to change
eco_netlist -by_verilog_file out/chip_eco_v2.v
verify_equivalence -cycles 400 -resets {rst_n}
report_eco_changes
