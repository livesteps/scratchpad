# Power planning, special routing, route rules and physical verification on the macro floorplan
source common.tcl
read_lib -corner tt ../lib/rs28_phys.lib
read_lef ../lib/rs28_phys.lef
analyze -format sverilog rtl/mem_sys.sv
elaborate mem_sys
create_clock -name clk -period 2.0 [get_ports clk]
compile_fusion -to logic_opto
initialize_floorplan -die_width 340 -die_height 280 -core_width 300 -core_height 240 -no_pins
place_io_pins -ports * -direction {left right} -layer M3
place_macros -group_by module -spacing 4 -halo 3
snap_macros_to_grid -grid {0.2 1.6}
cut_row -halo 4
# ---- global PG connectivity
puts "GC1 [globalNetConnect VDD -type pgpin -pin VDD -inst *]"
puts "GC2 [connect_global_net VSS -type pg_pin -pin_base_name VSS -inst_base_name *]"
report_global_net_connections
# ---- rings, stripes, rails, block pins, vias
puts "RING [addRing -nets {VDD VSS} -type core_rings -around core -layer {top M5 bottom M5 left M6 right M6} -width 3 -spacing 1.5 -offset 1.5]"
puts "BRING [add_rings -nets {VDD VSS} -type block_rings -around each_block -layer {top M5 bottom M5 left M6 right M6} -width 1.0 -spacing 0.5 -offset 0.4]"
puts "STR6 [addStripe -nets {VDD VSS} -layer M6 -direction vertical -width 2 -spacing 1 -set_to_set_distance 40 -extend_to first_ring]"
puts "STR5 [add_stripes -nets {VDD VSS} -layer M5 -direction horizontal -width 2 -spacing 1 -set_to_set_distance 48 -extend_to first_ring]"
puts "FPIN [sroute -connect {core_pin} -nets {VDD VSS} -layer M1 -width 0.24]"
puts "BPIN [sroute -connect {block_pin} -nets {VDD VSS}]"
puts "MV0 [check_missing_vias]"
puts "VIA [generate_vias]"
puts "MV1 [check_missing_vias]"
report_power_routes
# ---- route rules
create_route_rule -preset 1w1s
create_route_rule -preset 1w2s
create_route_rule -preset 2w1s
create_route_rule -name NDR_2W2S -width_multiplier 2 -spacing_multiplier 2
set_route_attributes -clock_nets -route_rule NDR_2W2S
report_route_rules
# ---- place, route, verify
place_opt
route_auto
puts "LVS0 [check_lvs]"
puts "DRC0 [check_drc]"
file mkdir out
write_def out/pg.def
# ---- inject errors: a VDD shape over a VSS stripe, a deleted via, a cut rail
add_special_wire -net VDD -layer M6 -rect {30 150 50 152}
editPowerVia -delete_vias 1 -nets VSS -area {0 0 340 40}
delete_special_wire -net VDD -layer M1 -area {150 100 152 140}
puts "MV2 [check_missing_vias]"
puts "DRC1 [check_drc]"
puts "LVS1 [check_lvs -shorts -connectivity]"
report_markers -limit 12
write_markers -format calibre -output out/pg_markers.rdb
write_markers -format text -output out/pg_markers.txt
puts "RM [read_markers -tool calibre out/pg_markers.rdb]"
gui_write_state out/pg.json
if {[catch {gui_write_image out/pg.png -width 1400 -height 1150} m]} { puts "image: $m" }
if {[catch {gui_write_image out/pg_zoom.png -rect {60 40 120 90} -width 1400 -height 1150 -show {rows}} m]} { puts "image: $m" }
# ---- fix: remove the bad shape, restore the vias, re-verify
delete_special_wire -net VDD -layer M6 -area {30 150 50 152}
puts "VIA2 [generate_vias -nets VSS]"
puts "MV3 [check_missing_vias]"
puts "DRC2 [check_drc]"
puts "LVS2 [check_lvs]"
# ---- schematic signal tracing (the GUI's pin double-click)
set ff [lindex [all_registers] 0]
gui_show_schematic -cells $ff -depth 0
puts "TR1 [gui_trace_schematic -pin $ff/Q -levels 2]"
puts "TR2 [gui_trace_schematic -pin $ff/D -to_endpoint]"
puts "TR3 [gui_trace_schematic -pin rst_n -levels 1]"
gui_write_state out/pg_trace.json
