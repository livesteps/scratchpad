# ---------------------------------------------------------------------------
# Advanced floorplan / route edits on a routed block: wire cut, delete, add,
# via add / delete / swap (multi-cut via resistance in extraction), re-route.
# ---------------------------------------------------------------------------
source common.tcl
analyze -format sverilog rtl/chip_ctrl.sv
elaborate chip_ctrl
create_clock -name clk -period 1.0 [get_ports clk]
compile_fusion -to logic_opto
initialize_floorplan -core_utilization 0.45 -aspect_ratio 1.0 -core2die_spacing 3 -no_pins
place_io_pins -auto_group_bus -direction {left right} -track_pitch 4
place_io_pins -ports {clk rst_n en mode*} -direction {top} -layer M4
place_opt
route_auto
check_routes
report_timing -max_paths 1

# ---- pick the first straight run of a net
set net {dout[0]}
set segs [get_route_segments -net $net]
puts "route segments of $net: $segs"
set s  [lindex $segs 0]
set ly [lindex $s 0]
set x0 [lindex $s 1] ; set y0 [lindex $s 2] ; set x1 [lindex $s 3] ; set y1 [lindex $s 4]
set mx [expr ($x0 + $x1) / 2.0] ; set my [expr ($y0 + $y1) / 2.0]

cut_wire -net $net -at [list $mx $my] -layer $ly
check_routes
add_wire -net $net -layer $ly -points [list $x0 $y0 $x1 $y1]
check_routes
add_via    -net $net -at [list $x0 $y0] -from $ly -to M5 -type VIA34_2CUT
delete_via -net $net -at [list $x0 $y0] -from $ly -to M5
delete_wire -net $net -layer $ly -area [list $x0 $y0 $x1 $y1]
check_routes
route_eco
check_routes

# ---- via swap: double-cut vias on every net (resistance halves in extraction)
swap_via -to_type VIA12_2CUT
swap_via -to_type VIA23_2CUT -nets {dout*}
report_route_edits
report_net_parasitics -nets $net
report_timing -max_paths 1
file mkdir out
write_def out/route_edit.def
