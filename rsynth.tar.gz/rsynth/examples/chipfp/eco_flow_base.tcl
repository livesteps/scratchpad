# shared implementation of the ECO examples (identical in eco_prep / eco_premask /
# eco_postmask): RTL -> floorplan -> spare cells pre-placed -> place_opt -> route
analyze -format sverilog rtl/chip_ctrl.sv
elaborate chip_ctrl -keep_reference
create_clock -name clk -period 1.0 [get_ports clk]
compile_fusion -to logic_opto
initialize_floorplan -core_utilization 0.40 -core2die_spacing 3 -no_pins
place_io_pins -auto_group_bus -direction {left right} -track_pitch 4
place_io_pins -ports {clk rst_n en mode*} -direction {top} -layer M4
# spare gates: inputs tied low, outputs open, grouped in spare_* hierarchy, fixed before place_opt
insert_spare_cells -cells {INV_X1_SVT 1 NAND2_X1_SVT 2 NOR2_X1_SVT 1 DFF_X1_SVT 1} -groups_per_module 4 -tie_cell TIELO_X1_SVT
place_opt
route_auto
