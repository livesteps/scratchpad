# ---------------------------------------------------------------------------
# Flip-chip area-IO chip: bump array on the AP layer, area-IO pads, supply /
# signal bump assignment, assignment re-optimization, RDL routing with and
# without 45-degree segments, bump dumps in DEF / GDS / text and DEF read-back.
# ---------------------------------------------------------------------------
source common.tcl
analyze -format sverilog rtl/chip_ctrl.sv
elaborate chip_ctrl
create_clock -name clk -period 2.0 [get_ports clk]
compile_fusion -to logic_opto

initialize_floorplan -die_width 800 -die_height 800 -core2die_spacing 40 -no_pins
create_seal_ring -width 5 -layers {M1 M2 M3 M4 M5 M6 AP} -chamfer 15

# ---- bumps: 60 um bumps on a 100 um pitch (full array), staggered alternative
create_bump_array -cell BUMP60 -pitch 100 -layer AP -pattern staggered -prefix sbump
report_bumps
# perimeter-only trial (overlap warning against the staggered one), then the full array
create_bump_array -cell BUMP40 -pitch 100 -layer AP -pattern perimeter -rings 2 -prefix pbump
delete_bumps {sbump_* pbump_*}
create_bump_array -cell BUMP60 -pitch 100 -layer AP -pattern full -prefix bump

# ---- area-IO pads next to the core logic
create_area_io -input_cell AIO_IN -output_cell AIO_OUT -ports {*} -inset 20
place_opt

# ---- supply + signal bumps; the outer rings carry signals (with interleaved supply bumps)
assign_bumps -power_nets {VDD} -ground_nets {VSS} -supply_pattern checker -pad_cells {aio_*}
report_bumps
optimize_bump_assignment -iterations 8
report_bumps

# ---- RDL: orthogonal first, then 45-degree
route_rdl -layer AP -width 6 -spacing 6
route_rdl -layer AP -width 6 -spacing 6 -allow_45
report_bumps

file mkdir out
write_bumps -format text out/flipchip_bumps.txt
write_bumps -format def  out/flipchip_bumps.def
write_bumps -format gds  out/flipchip_bumps.gds
write_def out/flipchip_chip.def
export_gds -gds_map_file ../gds/rs28.map -output out/flipchip_chip.gds -no_routing
read_def out/flipchip_chip.def
