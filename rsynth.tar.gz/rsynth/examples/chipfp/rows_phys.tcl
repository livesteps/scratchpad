# Core rows (cut / create / delete), routing tracks, physical-only cells (end caps, well taps,
# decaps, fillers) and un-placement on the macro floorplan
source common.tcl
read_lib -corner tt ../lib/rs28_phys.lib
read_lef ../lib/rs28_phys.lef
analyze -format sverilog rtl/mem_sys.sv
elaborate mem_sys
create_clock -name clk -period 2.0 [get_ports clk]
compile_fusion -to logic_opto
initialize_floorplan -die_width 324 -die_height 264 -core_width 300 -core_height 240 -no_pins
place_io_pins -ports * -direction {left right} -layer M3
place_macros -group_by module -spacing 4 -halo 3
snap_macros_to_grid -grid {0.2 1.6}
# ---- rows
report_rows
puts "CUT [cut_row -halo 2]"
puts "CUTA [cut_row -area {12 12 40 30}]"
puts "CR [create_row -site coreSite -area {12 12 40 20} -flip1st]"
puts "DEL [delete_row -area {12 230 312 252}]"
report_rows
# ---- tracks
add_tracks
create_track -layer M2 -dir X -start 12.1 -step 0.2
create_track -layer {M5 M6} -step 0.8
report_tracks
# ---- physical-only cells, placement inside the rows only
puts "ENDCAP [add_endcaps -pre_cap ENDCAP -post_cap ENDCAPR]"
puts "TAP [add_well_taps -cell TAPCELL -cell_interval 25 -checkerboard]"
place_opt
check_legality
puts "DECAP [add_decaps -cells {DECAP16 DECAP8 DECAP4} -count 40]"
puts "FILL [addFiller -cell {FILL16 FILL8 FILL4 FILL2 FILL1} -prefix FILL]"
report_physical_cells
check_legality
file mkdir out
write_def out/rows_phys.def
gui_write_state out/rows_phys.json
if {[catch {gui_write_image out/rows_phys.png -rect {8 8 48 36} -width 1400 -height 1000 -show {rows tracks} -hide {labels}} m]} { puts "layout image: $m" }
if {[catch {gui_write_image out/rows_phys_full.png -width 1400 -height 1100 -show rows} m]} { puts "layout image: $m" }
# ---- removal / un-placement
puts "DELI [delete_instance -inst *FILL*]"
puts "DELD [deleteDeCap]"
puts "UNP1 [unplace -inst {u_bank0/*}]"
puts "UNP2 [unplace -all_std_cells]"
puts "UNP3 [unplace -macros]"
puts "UNP4 [unplace -macros -override_fixed]"
puts "UNP5 [unplace -physical_cells -override_fixed]"
report_physical_cells
# ---- the DEF keeps the edited rows and tracks
read_def out/rows_phys.def
report_rows
