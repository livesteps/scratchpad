# ---------------------------------------------------------------------------
# Wire-bond chip: command-based floorplan, seal ring, pad ring from a
# pad_ring_order_config_file (corners, IO fillers, breakers, clamps, inline and
# staggered bond pads), ESD / IO-ring checks, manual pad edits, DEF + GDS.
# ---------------------------------------------------------------------------
source common.tcl
analyze -format sverilog rtl/chip_ctrl.sv
elaborate chip_ctrl
create_clock -name clk -period 2.0 [get_ports clk]
compile_fusion -to logic_opto

# die 700 x 700, core 130 um inside the die on every side
initialize_floorplan -die_width 700 -die_height 700 -core2die_spacing 130 -row_height 1.6 -no_pins
create_seal_ring -width 4 -height 4 -layers {M1 M2 M3 M4 M5 M6} -offset 0 -chamfer 12

# ---- inline bond pads
create_pad_ring -pad_ring_order_config_file pads_inline.cfg
report_pad_ring
check_esd -max_clamp_distance 400 -max_signals_per_supply 4
check_bond_pads -min_pitch 40

# ---- manual pad edit: swap two signal pads, then re-check
move_objects -objects {io_din4} -delta {41 0}
move_objects -objects {io_din5} -delta {-41 0}
check_esd

# ---- staggered bond pads on abutted pads (30 um pad pitch, 60 um per row)
create_pad_ring -pad_ring_order_config_file pads_staggered.cfg
check_bond_pads -min_pitch 50 -min_row_pitch 25
check_bond_pads -min_pitch 50
check_esd

place_opt
check_legality
file mkdir out
write_def out/wirebond_chip.def
export_gds -gds_map_file ../gds/rs28.map -output out/wirebond_chip.gds -no_routing
# DEF read-back: seal ring special wiring survives
read_def out/wirebond_chip.def
report_floorplan

# ---- ESD negative: missing breakers / clamp / IO ground
create_pad_ring -pad_ring_order_config_file pads_bad_esd.cfg -no_insert
check_esd
