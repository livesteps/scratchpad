# ---------------------------------------------------------------------------
# Post-mask (metal-only) ECO: spare cells per module pre-placed before place_opt,
# gate-array base fillers after placement, frozen base, netlist diff, remap of
# the ECO cells onto spares / gate-array cells, metal-only re-route, mask check
# and functional verification against the ECO target.
# ---------------------------------------------------------------------------
source common.tcl
# the ECO target netlist is the verification reference
read_verilog out/chip_eco_v2.v
elaborate chip_ctrl
source eco_flow_base.tcl
report_spare_cells
check_legality
# gate-array base cells in the remaining row space
insert_gate_array_fillers -cells {GFILL4 GFILL2 GFILL1}
check_routes
file mkdir out
write_def out/eco_base.def

# ---- tape-out: freeze the base layers
set_eco_mode -post_mask true -metal_layers {M1 M2 M3 M4 M5 M6}
eco_netlist -by_verilog_file out/chip_eco_v2.v -apply
# spares first (an inverter may use a NAND2 spare with tied inputs), then gate-array cells
eco_remap_post_mask -use spare -allow_function_mapping
eco_remap_post_mask -use gate_array
report_spare_cells
route_eco
check_routes
check_eco_mask
# the same changes with M1 frozen: shows which masks would have to be re-spun
check_eco_mask -metal_layers {M2 M3 M4 M5 M6}
verify_equivalence -cycles 400 -resets {rst_n}
write_def out/eco_postmask.def
