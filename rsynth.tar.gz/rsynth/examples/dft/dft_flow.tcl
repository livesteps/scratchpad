# Advanced DFT reference flow on mem_sys (4 SRAM macros + logic):
# scan insertion, OCC, compression, boundary scan, MBIST, lockups, test-mode SDC,
# sanity checks, ATPG (stuck-at + at-speed transition), STIL / Verilog test benches.
read_lib -corner tt ../lib/rs28_tt_0p80v_25c.lib
read_lef ../lib/rs28_macros.lef
set_app_options -name hdlin.elaborate.empty_module_as_blackbox -value true
analyze -format sverilog ../chipfp/rtl/mem_sys.sv
elaborate mem_sys
link_block
create_clock -name clk -period 2.0 [get_ports clk]
compile_fusion -to logic_opto
file mkdir out
set_dft_signal -type ScanEnable -port test_se -active_state 1
set_scan_configuration -chain_count 8
create_test_protocol
insert_dft
insert_occ -clocks clk -pulses 2
insert_scan_compression -channels 2
insert_boundary_scan -idcode 0x1A5B0001
insert_mbist -memories * -algorithm march_c- -control pins
insert_lockup_latches
report_dft
check_dft
# functional mode (test_mode = 0, TAP in reset, BIST off) must equal the RTL
verify_equivalence -cycles 2000 -resets {rst_n} -constants {test_mode 0 test_se 0 test_clk 0 test_atspeed 0 test_ci0 0 test_ci1 0 test_edt_clear 0 test_comp_en 0 tck 0 tms 1 tdi 0 trst_n 0 mbist_en 0 mbist_start 0 mbist_rst_n 0}
write_bsdl out/mem_sys.bsdl
create_test_mode_scenarios -directory out
write_test_mode_sdc -mode shift -output out/test_shift.sdc
write_test_mode_sdc -mode atspeed -output out/test_atspeed.sdc
write_verilog out/mem_sys_dft.v
write_simulation_models out/models.v
create_test_patterns -fault_model stuck_at
report_atpg
write_test_patterns -format stil -output out/sa.stil
write_test_patterns -format stil_flat -output out/sa_flat.stil
write_test_patterns -format verilog -output out/tb_sa.v
create_test_patterns -fault_model transition -capture atspeed
report_atpg
write_test_patterns -format verilog -output out/tb_tr.v
write_test_patterns -format stil -output out/tr.stil
write_mbist_testbench out/tb_mbist.v
write_bscan_testbench out/tb_bscan.v
