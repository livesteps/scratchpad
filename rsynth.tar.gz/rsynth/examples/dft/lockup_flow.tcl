# Two clock domains on one mixed-clock chain: lockup latch insertion, restitch, ATPG
file mkdir out
read_lib -corner tt ../lib/rs28_tt_0p80v_25c.lib
analyze -format sverilog two_clock.sv
elaborate t
link_block
create_clock -name ca -period 2 [get_ports clka]
create_clock -name cb -period 3 [get_ports clkb]
compile_fusion -to logic_opto
set_dft_signal -type ScanEnable -port test_se -active_state 1
set_scan_configuration -chain_count 1 -clock_mixing mix_clocks
create_test_protocol
insert_dft
restitch_scan_chains -chain_count 1
insert_lockup_latches
check_dft
write_verilog out/two_clock_dft.v
write_simulation_models out/two_clock_models.v
create_test_patterns
write_test_patterns -format verilog -output out/tb_two_clock.v
