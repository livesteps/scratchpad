module t(input clka, clkb, rst_n, input [3:0] a, output reg [3:0] y);
  reg [3:0] r;
  always @(posedge clka or negedge rst_n) if (!rst_n) r <= 0; else r <= a + r;
  always @(posedge clkb or negedge rst_n) if (!rst_n) y <= 0; else y <= r ^ y;
endmodule
