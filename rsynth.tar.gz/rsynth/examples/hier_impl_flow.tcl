# Hierarchical implementation: partition + budget (part_flow.tcl), implement every block on its
# own (place / CTS / route / route_opt, block ETM + LEF abstract + ILM), then time the top level
# on the block ETMs and compare with flat timing of the assembled implemented blocks
source part_flow.tcl
puts "=== HIER IMPL"
implement_partitions -input_dir out/parts -output_dir out/impl -jobs 4 -transitions {0.01 0.03 0.06 0.1 0.15 0.22 0.32} -loads {0.001 0.004 0.01 0.02 0.035 0.06}
report_hierarchical_implementation
puts "=== HIER VERIFY"
verify_block_abstracts -tolerance 0.015 -hold_tolerance 0.010
# negative check: a hold-scenario ETM with max (setup) delays must be caught
puts "=== HIER NEGATIVE"
file copy -force out/impl/u_core_u_arb_func_ss.lib out/impl/u_core_u_arb_func_ff.lib
verify_block_abstracts -tolerance 0.015 -hold_tolerance 0.010 -max_report 3
