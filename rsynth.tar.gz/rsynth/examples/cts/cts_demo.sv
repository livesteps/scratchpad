// CTS demo: two clocks, enable-gated register banks (clock gating), a divide-by-2 clock and a
// black-box macro clock pin
module ram_bb (input CLK, input [7:0] D, output [7:0] Q);
endmodule
module cts_demo (input clk_a, input clk_b, input rst_n, input en0, input en1, input [7:0] din, output [7:0] q0, output [7:0] q1, output [7:0] q2, output [7:0] qm);
  reg [7:0] r0, r1, r2, r3;
  reg div2;
  always @(posedge clk_a or negedge rst_n) if (!rst_n) r0 <= 0; else if (en0) r0 <= din;
  always @(posedge clk_a or negedge rst_n) if (!rst_n) r1 <= 0; else if (en1) r1 <= r0 ^ din;
  always @(posedge clk_a or negedge rst_n) if (!rst_n) div2 <= 0; else div2 <= ~div2;
  always @(posedge div2 or negedge rst_n) if (!rst_n) r2 <= 0; else r2 <= r1 + 8'd1;
  always @(posedge clk_b or negedge rst_n) if (!rst_n) r3 <= 0; else r3 <= r3 + din;
  ram_bb u_ram (.CLK(clk_a), .D(r0), .Q(qm));
  assign q0 = r1;
  assign q1 = r2;
  assign q2 = r3;
endmodule
