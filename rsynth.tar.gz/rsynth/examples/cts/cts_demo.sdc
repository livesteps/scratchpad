create_clock -name clk_a -period 1.0 [get_ports clk_a]
create_clock -name clk_b -period 1.5 [get_ports clk_b]
create_generated_clock -name clk_div -source [get_ports clk_a] -divide_by 2 [get_pins div2_reg/Q]
set_clock_groups -asynchronous -group {clk_a clk_div} -group {clk_b}
set_input_delay 0.1 -clock clk_a [get_ports {din en0 en1}]
set_output_delay 0.1 -clock clk_a [get_ports {q0 q1 qm}]
set_output_delay 0.1 -clock clk_b [get_ports q2]
