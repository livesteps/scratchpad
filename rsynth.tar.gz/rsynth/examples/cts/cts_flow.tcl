# ---------------------------------------------------------------------------
# Clock tree specification (clocktree.cfg), clock tree tracing and clock_opt honouring it;
# update_timing after SDC / MMMC / derate edits; clock tree browser data
# ---------------------------------------------------------------------------
create_mode func ; create_corner ss ; create_corner ff
read_lib -corner ss ../lib/rs28_ss_0p72v_125c.lib
read_lib -corner ff ../lib/rs28_ff_0p88v_m40c.lib
create_scenario -name func_ss -mode func -corner ss
create_scenario -name func_ff -mode func -corner ff
set_scenario_status func_ss -hold false
set_scenario_status func_ff -setup false -hold true
analyze -format sverilog cts_demo.sv
elaborate cts_demo
current_mode func ; read_sdc cts_demo.sdc
insert_clock_gating
compile_fusion -to logic_opto
report_clock_gating
initialize_floorplan -core_utilization 0.5 -core2die_spacing 5
place_pins -self
place_opt

# ---- clock tree tracing before CTS
file mkdir out
puts "TR0 [trace_clock_tree -file out/trace0.rpt]"
# ---- pre-configuration: dump, edit, read back
file mkdir out
write_clock_tree_spec -file out/clocktree.cfg
set f [open out/clocktree.cfg a]
puts $f {clock_latency          clk_b 0.60}
puts $f {ignore_pins            {r3_reg[0]/CK}}
puts $f {float_pins             {u_ram/CLK 0.080}}
close $f
puts "CO [catch {clock_opt -spec out/clocktree.cfg -trace -from build_clock -to route_clock} m] $m"
report_clock_tree_spec
report_clock_qor -type summary
puts "TR1 [trace_clock_tree -clocks clk_a]"

# ---- timing update after SDC / MMMC / derate edits (Innovus style)
puts "UT0 [update_timing]"
puts "UT1 [update_timing]"
set_clock_uncertainty -setup 0.05 [get_clocks clk_a]
set_timing_derate -late 1.06 -cell_delay -corners ss
puts "ST [report_timing_update_status]"
puts "UT2 [update_timing]"
puts "UTF [update_timing -full]"
update_delay_corner -name ss -late_cell_derate 1.10
set_analysis_view -setup {func_ss} -hold {func_ff}
puts "UT3 [update_timing]"
update_constraint_mode -name func -sdc_files cts_demo.sdc
puts "UT4 [update_timing]"
report_timing -max_paths 1
gui_write_state out/cts_state.json

# ---- free the design and load it again in the same session
free_design
puts "FD [catch {get_cells *}]"
create_mode func ; create_corner ss
read_lib -corner ss ../lib/rs28_ss_0p72v_125c.lib
create_scenario -name func_ss -mode func -corner ss
analyze -format sverilog cts_demo.sv
elaborate cts_demo
current_mode func ; read_sdc cts_demo.sdc
compile_fusion -to logic_opto
puts "RELOAD [sizeof_collection [get_cells *]]"
puts "UT5 [update_timing]"
