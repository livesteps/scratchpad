# ---------------------------------------------------------------------------
# Integrated place -> CTS -> route -> route_opt (non-SI) flow with timing
# margins: clock uncertainty, flat OCV (clock/data), AOCV, POCV/SOCV and CRPR.
# ---------------------------------------------------------------------------
source fp_flow_setup.tcl

# ---- timing margins -------------------------------------------------------
# uncertainty (setup/hold) on top of the SDC values
set_clock_uncertainty -setup 0.05 [all_clocks]
set_clock_uncertainty -hold  0.02 [all_clocks]
# flat OCV: separate clock-network and data-path derates on both corners
set_timing_derate -late  1.05 -clock -corners {ss ff}
set_timing_derate -early 0.95 -clock -corners {ss ff}
set_timing_derate -late  1.03 -data  -corners {ss ff}
set_timing_derate -early 0.97 -data  -corners {ss ff}
set_app_options -name time.remove_clock_reconvergence_pessimism -value true
report_timing_derate

# ---- placement ------------------------------------------------------------
place_opt
legalize_placement
check_legality
report_placement

# ---- clock tree synthesis -------------------------------------------------
set_clock_tree_options -target_skew 0.05 -max_fanout 16
set_lib_cell_purpose -include cts [get_lib_cells {*/BUF_X4_SVT */BUF_X8_SVT}]
clock_opt -from build_clock -to route_clock
report_clock_qor
clock_opt -from final_opto -to final_opto
report_clock_timing -type skew
# global clock-tree analysis: summary, per-level table, structure, latency paths, histogram, DRC
report_clock_qor -type level
report_clock_qor -type structure -max_level 2
report_clock_qor -type latency -nworst 2 -verbose
report_clock_qor -type histogram
report_clock_qor -type drc_violators
file mkdir out
write_clock_tree -output out/clock_tree.json
verify_equivalence -cycles 1500 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1}

# ---- detailed routing -----------------------------------------------------
route_auto
check_routes
report_routing
report_timing -delay_type max -max_paths 1
report_timing -delay_type min -max_paths 1

# ---- route-based optimization (non-SI) ------------------------------------
route_opt -iterations 2
check_routes
check_legality
report_qor

# ---- AOCV: depth/distance-based derates replace the flat cell derates ------
read_ocvm ocv/rs28.aocvm
report_ocvm
report_qor -summary
remove_ocvm

# ---- POCV/SOCV: per-cell sigma, 3-sigma merge ------------------------------
read_ocvm ocv/rs28.pocvm
set_app_options -name time.pocvm_corner_sigma -value 3
report_timing -delay_type max -max_paths 1
report_qor -summary
remove_ocvm

verify_equivalence -cycles 1500 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1}

file mkdir out
write_def out/soc_top.routed.def
write_parasitics -output out/soc_top.routed
write_verilog out/soc_top.routed.v
