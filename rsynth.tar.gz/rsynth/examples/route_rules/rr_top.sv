// route_rules example: 4-lane multiply-accumulate with a long broadcast bus, constant ID
// outputs (tie cells) and IO ports far apart (long nets for net-length buffering)
module rr_lane #(parameter W = 8) (
  input  logic         clk, rst_n, en,
  input  logic [W-1:0] a, b,
  output logic [2*W-1:0] acc
);
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) acc <= '0;
    else if (en) acc <= acc + a * b;
endmodule

module rr_top (
  input  logic        clk, rst_n, en,
  input  logic [7:0]  a0, a1, a2, a3, bcast,
  output logic [15:0] y0, y1, y2, y3,
  output logic [7:0]  rev_id,
  output logic        ready
);
  rr_lane u0 (.clk, .rst_n, .en, .a(a0), .b(bcast), .acc(y0));
  rr_lane u1 (.clk, .rst_n, .en, .a(a1), .b(bcast), .acc(y1));
  rr_lane u2 (.clk, .rst_n, .en, .a(a2), .b(bcast), .acc(y2));
  rr_lane u3 (.clk, .rst_n, .en, .a(a3), .b(bcast), .acc(y3));
  assign rev_id = 8'hA5;
  assign ready  = 1'b1;
endmodule

// small variant for quick runs / regression tests
module rr_small (
  input  logic        clk, rst_n, en,
  input  logic [3:0]  a0, a1, bcast,
  output logic [7:0]  y0, y1,
  output logic [3:0]  rev_id,
  output logic        ready
);
  rr_lane #(.W(4)) u0 (.clk, .rst_n, .en, .a(a0), .b(bcast), .acc(y0));
  rr_lane #(.W(4)) u1 (.clk, .rst_n, .en, .a(a1), .b(bcast), .acc(y1));
  assign rev_id = 4'h9;
  assign ready  = 1'b1;
endmodule
