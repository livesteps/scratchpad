# ---------------------------------------------------------------------------
# LEF-rule driven routing, OPC / metal fill, antenna, net-length buffering and
# route_opt -yield (wire spreading, then multi-cut vias) — RSynth 0.12.0
#   rsynth -f route_rules_flow.tcl   (OPC rules: route_auto / route_opt -opc opc_fill.rules)
# ---------------------------------------------------------------------------
create_mode func ; create_corner ss ; create_corner ff
read_lib -corner ss ../lib/rs28_ss_0p72v_125c.lib
read_lib -corner ff ../lib/rs28_ff_0p88v_m40c.lib
create_scenario -name func_ss -mode func -corner ss
create_scenario -name func_ff -mode func -corner ff
set_scenario_status func_ss -hold false
set_scenario_status func_ff -setup false -hold true
# routing rules: tracks, width, spacing table, AREA, RC, density / fill, antenna
read_lef rs28_rules_tech.lef
analyze -format sverilog rr_top.sv
elaborate rr_top
current_mode func ; read_sdc rr.sdc
compile_fusion -to logic_opto
file mkdir out

initialize_floorplan -core_utilization 0.35 -core2die_spacing 4
place_pins -self
add_rings -nets {VDD VSS} -layer {top M5 bottom M5 left M6 right M6} -width 0.8 -spacing 0.4 -offset 0.6
add_stripes -nets {VDD VSS} -layer M4 -direction vertical -width 0.4 -spacing 0.4 -set_to_set_distance 12 -start_offset 4
report_layer_rules

# ---- tie cells: at most 3 loads per tie, loads within 20um
puts "TIE [add_tie_hi_lo -cell {TIEHI_X1_SVT TIELO_X1_SVT} -max_fanout 3 -max_distance 20]"

# ---- placement: timing driven, high effort, congestion effort, PG stripes as blockages
place_opt -timing_driven -effort high -congestion_effort medium -preroute_as_blockages {M4}
place_detail -timing_driven -effort medium
# ---- antenna diodes under the input ports
puts "PD [add_port_diodes -cell ANTENNA_X1_SVT -direction input]"
check_legality

# ---- global / detailed routing with layer range, effort, timing and antenna options
route_global -min_layer M2 -max_layer M6 -effort_level medium
report_congestion
route_auto -timing_driven -effort_level medium -min_layer M2 -max_layer M6 -layer_jogs -antenna_diode ANTENNA_X1_SVT -max_buffering_distance 60 -opc opc_fill.rules
check_routes
puts "RULES [check_route_rules]"
puts "ANT [check_antenna]"
report_net_length -max 60 -top 5

# ---- route_opt: net-length buffering + yield (1 wire spreading, 2 multi-cut vias)
route_opt -max_net_length 50 -yield -opc opc_fill.rules
check_routes
puts "RULES2 [check_route_rules]"
puts "LITHO [check_litho]"

# ---- OPC metal fill to the LEF / OPC density targets
puts "FILL [add_metal_fill]"
puts "DENS [report_metal_density]"
puts "RULES3 [check_route_rules]"
route_eco -effort_level low
puts "TRIM [check_route_rules]"
report_qor -summary
write_def out/route_rules.def
write_gds out/route_rules.gds
