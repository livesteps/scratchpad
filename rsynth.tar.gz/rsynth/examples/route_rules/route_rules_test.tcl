# regression checks for the routing features (run: rsynth -f route_rules_test.tcl)
source route_rules_small.tcl
puts "OPC [report_opc_rules]"
puts "LR [report_layer_rules]"
puts "NL [report_net_length -max 20]"
# repeaters: -buff_cell / -inv_cell (pairs), -lib_cell replaced, delete_repeater -inv_pairs
puts "LIBCELL [catch {add_repeater -lib_cell BUF_X2_SVT -net {a1[2]}} m] $m"
puts "BOTH [catch {add_repeater -buff_cell BUF_X2_SVT -inv_cell INV_X1_SVT -net {a1[2]}} m]"
puts "NOTBUF [catch {add_repeater -buff_cell INV_X1_SVT -net {a1[2]}} m]"
puts "BUF [llength [add_repeater -buff_cell BUF_X2_SVT -net {a1[2]} -name rbuf]]"
puts "INV [llength [add_repeater -inv_cell INV_X1_SVT -net {a1[3]} -stage_count 1 -name rinv]]"
puts "DELINV [delete_repeater -inv_pairs -net {a1[3]}]"
# DEF fill section round trip
write_def out/rr_small_fill.def
set f [open out/rr_small_fill.def] ; set d [read $f] ; close $f
puts "DEFFILL [string first "FILLS " $d] [string first "END FILLS" $d]"
puts "DELFILL [delete_metal_fill -layers M6]"
puts "DENS2 [report_metal_density -layers {M2 M3}]"
puts "TIE2 [add_tie_low -cell TIELO_X1_SVT -max_fanout 1]"
