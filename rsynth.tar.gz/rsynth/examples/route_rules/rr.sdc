create_clock -name clk -period 2.5 [get_ports clk]
set_input_delay 0.2 -clock clk [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay 0.2 -clock clk [all_outputs]
set_load 0.004 [all_outputs]
