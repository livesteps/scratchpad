library ieee; use ieee.std_logic_1164.all;
entity pv is port (a, b : in std_logic; y : out std_logic); end entity;
architecture rtl of pv is
begin
  y <= a and b;
  -- synopsys translate_off
  this is not VHDL at all and must be skipped
  -- synopsys translate_on
end architecture;
