read_lib ../lib/rs28_tt_0p80v_25c.lib
analyze -format sverilog prag_nopragma_src.v
elaborate prag_nopragma
