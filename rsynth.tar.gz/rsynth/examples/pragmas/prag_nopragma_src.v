// Synopsys-style synthesis pragmas
module prag_nopragma (input clk, input rst_n, input [1:0] sel, input [3:0] d, input [2:0] oh,
             output reg y, output reg z, output reg [1:0] w, output q);
  wire mid;                       // synopsys keep_signal_name "mid"
  assign mid = d[0] ^ d[3];

  // incomplete case: without full_case a latch would be inferred for y
  always @(*) begin
    case (sel) 
      2'b00: y = d[0];
      2'b01: y = d[1];
      2'b10: y = d[2];
    endcase
  end

  // one-hot select, parallel_case (RTL priority is kept)
  always @(*) begin
    z = 1'b0;
    case (1'b1) 
      oh[0]: z = d[0];
      oh[1]: z = d[1];
      oh[2]: z = mid;
    endcase
  end

  // SystemVerilog style keywords work as well
  always @(*) begin
    unique case (sel)
      2'd0: w = 2'd1;
      2'd1: w = 2'd2;
      2'd2: w = 2'd3;
      2'd3: w = 2'd0;
    endcase
  end

  reg r;
  always @(posedge clk or negedge rst_n)   // synopsys async_set_reset "rst_n"
    if (!rst_n) r <= 1'b0; else r <= mid;
  assign q = r;

  // synopsys translate_off
  initial begin
    $display("simulation only");
    this_module_does_not_exist u_sim_only (.a(clk));
  end
  // synopsys translate_on

  /* synopsys dc_tcl_script_begin
  */
  // set_max_fanout 6 [current_design]
  // puts "DC_TCL_RAN ports=[sizeof_collection [get_ports *]]"
  /* synopsys dc_tcl_script_end */

  // pragma translate_off
  always @(posedge clk) $display("also simulation only %b", y);
  // pragma translate_on
endmodule
