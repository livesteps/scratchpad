read_lib ../lib/rs28_tt_0p80v_25c.lib
analyze -format sverilog prag.v
analyze -format vhdl prag_vhd.vhd
elaborate prag
puts "=== PRAGMAS"
report_pragmas
puts "LATCHES [sizeof_collection [get_cells -hier * -filter {ref_name =~ *LAT*} -quiet]]"
puts "KEEP [get_property [get_nets mid] is_dont_touch]"
puts "MAXFANOUT_SDC_OK"
compile_fusion
puts "LATCHES_MAPPED [sizeof_collection [get_cells -hier * -filter {ref_name =~ *LAT*} -quiet]]"
verify_equivalence -cycles 2000 -resets {rst_n}
elaborate pv
puts "PV_CELLS [sizeof_collection [get_cells -hier *]]"
