# Replay the ECO recorded by innovus_eco.tcl on the original netlist
source fp_flow_setup.tcl
source out/innovus_eco.tcl
report_qor -summary
verify_equivalence -cycles 2000 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1}
