# Re-assemble the written partitions (top + blocks) and verify against the RTL
read_lib lib/rs28_ss_0p72v_125c.lib
analyze -format sverilog {rtl/soc_pkg.sv rtl/bus_if.sv rtl/lane.sv rtl/arbiter.sv rtl/core.sv rtl/soc_top.sv}
analyze -format vhdl rtl/checksum.vhd
elaborate soc_top
analyze -format verilog {out/parts/lane0.v out/parts/lane1.v out/parts/u_core_u_csum.v out/parts/u_core_u_arb.v out/parts/soc_top.top.v}
elaborate soc_top -keep_reference
report_hierarchy
verify_equivalence -cycles 2000 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1}
