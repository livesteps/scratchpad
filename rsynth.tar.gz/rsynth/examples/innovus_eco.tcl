# ---------------------------------------------------------------------------
# Innovus / Tempus-style ECO automation: get_property / set_property, dbGet / dbSet,
# ecoChangeCell / ecoAddRepeater.  All changes are recorded by write_eco_changes.
# Replay on the original netlist: innovus_eco_replay.tcl
# ---------------------------------------------------------------------------
source fp_flow_setup.tcl
reset_eco_changes
report_qor -summary

# ---- 1. the classic loop: upsize every X1 instance on the worst paths -------------
#      (this library names cells <func>_X<n>_<vt>, so match *_X1_* instead of *X1)
proc upsize_x1_on_paths {collection} {
    set instNameList {}
    foreach_in_collection timing_point [get_property $collection timing_points] {
        set pin_name [get_property [get_property $timing_point pin] hierarchical_name]
        set inst_name [file dirname $pin_name]
        if {$inst_name eq "."} continue                       ;# top-level port
        if {[lsearch -exact $instNameList $inst_name] == -1} { lappend instNameList $inst_name }
    }
    set n 0
    foreach instName $instNameList {
        set inst [dbGetInstByName $instName]
        if {$inst eq "0x0" || [dbGet $inst.cell.isSequential]} continue
        if {[get_property $inst eco_touched] eq "true"} continue   ;# user property
        set cellName [dbGet $inst.cell.name]
        if {[string match *_X1_* $cellName]} {
            regsub {_X1_} $cellName {_X2_} newCellName
            if {[dbGetCellByName $newCellName] ne "0x0"} {
                ecoChangeCell -inst $instName -cell $newCellName
                set_property $inst eco_touched true
                incr n
            }
        }
    }
    return $n
}
define_property eco_touched -type boolean -default false
for {set i 1} {$i <= 3} {incr i} {
    set paths [report_timing -collection -max_paths 30 -nworst 1 -slack_lesser_than 0 -scenarios func_ss]
    if {![sizeof_collection $paths]} break
    set worst [get_property [index_collection $paths 0] slack]
    set n [upsize_x1_on_paths $paths]
    puts "pass $i: [sizeof_collection $paths] violating paths, worst $worst -> upsized $n instance(s)"
}

# ---- 2. Tempus path properties --------------------------------------------------
set p [report_timing -collection -scenarios func_ss]
puts "worst: slack [get_property $p slack]  [get_property [get_property $p launching_point] hierarchical_name] -> [get_property [get_property $p capturing_point] hierarchical_name]"
puts "       clock [get_object_name [get_property $p launching_clock]], view [get_property $p view_name], required [get_property $p required_time], points [sizeof_collection [get_property $p timing_points]]"

# ---- 3. dbGet queries -----------------------------------------------------------
puts "design [dbGet top.name]: [dbGet top.numInsts] insts"
set dlys [dbGet -p2 top.insts.cell.name DLY*]
puts "delay cells: [llength $dlys]"
set x1 [dbGet -u top.insts.cell.name *_X1_SVT]
puts "distinct X1 SVT masters: [llength $x1]"
set ff [dbGet -p top.insts.name *stage1_reg\[0\]]
puts "stage1_reg\[0\] instances: [llength $ff]; first master [dbGet [lindex $ff 0].cell.name]"

# ---- 4. repeater on the highest-fanout data net of the worst path ---------------
set best "" ; set bfo 0
foreach_in_collection pt [get_property $p timing_points] {
    set fo [get_property $pt fanout]
    if {$fo > $bfo && [get_property $pt net] ne ""} { set bfo $fo ; set best [get_object_name [get_property $pt net]] }
}
puts "highest fanout net on worst path: $best ($bfo)"
if {$bfo >= 4} { ecoAddRepeater -net $best -cell BUF_X4_SVT -name eco_rep }

# ---- 5. protect what we changed -------------------------------------------------
foreach inst [dbGet -p top.insts.name *eco_rep*] { dbSet $inst.dontTouch 1 }

report_qor -summary
file mkdir out
write_eco_changes out/innovus_eco.tcl
verify_equivalence -cycles 2000 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1}
