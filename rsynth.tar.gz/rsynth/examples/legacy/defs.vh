`define WIDTH 6
`define USE_PARITY
