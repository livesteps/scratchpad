// Verilog-2001 style design with lint issues on purpose
`include "defs.vh"
`timescale 1ns/1ps
module dly_cell (a, y);      // non-ANSI port list
  input a;
  output y;
  wire n1;
  not  g1 (n1, a);           // gate primitives
  not  g2 (y, n1);
endmodule

module cnt (clk, rst, en, q);
  parameter W = 4;
  input clk, rst, en;
  output [W-1:0] q;
  reg [W-1:0] q;
  always @(posedge clk)       // synchronous active-high reset
    if (rst) q <= {W{1'b0}};
    else if (en) q <= q + 1'b1;
endmodule

module dec (sel, y);
  input [2:0] sel;
  output reg [7:0] y;
  integer i;
  always @(*) begin
    y = 8'h00;
    casez (sel)
      3'b1??: y = 8'hF0;
      3'b01?: y = 8'h0C;
      default: for (i = 0; i < 2; i = i + 1) y[i] = sel[i];
    endcase
  end
endmodule

module legacy_top (clk, rst, en, a, b, sel, q0, q1, y, p, loop_out, md, unused_in, undriven_out, bb_q);
  input clk, rst, en;
  input [`WIDTH-1:0] a, b;
  input [2:0] sel;
  input unused_in;                     // unused input port
  output [3:0] q0, q1;
  output [7:0] y;
  output p, loop_out, md, undriven_out;
  output [3:0] bb_q;

  cnt #(.W(4)) u_c0 (.clk(clk), .rst(rst), .en(en), .q(q0));   // two identical instances
  cnt #(4)     u_c1 (.clk(clk), .rst(rst), .en(en), .q(q1));   // -> non-uniquified design
  dec u_dec (.sel(sel), .y(y));

  wire [`WIDTH-1:0] s = a + b;
  genvar g;
  generate
    if (`WIDTH > 4) begin : g_wide
      for (g = 0; g < 2; g = g + 1) begin : g_d
        wire t;
        dly_cell u_d (.a(s[g]), .y(t));
      end
    end
  endgenerate

`ifdef USE_PARITY
  assign p = ^s;
`else
  assign p = 1'b0;
`endif

  // combinational feedback loop
  wire l1, l2;
  assign l1 = ~(l2 & en);
  assign l2 = l1 ^ a[0];
  assign loop_out = l2;

  // multi-driven net
  assign md = a[1];
  assign md = b[1];

  // imported black box (stub read with read_verilog -blackbox)
  ip_core u_ip (.clk(clk), .d(s[3:0]), .q(bb_q));
endmodule
