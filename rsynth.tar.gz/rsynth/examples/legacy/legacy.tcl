read_lib ../lib/rs28_tt_0p80v_25c.lib
analyze -format verilog -search_path . legacy.v
read_verilog -blackbox ip_core_stub.v
analyze -format vhdl sel.vhd
elaborate legacy_top
check_design
uniquify
create_clock -period 0.6 [get_ports clk]
set_clock_uncertainty -hold 0.12 [get_clocks clk]
set_input_delay 0.05 -clock clk [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay 0.05 -clock clk [all_outputs]
check_timing -include {loops drivers io_delays unconstrained_endpoints}
cleanup_design -multidriven -loops
compile_fusion
report_timing -delay_type min -max_paths 1
report_reference
# ---- ECO
set c0 [lindex [get_cells -hier * -filter {ref_name =~ INV*}] 0]
size_cell $c0 INV_X4_LVT
insert_buffer [get_nets {s[0]}] BUF_X2_SVT
set qn [get_attribute [get_pins {u_c0/q_reg[0]/Q}] net_name]
set ld [remove_from_collection [get_pins -of_objects [get_nets $qn]] [get_pins {u_c0/q_reg[0]/Q}]]
clone_cell -cell {u_c0/q_reg[0]} -loads [lrange $ld 0 1]
split_fanout -net rst -max_fanout 2
fix_eco_timing -type {setup hold drc}
report_qor
verify_equivalence -cycles 2000 -constants {rst 0}
elaborate sel4 -parameters "N=4"
compile_fusion -to initial_map
verify_equivalence -cycles 500
write_verilog sel4.v
