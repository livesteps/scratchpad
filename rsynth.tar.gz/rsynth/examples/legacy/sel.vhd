library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity sel4 is
  generic (N : integer := 4);
  port (s : in std_logic_vector(1 downto 0);
        d : in std_logic_vector(N-1 downto 0);
        y : out std_logic;
        z : out std_logic_vector(N-1 downto 0));
end sel4;
architecture rtl of sel4 is
  type st_t is (A, B, C);
  signal st : st_t;
begin
  with s select y <= d(0) when "00", d(1) when "01", d(2) when "10", d(3) when others;
  gen: for i in 0 to N-1 generate
    z(i) <= not d(i);
  end generate;
end rtl;
