// Port-only model of a third-party IP: imported as black box
module ip_core (input clk, input [3:0] d, output [3:0] q);
  assign q = d;   // body ignored when read with -blackbox
endmodule
