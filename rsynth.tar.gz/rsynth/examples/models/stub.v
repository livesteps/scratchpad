// black-box stub of an IP: ports only
module pll_ip (input ref_clk, input rst_n, input [3:0] div, input en, output clk_out, output locked, output [1:0] status);
endmodule
