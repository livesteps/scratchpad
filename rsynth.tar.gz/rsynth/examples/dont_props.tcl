# set_property -user is_dont_touch / is_dont_use on nets, cells and lib cells
source fp_flow_setup.tcl
puts "=== DT"
set n [get_nets {u_core/g_lane[0].u_lane/stage1[0]}]
set_property -user $n is_dont_touch true
puts "NET_DT [get_property $n is_dont_touch]"
set c [get_cells {u_core/g_lane[3].u_lane/U1738}]
set_property -user $c is_dont_touch true
puts "CELL_DT [get_property $c is_dont_touch] [get_property $c ref_name]"
set lc [get_lib_cells */XOR2_X2_LVT]
puts "LC [get_object_name $lc]"
set_property -user $lc is_dont_use true
puts "LC_DU [get_property $lc is_dont_use]"
set c2 [get_cells {u_core/g_lane[2].u_lane/U1183}]
set_property -user $c2 is_dont_use true
puts "CELL_DU [get_property $c2 is_dont_use] -> [get_property [get_lib_cells */[get_property $c2 ref_name]] is_dont_use]"
catch {set_property $n is_dont_touch maybe} m; puts "BADBOOL $m"
set before [sizeof_collection [all_connected $n]]
compile_fusion -from initial_place -to final_opto
puts "AFTER: net pins [sizeof_collection [all_connected $n]] (was $before) cell [get_property $c ref_name] XOR2_X2_LVT_used [sizeof_collection [get_cells -hier * -filter {ref_name == XOR2_X2_LVT} -quiet]] U1183_lib [get_property $c2 ref_name]"
set_property $lc is_dont_use false
puts "LC_DU_OFF [get_property $lc is_dont_use]"
