# sign-off exports after detailed routing: SPEF/DSPF per extraction corner, SDF min/typ/max, GDS merge
source fp_flow_setup.tcl
set_timing_derate -late  1.03 -data  -corners {ss ff}
set_timing_derate -early 0.97 -data  -corners {ss ff}
place_opt
clock_opt -from build_clock -to route_clock
route_auto
puts "=== XOUT"
file mkdir out/xo
set w0 [get_attribute [get_timing_paths -scenarios func_ss -max_paths 1] slack]
set h0 [get_attribute [get_timing_paths -scenarios func_ss -delay_type min -max_paths 1] slack]
puts "BASE setup $w0 hold $h0"
write_spef -output out/xo/top -extraction_corners {ss ff} -stage detail_route
write_spef -output out/xo/top_ps_ff.spef -corner ss -time_unit PS -cap_unit FF -res_unit OHM -no_name_map -coordinates
write_spef -output out/xo/clk.spef -corner ss -nets {clk*}
write_dspf -output out/xo/top -corners {ss ff}
write_sdf out/xo/top.sdf -scenario func_ss
write_sdf out/xo/top_mtm.sdf -min_corner ff -typ_corner ss -max_corner ss -include {SETUPHOLD RECREM}
write_sdf -min out/xo/top_min.sdf -min_corner ff -max_corner ss
write_sdf -max out/xo/top_max.sdf -min_corner ff -max_corner ss
write_sdf -typ out/xo/top_typ.sdf -corner ss
write_sdf out/xo/top_v21.sdf -version 2.1 -corners {ss ff} -no_negative_values timing_checks -time_unit ps
file mkdir out/gds
write_cell_gds -cells {*_SVT *_LVT *_HVT} -output out/gds/stdcells.gds -gds_map_file gds/rs28.map
write_cell_gds -cells sram_macro_8x16 -size {20 12} -units 2000 -output out/gds/sram.gds -pin_layer M4 -gds_map_file gds/rs28.map
write_cell_gds -cells {pll_ip BUF_X1_SVT} -size {30 30} -pins {REFCLK CLKOUT LOCK} -output out/gds/pll.gds -pin_layer M5 -gds_map_file gds/rs28.map
export_gds -m -output out/gds/soc_top.gds -gds_map_file gds/rs28.map -merge gds/merge.list -top_cell_name SOC_TOP
export_gds -output out/gds/soc_top_pruned.gds -gds_map_file gds/rs28.map -merge gds/merge.list -top_cell_name SOC_TOP -prune_unused
report_gds out/gds/soc_top_pruned.gds
report_gds out/gds/soc_top.gds
export_gds -output out/gds/soc_top_u.gds -merge {out/gds/stdcells.gds out/gds/sram.gds out/gds/pll.gds} -uniquify_cell_names -top_cell_name SOC_TOP -write_map_file out/gds/default.map
export_gds -output out/gds/soc_top_nostd.gds -merge out/gds/sram.gds -mode NOROUTING
report_gds out/gds/soc_top_nostd.gds
# round trips
read_parasitics -corner ss out/xo/top.ss.spef
puts "SPEF_RT setup [get_attribute [get_timing_paths -scenarios func_ss -max_paths 1] slack]"
remove_parasitics
write_sdf out/xo/rt.sdf -scenario func_ss -significant_digits 6
read_sdf out/xo/rt.sdf
puts "SDF_RT setup [get_attribute [get_timing_paths -scenarios func_ss -max_paths 1] slack] hold [get_attribute [get_timing_paths -scenarios func_ss -delay_type min -max_paths 1] slack]"
