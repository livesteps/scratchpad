module t(input clka, input clkb, input d, output reg q);
  reg a;
  always @(posedge clka) a <= d;
  always @(posedge clkb) q <= ~a;
endmodule
