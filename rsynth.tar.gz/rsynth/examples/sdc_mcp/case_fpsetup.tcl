source base.tcl
set_false_path -setup -from [get_clocks ca] -to [get_clocks cb]
req fpsetup
