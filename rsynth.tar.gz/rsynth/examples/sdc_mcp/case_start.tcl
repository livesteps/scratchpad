source base.tcl
set_multicycle_path 2 -setup -start -from [get_clocks ca] -to [get_clocks cb]
req start
