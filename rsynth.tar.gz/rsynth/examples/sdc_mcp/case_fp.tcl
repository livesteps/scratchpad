source base.tcl
set_false_path -from [get_clocks ca] -to [get_clocks cb]
req fp
