source base.tcl
set_false_path -start -from [get_clocks ca] -to [get_clocks cb]
req fpstart
