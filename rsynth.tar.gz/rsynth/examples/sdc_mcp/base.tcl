# Two clocks: ca 1 ns launches, cb 3 ns captures; timing exceptions are applied per case script
read_lib ../lib/rs28_tt_0p80v_25c.lib
read_verilog t.v
link_block t
current_design t
create_clock -name ca -period 1 [get_ports clka]
create_clock -name cb -period 3 [get_ports clkb]
set_input_delay 0 -clock ca [get_ports d]
set_output_delay 0 -clock cb [get_ports q]
compile_fusion -to logic_opto
proc req {tag} { set p [get_timing_paths -to [get_pins -hier *q_reg*/D]]; puts "$tag setup_req [get_attribute $p required] slack [get_attribute $p slack]"; set h [get_timing_paths -delay_type min -to [get_pins -hier *q_reg*/D]]; puts "$tag hold_req [get_attribute $h required]" }
