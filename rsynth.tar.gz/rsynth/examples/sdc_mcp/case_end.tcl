source base.tcl
set_multicycle_path 2 -setup -end -from [get_clocks ca] -to [get_clocks cb]
req end
