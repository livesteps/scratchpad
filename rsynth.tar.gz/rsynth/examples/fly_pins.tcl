# Flylines of instances, pins and ports (GUI flyline engine, no GUI needed)
source pnr_flow.tcl
set c [lindex [get_object_name [get_cells -hier *]] 100]
set pn [lindex [get_object_name [get_pins -of_objects [get_cells $c]]] 0]
puts "FLYCELL [gui_show_flylines -cells [list $c]]"
puts "FLYPIN [gui_show_flylines -pins [list $pn]]"
puts "FLYPORT [gui_show_flylines -ports {din0[0]}]"
puts "FLYADD [gui_show_flylines -add -cells [list $c]]"
puts "FLYBAD [catch {gui_show_flylines -pins {no/such}} m]"
gui_show_flylines -clear
puts "VERSION [version]"
