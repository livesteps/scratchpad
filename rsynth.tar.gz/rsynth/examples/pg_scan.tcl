# Path groups, path margins, scan-chain reordering on the full MMMC/UPF/DFT flow
# ---------------------------------------------------------------------------
# RSynth reference flow: MMMC + UPF + DEF-driven physical synthesis + DFT
# ---------------------------------------------------------------------------
set_app_options -name hdlin.elaborate.empty_module_as_blackbox -value true
set_app_options -name compile.clockgate.enable -value true
set_app_options -name opt.tie_cell.max_fanout -value 6
set_app_options -name opt.hfn.threshold -value 24

# ---- MMMC setup ----------------------------------------------------------
create_mode func
create_mode test
foreach c {ss tt ff} { create_corner $c }
read_lib -corner ss lib/rs28_ss_0p72v_125c.lib
read_lib -corner tt lib/rs28_tt_0p80v_25c.lib
read_lib -corner ff lib/rs28_ff_0p88v_m40c.lib
set_timing_derate -late  1.05 -corners ss
set_timing_derate -early 0.95 -corners ff
set_parasitic_parameters -corner ss -r_scale 1.10 -c_scale 1.05
set_parasitic_parameters -corner ff -r_scale 0.90 -c_scale 0.95
create_scenario -name func_ss -mode func -corner ss
create_scenario -name func_ff -mode func -corner ff
create_scenario -name func_tt -mode func -corner tt
create_scenario -name test_ss -mode test -corner ss
set_scenario_status func_ss -setup true  -hold false -leakage_power false
set_scenario_status func_ff -setup false -hold true  -leakage_power false -dynamic_power false
set_scenario_status func_tt -setup false -hold false -leakage_power true  -dynamic_power true
set_scenario_status test_ss -setup true  -hold true
set_dont_use [get_lib_cells */*X8_HVT]

# ---- design input --------------------------------------------------------
analyze -format sverilog {rtl/soc_pkg.sv rtl/bus_if.sv rtl/lane.sv rtl/arbiter.sv rtl/core.sv rtl/soc_top.sv}
analyze -format vhdl rtl/checksum.vhd
elaborate soc_top
link_block
check_design

# ---- constraints, floorplan, power intent --------------------------------
current_mode func ; read_sdc func.sdc
current_mode test ; read_sdc test.sdc
read_def floorplan.def
load_upf power.upf
report_power_domains
check_timing -scenarios func_ss

# ---- synthesis -------------------------------------------------------------
compile_fusion -to initial_opto

# ---- DFT ------------------------------------------------------------------
set_dft_signal -view existing_dft -type ScanEnable -port scan_en -active_state 1
set_scan_configuration -chain_count 4 -clock_mixing no_mix
create_test_protocol
dft_drc
insert_dft
compile_fusion -from final_place -to final_opto
# ---- path groups / margins (path groups belong to the current mode)
current_mode func
create_path_groups -auto
group_path -name lane0 -to [get_cells -hier {u_core/g_lane\[0\].u_lane/*}]
set_path_group_options in2reg -weight 2 -critical_range 0.1
report_path_groups
report_timing -groups reg2out -path_type summary -max_paths 2
set_path_margin -setup 0.1 -to [all_outputs]
report_timing -groups reg2out -max_paths 1
delete_path_groups in2out
report_path_groups
# ---- scan-chain wirelength optimization
report_scan_chains
optimize_scan_chain -effort high
optimize_scan_chain -repartition
check_scan_chains
report_scan_chains
compile_fusion -from final_opto
report_qor
report_clocks -attributes -skew
report_clock_crossing
verify_equivalence -cycles 3000 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1 test_si0 0 test_si1 0 test_si2 0 test_si3 0}
