# MIM needs instances of one module: the soc lanes have different ID parameters
create_mode func ; create_corner ss
read_lib -corner ss lib/rs28_ss_0p72v_125c.lib
create_scenario -name func_ss -mode func -corner ss
analyze -format sverilog {rtl/soc_pkg.sv rtl/bus_if.sv rtl/lane.sv rtl/arbiter.sv rtl/core.sv rtl/soc_top.sv}
analyze -format vhdl rtl/checksum.vhd
elaborate soc_top
current_mode func ; read_sdc func.sdc
set_boundary_optimization [get_cells {u_core/g_lane[0].u_lane u_core/g_lane[1].u_lane}] false
compile_fusion -to logic_opto
puts "R5 [catch {create_partition -name l [get_cells {u_core/g_lane[0].u_lane u_core/g_lane[1].u_lane}]} m] $m"
