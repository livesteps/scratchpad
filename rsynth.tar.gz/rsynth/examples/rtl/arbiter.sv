// Round-robin arbiter with an ARRAY OF INTERFACE PORTS (bus_if.slave req[N])
module arbiter import soc_pkg::*; #(parameter int N = 4, parameter int W = 8) (
  input  logic         clk,
  input  logic         rst_n,
  bus_if.slave         req [N],
  output logic [W-1:0] gnt_data,
  output logic         gnt_valid,
  output logic [$clog2(N)-1:0] gnt_id,
  output state_t       state
);
  logic [$clog2(N)-1:0] ptr;
  logic [N-1:0]         vld;
  logic [W-1:0]         dat [N];
  state_t               nstate;

  for (genvar i = 0; i < N; i++) begin : g_unpack
    assign vld[i] = req[i].valid;
    assign dat[i] = req[i].data;
    assign req[i].ready = (ptr == i) && (state == RUN);
  end

  always_comb begin
    nstate = state;
    unique case (state)
      IDLE:  if (|vld) nstate = RUN;
      RUN:   if (!(|vld)) nstate = DRAIN;
      DRAIN: nstate = IDLE;
      default: nstate = ERR;
    endcase
  end

  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin
      state <= IDLE; ptr <= '0; gnt_valid <= 1'b0; gnt_data <= '0; gnt_id <= '0;
    end else begin
      state     <= nstate;
      ptr       <= ptr + 1'b1;
      gnt_valid <= vld[ptr];
      gnt_data  <= dat[ptr];
      gnt_id    <= ptr;
    end
endmodule
