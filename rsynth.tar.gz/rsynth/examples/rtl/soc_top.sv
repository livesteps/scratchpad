// Top level: core (power domain PD_CORE), a hard-macro black box, debug latch.
module soc_top import soc_pkg::*; (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          en,
  input  logic          iso_en,
  input  logic          save,
  input  logic          restore,
  input  logic          scan_en,
  input  logic [DW-1:0] din0, din1, din2, din3,
  input  logic [NLANE-1:0] din_vld,
  input  logic          dbg_sel,
  output logic [DW-1:0] dout,
  output logic          dout_vld,
  output logic [1:0]    dout_id,
  output logic [7:0]    csum,
  output logic [DW-1:0] acc0,
  output logic [1:0]    st,
  output logic [3:0]    dbg,
  output logic [7:0]    macro_q
);
  logic [DW-1:0] din [NLANE];
  assign din[0] = din0; assign din[1] = din1; assign din[2] = din2; assign din[3] = din3;
  state_t st_i;
  logic [DW-1:0] dout_i;

  core u_core (.clk, .rst_n, .en, .din(din), .din_vld, .dout(dout_i), .dout_vld, .dout_id,
               .csum, .acc0, .st(st_i));
  assign dout = dout_i;
  assign st = st_i;

  // hard macro without a model: becomes a black box (pin directions inferred)
  sram_macro_8x16 u_mem (.CLK(clk), .D(dout_i), .A(dout_id), .Q(macro_q));

  // intentionally incomplete combinational assignment -> latch inference
  always_comb begin
    if (dbg_sel) dbg = dout_i[3:0];
  end
endmodule
