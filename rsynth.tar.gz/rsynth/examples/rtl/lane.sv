// One processing lane: interface ports in and out, registered datapath
module lane import soc_pkg::*; #(parameter int W = 8, parameter int ID = 0) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          en,
  bus_if.slave          s,
  bus_if.master         m,
  output logic [W-1:0]  acc
);
  logic [W-1:0] stage1, stage2;
  hdr_t         hdr;
  assign s.ready = m.ready | ~m.valid;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      stage1 <= '0;
      stage2 <= '0;
      m.valid <= 1'b0;
      acc <= '0;
    end else if (en) begin            // enable => clock-gating candidate
      stage1  <= parity_mix(s.data, W'(ID * 37));
      stage2  <= stage1 * 3 + W'(ID);
      m.valid <= s.valid;
      acc     <= acc + stage2;
    end
  end
  assign hdr = '{tag: stage2[3:0], last: stage2[4], prio: stage2[7:5]};
  assign m.data = {hdr.prio, hdr.last, hdr.tag} ^ stage1;
endmodule
