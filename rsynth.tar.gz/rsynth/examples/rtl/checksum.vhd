-- VHDL checksum accumulator (mixed-language instantiation from SystemVerilog)
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity checksum is
  port (
    clk   : in  std_logic;
    rst_n : in  std_logic;
    d     : in  std_logic_vector(7 downto 0);
    v     : in  std_logic;
    sum   : out std_logic_vector(7 downto 0)
  );
end entity;

architecture rtl of checksum is
  signal acc : unsigned(7 downto 0);
begin
  process (clk, rst_n)
  begin
    if rst_n = '0' then
      acc <= (others => '0');
    elsif rising_edge(clk) then
      if v = '1' then
        acc <= acc + unsigned(d);
      end if;
    end if;
  end process;
  sum <= std_logic_vector(acc) when v = '1' else (others => '0');
end architecture;
