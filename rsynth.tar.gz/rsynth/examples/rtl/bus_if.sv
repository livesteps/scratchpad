// Valid/ready streaming interface with modports
interface bus_if #(parameter int W = 8);
  logic [W-1:0] data;
  logic         valid;
  logic         ready;
  modport master (output data, output valid, input ready);
  modport slave  (input data, input valid, output ready);
endinterface
