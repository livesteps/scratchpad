// Core: generate-array of lanes connected through an interface array, arbiter,
// a VHDL checksum unit, an empty module and an unresolved hard macro.
module core import soc_pkg::*; (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          en,
  input  logic [DW-1:0] din [NLANE],
  input  logic [NLANE-1:0] din_vld,
  output logic [DW-1:0] dout,
  output logic          dout_vld,
  output logic [1:0]    dout_id,
  output logic [7:0]    csum,
  output logic [DW-1:0] acc0,
  output state_t        st
);
  bus_if #(.W(DW)) src [NLANE] ();
  bus_if #(.W(DW)) dst [NLANE] ();
  logic [DW-1:0] acc [NLANE];

  for (genvar i = 0; i < NLANE; i++) begin : g_lane
    assign src[i].data  = din[i];
    assign src[i].valid = din_vld[i];
    lane #(.W(DW), .ID(i)) u_lane (.clk, .rst_n, .en, .s(src[i]), .m(dst[i]), .acc(acc[i]));
  end

  arbiter #(.N(NLANE), .W(DW)) u_arb (
    .clk, .rst_n, .req(dst), .gnt_data(dout), .gnt_valid(dout_vld), .gnt_id(dout_id), .state(st));

  checksum u_csum (.clk(clk), .rst_n(rst_n), .d(dout), .v(dout_vld), .sum(csum));

  // empty placeholder (kept as empty hierarchical block)
  spare_cells u_spare (.clk(clk), .a(dout[0]), .y());

  assign acc0 = acc[0];
endmodule

module spare_cells (input logic clk, input logic a, output logic y);
endmodule
