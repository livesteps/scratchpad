// Shared package: parameters, enum and packed struct types
package soc_pkg;
  parameter int DW = 8;
  parameter int NLANE = 4;
  typedef enum logic [1:0] {IDLE = 2'd0, RUN = 2'd1, DRAIN = 2'd2, ERR = 2'd3} state_t;
  typedef struct packed {
    logic [3:0] tag;
    logic       last;
    logic [2:0] prio;
  } hdr_t;
  function automatic logic [7:0] parity_mix(input logic [7:0] a, input logic [7:0] b);
    logic [7:0] r;
    r = a ^ {b[3:0], b[7:4]};
    return r + 8'd1;
  endfunction
endpackage
