# Nangate45 companion libraries: gate-array logic (also used as the synthesis target here, so
# the examples run without the Nangate45 PDK files), IO ring, area IO, bumps.
# With the Nangate45 PDK, add its standard cells as well, e.g.
#   read_lib -corner tt $env(NANGATE45)/lib/NangateOpenCellLibrary_typical.lib
#   read_lef $env(NANGATE45)/lef/NangateOpenCellLibrary.tech.lef $env(NANGATE45)/lef/NangateOpenCellLibrary.macro.lef
create_mode func
create_corner tt ; create_corner ss ; create_corner ff
read_lib -corner tt n45_ga_tt_1p10v_25c.lib  n45_io_tt_1p10v_25c.lib
read_lib -corner ss n45_ga_ss_0p95v_125c.lib n45_io_ss_0p95v_125c.lib
read_lib -corner ff n45_ga_ff_1p25v_m40c.lib n45_io_ff_1p25v_m40c.lib
create_scenario -name func_tt -mode func -corner tt
create_scenario -name func_ss -mode func -corner ss
create_scenario -name func_ff -mode func -corner ff
read_lef n45_tech.lef n45_ga.lef n45_io.lef n45_bump.lef
