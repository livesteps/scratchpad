# ---------------------------------------------------------------------------
# Placement pre-checks on the Nangate45 example:
#   ROW / SITE consistency (place_detail / legalize_placement abort on a mismatch)
#   IO pad / corner / area-IO / macro overlaps (check_io_overlaps, check_legality,
#   check_esd, and the placement pre-check)
# ---------------------------------------------------------------------------
source n45_wirebond.tcl
puts "SITE0 [check_row_site]"
puts "IO0 [check_io_overlaps]"
puts "LEG0 [check_legality]"
puts "PD0 [place_detail]"
puts "LP0 [legalize_placement]"

# ---- 1: placement grid that does not match the LEF SITE (0.19 x 1.4)
set_app_var place.site_width 0.2
puts "SITE1 [check_row_site]"
puts "PD1 [catch {place_detail} msg] $msg"
puts "LP1 [catch {legalize_placement} msg] $msg"
puts "LP1S [catch {legalize_placement -skip_site_check}]"
set_app_var place.site_width 0.19
legalize_placement

# ---- 2: DEF rows on a site the LEF does not define
file mkdir out
write_def out/n45_rows.def
set f [open out/n45_rows.def r] ; set d [read $f] ; close $f
set f [open out/n45_badsite.def w] ; puts -nonewline $f [string map {"FreePDK45_38x28_10R_NP_162NW_34O" "coreSite"} $d] ; close $f
read_def out/n45_badsite.def
puts "SITE2 [check_row_site]"
puts "PD2 [catch {place_detail} msg] $msg"
read_def out/n45_rows.def
puts "SITE3 [check_row_site]"

# ---- 3: IO pad overlaps: a pad pushed onto its neighbour, another moved across the ring
move_objects -objects io_din1 -delta {-20 0}
move_objects -objects io_dout0 -to {1000 120}
puts "IO1 [check_io_overlaps]"
report_markers -tool drc
puts "LEG1 [check_legality]"
puts "ESD1 [check_esd]"
puts "PD3 [catch {place_detail} msg] $msg"
move_objects -objects io_din1 -delta {20 0}
