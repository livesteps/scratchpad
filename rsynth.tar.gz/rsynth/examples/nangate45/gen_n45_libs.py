#!/usr/bin/env python3
"""Nangate45 (FreePDK45) companion libraries for RSynth.

Generates, for the tt / ss / ff corners:

  n45_io_<corner>.lib + n45_io.lef     IO-ring library for abutted pad rings
      N45IO_GPIO                 bidirectional GPIO: PAD, A (core -> pad data), OE (output
                                 enable), IE (input enable), PU / PD (pull-up / pull-down
                                 enables), Y (pad -> core)
      N45IO_IN / N45IO_OUT       input-only / output-only pads
      N45IO_ANALOG               analog pass-through pad (PLL / bias / analog IO): PAD <-> AY
      N45IO_PVDD  N45IO_PVSS     core-supply pads (CORE_VDD / CORE_VSS bond), ESD protected
      N45IO_PVDDIO N45IO_PVSSIO  IO-supply pads (IO_VDD / IO_VSS bond), ESD protected
      N45IO_ESDCLAMP             rail-to-rail ESD power clamp (no bond pad)
      N45IO_BRK_IO               pad breaker: cuts IO_VDD / IO_VSS (new IO domain)
      N45IO_BRK_ALL              pad breaker: cuts all four rails
      N45IO_CORNER               corner cell (L-shaped rails)
      N45IO_FILL01/1/2/5/10/20   IO fillers (0.1 .. 20 um), rails only
      N45IO_BONDPAD              wire-bond pad (inline or staggered)
      N45IO_AIO_IN/OUT/BIDIR     area-IO buffers for flip-chip (PAD landing for the RDL)
    Every pad / corner / filler / breaker carries the four ring rails CORE_VDD, CORE_VSS,
    IO_VDD, IO_VSS as full-width ABUTMENT pins, so an abutted ring is connected by placement.

  n45_ga_<corner>.lib + n45_ga.lef     gate-array library (metal-programmable base)
      functional: GINV GBUF GCLKBUF GNAND2/3 GNOR2/3 GAND2 GOR2 GXOR2 GXNOR2 GAOI21/22
                  GOAI21/22 GMUX2 GDFF GDFFR GDFFS GDFFRS GSDFF GSDFFR GDLH GTIEHI GTIELO
      physical:   GFILLER_X1..X16 (unprogrammed base, programmable into any G cell of the
                  same width) and GDCAP_X2..X16 (base programmed as decoupling capacitance)
    All cells sit on the Nangate45 core site (0.19 x 1.4 um) on a 2-site (0.38 um) base unit.

  n45_bump.lef                         flip-chip bumps + the AP (aluminium RDL) layer
  n45_tech.lef                         Nangate45-compatible technology LEF (metal1..metal10,
                                       via1..via9, VIARULE GENERATE, core + IO sites), so the
                                       abstracts above load without the original PDK files

Timing: the core-side arcs are fitted from the Nangate45 typical library (8-term polynomial model in
input slew and load, refit per arc and re-tabulated on the same index grids; no table is
copied) and scaled to the corners below; pad drivers use an analytic pad-load model.

  python3 gen_n45_libs.py --nangate-lib /path/to/NangateOpenCellLibrary_typical.lib
"""
import argparse, math, os, re, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

# ----------------------------------------------------------------------------- corners
# name, process, core V, IO V, temp, delay factor, leakage factor, power (V^2) factor
CORNERS = [
    ('tt_1p10v_25c',  'typical', 1.10, 1.80,  25.0, 1.00, 1.00, 1.00),
    ('ss_0p95v_125c', 'slow',    0.95, 1.62, 125.0, 1.42, 7.50, (0.95 / 1.10) ** 2),
    ('ff_1p25v_m40c', 'fast',    1.25, 1.98, -40.0, 0.71, 0.35, (1.25 / 1.10) ** 2),
]

# ----------------------------------------------------------------------------- Liberty parser
class G:
    """Liberty group: name (args) { attrs / complex attrs / groups }"""
    def __init__(self, name, args):
        self.name, self.args, self.items = name, args, []   # items: ('a', k, v) | ('c', k, [v]) | ('g', G)
    def groups(self, n=None):
        return [x[1] for x in self.items if x[0] == 'g' and (n is None or x[1].name == n)]
    def attr(self, k, d=None):
        for x in self.items:
            if x[0] == 'a' and x[1] == k:
                return x[2]
        return d
    def cattr(self, k):
        for x in self.items:
            if x[0] == 'c' and x[1] == k:
                return x[2]
        return None

TOK = re.compile(r'"(?:[^"\\]|\\.)*"|[{}();:,]|[^\s{}();:,"]+')

def parse_lib(text):
    text = re.sub(r'/\*.*?\*/', ' ', text, flags=re.S)
    text = text.replace('\\\n', ' ')
    toks = TOK.findall(text)
    pos = [0]
    def peek(o=0):
        return toks[pos[0] + o] if pos[0] + o < len(toks) else None
    def take():
        t = toks[pos[0]]; pos[0] += 1; return t
    def body(g):
        while peek() is not None and peek() != '}':
            name = take()
            if peek() == ':':
                take()
                v = []
                while peek() != ';':
                    v.append(take())
                take()
                g.items.append(('a', name, ' '.join(v)))
            elif peek() == '(':
                take()
                args = []
                while peek() != ')':
                    t = take()
                    if t != ',':
                        args.append(t)
                take()
                if peek() == '{':
                    take()
                    sub = G(name, args)
                    body(sub)
                    take()  # }
                    g.items.append(('g', sub))
                else:
                    if peek() == ';':
                        take()
                    g.items.append(('c', name, args))
            elif peek() == ';':
                take()
        return g
    root = G('root', [])
    body(root)
    return root.groups('library')[0]

def unq(s):
    return s[1:-1] if s.startswith('"') and s.endswith('"') else s

def floats(s):
    return [float(x) for x in unq(s).replace('\\', ' ').split(',') if x.strip()]

# ----------------------------------------------------------------------------- table fitting
TABLE_DELAY = {'cell_rise', 'cell_fall', 'rise_transition', 'fall_transition', 'rise_constraint', 'fall_constraint'}
TABLE_POWER = {'rise_power', 'fall_power', 'power'}
FIT = {'n': 0, 'err': 0.0, 'derr': 0.0}

def fit_table(tg):
    """least-squares fit v = p0 + p1 x + p2 y + p3 xy + p4 x^2 + p5 y^2 + p6 sqrt(x) + p7 sqrt(y) (1-D: linear)"""
    i1 = tg.cattr('index_1'); i2 = tg.cattr('index_2'); vals = tg.cattr('values')
    if not vals:
        return None
    x = floats(i1[0]) if i1 else [0.0]
    y = floats(i2[0]) if i2 else None
    rows = [floats(r) for r in vals]
    if y is None:
        v = np.array(rows[0] if len(rows) == 1 else [r[0] for r in rows])
        xs = np.array(x[:len(v)])
        A = np.vstack([np.ones_like(xs), xs, xs * xs, np.sqrt(np.abs(xs))]).T[:, :max(1, min(4, len(xs) - 1))]
        p, *_ = np.linalg.lstsq(A, v, rcond=None)
        V = A @ p
        FIT['n'] += 1; FIT['err'] = max(FIT['err'], float(np.max(np.abs(V - v)) / (np.max(np.abs(v)) + 1e-12)))
        return x, None, [list(V)]
    X, Y = np.meshgrid(np.array(x), np.array(y), indexing='ij')
    v = np.array(rows)
    xs, ys = X.ravel(), Y.ravel()
    A = np.vstack([np.ones(X.size), xs, ys, xs * ys, xs * xs, ys * ys, np.sqrt(np.abs(xs)), np.sqrt(np.abs(ys))]).T
    if A.shape[1] > X.size:
        A = A[:, :X.size]
    p, *_ = np.linalg.lstsq(A, v.ravel(), rcond=None)
    V = (A @ p).reshape(v.shape)
    FIT['n'] += 1; FIT['err'] = max(FIT['err'], float(np.max(np.abs(V - v)) / (np.max(np.abs(v)) + 1e-12)))
    return x, y, V.tolist()

def fmt(v):
    return ('%.6f' % v).rstrip('0').rstrip('.') if abs(v) >= 1e-6 else '0'

def table(name, tmpl, x, y, V, ind):
    s = '%s%s(%s) {\n' % (ind, name, tmpl)
    s += '%s  index_1 ("%s");\n' % (ind, ', '.join(fmt(a) for a in x))
    if y is not None:
        s += '%s  index_2 ("%s");\n' % (ind, ', '.join(fmt(a) for a in y))
    s += '%s  values (%s);\n' % (ind, (', \\\n' + ind + '          ').join('"%s"' % ', '.join(fmt(a) for a in r) for r in V))
    return s + ind + '}\n'

# ----------------------------------------------------------------------------- emit a re-fitted cell
SKIP_ATTR = {'drive_strength'}
def emit(g, ind, ctx):
    """re-emit a Liberty group, regenerating tables and scaling numbers"""
    s = ''
    for it in g.items:
        if it[0] == 'a':
            k, v = it[1], it[2]
            if k in SKIP_ATTR:
                continue
            if k == 'area' and ctx.get('area') is not None:
                v = fmt(ctx['area'])
            elif k in ('cell_leakage_power',) or (k == 'value' and g.name == 'leakage_power'):
                v = fmt(float(v) * ctx['kleak'])
            elif k in ('capacitance', 'rise_capacitance', 'fall_capacitance'):
                v = fmt(float(v) * ctx['kcap'])
            elif k == 'max_capacitance':
                v = fmt(float(v))
            s += '%s%s : %s;\n' % (ind, k, v)
        elif it[0] == 'c':
            s += '%s%s (%s);\n' % (ind, it[1], ', '.join(it[2]))
        else:
            sub = it[1]
            if sub.name in TABLE_DELAY | TABLE_POWER and sub.cattr('values'):
                tm = sub.args[0] if sub.args else 'scalar'
                if tm == 'scalar':
                    k = ctx['kdel'] if sub.name in TABLE_DELAY else ctx['kpow']
                    s += '%s%s(scalar) { values ("%s"); }\n' % (ind, sub.name, fmt(floats(sub.cattr('values')[0])[0] * k))
                    continue
                e0 = FIT['err']; FIT['err'] = 0.0
                r = fit_table(sub)
                if sub.name in TABLE_DELAY:
                    FIT['derr'] = max(FIT['derr'], FIT['err'])
                FIT['err'] = max(FIT['err'], e0)
                k = ctx['kdel'] if sub.name in TABLE_DELAY else ctx['kpow']
                x, y, V = r
                V = [[max(a * k, 0.0) if sub.name in ('cell_rise', 'cell_fall', 'rise_transition', 'fall_transition') else a * k for a in row] for row in V]
                s += table(sub.name, 'n45_' + tm.lower(), x, y, V, ind)
                continue
            if sub.name in ('pg_pin',):
                s += '%spg_pin (%s) {\n%s  voltage_name : %s;\n%s  pg_type : %s;\n%s}\n' % (ind, sub.args[0], ind, sub.attr('voltage_name'), ind, sub.attr('pg_type'), ind)
                continue
            nm = sub.name
            args = sub.args
            if nm == 'cell':
                args = [ctx['name']]
            s += '%s%s (%s) {\n' % (ind, nm, ', '.join(args))
            s += emit(sub, ind + '  ', dict(ctx, area=None) if nm != 'cell' else ctx)
            s += ind + '}\n'
    return s

def header(name, corner, templates, extra_templates=''):
    (cn, proc, v, vio, t, *_r) = corner
    s = '/* %s -- RSynth Nangate45 (FreePDK45) companion library, corner %s.\n' % (name, cn)
    s += '   Generated by examples/nangate45/gen_n45_libs.py: arcs fitted from the Nangate45 typical\n'
    s += '   library and scaled to %s %.2f V %.0f C. Use with the Nangate45 standard cells. */\n' % (proc, v, t)
    s += 'library (%s) {\n' % name
    s += '''  delay_model : table_lookup;
  in_place_swap_mode : match_footprint;
  library_features (report_delay_calculation, report_power_calculation);
  time_unit : "1ns";
  leakage_power_unit : "1nW";
  voltage_unit : "1V";
  current_unit : "1mA";
  pulling_resistance_unit : "1kohm";
  capacitive_load_unit (1,ff);
  input_threshold_pct_rise : 50;
  input_threshold_pct_fall : 50;
  output_threshold_pct_rise : 50;
  output_threshold_pct_fall : 50;
  slew_lower_threshold_pct_rise : 30;
  slew_upper_threshold_pct_rise : 70;
  slew_lower_threshold_pct_fall : 30;
  slew_upper_threshold_pct_fall : 70;
  slew_derate_from_library : 1.0;
  default_cell_leakage_power : 0;
  default_fanout_load : 1;
  default_inout_pin_cap : 1.0;
  default_input_pin_cap : 1.0;
  default_output_pin_cap : 0.0;
  default_leakage_power_density : 0;
  default_max_transition : %s;
''' % fmt(0.198535 * corner[5] * 1.5)
    s += '  nom_process : 1.0;\n  nom_temperature : %s;\n  nom_voltage : %s;\n' % (fmt(t), fmt(v))
    s += '  voltage_map (VDD, %s);\n  voltage_map (VSS, 0);\n' % fmt(v)
    if vio:
        s += '  voltage_map (CORE_VDD, %s);\n  voltage_map (CORE_VSS, 0);\n  voltage_map (IO_VDD, %s);\n  voltage_map (IO_VSS, 0);\n' % (fmt(v), fmt(vio))
    s += '  operating_conditions (%s) {\n    process : 1.0;\n    temperature : %s;\n    voltage : %s;\n    tree_type : balanced_tree;\n  }\n' % (cn, fmt(t), fmt(v))
    s += '  default_operating_conditions : %s;\n' % cn
    s += templates + extra_templates
    return s

def templates_of(lib):
    s = ''
    for kind in ('lu_table_template', 'power_lut_template'):
        for g in lib.groups(kind):
            s += '  %s (n45_%s) {\n' % (kind, g.args[0].lower())
            for it in g.items:
                if it[0] == 'a':
                    s += '    %s : %s;\n' % (it[1], it[2])
                elif it[0] == 'c':
                    s += '    %s (%s);\n' % (it[1], ', '.join(it[2]))
            s += '  }\n'
    return s

# ----------------------------------------------------------------------------- gate array
SITE_W, ROW_H = 0.19, 1.4
BASE = 2 * SITE_W                       # base unit: 2 sites
GA = [  # name, Nangate source, base units
    ('GINV_X1', 'INV_X1', 2), ('GINV_X2', 'INV_X2', 2), ('GBUF_X1', 'BUF_X1', 3), ('GBUF_X2', 'BUF_X2', 3),
    ('GCLKBUF_X1', 'CLKBUF_X1', 3), ('GNAND2_X1', 'NAND2_X1', 3), ('GNAND3_X1', 'NAND3_X1', 3),
    ('GNOR2_X1', 'NOR2_X1', 3), ('GNOR3_X1', 'NOR3_X1', 3), ('GAND2_X1', 'AND2_X1', 3), ('GOR2_X1', 'OR2_X1', 3),
    ('GXOR2_X1', 'XOR2_X1', 4), ('GXNOR2_X1', 'XNOR2_X1', 4), ('GAOI21_X1', 'AOI21_X1', 3), ('GOAI21_X1', 'OAI21_X1', 3),
    ('GAOI22_X1', 'AOI22_X1', 4), ('GOAI22_X1', 'OAI22_X1', 4), ('GMUX2_X1', 'MUX2_X1', 5),
    ('GDFF_X1', 'DFF_X1', 11), ('GDFFR_X1', 'DFFR_X1', 12), ('GDFFS_X1', 'DFFS_X1', 12), ('GDFFRS_X1', 'DFFRS_X1', 13), ('GSDFF_X1', 'SDFF_X1', 14), ('GSDFFR_X1', 'SDFFR_X1', 15), ('GDLH_X1', 'DLH_X1', 7),
    ('GTIEHI', 'LOGIC1_X1', 2), ('GTIELO', 'LOGIC0_X1', 2),
]
GFILL = [1, 2, 4, 8, 16]
GDCAP = [2, 4, 8, 16]
GA_DELAY, GA_LEAK, GA_CAP = 1.10, 1.15, 1.08   # gate-array penalty vs the custom cells

# ----------------------------------------------------------------------------- pads
PAD_W, PAD_H = 60.0, 120.0          # signal / supply pad: width along the ring, depth
BRK_W = 10.0
FILLS = [('N45IO_FILL01', 0.1), ('N45IO_FILL1', 1.0), ('N45IO_FILL2', 2.0), ('N45IO_FILL5', 5.0), ('N45IO_FILL10', 10.0), ('N45IO_FILL20', 20.0)]
# ring rails (distance from the outer edge, y0 .. y1) and their layers
RAILS = [('IO_VSS', 'GROUND', 64.0, 72.0, ('metal8', 'metal9')), ('IO_VDD', 'POWER', 74.0, 82.0, ('metal8', 'metal9')),
         ('CORE_VSS', 'GROUND', 86.0, 94.0, ('metal7', 'metal8')), ('CORE_VDD', 'POWER', 96.0, 104.0, ('metal7', 'metal8'))]
BOND = (5.0, 2.0, 55.0, 52.0)       # bond opening of the pad cells (metal10)
AIO_W = 50.0

def pad_load_tables(kd, d0, r_ns_per_pf, t0, kslew):
    """pad driver: delay = d0 + kslew*slew + R*C, transition = t0 + 2.2 R C"""
    sl = [0.01, 0.05, 0.1, 0.2, 0.4, 0.8, 1.6]
    ld = [500.0, 2000.0, 5000.0, 10000.0, 20000.0, 35000.0, 50000.0]   # fF
    dly = [[(d0 + kslew * s + r_ns_per_pf * c / 1000.0) * kd for c in ld] for s in sl]
    tr = [[(t0 + 0.2 * s + 2.2 * r_ns_per_pf * c / 1000.0) * kd for c in ld] for s in sl]
    return sl, ld, dly, tr

def core_tables(kd, d0, k_ff, t0, kslew):
    """pad receiver / area-IO into the core: Nangate45 delay grid"""
    sl = [0.00117378, 0.00472397, 0.0171859, 0.0409838, 0.0780596, 0.130081, 0.198535]
    ld = [0.365616, 1.897810, 3.795620, 7.591250, 15.182500, 30.365000, 60.730000]
    dly = [[(d0 + kslew * s + k_ff * c) * kd for c in ld] for s in sl]
    tr = [[(t0 + 0.4 * s + 2.0 * k_ff * c) * kd for c in ld] for s in sl]
    return sl, ld, dly, tr

def arc(related, sense, tmpl, t, ind, ttype=None):
    sl, ld, dly, tr = t
    s = '%stiming () {\n%s  related_pin : "%s";\n' % (ind, ind, related)
    if ttype:
        s += '%s  timing_type : %s;\n' % (ind, ttype)
    if sense:
        s += '%s  timing_sense : %s;\n' % (ind, sense)
    for n, V in (('cell_rise', dly), ('cell_fall', [[a * 0.94 for a in r] for r in dly]), ('rise_transition', tr), ('fall_transition', [[a * 0.9 for a in r] for r in tr])):
        s += table(n, tmpl, sl, ld, V, ind + '  ')
    return s + ind + '}\n'

def pgpins(ind, names):
    return ''.join('%spg_pin (%s) {\n%s  voltage_name : %s;\n%s  pg_type : %s;\n%s}\n' % (ind, n, ind, n, ind, 'primary_ground' if 'VSS' in n else 'primary_power', ind) for n in names)

RING_PG = ['CORE_VDD', 'CORE_VSS', 'IO_VDD', 'IO_VSS']

def io_cells(corner):
    (cn, proc, v, vio, t, kd, kl, kp) = corner
    o = []
    hd = '  cell (%s) {\n    area : %s;\n    pad_cell : true;\n    dont_touch : true;\n    dont_use : true;\n'
    def rel(p, io=False):
        return '      related_power_pin : "%s";\n      related_ground_pin : "%s";\n' % (('IO_VDD', 'IO_VSS') if io else ('CORE_VDD', 'CORE_VSS'))
    drv = pad_load_tables(kd, 0.85, 0.025, 0.12, 0.35)       # 25 ohm output driver
    ena = pad_load_tables(kd, 0.95, 0.025, 0.12, 0.35)
    rcv = core_tables(kd, 0.32, 0.0042, 0.03, 0.25)          # Schmitt receiver + core-side X4 buffer
    def leak(nw):
        return '    cell_leakage_power : %s;\n' % fmt(nw * kl)
    # GPIO
    s = hd % ('N45IO_GPIO', fmt(PAD_W * PAD_H)) + pgpins('    ', RING_PG) + leak(2200.0)
    for p in ('A', 'OE', 'IE', 'PU', 'PD'):
        s += '    pin (%s) {\n      direction : input;\n%s      capacitance : %s;\n    }\n' % (p, rel(p), fmt({'A': 2.4, 'OE': 2.1}.get(p, 1.2)))
    s += '    pin (PAD) {\n      direction : inout;\n      is_pad : true;\n%s      capacitance : 3200;\n      max_capacitance : 50000;\n      function : "A";\n      three_state : "!OE";\n      drive_current : 8;\n' % rel('PAD', True)
    s += arc('A', 'positive_unate', 'n45_pad_7x7', drv, '      ')
    s += arc('OE', None, 'n45_pad_7x7', ena, '      ', 'three_state_enable')
    s += arc('OE', None, 'n45_pad_7x7', ena, '      ', 'three_state_disable')
    s += '    }\n'
    s += '    pin (Y) {\n      direction : output;\n%s      max_capacitance : 60.73;\n      function : "(PAD & IE)";\n' % rel('Y')
    s += arc('PAD', 'positive_unate', 'n45_core_7x7', rcv, '      ')
    s += arc('IE', 'positive_unate', 'n45_core_7x7', core_tables(kd, 0.08, 0.0042, 0.03, 0.2), '      ')
    s += '    }\n  }\n'
    o.append(s)
    # input / output only
    s = hd % ('N45IO_IN', fmt(PAD_W * PAD_H)) + pgpins('    ', RING_PG) + leak(1100.0)
    s += '    pin (PAD) {\n      direction : input;\n      is_pad : true;\n%s      capacitance : 2900;\n    }\n' % rel('PAD', True)
    s += '    pin (Y) {\n      direction : output;\n%s      max_capacitance : 60.73;\n      function : "PAD";\n' % rel('Y')
    s += arc('PAD', 'positive_unate', 'n45_core_7x7', rcv, '      ') + '    }\n  }\n'
    o.append(s)
    s = hd % ('N45IO_OUT', fmt(PAD_W * PAD_H)) + pgpins('    ', RING_PG) + leak(1800.0)
    s += '    pin (A) {\n      direction : input;\n%s      capacitance : 2.4;\n    }\n' % rel('A')
    s += '    pin (PAD) {\n      direction : output;\n      is_pad : true;\n%s      max_capacitance : 50000;\n      function : "A";\n      drive_current : 8;\n' % rel('PAD', True)
    s += arc('A', 'positive_unate', 'n45_pad_7x7', drv, '      ') + '    }\n  }\n'
    o.append(s)
    s = hd % ('N45IO_ANALOG', fmt(PAD_W * PAD_H)) + pgpins('    ', RING_PG) + leak(300.0)
    s += '    pin (PAD) {\n      direction : inout;\n      is_pad : true;\n%s      capacitance : 1500;\n    }\n' % rel('PAD', True)
    s += '    pin (AY) {\n      direction : inout;\n%s      capacitance : 150;\n    }\n  }\n' % rel('AY')
    o.append(s)
    # supply / clamp / breakers / corner / fillers / bond pad: physical, PG pins only
    for n, w, lk in [('N45IO_PVDD', PAD_W, 900.0), ('N45IO_PVSS', PAD_W, 900.0), ('N45IO_PVDDIO', PAD_W, 1400.0), ('N45IO_PVSSIO', PAD_W, 1400.0),
                     ('N45IO_ESDCLAMP', PAD_W, 2600.0), ('N45IO_BRK_IO', BRK_W, 0.0), ('N45IO_BRK_ALL', BRK_W, 0.0), ('N45IO_CORNER', PAD_H, 0.0)] + \
                    [(f, w, 0.0) for f, w in FILLS]:
        pg = RING_PG
        s = hd % (n, fmt(w * PAD_H)) + pgpins('    ', pg) + (leak(lk) if lk else '') + '  }\n'
        o.append(s)
    o.append('  cell (N45IO_BONDPAD) {\n    area : %s;\n    pad_cell : true;\n    dont_touch : true;\n    dont_use : true;\n  }\n' % fmt(50.0 * 55.0))
    # area IO (flip chip): smaller driver, PAD lands on the RDL
    adrv = pad_load_tables(kd, 0.42, 0.06, 0.08, 0.3)
    for n, kind in (('N45IO_AIO_IN', 'in'), ('N45IO_AIO_OUT', 'out'), ('N45IO_AIO_BIDIR', 'bidir')):
        s = hd % (n, fmt(AIO_W * AIO_W)) + pgpins('    ', ['VDD', 'VSS']) + leak(450.0)
        r = '      related_power_pin : "VDD";\n      related_ground_pin : "VSS";\n'
        if kind != 'in':
            s += '    pin (A) {\n      direction : input;\n%s      capacitance : 1.9;\n    }\n' % r
        if kind == 'bidir':
            s += '    pin (OE) {\n      direction : input;\n%s      capacitance : 1.7;\n    }\n' % r
        if kind == 'in':
            s += '    pin (PAD) {\n      direction : input;\n      is_pad : true;\n%s      capacitance : 650;\n    }\n' % r
        else:
            s += '    pin (PAD) {\n      direction : %s;\n      is_pad : true;\n%s      max_capacitance : 50000;\n      function : "A";\n' % ('inout' if kind == 'bidir' else 'output', r)
            if kind == 'bidir':
                s += '      three_state : "!OE";\n      capacitance : 650;\n'
            s += arc('A', 'positive_unate', 'n45_pad_7x7', adrv, '      ')
            if kind == 'bidir':
                s += arc('OE', None, 'n45_pad_7x7', adrv, '      ', 'three_state_enable')
            s += '    }\n'
        if kind != 'out':
            s += '    pin (Y) {\n      direction : output;\n%s      max_capacitance : 60.73;\n      function : "PAD";\n' % r
            s += arc('PAD', 'positive_unate', 'n45_core_7x7', core_tables(kd, 0.12, 0.0042, 0.03, 0.25), '      ') + '    }\n'
        s += '  }\n'
        o.append(s)
    return o

PAD_TEMPLATES = '''  lu_table_template (n45_pad_7x7) {
    variable_1 : input_net_transition;
    variable_2 : total_output_net_capacitance;
    index_1 ("0.01, 0.05, 0.1, 0.2, 0.4, 0.8, 1.6");
    index_2 ("500, 2000, 5000, 10000, 20000, 35000, 50000");
  }
  lu_table_template (n45_core_7x7) {
    variable_1 : input_net_transition;
    variable_2 : total_output_net_capacitance;
    index_1 ("0.00117378, 0.00472397, 0.0171859, 0.0409838, 0.0780596, 0.130081, 0.198535");
    index_2 ("0.365616, 1.897810, 3.795620, 7.591250, 15.182500, 30.365000, 60.730000");
  }
'''

# ----------------------------------------------------------------------------- LEF writers
HDR = 'VERSION 5.8 ;\nBUSBITCHARS "[]" ;\nDIVIDERCHAR "/" ;\nUNITS\n  DATABASE MICRONS 2000 ;\nEND UNITS\nMANUFACTURINGGRID 0.005 ;\n\n'

def r4(r):
    return '%.3f %.3f %.3f %.3f' % r

def pin(name, d, use, ports, shape=None):
    """ports: [(layer, rect)]"""
    s = '  PIN %s\n    DIRECTION %s ;\n    USE %s ;\n' % (name, d, use)
    if shape:
        s += '    SHAPE %s ;\n' % shape
    s += '    PORT\n'
    for ly, r in ports:
        s += '      LAYER %s ;\n        RECT %s ;\n' % (ly, r4(r))
    return s + '    END\n  END %s\n' % name

def macro(name, cls, w, h, body, sym='X Y R90', site=None, fore=None):
    s = 'MACRO %s\n  CLASS %s ;\n' % (name, cls)
    if fore:
        s += '  FOREIGN %s 0 0 ;\n' % name
    s += '  ORIGIN 0 0 ;\n  SIZE %.3f BY %.3f ;\n  SYMMETRY %s ;\n' % (w, h, sym)
    if site:
        s += '  SITE %s ;\n' % site
    return s + body + 'END %s\n\n' % name

def obs(rects):
    return '  OBS\n' + ''.join('    LAYER %s ;\n      RECT %s ;\n' % (ly, r4(r)) for ly, r in rects) + '  END\n'

def rails(w, which=RING_PG):
    s = ''
    for n, use, y0, y1, lys in RAILS:
        if n in which:
            s += pin(n, 'INOUT', use, [(ly, (0.0, y0, w, y1)) for ly in lys], 'ABUTMENT')
    return s

def corner_rails():
    s = ''
    for n, use, y0, y1, lys in RAILS:
        ports = []
        for ly in lys:
            ports.append((ly, (y0, y0, PAD_H, y1)))     # horizontal leg (bottom side pads)
            ports.append((ly, (y0, y0, y1, PAD_H)))     # vertical leg (left side pads)
        s += pin(n, 'INOUT', use, ports, 'ABUTMENT')
    return s

def core_pin_x(k, n):
    return PAD_W / 2.0 + (k - (n - 1) / 2.0) * 6.0

def core_pins(spec):
    """core-side signal pins on the inner edge (y = PAD_H): spec [(name, dir)]"""
    s = ''
    for k, (p, d) in enumerate(spec):
        x = core_pin_x(k, len(spec))
        s += pin(p, d, 'SIGNAL', [('metal2', (x - 0.25, PAD_H - 1.0, x + 0.25, PAD_H)), ('metal3', (x - 0.25, PAD_H - 1.0, x + 0.25, PAD_H))])
    return s

PAD_OBS = [(l, (0.0, 0.0, PAD_W, PAD_H - 2.0)) for l in ('metal1', 'metal2', 'metal3', 'metal4', 'metal5', 'metal6')] + \
          [('metal7', (0.0, 0.0, PAD_W, 84.0)), ('metal7', (0.0, 106.0, PAD_W, PAD_H - 2.0))]

def io_lef():
    L = HDR + 'SITE N45IO_SITE\n  CLASS PAD ;\n  SYMMETRY Y R90 ;\n  SIZE 0.1 BY %.1f ;\nEND N45IO_SITE\n\n' % PAD_H
    L += 'SITE N45IO_CORNER_SITE\n  CLASS PAD ;\n  SYMMETRY Y R90 ;\n  SIZE %.1f BY %.1f ;\nEND N45IO_CORNER_SITE\n\n' % (PAD_H, PAD_H)
    padpin = lambda d: pin('PAD', d, 'SIGNAL', [('metal10', BOND)])
    L += macro('N45IO_GPIO', 'PAD INOUT', PAD_W, PAD_H, padpin('INOUT') + core_pins([('A', 'INPUT'), ('OE', 'INPUT'), ('IE', 'INPUT'), ('PU', 'INPUT'), ('PD', 'INPUT'), ('Y', 'OUTPUT')]) + rails(PAD_W) + obs(PAD_OBS), site='N45IO_SITE')
    L += macro('N45IO_IN', 'PAD INPUT', PAD_W, PAD_H, padpin('INPUT') + core_pins([('Y', 'OUTPUT')]) + rails(PAD_W) + obs(PAD_OBS), site='N45IO_SITE')
    L += macro('N45IO_OUT', 'PAD OUTPUT', PAD_W, PAD_H, padpin('OUTPUT') + core_pins([('A', 'INPUT')]) + rails(PAD_W) + obs(PAD_OBS), site='N45IO_SITE')
    # analog: wide core-side pin on metal7 / metal8 (low resistance)
    ana = pin('AY', 'INOUT', 'ANALOG', [('metal6', (PAD_W / 2 - 4, PAD_H - 2.0, PAD_W / 2 + 4, PAD_H))])
    L += macro('N45IO_ANALOG', 'PAD INOUT', PAD_W, PAD_H, pin('PAD', 'INOUT', 'ANALOG', [('metal10', BOND)]) + ana + rails(PAD_W) + obs(PAD_OBS[:5]), site='N45IO_SITE')
    # supply pads: the bond opening is a port of the rail it feeds; a wide core-side strap
    for n, rail in (('N45IO_PVDD', 'CORE_VDD'), ('N45IO_PVSS', 'CORE_VSS'), ('N45IO_PVDDIO', 'IO_VDD'), ('N45IO_PVSSIO', 'IO_VSS')):
        body = ''
        for rn, use, y0, y1, lys in RAILS:
            ports = [(ly, (0.0, y0, PAD_W, y1)) for ly in lys]
            if rn == rail:
                ports.append(('metal10', BOND))
                if rn.startswith('CORE'):
                    ports += [(ly, (PAD_W / 2 - 10, y1, PAD_W / 2 + 10, PAD_H)) for ly in ('metal7', 'metal8')]
            body += pin(rn, 'INOUT', use, ports, 'ABUTMENT')
        L += macro(n, 'PAD POWER', PAD_W, PAD_H, body + obs(PAD_OBS[:6]), site='N45IO_SITE')
    L += macro('N45IO_ESDCLAMP', 'PAD POWER', PAD_W, PAD_H, rails(PAD_W) + obs(PAD_OBS[:6]), site='N45IO_SITE')
    L += macro('N45IO_BRK_IO', 'PAD SPACER', BRK_W, PAD_H, rails(BRK_W, ['CORE_VDD', 'CORE_VSS']), site='N45IO_SITE')
    L += macro('N45IO_BRK_ALL', 'PAD SPACER', BRK_W, PAD_H, obs([('metal1', (0.0, 0.0, BRK_W, 50.0))]), site='N45IO_SITE')
    for f, w in FILLS:
        L += macro(f, 'PAD SPACER', w, PAD_H, rails(w), site='N45IO_SITE')
    L += macro('N45IO_CORNER', 'ENDCAP BOTTOMLEFT', PAD_H, PAD_H, corner_rails() + obs([(l, (0.0, 0.0, 60.0, 60.0)) for l in ('metal1', 'metal2', 'metal3')]), site='N45IO_CORNER_SITE')
    L += macro('N45IO_BONDPAD', 'COVER', 50.0, 55.0, pin('PAD', 'INOUT', 'SIGNAL', [('metal10', (1.0, 1.0, 49.0, 54.0))]))
    # area IO: 50 x 50, PAD landing (metal10) in the centre for the RDL via, core pins at the bottom
    a = AIO_W
    pg = pin('VDD', 'INOUT', 'POWER', [('metal1', (0.0, a - 0.5, a, a))]) + pin('VSS', 'INOUT', 'GROUND', [('metal1', (0.0, 0.0, a, 0.5))])
    aobs = obs([(l, (0.0, 1.5, a, a - 1.5)) for l in ('metal1', 'metal2', 'metal3', 'metal4')])
    land = lambda d: pin('PAD', d, 'SIGNAL', [('metal10', (a / 2 - 6, a / 2 - 6, a / 2 + 6, a / 2 + 6))])
    cp = lambda p, d, x: pin(p, d, 'SIGNAL', [('metal2', (x - 0.25, 0.5, x + 0.25, 1.5))])
    L += macro('N45IO_AIO_IN', 'BLOCK', a, a, land('INPUT') + cp('Y', 'OUTPUT', a / 2) + pg + aobs)
    L += macro('N45IO_AIO_OUT', 'BLOCK', a, a, land('OUTPUT') + cp('A', 'INPUT', a / 2) + pg + aobs)
    L += macro('N45IO_AIO_BIDIR', 'BLOCK', a, a, land('INOUT') + cp('A', 'INPUT', a / 2 - 4) + cp('OE', 'INPUT', a / 2) + cp('Y', 'OUTPUT', a / 2 + 4) + pg + aobs)
    return L + 'END LIBRARY\n'

def ga_pins(lc):
    """GA abstract: metal1 vertical pin stubs on site centres, VDD / VSS rails"""
    pins = [p for p in lc.groups('pin')]
    return [(p.args[0], {'input': 'INPUT', 'output': 'OUTPUT', 'inout': 'INOUT'}.get(p.attr('direction'), 'INPUT')) for p in pins]

def ga_lef(cells_by):
    L = HDR
    def railpins(w):
        return pin('VDD', 'INOUT', 'POWER', [('metal1', (0.0, 1.315, w, 1.485))], 'ABUTMENT') + pin('VSS', 'INOUT', 'GROUND', [('metal1', (0.0, -0.085, w, 0.085))], 'ABUTMENT')
    for g, src, u in GA:
        w = u * BASE
        pl = ga_pins(cells_by[src])
        body = ''
        nsite = int(round(w / SITE_W))
        assert len(pl) < nsite, (g, len(pl), nsite)
        for k, (p, d) in enumerate(pl):
            x = SITE_W * (k + 0.5)
            if d == 'OUTPUT':
                x = w - SITE_W * 0.5 - SITE_W * (len([q for q in pl if q[1] == 'OUTPUT']) - 1 - [q[0] for q in pl if q[1] == 'OUTPUT'].index(p))
            body += pin(p, d, 'SIGNAL', [('metal1', (x - 0.035, 0.35, x + 0.035, 1.05))])
        body += railpins(w)
        body += obs([('metal1', (0.0, 0.17, w, 0.25)), ('metal1', (0.0, 1.15, w, 1.23))])
        L += macro(g, 'CORE' if not g.startswith('GTIE') else ('CORE TIEHIGH' if g == 'GTIEHI' else 'CORE TIELOW'), w, ROW_H, body, 'X Y', 'FreePDK45_38x28_10R_NP_162NW_34O', True)
    for u in GFILL:
        L += macro('GFILLER_X%d' % u, 'CORE SPACER', u * BASE, ROW_H, railpins(u * BASE), 'X Y', 'FreePDK45_38x28_10R_NP_162NW_34O', True)
    for u in GDCAP:
        L += macro('GDCAP_X%d' % u, 'CORE SPACER', u * BASE, ROW_H, railpins(u * BASE) + obs([('metal1', (0.0, 0.17, u * BASE, 1.23))]), 'X Y', 'FreePDK45_38x28_10R_NP_162NW_34O', True)
    return L + 'END LIBRARY\n'

def bump_lef():
    L = HDR
    L += '''# AP: aluminium redistribution layer above metal10 (bump landing + RDL routing)
LAYER pad_via
  TYPE CUT ;
  SPACING 5.0 ;
  WIDTH 5.0 ;
END pad_via

LAYER AP
  TYPE ROUTING ;
  DIRECTION HORIZONTAL ;
  PITCH 20.0 ;
  WIDTH 8.0 ;
  SPACING 8.0 ;
  RESISTANCE RPERSQ 0.010 ;
END AP

VIARULE AP_VIA_GEN GENERATE
  LAYER metal10 ;
    ENCLOSURE 1.0 1.0 ;
  LAYER pad_via ;
    RECT -2.5 -2.5 2.5 2.5 ;
    SPACING 10.0 BY 10.0 ;
  LAYER AP ;
    ENCLOSURE 1.0 1.0 ;
END AP_VIA_GEN

'''
    # C4 bumps (pitch >= 1.6 x size), micro bump; the pad pin is the under-bump metal on AP
    for n, sz, ubm, note in (('N45_BUMP_C4_100', 100.0, 90.0, 'C4 solder bump, 100 um (180-250 um pitch)'),
                             ('N45_BUMP_C4_80', 80.0, 72.0, 'C4 solder bump, 80 um (150-200 um pitch)'),
                             ('N45_BUMP_C4_60', 60.0, 54.0, 'C4 solder bump, 60 um (100-150 um pitch)'),
                             ('N45_UBUMP_25', 25.0, 22.0, 'micro bump, 25 um (40-55 um pitch, 2.5D / 3D)')):
        o = (sz - ubm) / 2.0
        L += '# %s\n' % note
        L += macro(n, 'COVER BUMP', sz, sz, pin('PAD', 'INOUT', 'SIGNAL', [('AP', (o, o, sz - o, sz - o))]), 'X Y R90')
    return L + 'END LIBRARY\n'

def tech_lef():
    L = HDR.replace('MANUFACTURINGGRID 0.005 ;\n\n', 'MANUFACTURINGGRID 0.005 ;\n\nPROPERTYDEFINITIONS\nEND PROPERTYDEFINITIONS\n\n')
    # name, direction, pitch, width, spacing, ohm/sq, pF/um^2 (area), offset
    metals = [('metal1', 'HORIZONTAL', 0.14, 0.07, 0.065, 0.38), ('metal2', 'VERTICAL', 0.19, 0.07, 0.07, 0.25), ('metal3', 'HORIZONTAL', 0.14, 0.07, 0.07, 0.25),
              ('metal4', 'VERTICAL', 0.28, 0.14, 0.14, 0.21), ('metal5', 'HORIZONTAL', 0.28, 0.14, 0.14, 0.21), ('metal6', 'VERTICAL', 0.28, 0.14, 0.14, 0.21),
              ('metal7', 'HORIZONTAL', 0.8, 0.4, 0.44, 0.075), ('metal8', 'VERTICAL', 0.8, 0.4, 0.44, 0.075), ('metal9', 'HORIZONTAL', 1.6, 0.8, 0.8, 0.03),
              ('metal10', 'VERTICAL', 1.6, 0.8, 0.8, 0.03)]
    cuts = [0.07, 0.07, 0.07, 0.14, 0.14, 0.14, 0.4, 0.4, 0.8]
    for i, (n, d, p, w, sp, r) in enumerate(metals):
        L += 'LAYER %s\n  TYPE ROUTING ;\n  DIRECTION %s ;\n  PITCH %s ;\n  OFFSET %s ;\n  WIDTH %s ;\n  SPACING %s ;\n  RESISTANCE RPERSQ %s ;\n  CAPACITANCE CPERSQDIST %s ;\nEND %s\n\n' % (
            n, d, fmt(p), fmt(p / 2 if i != 1 else 0.095), fmt(w), fmt(sp), fmt(r), fmt(7.7e-5 if i < 6 else 3.0e-5), n)
        if i < len(cuts):
            L += 'LAYER via%d\n  TYPE CUT ;\n  SPACING %s ;\n  WIDTH %s ;\n  RESISTANCE %s ;\nEND via%d\n\n' % (i + 1, fmt(cuts[i] * 1.14), fmt(cuts[i]), fmt([5.0, 5.0, 5.0, 3.0, 3.0, 3.0, 1.0, 1.0, 0.5][i]), i + 1)
    for i in range(9):
        lo, hi, c = metals[i][0], metals[i + 1][0], cuts[i]
        enc = 0.035 if c < 0.1 else (0.04 if c < 0.3 else 0.1)
        L += 'VIARULE M%dM%d_GEN GENERATE\n  LAYER %s ;\n    ENCLOSURE %s %s ;\n  LAYER via%d ;\n    RECT %s %s %s %s ;\n    SPACING %s BY %s ;\n  LAYER %s ;\n    ENCLOSURE %s %s ;\nEND M%dM%d_GEN\n\n' % (
            i + 1, i + 2, lo, fmt(enc), fmt(enc), i + 1, fmt(-c / 2), fmt(-c / 2), fmt(c / 2), fmt(c / 2), fmt(c * 2.14), fmt(c * 2.14), hi, fmt(enc), fmt(enc), i + 1, i + 2)
    L += 'SITE FreePDK45_38x28_10R_NP_162NW_34O\n  CLASS CORE ;\n  SYMMETRY Y ;\n  SIZE 0.19 BY 1.4 ;\nEND FreePDK45_38x28_10R_NP_162NW_34O\n\n'
    return L + 'END LIBRARY\n'

# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--nangate-lib', default=os.environ.get('NANGATE45_LIB', os.path.join(HERE, 'pdk', 'NangateOpenCellLibrary_typical.lib')))
    ap.add_argument('--out', default=HERE)
    a = ap.parse_args()
    if not os.path.exists(a.nangate_lib):
        sys.exit('Nangate45 typical library not found: %s (--nangate-lib or NANGATE45_LIB)' % a.nangate_lib)
    lib = parse_lib(open(a.nangate_lib).read())
    cells_by = {c.args[0]: c for c in lib.groups('cell')}
    tmpl = templates_of(lib)
    for corner in CORNERS:
        cn, kd, kl, kp = corner[0], corner[5], corner[6], corner[7]
        # gate array
        out = [header('n45_ga_%s' % cn, (corner[0], corner[1], corner[2], None) + corner[4:], tmpl)]
        for g, src, u in GA:
            ctx = {'name': g, 'area': u * BASE * ROW_H, 'kleak': kl * GA_LEAK, 'kcap': GA_CAP, 'kdel': kd * GA_DELAY, 'kpow': kp * 1.05}
            out.append('  /* gate-array %s: function of %s, %d base units */\n' % (g, src, u) + emit(_wrap(cells_by[src]), '  ', ctx))
        for u in GFILL:
            out.append('  cell (GFILLER_X%d) {\n    area : %s;\n    dont_touch : true;\n    dont_use : true;\n    /* unprogrammed gate-array base: metal-programmable into any G cell of %d base unit(s) */\n%s  }\n' % (u, fmt(u * BASE * ROW_H), u, pgpins('    ', ['VDD', 'VSS'])))
        for u in GDCAP:
            out.append('  cell (GDCAP_X%d) {\n    area : %s;\n    dont_touch : true;\n    dont_use : true;\n    /* gate-array base programmed as VDD-VSS decoupling capacitance: ~%.1f fF */\n    cell_leakage_power : %s;\n%s  }\n' % (u, fmt(u * BASE * ROW_H), u * 1.9, fmt(u * 2.6 * kl), pgpins('    ', ['VDD', 'VSS'])))
        open(os.path.join(a.out, 'n45_ga_%s.lib' % cn), 'w').write(''.join(out) + '}\n')
        # IO
        out = [header('n45_io_%s' % cn, corner, '', PAD_TEMPLATES)] + io_cells(corner)
        open(os.path.join(a.out, 'n45_io_%s.lib' % cn), 'w').write(''.join(out) + '}\n')
    open(os.path.join(a.out, 'n45_io.lef'), 'w').write(io_lef())
    open(os.path.join(a.out, 'n45_ga.lef'), 'w').write(ga_lef(cells_by))
    open(os.path.join(a.out, 'n45_bump.lef'), 'w').write(bump_lef())
    open(os.path.join(a.out, 'n45_tech.lef'), 'w').write(tech_lef())
    print('generated n45 IO / gate-array libraries (%s), LEF abstracts, bump and tech LEF; %d tables fitted; max fit error: delay / transition / constraint %.1f %%, internal power %.1f %%'
          % (', '.join(c[0] for c in CORNERS), FIT['n'] // len(CORNERS), 100 * FIT['derr'], 100 * FIT['err']))

def _wrap(cell):
    """a root holding just this cell (emit() walks the children)"""
    r = G('root', [])
    r.items.append(('g', cell))
    return r

if __name__ == '__main__':
    main()
