# Nangate45 companion libraries

Scaled IO-ring, gate-array and flip-chip libraries for the Nangate45 / FreePDK45 node,
for the tt / ss / ff corners. They are meant to be used **together with the Nangate45
standard cells** (`NangateOpenCellLibrary_typical.lib`, `.tech.lef`, `.macro.lef`): the layer
names (`metal1`..`metal10`, `via1`..`via9`), the core site (`FreePDK45_38x28_10R_NP_162NW_34O`,
0.19 x 1.4 um), units (ns, fF, nW, V) and the delay grids match. The Nangate45 files themselves
are not included.

| Corner | Process | Core V | IO V | Temp | Delay | Leakage |
|---|---|---|---|---|---|---|
| `tt_1p10v_25c`  | typical | 1.10 | 1.80 | 25 C   | 1.00x | 1.0x |
| `ss_0p95v_125c` | slow    | 0.95 | 1.62 | 125 C  | 1.42x | 7.5x |
| `ff_1p25v_m40c` | fast    | 1.25 | 1.98 | -40 C  | 0.71x | 0.35x |

## Files

| File | Contents |
|---|---|
| `n45_io_<corner>.lib`, `n45_io.lef` | IO ring: `N45IO_GPIO` (bidirectional: PAD, A, OE, IE, PU, PD, Y), `N45IO_IN`, `N45IO_OUT`, `N45IO_ANALOG` (PLL / analog: PAD <-> AY), ESD-protected supply pads `N45IO_PVDD` / `N45IO_PVSS` (core supply) and `N45IO_PVDDIO` / `N45IO_PVSSIO` (IO supply), `N45IO_ESDCLAMP` (power clamp), pad breakers `N45IO_BRK_IO` (cuts IO_VDD / IO_VSS) and `N45IO_BRK_ALL` (cuts all rails), `N45IO_CORNER`, fillers `N45IO_FILL01/1/2/5/10/20`, `N45IO_BONDPAD`, area-IO buffers `N45IO_AIO_IN/OUT/BIDIR` |
| `n45_ga_<corner>.lib`, `n45_ga.lef` | gate array on a 0.38 um (2-site) base unit: `GINV GBUF GCLKBUF GNAND2/3 GNOR2/3 GAND2 GOR2 GXOR2 GXNOR2 GAOI21/22 GOAI21/22 GMUX2 GDFF GDFFR GDFFS GDFFRS GSDFF GSDFFR GDLH GTIEHI GTIELO`; physical `GFILLER_X1/2/4/8/16` (unprogrammed base) and `GDCAP_X2/4/8/16` (base programmed as decap) |
| `n45_bump.lef` | `AP` aluminium RDL layer + `pad_via`, C4 bumps `N45_BUMP_C4_100/80/60`, micro bump `N45_UBUMP_25` |
| `n45_tech.lef` | Nangate45-compatible technology LEF (metal1..metal10, via1..via9, `VIARULE ... GENERATE` per layer pair, core site) so the abstracts load stand-alone |
| `gen_n45_libs.py` | the generator |

## Pad ring power

Pads are 60 x 120 um (corner 120 x 120), outer (bond) edge at y = 0. Every pad, filler, corner
and breaker carries the four ring rails as full-width `SHAPE ABUTMENT` pins, so an **abutted
ring is connected by placement** (`distribute abut` in the pad order file):

| Rail | Distance from the outer edge | Layers |
|---|---|---|
| `IO_VSS`   | 64 - 72 um  | metal8, metal9 |
| `IO_VDD`   | 74 - 82 um  | metal8, metal9 |
| `CORE_VSS` | 86 - 94 um  | metal7, metal8 |
| `CORE_VDD` | 96 - 104 um | metal7, metal8 |

The corner has L-shaped rails at the same distances from both outer edges. Supply pads add
their bond opening (metal10) to the rail they feed; the core-supply pads also have a 20 um
metal7 / metal8 strap to the core ring. `N45IO_BRK_IO` leaves out the IO rails (a new IO
domain); `N45IO_BRK_ALL` leaves out all four. Core-side signal pins sit on the inner edge
(metal2 / metal3). In the library the pads have the pg_pins `CORE_VDD CORE_VSS IO_VDD IO_VSS`
(`voltage_map` 1.1 / 0 / 1.8 / 0 V at tt); `PAD` pins are related to the IO supply, core
pins to the core supply. Connect them with `connect_global_net` (see `n45_wirebond.tcl`).

When a `N45IO_GPIO` pads an input port, `create_pad_ring` connects `Y` to the core and ties
`OE=0 IE=1 PU=0 PD=0`; for an output port it connects `A` and ties `OE=1 IE=0`.

## Timing and power

Core-side arcs of the gate-array cells are fitted per arc from the Nangate45 typical library
(8-term model in input slew and load: max error 9 % on delay / transition / constraint, 12 % on
internal power), re-tabulated on the same index grids and scaled to the corners. Gate-array
cells carry a 10 % delay, 15 % leakage and 8 % pin-capacitance penalty over the custom cells.
Pad drivers use an analytic pad-load model (output driver ~25 ohm, 0.5 - 50 pF load grid).

## Regenerate

```
python3 gen_n45_libs.py --nangate-lib /path/to/NangateOpenCellLibrary_typical.lib
```

## Examples

```
../../target/release/rsynth -f n45_wirebond.tcl   # abutted IO ring, global PG connect, core grid, GA fillers
../../target/release/rsynth -f n45_flipchip.tcl   # C4 bumps on AP, area IO, bump assignment, RDL routing
```

The examples synthesize onto the gate-array cells so that they run without the Nangate45
files; with the PDK, add its library and LEFs in `common.tcl`.
