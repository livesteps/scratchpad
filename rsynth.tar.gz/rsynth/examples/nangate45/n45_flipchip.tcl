# ---------------------------------------------------------------------------
# Nangate45 flip-chip / area-IO chip: C4 bumps on the AP (aluminium RDL) layer,
# N45IO area-IO buffers next to the core logic, supply / signal bump assignment,
# re-optimization, RDL routing (orthogonal, then 45-degree), bump dumps.
# ---------------------------------------------------------------------------
source common.tcl
analyze -format sverilog rtl/chip_ctrl.sv
elaborate chip_ctrl
create_clock -name clk -period 2.0 [get_ports clk]
compile_fusion -to logic_opto

initialize_floorplan -die_width 1050 -die_height 1050 -core2die_spacing 60 -row_height 1.4 -no_pins
create_seal_ring -width 5 -layers {metal1 metal2 metal3 metal4 metal5 metal6 metal7 metal8 metal9 metal10 AP} -chamfer 15

# ---- 80 um C4 bumps on a 150 um pitch (6 x 6)
create_bump_array -cell N45_BUMP_C4_80 -pitch 150 -layer AP -pattern full -prefix bump
report_bumps

# ---- area-IO buffers for every port, on a ring 20 um inside the core
create_area_io -input_cell N45IO_AIO_IN -output_cell N45IO_AIO_OUT -ports {*} -inset 20
connect_global_net VDD -type pg_pin -pin_base_name VDD -inst_base_name *
connect_global_net VSS -type pg_pin -pin_base_name VSS -inst_base_name *
place_opt

# ---- supply + signal bumps (signals on the outer rings, interleaved supplies)
assign_bumps -power_nets {VDD} -ground_nets {VSS} -supply_pattern checker -pad_cells {aio_*}
optimize_bump_assignment -iterations 8
report_bumps

# ---- RDL on AP: orthogonal, then 45-degree
route_rdl -layer AP -width 8 -spacing 8
route_rdl -layer AP -width 8 -spacing 8 -allow_45
report_bumps

file mkdir out
write_bumps -format text out/n45_bumps.txt
write_bumps -format def  out/n45_bumps.def
write_def out/n45_flipchip.def
if {[catch {gui_write_image out/n45_flipchip.png}]} { puts "(layout image needs the GTK build)" }
