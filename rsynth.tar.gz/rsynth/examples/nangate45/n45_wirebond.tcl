# ---------------------------------------------------------------------------
# Nangate45 wire-bond chip: chip_ctrl on the gate-array cells, an abutted IO ring
# of N45IO pads (GPIO / IN / OUT / analog / supply / ESD clamp / breaker / corner /
# fillers) whose CORE_VDD CORE_VSS IO_VDD IO_VSS rails connect by abutment,
# global PG connections for every pad and cell, core power grid, ESD / bond checks.
# ---------------------------------------------------------------------------
source common.tcl
analyze -format sverilog rtl/chip_ctrl.sv
elaborate chip_ctrl
create_clock -name clk -period 2.0 [get_ports clk]
compile_fusion -to logic_opto
report_area

# die 1100 x 1100: 120 um pad ring + 20 um ring-to-core space
initialize_floorplan -die_width 1100 -die_height 1100 -core2die_spacing 140 -row_height 1.4 -no_pins
create_pad_ring -pad_ring_order_config_file pads_n45.cfg
report_pad_ring
puts "ESD [check_esd -max_clamp_distance 500 -max_signals_per_supply 6]"
puts "BOND [check_bond_pads -min_pitch 50]"

# ---- global PG connections: pad ring rails, gate-array cells, area-IO blocks
connect_global_net VDD   -type pg_pin -pin_base_name CORE_VDD -inst_base_name *
connect_global_net VSS   -type pg_pin -pin_base_name CORE_VSS -inst_base_name *
connect_global_net VDDIO -type pg_pin -pin_base_name IO_VDD   -inst_base_name *
connect_global_net VSSIO -type pg_pin -pin_base_name IO_VSS   -inst_base_name *
connect_global_net VDD   -type pg_pin -pin_base_name VDD      -inst_base_name *
connect_global_net VSS   -type pg_pin -pin_base_name VSS      -inst_base_name *
report_global_net_connections

# ---- core power grid (Nangate45 style): metal7 / metal8 rings, metal4 vertical and metal7
#      horizontal stripes, metal1 followpins (0.17 um), via stacks from the LEF via rules
add_rings -nets {VDD VSS} -type core_rings -layer {top metal7 bottom metal7 left metal8 right metal8} -width 4 -spacing 2 -offset 2
add_stripes -nets {VDD VSS} -layer metal4 -direction vertical -width 0.48 -spacing 0.48 -set_to_set_distance 56 -start_offset 10 -extend_to first_ring
add_stripes -nets {VDD VSS} -layer metal7 -direction horizontal -width 1.4 -spacing 1.4 -set_to_set_distance 40 -start_offset 10 -extend_to first_ring
create_followpins -nets {VDD VSS} -layer metal1 -width 0.17 -extend_to core
generate_vias
puts "MV [check_missing_vias]"
report_power_routes
puts "PGLVS [check_lvs -connectivity -type pg]"

place_opt
insert_gate_array_fillers -cells {GFILLER_X16 GFILLER_X8 GFILLER_X4 GFILLER_X2 GFILLER_X1} -prefix ga_fill
check_legality
file mkdir out
write_def out/n45_wirebond.def
write_verilog out/n45_wirebond.v
if {[catch {gui_write_image out/n45_wirebond.png}]} { puts "(layout image needs the GTK build)" }
