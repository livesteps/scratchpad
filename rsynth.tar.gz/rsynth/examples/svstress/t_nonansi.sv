// Non-ANSI ports with signed / reg re-declarations, escaped identifiers, implicit continuous nets
module t_nonansi (a, b, \in.v , y, z, \out[0] );
  input signed [3:0] a;
  input [3:0] b;
  input [1:0] \in.v ;
  output signed [7:0] y;
  output z;
  output \out[0] ;
  reg signed [7:0] y;
  wire [7:0] \sum$x = a + b;
  assign \out[0] = ^\sum$x ^ \in.v [1];
  always @(*) y = a * $signed({1'b0, b});
  assign z = \in.v [0] | (a < 0);
endmodule
