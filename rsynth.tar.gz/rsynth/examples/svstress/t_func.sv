// Functions: automatic, loops, early return, local variables, nested calls, in assign and always
module t_func (input logic [7:0] a, b, input logic [2:0] s, output logic [3:0] pc, output logic [7:0] mx, r, g, output logic [15:0] m2, output logic [2:0] lz);
  function automatic logic [3:0] popcnt(input logic [7:0] v);
    logic [3:0] c; c = 0;
    for (int i = 0; i < 8; i++) c += v[i];
    return c;
  endfunction
  function automatic logic [7:0] max2(input logic [7:0] x, y);
    if (x > y) return x;
    return y;
  endfunction
  function logic [7:0] rev8(input [7:0] v);
    integer i;
    for (i = 0; i < 8; i = i + 1) rev8[i] = v[7 - i];
  endfunction
  function automatic [7:0] bin2gray(input [7:0] v); bin2gray = v ^ (v >> 1); endfunction
  function automatic logic [15:0] mul_add(input logic [7:0] x, input logic [7:0] y, input logic [2:0] k);
    logic [15:0] t;
    t = x * y;
    t = t + k;
    mul_add = t;
  endfunction
  function automatic logic [2:0] lzc(input logic [7:0] v);
    for (int i = 7; i >= 0; i--) if (v[i]) return 3'(7 - i);
    return 3'd7;
  endfunction
  assign pc = popcnt(a ^ b);
  assign mx = max2(max2(a, b), {5'b0, s});
  always_comb r = rev8(a);
  assign g = bin2gray(b);
  assign m2 = mul_add(a, b, s);
  assign lz = lzc(a);
endmodule
