// Loops with compile-time bounds: repeat, while, do-while, foreach, break, continue, nested
module t_loops (input logic [7:0] a, b, input logic [15:0] w,
  output logic [7:0] o1, o2, o3, o4, o5, o6, output logic [3:0] o7);
  logic [3:0] arr [4];
  always_comb begin
    o1 = 0;
    repeat (3) o1 = o1 + a;
  end
  always_comb begin
    int k;
    k = 0; o2 = b;
    while (k < 4) begin o2 = o2 ^ (a >> k); k++; end
  end
  always_comb begin
    int k;
    k = 0; o3 = 0;
    do begin o3 = o3 + 8'(k); k += 2; end while (k < 7);
  end
  always_comb begin
    for (int i = 0; i < 4; i++) arr[i] = w[i*4 +: 4];
    o4 = 0;
    foreach (arr[j]) o4 = o4 + arr[j];
  end
  always_comb begin
    o5 = 8'hFF;
    for (int i = 0; i < 8; i++) begin
      if (a[i]) begin o5 = 8'(i); break; end        // lowest set bit
    end
  end
  always_comb begin
    o6 = 0;
    for (int i = 0; i < 8; i++) begin
      if (b[i]) continue;
      o6 = o6 + 1;                                     // number of zero bits
    end
  end
  always_comb begin
    o7 = 0;
    for (int i = 0; i < 4; i++)
      for (int j = 0; j < 4; j++)
        if (i != j && w[i*4+j]) o7 = o7 + 1;
  end
endmodule
