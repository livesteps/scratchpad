// Preprocessor: define with arguments, ifdef / ifndef / elsif / else, nested, undef, line continuation
// defines: WIDE=1 USE_XOR
`define MAX(a, b) ((a) > (b) ? (a) : (b))
`define W 8
`define TWICE(x) \
   ((x) << 1)
`ifdef WIDE
  `define OW 16
`else
  `define OW 8
`endif
module t_preproc (input logic [`W-1:0] a, b, output logic [`OW-1:0] o1, output logic [7:0] o2, o3);
  assign o1 = `MAX(a, b) + `TWICE(a);
`ifdef USE_XOR
  `ifndef NOPE
  assign o2 = a ^ b;
  `else
  assign o2 = 0;
  `endif
`elsif USE_AND
  assign o2 = a & b;
`else
  assign o2 = a | b;
`endif
`undef W
`ifdef W
  assign o3 = 8'hFF;
`else
  assign o3 = `MAX(a, 8'd100);
`endif
endmodule
