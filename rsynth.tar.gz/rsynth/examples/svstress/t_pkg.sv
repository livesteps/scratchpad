// Packages: parameters, typedefs, enums, functions; import p::*, explicit p::name, typed package constants
package t_cfg_pkg;
  parameter int WIDTH = 8;
  localparam logic [7:0] MAGIC = 8'hC3;
  typedef enum logic [2:0] { OP_ADD, OP_SUB, OP_AND = 3'd4, OP_OR, OP_XOR } op_e;
  typedef struct packed { op_e op; logic [WIDTH-1:0] a; } cmd_t;
  function automatic logic [WIDTH-1:0] alu(input op_e op, input logic [WIDTH-1:0] x, y);
    case (op)
      OP_ADD: return x + y;
      OP_SUB: return x - y;
      OP_AND: return x & y;
      OP_OR:  return x | y;
      OP_XOR: return x ^ y;
      default: return MAGIC;
    endcase
  endfunction
endpackage
module t_pkg import t_cfg_pkg::*; (input logic [2:0] op, input logic [7:0] a, b,
  output logic [7:0] y, z, output logic [10:0] c, output logic is_or, output logic [2:0] nxt);
  cmd_t cmd;
  assign cmd.op = op_e'(op);
  assign cmd.a = a;
  assign y = alu(cmd.op, cmd.a, b);
  assign z = t_cfg_pkg::alu(t_cfg_pkg::OP_XOR, a, t_cfg_pkg::MAGIC);
  assign c = cmd;
  assign is_or = (cmd.op == OP_OR);
  assign nxt = OP_OR + 3'd1;          // enum constant in arithmetic: base type width
endmodule
