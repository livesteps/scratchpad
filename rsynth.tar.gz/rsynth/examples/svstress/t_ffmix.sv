// Clocked blocks: blocking temporaries, several nonblocking writes (last wins), named-block locals,
// reading a register after a nonblocking write (old value), conditional temporaries
module t_ffmix (input logic clk, rst, input logic [7:0] a, b, input logic s,
  output logic [7:0] q1, q2, q3, q4, output logic [8:0] acc);
  always_ff @(posedge clk) begin : blk
    logic [7:0] t;
    t = a + b;
    q1 <= t;
    t = t ^ 8'hFF;
    q2 <= t;
  end
  always_ff @(posedge clk) begin
    q3 <= a;
    if (s) q3 <= b;
    q4 <= q3;              // old value of q3
    if (rst) q4 <= 0;
  end
  always_ff @(posedge clk)
    if (rst) acc <= 0;
    else acc <= acc[7:0] + (s ? a : b);
endmodule
