// SV extras: inside, casts, $bits / $size, logic init, ++ / --, streaming, int / byte / shortint types
module t_misc_sv (input logic [7:0] a, b, input logic [3:0] s,
  output logic o_in, o_in2, output logic [15:0] c16, output logic [3:0] c4, output logic [7:0] sz, output byte sb, output shortint sh,
  output logic [7:0] rv, output int iv, output logic [7:0] bits2, output logic signed [7:0] scast);
  assign o_in = a inside {8'd1, 8'd3, [8'd10:8'd20]};
  assign o_in2 = s inside {[0:3], 4'hF};
  assign c16 = 16'(a) << 4;
  assign c4 = 4'(a + b);
  assign sz = $bits(c16) + $size(a);
  assign sb = byte'(a) >>> 2;
  assign sh = shortint'(signed'(b)) * 2;
  assign rv = {<<{a}};
  assign iv = int'(a) - int'(b);
  assign bits2 = {<<2{b}};
  assign scast = signed'(a) / 2;
endmodule
