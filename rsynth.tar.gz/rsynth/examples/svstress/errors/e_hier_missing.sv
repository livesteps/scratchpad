module e_hier_missing (input logic a, output logic y);
  for (genvar i = 0; i < 2; i++) begin : g logic x; assign x = a; end
  assign y = g[5].x;
endmodule
