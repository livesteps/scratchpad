module e_undecl (input logic a, output logic y);
  assign y = a & nope;
endmodule
