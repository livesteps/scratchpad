`define F(a, b) (a + b)
module e_macro_args (input logic [3:0] a, output logic [3:0] y);
  assign y = `F(a;
endmodule
