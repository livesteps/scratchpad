typedef struct packed { logic [3:0] a; logic [3:0] b; } s_t;
module e_pattern_count (output s_t y);
  assign y = '{4'd1, 4'd2, 4'd3};
endmodule
