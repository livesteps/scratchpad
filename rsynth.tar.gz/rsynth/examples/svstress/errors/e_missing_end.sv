module e_missing_end (input logic a, output logic y);
  assign y = a;
