module e_while_var (input logic [3:0] n, output logic [7:0] y);
  always_comb begin int k; k = 0; y = 0; while (k < n) begin y++; k++; end end
endmodule
