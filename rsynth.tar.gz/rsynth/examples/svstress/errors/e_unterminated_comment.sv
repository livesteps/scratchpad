module e_unterminated_comment (input logic a, output logic y);
  assign y = a; /* never closed
endmodule
