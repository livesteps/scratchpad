typedef struct packed { logic a; logic b; } s_t;
module e_bad_member (input s_t x, output logic y);
  assign y = x.c;
endmodule
