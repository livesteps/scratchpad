module e_neg_repl #(parameter N = -2) (input logic a, output logic [3:0] y);
  assign y = {N{a}};
endmodule
