module e_noconst_loop (input logic [3:0] n, output logic [7:0] y);
  always_comb begin y = 0; for (int i = 0; i < n; i++) y = y + 1; end
endmodule
