module e_range (input logic [3:0] a, output logic [3:0] y);
  assign y = a[7:4];
endmodule
