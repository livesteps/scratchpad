module e_iter_limit (output logic [7:0] y);
  always_comb begin y = 0; for (int i = 0; i >= 0; i++) y = y + 1; end
endmodule
