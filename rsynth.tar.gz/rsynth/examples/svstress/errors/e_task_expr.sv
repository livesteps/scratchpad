module e_task_expr (input logic [3:0] a, output logic [3:0] y);
  task automatic t(input logic [3:0] x, output logic [3:0] z); z = x; endtask
  assign y = t(a, y);
endmodule
