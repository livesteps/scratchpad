module e_recursive (input logic a, output logic y);
  e_recursive u (.a(a), .y(y));
endmodule
