// Procedural combinational: defaults then overrides, temporaries, if/else chains, loops, compound ops
module t_comb_proc (input logic [7:0] a, b, input logic [3:0] s,
  output logic [7:0] y1, y2, y3, output logic [3:0] cnt, lead, output logic [7:0] rev, output logic par);
  logic [7:0] t;
  always_comb begin
    t = a;
    t = t + b;           // blocking temp reuse
    y1 = t ^ a;
    if (s[0]) y1 = y1 + 1;
    else if (s[1]) y1 -= 2;
    else y1 <<= 1;
  end
  always @(*) begin
    y2 = 0;
    if (s == 4'd3) y2 = a;
    if (s > 4'd8) y2 = b;  // later if has priority
  end
  always_comb begin
    cnt = 0;
    for (int i = 0; i < 8; i++) cnt = cnt + a[i];
  end
  always_comb begin
    lead = 4'd8;
    for (int i = 0; i < 8; i = i + 1) if (b[i]) lead = i[3:0];   // highest set bit
  end
  always_comb begin
    for (int i = 0; i < 8; i++) rev[i] = a[7-i];
  end
  always_comb begin
    par = 0;
    for (int i = 7; i >= 0; i--) par ^= b[i];
  end
  always_comb begin
    y3 = a;
    y3++;
    y3 *= 2;
    y3 |= {4'b0, s};
    y3 ^= b;
    y3 >>= 1;
  end
endmodule
