// Unpacked arrays: whole-array copy and compare, assignment patterns, parameter lookup tables,
// unpacked array ports, arrays of packed arrays
module t_asum (input logic [7:0] v [4], output logic [9:0] s);
  always_comb begin s = 0; foreach (v[i]) s += v[i]; end
endmodule
module t_arrays (input logic clk, input logic [7:0] a, b, input logic [1:0] i, input logic [2:0] k,
  output logic [7:0] o1, o2, o3, output logic [9:0] o4, output logic o5, output logic [7:0] o6, o7);
  localparam logic [7:0] LUT [8] = '{8'd3, 8'd1, 8'd4, 8'd1, 8'd5, 8'd9, 8'd2, 8'd6};
  logic [7:0] x [4], y [4];
  logic [3:0][7:0] pk [2];
  always_comb begin
    x = '{a, b, a ^ b, 8'hAA};
    y = x;
    y[i] = 8'h00;
  end
  assign o1 = x[i] + y[3 - i];
  assign o2 = LUT[k];
  assign o3 = LUT[3] * 8'd10 + LUT[k ^ 3'd7];
  t_asum u_sum (.v(x), .s(o4));
  assign o5 = (x == y);
  always_comb begin
    pk = '{default: '0};
    pk[0][i] = a;
    pk[1] = {b, a, b, a};
  end
  assign o6 = pk[0][i] ^ pk[1][k[1:0]];
  always_ff @(posedge clk) o7 <= LUT[a[2:0]] ^ LUT[b[2:0]];
endmodule
