// Very wide arithmetic: > 128-bit add / compare / shift / multiply, wide parameters, wide constants
module t_wide (input logic [199:0] a, b, input logic [7:0] s, input logic [63:0] m, n,
  output logic [200:0] sum, output logic [199:0] dif, sh, x1, output logic lt, eq, output logic [127:0] prod, output logic [199:0] k);
  localparam logic [199:0] K = 200'hF_0123_4567_89AB_CDEF_FEDC_BA98_7654_3210_0F0F_F0F0_1234_5678;
  localparam logic signed [159:0] NEG = -160'sd5;
  assign sum = a + b;
  assign dif = a - b;
  assign sh = a >> s;
  assign x1 = a ^ K;
  assign lt = a < b;
  assign eq = a[199:130] == b[69:0];
  assign prod = m * n;
  assign k = K + NEG;                    // NEG sign-extended to 200 bits
endmodule
