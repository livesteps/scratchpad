// Flops not covered by the asynchronous reset hold their value while reset is active;
// partial vector assignments in branches; negedge clock; reset to parameter / expression
module t_seq2 #(parameter [7:0] INIT = 8'h3C) (input logic clk, rst_n, en, input logic [7:0] d, input logic [1:0] m,
  output logic [7:0] a, b, c, output logic [7:0] v, output logic [3:0] n);
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) a <= 0;
    else begin a <= d; b <= d ^ a; end       // b: no reset, holds during reset
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) c <= INIT ^ 8'h01;
    else if (en) c <= c + 1;
  always_ff @(posedge clk) begin
    case (m)
      2'd0: v[3:0] <= d[3:0];
      2'd1: v[7:4] <= d[7:4];
      2'd2: begin v[0] <= 1'b1; v[7] <= ~v[7]; end
      default: v <= ~v;
    endcase
  end
  always_ff @(negedge clk) n <= d[3:0] + n;
endmodule
