// Sequential: async / sync reset, enables, nonblocking swap, counters, shift registers
module t_seq (input logic clk, rst_n, srst, en, input logic [7:0] d, input logic [1:0] mode,
  output logic [7:0] q1, q2, q3, cnt, output logic [3:0] sh, output logic [7:0] x, y, output logic t);
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) q1 <= 8'h5A; else if (en) q1 <= d;
  always_ff @(posedge clk)
    if (srst) q2 <= 0; else q2 <= q2 + d;
  always_ff @(posedge clk or negedge rst_n) begin
    if (~rst_n) begin cnt <= 0; q3 <= 0; end
    else begin
      case (mode)
        2'd0: cnt <= cnt + 1;
        2'd1: cnt <= cnt - 1;
        2'd2: cnt <= d;
        default: ;
      endcase
      q3 <= cnt;          // old value
    end
  end
  always_ff @(posedge clk) sh <= {sh[2:0], d[0]};
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin x <= 8'd1; y <= 8'd2; end
    else if (en) begin x <= y; y <= x; end   // swap
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) t <= 0; else t <= t ^ d[7];
endmodule
