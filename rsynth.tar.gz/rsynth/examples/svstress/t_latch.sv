// always_latch / inferred latch with enable, latch with reset, mixed with comb logic
module t_latch (input logic en, rst, input logic [7:0] d, output logic [7:0] q1, q2);
  always_latch if (en) q1 = d;
  always_latch if (rst) q2 <= 0; else if (en) q2 <= d ^ 8'h0F;
endmodule
