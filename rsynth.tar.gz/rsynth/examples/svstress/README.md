# SystemVerilog parse / elaboration stress suite

Each `t_*.sv` exercises one area of the language. `svcheck.py` elaborates it with RSynth,
writes the generic netlist and simulates the RTL against the netlist with random stimulus
(Icarus Verilog, or Verilator where Icarus cannot read the construct or deviates from
IEEE 1800). Ports and widths are taken from the netlist; a port-width warning on the
reference counts as a failure.

    python3 svcheck.py                 # all tests (RTL vs elaborated netlist)
    python3 svcheck.py --compile       # also map to rs28 and verify_equivalence
    python3 svcheck.py t_case.sv       # one test
    ./check_errors.sh                  # malformed RTL: clear errors, no panic / hang
    python3 fuzz.py 10 1               # mutated tests: no panic / hang

Markers in a test file: `// cycles: N`, `// defines: A B=1`, `// sim: verilator`.

| Area | Tests |
|------|-------|
| Operators, widths, signedness | t_arith, t_signed, t_signed3, t_shift, t_logic, t_ctxwidth, t_literals, t_wide, t_constexpr |
| Selects | t_bitsel, t_packed, t_memory, t_memory2, (examples/partselect) |
| Procedural | t_comb_proc, t_case, t_casex, t_wild, t_uniqueif, t_loops, t_compound, t_latch |
| Sequential | t_seq, t_seq2, t_ffmix, t_init |
| Functions / tasks | t_func, t_tasks, t_constfn, t_structio |
| Types | t_packed, t_struct2, t_structio, t_pkg, t_arrays, t_misc_sv |
| Parameters | t_params, t_params2, t_constfn |
| Hierarchy / generate | t_hier, t_portext, t_generate, t_gen2, t_hierref, t_iface, t_iface2 |
| Syntax / preprocessor | t_syntax, t_v2001, t_nonansi, t_preproc, t_preproc2 |
