// Hierarchy: positional / named / .* / .name connections, unconnected and width-mismatched ports, expressions, instance arrays
module t_add #(parameter W = 4) (input logic [W-1:0] a, b, input logic ci, output logic [W-1:0] s, output logic co);
  assign {co, s} = a + b + ci;
endmodule
module t_inv (input logic [3:0] i, output logic [3:0] o); assign o = ~i; endmodule
module t_hier (input logic [7:0] a, b, input logic ci, output logic [7:0] s, output logic co, output logic [7:0] w1, output logic [15:0] w2, output logic [15:0] ia, output logic [3:0] x);
  logic c0;
  t_add #(4) lo (a[3:0], b[3:0], ci, s[3:0], c0);
  t_add #(.W(4)) hi (.a(a[7:4]), .b(b[7:4]), .ci(c0), .s(s[7:4]), .co(co));
  t_add #(8) nar (.a(a[3:0]), .b(16'hFFFF), .ci(1'b0), .s(w1), .co());   // a zero-extended, b truncated
  t_add #(16) wid (.a(a), .b(~b), .ci(), .s(w2), .co());                  // ci unconnected (z -> x)
  t_inv arr [3:0] (.i({a[3:0], b[3:0], a[7:4], b[7:4]}), .o(ia));
  logic [3:0] i;
  assign i = a[5:2] ^ b[3:0];
  t_inv u_dot (.i, .o(x));
endmodule
