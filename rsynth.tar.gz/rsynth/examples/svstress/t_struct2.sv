// Nested structs, arrays of structs (packed and unpacked), unions, signed structs,
// struct assignment patterns, member selects with variable index
typedef struct packed { logic [3:0] a; logic [3:0] b; } pair_t;
typedef struct packed { pair_t p; logic [1:0] tag; logic v; } rec_t;     // 11 bits
typedef union packed { pair_t pr; logic [7:0] w; struct packed { logic [1:0] x; logic [5:0] y; } xy; } u8_t;
typedef struct packed signed { logic [3:0] hi; logic [3:0] lo; } sp_t;
module t_struct2 (input logic [7:0] a, b, input logic [1:0] i, input logic [2:0] t,
  output logic [3:0] o1, o2, output logic [10:0] o3, output logic [7:0] o4, o5, output logic [5:0] o6, output logic [15:0] o7,
  output logic [3:0] o8, output logic [7:0] o9, output logic [7:0] o10, output logic o11, output logic [7:0] o12);
  rec_t r;
  pair_t [3:0] pa;            // packed array of structs
  pair_t ua [0:3];            // unpacked array of structs
  u8_t u;
  sp_t s;
  always_comb begin
    r = '0;
    r.p.a = a[7:4];
    r.p.b = b[3:0];
    r.tag = t[1:0];
    r.v = ^a;
  end
  assign o1 = r.p.a ^ r.p.b;
  assign o3 = r;
  always_comb begin
    pa = {a, b, ~a, ~b};
    pa[i].b = 4'h5;
    for (int k = 0; k < 4; k++) ua[k] = pa[k];
  end
  assign o2 = pa[i].a;
  assign o4 = ua[i];
  assign o8 = ua[3 - i].b;
  always_comb begin u.w = a; u.xy.x = b[1:0]; end
  assign o5 = u.pr;
  assign o6 = u.xy.y;
  assign s = a;
  assign o7 = s;              // signed struct: sign-extended
  assign o9 = pair_t'{a: b[3:0], b: a[3:0]};
  pair_t pq;
  assign pq = '{b: t, a: ~b[3:0]};          // typed by the target
  assign o12 = pq;
  always_comb o10 = pair_t'{default: t[0] ? 4'hF : 4'h1};
  assign o11 = (r.p == pair_t'(a)) || (pa[0] == pa[1]);
endmodule
