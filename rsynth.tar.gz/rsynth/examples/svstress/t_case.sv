// case / casez / casex / case inside / unique / priority, overlap priority, default positions
module t_case (input logic [3:0] s, input logic [7:0] a, b, input logic signed [3:0] ss,
  output logic [7:0] o1, o2, o3, o4, o5, o6);
  always_comb begin
    case (s)
      4'd0, 4'd1: o1 = a;
      4'd2: o1 = b;
      4'd2: o1 = 8'hFF;              // never reached (first match wins)
      4'd3 + 4'd1: o1 = a ^ b;       // expression label
      default: o1 = 8'h00;
    endcase
  end
  always_comb begin
    casez (s)
      4'b1???: o2 = 8'd1;
      4'b01?1: o2 = 8'd2;
      4'b0?1?: o2 = 8'd3;
      default: o2 = 8'd4;
    endcase
  end
  always_comb begin
    o3 = 8'd7;
    casex (s)
      4'b1x0x: o3 = a;
      4'bx11x: o3 = b;
    endcase
  end
  always_comb begin
    case (s) inside
      [4'd0:4'd3]: o4 = 8'd10;
      4'd5, [4'd8:4'd9]: o4 = 8'd20;
      4'b11??: o4 = 8'd30;
      default: o4 = 8'd40;
    endcase
  end
  always_comb begin
    unique case (s[1:0])
      2'd0: o5 = a; 2'd1: o5 = b; 2'd2: o5 = a & b; 2'd3: o5 = a | b;
    endcase
  end
  always_comb begin
    case (ss)
      -4'sd1: o6 = 8'd1;
      -4'sd8: o6 = 8'd2;
      4'sd7: o6 = 8'd3;
      default: o6 = 8'd0;
    endcase
  end
endmodule
