// sim: verilator   (Icarus evaluates untyped parameter expressions without truncation)
// Parameter typing: a range / type sets width and signedness; an untyped parameter takes the
// type of its value; overrides; selects of parameters; truncation of typed localparams
module t_pv #(parameter P = 4'b1010, parameter [7:0] R = 8'h0F) (input logic [7:0] a, output logic [15:0] o1, o2);
  assign o1 = {P, P, R};
  assign o2 = ~R;
endmodule
module t_params2 (input logic [7:0] a, input logic [3:0] s,
  output logic [15:0] o1, o2, o3, o4, o5, o6, o7, o8, output logic [3:0] o9, o10, output logic [15:0] c1, c2, c3, c4);
  parameter [7:0] P8 = 8'hF0;
  localparam Q = 4'b1010;
  localparam signed [7:0] N = -3;
  localparam [3:0] T = 4'hF + 1;
  localparam integer I = -1;
  localparam int unsigned U = 32'hFFFF_FFF0;
  localparam W = 8'd200 + 8'd100;     // self-determined: 8 bits
  assign o1 = ~P8;                    // 16-bit context: 16'h000F ^ ... -> 16'hFF0F
  assign o2 = {Q, Q, Q};              // 12 bits
  assign o3 = N >>> 1;
  assign o4 = a + N;                  // N signed but a unsigned: 8'hFD zero-extended
  assign o5 = $signed(a) + N;         // both signed: sign-extended
  assign o6 = T;
  assign o7 = I[15:0] ^ {12'b0, s};
  assign o8 = (U >> 4) ^ W;
  assign o9 = P8[7:4] ^ s;
  assign o10 = Q[s[1:0]] ? 4'd1 : 4'd2;
  t_pv u1 (.a(a), .o1(c1), .o2(c2));
  t_pv #(.P(6'b110011), .R(8'hA5)) u2 (.a(a), .o1(c3), .o2(c4));
endmodule
