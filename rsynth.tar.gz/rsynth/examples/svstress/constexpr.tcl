# Constant expressions (IEEE width / signedness rules) elaborated to constant outputs
file mkdir out
analyze -format sverilog t_constexpr.sv
elaborate t_constexpr
write_verilog out/t_constexpr_gen.v
puts "CONSTEXPR_DONE"
