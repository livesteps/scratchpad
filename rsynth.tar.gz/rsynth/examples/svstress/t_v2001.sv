// Verilog-2001 style: non-ANSI ports, reg declarations, integer, named blocks, @(a or b), functions with 'input' list
module t_v2001 (clk, a, b, sel, y, z, q);
  input clk;
  input [7:0] a, b;
  input [1:0] sel;
  output [7:0] y;
  output reg [7:0] z;
  output q;
  reg [7:0] y;
  reg q;
  integer i;
  always @(a or b or sel) begin : blk
    reg [7:0] tmp;
    tmp = a & b;
    case (sel)
      2'b00: y = tmp;
      2'b01: y = a | b;
      2'b10: y = a ^ tmp;
      default: y = ~a;
    endcase
  end
  always @(a) begin
    z = 0;
    for (i = 0; i < 8; i = i + 1) z = z + {7'b0, a[i]};
  end
  always @(posedge clk) q <= ^y;
endmodule
