// Literals: bases, underscores, unsized fills, wide constants (>64 bits), truncation, x in compare
module t_literals (input logic [127:0] a, input logic [7:0] b,
  output logic [127:0] o1, o2, o3, o4, output logic [7:0] f0, f1, o5, o6, output logic [99:0] o7, output logic m1, m2);
  assign o1 = a ^ 128'hDEAD_BEEF_0123_4567_89AB_CDEF_F0E1_D2C3;
  assign o2 = a + 128'd1;
  assign o3 = a & '1;
  assign o4 = {64'hFFFF_FFFF_FFFF_FFFF, 64'h0} | a;
  assign f0 = '0;
  assign f1 = '1;
  assign o5 = b + 'd300;               // unsized 32-bit constant, truncated result
  assign o6 = b ^ 8'b1010_zz01 & 8'hF3 | 8'o17;
  assign o7 = 100'h1 << b[6:0];
  assign m1 = b == 8'd255;
  assign m2 = (a[127:64] == 64'hFFFF_FFFF_FFFF_FFFF);
endmodule
