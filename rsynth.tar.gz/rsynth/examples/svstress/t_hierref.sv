// References into generate scopes and named blocks, including before the block is declared
module t_hierref (input logic [7:0] a, output logic [7:0] o1, o2, o3);
  assign o1 = g_late[0].x + g_late[1].x;        // forward reference
  for (genvar i = 0; i < 2; i++) begin : g_late
    logic [7:0] x;
    assign x = a << i;
  end
  if (1) begin : g_one
    logic [7:0] y;
    assign y = ~a;
  end
  assign o2 = g_one.y;
  for (genvar i = 0; i < 3; i++) begin : g_n
    for (genvar j = 0; j < 2; j++) begin : g_m
      wire [7:0] z = a + 8'(i * 10 + j);
    end
  end
  assign o3 = g_n[2].g_m[1].z ^ g_n[0].g_m[0].z;
endmodule
