// Interfaces with modports, interface arrays, parameterized interface, functions over interface signals
interface t_bus_if #(parameter W = 8);
  logic [W-1:0] data;
  logic valid, ready;
  modport src (output data, valid, input ready);
  modport dst (input data, valid, output ready);
endinterface
module t_isrc (t_bus_if.src b, input logic [7:0] d, input logic v);
  assign b.data = d + 8'd1;
  assign b.valid = v;
endmodule
module t_idst (t_bus_if.dst b, output logic [7:0] q, output logic ok);
  assign q = b.valid ? b.data : 8'h00;
  assign b.ready = ^b.data;
  assign ok = b.ready & b.valid;
endmodule
module t_iface (input logic [7:0] d0, d1, input logic v0, v1, output logic [7:0] q0, q1, output logic ok0, ok1, r);
  t_bus_if #(.W(8)) bus [2] ();
  t_isrc s0 (.b(bus[0]), .d(d0), .v(v0));
  t_isrc s1 (.b(bus[1]), .d(d1), .v(v1));
  t_idst k0 (.b(bus[0]), .q(q0), .ok(ok0));
  t_idst k1 (.b(bus[1]), .q(q1), .ok(ok1));
  assign r = bus[0].ready ^ bus[1].valid;
endmodule
