// Packed structs / unions / multi-dimensional packed arrays, enums, typedefs, member lvalues
typedef enum logic [1:0] { IDLE = 2'd0, RUN = 2'd2, DONE = 2'd3 } st_e;
typedef struct packed { logic [3:0] hi; logic [2:0] mid; logic lo; } fld_t;
typedef union packed { fld_t f; logic [7:0] raw; } u_t;
module t_packed (input logic [7:0] a, input logic [31:0] w, input logic [1:0] i, j, input logic [2:0] k,
  output logic [7:0] o1, o2, output logic [3:0] o3, output logic [7:0] o4, o5, output logic [31:0] o6, output logic [1:0] o7, output logic [2:0] o8, output logic o9);
  fld_t f; u_t u;
  logic [3:0][7:0] arr;
  logic [1:0][1:0][3:0] cube;
  st_e st;
  assign f = a;
  assign o1 = {f.lo, f.mid, f.hi};
  always_comb begin u.raw = a; u.f.mid = 3'b101; o2 = u.raw; end
  assign o3 = f.hi + f.mid;
  assign arr = w;
  assign o4 = arr[i];
  assign o5 = arr[2] ^ arr[i][7:0];
  always_comb begin
    cube = w;
    cube[i[0]][j[0]] = 4'hA;          // in range: simulators differ on out-of-range packed writes
    o6 = cube;
  end
  assign st = st_e'(a[1:0]);
  assign o7 = (st == RUN) ? 2'd1 : (st == DONE) ? 2'd2 : 2'd0;
  assign o8 = arr[3][k +: 3];
  assign o9 = cube[1][0][k[1:0]];
endmodule
