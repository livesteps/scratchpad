// Generate: descending genvar loops, genvar expressions, localparams per iteration, if inside for,
// nested instance arrays, generate-case on a genvar
module t_gleaf #(parameter int K = 0) (input logic [7:0] i, output logic [7:0] o);
  assign o = i + 8'(K);
endmodule
module t_gen2 #(parameter int N = 5) (input logic [7:0] a, output logic [N*8-1:0] o1, output logic [7:0] o2, output logic [N-1:0] o3);
  for (genvar g = N - 1; g >= 0; g--) begin : gd
    localparam int SQ = g * g;
    if (g % 2 == 0) begin : ev
      t_gleaf #(.K(SQ)) u (.i(a), .o(o1[g*8 +: 8]));
    end else begin : od
      assign o1[g*8 +: 8] = a ^ 8'(SQ);
    end
    case (g)
      0: begin : c assign o3[g] = a[0]; end
      1, 2: begin : c assign o3[g] = a[g] & a[g+1]; end
      default: begin : c assign o3[g] = ^a[g:0]; end
    endcase
  end
  assign o2 = gd[4].ev.u.o ^ gd[3].SQ[7:0];
endmodule
