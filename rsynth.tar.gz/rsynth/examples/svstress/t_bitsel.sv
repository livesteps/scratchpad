// Variable bit / part selects on offset, ascending and signed vectors; constant out-of-range selects
module t_bitsel (input logic [15:8] hi, input logic [0:7] asc, input logic signed [7:0] sv, input logic [3:0] i, input logic [2:0] j,
  output logic b1, b2, b3, output logic [3:0] p1, p2, output logic [7:0] w1, output logic [15:0] w2);
  assign b1 = hi[i + 4'd8];
  assign b2 = asc[j];
  assign b3 = sv[j];
  assign p1 = hi[i[1:0] * 2 + 8 +: 4];
  assign p2 = asc[j[1:0] +: 4];
  always_comb begin
    w1 = 8'h00;
    w1[j] = 1'b1;
    w1[j ^ 3'd7] = hi[15];
  end
  assign w2 = sv[j +: 2] + 16'sd0;      // part-select is unsigned
endmodule
