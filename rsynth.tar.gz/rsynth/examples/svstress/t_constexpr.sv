// Constant expressions covering IEEE width / signedness rules (outputs are constants; the
// expected values are also checked without a simulator by tests/flows.rs)
module t_constexpr (input logic unused, output logic [15:0] c0, c1, c2, c3, c4, c5, c6, c7, c8, c9,
  output logic [15:0] c10, c11, c12, c13, c14, c15, c16, c17, c18, c19, output logic [15:0] c20, c21, c22, c23, c24, c25);
  localparam logic signed [7:0] SN = -8'sd3;
  localparam logic [7:0] U8 = 8'hF0;
  localparam P4 = 4'b1010;
  localparam W8 = 8'd200 + 8'd100;
  typedef struct packed { logic [3:0] a; logic signed [3:0] b; } s_t;
  localparam s_t S = '{a: 4'h9, b: -4'sd2};
  function automatic int f(input int n); return n <= 1 ? 1 : n * f(n - 1); endfunction
  assign c0  = SN;                       // sign-extended: FFFD
  assign c1  = U8;                       // zero-extended: 00F0
  assign c2  = ~U8;                      // 16-bit ~: FF0F
  assign c3  = SN + 8'd1;                // unsigned operand: 00FE
  assign c4  = SN + 8'sd1;               // signed: FFFE
  assign c5  = {P4, P4};                 // 4-bit parameter: 00AA
  assign c6  = W8;                       // 8-bit value: 002C
  assign c7  = -8'sd128 / -8'sd1;        // 8'sd128 is -128, negated +128, / -1: FF80
  assign c8  = 8'sd7 / -8'sd2;           // truncates toward zero: FFFD
  assign c9  = -8'sd7 % 8'sd2;           // sign of dividend: FFFF
  assign c10 = SN >>> 1;                 // FFFE
  assign c11 = $unsigned(SN) >> 1;       // 007E
  assign c12 = 2 ** 10;                  // 0400
  assign c13 = (-3) ** 3;                // FFE5
  assign c14 = 16'(4'hF + 4'h1);         // 4-bit operands in 16-bit cast context: 0010
  assign c15 = {<<4{16'hABCD}};          // DCBA
  assign c16 = S.b;                      // signed member: FFFE
  assign c17 = S;                        // 009E
  assign c18 = f(6);                     // 02D0
  assign c19 = (8'hFF == -1) ? 16'd1 : 16'd2;          // unsigned compare: 0002
  assign c20 = ($signed(8'hFF) == -1) ? 16'd1 : 16'd2; // signed: 0001
  assign c21 = (~8'h00 == 0) ? 16'd1 : 16'd2;          // ~ in 32-bit context: 0002
  assign c22 = 4'b1010 ==? 4'b1x1z;      // 0001
  assign c23 = $countones(16'hF0F3) + $clog2(17); // 10 + 5 = 000F
  assign c24 = 16'(SN);                  // FFFD
  assign c25 = {8{1'b1}} + 1;            // 32-bit: 0100
endmodule
