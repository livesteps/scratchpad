// Constant functions in parameters and ranges, recursion at elaboration, $clog2 / $bits / $size of params
module t_constfn #(parameter int N = 12) (input logic [N-1:0] a, output logic [$clog2(N)-1:0] lg, output logic [7:0] f5, output logic [N-1:0] y, output logic [7:0] sz);
  function automatic int fact(input int k);
    if (k <= 1) return 1;
    return k * fact(k - 1);
  endfunction
  function automatic int nbits(input int v);
    int r; r = 0;
    while (v > 0) begin r++; v = v >> 1; end
    return r;
  endfunction
  localparam int F5 = fact(5);                 // 120
  localparam int NB = nbits(N * 3);            // 6
  localparam logic [N-1:0] MASK = (1 << NB) - 1;
  logic [NB-1:0] tmp;
  assign tmp = a[NB-1:0];
  assign lg = $clog2(N);
  assign f5 = F5[7:0];
  assign y = a & MASK | {{(N-NB){1'b0}}, ~tmp};
  assign sz = $bits(tmp) + $size(a) + $bits(MASK);
endmodule
