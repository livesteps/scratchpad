// Declaration initializers: nets are continuous, variables get an initial value only
// cycles: 300
module t_init (input logic clk, rst, input logic [7:0] d, output logic [7:0] q, w, c);
  logic [7:0] cnt = 8'd5;              // variable: initial value (ignored for synthesis), driven by the flop
  wire [7:0] ww = d ^ 8'h3C;           // net: continuous assignment
  logic [7:0] kc = 8'hA5;              // never driven: keeps its initial value
  always_ff @(posedge clk) if (rst) cnt <= 8'd1; else cnt <= cnt + 1;
  assign q = cnt;
  assign w = ww;
  assign c = kc;
endmodule
