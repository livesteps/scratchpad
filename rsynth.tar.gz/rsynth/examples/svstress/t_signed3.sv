// More signed rules: selects and concatenations are unsigned, integer arithmetic,
// mixed signed * unsigned, signed division corner cases, signed compare with literals
module t_signed3 (input logic signed [7:0] sa, sb, input logic [7:0] ua, input logic [2:0] k,
  output logic [15:0] o1, o2, o3, o4, o5, o6, output logic signed [7:0] d1, d2, output logic c1, c2, c3, c4, output logic [31:0] i1);
  integer ii;
  assign o1 = sa[7:0];             // part-select: unsigned, zero-extended
  assign o2 = {sa};                // concatenation: unsigned
  assign o3 = sa * 3;              // 3 is signed: signed multiply
  assign o4 = sa * 3'd3;           // unsigned operand: unsigned multiply
  assign o5 = sa * ua;
  assign o6 = $signed({1'b0, ua}) * sb;
  assign d1 = sa / sb;
  assign d2 = sa % (sb | 8'sd1);
  assign c1 = sa > -2;
  assign c2 = sa > 8'hFE;          // unsigned compare
  assign c3 = $signed(ua) < 0;
  assign c4 = sa[7] == 1;
  always_comb begin ii = sa; ii = ii * 5 - ua; i1 = ii >>> k; end
endmodule
