// Shifts: by variable, by >= width, wide shift amount, shift in wider context, rotates
module t_shift (input logic [15:0] a, input logic [4:0] s, input logic [39:0] big,
  output logic [15:0] l, r, out_big, output logic [31:0] wide_l, output logic [15:0] rotl, rotr,
  output logic [7:0] k1, k2, output logic [15:0] by_big, output logic [3:0] onehot);
  assign l = a << s;
  assign r = a >> s;
  assign out_big = a << 20;            // all shifted out
  assign wide_l = a << s;              // 32-bit context keeps the shifted bits
  assign rotl = (a << s[3:0]) | (a >> (16 - s[3:0]));
  assign rotr = {a, a} >> s[3:0];
  assign k1 = 8'h81 << 3'd7;
  assign k2 = 8'sh81 >>> 3'd7;
  assign by_big = a >> big;            // shift amount 40 bits wide
  assign onehot = 4'b1 << s[1:0];
endmodule
