// Preprocessor 2: macro default arguments, nested macros, macro argument with commas in
// parentheses, stringified-free token pasting with ``, include-free ifdef chains, `line markers
// defines: MODE=2
`define ADD3(a, b, c = 8'd1) ((a) + (b) + (c))
`define SEL(m, x, y) ((m) ? (x) : (y))
`define WRAP(e) `SEL(e[0], e, ~e)
`define CAT(p, s) p``s
`define BUS_W 8
module t_preproc2 (input logic [`BUS_W-1:0] a, b, output logic [7:0] o1, o2, o3, o4, output logic [7:0] `CAT(res, _x));
  assign o1 = `ADD3(a, b);
  assign o2 = `ADD3(a, b, {4'h0, a[3:0]});
  assign o3 = `WRAP(a);
  assign o4 = `SEL(a > b, {a[3:0], b[7:4]}, (a ^ b));
`ifdef MODE
  `ifndef UNDEFINED_THING
  assign res_x = (`MODE == 2) ? a - b : a + b;
  `endif
`else
  assign res_x = 0;
`endif
endmodule
