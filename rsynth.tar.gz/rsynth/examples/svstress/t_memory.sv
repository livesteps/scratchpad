// Unpacked arrays: register files, variable index read / write, 2-D, constant init via reset loop
// cycles: 600
module t_memory (input logic clk, rst, we, input logic [2:0] wa, ra, rb, input logic [7:0] wd, input logic [1:0] r2, c2,
  output logic [7:0] qa, qb, qc, output logic [3:0] m2);
  logic [7:0] mem [0:7];
  logic [3:0] grid [2][4];
  always_ff @(posedge clk) begin
    if (rst) for (int i = 0; i < 8; i++) mem[i] <= 8'(i * 3);
    else if (we) mem[wa] <= wd;
  end
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int r = 0; r < 2; r++) for (int c = 0; c < 4; c++) grid[r][c] <= 4'(r * 4 + c);
    end else if (we) grid[r2[0]][c2] <= wd[3:0];
  end
  assign qa = mem[ra];
  assign qb = mem[rb] + mem[3'd7];
  always_ff @(posedge clk) qc <= mem[ra ^ rb];
  assign m2 = grid[r2[1]][c2];
endmodule
