// Context-determined width traps: ~a compared with 0, unsized constants, ternary width,
// arithmetic in comparisons, reductions of expressions, mixed widths in concatenations
module t_ctxwidth (input logic [7:0] a, b, input logic [3:0] c, input logic s,
  output logic e1, e2, e3, e4, e5, output logic [15:0] t1, t2, output logic [8:0] t3, output logic r1, output logic [7:0] k1, output logic [11:0] k2);
  assign e1 = (~a == 0);           // ~a in 32-bit context: never zero
  assign e2 = (~a == 8'd0);        // 8-bit: a == 8'hFF
  assign e3 = (a + b) > 8'd255;    // 9-bit context, carry visible
  assign e4 = (a + b) == 9'h100;
  assign e5 = (c - 4'd5) < 0;      // unsigned: never true
  assign t1 = s ? a : b + 16'h100;
  assign t2 = s ? {a, b} : c;
  assign t3 = a + 1'b1;
  assign r1 = &(a | b) ^ |(c & 4'hA);
  assign k1 = (a * b) >> 8;        // 8-bit context: product truncated before shift
  assign k2 = (a * b) >> 8;        // 12-bit context
endmodule
