// Generate: for (nested), if / else, case, labelled blocks, hierarchical references into generate scopes
module t_gsub #(parameter W = 4, parameter INV = 0) (input logic [W-1:0] i, output logic [W-1:0] o);
  if (INV) begin : g_inv assign o = ~i; end
  else begin : g_buf assign o = i; end
endmodule
module t_generate #(parameter N = 4, parameter MODE = 1) (input logic [15:0] a, input logic [3:0] b, output logic [15:0] o1, o2, output logic [3:0] o3, output logic [7:0] o4, output logic o5);
  genvar i, j;
  for (i = 0; i < N; i++) begin : g_row
    logic [3:0] v;
    for (j = 0; j < 4; j = j + 1) begin : g_col
      assign v[j] = a[i*4+j] ^ b[j];
    end
    assign o1[i*4 +: 4] = v;
  end
  generate
    for (genvar k = 0; k < 4; k++) begin : g_sub
      t_gsub #(.W(4), .INV(k % 2)) u (.i(a[k*4 +: 4]), .o(o2[k*4 +: 4]));
    end
  endgenerate
  if (MODE == 0) begin : g_m assign o3 = b; end
  else if (MODE == 1) begin : g_m assign o3 = ~b; end
  else begin : g_m assign o3 = 0; end
  case (N)
    2: begin : g_c assign o4 = a[7:0]; end
    4: begin : g_c assign o4 = a[15:8] + g_row[1].v; end
    default: begin : g_c assign o4 = 0; end
  endcase
  assign o5 = ^g_row[3].v ^ g_sub[0].u.o[0];
endmodule
