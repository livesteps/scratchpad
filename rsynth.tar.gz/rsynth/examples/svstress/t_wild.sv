// Wildcard equality ==? / !=?, inside with wildcard and ranges, case inside with wildcards
module t_wild (input logic [7:0] a, input logic [3:0] s, output logic w1, w2, w3, w4, output logic [2:0] c);
  assign w1 = a ==? 8'b1??0_??01;
  assign w2 = a !=? 8'bxx11_xxxx;
  assign w3 = s inside {4'b1?0?, 4'd3};
  assign w4 = a inside {[8'd16:8'd31], 8'b0000_00??};
  always_comb
    case (s) inside
      4'b00??: c = 3'd1;
      4'b?1?1: c = 3'd2;
      [4'd8:4'd10]: c = 3'd3;
      default: c = 3'd4;
    endcase
endmodule
