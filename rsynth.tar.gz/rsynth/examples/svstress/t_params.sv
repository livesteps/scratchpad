// Parameters: positional / named overrides, localparams, $clog2, typed params, params in ranges, defaults from params
module t_pchild #(parameter int W = 8, parameter logic [W-1:0] K = '1, parameter D = W / 2) (input logic [W-1:0] i, output logic [W-1:0] o, output logic [$clog2(W)-1:0] lg);
  localparam int H = W - D;
  assign o = (i ^ K) + H;
  assign lg = $clog2(W) - 1;
endmodule
module t_params #(parameter A = 5, localparam B = A * 2 + 1) (input logic [15:0] x, output logic [15:0] o1, output logic [4:0] o2, output logic [2:0] l1, output logic [3:0] l2, output logic [3:0] l3, output logic [7:0] cb);
  localparam [7:0] C = 8'hF0 | A;
  t_pchild #(16, 16'h1234) u1 (.i(x), .o(o1), .lg(l2));
  t_pchild #(.W(5), .D(1)) u2 (.i(x[4:0]), .o(o2), .lg(l1));
  wire [B-1:0] w = x[B-1:0];
  assign l3 = $clog2(B + 1) + $bits(w);
  assign cb = C ^ w[7:0];
endmodule
