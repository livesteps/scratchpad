// unique / priority if, unique0 case, nested ternaries in procedural code, if without else in comb with default
module t_uniqueif (input logic [3:0] s, input logic [7:0] a, b, output logic [7:0] o1, o2, o3);
  always_comb begin
    unique if (s[1:0] == 2'd0) o1 = a;
    else if (s[1:0] == 2'd1) o1 = b;
    else if (s[1:0] == 2'd2) o1 = a + b;
    else o1 = a - b;
  end
  always_comb begin
    o2 = 8'h11;
    priority if (s[3]) o2 = a;
    else if (s[2]) o2 = b;
  end
  always_comb begin
    o3 = 8'hEE;
    unique0 case (s)
      4'd1: o3 = a;
      4'd2: o3 = b;
    endcase
  end
endmodule
