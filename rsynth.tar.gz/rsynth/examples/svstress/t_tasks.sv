// Tasks with output / inout arguments, void functions, function with output argument
module t_tasks (input logic [7:0] a, b, output logic [7:0] s, d, mx, mn, output logic [7:0] acc, output logic [3:0] q, r);
  task automatic sumdiff(input logic [7:0] x, y, output logic [7:0] su, di);
    su = x + y;
    di = x - y;
  endtask
  task automatic minmax(input logic [7:0] x, y, output logic [7:0] hi, output logic [7:0] lo);
    if (x > y) begin hi = x; lo = y; end
    else begin hi = y; lo = x; end
  endtask
  task automatic accum(inout logic [7:0] v, input logic [7:0] k);
    v = v + k;
  endtask
  function automatic void divmod4(input logic [7:0] x, output logic [3:0] qq, output logic [3:0] rr);
    qq = x[7:4] / 4'd3;
    rr = x[3:0] % 4'd5;
  endfunction
  always_comb begin
    sumdiff(a, b, s, d);
    minmax(a, b, mx, mn);
    acc = a;
    accum(acc, b);
    accum(acc, 8'd1);
    divmod4(a ^ b, q, r);
  end
endmodule
