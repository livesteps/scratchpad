// Memories: index narrower / wider than the address range, offset and descending ranges,
// out-of-range writes ignored, out-of-range reads, element-select of signed memories
// cycles: 800
module t_memory2 (input logic clk, rst, we, input logic [1:0] a2, input logic [4:0] a5, input logic [3:0] a4, input logic [7:0] d,
  output logic [7:0] q0, q1, q2, q3, q4, output logic [15:0] q5);
  logic [7:0] m8 [0:7];             // written with a 2-bit index: only m8[0..3]
  logic [7:0] mo [8:15];            // offset range written with a 4-bit index
  logic [7:0] md [5:0];             // descending, written with a 5-bit index (out of range writes ignored)
  logic signed [7:0] ms [4];
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int i = 0; i < 8; i++) begin m8[i] <= 8'(i); mo[i + 8] <= 8'(i + 100); end
      for (int i = 0; i < 6; i++) md[i] <= 8'(200 + i);
      for (int i = 0; i < 4; i++) ms[i] <= -8'sd1 - 8'(i);
    end else if (we) begin
      m8[a2] <= d;
      mo[a4] <= d ^ 8'h55;
      md[a5] <= ~d;
      ms[a2] <= d;
    end
  end
  assign q0 = m8[a5[2:0]];
  assign q1 = mo[a4];
  assign q2 = (a5 < 6) ? md[a5] : 8'h00;
  assign q3 = m8[4] ^ m8[7];        // never written after reset
  assign q4 = mo[4'd8] + md[0];
  assign q5 = ms[a2];               // signed element: sign-extended
endmodule
