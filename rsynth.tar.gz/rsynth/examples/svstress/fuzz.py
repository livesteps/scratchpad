#!/usr/bin/env python3
"""Robustness fuzz: mutate the stress tests (delete / duplicate / swap tokens) and check that
RSynth never panics or hangs on the result.   fuzz.py [mutants-per-file] [seed]"""
import glob, os, random, re, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE)
RS = os.path.join(HERE, '..', '..', 'target', 'release', 'rsynth')
n = int(sys.argv[1]) if len(sys.argv) > 1 else 8
rnd = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
os.makedirs('out/fuzz', exist_ok=True)
tok = re.compile(r"\s+|//[^\n]*|/\*.*?\*/|\w+|'\{|<<<=|>>>=|[<>=!]=|&&|\|\||<<|>>|\+:|-:|::|.", re.S)
bad = 0; total = 0
for f in sorted(glob.glob('t_*.sv')):
    toks = tok.findall(open(f).read())
    top = os.path.splitext(f)[0]
    for k in range(n):
        t = list(toks)
        for _ in range(rnd.randint(1, 3)):
            i = rnd.randrange(len(t))
            op = rnd.randrange(4)
            if op == 0: del t[i]
            elif op == 1: t.insert(i, t[rnd.randrange(len(t))])
            elif op == 2: j = rnd.randrange(len(t)); t[i], t[j] = t[j], t[i]
            else: t[i] = rnd.choice(['[', ']', '(', ')', '{', '}', ';', ',', '`', "'", '1', '#', '@', '?', ':', 'begin', 'end'])
        mf = 'out/fuzz/%s_%d.sv' % (top, k)
        open(mf, 'w').write(''.join(t))
        open('out/fuzz/run.tcl', 'w').write('analyze -format sverilog %s\nelaborate %s\nwrite_verilog out/fuzz/o.v\n' % (mf, top))
        total += 1
        try:
            r = subprocess.run([RS, '-f', 'out/fuzz/run.tcl'], capture_output=True, text=True, timeout=60)
            if 'panicked' in r.stdout + r.stderr or r.returncode not in (0, 1):
                bad += 1; print('PANIC', mf, (r.stdout + r.stderr).split('panicked')[-1][:200].replace('\n', ' '))
        except subprocess.TimeoutExpired:
            bad += 1; print('HANG ', mf)
print('FUZZ %d mutants, %d failures' % (total, bad))
sys.exit(1 if bad else 0)
