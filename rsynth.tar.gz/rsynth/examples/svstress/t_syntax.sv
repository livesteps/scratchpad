// Syntax corner cases: attributes, end labels, delays, spaced literals, generate / genvar forms,
// anonymous enums, case default in the middle, nested comments, implication operator
`timescale 1ns/1ps
`default_nettype none
(* keep_hierarchy = "yes" *)
module t_syntax #(parameter int W = 8, localparam int H = W / 2) (
  input  wire logic [W-1:0] a, b,     // explicit net kind
  input  wire [1:0] s,
  output logic [W-1:0] o1, o2,
  output logic [H-1:0] o3,
  output logic o4, o5
);
  (* mark_debug = "true" *) logic [W-1:0] t1 /* inline */ ;
  enum logic [1:0] { S0, S1, S2 } st;
  genvar g;
  generate
    for (g = 0; g < H; g = g + 1) begin : gl
      assign o3[g] = a[2*g] ^ b[2*g+1];
    end : gl
  endgenerate
  assign #1 t1 = a + 8 'h 0F;          // delay ignored; spaces inside the literal
  always_comb begin : comb_blk
    case (s)
      2'd1: o1 = t1;
      default: o1 = ~t1;
      2'd2: o1 = a & b;
    endcase
  end : comb_blk
  assign st = (s == 2'd3) ? S2 : (s == 2'd1 ? S1 : S0);
  assign o2 = (st == S2) ? 'h5A : {a[3:0], b[7:4]};
  assign o4 = (s[0] -> s[1]);
  /* multi-line
     comment // with slashes */
  assign o5 = (a[7 -: 4] == b[3 +: 4]) <-> s[1];
endmodule : t_syntax
`default_nettype wire
