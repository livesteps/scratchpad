#!/usr/bin/env python3
"""SystemVerilog parse / elaboration stress check.

  svcheck.py [--compile] [file.sv ...]      (default: every t_*.sv here)

For every test file (top module = file stem):
  1. RSynth: analyze + elaborate + write_verilog  -> out/<top>_gen.v   (any Error = FAIL)
  2. Random-stimulus simulation of the RTL (reference, modules renamed ref_*) against the
     generic netlist in one testbench, with Icarus (fallback: Verilator --binary).
     Ports / widths come from the netlist; any port-width warning on the reference is a
     FAIL (catches dropped / resized / reordered ports).  X / Z bits of the reference are
     not compared; a known reference bit that differs in the netlist is a mismatch.
With --compile each test is also mapped to the rs28 library (compile_fusion -to logic_opto)
and the mapped netlist is verified against the elaborated RTL with verify_equivalence.
Prints one line per test and 'SUMMARY <pass> passed, <fail> failed'.
`// sim: verilator` uses Verilator only (where Icarus deviates from IEEE 1800).
Inputs named clk* are clocks, rst / rst_n / reset / arst_n / rstn are resets (asserted
for the first cycles, then 1 in 16).  A `// cycles: N` line overrides the cycle count.
"""
import os, re, subprocess, sys, glob, shutil
HERE = os.path.dirname(os.path.abspath(__file__))
RS = os.path.join(HERE, '..', '..', 'target', 'release', 'rsynth')
os.chdir(HERE); os.makedirs('out', exist_ok=True)

def ports_of(net, top):
    src = open(net).read()
    m = re.search(r'^module %s\b.*?;(.*?)^endmodule' % re.escape(top), src, re.S | re.M)
    out = []
    for d, rng, names in re.findall(r'^\s*(input|output|inout)\s*(\[[^\]]*\])?\s*([^;]+);', m.group(1), re.M):
        w = 1
        if rng:
            a, b = [int(x) for x in re.findall(r'-?\d+', rng)]
            w = abs(a - b) + 1
        for n in names.split(','):
            out.append((d, w, n.strip()))
    return out

def idn(n, pre=''):
    """identifier (escaped identifiers keep their backslash and get the terminating space)"""
    return '\\' + pre + n[1:] + ' ' if n.startswith('\\') else pre + n

def is_clk(n): return re.match(r'clk', n, re.I) is not None
def is_rst(n): return n.lstrip('\\').lower() in ('rst', 'rst_n', 'reset', 'arst_n', 'rstn', 'arst', 'srst', 'srst_n')

def tb_text(top, ports, cycles):
    L = ['`timescale 1ns/1ps', 'module tb;']
    for d, w, n in ports:
        if d == 'input': L.append('  logic [%d:0] %s;' % (w - 1, idn(n)))
        else: L.append('  wire [%d:0] %s, %s;' % (w - 1, idn(n, 'r_'), idn(n, 'g_')))
    conn = lambda p: ', '.join('.%s(%s)' % (idn(n), idn(n) if d == 'input' else idn(n, p)) for d, w, n in ports)
    L += ['  ref_%s R (%s);' % (top, conn('r_')), '  %s G (%s);' % (top, conn('g_')),
          '  integer kk, bad, bi; logic [31:0] rr;',
          '  initial begin bad = 0;']
    clks = [n for d, w, n in ports if d == 'input' and is_clk(n)]
    for c in clks: L.append('    %s = 0;' % c)
    L.append('    for (kk = 0; kk < %d; kk = kk + 1) begin' % cycles)
    for d, w, n in ports:
        if d != 'input' or is_clk(n): continue
        if is_rst(n):
            act = '0' if n.lower().endswith('n') else '1'
            L.append("      rr = $random; %s = (kk < 3 || rr[3:0] == 0) ? 1'b%s : ~1'b%s;" % (idn(n), act, act))
        else:
            words = (w + 31) // 32
            L.append('      %s = {%s};' % (idn(n), ','.join(['$random'] * words)))
            L.append('      rr = $random; if (rr[2:0] == 0) %s = 0; else if (rr[2:0] == 1) %s = \'1;' % (idn(n), idn(n)))
    L.append('      #1;')
    for c in clks: L.append('      %s = 1;' % c)
    L.append('      #1;')
    for d, w, n in ports:
        if d == 'output':
            r_, g_ = idn(n, 'r_'), idn(n, 'g_')
            L.append('      for (bi = 0; bi < %d; bi = bi + 1) if ((%s[bi] === 1\'b0 || %s[bi] === 1\'b1) && %s[bi] !== %s[bi]) begin' % (w, r_, r_, r_, g_))
            L.append('        bad = bad + 1; if (bad < 6) $display("MISMATCH cycle %%0d %s[%%0d] ref=%%b net=%%b", kk, bi, %s, %s); bi = %d; end' % (n.replace('\\', ''), r_, g_, w))
    for c in clks: L.append('      %s = 0;' % c)
    L += ['    end', '    $display("RESULT %0d mismatches", bad); $finish;', '  end', 'endmodule']
    return '\n'.join(L) + '\n'

def run(cmd, **k):
    return subprocess.run(cmd, capture_output=True, text=True, **k)

def check(f):
    top = os.path.splitext(os.path.basename(f))[0]
    src = open(f).read()
    cyc = int((re.search(r'//\s*cycles:\s*(\d+)', src) or [0, 400])[1])
    defs = (re.search(r'//\s*defines:\s*(.*)', src) or [0, ''])[1].split()
    tcl = 'out/%s.tcl' % top
    open(tcl, 'w').write('analyze -format sverilog %s%s\nelaborate %s\nwrite_verilog out/%s_gen.v\nputs "ELAB_OK"\n'
                         % ('-define {%s} ' % ' '.join(defs) if defs else '', f, top, top))
    r = run([RS, '-f', tcl], timeout=600)
    log = r.stdout + r.stderr
    open('out/%s.log' % top, 'w').write(log)
    if 'ELAB_OK' not in log or re.search(r'^Error', log, re.M) or 'panicked' in log:
        e = [l for l in log.splitlines() if l.startswith('Error') or 'panicked' in l][:3]
        return 'FAIL  rsynth: ' + ' | '.join(e or log.strip().splitlines()[-2:])
    warn = [l for l in log.splitlines() if re.search(r'unsupported|ignored|not supported', l, re.I)]
    net = 'out/%s_gen.v' % top
    ports = ports_of(net, top)
    # reference: rename every module of the test file
    mods = re.findall(r'^\s*module\s+(\w+)', src, re.M)
    ref = src
    for m in mods: ref = re.sub(r'\b%s\b' % m, 'ref_' + m, ref)
    open('out/ref_%s.sv' % top, 'w').write(ref)
    open('out/tb_%s.sv' % top, 'w').write(tb_text(top, ports, cyc))
    dflags = ['-D' + d for d in defs]
    force_vl = re.search(r'//\s*sim:\s*verilator', src) is not None
    r = subprocess.CompletedProcess([], 1, '', 'forced verilator') if force_vl else run(['iverilog', '-g2012', *dflags, '-o', 'out/sim_%s' % top, 'out/tb_%s.sv' % top, 'out/ref_%s.sv' % top, net])
    msgs = r.stdout + r.stderr
    sim = 'icarus'
    if r.returncode:
        vd = 'out/vl_%s' % top; shutil.rmtree(vd, ignore_errors=True)
        r = run(['verilator', '--binary', '--timing', '-Wno-fatal', '-Wno-lint', '-Wno-style', '-Wno-WIDTH', *['+define+' + d for d in defs],
                 '--top-module', 'tb', '-Mdir', vd, '-o', 'sim', 'out/tb_%s.sv' % top, 'out/ref_%s.sv' % top, net], timeout=900)
        if r.returncode:
            return 'FAIL  neither simulator compiles: ' + (msgs + r.stderr).strip().splitlines()[0][:200]
        msgs += r.stderr; sim = 'verilator'
        out = run([vd + '/sim'], timeout=300).stdout
    else:
        out = run(['vvp', '-n', 'out/sim_%s' % top], timeout=300).stdout
    pw = [l for l in msgs.splitlines() if 'tb_' in l and re.search(r'[Pp]ort.*(expects|bits|size)|PINCONNECTEMPTY|PINMISSING|Pin not found', l)]
    res = re.search(r'RESULT (\d+) mismatches', out)
    note = ('  [%s]' % sim) + ('  (rsynth: %s)' % warn[0][:90] if warn else '')
    if pw: return 'FAIL  port width/connection: ' + pw[0][:160]
    if not res: return 'FAIL  simulation did not finish: ' + out.strip()[-200:]
    if res[1] != '0':
        mm = [l for l in out.splitlines() if l.startswith('MISMATCH')][:2]
        return 'FAIL  %s mismatches %s %s' % (res[1], note, ' | '.join(mm)[:300])
    return 'ok' + note

def check_compiled(f):
    """compile with the rs28 library and verify the mapped netlist against the elaborated RTL"""
    top = os.path.splitext(os.path.basename(f))[0]
    src = open(f).read()
    defs = (re.search(r'//\s*defines:\s*(.*)', src) or [0, ''])[1].split()
    net = 'out/%s_gen.v' % top
    # elaborated netlist for the port list (RSynth only, no simulator needed)
    open('out/%s_e.tcl' % top, 'w').write('analyze -format sverilog %s%s\nelaborate %s\nwrite_verilog %s\n'
                                          % ('-define {%s} ' % ' '.join(defs) if defs else '', f, top, net))
    r = run([RS, '-f', 'out/%s_e.tcl' % top], timeout=600)
    if not os.path.exists(net) or re.search(r'^Error', r.stdout + r.stderr, re.M):
        return 'FAIL  (elaboration) ' + ' | '.join(l for l in (r.stdout + r.stderr).splitlines() if l.startswith('Error'))[:200]
    resets = [n for d, w, n in ports_of(net, top) if d == 'input' and is_rst(n)]
    tcl = 'out/%s_c.tcl' % top
    open(tcl, 'w').write('read_lib ../lib/rs28_tt_0p80v_25c.lib\nanalyze -format sverilog %s%s\nelaborate %s\ncompile_fusion -to logic_opto\n'
                         'write_verilog out/%s_mapped.v\nputs "EQV [verify_equivalence -cycles 1500 -resets {%s}]"\n'
                         % ('-define {%s} ' % ' '.join(defs) if defs else '', f, top, top, ' '.join(resets)))
    r = run([RS, '-f', tcl], timeout=900)
    log = r.stdout + r.stderr
    open('out/%s_c.log' % top, 'w').write(log)
    if 'panicked' in log or re.search(r'^Error', log, re.M) and 'Verification FAILED' not in log:
        e = [l for l in log.splitlines() if l.startswith('Error') or 'panicked' in l][:2]
        return 'FAIL  compile: ' + ' | '.join(e)
    m = re.search(r'Verification SUCCEEDED: (\d+) outputs matched over (\d+) cycles', log)
    if m:
        return 'ok  [%s outputs, %s cycles]' % (m[1], m[2])
    mm = [l.strip() for l in log.splitlines() if re.match(r'\s+cycle\s+\d+', l)][:2]
    return 'FAIL  mapped netlist: ' + ' | '.join(mm)

compiled = '--compile' in sys.argv
if '--elab-only' in sys.argv:
    sys.argv.remove('--elab-only')     # accepted for compatibility: --compile never simulates
if compiled:
    sys.argv.remove('--compile')
    check = (lambda c: (lambda f: check_compiled(f)))(check)
files = sys.argv[1:] or sorted(glob.glob('t_*.sv'))
npass = nfail = 0
for f in files:
    try: s = check(f)
    except Exception as e: s = 'FAIL  harness: %r' % e
    ok = s.startswith('ok'); npass += ok; nfail += not ok
    print('%-28s %s' % (os.path.basename(f), s), flush=True)
print('SUMMARY %d passed, %d failed' % (npass, nfail))
sys.exit(1 if nfail else 0)
