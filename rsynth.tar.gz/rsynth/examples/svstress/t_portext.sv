// Port connection extension: narrow output into wider net (zero / sign extended), signed
// input from narrower expression, constants on ports, part-select connections
module t_po (input logic [3:0] i, output logic [3:0] o, output logic signed [3:0] so);
  assign o = i + 1;
  assign so = i;
endmodule
module t_pi (input logic signed [7:0] si, input logic [7:0] ui, output logic [7:0] o);
  assign o = si ^ ui;
endmodule
module t_portext (input logic [3:0] a, input logic signed [3:0] sa, output logic [7:0] w1, w2, output logic [7:0] x1, x2, output logic [7:0] y);
  t_po u1 (.i(a), .o(w1), .so(w2));
  t_pi u2 (.si(sa), .ui(a), .o(x1));
  t_pi u3 (.si(4'sb1000), .ui(8'd3), .o(x2));
  logic [7:0] t;
  t_po u4 (.i(a ^ 4'h3), .o(t[5:2]), .so());
  assign y = t;
endmodule
