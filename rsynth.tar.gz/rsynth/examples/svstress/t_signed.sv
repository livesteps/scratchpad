// Signedness rules: extension, comparisons, $signed / $unsigned, signed literals, >>>
module t_signed (input logic [7:0] a, b, input logic signed [7:0] sa, sb, input logic [3:0] n,
  output logic [15:0] ext_s, ext_u, output logic lt_s, lt_u, lt_mix, lt_neg, ge_lit,
  output logic [7:0] ashr, lshr, ashr_u, output logic signed [15:0] cast1, output logic [15:0] cast2,
  output logic signed [9:0] tern, output logic [7:0] absv, output logic signed [11:0] sadd, output logic [3:0] slit);
  assign ext_s = sa;                   // sign-extended
  assign ext_u = a;                    // zero-extended
  assign lt_s = sa < sb;
  assign lt_u = a < b;
  assign lt_mix = sa < b;              // unsigned compare (one operand unsigned)
  assign lt_neg = sa < -8'sd3;
  assign ge_lit = $signed(a) >= -1;
  assign ashr = sa >>> n[2:0];
  assign lshr = sa >> n[2:0];
  assign ashr_u = a >>> n[2:0];        // unsigned operand: logical
  assign cast1 = $signed(a) * $signed(b);
  assign cast2 = $unsigned(sa) + 16'd0;
  assign tern = n[0] ? sa : sb;        // both signed -> sign extended to 10
  assign absv = sa[7] ? -sa : sa;
  assign sadd = sa + sb + 4'sd1;
  assign slit = -4'sd3 >>> 1;
endmodule
