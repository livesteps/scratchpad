// Reductions, logical ops, precedence, equality with x/z literals, nested ternaries
module t_logic (input logic [7:0] a, b, c, input logic [2:0] s,
  output logic r_and, r_or, r_xor, r_nand, r_nor, r_xnor, l_and, l_or, l_not, eq, ne, ceq,
  output logic [7:0] prec1, prec2, prec3, tsel, output logic [1:0] cmpv, output logic [8:0] notw, output logic bnot);
  assign r_and = &a; assign r_or = |a; assign r_xor = ^a;
  assign r_nand = ~&a; assign r_nor = ~|a; assign r_xnor = ~^a;
  assign l_and = a && b; assign l_or = !a || (b & c) != 0; assign l_not = !c;
  assign eq = (a == b); assign ne = a != c; assign ceq = (a === b);
  assign prec1 = a & b | c ^ a;
  assign prec2 = a + b & c;            // + binds tighter than &
  assign prec3 = a == b ? c : a | b;
  assign tsel = s == 0 ? a : s == 1 ? b : s == 2 ? c : s[2] ? a ^ b : 8'hA5;
  assign cmpv = {a > b, a <= c};
  assign notw = ~a;                    // 9-bit context: ~ applied after extension
  assign bnot = ~a[0] & b[1] ^ !c;
endmodule
