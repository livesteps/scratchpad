// Compound assignments on selects, members and array elements; ++ on elements; nested selects
typedef struct packed { logic [3:0] cnt; logic [3:0] val; } cv_t;
module t_compound (input logic [7:0] a, b, input logic [1:0] i, output logic [7:0] o1, o2, output logic [31:0] o3, output logic [7:0] o4);
  logic [3:0][7:0] arr;
  cv_t c;
  always_comb begin
    o1 = a;
    o1[3:0] += b[3:0];
    o1[7] ^= 1'b1;
    o1[6:5] <<= 1;
  end
  always_comb begin
    c = a;
    c.cnt += 4'd3;
    c.val *= 4'd2;
    c.cnt[0] |= b[0];
    o2 = c;
  end
  always_comb begin
    arr = {a, b, a & b, a | b};
    arr[i] -= 8'd1;
    arr[i ^ 2'd1]++;
    arr[0][i +: 2] ^= 2'b11;
    o3 = arr;
  end
  always_comb begin
    o4 = 8'd200;
    o4 /= (b[2:0] + 8'd1);
    o4 %= 8'd7;
    o4 >>>= 1;
  end
endmodule
