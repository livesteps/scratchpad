#!/bin/sh
# Malformed / unsupported RTL must give a clear Error (no panic, no hang).
cd "$(dirname "$0")/errors" || exit 2
RS=../../../target/release/rsynth
fail=0
for f in e_*.sv; do
  top=$(basename "$f" .sv)
  printf 'analyze -format sverilog %s\nelaborate %s\nputs "ELAB_DONE"\n' "$f" "$top" > /tmp/err_$top.tcl
  out=$(timeout 60 $RS -f /tmp/err_$top.tcl 2>&1); rc=$?
  msg=$(printf '%s\n' "$out" | grep -m1 '^Error' | sed 's/^Error: //')
  if [ $rc -eq 124 ]; then echo "$f: HANG"; fail=1
  elif printf '%s' "$out" | grep -q panicked; then echo "$f: PANIC"; fail=1
  elif [ -z "$msg" ]; then echo "$f: NO ERROR REPORTED"; fail=1
  else echo "$f: ok -> $msg"; fi
done
exit $fail
