// Plain case items with x / z never match a 2-state selector (4-state semantics); casez wildcards
module t_casex (input logic [3:0] s, input logic [7:0] a, output logic [7:0] o1, o2);
  always_comb begin
    case (s)
      4'b1x00: o1 = 8'd1;              // never matches (x in a plain case item)
      4'b1000: o1 = 8'd2;
      4'bz001: o1 = 8'd3;              // never matches
      default: o1 = a;
    endcase
  end
  always_comb begin
    casez (s)
      4'b1z0?: o2 = 8'd5;              // z / ? are wildcards in casez
      default: o2 = ~a;
    endcase
  end
endmodule
