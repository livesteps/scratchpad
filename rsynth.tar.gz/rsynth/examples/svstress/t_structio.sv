// Structs through ports and functions; struct with enum member; struct equality; signed function results
typedef enum logic [1:0] { RD, WR, NOP } kind_e;
typedef struct packed { kind_e k; logic [5:0] addr; logic [7:0] data; } req_t;   // 16 bits
module t_sproc (input req_t r, output req_t o);
  always_comb begin
    o = r;
    if (r.k == WR) o.data = r.data + 1;
    else if (r.k == RD) o.addr = ~r.addr;
  end
endmodule
module t_structio (input logic [15:0] x, input logic signed [3:0] p, q, output logic [15:0] y, output logic e, output logic signed [7:0] f1, output logic [7:0] f2);
  function automatic req_t mk(input kind_e k, input logic [5:0] a, input logic [7:0] d);
    req_t r; r.k = k; r.addr = a; r.data = d; return r;
  endfunction
  function automatic logic signed [3:0] neg4(input logic signed [3:0] v); return -v; endfunction
  req_t ri, ro;
  assign ri = mk(kind_e'(x[15:14]), x[13:8], x[7:0]);
  t_sproc u (.r(ri), .o(ro));
  assign y = ro;
  assign e = (ri == ro);
  assign f1 = neg4(p) + q;               // signed function result: sign-extended
  assign f2 = neg4(p) + 8'd0;            // unsigned operand: zero-extended
endmodule
