// Arithmetic: widths from context, carries, signed / unsigned mixing, * / % **
module t_arith (input logic [7:0] a, b, input logic [3:0] c, input logic signed [7:0] sa, sb,
  output logic [8:0] sum9, output logic [7:0] sum8, output logic [15:0] prod, output logic signed [15:0] sprod,
  output logic [7:0] quo, rem, output logic signed [7:0] squo, srem, output logic [9:0] avg, output logic [11:0] mix,
  output logic [7:0] pw, output logic [15:0] neg, output logic [4:0] cs, output logic [8:0] sh);
  assign sum9 = a + b;                       // carry kept (context width 9)
  assign sum8 = a + b + c;
  assign prod = a * b;
  assign sprod = sa * sb;
  assign quo = (b == 0) ? 8'd0 : a / b;
  assign rem = (b == 0) ? 8'd0 : a % b;
  assign squo = (sb == 0) ? 8'sd0 : sa / sb;  // truncates toward zero
  assign srem = (sb == 0) ? 8'sd0 : sa % sb;  // sign of dividend
  assign avg = (a + b) >> 1;                 // 10-bit context: carry not lost
  assign mix = sa + c;                       // c unsigned -> whole expression unsigned, sa zero-extended
  assign pw = c[1:0] ** 2'd3;
  assign neg = -a;                           // 16-bit context
  assign {cs[4], cs[3:0]} = c + 4'd9;
  assign sh = {1'b0, a} - {1'b0, b};
endmodule
