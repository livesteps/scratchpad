// Interface with its own logic (continuous assign, always_comb) and a function used by a module
interface t_cnt_if (input logic [7:0] base);
  logic [7:0] val, nxt;
  logic par;
  assign nxt = val + base;
  always_comb par = ^val;
  function automatic logic [7:0] twice(input logic [7:0] x); return x << 1; endfunction
  modport m (input base, nxt, par, output val, import twice);
endinterface
module t_iuse (t_cnt_if.m c, input logic [7:0] d, output logic [7:0] q, output logic p);
  assign c.val = d;
  assign q = c.twice(c.nxt);
  assign p = c.par;
endmodule
module t_iface2 (input logic [7:0] base, d, output logic [7:0] q, n, output logic p);
  t_cnt_if ci (.base(base));
  t_iuse u (.c(ci), .d(d), .q(q), .p(p));
  assign n = ci.nxt;
endmodule
