// Concatenation / replication as rvalue and lvalue, nested, with parameters
module t_concat #(parameter N = 3) (input logic [7:0] a, b, input logic [3:0] c,
  output logic [23:0] cat3, output logic [11:0] rep, output logic [7:0] lo, hi, output logic [3:0] x, y,
  output logic [N*4-1:0] prep, output logic [15:0] swap, output logic [8:0] nested);
  assign cat3 = {a, b, {c, c}};
  assign rep = {3{c}};
  assign {hi, lo} = {b, a} + 16'd1;
  assign {x, y} = a;
  assign prep = {N{c[1:0], c[3:2]}};
  assign swap = {a[3:0], a[7:4], b[0], b[1], b[2], b[3], b[7:4]};
  assign nested = {{2{c[0], 1'b1}}, {{c}, 1'b0}};
endmodule
