# create_voltage_area error checks (VA-001..006) and highlight errors (GUI-101)
create_mode func ; create_corner ss
read_lib -corner ss lib/rs28_ss_0p72v_125c.lib
create_scenario -name func_ss -mode func -corner ss
analyze -format sverilog {rtl/soc_pkg.sv rtl/bus_if.sv rtl/lane.sv rtl/arbiter.sv rtl/core.sv rtl/soc_top.sv}
analyze -format vhdl rtl/checksum.vhd
elaborate soc_top
read_def floorplan.def
puts "NOUPF [catch {gui_highlight_power_domain PD_LANES} m] $m"
load_upf va/power_va.upf
puts "T1 [catch {create_voltage_area -power_domains PD_NOPE -region {{0 0} {10 10}}} m] $m"
puts "T2 [catch {create_voltage_area -power_domains PD_TOP -region {{0 0} {10 10}}} m] $m"
puts "T3 [catch {create_voltage_area -power_domains PD_LANES -region {{0 0} {4 4}} -guard_band 2} m] $m"
puts "T4 [catch {create_voltage_area -name VA_A -power_domains PD_LANES -region {{4 54} {48 96}}} m] $m"
puts "T5 [catch {create_voltage_area -name VA_B -power_domains PD_CSUM -region {{40 40} {70 70}}} m] $m"
puts "T6 [catch {create_voltage_area -name VA_C -power_domains PD_LANES -region {{60 0} {80 20}}} m] $m"
puts "T7 [catch {gui_highlight_power_domain -color_by rainbow} m] $m"
puts "T8 [catch {gui_highlight_power_domain PD_*} m] $m"
puts "T9 [get_voltage_areas -of_objects PD_LANES]"
puts "T10 [remove_voltage_areas -all] [llength [get_voltage_areas]]"
