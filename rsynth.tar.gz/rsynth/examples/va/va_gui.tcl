# ---------------------------------------------------------------------------
# Voltage areas + floorplan-GUI power-domain selection / highlight
#   run from examples/:  rsynth -f va/va_gui.tcl
# ---------------------------------------------------------------------------
create_mode func ; create_corner ss ; create_corner ff
read_lib -corner ss lib/rs28_ss_0p72v_125c.lib
read_lib -corner ff lib/rs28_ff_0p88v_m40c.lib
create_scenario -name func_ss -mode func -corner ss
create_scenario -name func_ff -mode func -corner ff
set_scenario_status func_ss -hold false
set_scenario_status func_ff -setup false -hold true
analyze -format sverilog {rtl/soc_pkg.sv rtl/bus_if.sv rtl/lane.sv rtl/arbiter.sv rtl/core.sv rtl/soc_top.sv}
analyze -format vhdl rtl/checksum.vhd
elaborate soc_top
current_mode func ; read_sdc func.sdc
read_def floorplan.def
load_upf va/power_va.upf
compile_fusion -to logic_opto
report_power_domains

# ---- voltage areas (exclusive regions for PD_LANES and PD_CSUM; PD_TOP = die)
create_voltage_area -name VA_LANES -power_domains PD_LANES -region {{4 54} {48 96}} -guard_band {1.0 1.6}
create_voltage_area -name VA_CSUM  -power_domains PD_CSUM  -region {{62 6} {104 34}} -guard_band 1.0
get_voltage_areas
get_power_domains -of_objects [get_cells u_core/u_csum/*]

place_opt
check_legality
report_voltage_areas -verbose
verify_equivalence -cycles 800 -resets {rst_n} -constants {scan_en 0 iso_en 0 save 0 restore 0 dbg_sel 1}

# ---- GUI: highlight PD_LANES (dims every other domain, selects its cells), colour by domain
gui_highlight_power_domain -color_by power_domain PD_LANES
gui_highlight_power_domain -add PD_CSUM
gui_get_highlighted_power_domains
file mkdir va/out
gui_write_state va/out/va_floorplan.json
write_def va/out/va.def

# ---- voltage areas round-trip through DEF re-read (kept as command objects)
read_def va/out/va.def
report_voltage_areas
