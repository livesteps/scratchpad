read_lib ../lib/rs28_tt_0p80v_25c.lib
read_verilog angle.v
link_block top
current_design top
puts "=== BEFORE"
puts [lsort [get_object_name [get_cells -hier *]]]
define_name_rules my_rules -allowed "a-zA-Z0-9_!" -replacement_char "_" -hierarchy_delimiter "!" -hier_bus_char "_" -dot_char "_" -angle_to_square -target_bus_naming_style {%s[%d]}
report_names -rules my_rules
change_names -rules my_rules -verbose
puts "=== AFTER"
puts "CELLS [lsort [get_object_name [get_cells -hier *]]]"
puts "NETS [lsort [get_object_name [get_nets -hier *]]]"
puts "PORTS [lsort [get_object_name [get_ports *]]]"
file mkdir out
write_verilog out/angle_renamed.v
define_name_rules dot_rules -hierarchy_delimiter "." -hier_bus_char "_" -allowed "a-zA-Z0-9_." -angle_to_square
