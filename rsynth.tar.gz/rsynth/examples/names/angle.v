// gate-level netlist with angle-bracket bus bits and dotted / bussed flattened hierarchy names
module top (a, b, y, z);
  input [1:0] a;
  input b;
  output y;
  output [1:0] z;
  wire \u_blk<0>/n<0> ;
  wire \u_blk<0>/n<1> ;
  wire \gen[1].u_sub/m.q ;
  AND2_X1_SVT \u_blk<0>/U1  ( .A1(a[0]), .A2(a[1]), .Y(\u_blk<0>/n<0> ) );
  OR2_X1_SVT  \u_blk<0>/U2  ( .A1(\u_blk<0>/n<0> ), .A2(b), .Y(\u_blk<0>/n<1> ) );
  INV_X1_SVT  \gen[1].u_sub/m.inv  ( .A(\u_blk<0>/n<1> ), .Y(\gen[1].u_sub/m.q ) );
  BUF_X1_SVT  \gen[1].u_sub/U9  ( .A(\gen[1].u_sub/m.q ), .Y(y) );
  BUF_X1_SVT  ub0 ( .A(\u_blk<0>/n<0> ), .Y(z[0]) );
  BUF_X1_SVT  ub1 ( .A(\u_blk<0>/n<1> ), .Y(z[1]) );
endmodule
