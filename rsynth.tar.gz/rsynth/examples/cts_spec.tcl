# Clock tree specification (clocktree.cfg), clock tree tracing and clock_opt honouring the spec
source fp_flow_setup.tcl
place_opt
puts "TR0 [trace_clock_tree]"
write_clock_tree_spec -file out/clocktree.cfg
report_clock_tree_spec
