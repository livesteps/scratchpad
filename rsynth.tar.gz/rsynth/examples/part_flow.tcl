# ---------------------------------------------------------------------------
# Hierarchical partitioning + time budgeting + partition write-out
# ---------------------------------------------------------------------------
source fp_flow_setup.tcl
# partitions: two lanes as explicit partitions with physical regions, others by size
create_bound -name lane1_region -type exclusive -boundary {{5 5} {40 45}} {u_core/g_lane[1].u_lane}
create_partition -name lane0 -bound b_lane0 {u_core/g_lane[0].u_lane}
create_partition -name lane1 -bound lane1_region {u_core/g_lane[1].u_lane}
auto_partition -min_cells 40 -max_cells 120
create_feedthrough -name ft_lane1 -region lane1 -nets {u_core/g_lane[3]* din*}
report_partitions
place_opt
report_partitions

# ---- time budgeting from full-chip MMMC timing
set_budget_options -mode proportional -margin 0.05
compute_budget_constraints
report_budget -partition lane0
write_budgets -output out/budgets

# ---- write partitions and verify the re-assembled hierarchy against the RTL
write_partitions -output out/parts
report_partitions
