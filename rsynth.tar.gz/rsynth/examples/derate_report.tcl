# report_timing derate columns: user (object) derates, corner OCV, AOCV, POCV
source fp_flow_setup.tcl
place_opt
set_operating_conditions -analysis_type on_chip_variation
set_timing_derate -late 1.08 -cell_delay -corners ss
set_timing_derate -late 1.05 -net_delay -corners ss
report_timing_format -derate -ocv -user_derate -aocv -pocv
puts "=== OCV"
report_timing -scenarios func_ss -max_paths 1
# object derate on the worst path's second cell
set p [get_timing_paths -scenarios func_ss]
set c ""
foreach_in_collection q [get_attribute $p points] { if {[get_attribute $q capacitance] ne "" && [get_attribute $q cell] ne ""} { set c [get_attribute $q cell] } }
set_timing_derate -late 1.20 -cell_delay [get_cells [get_object_name $c]] -corners ss
puts "=== USER [get_object_name $c]"
report_timing -scenarios func_ss -max_paths 1
puts "=== AOCV"
read_ocvm ocv/rs28.aocvm
report_timing -scenarios func_ss -max_paths 1
remove_ocvm
puts "=== POCV"
read_ocvm ocv/rs28.pocvm
report_timing -scenarios func_ss -max_paths 1 -format {point incr path pocv derate}
set p [get_timing_paths -scenarios func_ss]
set q [index_collection [get_attribute $p points] 2]
puts "ATTR derate [get_attribute $q derate] ocv [get_attribute $q ocv_derate] pocv [get_attribute $q pocv_sigma]"
remove_ocvm
report_timing_format -derates -remove
report_timing_format -help
