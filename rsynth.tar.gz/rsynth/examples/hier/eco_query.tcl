# ECO + query regression on the hierarchy test design
source common.tcl
elaborate top
source sdc.tcl
compile_fusion -no_boundary_optimization
puts "== QUERIES"
puts "INPUTS: [all_inputs]"
puts "OUTPUTS: [sizeof_collection [all_outputs]]"
puts "REGS: [all_registers]"
puts "REG_CK: [sizeof_collection [all_registers -clock_pins]]  REG_D: [sizeof_collection [all_registers -data_pins]]"
puts "CLOCKS: [all_clocks]"
puts "NET_OF_D: [all_connected {q_reg[0]/D}]"
puts "LEAF_PINS: [all_connected -leaf [all_connected {q_reg[0]/D}]]"
puts "LEAF_A0: [all_connected -leaf [all_connected {a[0]}]]"
puts "RX_CELLS: [sizeof_collection [get_cells -hier -regexp {u_alu/U[0-9]+} -filter {ref_name =~ XOR.*}]]"
puts "GLOB_CELLS: [sizeof_collection [get_cells -hier u_alu/U* -filter {ref_name =~ XOR*}]]"
puts "RX_NETS: [get_nets -hier -regexp {q\[[0-3]\]}]"
puts "RX_PINS: [sizeof_collection [get_pins -hier -regexp {q_reg\[[0-9]\]/(D|CK)} -filter {direction == in}]]"
puts "NOCASE: [get_cells -nocase P0_REG]"
puts "SCOPE: [current_instance u_alu]"
puts "SCOPED: [sizeof_collection [get_cells *]] [lindex [get_cells *] 0]"
current_instance
report_transitive_fanout -from {a[0]} -levels 3
report_transitive_fanin -to {q_reg[0]/D} -endpoints_only
select_obj [get_cells -hier -regexp {q_reg\[[0-3]\]}]
add_to_selection [get_nets -hier -regexp {q\[[0-9]\]}]
remove_from_selection [get_cells {q_reg[0]}]
puts "SEL: [sizeof_collection [get_selection]]"
report_selection
deselect_all
puts "SEL_AFTER: [sizeof_collection [get_selection]]"
check_timing -verbose
puts "== ECO: function-preserving"
eco_create_ports {spare_in tp[3:0]} -direction in
eco_create_ports obs -direction out
puts "NEWPORTS: [get_ports {spare_in tp* obs}]"
set n0 [get_object_name [all_connected {q_reg[1]/D}]]
eco_add_repeater -cell BUF_X2_SVT -net $n0 -stage_count 2 -name rpt
catch {eco_add_repeater -cell INV_X1_SVT -net $n0 -stage_count 3} m ; puts "ODD_INV: $m"
eco_add_repeater -cell INV_X1_SVT -pin {q_reg[2]/D} -stage_count 2 -name ipair
verify_equivalence -cycles 500
eco_delete_repeater -inv_pairs -net [get_object_name [all_connected {q_reg[2]/D}]]
eco_delete_repeater -buff [get_cells rpt_*]
set c [lindex [get_cells -hier u_alu/U* -filter {ref_name =~ XOR2_X1*}] 0]
puts "SIZE_CELL: [get_object_name $c] [get_attribute $c ref_name]"
eco_sizecell -inst $c -autoup
puts "AFTER_UP: [get_attribute $c ref_name]"
eco_sizecell -inst $c -autodown
puts "AFTER_DOWN: [get_attribute $c ref_name]"
catch {eco_sizecell -inst $c -cell XNOR2_X1_SVT} m ; puts "SIZE_WRONG_FUNC: $m"
add_instance -name eco_and -cell AND2_X1_SVT -location {10 10}
catch {connect -net [get_object_name [all_connected {a[0]}]] -pin eco_and/A1 -no_punch_ports} m ; puts "NOPUNCH_TOP: $m"
connect -net [get_object_name [all_connected {a[0]}]] -pin eco_and/A1
connect -net [get_object_name [all_connected spare_in]] -pin eco_and/A2
create_net eco_obs
connect -net eco_obs -pin {eco_and/Y obs}
catch {connect -net eco_obs -pin {q_reg[0]/D}} m ; puts "ALREADY: $m"
set inner [lindex [get_cells -hier u_alu/U* ] 3]
set ip [lindex [get_pins -of_objects $inner -filter {direction == in}] 0]
catch {connect -net eco_obs -pin [get_object_name $ip] -auto_disconnect_existing -no_punch_ports} m ; puts "NOPUNCH_HIER: $m"
verify_equivalence -cycles 500
puts "== ECO: functional change (must FAIL), then undo"
eco_change_cell -inst $c -cell XNOR2_X1_SVT
verify_equivalence -cycles 300
eco_change_cell -inst $c -cell XOR2_X1_SVT
disconnect_pin {eco_and/A1 eco_and/A2 eco_and/Y obs} 
delete_instance eco_and
eco_delete_ports {tp* spare_in obs}
verify_equivalence -cycles 500
report_eco_changes
file mkdir out
write_eco_changes out/eco.tcl
write_verilog out/eco.v
