# Boundary optimization / ungroup / flatten regression (each block re-elaborates from RTL)
source common.tcl
proc run {tag cmds} {
  elaborate top
  source sdc.tcl
  foreach c $cmds { eval $c }
  report_hierarchy
  report_qor
  file mkdir out
  write_verilog out/$tag.v
  verify_equivalence -cycles 500
  puts "RESULT $tag cells=[sizeof_collection [get_cells -hier * -filter {ref_name =~ *_X*}]]"
}
run bopt_on   {{compile_fusion}}
run bopt_off  {{compile_fusion -no_boundary_optimization}}
set_app_options -name compile.flow.boundary_optimization -value true
run inst_off  {{set_boundary_optimization [get_cells u_alu] false} {compile_fusion}}
set_boundary_optimization u_alu true
run ungroup   {{set_boundary_optimization -all false} {ungroup [get_cells u_p*]} {compile_fusion}}
set_app_options -name compile.flow.boundary_optimization -value true
run flatten   {{compile_fusion -no_boundary_optimization -flatten}}
set_app_options -name compile.flow.boundary_optimization -value true
run autoungrp {{compile_fusion -no_boundary_optimization -auto_ungroup area}}
set_app_options -name compile.flow.boundary_optimization -value true
run setungrp  {{set_boundary_optimization -all false} {set_ungroup [get_cells u_t] true} {compile_fusion}}
set_app_options -name compile.flow.boundary_optimization -value true
run simple    {{compile_fusion} {ungroup -all -flatten -simple_names}}
# read the boundary-preserving hierarchical netlist back and verify against the RTL
analyze -format verilog out/bopt_off.v
elaborate top -keep_reference
verify_equivalence -cycles 500
