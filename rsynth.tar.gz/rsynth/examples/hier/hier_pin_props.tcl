# Hierarchical pins and nets: get_pins inst/port, leafpins / leaf_drivers / leaf_loads / leaf_ports, is_hierarchical, layer
source common.tcl
elaborate top
source sdc.tcl
compile_fusion -no_boundary_optimization
puts "=== HIER PIN PROPERTIES"
set hp [get_pins u_alu/*]
puts "HPINS [sizeof_collection $hp]: [lrange [get_object_name $hp] 0 5]"
set p [get_pins {u_alu/a[0]}]
puts "HPIN [get_object_name $p] dir [get_property $p direction] hier [get_property $p is_hierarchical] net [get_object_name [get_property $p net]] loc '[get_property $p location]' layer '[get_property $p layer]' slack [get_property $p slack_max]"
puts "LEAF_OF_HIER_NET [get_object_name [get_property [get_nets {u_alu/a[0]}] leafpins]]"
puts "HIER_Y [get_object_name [get_pins {u_alu/y[3]}]] dir [get_property [get_pins {u_alu/y[3]}] direction] leaf_drv [get_object_name [get_property [get_nets {u_alu/y[3]}] leaf_drivers]]"
puts "LEAFPIN [get_property [get_pins {u_alu/U8/A2}] is_hierarchical] [get_property [get_pins {u_alu/U8/A2}] layer]"
