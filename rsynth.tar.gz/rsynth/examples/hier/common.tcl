read_lib ../lib/rs28_ss_0p72v_125c.lib
analyze -format verilog hier.v
