// Hierarchy / boundary-optimization test design
module alu (input [7:0] a, b, input [1:0] mode, output [7:0] y, output [7:0] dbg);
  assign y   = (mode == 2'd0) ? a + b : (mode == 2'd1) ? a - b : (mode == 2'd2) ? a & b : a ^ b;
  assign dbg = a * b;                     // only observable if dbg is used by the parent
endmodule
module parity (input [7:0] d, output p);   // identical instances on identical inputs
  assign p = ^d;
endmodule
module tiny (input x, output y);           // auto-ungroup candidate
  assign y = ~x;
endmodule
module top (input clk, input [7:0] a, b, output reg [7:0] q, output reg p0, p1, output t);
  wire [7:0] y, dbg_unused;
  wire pa, pb;
  alu    u_alu (.a(a), .b(b), .mode(2'b00), .y(y), .dbg(dbg_unused));   // constant mode, unused dbg
  parity u_p0  (.d(a), .p(pa));
  parity u_p1  (.d(a), .p(pb));
  tiny   u_t   (.x(pa), .y(t));
  always @(posedge clk) begin q <= y; p0 <= pa; p1 <= pb; end
endmodule
