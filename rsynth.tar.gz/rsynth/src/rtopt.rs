//! Routing-stage optimization and ECO commands.
//!
//! * Route command options (route_auto / route_detail / route_global / route_eco):
//!   `-timing_driven`, `-effort_level low|medium|high`, `-min_layer` / `-max_layer`,
//!   `-layer_jogs` (antenna repair by layer jumpers), `-antenna_diode <cell>` (antenna repair by
//!   diodes after routing), `-max_buffering_distance <um>` (net-length buffering after routing),
//!   `-opc <rules>` (litho-driven routing and OPC fill).
//! * Antenna (`check_antenna`, `fix_antenna`): per gate pin and metal layer, the metal of that
//!   layer connected to the gate through layers up to it (partial antenna ratio, IEEE-style
//!   process antenna model: a path to a driver diffusion or a diode protects the gate);
//!   limits from LEF ANTENNAAREARATIO, gate areas from LEF ANTENNAGATEAREA.
//! * Net-length buffering (`report_net_length`, `fix_net_length`, `route_opt -max_net_length`):
//!   repeaters are placed along the routed tree each time the wire from the last repeater
//!   exceeds the limit; each drives the sinks downstream of it.
//! * `add_tie_hi_lo` (addTieHiLo): constant inputs get tie cells, at most `-max_fanout` loads
//!   per tie and loads within `-max_distance` of it.
//! * `add_port_diodes`: an antenna diode cell under each I/O port pin, connected to the port net.

use crate::droute::NONE;
use crate::netlist::*;
use crate::rtrules::OpcRules;
use crate::session::{args, Session};
use crate::tcl::{err, split_list, R};
use std::collections::{HashMap, HashSet};

#[derive(Clone, Debug, Default)]
pub struct RouteOpts {
    pub timing_driven: bool,
    /// 0 default, 1 low, 2 medium, 3 high
    pub effort: u8,
    pub min_layer: Option<usize>,
    pub max_layer: Option<usize>,
    pub layer_jogs: bool,
    pub antenna_diode: Option<String>,
    pub max_buf_dist: f64,
    pub opc: Option<OpcRules>,
    /// layer cost factors for one routing call (antenna layer jumpers)
    pub layer_cost: Vec<f32>,
}

fn effort_of(s: &str) -> Option<u8> {
    match s.to_lowercase().as_str() {
        "low" => Some(1),
        "medium" | "standard" => Some(2),
        "high" | "extreme" => Some(3),
        _ => None,
    }
}

impl Session {
    /// apply route command options (persist for later route calls, like setNanoRouteMode)
    pub(crate) fn route_options(&mut self, cmd: &str, a: &[String]) -> Result<(), crate::tcl::Flow> {
        let x = args(a, &["-effort_level", "-effort", "-min_layer", "-min_routing_layer", "-max_layer", "-max_routing_layer", "-antenna_diode", "-antenna_diode_cell", "-max_buffering_distance", "-opc", "-max_detail_route_iterations", "-max_iterations", "-nets"]);
        let order = self.metal_order();
        let lidx = |s: &str| -> Result<usize, crate::tcl::Flow> {
            order.iter().position(|l| l.eq_ignore_ascii_case(s)).or_else(|| s.trim_start_matches(['M', 'm']).parse::<usize>().ok().map(|k| k.saturating_sub(1))).ok_or_else(|| crate::tcl::Flow::Err(format!("{}: unknown routing layer '{}' (RT-021)", cmd, s)))
        };
        if x.has("-timing_driven") { self.rt.timing_driven = true; }
        if x.has("-no_timing_driven") { self.rt.timing_driven = false; }
        if let Some(e) = x.get("-effort_level").or(x.get("-effort")) {
            self.rt.effort = effort_of(e).ok_or_else(|| crate::tcl::Flow::Err(format!("{}: -effort_level low | medium | high (RT-022)", cmd)))?;
        }
        if let Some(l) = x.get("-min_layer").or(x.get("-min_routing_layer")) { self.rt.min_layer = Some(lidx(l)?); }
        if let Some(l) = x.get("-max_layer").or(x.get("-max_routing_layer")) { self.rt.max_layer = Some(lidx(l)?); }
        if let (Some(a0), Some(b0)) = (self.rt.min_layer, self.rt.max_layer) {
            if a0 > b0 { return Err(crate::tcl::Flow::Err(format!("{}: -min_layer is above -max_layer (RT-023)", cmd))); }
        }
        if x.has("-layer_jogs") || x.has("-antenna_layer_jogs") { self.rt.layer_jogs = true; }
        if let Some(c) = x.get("-antenna_diode").or(x.get("-antenna_diode_cell")) {
            let c = c.rsplit('/').next().unwrap_or(c).to_string();
            if !self.libs.iter().any(|l| l.cells.contains_key(&c)) {
                return Err(crate::tcl::Flow::Err(format!("{}: antenna diode cell '{}' not found in the libraries (RT-024)", cmd, c)));
            }
            self.rt.antenna_diode = Some(c);
        }
        if let Some(d) = x.num("-max_buffering_distance") {
            if d < 0.0 { return Err(crate::tcl::Flow::Err(format!("{}: -max_buffering_distance must be >= 0 (RT-025)", cmd))); }
            self.rt.max_buf_dist = d;
        }
        if let Some(f) = x.get("-opc") { self.load_opc(f)?; }
        let mut s = vec![];
        if self.rt.timing_driven { s.push("timing-driven".to_string()); }
        if self.rt.effort > 0 { s.push(format!("effort {}", ["", "low", "medium", "high"][self.rt.effort as usize])); }
        if let Some(l) = self.rt.min_layer { s.push(format!("min layer {}", order.get(l).cloned().unwrap_or_default())); }
        if let Some(l) = self.rt.max_layer { s.push(format!("max layer {}", order.get(l).cloned().unwrap_or_default())); }
        if self.rt.layer_jogs { s.push("antenna layer jogs".into()); }
        if let Some(d) = &self.rt.antenna_diode { s.push(format!("antenna diode {}", d)); }
        if self.rt.max_buf_dist > 0.0 { s.push(format!("max buffering distance {}um", self.rt.max_buf_dist)); }
        if let Some(o) = &self.rt.opc { s.push(format!("OPC rules {}", o.file)); }
        if !s.is_empty() { crate::info!("RT-020", "{}: {}", cmd, s.join(", ")); }
        Ok(())
    }

    /// after a detailed route: LEF minimum-area patches, OPC line ends, fill trim, antenna repair,
    /// net-length buffering
    pub(crate) fn route_post(&mut self, cmd: &str) -> Result<(), crate::tcl::Flow> {
        if let Some(mut db) = self.routes.take() {
            self.min_area_repair(&mut db, cmd);
            if let Some(o) = self.rt.opc.clone() {
                let n = self.line_end_extension(&mut db, &o);
                if n > 0 { crate::info!("OPC-110", "{}: {} line end(s) extended (OPC rules)", cmd, n); }
            }
            self.routes = Some(db);
        }
        if self.rt.layer_jogs || self.rt.antenna_diode.is_some() {
            self.antenna_fix(cmd)?;
        }
        if self.rt.max_buf_dist > 0.0 {
            let d = self.rt.max_buf_dist;
            self.net_length_buffering(d, None, cmd)?;
            if let Some(mut db) = self.routes.take() { self.min_area_repair(&mut db, cmd); self.routes = Some(db); }
        }
        let t = self.trim_fill();
        if t > 0 { crate::info!("FILL-112", "{}: {} metal-fill shape(s) trimmed for the new routing", cmd, t); }
        self.refresh_rc();
        Ok(())
    }

    /// worst slack per net (timing-driven routing order); empty when timing is unavailable
    pub(crate) fn net_slacks(&mut self) -> HashMap<NetId, f64> {
        if self.libs.is_empty() { return HashMap::new(); }
        self.with_env(|nl, env| {
            let a = env.analyze(nl, 0);
            let mut m: HashMap<NetId, f64> = HashMap::new();
            for (p, s) in &a.slack {
                if let Some(n) = nl.pin_net(*p) { let e = m.entry(n).or_insert(f64::MAX); if *s < *e { *e = *s; } }
            }
            m
        }).unwrap_or_default()
    }

    /// LEF minimum-area patches, then rerouting of the nets whose pieces had no room for a patch
    pub(crate) fn min_area_repair(&self, db: &mut crate::droute::RouteDb, cmd: &str) {
        let (f, mut badn) = self.fix_min_area_nets(db);
        let bad0 = badn.len();
        // pieces without room for a patch: each failing net alone is rerouted (legal-only, steered off
        // its failing landings) and kept only when its own pieces improve; else its route goes back
        let p = crate::droute::RouteParams { max_iter: 2, via_cost: self.appf("route.detail.via_cost") as f32 * 2.0, m1_cost: self.appf("route.detail.wrong_way_cost") as f32, adj_cost: 0.5, layer_cost: vec![], order: vec![], legal_only: true, fp_steps: vec![], fp_cost: 0.0 };
        for round in 0..4 {
            if badn.is_empty() { break; }
            let mut by: std::collections::BTreeMap<NetId, Vec<u32>> = std::collections::BTreeMap::new();
            for (n, nodes) in &badn { by.entry(*n).or_default().extend(nodes.iter().copied()); }
            let mut improved = 0;
            for (net, nodes) in by {
                let Some(old) = db.nets.get(&net).cloned() else { continue };
                let before = badn.iter().filter(|b| b.0 == net).count();
                for nd in &nodes { db.hist[*nd as usize] += 20.0 * (round + 1) as f32; }
                crate::droute::route(db, vec![old.clone()], &p);
                let (_, b2) = self.fix_min_area_for(db, Some(net));
                let open = db.nets.get(&net).map(|r| r.open).unwrap_or(true);
                if open || b2.len() >= before {
                    // back to the previous route (nothing else moved)
                    if let Some(cur) = db.nets.remove(&net) { for (nd, _) in &cur.tree { let o = &mut db.occ[*nd as usize]; *o = o.saturating_sub(1); } }
                    for (nd, _) in &old.tree { db.occ[*nd as usize] += 1; }
                    db.nets.insert(net, old);
                } else {
                    improved += 1;
                }
            }
            let (_, b) = self.fix_min_area_nets(db);
            badn = b;
            if improved == 0 { break; }
        }
        let bad = badn.len();
        if bad < bad0 { crate::info!("RT-121", "{}: minimum-area repair by rerouting: pieces without room {} -> {}", cmd, bad0, bad); }
        if f + bad > 0 { crate::info!("RT-120", "{}: {} minimum-area patch(es) (LEF AREA){}", cmd, f, if bad > 0 { format!(", {} piece(s) without room", bad) } else { String::new() }); }
    }

    // ------------------------------------------------------------------ antenna
    /// antenna violations: (net, gate pin, layer, ratio, limit)
    pub(crate) fn antenna_violations(&self) -> Result<Vec<(NetId, PinRef, usize, f64, f64)>, crate::tcl::Flow> {
        let nl = self.nl()?;
        let db = self.routes.as_ref().ok_or_else(|| crate::tcl::Flow::Err("check_antenna: not routed (RT-400)".into()))?;
        let rules = self.layer_rules();
        let def_ratio = { let v = self.appf("route.antenna.max_ratio"); if v > 0.0 { v } else { 400.0 } };
        let def_gate = { let v = self.appf("route.antenna.gate_area"); if v > 0.0 { v } else { 0.05 } };
        let gate_area = |c: CellId, pi: usize| -> f64 {
            crate::lef::phys(&self.lef, nl.cell(c)).and_then(|m| m.pins.iter().find(|p| p.name == nl.cell(c).pins[pi].name).map(|p| p.gate_area)).filter(|a| *a > 0.0).unwrap_or(def_gate)
        };
        let is_diode = |c: CellId| -> bool { let n = nl.cell(c).lib().unwrap_or("").to_uppercase(); n.contains("ANTENNA") || n.contains("DIODE") || crate::lef::phys(&self.lef, nl.cell(c)).map(|m| m.class.contains("ANTENNACELL")).unwrap_or(false) };
        let mut out = vec![];
        let mut ids: Vec<NetId> = db.nets.keys().copied().collect();
        ids.sort();
        for id in ids {
            let rn = &db.nets[&id];
            if rn.tree.len() < 2 { continue; }
            // protected nodes: driver pin (diffusion), diodes, ports
            let mut prot: HashSet<u32> = HashSet::new();
            let mut gates: Vec<(PinRef, u32)> = vec![];
            for (p, nd) in &rn.pins {
                match p {
                    PinRef::Port(_) => { prot.insert(*nd); }
                    PinRef::Cell(c, i) => {
                        if nl.cell(*c).pins[*i].dir != Dir::In || is_diode(*c) { prot.insert(*nd); } else { gates.push((*p, *nd)); }
                    }
                }
            }
            if gates.is_empty() { continue; }
            let nlay = db.layers.len();
            for top in 1..nlay {
                let limit = rules.get(top).map(|r| r.lef.ant_ratio).filter(|v| *v > 0.0).unwrap_or(def_ratio);
                // components over layers 0..=top
                let mut par: HashMap<u32, u32> = HashMap::new();
                fn f(p: &mut HashMap<u32, u32>, x: u32) -> u32 { let mut r = x; while let Some(&q) = p.get(&r) { if q == r { break; } r = q; } r }
                for &(nd, _) in &rn.tree { if db.xyl(nd).2 <= top { par.insert(nd, nd); } }
                for &(nd, p) in &rn.tree {
                    if p == NONE || !par.contains_key(&nd) || !par.contains_key(&p) { continue; }
                    let (a, b) = (f(&mut par, nd), f(&mut par, p));
                    if a != b { par.insert(a, b); }
                }
                let mut area: HashMap<u32, f64> = HashMap::new();
                let w = rules.get(top).map(|r| r.width).unwrap_or(0.1) * rn.wmul.max(1.0) as f64;
                for &(nd, p) in &rn.tree {
                    if p == NONE || !par.contains_key(&nd) { continue; }
                    let (l1, l2) = (db.xyl(nd).2, db.xyl(p).2);
                    if l1 == top && l2 == top { *area.entry(f(&mut par, nd)).or_default() += db.g * w; }
                }
                let mut safe: HashSet<u32> = HashSet::new();
                for n in &prot { if par.contains_key(n) { safe.insert(f(&mut par, *n)); } }
                let mut garea: HashMap<u32, f64> = HashMap::new();
                for (p, nd) in &gates {
                    if !par.contains_key(nd) { continue; }
                    if let PinRef::Cell(c, i) = p { *garea.entry(f(&mut par, *nd)).or_default() += gate_area(*c, *i); }
                }
                for (p, nd) in &gates {
                    if !par.contains_key(nd) { continue; }
                    let r = f(&mut par, *nd);
                    if safe.contains(&r) { continue; }
                    let ratio = area.get(&r).copied().unwrap_or(0.0) / garea.get(&r).copied().unwrap_or(def_gate).max(1e-6);
                    if ratio > limit { out.push((id, *p, top, ratio, limit)); }
                }
            }
        }
        Ok(out)
    }

    /// layer jumpers (reroute with costly low layers) then diodes beside the gates still failing
    pub(crate) fn antenna_fix(&mut self, cmd: &str) -> Result<(usize, usize), crate::tcl::Flow> {
        let v0 = self.antenna_violations()?;
        if v0.is_empty() { crate::info!("ANT-100", "{}: no antenna violations", cmd); return Ok((0, 0)); }
        let nets0: HashSet<NetId> = v0.iter().map(|v| v.0).collect();
        let mut jumped = 0;
        if self.rt.layer_jogs {
            // jumpers: the violating nets climb to upper metal early (lower layers 6x the cost)
            let nl_layers = self.routes.as_ref().map(|d| d.layers.len()).unwrap_or(0);
            let lc: Vec<f32> = (0..nl_layers).map(|l| if l >= 1 && l + 2 < nl_layers { 6.0 } else { 1.0 }).collect();
            let todo: Vec<crate::droute::RNet> = { let db = self.routes.as_ref().unwrap(); nets0.iter().filter_map(|n| db.nets.get(n).cloned()).collect() };
            let mut db = self.routes.take().unwrap();
            let p = crate::droute::RouteParams { max_iter: 3, via_cost: self.appf("route.detail.via_cost") as f32 * 0.5, m1_cost: self.appf("route.detail.wrong_way_cost") as f32, adj_cost: 0.0, layer_cost: lc, order: vec![], legal_only: false, fp_steps: vec![], fp_cost: 0.0 };
            crate::droute::route(&mut db, todo, &p);
            let _ = self.fix_min_area(&mut db);
            self.routes = Some(db);
            let v1 = self.antenna_violations()?;
            let n1: HashSet<NetId> = v1.iter().map(|v| v.0).collect();
            jumped = nets0.difference(&n1).count();
            crate::info!("ANT-110", "{}: layer jumpers on {} net(s): {} fixed, {} violation(s) left", cmd, nets0.len(), jumped, v1.len());
        }
        let left = self.antenna_violations()?;
        let mut diodes = 0;
        if let (Some(dc), false) = (self.rt.antenna_diode.clone(), left.is_empty()) {
            let lc = self.libs.iter().find_map(|l| l.cells.get(&dc)).cloned().unwrap();
            let pin = lc.pins.first().map(|p| p.name.clone()).unwrap_or("A".into());
            let mut seen: HashSet<(NetId, PinRef)> = HashSet::new();
            let mut new_cells = vec![];
            {
                let nl = self.nlm()?;
                for (net, gp, _, _, _) in &left {
                    if !seen.insert((*net, *gp)) { continue; }
                    let loc = nl.pin_loc(*gp);
                    let nm = nl.fresh("antenna_diode_");
                    let c = nl.add_cell(&nm, Kind::Lib(dc.clone()), &crate::opt::lib_pins(&lc));
                    nl.connect_name(c, &pin, *net);
                    nl.cell_mut(c).loc = loc;
                    nl.cell_mut(c).attrs.push("antenna_diode".into());
                    nl.cell_mut(c).dont_touch = true;
                    new_cells.push(c);
                    diodes += 1;
                }
            }
            if !new_cells.is_empty() {
                let _ = self.fp_legalize(Some(new_cells), false, true);
                self.route_incremental(false, false)?;
                if let Some(mut db) = self.routes.take() { let _ = self.fix_min_area(&mut db); self.routes = Some(db); }
            }
            let v2 = self.antenna_violations()?;
            crate::info!("ANT-120", "{}: {} antenna diode(s) {} inserted beside failing gate pins; {} violation(s) left", cmd, diodes, dc, v2.len());
        }
        Ok((jumped, diodes))
    }

    // ------------------------------------------------------------------ net length
    /// routed length (um) per net (lateral tree edges), or the HPWL when not routed
    pub(crate) fn net_lengths(&self) -> Vec<(NetId, f64)> {
        let Some(nl) = self.nl.as_ref() else { return vec![] };
        if let Some(db) = self.routes.as_ref() {
            let mut v: Vec<(NetId, f64)> = db.nets.iter().map(|(n, rn)| {
                let l = rn.tree.iter().filter(|(c, p)| *p != NONE && db.xyl(*c).2 == db.xyl(*p).2 && !db.patches.contains_key(c)).count() as f64 * db.g;
                (*n, l)
            }).collect();
            v.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap().then(a.0.cmp(&b.0)));
            return v;
        }
        let mut v: Vec<(NetId, f64)> = nl.net_ids().into_iter().map(|n| {
            let pts: Vec<(f64, f64)> = nl.net(n).conns.iter().filter_map(|p| nl.pin_loc(*p)).collect();
            if pts.len() < 2 { return (n, 0.0); }
            let (x0, x1) = pts.iter().fold((f64::MAX, f64::MIN), |a, p| (a.0.min(p.0), a.1.max(p.0)));
            let (y0, y1) = pts.iter().fold((f64::MAX, f64::MIN), |a, p| (a.0.min(p.1), a.1.max(p.1)));
            (n, (x1 - x0) + (y1 - y0))
        }).collect();
        v.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap().then(a.0.cmp(&b.0)));
        v
    }

    fn default_length_buffer(&self) -> Option<crate::liberty::LibCell> {
        let want = self.app.get("route_opt.flow.net_length_buffer").cloned().unwrap_or_default();
        if !want.is_empty() {
            return self.libs.iter().find_map(|l| l.cells.get(&want)).cloned();
        }
        let mut bufs: Vec<crate::liberty::LibCell> = self.libs.iter().flat_map(|l| l.cells.values()).filter(|c| c.is_buf && !c.name.to_uppercase().contains("CLK") && !c.name.to_uppercase().contains("AON") && !self.dont_use.iter().any(|d| glob(d, &c.name))).cloned().collect();
        bufs.sort_by(|a, b| a.drive.partial_cmp(&b.drive).unwrap_or(std::cmp::Ordering::Equal).then(a.name.cmp(&b.name)));
        bufs.dedup_by(|a, b| a.name == b.name);
        if bufs.is_empty() { return None; }
        let k = (bufs.len() * 2 / 3).min(bufs.len() - 1);
        Some(bufs[k].clone())
    }

    /// repeaters along routed nets longer than `max_len`: one each time the wire from the last
    /// repeater (or the driver) passes `max_len`
    /// net-length buffering in up to three passes (rerouting after a pass can leave a net long)
    pub(crate) fn net_length_buffering(&mut self, max_len: f64, only: Option<&HashSet<String>>, cmd: &str) -> Result<usize, crate::tcl::Flow> {
        let mut total = 0;
        let mut prev = f64::MAX;
        for pass in 0..3 {
            let n = self.net_length_pass(max_len, only, cmd, pass)?;
            total += n;
            let worst = self.longest_signal_net();
            if n == 0 || worst <= max_len || worst >= prev - 1e-6 { break; }
            prev = worst;
        }
        Ok(total)
    }

    /// routed length of the longest non-clock net
    pub(crate) fn longest_signal_net(&self) -> f64 {
        let Some(nl) = self.nl.as_ref() else { return 0.0 };
        let clock: HashSet<NetId> = self.cts_nets.iter().filter_map(|n| nl.net_by_name(n)).collect();
        let db = self.routes.as_ref();
        self.net_lengths().into_iter().filter(|(n, _)| !clock.contains(n) && !db.and_then(|d| d.nets.get(n)).map(|r| r.clock).unwrap_or(false)).map(|x| x.1).fold(0.0, f64::max)
    }

    fn net_length_pass(&mut self, max_len: f64, only: Option<&HashSet<String>>, cmd: &str, pass: usize) -> Result<usize, crate::tcl::Flow> {
        if max_len <= 0.0 { return Ok(0); }
        let buf = self.default_length_buffer().ok_or_else(|| crate::tcl::Flow::Err(format!("{}: no buffer cell for net-length buffering (route_opt.flow.net_length_buffer) (OPT-940)", cmd)))?;
        if self.routes.is_none() {
            return Err(crate::tcl::Flow::Err(format!("{}: net-length buffering needs a routed design (route_auto first) (OPT-941)", cmd)));
        }
        let clock: HashSet<NetId> = { let nl = self.nl()?; self.cts_nets.iter().filter_map(|n| nl.net_by_name(n)).collect() };
        let long: Vec<(NetId, f64)> = self.net_lengths().into_iter().filter(|(_, l)| *l > max_len).collect();
        let core = self.fp.as_ref().map(|f| f.core.unwrap_or(f.die)).unwrap_or((0.0, 0.0, 1e9, 1e9));
        let (inp, out) = (buf.inputs()[0].name.clone(), buf.outputs()[0].name.clone());
        let mut made = vec![];
        let mut nets_done = 0;
        let mut skipped = 0;
        for (net, len) in long {
            let (rn, g, pos) = {
                let db = self.routes.as_ref().unwrap();
                let Some(rn) = db.nets.get(&net).cloned() else { continue };
                let pos: HashMap<u32, (f64, f64, usize)> = rn.tree.iter().map(|(n, _)| (*n, db.pos(*n))).collect();
                (rn, db.g, pos)
            };
            let nl = self.nl()?;
            if clock.contains(&net) || rn.clock || nl.net(net).dont_touch { skipped += 1; continue; }
            if let Some(o) = only { if !o.contains(&nl.net(net).name) { continue; } }
            // sinks must be on this net (no boundary-joined groups)
            if rn.pins.iter().any(|(p, _)| nl.pin_net(*p) != Some(net)) || rn.pins.is_empty() { skipped += 1; continue; }
            let Some(drv) = nl.driver(net) else { skipped += 1; continue };
            let root = match rn.pins.iter().find(|(p, _)| *p == drv) { Some(r) => r.1, None => { skipped += 1; continue } };
            // tree as children lists rooted at the driver node
            let mut adj: HashMap<u32, Vec<u32>> = HashMap::new();
            for &(c, p) in &rn.tree { if p != NONE { adj.entry(c).or_default().push(p); adj.entry(p).or_default().push(c); } }
            let sinks_at: HashMap<u32, Vec<PinRef>> = rn.pins.iter().filter(|(p, _)| *p != drv).fold(HashMap::new(), |mut m, (p, n)| { m.entry(*n).or_insert_with(Vec::new).push(*p); m });
            // bottom-up length clustering: walking up from the sinks, a repeater goes where the
            // wire of the subtree below a node reaches the budget, and drives that subtree
            let margin = max_len * 0.85;
            let mut par: HashMap<u32, u32> = HashMap::new();
            let mut order: Vec<u32> = vec![root];
            par.insert(root, NONE);
            let mut qi = 0;
            while qi < order.len() {
                let u = order[qi];
                qi += 1;
                for &v in adj.get(&u).map(|x| x.as_slice()).unwrap_or(&[]) {
                    if par.contains_key(&v) { continue; }
                    par.insert(v, u);
                    order.push(v);
                }
            }
            let elen = |a: u32, b: u32| -> f64 { if pos[&a].2 == pos[&b].2 { g } else { 0.0 } };
            let mut acc: HashMap<u32, f64> = HashMap::new();
            let mut rep: HashSet<u32> = HashSet::new();
            for &v in order.iter().rev() {
                let mut w = acc.get(&v).copied().unwrap_or(0.0);
                if v != root && w >= margin { rep.insert(v); w = 0.0; }
                let p = par[&v];
                if p != NONE { *acc.entry(p).or_insert(0.0) += w + elen(v, p); }
            }
            let mut owners: Vec<(Option<usize>, (f64, f64), Vec<PinRef>)> = vec![(None, (0.0, 0.0), vec![])];
            let mut own: HashMap<u32, usize> = HashMap::new();
            for &v in &order {
                let p = par[&v];
                let po = if p == NONE { 0 } else { own[&p] };
                let o = if rep.contains(&v) { owners.push((Some(po), (pos[&v].0, pos[&v].1), vec![])); owners.len() - 1 } else { po };
                own.insert(v, o);
                if let Some(ps) = sinks_at.get(&v) { owners[o].2.extend(ps.iter().copied()); }
            }
            // drop repeaters with nothing downstream (merge them into their owner)
            let n = owners.len();
            let mut has: Vec<bool> = owners.iter().map(|o| !o.2.is_empty()).collect();
            for k in (1..n).rev() { if has[k] { if let Some(p) = owners[k].0 { has[p] = true; } } }
            if owners.len() <= 1 || !has.iter().skip(1).any(|x| *x) { continue; }
            let nl = self.nlm()?;
            let mut netof: Vec<Option<NetId>> = vec![None; n];
            netof[0] = Some(net);
            let mut cnt = 0;
            for k in 1..n {
                if !has[k] { continue; }
                let mut p = owners[k].0;
                while let Some(q) = p { if q == 0 || has[q] { break; } p = owners[q].0; }
                let up = netof[p.unwrap_or(0)].unwrap_or(net);
                let nm = nl.fresh("len_buf_");
                let c = nl.add_cell(&nm, Kind::Lib(buf.name.clone()), &crate::opt::lib_pins(&buf));
                let nn = nl.add_net(&format!("{}_net", nm));
                nl.connect_name(c, &inp, up);
                nl.connect_name(c, &out, nn);
                let p0 = owners[k].1;
                nl.cell_mut(c).loc = Some((p0.0.clamp(core.0 + 0.5, core.2 - 1.0), p0.1.clamp(core.1 + 0.5, core.3 - 1.0)));
                nl.cell_mut(c).attrs.push("opt_buffer".into());
                netof[k] = Some(nn);
                made.push(c);
                cnt += 1;
            }
            // sinks follow their nearest kept repeater
            for k in 0..n {
                let mut o = Some(k);
                while let Some(q) = o { if q == 0 || has[q] && netof[q].is_some() { break; } o = owners[q].0; }
                let tn = netof[o.unwrap_or(0)].unwrap_or(net);
                if tn == net { continue; }
                for p in owners[k].2.clone() {
                    match p {
                        PinRef::Cell(c, i) => nl.connect(c, i, tn),
                        PinRef::Port(q) => nl.connect_port(q, tn),
                    }
                }
            }
            nets_done += 1;
            crate::info!("OPT-942", "Net '{}' ({:.1}um routed > {:.1}um): {} repeater(s) {}", nl.net(net).name, len, max_len, cnt, buf.name);
        }
        if !made.is_empty() {
            let _ = self.fp_legalize(Some(made.clone()), false, true);
            self.route_incremental(false, false)?;
            if let Some(mut db) = self.routes.take() { let _ = self.fix_min_area(&mut db); self.routes = Some(db); }
        }
        let worst = self.longest_signal_net();
        if pass > 0 && made.is_empty() { return Ok(0); }
        crate::info!("OPT-943", "{}: net-length buffering (max {:.1}um, pass {}): {} net(s), {} repeater(s) {}, {} skipped (clock / dont_touch / hierarchical); longest signal net now {:.1}um", cmd, max_len, pass + 1, nets_done, made.len(), buf.name, skipped, worst);
        Ok(made.len())
    }

    // ------------------------------------------------------------------ ties
    pub(crate) fn add_tie_hi_lo(&mut self, a: &[String], name: &str) -> R {
        let x = args(a, &["-cell", "-cells", "-tie_high_cell", "-tie_low_cell", "-max_fanout", "-maxFanout", "-max_distance", "-maxDistance", "-prefix"]);
        let cells: Vec<String> = x.get("-cell").or(x.get("-cells")).map(|s| split_list(s)).unwrap_or_default();
        let find = |s: &Session, want_hi: bool, n: Option<&String>| -> Option<crate::liberty::LibCell> {
            if let Some(n) = n { return s.libs.iter().find_map(|l| l.cells.get(n.rsplit('/').next().unwrap_or(n))).cloned(); }
            for c in &cells { if let Some(lc) = s.libs.iter().find_map(|l| l.cells.get(c.rsplit('/').next().unwrap_or(c))) { if lc.tie == Some(want_hi) { return Some(lc.clone()); } } }
            if !cells.is_empty() { return None; }
            s.libs.iter().flat_map(|l| l.cells.values()).filter(|c| c.tie == Some(want_hi) && !s.dont_use.iter().any(|d| glob(d, &c.name))).min_by(|a, b| a.area.partial_cmp(&b.area).unwrap().then(a.name.cmp(&b.name))).cloned()
        };
        let want_hi = name != "add_tie_low";
        let want_lo = name != "add_tie_high";
        let hi = if want_hi { find(self, true, x.get("-tie_high_cell")) } else { None };
        let lo = if want_lo { find(self, false, x.get("-tie_low_cell")) } else { None };
        if (want_hi && hi.is_none()) && (want_lo && lo.is_none()) { return err(format!("{}: no TIEHI / TIELO cell (give -cell {{tie_hi tie_lo}}) (TIE-001)", name)); }
        let maxf = x.num("-max_fanout").or(x.num("-maxFanout")).map(|v| v as usize).unwrap_or_else(|| { let v = self.appu("opt.tie_cell.max_fanout"); if v > 0 { v } else { 8 } }).max(1);
        let maxd = x.num("-max_distance").or(x.num("-maxDistance")).unwrap_or(0.0);
        let prefix = x.get("-prefix").cloned().unwrap_or_else(|| "tie_".into());
        let placed = self.fp.is_some();
        let nl = self.nlm()?;
        // constant sources: generic constants and existing tie cells
        let mut srcs: Vec<(CellId, bool, NetId)> = vec![];
        for c in nl.cell_ids() {
            let v = match nl.cell(c).gop() { Some(GOp::C0) => Some(false), Some(GOp::C1) => Some(true), _ => None };
            let v = v.or_else(|| nl.cell(c).lib().and_then(|l| { let up = l.to_uppercase(); if up.starts_with("TIEHI") || up.starts_with("TIEH") && !up.starts_with("TIEL") { Some(true) } else if up.starts_with("TIELO") || up.starts_with("TIEL") { Some(false) } else { None } }));
            let Some(v) = v else { continue };
            let Some(net) = nl.cell(c).pins.iter().find(|p| p.dir == Dir::Out).and_then(|p| p.net) else { continue };
            srcs.push((c, v, net));
        }
        let mut made: Vec<CellId> = vec![];
        let (mut nh, mut nlo, mut moved) = (0, 0, 0);
        for (src, v, net) in srcs {
            let tc = if v { &hi } else { &lo };
            let Some(tc) = tc.clone() else { continue };
            // instance inputs and output ports driven by the constant
            let loads: Vec<PinRef> = nl.loads(net);
            if loads.is_empty() { continue; }
            let is_tie_cell = nl.cell(src).lib().is_some();
            // already within the limits: keep
            if is_tie_cell && loads.len() <= maxf && (maxd <= 0.0 || { let sl = nl.cell(src).loc; loads.iter().all(|l| match (sl, nl.pin_loc(*l)) { (Some(a), Some(b)) => (a.0 - b.0).abs() + (a.1 - b.1).abs() <= maxd, _ => true }) }) { continue; }
            // greedy clusters by location: seed, then nearest loads within max_distance until max_fanout
            let mut rest: Vec<PinRef> = loads.clone();
            rest.sort_by(|a, b| { let (pa, pb) = (nl.pin_loc(*a).unwrap_or((0.0, 0.0)), nl.pin_loc(*b).unwrap_or((0.0, 0.0))); pa.0.partial_cmp(&pb.0).unwrap().then(pa.1.partial_cmp(&pb.1).unwrap()) });
            while !rest.is_empty() {
                let seed = rest.remove(0);
                let sp = nl.pin_loc(seed);
                let mut grp = vec![seed];
                if let Some(s0) = sp {
                    let mut cand: Vec<(f64, usize)> = rest.iter().enumerate().filter_map(|(i, p)| nl.pin_loc(*p).map(|q| ((q.0 - s0.0).abs() + (q.1 - s0.1).abs(), i))).filter(|(d, _)| maxd <= 0.0 || *d <= maxd * 2.0).collect();
                    cand.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
                    let take: Vec<usize> = cand.iter().take(maxf - 1).map(|c| c.1).collect();
                    let mut take_s = take.clone();
                    take_s.sort_unstable_by(|a, b| b.cmp(a));
                    for i in take_s { grp.push(rest.remove(i)); }
                } else {
                    while grp.len() < maxf && !rest.is_empty() { grp.push(rest.remove(0)); }
                }
                let h = match grp[0] { PinRef::Cell(c, _) => nl.cell(c).hier_prefix().to_string(), _ => String::new() };
                let base = nl.fresh(&format!("{}{}_", prefix, if v { "hi" } else { "lo" }));
                let nm = if h.is_empty() { base } else { format!("{}/{}", h, base) };
                let t = nl.add_cell(&nm, Kind::Lib(tc.name.clone()), &crate::opt::lib_pins(&tc));
                let tn = nl.add_net(&format!("{}_net", nm));
                nl.connect_name(t, &tc.outputs()[0].name.clone(), tn);
                let pts: Vec<(f64, f64)> = grp.iter().filter_map(|p| nl.pin_loc(*p)).collect();
                for p in &grp {
                    match p { PinRef::Cell(c, i) => nl.connect(*c, *i, tn), PinRef::Port(q) => nl.connect_port(*q, tn) }
                    moved += 1;
                }
                if !pts.is_empty() { nl.cell_mut(t).loc = Some((pts.iter().map(|p| p.0).sum::<f64>() / pts.len() as f64, pts.iter().map(|p| p.1).sum::<f64>() / pts.len() as f64)); }
                nl.cell_mut(t).attrs.push("tie".into());
                made.push(t);
                if v { nh += 1 } else { nlo += 1 }
            }
            // an emptied tie cell goes away
            if is_tie_cell && nl.loads(net).is_empty() { nl.remove_cell(src); }
        }
        nl.sweep_nets();
        if placed && !made.is_empty() { let _ = self.fp_legalize(Some(made.clone()), false, true); }
        crate::info!("TIE-100", "{}: {} tie-high {}, {} tie-low {} added for {} constant input(s) (max fanout {}{})", name, nh, hi.map(|c| c.name).unwrap_or("-".into()), nlo, lo.map(|c| c.name).unwrap_or("-".into()), moved, maxf, if maxd > 0.0 { format!(", max distance {}um", maxd) } else { String::new() });
        Ok((nh + nlo).to_string())
    }

    // ------------------------------------------------------------------ port diodes
    pub(crate) fn add_port_diodes(&mut self, a: &[String], name: &str) -> R {
        let x = args(a, &["-cell", "-diode_cell", "-ports", "-direction", "-prefix", "-offset"]);
        let Some(cn) = x.get("-cell").or(x.get("-diode_cell")).cloned() else { return err(format!("{}: -cell <antenna diode cell> is required (ANT-201)", name)) };
        let cn = cn.rsplit('/').next().unwrap_or(&cn).to_string();
        let Some(lc) = self.libs.iter().find_map(|l| l.cells.get(&cn)).cloned() else { return err(format!("{}: cell '{}' not found (ANT-202)", name, cn)) };
        let pin = lc.pins.first().map(|p| p.name.clone()).ok_or_else(|| crate::tcl::Flow::Err(format!("{}: '{}' has no pin", name, cn)))?;
        let pats: Vec<String> = x.get("-ports").map(|s| split_list(s)).unwrap_or_else(|| vec!["*".into()]);
        let dir = x.get("-direction").cloned().unwrap_or_else(|| "input".into());
        let prefix = x.get("-prefix").cloned().unwrap_or_else(|| "port_diode_".into());
        let Some(fp) = self.fp.as_ref() else { return err(format!("{}: no floorplan (FP-001)", name)) };
        let core = fp.core.unwrap_or(fp.die);
        let rh = fp.row_h;
        let off = x.num("-offset").unwrap_or(rh.max(0.5));
        let info = fp.pin_info.clone();
        let nl = self.nlm()?;
        let mut made = vec![];
        let mut skipped = 0;
        for p in nl.port_ids() {
            let pn = nl.ports[p].name.clone();
            if !pats.iter().any(|q| glob(q, &pn) || q == &pn) { continue; }
            let d = nl.ports[p].dir;
            let ok = match dir.as_str() { "input" | "in" => d == Dir::In, "output" | "out" => d == Dir::Out, _ => true };
            if !ok { continue; }
            let (Some(net), Some(l)) = (nl.ports[p].net, nl.ports[p].loc) else { skipped += 1; continue };
            if nl.net(net).conns.iter().any(|q| matches!(q, PinRef::Cell(c, _) if nl.cell(*c).has_attr("port_diode"))) { skipped += 1; continue; }
            // inside the core, under the port pin (projected inward)
            let (cx, cy) = (l.0.clamp(core.0 + off, core.2 - off), l.1.clamp(core.1 + off, core.3 - off));
            let nm = nl.fresh(&prefix);
            let c = nl.add_cell(&nm, Kind::Lib(cn.clone()), &crate::opt::lib_pins(&lc));
            nl.connect_name(c, &pin, net);
            nl.cell_mut(c).loc = Some((cx, cy));
            nl.cell_mut(c).attrs.push("port_diode".into());
            nl.cell_mut(c).attrs.push("antenna_diode".into());
            nl.cell_mut(c).dont_touch = true;
            made.push(c);
            let _ = info.get(&pn);
        }
        let n = made.len();
        if n > 0 {
            let _ = self.fp_legalize(Some(made.clone()), false, true);
            let nl = self.nlm()?;
            for c in &made { nl.cell_mut(*c).fixed = true; }
        }
        crate::info!("ANT-200", "{}: {} diode(s) {} attached under {} I/O port(s) (fixed){}", name, n, cn, dir, if skipped > 0 { format!("; {} port(s) skipped (unplaced / unconnected / already protected)", skipped) } else { String::new() });
        Ok(n.to_string())
    }

    // ------------------------------------------------------------------ placement options
    /// place_opt / place_detail: -timing_driven, -effort, -congestion_effort,
    /// -preroute_as_blockages [layers]; returns (state to restore, remaining args)
    pub(crate) fn place_options_begin(&mut self, cmd: &str, a: &[String]) -> Result<(PlaceSave, Vec<String>), crate::tcl::Flow> {
        let mut rest = vec![];
        let mut sv = PlaceSave::default();
        let mut i = 0;
        let lvl = |v: Option<&String>, o: &str| -> Result<u8, crate::tcl::Flow> {
            let v = v.ok_or_else(|| crate::tcl::Flow::Err(format!("{}: {} needs low | medium | high (PLC-401)", cmd, o)))?;
            effort_of(v).ok_or_else(|| crate::tcl::Flow::Err(format!("{}: {} must be low, medium or high (PLC-401)", cmd, o)))
        };
        let mut pre: Option<Vec<String>> = None;
        while i < a.len() {
            match a[i].as_str() {
                "-timing_driven" => sv.timing = true,
                "-effort" | "-place_effort" if cmd != "place_opt" || a.get(i + 1).and_then(|v| effort_of(v)).is_some() => {
                    // place_opt -effort is the optimization effort too: keep it for the optimizer
                    sv.effort = lvl(a.get(i + 1), "-effort")?;
                    if cmd == "place_opt" { rest.push(a[i].clone()); rest.push(a[i + 1].clone()); }
                    i += 1;
                }
                "-congestion_effort" => { sv.cong = lvl(a.get(i + 1), "-congestion_effort")?; i += 1; }
                "-preroute_as_blockages" | "-preroute_as_obs" => {
                    match a.get(i + 1) {
                        Some(v) if !v.starts_with('-') => { pre = Some(split_list(v)); i += 1; }
                        _ => pre = Some(vec![]),
                    }
                }
                _ => rest.push(a[i].clone()),
            }
            i += 1;
        }
        let keys = ["place.coarse.iterations", "place.coarse.max_density", "place.detail.passes", "place.routing_blockage_density"];
        for k in keys { sv.app.push((k.to_string(), self.app.get(k).cloned())); }
        let mut msg = vec![];
        if sv.effort > 0 {
            let it = self.appu("place.coarse.iterations").max(1);
            let ps = self.appu("place.detail.passes").max(1);
            let (it, ps) = match sv.effort { 1 => ((it / 2).max(3), 1), 3 => (it * 2, ps * 2), _ => (it, ps) };
            self.app.insert("place.coarse.iterations".into(), it.to_string());
            self.app.insert("place.detail.passes".into(), ps.to_string());
            msg.push(format!("effort {} ({} global iterations, {} detail passes)", ["", "low", "medium", "high"][sv.effort as usize], it, ps));
        }
        if sv.cong > 0 {
            let md = self.appf("place.coarse.max_density").clamp(0.05, 1.0);
            let (md, rb) = match sv.cong { 1 => (md, self.appf("place.routing_blockage_density")), 2 => ((md - 0.05).max(0.3), self.appf("place.routing_blockage_density").max(30.0)), _ => ((md - 0.12).max(0.3), self.appf("place.routing_blockage_density").max(60.0)) };
            // high: also spread by global-route congestion when a global route exists
            self.app.insert("place.coarse.max_density".into(), format!("{:.3}", md));
            self.app.insert("place.routing_blockage_density".into(), format!("{:.1}", rb));
            msg.push(format!("congestion effort {} (max density {:.0}%, routing-blockage density {:.0}%)", ["", "low", "medium", "high"][sv.cong as usize], md * 100.0, rb));
        }
        if let Some(ls) = pre {
            let order = self.metal_order();
            let ls: Vec<String> = if ls.is_empty() { order.iter().take(3).cloned().collect() } else if ls.iter().any(|l| l == "all") { order.clone() } else { ls };
            let sp = self.appf("place.preroute_blockage_margin").max(0.0);
            if let Some(fp) = self.fp.as_mut() {
                let mut n = 0;
                let shapes: Vec<(String, (f64, f64, f64, f64))> = fp.special.iter().filter(|sh| crate::pg::is_pg_kind(&sh.kind) && !sh.kind.eq_ignore_ascii_case("followpin") && sh.via.is_none() && ls.iter().any(|l| l == &sh.layer)).filter_map(|sh| sh.rect.map(|r| (sh.name.clone(), r))).collect();
                for (nm, r) in shapes {
                    fp.pblk.push(crate::fplan::PBlockage { name: format!("preroute_{}", nm), rect: (r.0 - sp, r.1 - sp, r.2 + sp, r.3 + sp), kind: crate::fplan::PbKind::Hard, source: "preroute".into() });
                    n += 1;
                }
                sv.preroute = n;
                msg.push(format!("{} pre-routed PG stripe(s) on {} as placement blockages", n, ls.join(" ")));
            }
        }
        if sv.timing { msg.push("timing-driven".into()); }
        if !msg.is_empty() { crate::info!("PLC-400", "{}: {}", cmd, msg.join(", ")); }
        Ok((sv, rest))
    }

    /// timing-driven refinement, then restore the placement settings and drop temporary blockages
    pub(crate) fn place_options_end(&mut self, cmd: &str, sv: PlaceSave) -> Result<(), crate::tcl::Flow> {
        if sv.timing && self.fp.is_some() {
            let moved = self.timing_driven_refine()?;
            if moved > 0 {
                self.fp_legalize(None, true, true)?;
            }
            let q = self.with_env(|nl, env| { let a = env.analyze(nl, 0); (a.wns, a.tns) })?;
            crate::info!("PLC-410", "{}: timing-driven refinement moved {} cell(s) toward their critical nets; WNS {:.4} TNS {:.4}", cmd, moved, q.0, q.1);
        }
        for (k, v) in sv.app {
            match v { Some(v) => { self.app.insert(k, v); } None => { self.app.remove(&k); } }
        }
        if sv.preroute > 0 {
            if let Some(fp) = self.fp.as_mut() { fp.pblk.retain(|b| b.source != "preroute"); }
        }
        Ok(())
    }

    /// pull cells on negative-slack nets toward the pins of those nets (net weighting by slack)
    fn timing_driven_refine(&mut self) -> Result<usize, crate::tcl::Flow> {
        let sl = self.net_slacks();
        if sl.is_empty() { return Ok(0); }
        let worst = sl.values().copied().fold(0.0f64, f64::min);
        if worst >= 0.0 { return Ok(0); }
        let nl = self.nlm()?;
        let mut target: HashMap<CellId, (f64, f64, f64)> = HashMap::new();
        // only the critical nets (slack within the worst 30%) pull their cells
        for (n, s) in &sl {
            if *s >= 0.0 || *s > worst * 0.7 { continue; }
            let w = (s / worst).clamp(0.0, 1.0);
            let pts: Vec<(f64, f64)> = nl.net(*n).conns.iter().filter_map(|p| nl.pin_loc(*p)).collect();
            if pts.len() < 2 { continue; }
            let c = (pts.iter().map(|p| p.0).sum::<f64>() / pts.len() as f64, pts.iter().map(|p| p.1).sum::<f64>() / pts.len() as f64);
            for p in &nl.net(*n).conns {
                if let PinRef::Cell(cid, _) = p {
                    let e = target.entry(*cid).or_insert((0.0, 0.0, 0.0));
                    e.0 += c.0 * w; e.1 += c.1 * w; e.2 += w;
                }
            }
        }
        let mut moved = 0;
        for (c, (x, y, w)) in target {
            let cl = nl.cell(c);
            if cl.fixed || cl.lib().is_none() || w <= 0.0 { continue; }
            let Some(l) = cl.loc else { continue };
            let t = (x / w, y / w);
            let nl2 = (l.0 + (t.0 - l.0) * 0.4, l.1 + (t.1 - l.1) * 0.4);
            if (nl2.0 - l.0).abs() + (nl2.1 - l.1).abs() > 0.05 { nl.cell_mut(c).loc = Some(nl2); moved += 1; }
        }
        Ok(moved)
    }

    pub(crate) fn rtopt_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "check_antenna" | "verify_antenna" | "verifyProcessAntenna" | "report_antenna" => match self.antenna_violations() {
                Ok(v) => {
                    let names: Vec<String> = { let nl = self.nl.as_ref().unwrap(); let order = self.metal_order(); v.iter().take(40).map(|(n, p, l, r, lim)| format!("    {:<28} {:<30} {:<4} ratio {:>8.1} > {:.0}", nl.net(*n).name, nl.pin_name(*p), order.get(*l).cloned().unwrap_or_default(), r, lim)).collect() };
                    crate::out!("\n****************************************\nReport : check_antenna\n****************************************");
                    crate::out!("  Violations : {} on {} net(s)", v.len(), v.iter().map(|x| x.0).collect::<HashSet<_>>().len());
                    for s in names { crate::out!("{}", s); }
                    Ok(v.len().to_string())
                }
                Err(e) => Err(e),
            },
            "fix_antenna" | "fixAntenna" | "route_fix_antenna" => {
                let x = args(a, &["-diode", "-antenna_diode", "-cell"]);
                if let Some(c) = x.get("-diode").or(x.get("-antenna_diode")).or(x.get("-cell")) { self.rt.antenna_diode = Some(c.rsplit('/').next().unwrap_or(c).to_string()); }
                if x.has("-layer_jogs") || (x.get("-diode").is_none() && x.get("-antenna_diode").is_none() && x.get("-cell").is_none()) { self.rt.layer_jogs = true; }
                match self.antenna_fix(name) {
                    Ok((j, d)) => Ok(format!("{} {}", j, d)),
                    Err(e) => Err(e),
                }
            }
            "report_net_length" | "report_net_lengths" => {
                let x = args(a, &["-max", "-max_length", "-top", "-nets"]);
                let lim = x.num("-max").or(x.num("-max_length")).unwrap_or(0.0);
                let top = x.num("-top").map(|v| v as usize).unwrap_or(20);
                let v = self.net_lengths();
                let nl = match self.nl() { Ok(n) => n, Err(e) => return Some(Err(e)) };
                let pats: Vec<String> = x.get("-nets").map(|s| split_list(s)).unwrap_or_default();
                crate::out!("\n****************************************\nReport : net_length ({})\n****************************************", if self.routes.is_some() { "routed" } else { "HPWL" });
                let over = v.iter().filter(|(_, l)| lim > 0.0 && *l > lim).count();
                for (n, l) in v.iter().filter(|(n, _)| pats.is_empty() || pats.iter().any(|p| glob(p, &nl.net(*n).name))).take(top) {
                    crate::out!("  {:<40} {:>10.2}um{}", nl.net(*n).name, l, if lim > 0.0 && *l > lim { "  > max" } else { "" });
                }
                if lim > 0.0 { crate::out!("  nets longer than {:.1}um: {}", lim, over); }
                Ok(over.to_string())
            }
            "fix_net_length" | "buffer_long_nets" | "fixLongNets" => {
                let x = args(a, &["-max", "-max_length", "-max_net_length", "-buffer", "-cell", "-nets"]);
                let Some(l) = x.num("-max").or(x.num("-max_length")).or(x.num("-max_net_length")) else { return Some(err(format!("{}: -max <um> is required", name))) };
                if let Some(b) = x.get("-buffer").or(x.get("-cell")) { self.app.insert("route_opt.flow.net_length_buffer".into(), b.rsplit('/').next().unwrap_or(b).to_string()); }
                let only: Option<HashSet<String>> = x.get("-nets").map(|s| split_list(s).into_iter().collect());
                self.net_length_buffering(l, only.as_ref(), name).map(|n| n.to_string())
            }
            "add_tie_hi_lo" | "addTieHiLo" | "add_tie_cells" | "add_tie_high" | "add_tie_low" | "insert_tie_cells" => self.add_tie_hi_lo(a, name),
            "add_port_diodes" | "place_port_diodes" | "add_io_diodes" | "attach_port_diodes" | "attachDiode" => self.add_port_diodes(a, name),
            _ => return None,
        })
    }
}

/// placement settings changed by place_opt / place_detail options (restored afterwards)
#[derive(Clone, Debug, Default)]
pub struct PlaceSave {
    pub timing: bool,
    pub effort: u8,
    pub cong: u8,
    pub preroute: usize,
    pub app: Vec<(String, Option<String>)>,
}
