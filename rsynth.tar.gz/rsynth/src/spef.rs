//! SPEF reader (IEEE 1481): header units and delimiters, *NAME_MAP, *PORTS, *D_NET with *CONN,
//! *CAP (grounded and coupling), *RES. Each net becomes per-load Elmore delays plus its total wire
//! capacitance, in the same form as detailed-route extraction (`RoutedRc`), annotated per corner.
//! Coupling capacitors are grounded on both nodes (non-SI analysis). Where the resistor network
//! has loops, a spanning tree from the driver is used for the Elmore delays (the loops are counted).
use crate::droute::RoutedRc;
use crate::netlist::{NetId, Netlist, PinRef};
use std::collections::{HashMap, HashSet, VecDeque};

#[derive(Default, Debug, Clone)]
pub struct SpefStats {
    pub file: String,
    pub design: String,
    pub nets_in_file: usize,
    pub nets_annotated: usize,
    pub unmatched_nets: Vec<String>,
    pub missing_pins: Vec<String>,
    pub unknown_pins: Vec<String>,
    pub coupling_caps: usize,
    pub res_loops: usize,
    pub lumped_nets: usize,
    pub total_cap: f64,
}

fn unit(v: &str, u: &str, kind: char) -> f64 {
    let n: f64 = v.parse().unwrap_or(1.0);
    let u = u.to_uppercase();
    n * match (kind, u.as_str()) {
        ('C', "FF") => 1e-3,
        ('C', "PF") => 1.0,
        ('C', "NF") => 1e3,
        ('C', "UF") => 1e6,
        ('R', "OHM") => 1e-3,
        ('R', "KOHM") => 1.0,
        ('R', "MOHM") => 1e3,
        _ => 1.0,
    }
}

/// parse a SPEF file and annotate it against `nl`; `pin_cap` gives load pin capacitance (pF)
pub fn read_spef(path: &str, nl: &Netlist, pin_cap: &dyn Fn(PinRef) -> f64) -> Result<(RoutedRc, SpefStats), String> {
    read_spef_at(path, nl, pin_cap, None)
}

/// inner-side pin of a hierarchical boundary pin (the block-side end of a port net)
fn inner_port_pin(nl: &Netlist, inst: &str, port: &str) -> Option<PinRef> {
    let outer = nl.find_hier_pin(inst, port)?;
    let PinRef::Cell(c, p) = outer else { return None };
    let q = (0..nl.cell(c).pins.len()).find(|&k| k != p)?;
    Some(PinRef::Cell(c, q))
}

/// read a SPEF; with `prefix` the file is a block's SPEF whose names are local to the
/// hierarchical instance `prefix` (its ports are that instance's boundary pins)
pub fn read_spef_at(path: &str, nl: &Netlist, pin_cap: &dyn Fn(PinRef) -> f64, prefix: Option<&str>) -> Result<(RoutedRc, SpefStats), String> {
    let txt = std::fs::read_to_string(path).map_err(|e| format!("{}: {}", path, e))?;
    let mut st = SpefStats { file: path.to_string(), ..Default::default() };
    let (mut cu, mut ru) = (1.0, 1.0);
    let (mut delim, mut divider) = (':', '/');
    let mut names: HashMap<String, String> = HashMap::new();
    let mut rc = RoutedRc::default();
    // current net state
    struct Cur {
        net: Option<NetId>,
        name: String,
        conns: Vec<String>,
        caps: Vec<(String, Option<String>, f64)>,
        res: Vec<(String, String, f64)>,
    }
    let mut cur: Option<Cur> = None;
    let mut section = "";
    let unesc = |s: &str| s.replace('\\', "");
    let expand = |s: &str, names: &HashMap<String, String>| -> String {
        // *123 or *123:4 -> mapped name
        if let Some(r) = s.strip_prefix('*') {
            let (k, rest) = match r.find(|c: char| !c.is_ascii_digit()) {
                Some(i) => (&r[..i], &r[i..]),
                None => (r, ""),
            };
            if let Some(n) = names.get(k) {
                return format!("{}{}", n, rest);
            }
        }
        unesc(s)
    };
    let finish = |c: Cur, st: &mut SpefStats, rc: &mut RoutedRc, delim: char, divider: char| {
        let Some(net) = c.net else { return };
        // node -> pin
        let to_pin = |node: &str| -> Option<PinRef> {
            if let Some(i) = node.rfind(delim) {
                let (a, b) = (&node[..i], &node[i + 1..]);
                let pa;
                let a = match prefix {
                    Some(p) => {
                        pa = format!("{}/{}", p, a.replace(divider, "/"));
                        pa.as_str()
                    }
                    None => a,
                };
                if let Some(pr) = nl.find_pin(&format!("{}{}{}", a, '/', b)) {
                    return Some(pr);
                }
                if divider != '/' {
                    if let Some(pr) = nl.find_pin(&format!("{}/{}", a.replace(divider, "/"), b)) {
                        return Some(pr);
                    }
                }
            }
            match prefix {
                Some(p) => inner_port_pin(nl, p, node),
                None => nl.port_by_name(node).map(PinRef::Port),
            }
        };
        let mut idx: HashMap<String, usize> = HashMap::new();
        let mut node_cap: Vec<f64> = vec![];
        let id = |n: &str, idx: &mut HashMap<String, usize>, node_cap: &mut Vec<f64>| -> usize {
            *idx.entry(n.to_string()).or_insert_with(|| {
                node_cap.push(0.0);
                node_cap.len() - 1
            })
        };
        let mut wire = 0.0;
        let mut ccl: Vec<(usize, NetId, f64)> = vec![];
        for (a, b, v) in &c.caps {
            let ia = id(a, &mut idx, &mut node_cap);
            wire += v;
            match b {
                Some(bn) if !(bn.starts_with(&format!("{}{}", c.name, delim)) || to_pin(bn).map(|p| nl.pin_net(p) == Some(net)).unwrap_or(false)) => {
                    // coupling to another net: kept separately (Miller factor in the delay calculator)
                    let aggr = bn.rsplit_once(delim).and_then(|(pfx, _)| nl.net_by_name(pfx))
                        .or_else(|| to_pin(bn).and_then(|p| nl.pin_net(p))).unwrap_or(net);
                    ccl.push((ia, aggr, *v));
                }
                _ => node_cap[ia] += v,
            }
            if let Some(b) = b {
                // coupling to another net: grounded (non-SI)
                if b.starts_with(&format!("{}{}", c.name, delim)) || to_pin(b).map(|p| nl.pin_net(p) == Some(net)).unwrap_or(false) {
                    let ib = id(b, &mut idx, &mut node_cap);
                    node_cap[ib] += 0.0;
                }
                st.coupling_caps += 1;
            }
        }
        let mut adj: Vec<Vec<(usize, f64)>> = vec![];
        for (a, b, r) in &c.res {
            let ia = id(a, &mut idx, &mut node_cap);
            let ib = id(b, &mut idx, &mut node_cap);
            adj.resize(node_cap.len(), vec![]);
            adj[ia].push((ib, *r));
            adj[ib].push((ia, *r));
        }
        for cn in &c.conns {
            id(cn, &mut idx, &mut node_cap);
        }
        adj.resize(node_cap.len(), vec![]);
        // pins of the net present in the file
        let mut node_pin: HashMap<usize, PinRef> = HashMap::new();
        for (name, &i) in &idx {
            if let Some(pr) = to_pin(name) {
                if nl.pin_net(pr) == Some(net) || nl.pin_net(pr).map(|x| crate::session::Session::leaf_conns(nl, x).contains(&pr)).unwrap_or(false) {
                    node_pin.insert(i, pr);
                } else if !name.starts_with(&format!("{}{}", c.name, delim)) {
                    st.unknown_pins.push(format!("{} (net {})", name, c.name));
                }
            } else if !name.starts_with(&format!("{}{}", c.name, delim)) && c.conns.contains(name) {
                st.unknown_pins.push(format!("{} (net {})", name, c.name));
            }
        }
        // every netlist pin of the net should be in *CONN
        let present: HashSet<PinRef> = node_pin.values().copied().collect();
        for pr in &nl.net(net).conns {
            if nl.cell_is_hport(*pr) {
                continue;
            }
            if !present.contains(pr) {
                st.missing_pins.push(format!("{} (net {})", nl.pin_name(*pr), c.name));
            }
        }
        for (&i, pr) in &node_pin {
            if !nl.is_driver(*pr) {
                node_cap[i] += pin_cap(*pr);
            }
        }
        let drv = nl.driver(net).and_then(|d| node_pin.iter().find(|(_, p)| **p == d).map(|(i, _)| *i));
        if c.res.is_empty() {
            st.lumped_nets += 1;
        }
        if let Some(root) = drv {
            // spanning tree (BFS) from the driver; Elmore over it
            let n = node_cap.len();
            let mut par = vec![usize::MAX; n];
            let mut pr_r = vec![0.0; n];
            let mut order = vec![root];
            let mut seen = vec![false; n];
            seen[root] = true;
            let mut q = VecDeque::from([root]);
            let mut edges_used = 0;
            while let Some(u) = q.pop_front() {
                for &(v, r) in &adj[u] {
                    if !seen[v] {
                        seen[v] = true;
                        par[v] = u;
                        pr_r[v] = r;
                        order.push(v);
                        q.push_back(v);
                        edges_used += 1;
                    }
                }
            }
            if c.res.len() > edges_used {
                st.res_loops += c.res.len() - edges_used;
            }
            let mut down = node_cap.clone();
            for (i, _, v) in &ccl {
                down[*i] += v;
            }
            for &v in order.iter().rev() {
                if par[v] != usize::MAX {
                    let d = down[v];
                    down[par[v]] += d;
                }
            }
            let mut el = vec![0.0; n];
            let rev: HashMap<usize, String> = idx.iter().map(|(k, v)| (*v, k.clone())).collect();
            let mut segs = vec![];
            for &v in &order {
                if par[v] != usize::MAX {
                    el[v] = el[par[v]] + pr_r[v] * down[v];
                    let nm = |i: usize| -> String {
                        node_pin.get(&i).map(|p| nl.pin_name(*p)).unwrap_or_else(|| rev[&i].rsplit(delim).next().unwrap_or("0").to_string())
                    };
                    segs.push((nm(par[v]), nm(v), pr_r[v], node_cap[v] - node_pin.get(&v).filter(|p| !nl.is_driver(**p)).map(|p| pin_cap(*p)).unwrap_or(0.0)));
                }
            }
            for (&i, p) in &node_pin {
                if !nl.is_driver(*p) && seen[i] {
                    rc.elmore.insert(*p, el[i]);
                }
            }
            rc.segs.insert(net, segs);
            // RC tree in BFS order (parents before children)
            let mut newi = vec![usize::MAX; n];
            for (k, &v) in order.iter().enumerate() {
                newi[v] = k;
            }
            let mut t = crate::rcnet::RcTree { src: "spef", ..Default::default() };
            for &v in &order {
                let p = if par[v] == usize::MAX { crate::rcnet::ROOT } else { newi[par[v]] as u32 };
                t.add_node(p, pr_r[v], node_cap[v]);
                if let Some(pp) = node_pin.get(&v) {
                    if !nl.is_driver(*pp) {
                        *t.cpin.last_mut().unwrap() = pin_cap(*pp);
                    }
                }
            }
            for (&i, p) in &node_pin {
                if seen[i] {
                    t.pins.push((*p, newi[i] as u32));
                }
            }
            t.cc = ccl.iter().filter(|(i, _, _)| seen[*i]).map(|(i, a, v)| (newi[*i] as u32, *a, *v)).collect();
            rc.trees.insert(net, std::sync::Arc::new(t));
        }
        rc.wire_c.insert(net, wire);
        st.total_cap += wire;
        st.nets_annotated += 1;
    };
    for raw in txt.lines() {
        let line = raw.split("//").next().unwrap_or("").trim();
        if line.is_empty() {
            continue;
        }
        let t: Vec<&str> = line.split_whitespace().collect();
        let k = t[0];
        match k {
            "*DESIGN" => st.design = t.get(1).map(|s| s.trim_matches('"').to_string()).unwrap_or_default(),
            "*DELIMITER" => delim = t.get(1).and_then(|s| s.chars().next()).unwrap_or(':'),
            "*DIVIDER" => divider = t.get(1).and_then(|s| s.chars().next()).unwrap_or('/'),
            "*C_UNIT" => cu = unit(t.get(1).unwrap_or(&"1"), t.get(2).unwrap_or(&"PF"), 'C'),
            "*R_UNIT" => ru = unit(t.get(1).unwrap_or(&"1"), t.get(2).unwrap_or(&"KOHM"), 'R'),
            "*NAME_MAP" => section = "map",
            "*PORTS" | "*PHYSICAL_PORTS" => section = "ports",
            "*D_NET" => {
                if let Some(c) = cur.take() {
                    finish(c, &mut st, &mut rc, delim, divider);
                }
                st.nets_in_file += 1;
                let name = expand(t.get(1).unwrap_or(&""), &names);
                let net = match prefix {
                    Some(p) => nl.net_by_name(&format!("{}/{}", p, name.replace(divider, "/"))).or_else(|| inner_port_pin(nl, p, &name).and_then(|q| nl.pin_net(q))),
                    None => nl.net_by_name(&name).or_else(|| if divider != '/' { nl.net_by_name(&name.replace(divider, "/")) } else { None }),
                };
                if net.is_none() {
                    st.unmatched_nets.push(name.clone());
                }
                cur = Some(Cur { net, name, conns: vec![], caps: vec![], res: vec![] });
                section = "dnet";
            }
            "*CONN" => section = "conn",
            "*CAP" => section = "cap",
            "*RES" => section = "res",
            "*INDUC" => section = "induc",
            "*END" => {
                if let Some(c) = cur.take() {
                    finish(c, &mut st, &mut rc, delim, divider);
                }
                section = "";
            }
            _ if k.starts_with('*') && section == "map" && t.len() >= 2 && k[1..].chars().all(|c| c.is_ascii_digit()) => {
                names.insert(k[1..].to_string(), unesc(t[1]));
            }
            "*P" | "*I" if section == "conn" => {
                if let (Some(c), Some(n)) = (cur.as_mut(), t.get(1)) {
                    c.conns.push(expand(n, &names));
                }
            }
            _ if section == "cap" && t.len() >= 3 => {
                if let Some(c) = cur.as_mut() {
                    let v: f64 = t[t.len() - 1].parse().unwrap_or(0.0) * cu;
                    let a = expand(t[1], &names);
                    let b = if t.len() >= 4 { Some(expand(t[2], &names)) } else { None };
                    c.caps.push((a, b, v));
                }
            }
            _ if section == "res" && t.len() >= 4 => {
                if let Some(c) = cur.as_mut() {
                    let v: f64 = t[3].parse().unwrap_or(0.0) * ru;
                    c.res.push((expand(t[1], &names), expand(t[2], &names), v));
                }
            }
            _ => {}
        }
    }
    if let Some(c) = cur.take() {
        finish(c, &mut st, &mut rc, delim, divider);
    }
    Ok((rc, st))
}
