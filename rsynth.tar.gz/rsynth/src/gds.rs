//! GDSII stream export and merge:
//!   * a GDSII record reader / writer (structures kept as raw records, so merged layouts are
//!     copied bit-exact; coordinates are rescaled when a library uses another database unit)
//!   * export_gds / write_gds / streamOut : top cell with the die boundary, one SREF per placed
//!     instance (standard cells, memories, PLL / analog / GPIO macros), routed wires and vias,
//!     top-level pin shapes and labels, merged with the layouts of every library cell / IP
//!     listed in -merge or in a list file; layer mapping from a -gds_map_file
//!   * report_gds / check_gds : structure hierarchy, top cells, unresolved references, layers
//!   * write_cell_gds : placeholder (abstract) layouts for library cells or IPs, for flows that
//!     lack real cell GDS (boundary box plus pin labels; not a real layout)
use crate::netlist::{Dir, Kind, Netlist, PinRef};
use crate::session::*;
use crate::tcl::{split_list, Flow};
use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet};
type R = Result<String, Flow>;

fn err(m: impl Into<String>) -> R {
    Err(Flow::Err(m.into()))
}

// ------------------------------------------------------------------ records

pub const HEADER: u8 = 0x00;
pub const BGNLIB: u8 = 0x01;
pub const LIBNAME: u8 = 0x02;
pub const UNITS: u8 = 0x03;
pub const ENDLIB: u8 = 0x04;
pub const BGNSTR: u8 = 0x05;
pub const STRNAME: u8 = 0x06;
pub const ENDSTR: u8 = 0x07;
pub const BOUNDARY: u8 = 0x08;
pub const PATH: u8 = 0x09;
pub const SREF: u8 = 0x0A;
pub const AREF: u8 = 0x0B;
pub const TEXT: u8 = 0x0C;
pub const LAYER: u8 = 0x0D;
pub const DATATYPE: u8 = 0x0E;
pub const WIDTH: u8 = 0x0F;
pub const XY: u8 = 0x10;
pub const ENDEL: u8 = 0x11;
pub const SNAME: u8 = 0x12;
pub const TEXTTYPE: u8 = 0x16;
pub const PRESENTATION: u8 = 0x17;
pub const STRING: u8 = 0x19;
pub const STRANS: u8 = 0x1A;
pub const ANGLE: u8 = 0x1C;
pub const PATHTYPE: u8 = 0x21;
pub const BOXTYPE: u8 = 0x2E;

#[derive(Clone, Debug)]
pub struct Rec {
    pub rt: u8,
    pub dt: u8,
    pub data: Vec<u8>,
}

#[derive(Clone, Debug, Default)]
pub struct GStruct {
    pub name: String,
    /// BGNSTR timestamp data
    pub stamp: Vec<u8>,
    /// elements: each a list of records from BOUNDARY/PATH/... to ENDEL (inclusive)
    pub elems: Vec<Vec<Rec>>,
}

#[derive(Clone, Debug, Default)]
pub struct GLib {
    pub name: String,
    /// user units per database unit, meters per database unit
    pub uu: f64,
    pub dbm: f64,
    pub structs: Vec<GStruct>,
}

pub fn real8_enc(v: f64) -> [u8; 8] {
    if v == 0.0 {
        return [0; 8];
    }
    let neg = v < 0.0;
    let mut m = v.abs();
    let mut e: i32 = 64;
    while m >= 1.0 {
        m /= 16.0;
        e += 1;
    }
    while m < 0.0625 {
        m *= 16.0;
        e -= 1;
    }
    let mant = (m * (1u64 << 56) as f64).round() as u64;
    let mut b = [0u8; 8];
    b[0] = ((if neg { 0x80 } else { 0 }) | (e as u8 & 0x7f)) as u8;
    for i in 0..7 {
        b[7 - i] = ((mant >> (8 * i)) & 0xff) as u8;
    }
    b
}
pub fn real8_dec(b: &[u8]) -> f64 {
    if b.len() < 8 {
        return 0.0;
    }
    let neg = b[0] & 0x80 != 0;
    let e = (b[0] & 0x7f) as i32 - 64;
    let mut mant: u64 = 0;
    for &x in &b[1..8] {
        mant = (mant << 8) | x as u64;
    }
    let v = mant as f64 / (1u64 << 56) as f64 * 16f64.powi(e);
    if neg {
        -v
    } else {
        v
    }
}

fn rec(rt: u8, dt: u8, data: Vec<u8>) -> Rec {
    Rec { rt, dt, data }
}
fn r_i16(rt: u8, v: &[i16]) -> Rec {
    rec(rt, 0x02, v.iter().flat_map(|x| x.to_be_bytes()).collect())
}
fn r_i32(rt: u8, v: &[i32]) -> Rec {
    rec(rt, 0x03, v.iter().flat_map(|x| x.to_be_bytes()).collect())
}
fn r_str(rt: u8, s: &str) -> Rec {
    let mut d = s.as_bytes().to_vec();
    if d.len() % 2 == 1 {
        d.push(0);
    }
    rec(rt, 0x06, d)
}
fn r_nodata(rt: u8) -> Rec {
    rec(rt, 0x00, vec![])
}
fn rec_str(r: &Rec) -> String {
    String::from_utf8_lossy(&r.data).trim_end_matches('\0').to_string()
}
fn rec_i32s(r: &Rec) -> Vec<i32> {
    r.data.chunks(4).filter(|c| c.len() == 4).map(|c| i32::from_be_bytes([c[0], c[1], c[2], c[3]])).collect()
}
fn rec_i16s(r: &Rec) -> Vec<i16> {
    r.data.chunks(2).filter(|c| c.len() == 2).map(|c| i16::from_be_bytes([c[0], c[1]])).collect()
}

pub fn read_gds(path: &str) -> Result<GLib, String> {
    let b = std::fs::read(path).map_err(|e| format!("{}: {}", path, e))?;
    if b.len() < 4 || b[2] != HEADER {
        return Err(format!("{}: not a GDSII stream file", path));
    }
    let mut i = 0;
    let mut lib = GLib { uu: 1e-3, dbm: 1e-9, ..Default::default() };
    let mut cur: Option<GStruct> = None;
    let mut el: Option<Vec<Rec>> = None;
    while i + 4 <= b.len() {
        let len = u16::from_be_bytes([b[i], b[i + 1]]) as usize;
        if len < 4 {
            break; // padding
        }
        if i + len > b.len() {
            return Err(format!("{}: truncated record at byte {}", path, i));
        }
        let r = rec(b[i + 2], b[i + 3], b[i + 4..i + len].to_vec());
        i += len;
        match r.rt {
            LIBNAME => lib.name = rec_str(&r),
            UNITS => {
                lib.uu = real8_dec(&r.data[0..8.min(r.data.len())]);
                lib.dbm = real8_dec(&r.data[8.min(r.data.len())..]);
            }
            BGNSTR => cur = Some(GStruct { stamp: r.data.clone(), ..Default::default() }),
            STRNAME => {
                if let Some(s) = cur.as_mut() {
                    s.name = rec_str(&r);
                }
            }
            ENDSTR => {
                if let Some(s) = cur.take() {
                    lib.structs.push(s);
                }
            }
            ENDLIB => break,
            BOUNDARY | PATH | SREF | AREF | TEXT | 0x15 | 0x2D => el = Some(vec![r]),
            ENDEL => {
                if let (Some(mut e), Some(s)) = (el.take(), cur.as_mut()) {
                    e.push(r);
                    s.elems.push(e);
                }
            }
            _ => {
                if let Some(e) = el.as_mut() {
                    e.push(r);
                }
            }
        }
    }
    Ok(lib)
}

pub fn write_gds(path: &str, lib: &GLib) -> std::io::Result<usize> {
    let mut out: Vec<u8> = vec![];
    let mut put = |r: &Rec| {
        let len = (r.data.len() + 4) as u16;
        out.extend_from_slice(&len.to_be_bytes());
        out.push(r.rt);
        out.push(r.dt);
        out.extend_from_slice(&r.data);
    };
    let now = stamp();
    put(&r_i16(HEADER, &[600]));
    put(&r_i16(BGNLIB, &[now.clone(), now.clone()].concat()));
    put(&r_str(LIBNAME, &lib.name));
    let mut u = real8_enc(lib.uu).to_vec();
    u.extend_from_slice(&real8_enc(lib.dbm));
    put(&rec(UNITS, 0x05, u));
    for s in &lib.structs {
        put(&rec(BGNSTR, 0x02, if s.stamp.len() == 24 { s.stamp.clone() } else { [now.clone(), now.clone()].concat().iter().flat_map(|x| x.to_be_bytes()).collect() }));
        put(&r_str(STRNAME, &s.name));
        for e in &s.elems {
            for r in e {
                put(r);
            }
        }
        put(&r_nodata(ENDSTR));
    }
    put(&r_nodata(ENDLIB));
    let n = out.len();
    std::fs::write(path, out)?;
    Ok(n)
}

/// a flat one-cell GDS from rectangles, paths (any angle) and labels, in microns
pub fn write_shapes(path: &str, top: &str, dbu: f64, die: (f64, f64, f64, f64), rects: &[(i16, i16, (f64, f64, f64, f64))], paths: &[(i16, i16, f64, Vec<(f64, f64)>)], texts: &[(i16, i16, (f64, f64), String)]) -> std::io::Result<usize> {
    let u = |v: f64| (v * dbu).round() as i32;
    let mut st = GStruct { name: top.to_string(), ..Default::default() };
    st.elems.push(el_boundary(100, 0, (u(die.0), u(die.1), u(die.2), u(die.3))));
    for (l, d, r) in rects {
        st.elems.push(el_boundary(*l, *d, (u(r.0), u(r.1), u(r.2), u(r.3))));
    }
    for (l, d, w, p) in paths {
        let pts: Vec<(i32, i32)> = p.iter().map(|q| (u(q.0), u(q.1))).collect();
        st.elems.push(el_path(*l, *d, u(*w), &pts));
    }
    for (l, d, at, t) in texts {
        st.elems.push(el_text(*l, *d, (u(at.0), u(at.1)), t));
    }
    write_gds(path, &GLib { name: top.to_string(), uu: 1.0 / dbu, dbm: 1e-6 / dbu, structs: vec![st] })
}

fn stamp() -> Vec<i16> {
    // year month day hour minute second, from the system clock (UTC)
    let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs() as i64).unwrap_or(0);
    let days = t.div_euclid(86400);
    let secs = t.rem_euclid(86400);
    // civil from days (Howard Hinnant)
    let z = days + 719468;
    let era = z.div_euclid(146097);
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    let y = if m <= 2 { y + 1 } else { y };
    vec![y as i16, m as i16, d as i16, (secs / 3600) as i16, ((secs / 60) % 60) as i16, (secs % 60) as i16]
}

/// element helpers
fn el_boundary(layer: i16, dt: i16, r: (i32, i32, i32, i32)) -> Vec<Rec> {
    let (x0, y0, x1, y1) = r;
    vec![r_nodata(BOUNDARY), r_i16(LAYER, &[layer]), r_i16(DATATYPE, &[dt]), r_i32(XY, &[x0, y0, x1, y0, x1, y1, x0, y1, x0, y0]), r_nodata(ENDEL)]
}
fn el_path(layer: i16, dt: i16, w: i32, pts: &[(i32, i32)]) -> Vec<Rec> {
    let xy: Vec<i32> = pts.iter().flat_map(|p| [p.0, p.1]).collect();
    vec![r_nodata(PATH), r_i16(LAYER, &[layer]), r_i16(DATATYPE, &[dt]), r_i16(PATHTYPE, &[2]), r_i32(WIDTH, &[w]), r_i32(XY, &xy), r_nodata(ENDEL)]
}
fn el_text(layer: i16, tt: i16, at: (i32, i32), s: &str) -> Vec<Rec> {
    vec![r_nodata(TEXT), r_i16(LAYER, &[layer]), r_i16(TEXTTYPE, &[tt]), r_i16(PRESENTATION, &[0x0005]), r_i32(XY, &[at.0, at.1]), r_str(STRING, s), r_nodata(ENDEL)]
}
/// DEF orientation -> (reflection about the x axis before rotation, counter-clockwise angle)
pub fn orient_tf(orient: &str) -> (bool, i32) {
    match orient {
        "S" => (false, 180),
        "E" => (false, 270),
        "W" => (false, 90),
        "FN" => (true, 180),
        "FS" => (true, 0),
        "FE" => (true, 90),
        "FW" => (true, 270),
        _ => (false, 0),
    }
}
fn el_sref(name: &str, at: (i32, i32), orient: &str) -> Vec<Rec> {
    let mut v = vec![r_nodata(SREF), r_str(SNAME, name)];
    let (refl, ang) = orient_tf(orient);
    let ang = ang as f64;
    if refl || ang != 0.0 {
        v.push(rec(STRANS, 0x01, vec![if refl { 0x80 } else { 0 }, 0]));
        if ang != 0.0 {
            v.push(rec(ANGLE, 0x05, real8_enc(ang).to_vec()));
        }
    }
    v.push(r_i32(XY, &[at.0, at.1]));
    v.push(r_nodata(ENDEL));
    v
}

/// rescale an element's coordinates (XY, WIDTH) by an integer-ish ratio
fn scale_elem(e: &mut [Rec], k: f64) -> usize {
    let mut inexact = 0;
    for r in e.iter_mut() {
        if r.rt == XY || r.rt == WIDTH {
            let v: Vec<i32> = rec_i32s(r)
                .into_iter()
                .map(|x| {
                    let f = x as f64 * k;
                    if (f - f.round()).abs() > 1e-6 {
                        inexact += 1;
                    }
                    f.round() as i32
                })
                .collect();
            r.data = v.iter().flat_map(|x| x.to_be_bytes()).collect();
        }
    }
    inexact
}
fn elem_sname(e: &[Rec]) -> Option<String> {
    e.iter().find(|r| r.rt == SNAME).map(rec_str)
}
fn elem_layer(e: &[Rec]) -> Option<(i16, i16)> {
    let l = e.iter().find(|r| r.rt == LAYER).and_then(|r| rec_i16s(r).first().copied())?;
    let d = e.iter().find(|r| r.rt == DATATYPE || r.rt == TEXTTYPE || r.rt == BOXTYPE).and_then(|r| rec_i16s(r).first().copied()).unwrap_or(0);
    Some((l, d))
}

// ------------------------------------------------------------------ layer map

#[derive(Clone, Debug, Default)]
pub struct LayerMap {
    /// (layer name upper, purpose upper) -> (gds layer, datatype)
    pub m: HashMap<(String, String), (i16, i16)>,
}
impl LayerMap {
    /// Innovus-style map lines: <layer> <purpose[,purpose]> <gds layer> <datatype>
    pub fn parse(txt: &str) -> Result<LayerMap, String> {
        let mut m = HashMap::new();
        for (ln, l) in txt.lines().enumerate() {
            let l = l.split('#').next().unwrap_or("").trim();
            if l.is_empty() || l.starts_with("//") {
                continue;
            }
            let t: Vec<&str> = l.split_whitespace().collect();
            if t.len() < 4 {
                return Err(format!("line {}: expected <layer> <purpose> <gds layer> <datatype>", ln + 1));
            }
            let gl: i16 = t[2].parse().map_err(|_| format!("line {}: bad GDS layer '{}'", ln + 1, t[2]))?;
            let gd: i16 = t[3].parse().map_err(|_| format!("line {}: bad datatype '{}'", ln + 1, t[3]))?;
            for p in t[1].split(',') {
                m.insert((t[0].to_uppercase(), p.to_uppercase()), (gl, gd));
            }
        }
        Ok(LayerMap { m })
    }
    pub fn default_for(layers: &[String]) -> LayerMap {
        let mut m = HashMap::new();
        for (i, l) in layers.iter().enumerate() {
            let n = 31 + i as i16;
            let u = l.to_uppercase();
            m.insert((u.clone(), "NET".into()), (n, 0));
            m.insert((u.clone(), "SPNET".into()), (n, 0));
            m.insert((u.clone(), "PIN".into()), (n, 2));
            m.insert((u.clone(), "LABEL".into()), (n, 251));
            m.insert((u.clone(), "BLOCKAGE".into()), (n, 4));
            if i + 1 < layers.len() {
                m.insert((format!("VIA{}", i + 1), "VIA".into()), (51 + i as i16, 0));
                // LEF cut-layer names of the form VIA<lower><upper> (VIA12, VIA56)
                m.insert((format!("VIA{}{}", i + 1, i + 2), "VIA".into()), (51 + i as i16, 0));
            }
        }
        // redistribution / bump layer
        for (p, d) in [("NET", 0i16), ("SPNET", 0), ("PIN", 2), ("LABEL", 251)] {
            m.entry(("AP".into(), p.into())).or_insert((74, d));
        }
        m.insert(("DIEAREA".into(), "ALL".into()), (100, 0));
        m.insert(("PRBOUNDARY".into(), "ALL".into()), (235, 0));
        LayerMap { m }
    }
    pub fn get(&self, layer: &str, purpose: &str) -> Option<(i16, i16)> {
        let l = layer.to_uppercase();
        let p = purpose.to_uppercase();
        self.m.get(&(l.clone(), p.clone())).or_else(|| if p == "LABEL" { self.m.get(&(l.clone(), "TEXT".into())) } else { None }).or_else(|| if p == "SPNET" { self.m.get(&(l.clone(), "NET".into())) } else { None }).or_else(|| self.m.get(&(l, "ALL".into()))).copied()
    }
    pub fn text(&self) -> String {
        let mut v: Vec<_> = self.m.iter().collect();
        v.sort_by(|a, b| (a.1, &a.0).cmp(&(b.1, &b.0)));
        v.iter().map(|((l, p), (g, d))| format!("{:<12} {:<9} {:>4} {:>4}\n", l, p, g, d)).collect()
    }
}

// ------------------------------------------------------------------ hierarchy report

pub struct GdsInfo {
    pub tops: Vec<String>,
    pub unresolved: BTreeSet<String>,
    pub layers: BTreeMap<(i16, i16), usize>,
    pub counts: [usize; 4],
}
pub fn gds_info(lib: &GLib) -> GdsInfo {
    let names: HashSet<&str> = lib.structs.iter().map(|s| s.name.as_str()).collect();
    let mut referenced: HashSet<String> = HashSet::new();
    let mut unresolved = BTreeSet::new();
    let mut layers = BTreeMap::new();
    let mut counts = [0usize; 4]; // boundary/path, sref/aref, text, other
    for s in &lib.structs {
        for e in &s.elems {
            match e[0].rt {
                BOUNDARY | PATH | 0x2D => counts[0] += 1,
                SREF | AREF => counts[1] += 1,
                TEXT => counts[2] += 1,
                _ => counts[3] += 1,
            }
            if let Some(n) = elem_sname(e) {
                if !names.contains(n.as_str()) {
                    unresolved.insert(n.clone());
                }
                referenced.insert(n);
            }
            if let Some(l) = elem_layer(e) {
                *layers.entry(l).or_insert(0) += 1;
            }
        }
    }
    let tops = lib.structs.iter().filter(|s| !referenced.contains(&s.name)).map(|s| s.name.clone()).collect();
    GdsInfo { tops, unresolved, layers, counts }
}

// ------------------------------------------------------------------ session commands

impl Session {
    pub(crate) fn gds_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "export_gds" | "write_gds" | "streamOut" | "write_stream" => self.c_export_gds(a),
            "report_gds" | "check_gds" => self.c_report_gds(a),
            "write_cell_gds" => self.c_write_cell_gds(a),
            _ => return None,
        })
    }

    fn cell_box(&self, c: usize) -> (f64, f64) {
        let nl = self.nl.as_ref().unwrap();
        let cl = nl.cell(c);
        let rh = self.fp.as_ref().map(|f| f.row_h).filter(|h| *h > 0.0).unwrap_or(1.6);
        let area = cl.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|lc| lc.area).unwrap_or(0.0);
        if matches!(cl.kind, Kind::BlackBox(_)) || area > 40.0 * rh * rh {
            let s = area.max(1.0).sqrt();
            return (s, s);
        }
        let site = 0.2;
        (((area / rh / site).ceil().max(1.0)) * site, rh)
    }

    fn c_write_cell_gds(&mut self, a: &[String]) -> R {
        let x = args(a, &["-cells", "-output", "-size", "-layer_map", "-gds_map_file", "-units", "-pin_layer", "-pins", "-library_name"]);
        let f = x.get("-output").cloned().or(x.pos.first().cloned()).ok_or_else(|| Flow::Err("write_cell_gds: -output required (GDS-301)".into()))?;
        let dbu = x.num("-units").unwrap_or(1000.0);
        let pats: Vec<String> = x.get("-cells").map(|s| split_list(s)).unwrap_or(vec!["*".into()]);
        let size: Option<(f64, f64)> = x.get("-size").map(|s| {
            let v: Vec<f64> = split_list(s).iter().filter_map(|t| t.parse().ok()).collect();
            (v.first().copied().unwrap_or(10.0), v.get(1).copied().unwrap_or(v.first().copied().unwrap_or(10.0)))
        });
        let map = match x.get("-gds_map_file").or(x.get("-layer_map")) {
            Some(m) => LayerMap::parse(&std::fs::read_to_string(m).map_err(|e| Flow::Err(format!("{}: {}", m, e)))?).map_err(|e| Flow::Err(format!("write_cell_gds: {}: {} (GDS-302)", m, e)))?,
            None => LayerMap::default_for(&self.route_layers().iter().map(|l| l.name.clone()).collect::<Vec<_>>()),
        };
        let pin_layer = x.get("-pin_layer").cloned().unwrap_or("M1".into());
        let (pl, pd) = map.get(&pin_layer, "PIN").unwrap_or((31, 2));
        let (tl, td) = map.get(&pin_layer, "LABEL").unwrap_or((31, 251));
        let (bl, bd) = map.get("PRBOUNDARY", "ALL").unwrap_or((235, 0));
        let (ml, md) = map.get(&pin_layer, "NET").unwrap_or((31, 0));
        // candidate cells: library cells and black-box modules used by the design, or named ones
        let mut cells: BTreeMap<String, ((f64, f64), Vec<(String, bool)>)> = BTreeMap::new();
        if let Some(nl) = self.nl.as_ref() {
            for c in nl.cell_ids() {
                let cl = nl.cell(c);
                let ref_name = match &cl.kind {
                    Kind::Lib(l) => l.clone(),
                    Kind::BlackBox(m) => m.clone(),
                    _ => continue,
                };
                if cl.is_hport() || !pats.iter().any(|p| crate::netlist::glob(p, &ref_name)) {
                    continue;
                }
                let sz = size.unwrap_or_else(|| self.cell_box(c));
                let pins = cl.pins.iter().map(|p| (p.name.clone(), p.dir == Dir::Out)).collect();
                cells.entry(ref_name).or_insert((sz, pins));
            }
        }
        for l in &self.libs {
            for (n, lc) in &l.cells {
                if cells.contains_key(n) || !pats.iter().any(|p| p != "*" && crate::netlist::glob(p, n)) {
                    continue;
                }
                let rh = self.fp.as_ref().map(|f| f.row_h).filter(|h| *h > 0.0).unwrap_or(1.6);
                let sz = size.unwrap_or(((lc.area / rh / 0.2).ceil().max(1.0) * 0.2, rh));
                cells.insert(n.clone(), (sz, lc.pins.iter().map(|p| (p.name.clone(), p.dir == Some(Dir::Out))).collect()));
            }
        }
        // explicitly named IPs that are neither in the design nor in a library (e.g. a PLL or
        // an analog block that is only merged at GDS level): need -size, pins from -pins
        let extra_pins: Vec<String> = x.get("-pins").map(|s| split_list(s)).unwrap_or_default();
        for p in &pats {
            if !p.contains('*') && !p.contains('?') && !cells.contains_key(p) {
                match size {
                    Some(sz) => {
                        cells.insert(p.clone(), (sz, extra_pins.iter().map(|n| (n.clone(), false)).collect()));
                    }
                    None => crate::warn!("GDS-304", "write_cell_gds: '{}' is not a library cell or design module; give -size to create it", p),
                }
            }
        }
        if cells.is_empty() {
            return err(format!("write_cell_gds: no cells match {:?} (GDS-303)", pats));
        }
        let u = |v: f64| (v * dbu).round() as i32;
        let mut lib = GLib { name: x.get("-library_name").cloned().unwrap_or("rsynth_cells".into()), uu: 1.0 / dbu, dbm: 1e-6 / dbu, structs: vec![] };
        for (n, ((w, h), pins)) in &cells {
            let mut s = GStruct { name: n.clone(), ..Default::default() };
            s.elems.push(el_boundary(bl, bd, (0, 0, u(*w), u(*h))));
            let np = pins.len().max(1) as f64;
            for (i, (p, _)) in pins.iter().enumerate() {
                let cx = w * (i as f64 + 1.0) / (np + 1.0);
                let cy = h * 0.5;
                let r = (u(cx - 0.05), u(cy - 0.2), u(cx + 0.05), u(cy + 0.2));
                s.elems.push(el_boundary(ml, md, r));
                s.elems.push(el_boundary(pl, pd, r));
                s.elems.push(el_text(tl, td, (u(cx), u(cy)), p));
            }
            lib.structs.push(s);
        }
        let bytes = write_gds(&f, &lib).map_err(|e| Flow::Err(format!("write_cell_gds: {}: {}", f, e)))?;
        crate::info!("GDS-300", "Wrote placeholder (abstract) layouts of {} cell(s) to '{}' ({} bytes): boundary + pin shapes/labels only, not a real layout", cells.len(), f, bytes);
        Ok(f)
    }

    fn c_report_gds(&mut self, a: &[String]) -> R {
        let x = args(a, &["-max_structures"]);
        let Some(f) = x.pos.first() else { return err("report_gds: file name required (GDS-201)") };
        let lib = read_gds(f).map_err(|e| Flow::Err(format!("report_gds: {} (GDS-202)", e)))?;
        let gi = gds_info(&lib);
        crate::out!("\n  GDS file      : {}", f);
        crate::out!("  library       : {}  (user unit {} um/dbu -> {} dbu/um)", lib.name, lib.uu, (1.0 / lib.uu).round());
        crate::out!("  structures    : {}", lib.structs.len());
        crate::out!("  top cell(s)   : {}{}", gi.tops.len(), if gi.tops.len() <= 8 { format!("  ({})", gi.tops.join(" ")) } else { format!("  ({} ... ; unreferenced library structures count as top cells)", gi.tops.iter().rev().take(4).cloned().collect::<Vec<_>>().join(" ")) });
        crate::out!("  shapes        : {}  references: {}  texts: {}", gi.counts[0], gi.counts[1], gi.counts[2]);
        crate::out!("  unresolved    : {}{}", gi.unresolved.len(), if gi.unresolved.is_empty() { String::new() } else { format!("  ({})", gi.unresolved.iter().take(12).cloned().collect::<Vec<_>>().join(" ")) });
        crate::out!("  layers (layer/datatype: elements):");
        let mut line = String::from("   ");
        for ((l, d), n) in &gi.layers {
            line.push_str(&format!(" {}/{}:{}", l, d, n));
        }
        crate::out!("{}", line);
        if x.has("-verbose") {
            let mx = x.num("-max_structures").unwrap_or(40.0) as usize;
            for s in lib.structs.iter().take(mx) {
                let refs = s.elems.iter().filter(|e| elem_sname(e).is_some()).count();
                crate::out!("    {:<32} elements {:>6}  references {:>6}", s.name, s.elems.len(), refs);
            }
        }
        if !gi.unresolved.is_empty() {
            crate::warn!("GDS-210", "{}: {} unresolved structure reference(s)", f, gi.unresolved.len());
        }
        Ok(format!("{} {} {}", lib.structs.len(), gi.tops.len(), gi.unresolved.len()))
    }

    fn c_export_gds(&mut self, a: &[String]) -> R {
        let x = args(a, &["-output", "-merge", "-merge_list", "-gds_map_file", "-map_file", "-mapFile", "-top_cell_name", "-structureName", "-units", "-mode", "-library_name", "-libName", "-uniquify_prefix", "-write_map_file", "-die_area_layer"]);
        let nl = self.nl()?.clone();
        let fp = self.fp.clone();
        // output: -output, else the first positional that is not an input list
        let out = x.get("-output").cloned().or(x.pos.first().cloned()).ok_or_else(|| Flow::Err("export_gds: -output required (GDS-001)".into()))?;
        let top = x.get("-top_cell_name").or(x.get("-structureName")).cloned().unwrap_or(nl.name.clone());
        let dbu = x.num("-units").or(fp.as_ref().map(|f| f.dbu).filter(|d| *d > 0.0)).unwrap_or(1000.0);
        let mode = x.get("-mode").map(|s| s.to_uppercase()).unwrap_or("ALL".into());
        if !["ALL", "NOINSTANCES", "NOROUTING", "FILLONLY"].contains(&mode.as_str()) {
            return err("export_gds: -mode must be ALL, NOINSTANCES, NOROUTING or FILLONLY (GDS-002)");
        }
        // merge inputs: -merge {files | list file}, -merge_list file, positional list files
        let mut inputs: Vec<String> = vec![];
        let add_spec = |spec: &str, inputs: &mut Vec<String>| -> Result<(), Flow> {
            for item in split_list(spec) {
                let is_gds = std::fs::read(&item).map(|b| b.len() >= 4 && b[2] == HEADER && b[3] == 0x02).unwrap_or(false);
                if is_gds {
                    inputs.push(item);
                } else if std::path::Path::new(&item).is_file() {
                    // list file: one GDS path per line (# comments); relative to the list's directory
                    let dir = std::path::Path::new(&item).parent().map(|p| p.to_path_buf()).unwrap_or_default();
                    let txt = std::fs::read_to_string(&item).map_err(|e| Flow::Err(format!("export_gds: {}: {}", item, e)))?;
                    for l in txt.lines() {
                        let l = l.split('#').next().unwrap_or("").trim();
                        if l.is_empty() {
                            continue;
                        }
                        for w in l.split_whitespace() {
                            let p = if std::path::Path::new(w).is_absolute() || std::path::Path::new(w).exists() { w.to_string() } else { dir.join(w).to_string_lossy().to_string() };
                            inputs.push(p);
                        }
                    }
                } else {
                    return Err(Flow::Err(format!("export_gds: merge input '{}' not found (GDS-003)", item)));
                }
            }
            Ok(())
        };
        if let Some(m) = x.get("-merge") {
            add_spec(m, &mut inputs)?;
        }
        if let Some(m) = x.get("-merge_list") {
            add_spec(m, &mut inputs)?;
        }
        for p in x.pos.iter().skip(if x.get("-output").is_some() { 0 } else { 1 }) {
            add_spec(p, &mut inputs)?;
        }
        if x.has("-m") && inputs.is_empty() {
            return err("export_gds: -m (merge) given but no GDS files to merge (-merge or a list file) (GDS-004)");
        }
        // layer map
        let layer_names: Vec<String> = self.route_layers().iter().map(|l| l.name.clone()).collect();
        let map = match x.get("-gds_map_file").or(x.get("-map_file")).or(x.get("-mapFile")) {
            Some(m) => {
                let txt = std::fs::read_to_string(m).map_err(|e| Flow::Err(format!("export_gds: {}: {} (GDS-005)", m, e)))?;
                LayerMap::parse(&txt).map_err(|e| Flow::Err(format!("export_gds: {}: {} (GDS-006)", m, e)))?
            }
            None => {
                crate::info!("GDS-010", "No -gds_map_file: using the default layer map (metal i -> {}+i, VIAi -> {}+i)", 31, 51);
                LayerMap::default_for(&layer_names)
            }
        };
        if let Some(w) = x.get("-write_map_file") {
            std::fs::write(w, map.text()).map_err(|e| Flow::Err(e.to_string()))?;
        }
        let mut unmapped: BTreeSet<String> = BTreeSet::new();
        let mut lget = |l: &str, p: &str| -> Option<(i16, i16)> {
            let r = map.get(l, p);
            if r.is_none() {
                unmapped.insert(format!("{} {}", l, p));
            }
            r
        };
        let u = |v: f64| (v * dbu).round() as i32;
        let mut lib = GLib { name: x.get("-library_name").or(x.get("-libName")).cloned().unwrap_or("DesignLib".into()), uu: 1.0 / dbu, dbm: 1e-6 / dbu, structs: vec![] };
        // ---- merge the input layouts
        let mut have: HashMap<String, String> = HashMap::new(); // structure -> source file
        let mut dups: Vec<String> = vec![];
        let mut per_file: Vec<(String, usize, usize)> = vec![];
        let uniq = x.get("-uniquify_prefix").cloned().or(if x.has("-uniquify_cell_names") { Some(String::new()) } else { None });
        for f in &inputs {
            let g = read_gds(f).map_err(|e| Flow::Err(format!("export_gds: {} (GDS-007)", e)))?;
            let k = g.uu / lib.uu;
            let rescale = (k - 1.0).abs() > 1e-9;
            let mut inexact = 0usize;
            let stem = std::path::Path::new(f).file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
            let mut ren: HashMap<String, String> = HashMap::new();
            let (mut added, mut skipped) = (0, 0);
            for s in &g.structs {
                if s.name == top {
                    crate::warn!("GDS-103", "{}: structure '{}' has the top cell name; skipped", f, s.name);
                    skipped += 1;
                    continue;
                }
                if let Some(prev) = have.get(&s.name) {
                    match &uniq {
                        Some(pfx) => {
                            let nn = format!("{}{}_{}", pfx, stem, s.name);
                            ren.insert(s.name.clone(), nn);
                        }
                        None => {
                            dups.push(format!("{} ({} kept, {} ignored)", s.name, prev, f));
                            skipped += 1;
                        }
                    }
                }
            }
            for s in &g.structs {
                if s.name == top || (have.contains_key(&s.name) && !ren.contains_key(&s.name)) {
                    continue;
                }
                let mut s2 = s.clone();
                if let Some(n) = ren.get(&s.name) {
                    s2.name = n.clone();
                }
                for e in s2.elems.iter_mut() {
                    if rescale {
                        inexact += scale_elem(e, k);
                    }
                    for r in e.iter_mut() {
                        if r.rt == SNAME {
                            if let Some(n) = ren.get(&rec_str(r)) {
                                *r = r_str(SNAME, n);
                            }
                        }
                    }
                }
                have.insert(s2.name.clone(), f.clone());
                lib.structs.push(s2);
                added += 1;
            }
            if rescale {
                crate::info!("GDS-105", "{}: database unit {} um rescaled to {} um (x{})", f, g.uu, lib.uu, k);
                if inexact > 0 {
                    crate::warn!("GDS-102", "{}: {} coordinate(s) are off the {} um grid after rescaling and were rounded", f, inexact, lib.uu);
                }
            }
            per_file.push((f.clone(), added, skipped));
        }
        // ---- top cell
        let mut topc = GStruct { name: top.clone(), ..Default::default() };
        let die = fp.as_ref().map(|f| f.die);
        if let Some((x0, y0, x1, y1)) = die {
            if !x.has("-no_die_area") {
                if let Some((l, d)) = lget(&x.get("-die_area_layer").cloned().unwrap_or("DIEAREA".into()), "ALL") {
                    topc.elems.push(el_boundary(l, d, (u(x0), u(y0), u(x1), u(y1))));
                }
            }
        }
        // instances
        let mut refs: BTreeMap<String, usize> = BTreeMap::new();
        let (mut n_inst, mut n_unplaced) = (0usize, 0usize);
        // bounding boxes of the merged structures (their own shapes), in dbu
        // (the die / placement-boundary outline when the structure has one, else all its shapes)
        let outline: Vec<(i16, i16)> = [map.get("DIEAREA", "ALL"), map.get("PRBOUNDARY", "ALL")].into_iter().flatten().collect();
        let sbox: HashMap<String, (i64, i64, i64, i64)> = lib
            .structs
            .iter()
            .filter_map(|st| {
                let has_outline = st.elems.iter().any(|e| e[0].rt == BOUNDARY && elem_layer(e).map(|l| outline.contains(&l)).unwrap_or(false));
                let mut b: Option<(i64, i64, i64, i64)> = None;
                for e in &st.elems {
                    if !matches!(e[0].rt, BOUNDARY | PATH | 0x2D) {
                        continue;
                    }
                    if has_outline && !(e[0].rt == BOUNDARY && elem_layer(e).map(|l| outline.contains(&l)).unwrap_or(false)) {
                        continue;
                    }
                    for r in e.iter().filter(|r| r.rt == XY) {
                        for xy in rec_i32s(r).chunks(2) {
                            if xy.len() == 2 {
                                let (x, y) = (xy[0] as i64, xy[1] as i64);
                                b = Some(match b {
                                    None => (x, y, x, y),
                                    Some(q) => (q.0.min(x), q.1.min(y), q.2.max(x), q.3.max(y)),
                                });
                            }
                        }
                    }
                }
                b.map(|b| (st.name.clone(), b))
            })
            .collect();
        let row_h = fp.as_ref().map(|f| f.row_h).filter(|h| *h > 0.0).unwrap_or(1.6);
        if mode != "NOINSTANCES" && mode != "FILLONLY" {
            for c in nl.cell_ids() {
                let cl = nl.cell(c);
                if cl.is_hport() {
                    continue;
                }
                let ref_name = match &cl.kind {
                    Kind::Lib(l) => l.clone(),
                    Kind::BlackBox(m) => m.clone(),
                    _ => continue,
                };
                let Some((px, py)) = cl.loc else {
                    n_unplaced += 1;
                    continue;
                };
                let orient = cl.attrs.iter().find_map(|a| a.strip_prefix("orient:")).unwrap_or("N").to_string();
                // the structure's box: from its merged layout, else the placement model
                let bx = sbox.get(&ref_name).copied().unwrap_or_else(|| {
                    let (w, h) = self.cell_box(c);
                    (0, 0, (w * dbu).round() as i64, (h * dbu).round() as i64)
                });
                // standard cells are placed by their centre, blocks and macros by their corner
                let hgt = (bx.3 - bx.1) as f64 / dbu;
                let centred = matches!(cl.kind, Kind::Lib(_)) && hgt <= 2.0 * row_h + 1e-6 && !cl.attrs.iter().any(|a| a == "partition" || a == "mim");
                let ll = if centred { (u(px) as i64 - (bx.2 - bx.0) / 2, u(py) as i64 - (bx.3 - bx.1) / 2) } else { (u(px) as i64, u(py) as i64) };
                // DEF orientation: the placed bounding box keeps its lower-left corner
                let (refl, ang) = orient_tf(&orient);
                let tf = |x: i64, y: i64| -> (i64, i64) {
                    let y = if refl { -y } else { y };
                    match ang {
                        90 => (-y, x),
                        180 => (-x, -y),
                        270 => (y, -x),
                        _ => (x, y),
                    }
                };
                let cs = [tf(bx.0, bx.1), tf(bx.2, bx.1), tf(bx.2, bx.3), tf(bx.0, bx.3)];
                let (mx, my) = (cs.iter().map(|c| c.0).min().unwrap(), cs.iter().map(|c| c.1).min().unwrap());
                topc.elems.push(el_sref(&ref_name, ((ll.0 - mx) as i32, (ll.1 - my) as i32), &orient));
                *refs.entry(ref_name).or_insert(0) += 1;
                n_inst += 1;
            }
        }
        // routing
        let (mut n_wire, mut n_via) = (0usize, 0usize);
        if mode == "ALL" && !x.has("-no_routing") {
            if let Some(db) = self.routes.as_ref() {
                let half = (db.g * 0.35 * dbu).round() as i32;
                let w = (db.g * 0.35 * dbu).round() as i32 * 2 / 2;
                let mut lay: Vec<Option<(i16, i16)>> = vec![];
                let mut vias: Vec<Option<(i16, i16)>> = vec![];
                for (i, l) in db.layers.iter().enumerate() {
                    lay.push(lget(&l.name, if false { "SPNET" } else { "NET" }));
                    vias.push(if i + 1 < db.layers.len() { lget(&format!("VIA{}", i + 1), "VIA") } else { None });
                }
                let mut ids: Vec<_> = db.nets.keys().copied().collect();
                ids.sort();
                for nid in ids {
                    let r = &db.nets[&nid];
                    let idx: HashMap<u32, usize> = r.tree.iter().enumerate().map(|(i, (n, _))| (*n, i)).collect();
                    let mut nchild = vec![0usize; r.tree.len()];
                    for (_, p) in &r.tree {
                        if let Some(&pi) = idx.get(p) {
                            nchild[pi] += 1;
                        }
                    }
                    let pins: HashSet<u32> = r.pins.iter().map(|q| q.1).collect();
                    let dir = |a: u32, b: u32| -> (i64, i64, i64) {
                        let (x1, y1, l1) = db.xyl(a);
                        let (x2, y2, l2) = db.xyl(b);
                        ((x2 as i64 - x1 as i64).signum(), (y2 as i64 - y1 as i64).signum(), l2 as i64 - l1 as i64)
                    };
                    for (i, (n, p)) in r.tree.iter().enumerate() {
                        if *p == crate::droute::NONE {
                            continue;
                        }
                        let (x1, y1, l1) = db.pos(*n);
                        let (_, _, l2) = db.pos(*p);
                        if l1 == l2 {
                            let d = dir(*n, *p);
                            // a run starts where the edge below does not continue it
                            if nchild[i] == 1 && !pins.contains(n) && r.tree.iter().any(|(c, cp)| cp == n && dir(*c, *n) == d) {
                                continue;
                            }
                            let mut end = *p;
                            loop {
                                let Some(&ei) = idx.get(&end) else { break };
                                let (_, ep) = r.tree[ei];
                                if ep == crate::droute::NONE || nchild[ei] != 1 || pins.contains(&end) || dir(end, ep) != d {
                                    break;
                                }
                                end = ep;
                            }
                            let (x2, y2, _) = db.pos(end);
                            if let Some((gl, gd)) = lay[l1] {
                                topc.elems.push(el_path(gl, gd, w.max(2), &[(u(x1), u(y1)), (u(x2), u(y2))]));
                                n_wire += 1;
                            }
                        } else {
                            let lo = l1.min(l2);
                            let r = (u(x1) - half, u(y1) - half, u(x1) + half, u(y1) + half);
                            for li in [lo, lo + 1] {
                                if let Some((gl, gd)) = lay[li] {
                                    topc.elems.push(el_boundary(gl, gd, r));
                                }
                            }
                            if let Some((gl, gd)) = vias[lo] {
                                let c = (half / 2).max(1);
                                topc.elems.push(el_boundary(gl, gd, (u(x1) - c, u(y1) - c, u(x1) + c, u(y1) + c)));
                            }
                            n_via += 1;
                        }
                    }
                }
            } else {
                crate::warn!("GDS-104", "export_gds: the design is not routed; no wires written");
            }
        }
        // special wiring (seal ring, RDL, manual wires), bumps and bond pads
        let (mut n_special, mut n_bump) = (0usize, 0usize);
        if let Some(f) = fp.as_ref() {
            if mode != "FILLONLY" {
                for sh in &f.special {
                    // generated via arrays: every cut on the cut layer, the landing pads on both metals
                    if let (Some(v), Some(r)) = (&sh.via, sh.rect) {
                        if let Some((gl, gd)) = lget(&sh.layer, "VIA") { for c in v.cuts(r) { topc.elems.push(el_boundary(gl, gd, (u(c.0), u(c.1), u(c.2), u(c.3)))); } }
                        for l in [&v.lower, &v.upper] { if let Some((gl, gd)) = lget(l, "SPNET") { topc.elems.push(el_boundary(gl, gd, (u(r.0), u(r.1), u(r.2), u(r.3)))); } }
                        n_special += 1;
                        continue;
                    }
                    let Some((gl, gd)) = lget(&sh.layer, "SPNET") else { continue };
                    if let Some(r) = sh.rect {
                        topc.elems.push(el_boundary(gl, gd, (u(r.0), u(r.1), u(r.2), u(r.3))));
                    } else if sh.pts.len() >= 2 {
                        let pts: Vec<(i32, i32)> = sh.pts.iter().map(|q| (u(q.0), u(q.1))).collect();
                        topc.elems.push(el_path(gl, gd, u(sh.width).max(2), &pts));
                    }
                    n_special += 1;
                }
                for b in &f.bumps {
                    let h = self.lef.get(&b.cell).map(|m| m.w / 2.0).unwrap_or(20.0);
                    if let Some((gl, gd)) = lget(&b.layer, "PIN") {
                        topc.elems.push(el_boundary(gl, gd, (u(b.x - h), u(b.y - h), u(b.x + h), u(b.y + h))));
                        n_bump += 1;
                    }
                    if !b.net.is_empty() && !x.has("-no_labels") {
                        if let Some((gl, gd)) = lget(&b.layer, "LABEL") {
                            topc.elems.push(el_text(gl, gd, (u(b.x), u(b.y)), &b.net));
                        }
                    }
                }
                for bp in &f.io.bond_pads {
                    let ly = self.lef.get(&bp.cell).and_then(|m| m.pins.first().and_then(|p| p.shapes.first().map(|s| s.0.clone()))).unwrap_or("M6".into());
                    if let Some((gl, gd)) = lget(&ly, "PIN") {
                        let r = bp.rect;
                        topc.elems.push(el_boundary(gl, gd, (u(r.0), u(r.1), u(r.2), u(r.3))));
                    }
                }
            }
        }
        if n_special + n_bump > 0 {
            crate::info!("GDS-107", "Wrote {} special shape(s) and {} bump(s)", n_special, n_bump);
        }
        // top-level pins: shape + label
        let mut n_pins = 0usize;
        if mode != "FILLONLY" && !x.has("-no_pins") {
            for p in nl.port_ids() {
                let pt = &nl.ports[p];
                let Some((px, py)) = pt.loc else { continue };
                let (side, layer, _) = fp.as_ref().and_then(|f| f.pin_info.get(&pt.name).cloned()).unwrap_or(("bottom".into(), "M3".into(), String::new()));
                let (w, d) = fp.as_ref().map(|f| f.pin_shapes.get(&pt.name).copied().unwrap_or_else(|| crate::fplan::pin_shape(&f.block_pins, &f.layers, &layer))).unwrap_or((0.1, 0.4));
                let rr = match side.as_str() {
                    "left" => (px, py - w / 2.0, px + d, py + w / 2.0),
                    "right" => (px - d, py - w / 2.0, px, py + w / 2.0),
                    "top" => (px - w / 2.0, py - d, px + w / 2.0, py),
                    _ => (px - w / 2.0, py, px + w / 2.0, py + d),
                };
                let r = (u(rr.0), u(rr.1), u(rr.2), u(rr.3));
                if let Some((gl, gd)) = lget(&layer, "PIN") {
                    topc.elems.push(el_boundary(gl, gd, r));
                }
                if !x.has("-no_labels") {
                    if let Some((gl, gd)) = lget(&layer, "LABEL") {
                        topc.elems.push(el_text(gl, gd, ((r.0 + r.2) / 2, (r.1 + r.3) / 2), &pt.name));
                    }
                }
                n_pins += 1;
            }
        }
        lib.structs.push(topc);
        if x.has("-prune_unused") {
            // keep only the structures reachable from the top cell
            let idx: HashMap<String, usize> = lib.structs.iter().enumerate().map(|(i, s)| (s.name.clone(), i)).collect();
            let mut keep: HashSet<usize> = HashSet::new();
            let mut st = vec![lib.structs.len() - 1];
            while let Some(i) = st.pop() {
                if !keep.insert(i) {
                    continue;
                }
                for e in &lib.structs[i].elems {
                    if let Some(n) = elem_sname(e) {
                        if let Some(&j) = idx.get(&n) {
                            st.push(j);
                        }
                    }
                }
            }
            let before = lib.structs.len();
            let mut k = 0;
            lib.structs.retain(|_| {
                k += 1;
                keep.contains(&(k - 1))
            });
            crate::info!("GDS-106", "-prune_unused: removed {} merged structure(s) not referenced from {}", before - lib.structs.len(), top);
        }
        // ---- checks
        let missing: Vec<(&String, &usize)> = refs.iter().filter(|(n, _)| !have.contains_key(*n)).collect();
        let bytes = write_gds(&out, &lib).map_err(|e| Flow::Err(format!("export_gds: {}: {}", out, e)))?;
        for (f, ad, sk) in &per_file {
            crate::info!("GDS-101", "Merged '{}': {} structure(s){}", f, ad, if *sk > 0 { format!(", {} skipped", sk) } else { String::new() });
        }
        for d in dups.iter().take(20) {
            crate::warn!("GDS-120", "Duplicate structure {} (use -uniquify_cell_names to keep both)", d);
        }
        for m in &unmapped {
            crate::warn!("GDS-130", "Layer/purpose '{}' is not in the layer map; those shapes are not written", m);
        }
        if !missing.is_empty() {
            crate::warn!(
                "GDS-110",
                "{} referenced cell(s) have no layout in the merged GDS ({} instances): {}{}",
                missing.len(),
                missing.iter().map(|m| *m.1).sum::<usize>(),
                missing.iter().take(10).map(|m| m.0.clone()).collect::<Vec<_>>().join(" "),
                if missing.len() > 10 { " ..." } else { "" }
            );
        }
        if n_unplaced > 0 {
            crate::warn!("GDS-111", "{} unplaced instance(s) not written", n_unplaced);
        }
        let _ = Dir::In;
        let _ = PinRef::Port(0);
        crate::info!(
            "GDS-100",
            "Wrote GDSII '{}' ({} bytes, {} dbu/um): top cell {} with {} instance(s) of {} cell type(s), {} wire(s), {} via(s), {} pin(s); {} structure(s) merged from {} file(s); {} unresolved reference(s)",
            out,
            bytes,
            dbu,
            top,
            n_inst,
            refs.len(),
            n_wire,
            n_via,
            n_pins,
            have.len(),
            inputs.len(),
            missing.len()
        );
        Ok(out)
    }
}

#[allow(dead_code)]
fn _u(_: &Netlist) {}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn gds_real8_and_records_round_trip() {
        for v in [1e-3, 1e-9, 0.5, 90.0, 270.0, -2.25, 1.0] {
            let d = real8_dec(&real8_enc(v));
            assert!((d - v).abs() <= v.abs() * 1e-14, "{} -> {}", v, d);
        }
        let mut lib = GLib { name: "L".into(), uu: 1e-3, dbm: 1e-9, structs: vec![] };
        let mut s = GStruct { name: "A".into(), ..Default::default() };
        s.elems.push(el_boundary(31, 0, (0, 0, 100, 200)));
        s.elems.push(el_text(31, 251, (50, 50), "VDD"));
        let mut t = GStruct { name: "TOP".into(), ..Default::default() };
        t.elems.push(el_sref("A", (1000, 2000), "FS"));
        t.elems.push(el_path(32, 0, 50, &[(0, 0), (0, 4000)]));
        lib.structs = vec![s, t];
        let p = std::env::temp_dir().join("rsynth_gds_unit.gds");
        write_gds(p.to_str().unwrap(), &lib).unwrap();
        let r = read_gds(p.to_str().unwrap()).unwrap();
        assert_eq!(r.structs.len(), 2);
        assert!((r.uu - 1e-3).abs() < 1e-15 && (r.dbm - 1e-9).abs() < 1e-20);
        let gi = gds_info(&r);
        assert_eq!(gi.tops, vec!["TOP".to_string()]);
        assert!(gi.unresolved.is_empty());
        assert_eq!(gi.counts[1], 1);
        let m = LayerMap::parse("M1 NET,SPNET 31 0\nM1 PIN 31 2\nVIA1 VIA 51 0\n").unwrap();
        assert_eq!(m.get("m1", "spnet"), Some((31, 0)));
        assert_eq!(m.get("M1", "PIN"), Some((31, 2)));
        assert!(LayerMap::parse("M1 NET x 0").is_err());
    }
}
