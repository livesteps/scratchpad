//! Optimization controls shared by place_opt, clock_opt and route_opt:
//!   -setup / -hold / -drv / -power : which fixes run (default: all of them)
//!   -incremental                   : keep the placement / clock trees / routes; fix only what is
//!                                    left (no re-placement, CTS rebuild, HFS, decloning, logic
//!                                    sharing; power/area recovery only with -power); changed
//!                                    cells are ECO-legalized
//!                                    and, when routed, only their nets rerouted
//!   -endpoints <file>              : work only on the paths to the listed endpoints; every other
//!                                    endpoint is guarded (a move that makes one worse is undone)
//!   -effort low|medium|high        : low = sizing only, few passes; medium = the default
//!                                    (sizing, Vt and pin swaps); high = also cloning, twice the
//!                                    passes and three times the paths per pass
use crate::netlist::{Netlist, PinRef};
use crate::session::*;
use crate::tcl::Flow;
type R = Result<String, Flow>;
use std::collections::{BTreeMap, HashSet};
use std::sync::Arc;

#[derive(Clone, Debug)]
pub struct OptCtl {
    pub flow: String,
    pub setup: bool,
    pub hold: bool,
    pub drv: bool,
    pub power: bool,
    /// a fix type was selected explicitly
    pub selected: bool,
    pub incremental: bool,
    pub effort: String,
    pub focus: Option<Arc<HashSet<String>>>,
    pub focus_file: Option<String>,
}

impl OptCtl {
    pub fn npaths(&self) -> usize {
        match self.effort.as_str() {
            "low" => 10,
            "high" => 120,
            _ => 40,
        }
    }
    /// timing-optimization passes for a base count
    pub fn iters(&self, base: usize) -> usize {
        match self.effort.as_str() {
            "low" => (base / 4).max(2),
            "high" => base * 2,
            _ => base,
        }
    }
    pub fn allow_vt(&self, dflt: bool) -> bool {
        dflt && self.effort != "low"
    }
    pub fn allow_clone(&self, dflt: bool) -> bool {
        match self.effort.as_str() {
            "low" => false,
            "high" => true,
            _ => dflt,
        }
    }
    /// global transformations (decloning, logic sharing, HFS) are kept out of incremental and
    /// endpoint-limited runs
    pub fn global_ok(&self) -> bool {
        !self.incremental && self.focus.is_none()
    }
}

pub const OPT_FLAGS: &[&str] = &["-setup", "-hold", "-drv", "-power", "-incremental"];
pub const OPT_VALUES: &[&str] = &["-endpoints", "-effort"];

/// endpoint names from a file: whitespace / newline separated, '#' comments, braces allowed; a
/// cell name stands for every endpoint pin of that cell
pub fn read_endpoints(nl: &Netlist, path: &str) -> Result<HashSet<String>, Flow> {
    let txt = std::fs::read_to_string(path).map_err(|e| Flow::Err(format!("-endpoints: {}: {} (OPT-902)", path, e)))?;
    let mut out = HashSet::new();
    let mut bad = vec![];
    for line in txt.lines() {
        let line = line.split('#').next().unwrap_or("");
        for tok in line.split_whitespace() {
            let t = tok.trim_matches(|c| c == '{' || c == '}' || c == '"');
            if t.is_empty() {
                continue;
            }
            if nl.find_pin(t).is_some() || nl.port_by_name(t).is_some() {
                out.insert(t.to_string());
            } else if let Some(c) = nl.cell_by_name(t) {
                // every input pin of the cell (the timing check decides which are endpoints)
                for p in &nl.cell(c).pins {
                    if p.dir == crate::netlist::Dir::In {
                        out.insert(format!("{}/{}", nl.cell(c).name, p.name));
                    }
                }
            } else {
                bad.push(t.to_string());
            }
        }
    }
    if !bad.is_empty() {
        return Err(Flow::Err(format!("-endpoints: {} name(s) in '{}' are not pins, ports or cells of the design: {} (OPT-901)", bad.len(), path, bad.iter().take(6).cloned().collect::<Vec<_>>().join(" "))));
    }
    if out.is_empty() {
        return Err(Flow::Err(format!("-endpoints: no endpoints in '{}' (OPT-903)", path)));
    }
    Ok(out)
}

impl Session {
    /// parse the optimization controls; returns (controls, remaining arguments)
    pub(crate) fn parse_opt_ctl(&self, flow: &str, a: &[String]) -> Result<(Option<OptCtl>, Vec<String>), Flow> {
        let mut rest = vec![];
        let mut ctl = OptCtl { flow: flow.into(), setup: false, hold: false, drv: false, power: false, selected: false, incremental: false, effort: "medium".into(), focus: None, focus_file: None };
        let mut any = false;
        let mut i = 0;
        while i < a.len() {
            let w = a[i].as_str();
            match w {
                "-setup" => ctl.setup = true,
                "-hold" => ctl.hold = true,
                "-drv" => ctl.drv = true,
                "-power" => ctl.power = true,
                "-incremental" => ctl.incremental = true,
                "-effort" | "-endpoints" => {
                    let Some(v) = a.get(i + 1) else { return Err(Flow::Err(format!("{}: {} needs a value (OPT-904)", flow, w))) };
                    if w == "-effort" {
                        let v = v.to_lowercase();
                        if !["low", "medium", "high"].contains(&v.as_str()) {
                            return Err(Flow::Err(format!("{}: -effort must be low, medium or high (OPT-905)", flow)));
                        }
                        ctl.effort = v;
                    } else {
                        let nl = self.nl()?;
                        ctl.focus = Some(Arc::new(read_endpoints(nl, v)?));
                        ctl.focus_file = Some(v.clone());
                    }
                    any = true;
                    i += 2;
                    continue;
                }
                _ => {
                    rest.push(a[i].clone());
                    i += 1;
                    continue;
                }
            }
            any = true;
            i += 1;
        }
        if !any {
            return Ok((None, rest));
        }
        ctl.selected = ctl.setup || ctl.hold || ctl.drv || ctl.power;
        if !ctl.selected {
            ctl.setup = true;
            ctl.hold = true;
            ctl.drv = true;
            ctl.power = ctl.focus.is_none() && !ctl.incremental;
        }
        Ok((Some(ctl), rest))
    }

    /// cell -> reference, for the change report
    fn cell_refs(&self) -> BTreeMap<String, String> {
        let Some(nl) = self.nl.as_ref() else { return BTreeMap::new() };
        nl.cell_ids()
            .into_iter()
            .filter(|c| !nl.cell(*c).is_hport())
            .map(|c| (nl.cell(c).name.clone(), match &nl.cell(c).kind {
                crate::netlist::Kind::Lib(l) => l.clone(),
                k => format!("{:?}", k),
            }))
            .collect()
    }

    /// (focus WNS, focus TNS, focus WHS, other WNS, other TNS, other WHS)
    fn focus_qor(&mut self) -> Option<[f64; 6]> {
        self.with_env(|nl, env| {
            let a = env.analyze(nl, 0);
            [a.fwns, a.ftns, a.fwhs, a.owns, a.otns, a.owhs]
        })
        .ok()
    }

    /// run one of place_opt / clock_opt / route_opt with the controls in force, and report what the
    /// controls did
    pub(crate) fn with_opt_ctl(&mut self, flow: &str, a: &[String], run: impl FnOnce(&mut Session, &[String], Option<&OptCtl>) -> R) -> R {
        let (ctl, rest) = self.parse_opt_ctl(flow, a)?;
        let Some(ctl) = ctl else { return run(self, &rest, None) };
        let refs0 = self.cell_refs();
        let g0 = self.with_env(|nl, env| {
            let a = env.analyze(nl, 0);
            (a.wns, a.tns, a.whs, a.drv.len())
        });
        self.opt_ctl = Some(ctl.clone());
        let q0 = if ctl.focus.is_some() { self.focus_qor() } else { None };
        let mut what = vec![];
        for (on, n) in [(ctl.setup, "setup"), (ctl.hold, "hold"), (ctl.drv, "drv"), (ctl.power, "power")] {
            if on {
                what.push(n);
            }
        }
        crate::info!(
            "OPT-900",
            "{}: fixing {}{}, effort {}{}",
            flow,
            what.join(" "),
            if ctl.incremental { ", incremental" } else { "" },
            ctl.effort,
            ctl.focus.as_ref().map(|f| format!(", {} endpoint(s) from '{}'", f.len(), ctl.focus_file.clone().unwrap_or_default())).unwrap_or_default()
        );
        let r = run(self, &rest, Some(&ctl));
        let q1 = if ctl.focus.is_some() { self.focus_qor() } else { None };
        self.opt_ctl = None;
        let r = r?;
        if let (Ok(b), Ok(e)) = (g0, self.with_env(|nl, env| {
            let a = env.analyze(nl, 0);
            (a.wns, a.tns, a.whs, a.drv.len())
        })) {
            crate::out!("  {} controls: WNS {:.4} -> {:.4}  TNS {:.4} -> {:.4}  WHS {:.4} -> {:.4}  DRV {} -> {}", flow, b.0, e.0, b.1, e.1, b.2, e.2, b.3, e.3);
        }
        // what changed
        let refs1 = self.cell_refs();
        let mut changed: Vec<String> = refs1.iter().filter(|(c, r)| refs0.get(*c).map(|r0| r0 != *r).unwrap_or(true)).map(|(c, _)| c.clone()).collect();
        let removed = refs0.keys().filter(|c| !refs1.contains_key(*c)).count();
        changed.sort();
        if let (Some(f), Some(a0), Some(a1)) = (ctl.focus.as_ref(), q0, q1) {
            // every changed or added cell must lie on a path to a focus endpoint
            let outside: Vec<String> = {
                let nl = self.nl()?;
                let env_nets = {
                    let mut nets = HashSet::new();
                    let mut st: Vec<crate::netlist::NetId> = vec![];
                    for n in f.iter() {
                        if let Some(pr) = nl.find_pin(n).or_else(|| nl.port_by_name(n).map(PinRef::Port)) {
                            if let Some(x) = nl.pin_net(pr) {
                                st.push(x);
                            }
                        }
                    }
                    while let Some(x) = st.pop() {
                        if !nets.insert(x) {
                            continue;
                        }
                        if let Some(PinRef::Cell(c, _)) = nl.driver(x) {
                            let seq = nl.cell(c).lib().and_then(|l| self.libs.iter().find_map(|q| q.cells.get(l))).map(|lc| lc.is_seq()).unwrap_or(false);
                            if !seq {
                                for p in &nl.cell(c).pins {
                                    if p.dir == crate::netlist::Dir::In {
                                        if let Some(m) = p.net {
                                            st.push(m);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    nets
                };
                changed
                    .iter()
                    .filter(|c| {
                        let Some(ci) = nl.cell_by_name(c) else { return false };
                        !nl.cell(ci).pins.iter().any(|p| p.net.map(|n| env_nets.contains(&n)).unwrap_or(false))
                    })
                    .cloned()
                    .collect()
            };
            crate::out!("\n  {} -endpoints {} ({} endpoints)", flow, ctl.focus_file.clone().unwrap_or_default(), f.len());
            crate::out!("  {:<22} {:>10} {:>10}", "", "before", "after");
            let fm = |v: f64| if v.is_finite() { format!("{:.4}", if v == 0.0 { 0.0 } else { v }) } else { "-".into() };
            for (k, l) in ["focus WNS", "focus TNS", "focus WHS", "other endpoints WNS", "other endpoints TNS", "other endpoints WHS"].iter().enumerate() {
                crate::out!("  {:<22} {:>10} {:>10}", l, fm(a0[k]), fm(a1[k]));
            }
            crate::out!("  cells changed or added {}, removed {}, outside the focus cones {}", changed.len(), removed, outside.len());
            // worse = lower than before and below zero (the optimizer's guard)
            let worse_s = (a1[3].is_finite() && a1[3] < a0[3] - 1e-6 && a1[3] < 0.0) || a1[4] < a0[4] - 1e-6;
            let worse_h = a1[5].is_finite() && a1[5] < a0[5] - 1e-6 && a1[5] < 0.0;
            if worse_s || worse_h || !outside.is_empty() {
                crate::warn!("OPT-910", "{} -endpoints: other endpoints were affected (setup {}, hold {}, {} cell(s) outside the focus cones: {})", flow, if worse_s { "worse" } else { "kept" }, if worse_h { "worse" } else { "kept" }, outside.len(), outside.iter().take(5).cloned().collect::<Vec<_>>().join(" "));
            } else {
                crate::info!("OPT-911", "{} -endpoints: only paths to the {} focus endpoint(s) were changed; other endpoints are not worse", flow, f.len());
            }
        } else {
            crate::info!("OPT-912", "{}: {} cell(s) changed or added, {} removed", flow, changed.len(), removed);
        }
        Ok(r)
    }
}

#[allow(dead_code)]
fn _u(_: &Netlist) {}
