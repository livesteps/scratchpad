//! define_name_rules / change_names / report_names.
//!
//! Names in the netlist are flat hierarchical paths ("u_core/g_lane[0].u_lane/U12"). A path is
//! renamed in pieces:
//!   * kept-hierarchy prefix (instances still written as their own modules): unchanged, or each
//!     segment renamed with `-hierarchy`
//!   * flattened hierarchy segments: bus brackets -> hier_bus_char, then the hierarchy delimiter
//!     ('/' by default; e.g. '_' or '!' or '.') joins them to the leaf
//!   * leaf: angle -> square bus bits, the target bus naming style on a trailing bit index,
//!     disallowed characters -> replacement char, map pairs, first/last restrictions, max length
//! Results are made unique across cells and nets (they share a Verilog module name space).
//! Old names stay valid as aliases, so constraints, UPF, DFT and floorplan references still resolve.
use crate::netlist::{Netlist, PinRef};
use std::collections::{BTreeMap, HashMap, HashSet};

#[derive(Clone, Debug)]
pub struct NameRules {
    pub name: String,
    /// allowed characters, as ranges and single characters ("a-zA-Z0-9_")
    pub allowed: Vec<(char, char)>,
    pub first_restricted: Vec<(char, char)>,
    pub last_restricted: Vec<(char, char)>,
    pub replacement: char,
    pub max_length: Option<usize>,
    pub map: Vec<(String, String)>,
    pub case_insensitive: bool,
    /// object types the rules apply to (cell, net, port)
    pub types: Vec<String>,
    /// target bus naming style for a trailing bit index, "%s[%d]" keeps brackets
    pub bus_style: String,
    /// replace the hierarchy separator of flattened names with this (None: keep '/')
    pub hier_delimiter: Option<char>,
    /// characters replacing [ and ] in hierarchical (bussed / generate) instance segments
    pub hier_bus_char: Option<char>,
    /// '.' (generate / struct separators) -> this
    pub dot_char: Option<char>,
    pub angle_to_square: bool,
    pub equal_ports_nets: bool,
    pub no_double_underscore: bool,
}

fn ranges(spec: &str) -> Vec<(char, char)> {
    let c: Vec<char> = spec.chars().collect();
    let mut v = vec![];
    let mut i = 0;
    while i < c.len() {
        if i + 2 < c.len() && c[i + 1] == '-' {
            v.push((c[i], c[i + 2]));
            i += 3;
        } else {
            v.push((c[i], c[i]));
            i += 1;
        }
    }
    v
}
fn inr(r: &[(char, char)], ch: char) -> bool {
    r.iter().any(|(a, b)| ch >= *a && ch <= *b)
}

impl NameRules {
    pub fn new(name: &str) -> NameRules {
        NameRules {
            name: name.into(),
            allowed: ranges("a-zA-Z0-9_"),
            first_restricted: vec![],
            last_restricted: vec![],
            replacement: '_',
            max_length: None,
            map: vec![],
            case_insensitive: false,
            types: vec!["cell".into(), "net".into(), "port".into()],
            bus_style: "%s[%d]".into(),
            hier_delimiter: None,
            hier_bus_char: None,
            dot_char: None,
            angle_to_square: false,
            equal_ports_nets: false,
            no_double_underscore: false,
        }
    }
    /// built-in rule sets
    pub fn builtin(name: &str) -> Option<NameRules> {
        let mut r = NameRules::new(name);
        match name {
            "verilog" => {
                r.first_restricted = ranges("0-9");
                r.hier_delimiter = Some('_');
                r.hier_bus_char = Some('_');
                r.dot_char = Some('_');
                r.angle_to_square = true;
                r.equal_ports_nets = true;
            }
            "vhdl" => {
                r.first_restricted = ranges("0-9_");
                r.last_restricted = ranges("_");
                r.hier_delimiter = Some('_');
                r.hier_bus_char = Some('_');
                r.dot_char = Some('_');
                r.angle_to_square = true;
                r.equal_ports_nets = true;
                r.no_double_underscore = true;
                r.case_insensitive = true;
            }
            _ => return None,
        }
        Some(r)
    }
    pub fn set_allowed(&mut self, s: &str) {
        self.allowed = ranges(s);
    }
    pub fn set_first(&mut self, s: &str) {
        self.first_restricted = ranges(s);
    }
    pub fn set_last(&mut self, s: &str) {
        self.last_restricted = ranges(s);
    }

    /// characters of one name piece: disallowed -> replacement, restrictions, collapse "__"
    fn clean(&self, s: &str) -> String {
        let mut o: String = s.chars().map(|c| if inr(&self.allowed, c) { c } else { self.replacement }).collect();
        if self.no_double_underscore {
            while o.contains("__") {
                o = o.replace("__", "_");
            }
        }
        if let Some(f) = o.chars().next() {
            if inr(&self.first_restricted, f) {
                // keep the character, put a legal letter in front
                o = format!("{}{}", if inr(&self.first_restricted, self.replacement) || !inr(&self.allowed, self.replacement) { 'n' } else { self.replacement }, o);
                if inr(&self.first_restricted, o.chars().next().unwrap()) {
                    o = format!("n{}", o);
                }
            }
        }
        while let Some(l) = o.chars().last() {
            if inr(&self.last_restricted, l) && o.len() > 1 {
                o.pop();
            } else {
                break;
            }
        }
        o
    }

    /// rename the part of a path below the kept-hierarchy prefix
    pub fn rename_rest(&self, rest: &str, kind: &str) -> String {
        let mut s = rest.to_string();
        for (a, b) in &self.map {
            s = s.replace(a.as_str(), b.as_str());
        }
        if self.angle_to_square {
            s = angle_to_square(&s);
        }
        let segs: Vec<&str> = s.split('/').collect();
        let (hier, leaf) = segs.split_at(segs.len() - 1);
        let leaf = leaf[0];
        let mut out_h: Vec<String> = vec![];
        for h in hier {
            let mut x = h.to_string();
            if let Some(c) = self.hier_bus_char {
                x = x.replace(['[', ']'], &c.to_string());
            }
            if let Some(c) = self.dot_char {
                x = x.replace('.', &c.to_string());
            }
            out_h.push(self.clean(&x));
        }
        // leaf: a trailing bit index of a net or port follows the bus naming style
        let (base, bit) = split_bit(leaf);
        let mut base = base;
        if let Some(c) = self.dot_char {
            base = base.replace('.', &c.to_string());
        }
        // only true vectors keep a bit index in brackets: ports, and nets on ports or on a kept
        // module's boundary (the flat writer declares no internal vectors)
        let keep_bus = (kind == "port" || kind == "port_net") && self.bus_style.contains('[');
        let leaf_new = match bit {
            Some(b) if keep_bus => format!("{}[{}]", self.clean(&base), b),
            Some(b) => {
                let st = self.bus_style.replace("%s", &base).replace("%d", &b.to_string());
                self.clean(&st)
            }
            None => self.clean(&base),
        };
        let mut r = match self.hier_delimiter {
            None => {
                let mut v = out_h;
                v.push(leaf_new);
                v.join("/")
            }
            Some(d) => {
                let mut v = out_h;
                v.push(leaf_new);
                let j = v.join(&d.to_string());
                if d == '_' && self.no_double_underscore {
                    let mut j = j;
                    while j.contains("__") {
                        j = j.replace("__", "_");
                    }
                    j
                } else {
                    j
                }
            }
        };
        if let Some(m) = self.max_length {
            if r.chars().count() > m {
                r = r.chars().take(m).collect();
            }
        }
        r
    }

    /// is a full name legal under these rules (for report_names / checks)?
    pub fn legal(&self, name: &str, kind: &str, kept: &[String]) -> bool {
        let (_, rest) = split_kept(name, kept);
        self.rename_rest(rest, kind) == rest
    }
}

pub fn angle_to_square(s: &str) -> String {
    // name<3> -> name[3] (only around digits)
    let c: Vec<char> = s.chars().collect();
    let mut o = String::new();
    let mut i = 0;
    while i < c.len() {
        if c[i] == '<' {
            if let Some(j) = (i + 1..c.len()).find(|&j| c[j] == '>') {
                if j > i + 1 && c[i + 1..j].iter().all(|x| x.is_ascii_digit() || *x == ':') {
                    o.push('[');
                    o.extend(&c[i + 1..j]);
                    o.push(']');
                    i = j + 1;
                    continue;
                }
            }
        }
        o.push(c[i]);
        i += 1;
    }
    o
}

fn split_bit(s: &str) -> (String, Option<i64>) {
    if s.ends_with(']') {
        if let Some(i) = s.rfind('[') {
            if let Ok(v) = s[i + 1..s.len() - 1].parse::<i64>() {
                return (s[..i].to_string(), Some(v));
            }
        }
    }
    (s.to_string(), None)
}

/// longest kept-hierarchy prefix of a name: (prefix, rest)
pub fn split_kept<'a>(name: &'a str, kept: &[String]) -> (&'a str, &'a str) {
    let mut best = 0;
    for k in kept {
        if name.len() > k.len() && name.starts_with(k.as_str()) && name.as_bytes()[k.len()] == b'/' && k.len() > best {
            best = k.len();
        }
    }
    if best == 0 {
        ("", name)
    } else {
        (&name[..best], &name[best + 1..])
    }
}

#[derive(Default, Debug)]
pub struct Changes {
    /// (type, old, new)
    pub list: Vec<(String, String, String)>,
    pub hier: Vec<(String, String)>,
}

/// compute (and with `apply`, perform) the renames
pub fn change_names(nl: &mut Netlist, r: &NameRules, hierarchy: bool, apply: bool) -> Changes {
    let mut ch = Changes::default();
    let kept: Vec<String> = nl.kept_hier().iter().map(|k| k.0.clone()).collect();
    // kept hierarchy instance paths: renamed segment by segment with -hierarchy
    let mut hmap: BTreeMap<String, String> = BTreeMap::new();
    if hierarchy {
        let mut ks = kept.clone();
        ks.sort_by_key(|k| k.matches('/').count());
        for k in &ks {
            let (parent, last) = match k.rsplit_once('/') {
                Some((p, l)) => (hmap.get(p).cloned().unwrap_or(p.to_string()), l),
                None => (String::new(), k.as_str()),
            };
            let mut x = last.to_string();
            if r.angle_to_square {
                x = angle_to_square(&x);
            }
            if let Some(c) = r.hier_bus_char {
                x = x.replace(['[', ']'], &c.to_string());
            }
            if let Some(c) = r.dot_char {
                x = x.replace('.', &c.to_string());
            }
            let nw = if parent.is_empty() { r.clean(&x) } else { format!("{}/{}", parent, r.clean(&x)) };
            hmap.insert(k.clone(), nw.clone());
            if &nw != k {
                ch.hier.push((k.clone(), nw));
            }
        }
    }
    let map_prefix = |p: &str| -> String { hmap.get(p).cloned().unwrap_or(p.to_string()) };
    let full = |p: &str, rest: &str| -> String { if p.is_empty() { rest.to_string() } else { format!("{}/{}", map_prefix(p), rest) } };
    let on = |k: &str| r.types.iter().any(|t| t == k);
    let key = |s: &str| if r.case_insensitive { s.to_lowercase() } else { s.to_string() };
    let mut taken: HashSet<String> = HashSet::new();
    // names that stay as they are reserve their slot first
    let mut cell_new: Vec<(crate::netlist::CellId, String)> = vec![];
    let mut net_new: Vec<(crate::netlist::NetId, String)> = vec![];
    let port_names: HashMap<crate::netlist::NetId, String> = nl.port_ids().iter().filter_map(|p| nl.ports[*p].net.map(|n| (n, nl.ports[*p].name.clone()))).collect();
    let port_keys: HashSet<String> = nl.port_ids().iter().map(|p| key(&nl.ports[*p].name)).collect();
    let mut pending: Vec<(bool, usize, String, String)> = vec![]; // (is_cell, id, old, wanted)
    for c in nl.cell_ids() {
        let cl = nl.cell(c);
        let old = cl.name.clone();
        let (p, rest) = split_kept(&old, &kept);
        let want = if cl.is_hport() {
            // boundary pins follow their instance; their own name is internal
            full(p, rest)
        } else if on("cell") {
            full(p, &r.rename_rest(rest, "cell"))
        } else {
            full(p, rest)
        };
        pending.push((true, c, old, want));
    }
    // kept prefix (module scope) of a cell name
    let scope_of_cell = |name: &str| -> String { split_kept(name, &kept).0.to_string() };
    for n in nl.net_ids() {
        let old = nl.net(n).name.clone();
        let constant = nl.driver(n).map(|d| matches!(d, PinRef::Cell(c, _) if matches!(nl.cell(c).kind, crate::netlist::Kind::Gen(crate::netlist::GOp::C0) | crate::netlist::Kind::Gen(crate::netlist::GOp::C1)))).unwrap_or(false);
        if constant || old == "1'b0" || old == "1'b1" {
            continue;
        }
        // the module a net lives in follows from its connections, not its name: the outer side
        // of a boundary pin belongs to the instance's parent scope
        // like the netlist writer: the lowest common module of every connection
        let scopes: Vec<String> = nl.net(n).conns.iter().filter_map(|c| match *c {
            PinRef::Port(_) => Some(String::new()),
            PinRef::Cell(ci, k) => {
                let cl = nl.cell(ci);
                match cl.hport() {
                    Some((inst, _, inp)) => {
                        let outer = (cl.pins[k].dir == crate::netlist::Dir::In) == inp;
                        Some(if outer { scope_of_cell(&inst) } else { inst })
                    }
                    None => Some(scope_of_cell(&cl.name)),
                }
            }
        }).collect();
        let lca = |a: &str, b: &str| -> String {
            let (x, y): (Vec<&str>, Vec<&str>) = (a.split('/').collect(), b.split('/').collect());
            let k = x.iter().zip(y.iter()).take_while(|(p, q)| p == q).count();
            let c = x[..k].join("/");
            if c.is_empty() || kept.contains(&c) { c } else { split_kept(&format!("{}/x", c), &kept).0.to_string() }
        };
        let scope = if scopes.is_empty() {
            split_kept(&old, &kept).0.to_string()
        } else {
            let mut l = scopes[0].clone();
            for s2 in &scopes[1..] {
                if l.is_empty() {
                    break;
                }
                l = lca(&l, s2);
            }
            l
        };
        // a net whose name does not start with its module's path (inherited through a boundary)
        // is renamed inside that module: its whole old name becomes the local name
        let scope_s = scope.clone();
        let (p, rest): (&str, &str) = if scope_s.is_empty() {
            ("", old.as_str())
        } else if old.starts_with(&format!("{}/", scope_s)) {
            (&old[..scope_s.len()], &old[scope_s.len() + 1..])
        } else {
            (scope_s.as_str(), old.as_str())
        };
        let boundary = nl.net(n).conns.iter().any(|c| nl.cell_is_hport(*c));
        let kind = if port_names.contains_key(&n) || boundary { "port_net" } else { "net" };
        let want = if r.equal_ports_nets && port_names.contains_key(&n) && p.is_empty() {
            port_names[&n].clone()
        } else if on("net") {
            full(p, &r.rename_rest(rest, kind))
        } else {
            full(p, rest)
        };
        pending.push((false, n, old, want));
    }
    let own_port: HashMap<crate::netlist::NetId, String> = port_names.clone();
    for (_, _, old, want) in &pending {
        if old == want {
            taken.insert(key(old));
        }
    }
    for (is_cell, id, old, want) in pending {
        if old == want {
            continue;
        }
        // a net may share its own port's name (if no other object holds it)
        if !is_cell && own_port.get(&id) == Some(&want) && r.equal_ports_nets && !taken.contains(&key(&want)) {
            taken.insert(key(&want));
            net_new.push((id, want.clone()));
            ch.list.push(("net".into(), old, want));
            continue;
        }
        let mut nm = want.clone();
        let mut k = 1;
        while taken.contains(&key(&nm)) || port_keys.contains(&key(&nm)) {
            nm = format!("{}_{}", want, k);
            k += 1;
        }
        taken.insert(key(&nm));
        if nm == old {
            continue;
        }
        if is_cell {
            cell_new.push((id, nm.clone()));
        } else {
            net_new.push((id, nm.clone()));
        }
        ch.list.push((if is_cell { "cell" } else { "net" }.into(), old, nm));
    }
    // ports: only illegal names are changed (the interface is kept otherwise)
    let mut port_new = vec![];
    if on("port") {
        for p in nl.port_ids() {
            let old = nl.ports[p].name.clone();
            let nw = r.rename_rest(&old, "port");
            if nw != old && !nl.port_by_name(&nw).is_some() {
                port_new.push((p, nw.clone()));
                ch.list.push(("port".into(), old, nw));
            }
        }
    }
    // boundary-pin port names of kept modules: multi-dimensional bits become legal vector bits
    // (din[0][1] -> din_0_[1]); single-dimension bits stay vector bits
    let mut hport_ren: Vec<(crate::netlist::CellId, String, String, bool)> = vec![];
    if let Some(hc) = r.hier_bus_char {
        for c in nl.cell_ids() {
            if let Some((inst, port, inp)) = nl.cell(c).hport() {
                let (base, bit) = split_bit(&port);
                if base.contains('[') || base.contains('.') {
                    let mut b2 = base.replace(['[', ']'], &hc.to_string());
                    if let Some(dc) = r.dot_char {
                        b2 = b2.replace('.', &dc.to_string());
                    }
                    let b2 = r.clean(&b2);
                    let np = match bit {
                        Some(i) => format!("{}[{}]", b2, i),
                        None => b2,
                    };
                    ch.list.push(("hier_port".into(), format!("{}/{}", inst, port), format!("{}/{}", inst, np)));
                    hport_ren.push((c, inst, np, inp));
                }
            }
        }
    }
    // generated boundary ports (nets crossing a kept boundary without a boundary pin)
    let mut alias_ren: Vec<(usize, String)> = vec![];
    if let Some(hc) = r.hier_bus_char {
        for (k, (inst, pb, _)) in nl.port_alias.iter().enumerate() {
            let (base, bit) = split_bit(pb);
            if base.contains('[') || base.contains('.') {
                let mut b2 = base.replace(['[', ']'], &hc.to_string());
                if let Some(dc) = r.dot_char {
                    b2 = b2.replace('.', &dc.to_string());
                }
                let b2 = r.clean(&b2);
                let np = match bit {
                    Some(i) => format!("{}[{}]", b2, i),
                    None => b2,
                };
                ch.list.push(("hier_port".into(), format!("{}/{}", inst, pb), format!("{}/{}", inst, np)));
                alias_ren.push((k, np));
            }
        }
    }
    if apply {
        for (k, np) in &alias_ren {
            nl.port_alias[*k].1 = np.clone();
        }
        for (c, inst, np, inp) in &hport_ren {
            let cm = nl.cell_mut(*c);
            cm.attrs.retain(|a| !a.starts_with("hp:"));
            cm.attrs.push(format!("hp:{}:{}:{}", inst, np, if *inp { "i" } else { "o" }));
        }
        // two phases so that swaps and chains never collide on the way
        for (c, _) in &cell_new {
            let tmp = format!("__cn_tmp_{}", c);
            nl.rename_cell(*c, &tmp);
        }
        for (n, _) in &net_new {
            let tmp = format!("__nn_tmp_{}", n);
            nl.rename_net(*n, &tmp);
        }
        for (c, nm) in &cell_new {
            nl.rename_cell(*c, nm);
        }
        for (n, nm) in &net_new {
            nl.rename_net(*n, nm);
        }
        for (p, nm) in &port_new {
            nl.rename_port(*p, nm);
        }
        for (t, old, nw) in &ch.list {
            nl.add_alias(t, old, nw);
        }
        // kept hierarchy: instance paths, boundary-pin attributes
        if !hmap.is_empty() {
            for (inst, _) in nl.hier.iter_mut() {
                *inst = hmap.get(inst).cloned().unwrap_or(inst.clone());
            }
            for c in nl.cell_ids() {
                if let Some((inst, port, inp)) = nl.cell(c).hport() {
                    if let Some(ni) = hmap.get(&inst) {
                        let cm = nl.cell_mut(c);
                        cm.attrs.retain(|a| !a.starts_with("hp:"));
                        cm.attrs.push(format!("hp:{}:{}:{}", ni, port, if inp { "i" } else { "o" }));
                    }
                }
            }
            for (o, n) in &ch.hier {
                nl.add_alias("hier", o, n);
            }
        }
    }
    let _ = PinRef::Port(0);
    ch
}
