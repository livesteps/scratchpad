//! Run metrics (Innovus-style) and the run / command logs.
//!
//! * Every run writes `rsynth.run.log` (the full session output, with `<CMD>` lines) and
//!   `rsynth.cmd.log` (the commands only, replayable with `source`) in the current directory, as
//!   Innovus writes innovus.log / innovus.cmd. When they exist from an earlier run the next free
//!   `rsynth.run.logN` / `rsynth.cmd.logN` pair is used. `set_log_filename` / `set_cmd_filename`
//!   move them (everything logged so far is kept); the environment variables `RSYNTH_LOG_FILE` /
//!   `RSYNTH_CMD_FILE` preset them; `-nolog` (or `RSYNTH_NOLOG=1`) turns both off.
//! * The log starts with a run header (version, host, user, pid, cwd, OS, CPUs, log files).
//!   Flow commands print `*** <cmd> #N [begin]` and `[finish]` lines with cpu / real time, the
//!   session totals and memory (RSS / peak), and a stage QoR line (cells, area, utilization, setup /
//!   hold WNS / TNS, DRVs, wirelength, opens / shorts). Other commands report the same
//!   `[finish]` line when they take at least `run_metrics.min_time` seconds. `report_run_metrics`
//!   lists per-command totals and the stage QoR history; the run ends with the session summary and
//!   `--- Ending "RSynth" (totcpu=..., real=..., mem=...) ---`.

use crate::session::{args, Session};
use crate::tcl::{err, R};
use std::collections::BTreeMap;
use std::sync::Mutex;
use std::time::Instant;

#[derive(Clone, Default)]
pub struct CmdStat {
    pub count: usize,
    pub real: f64,
    pub cpu: f64,
    pub mem_delta: f64,
    pub peak: f64,
}
#[derive(Clone)]
pub struct StageQor {
    pub cmd: String,
    pub n: usize,
    pub real: f64,
    pub cpu: f64,
    pub mem: f64,
    pub cells: usize,
    pub area: f64,
    pub util: Option<f64>,
    pub setup: Option<(f64, f64)>,
    pub hold: Option<(f64, f64)>,
    pub drv: Option<usize>,
    pub wl: Option<f64>,
    pub opens_shorts: Option<(usize, usize)>,
}
struct St {
    start: Instant,
    cpu0: f64,
    depth: usize,
    cmds: BTreeMap<String, CmdStat>,
    stages: Vec<StageQor>,
}
static ST: Mutex<Option<St>> = Mutex::new(None);
fn with<X>(f: impl FnOnce(&mut St) -> X) -> X {
    let mut g = ST.lock().unwrap_or_else(|e| e.into_inner());
    if g.is_none() { *g = Some(St { start: Instant::now(), cpu0: cpu_secs(), depth: 0, cmds: BTreeMap::new(), stages: vec![] }); }
    f(g.as_mut().unwrap())
}

/// flow commands: [begin] / [finish] lines and a stage QoR snapshot
pub const FLOW_CMDS: &[&str] = &[
    "compile", "compile_ultra", "compile_fusion", "synthesize", "syn_generic", "syn_map", "syn_opt", "initialize_floorplan", "create_floorplan", "place_opt", "place_detail", "legalize_placement", "create_placement",
    "clock_opt", "synthesize_clock_trees", "ccopt_design", "route_global", "route_auto", "route_detail", "route_eco", "route_opt", "opt_design", "optDesign", "place_opt_design", "routeDesign", "add_metal_fill",
    "extract_rc", "save_db", "restore_db", "insert_dft", "compile_power_domains", "optimize_wire_spreading", "insert_redundant_vias", "fix_net_length", "fix_antenna",
];
const QOR_CMDS: &[&str] = &[
    "compile", "compile_ultra", "compile_fusion", "synthesize", "syn_generic", "syn_map", "syn_opt", "place_opt", "place_detail", "clock_opt", "synthesize_clock_trees", "ccopt_design", "route_auto", "route_detail", "route_eco", "route_opt", "opt_design", "optDesign", "place_opt_design", "routeDesign", "restore_db", "insert_dft", "fix_net_length", "fix_antenna",
];

/// process CPU seconds (user + system), from /proc/self/stat
pub fn cpu_secs() -> f64 {
    let Ok(s) = std::fs::read_to_string("/proc/self/stat") else { return 0.0 };
    let Some(i) = s.rfind(')') else { return 0.0 };
    let f: Vec<&str> = s[i + 2..].split_whitespace().collect();
    let t = |k: usize| f.get(k).and_then(|v| v.parse::<f64>().ok()).unwrap_or(0.0);
    (t(11) + t(12)) / 100.0
}
/// (resident MB, peak resident MB)
pub fn mem_mb() -> (f64, f64) {
    let Ok(s) = std::fs::read_to_string("/proc/self/status") else { return (0.0, 0.0) };
    let g = |k: &str| s.lines().find(|l| l.starts_with(k)).and_then(|l| l.split_whitespace().nth(1)).and_then(|v| v.parse::<f64>().ok()).unwrap_or(0.0) / 1024.0;
    (g("VmRSS:"), g("VmHWM:"))
}
pub fn hms(s: f64) -> String {
    let t = s.max(0.0);
    let h = (t / 3600.0) as u64;
    let m = ((t - h as f64 * 3600.0) / 60.0) as u64;
    let sec = t - h as f64 * 3600.0 - m as f64 * 60.0;
    format!("{}:{:02}:{:04.1}", h, m, sec)
}
/// "2026-11-26 14:03:12 UTC"
pub fn now_stamp() -> String {
    let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0) as i64;
    let (days, rem) = (t.div_euclid(86400), t.rem_euclid(86400));
    // civil from days (H. Hinnant)
    let z = days + 719468;
    let era = z.div_euclid(146097);
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    format!("{:04}-{:02}-{:02} {:02}:{:02}:{:02} UTC", if m <= 2 { y + 1 } else { y }, m, d, rem / 3600, rem % 3600 / 60, rem % 60)
}
pub fn session_times() -> (f64, f64) { with(|s| (cpu_secs() - s.cpu0, s.start.elapsed().as_secs_f64())) }
fn ratio(c: f64, r: f64) -> f64 { if r > 1e-3 { c / r } else { 0.0 } }
pub fn init() { with(|_| ()); }

/// run header for the log
pub fn header() {
    let host = std::fs::read_to_string("/proc/sys/kernel/hostname").map(|s| s.trim().to_string()).or_else(|_| std::env::var("HOSTNAME")).unwrap_or_else(|_| "unknown".into());
    let user = std::env::var("USER").or_else(|_| std::env::var("LOGNAME")).ok().filter(|v| !v.is_empty()).unwrap_or_else(|| {
        // uid -> name from /etc/passwd
        let uid = std::fs::read_to_string("/proc/self/status").ok().and_then(|s| s.lines().find(|l| l.starts_with("Uid:")).and_then(|l| l.split_whitespace().nth(1).map(|x| x.to_string())));
        uid.and_then(|u| std::fs::read_to_string("/etc/passwd").ok().and_then(|p| p.lines().find(|l| l.split(':').nth(2) == Some(u.as_str())).and_then(|l| l.split(':').next().map(|x| x.to_string())))).unwrap_or_else(|| "unknown".into())
    });
    let os = std::fs::read_to_string("/proc/sys/kernel/osrelease").map(|s| format!("{} {}", std::env::consts::OS, s.trim())).unwrap_or_else(|_| std::env::consts::OS.to_string());
    let cpus = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1);
    let cwd = std::env::current_dir().map(|p| p.display().to_string()).unwrap_or_default();
    let args: Vec<String> = std::env::args().collect();
    let (rss, _) = mem_mb();
    crate::out!("@(#)RSynth {} ({}) — run started {}", env!("CARGO_PKG_VERSION"), std::env::consts::ARCH, now_stamp());
    crate::out!("@ Host: {}   User: {}   PID: {}   OS: {}   CPUs: {}", host, user, std::process::id(), os, cpus);
    crate::out!("@ Directory: {}", cwd);
    crate::out!("@ Command line: {}", args.join(" "));
    crate::out!("@ Run log: {}   Command log: {}   (set_log_filename / set_cmd_filename)", crate::log::log_path().unwrap_or_else(|| "(none)".into()), crate::log::cmd_path().unwrap_or_else(|| "(none)".into()));
    crate::out!("@ Memory at start: {:.1}M", rss);
}

fn tcl_quote(a: &str) -> String {
    if a.is_empty() { return "{}".into(); }
    if a.chars().any(|c| c.is_whitespace() || "{}[]$\";\\".contains(c)) {
        if a.chars().filter(|c| *c == '{').count() == a.chars().filter(|c| *c == '}').count() && !a.ends_with('\\') { format!("{{{}}}", a) } else { format!("\"{}\"", a.replace('\\', "\\\\").replace('"', "\\\"").replace('$', "\\$").replace('[', "\\[")) }
    } else { a.to_string() }
}

pub struct Tok { inc: bool, top: bool, t0: Instant, c0: f64, m0: f64, n: usize }

/// a command enters: user-level (top) commands go to the command log and get metrics; commands run
/// by another command's implementation (read_sdc, load_upf, ...) are nested and not logged
pub fn enter(name: &str, a: &[String]) -> Tok {
    // wrappers run their body at the user level
    let inc = !matches!(name, "foreach_in_collection" | "redirect");
    let top = with(|s| { let t = s.depth == 0; if inc { s.depth += 1; } t });
    if !top { return Tok { inc, top, t0: Instant::now(), c0: 0.0, m0: 0.0, n: 0 }; }
    let line = std::iter::once(name.to_string()).chain(a.iter().map(|x| tcl_quote(x))).collect::<Vec<_>>().join(" ");
    crate::log::command(&line);
    let n = with(|s| s.cmds.get(name).map(|c| c.count).unwrap_or(0) + 1);
    let (rss, _) = mem_mb();
    if FLOW_CMDS.contains(&name) {
        let (tc, tr) = session_times();
        crate::log::metric(&format!("*** {} #{} [begin] : totSession cpu/real = {}/{} ({:.1}), mem = {:.1}M", name, n, hms(tc), hms(tr), ratio(tc, tr), rss));
    }
    Tok { inc, top, t0: Instant::now(), c0: cpu_secs(), m0: rss, n }
}

/// the command left: records it and prints the [finish] (and stage [metrics]) line
pub fn leave(sess: &mut Session, name: &str, tok: Tok, ok: bool) {
    if tok.inc { with(|s| s.depth = s.depth.saturating_sub(1)); }
    if !tok.top || !tok.inc { return; }
    let (t0, c0, m0, n) = (tok.t0, tok.c0, tok.m0, tok.n);
    let real = t0.elapsed().as_secs_f64();
    let cpu = (cpu_secs() - c0).max(0.0);
    let (rss, peak) = mem_mb();
    with(|s| {
        let e = s.cmds.entry(name.to_string()).or_default();
        e.count += 1;
        e.real += real;
        e.cpu += cpu;
        e.mem_delta += rss - m0;
        e.peak = e.peak.max(peak);
    });
    let flow = FLOW_CMDS.contains(&name);
    let min = sess.app.get("run_metrics.min_time").and_then(|v| v.parse::<f64>().ok()).unwrap_or(1.0);
    if !(flow || real >= min) || sess.app.get("run_metrics.enable").map(|v| v == "false" || v == "0").unwrap_or(false) { return; }
    let (tc, tr) = session_times();
    crate::log::metric(&format!("*** {} #{} [finish]{} : cpu/real = {}/{} ({:.1}), totSession cpu/real = {}/{} ({:.1}), mem = {:.1}M (peak {:.1}M, {:+.1}M)", name, n, if ok { "" } else { " (error)" }, hms(cpu), hms(real), ratio(cpu, real), hms(tc), hms(tr), ratio(tc, tr), rss, peak, rss - m0));
    if ok && QOR_CMDS.contains(&name) && !sess.app.get("run_metrics.qor").map(|v| v == "false" || v == "0").unwrap_or(false) {
        // the snapshot's own analysis is not part of the command (depth guard)
        with(|s| s.depth += 1);
        let q = sess.stage_qor(name, n, real, cpu, rss);
        with(|s| s.depth -= 1);
        crate::log::metric(&qor_line(&q));
        with(|s| s.stages.push(q));
    }
}

fn qor_line(q: &StageQor) -> String {
    let mut s = format!("*** {} #{} [metrics] : cells {}  area {:.1}", q.cmd, q.n, q.cells, q.area);
    if let Some(u) = q.util { s += &format!("  util {:.1}%", u * 100.0); }
    if let Some((w, t)) = q.setup { s += &format!("  setup WNS {:.4} TNS {:.4}", w, t); }
    if let Some((w, t)) = q.hold { s += &format!("  hold WNS {:.4} TNS {:.4}", w, t); }
    if let Some(d) = q.drv { s += &format!("  DRV {}", d); }
    if let Some(w) = q.wl { s += &format!("  wirelength {:.1}um", w); }
    if let Some((o, sh)) = q.opens_shorts { s += &format!("  opens {} shorts {}", o, sh); }
    s
}

/// session summary and the Ending line (end of run)
pub fn finish(sess: &mut Session) {
    if !sess.app.get("run_metrics.enable").map(|v| v == "false" || v == "0").unwrap_or(false) {
        print_report(10, false);
    }
    let (tc, tr) = session_times();
    let (rss, peak) = mem_mb();
    crate::out!("--- Ending \"RSynth\" (totcpu={}, real={}, mem={:.1}M, peak={:.1}M) ---", hms(tc), hms(tr), rss, peak);
    crate::log::flush();
}

fn print_report(top: usize, stages_all: bool) -> usize {
    let (cmds, stages) = with(|s| (s.cmds.clone(), s.stages.clone()));
    let (tc, tr) = session_times();
    let (rss, peak) = mem_mb();
    crate::out!("\n****************************************\nReport : run_metrics\n****************************************");
    crate::out!("  Session    : cpu {}  real {}  ({:.1})  mem {:.1}M  peak {:.1}M", hms(tc), hms(tr), ratio(tc, tr), rss, peak);
    let mut v: Vec<(String, CmdStat)> = cmds.into_iter().collect();
    v.sort_by(|a, b| b.1.real.partial_cmp(&a.1.real).unwrap().then(a.0.cmp(&b.0)));
    let total: f64 = v.iter().map(|x| x.1.real).sum();
    crate::out!("  {:<28} {:>6} {:>12} {:>12} {:>7} {:>10} {:>10}", "command", "calls", "cpu", "real", "real%", "mem +/-M", "peak M");
    for (n, c) in v.iter().take(top) {
        crate::out!("  {:<28} {:>6} {:>12} {:>12} {:>6.1}% {:>+10.1} {:>10.1}", n, c.count, hms(c.cpu), hms(c.real), 100.0 * c.real / total.max(1e-9), c.mem_delta, c.peak);
    }
    if v.len() > top { crate::out!("  ... {} more command(s)", v.len() - top); }
    if !stages.is_empty() {
        crate::out!("  Stage QoR:");
        crate::out!("  {:<22} {:>10} {:>8} {:>10} {:>7} {:>10} {:>10} {:>9} {:>9} {:>6} {:>11} {:>8}", "stage", "real", "cells", "area", "util", "setupWNS", "setupTNS", "holdWNS", "holdTNS", "DRV", "wire um", "op/sh");
        let sel: Vec<&StageQor> = if stages_all || stages.len() <= 20 { stages.iter().collect() } else { stages.iter().skip(stages.len() - 20).collect() };
        for q in sel {
            let o = |v: Option<(f64, f64)>, k: usize| v.map(|x| format!("{:.4}", if k == 0 { x.0 } else { x.1 })).unwrap_or("-".into());
            crate::out!("  {:<22} {:>10} {:>8} {:>10.1} {:>7} {:>10} {:>10} {:>9} {:>9} {:>6} {:>11} {:>8}", format!("{} #{}", q.cmd, q.n), hms(q.real), q.cells, q.area, q.util.map(|u| format!("{:.1}%", u * 100.0)).unwrap_or("-".into()), o(q.setup, 0), o(q.setup, 1), o(q.hold, 0), o(q.hold, 1), q.drv.map(|d| d.to_string()).unwrap_or("-".into()), q.wl.map(|w| format!("{:.1}", w)).unwrap_or("-".into()), q.opens_shorts.map(|x| format!("{}/{}", x.0, x.1)).unwrap_or("-".into()));
        }
    }
    v.len()
}

impl Session {
    pub(crate) fn stage_qor(&mut self, cmd: &str, n: usize, real: f64, cpu: f64, mem: f64) -> StageQor {
        let (cells, area) = match self.nl.as_ref() {
            Some(nl) => {
                let ids = nl.cell_ids();
                let a: f64 = ids.iter().filter_map(|c| nl.cell(*c).lib()).filter_map(|l| self.libs.iter().find_map(|lb| lb.cells.get(l)).map(|lc| lc.area)).sum();
                (ids.len(), a)
            }
            None => (0, 0.0),
        };
        let util = self.fp.as_ref().map(|f| { let c = f.core.unwrap_or(f.die); let ca = ((c.2 - c.0) * (c.3 - c.1)).max(1e-9); area / ca });
        let (mut setup, mut hold, mut drv) = (None, None, None);
        if self.nl.is_some() && !self.libs.is_empty() && !self.scens.is_empty() {
            if let Ok(q) = self.with_env(|nl, env| { let a = env.analyze(nl, 0); (a.wns, a.tns, a.whs, a.ths, a.drv.iter().map(|d| d.1).sum::<usize>()) }) {
                setup = Some((q.0, q.1));
                hold = Some((q.2, q.3));
                drv = Some(q.4);
            }
        }
        let (wl, os) = match self.routes.as_ref() {
            Some(db) => { let st = crate::droute::stats(db); (Some(st.wl), Some((st.opens, st.shorts))) }
            None => (None, None),
        };
        StageQor { cmd: cmd.to_string(), n, real, cpu, mem, cells, area, util: if self.fp.is_some() { util } else { None }, setup, hold, drv, wl, opens_shorts: os }
    }

    pub(crate) fn metrics_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            // name the run log (default rsynth.run.log); the current log moves there with its contents
            "set_log_filename" | "set_log_file" | "setLogFileName" => {
                let Some(f) = a.iter().find(|x| !x.starts_with('-')) else { return Some(err(format!("{} <file.log>", name))) };
                match crate::log::set_log_path(f) {
                    Ok(old) => { crate::info!("LOG-100", "Run log is now '{}'{}", f, old.map(|o| format!(" (moved from '{}')", o)).unwrap_or_default()); Ok(f.clone()) }
                    Err(e) => err(format!("{}: {} (LOG-101)", name, e)),
                }
            }
            // name the command log (default rsynth.cmd.log); the current log moves there with its contents
            "set_cmd_filename" | "set_cmd_file" | "setCmdFileName" => {
                let Some(f) = a.iter().find(|x| !x.starts_with('-')) else { return Some(err(format!("{} <file.cmd>", name))) };
                match crate::log::set_cmd_path(f) {
                    Ok(old) => { crate::info!("LOG-102", "Command log is now '{}'{}", f, old.map(|o| format!(" (moved from '{}')", o)).unwrap_or_default()); Ok(f.clone()) }
                    Err(e) => err(format!("{}: {} (LOG-103)", name, e)),
                }
            }
            // current run log file
            "get_log_filename" | "getLogFileName" => Ok(crate::log::log_path().unwrap_or_default()),
            // current command log file
            "get_cmd_filename" | "getCmdFileName" => Ok(crate::log::cmd_path().unwrap_or_default()),
            // per-command cpu / real time / memory and the stage QoR history of this session
            "report_run_metrics" | "report_runtime" | "report_resource" | "report_resources" => {
                let x = args(a, &["-top", "-file"]);
                let top = x.num("-top").map(|v| v as usize).unwrap_or(30);
                if let Some(f) = x.get("-file") {
                    crate::log::push_redirect();
                    let n = print_report(top, true);
                    let s = crate::log::pop_redirect();
                    if let Err(e) = std::fs::write(f, s) { return Some(err(format!("{}: {}", name, e))); }
                    Ok(n.to_string())
                } else {
                    Ok(print_report(top, x.has("-all")).to_string())
                }
            }
            // session cpu, real time, memory or peak memory, or a command's totals
            "get_run_metric" => {
                let Some(k) = a.first() else { return Some(err("get_run_metric cpu|real|mem|peak|<command>")) };
                let (tc, tr) = session_times();
                let (rss, peak) = mem_mb();
                Ok(match k.as_str() {
                    "cpu" => format!("{:.3}", tc),
                    "real" => format!("{:.3}", tr),
                    "mem" => format!("{:.1}", rss),
                    "peak" => format!("{:.1}", peak),
                    c => with(|s| s.cmds.get(c).map(|x| format!("{} {:.3} {:.3}", x.count, x.cpu, x.real)).unwrap_or_else(|| "0 0 0".into())),
                })
            }
            // clear the run-metrics statistics
            "reset_run_metrics" => { with(|s| { s.cmds.clear(); s.stages.clear(); }); Ok(String::new()) }
            _ => return self.odb_cmd(name, a),
        })
    }
}
