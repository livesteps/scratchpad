//! Minimal JSON reader for the GUI state (gui.rs state document).

#[derive(Clone, Debug, PartialEq)]
pub enum J {
    Null,
    Bool(bool),
    Num(f64),
    Str(String),
    Arr(Vec<J>),
    Obj(Vec<(String, J)>),
}

pub static NULL: J = J::Null;

impl J {
    pub fn parse(s: &str) -> Result<J, String> {
        let b = s.as_bytes();
        let mut i = 0;
        let v = val(b, &mut i)?;
        ws(b, &mut i);
        if i != b.len() { return Err(format!("trailing data at {}", i)); }
        Ok(v)
    }
    pub fn get(&self, k: &str) -> &J {
        match self { J::Obj(v) => v.iter().find(|e| e.0 == k).map(|e| &e.1).unwrap_or(&NULL), _ => &NULL }
    }
    pub fn at(&self, i: usize) -> &J {
        match self { J::Arr(v) => v.get(i).unwrap_or(&NULL), _ => &NULL }
    }
    pub fn arr(&self) -> &[J] {
        match self { J::Arr(v) => v, _ => &[] }
    }
    pub fn f(&self) -> f64 {
        match self { J::Num(n) => *n, J::Bool(b) => *b as i32 as f64, _ => 0.0 }
    }
    pub fn i(&self) -> i64 { self.f() as i64 }
    pub fn s(&self) -> &str {
        match self { J::Str(s) => s, _ => "" }
    }
    pub fn b(&self) -> bool {
        match self { J::Bool(b) => *b, J::Num(n) => *n != 0.0, _ => false }
    }
    pub fn is_null(&self) -> bool { matches!(self, J::Null) }
    /// [x0,y0,x1,y1]
    pub fn rect(&self) -> Option<(f64, f64, f64, f64)> {
        let a = self.arr();
        if a.len() >= 4 { Some((a[0].f(), a[1].f(), a[2].f(), a[3].f())) } else { None }
    }
}

fn ws(b: &[u8], i: &mut usize) {
    while *i < b.len() && (b[*i] as char).is_ascii_whitespace() { *i += 1; }
}

fn val(b: &[u8], i: &mut usize) -> Result<J, String> {
    ws(b, i);
    if *i >= b.len() { return Err("unexpected end".into()); }
    match b[*i] {
        b'{' => {
            *i += 1;
            let mut v = vec![];
            ws(b, i);
            if b.get(*i) == Some(&b'}') { *i += 1; return Ok(J::Obj(v)); }
            loop {
                ws(b, i);
                let k = match val(b, i)? { J::Str(s) => s, _ => return Err(format!("key expected at {}", i)) };
                ws(b, i);
                if b.get(*i) != Some(&b':') { return Err(format!("':' expected at {}", i)); }
                *i += 1;
                let x = val(b, i)?;
                v.push((k, x));
                ws(b, i);
                match b.get(*i) { Some(b',') => *i += 1, Some(b'}') => { *i += 1; return Ok(J::Obj(v)); } _ => return Err(format!("',' or '}}' expected at {}", i)) }
            }
        }
        b'[' => {
            *i += 1;
            let mut v = vec![];
            ws(b, i);
            if b.get(*i) == Some(&b']') { *i += 1; return Ok(J::Arr(v)); }
            loop {
                v.push(val(b, i)?);
                ws(b, i);
                match b.get(*i) { Some(b',') => *i += 1, Some(b']') => { *i += 1; return Ok(J::Arr(v)); } _ => return Err(format!("',' or ']' expected at {}", i)) }
            }
        }
        b'"' => {
            *i += 1;
            let mut s: Vec<u8> = vec![];
            while *i < b.len() && b[*i] != b'"' {
                if b[*i] == b'\\' {
                    *i += 1;
                    match b.get(*i) {
                        Some(b'n') => s.push(b'\n'),
                        Some(b't') => s.push(b'\t'),
                        Some(b'r') => s.push(b'\r'),
                        Some(b'u') => {
                            let h = std::str::from_utf8(&b[*i + 1..(*i + 5).min(b.len())]).unwrap_or("0");
                            let c = u32::from_str_radix(h, 16).ok().and_then(char::from_u32).unwrap_or('?');
                            let mut t = [0u8; 4];
                            s.extend_from_slice(c.encode_utf8(&mut t).as_bytes());
                            *i += 4;
                        }
                        Some(c) => s.push(*c),
                        None => {}
                    }
                } else {
                    s.push(b[*i]);
                }
                *i += 1;
            }
            *i += 1;
            Ok(J::Str(String::from_utf8_lossy(&s).to_string()))
        }
        b't' => { *i += 4; Ok(J::Bool(true)) }
        b'f' => { *i += 5; Ok(J::Bool(false)) }
        b'n' => { *i += 4; Ok(J::Null) }
        _ => {
            let st = *i;
            while *i < b.len() && (b[*i] == b'-' || b[*i] == b'+' || b[*i] == b'.' || b[*i] == b'e' || b[*i] == b'E' || b[*i].is_ascii_digit()) { *i += 1; }
            std::str::from_utf8(&b[st..*i]).ok().and_then(|t| t.parse().ok()).map(J::Num).ok_or_else(|| format!("bad value at {}", st))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn parse_state_like() {
        let j = J::parse(r#"{"die":[0,0,10.5,20],"cells":[["a/b",1,2,0.5,"c",0,1,-1]],"x":null,"t":true,"s":"q\"<"}"#).unwrap();
        assert_eq!(j.get("die").rect(), Some((0.0, 0.0, 10.5, 20.0)));
        assert_eq!(j.get("cells").at(0).at(0).s(), "a/b");
        assert_eq!(j.get("cells").at(0).at(7).i(), -1);
        assert!(j.get("x").is_null() && j.get("t").b());
        assert_eq!(j.get("s").s(), "q\"<");
    }
}
