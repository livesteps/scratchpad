//! Power / ground planning, special routing, via generation, non-default routing rules and
//! physical verification markers (Innovus-style commands; legacy camelCase names accepted):
//!
//!  connect_global_net / globalNetConnect   net -type pg_pin|pgpin|tiehi|tielo -pin_base_name|-pin p
//!                                          [-inst_base_name|-inst pats] [-module m] [-override]
//!  report_global_net_connections [-verbose], clear_global_net_connections
//!  add_rings / addRing          -nets {..} [-type core_rings|block_rings] [-around core|each_block|selected]
//!                               [-blocks pats] -layer {top L bottom L left L right L} -width w|{..}
//!                               [-spacing s] [-offset o] [-center]
//!  add_stripes / addStripe      -nets {..} -layer L -direction vertical|horizontal -width w [-spacing s]
//!                               [-set_to_set_distance d] [-start_offset o | -start x] [-stop_offset o]
//!                               [-number_of_sets n] [-area {..}] [-extend_to core|first_ring|design_boundary]
//!  create_followpins / create_rails   -nets {VDD VSS} [-layer M1] [-width w] [-extend_to core|ring] [-area {..}]
//!  sroute / route_special       -connect {core_pin block_pin pad_pin} -nets {..} [-strap_width w] [-strap_pitch p]
//!  generate_vias / generateVias / editPowerVia -add_vias 1 / update_power_vias -add_vias 1
//!                               [-nets {..}] [-bottom_layer L] [-top_layer L] [-area {..}]
//!  delete_power_vias / editPowerVia -delete_vias 1, delete_pg_shapes [-nets] [-shape kinds]
//!  add_special_wire -net n -layer L -width w -points {x y ...} | -rect {..}   delete_special_wire -net n -area {..}
//!  report_power_routes
//!  check_missing_vias / verifyPowerVia / check_power_vias  [-nets] [-error n]
//!  check_drc / verify_drc       [-limit n] [-area {..}] [-layer L]
//!  check_lvs / verify_connectivity  [-shorts] [-connectivity|-opens] [-nets pats] [-type all|regular|special]
//!  report_markers [-tool t] [-limit n], delete_markers / clear_drc [-tool t]
//!  write_markers -format calibre|text|json -output f [-tool t], read_markers [-format calibre] file
//!  create_route_rule / add_ndr  -name N [-preset 1w1s|1w2s|2w1s|2w2s] [-width_multiplier m | -widths {L w ..}]
//!                               [-spacing_multiplier m | -spacings {L s ..}]
//!  set_route_attributes / setAttribute  -nets pats|-net n | -clock_nets  -route_rule|-non_default_rule R [-reset]
//!  report_route_rules / report_ndr, delete_route_rule / delete_ndr

use crate::lef::ViaRule;
use crate::netlist::*;
use crate::phys::{SpecialShape, ViaArr};
use crate::session::{args, Session};
use crate::tcl::{err, split_list, Flow, R};
use std::collections::{BTreeMap, HashMap, HashSet};

type Rect = (f64, f64, f64, f64);
const EPS: f64 = 1e-6;

#[derive(Clone, Debug, Default)]
pub struct GConn {
    pub net: String,
    pub kind: String, // pgpin | tiehi | tielo
    pub pin: String,
    pub inst: String,
    pub module: String,
    pub over: bool,
}

#[derive(Clone, Debug, Default)]
pub struct Ndr {
    pub name: String,
    pub wmul: f64,
    pub smul: f64,
    pub widths: BTreeMap<String, f64>,
    pub spacings: BTreeMap<String, f64>,
}
impl Ndr {
    /// grid halo (neighbour tracks the rule takes) in the router
    /// (half the wider wire + the wider spacing) in tracks of (width + spacing), less the own track
    pub fn halo(&self) -> u8 { ((((self.wmul.max(1.0) + 1.0) / 4.0 + self.smul.max(1.0) / 2.0) - 1e-9).ceil() as i64 - 1).clamp(0, 3) as u8 }
}

#[derive(Clone, Debug, Default)]
pub struct Marker {
    pub tool: String,
    pub kind: String,
    pub layer: String,
    pub rect: Rect,
    pub nets: Vec<String>,
    pub msg: String,
}

#[derive(Clone, Debug, Default)]
pub struct PgState {
    pub gconn: Vec<GConn>,
    pub via_rules: Vec<ViaRule>,
    pub ndrs: Vec<Ndr>,
    /// net name (or "__clock__") -> rule
    pub net_ndr: BTreeMap<String, String>,
    pub markers: Vec<Marker>,
}

pub fn is_pg_kind(k: &str) -> bool { matches!(k, "ring" | "block_ring" | "stripe" | "followpin" | "strap" | "pg_wire" | "pg_via" | "RING" | "STRIPE" | "FOLLOWPIN") }

fn parse_rect(s: &str) -> Option<Rect> {
    let v: Vec<f64> = s.replace(['{', '}'], " ").split_whitespace().filter_map(|x| x.parse().ok()).collect();
    if v.len() < 4 { return None; }
    Some((v[0].min(v[2]), v[1].min(v[3]), v[0].max(v[2]), v[1].max(v[3])))
}
fn inter(a: Rect, b: Rect) -> Option<Rect> {
    let r = (a.0.max(b.0), a.1.max(b.1), a.2.min(b.2), a.3.min(b.3));
    if r.2 > r.0 + EPS && r.3 > r.1 + EPS { Some(r) } else { None }
}
fn touch(a: Rect, b: Rect) -> bool { a.0 <= b.2 + EPS && b.0 <= a.2 + EPS && a.1 <= b.3 + EPS && b.1 <= a.3 + EPS }
fn gap(a: Rect, b: Rect) -> f64 {
    let dx = (b.0 - a.2).max(a.0 - b.2).max(0.0);
    let dy = (b.1 - a.3).max(a.1 - b.3).max(0.0);
    (dx * dx + dy * dy).sqrt()
}
fn grow(r: Rect, d: f64) -> Rect { (r.0 - d, r.1 - d, r.2 + d, r.3 + d) }
fn subtract(r: Rect, holes: &[Rect], horiz: bool) -> Vec<Rect> {
    // cut a wire along its length by the holes it crosses
    let mut segs = vec![r];
    for h in holes {
        let mut out = vec![];
        for s in segs {
            match inter(s, *h) {
                None => out.push(s),
                Some(_) => {
                    if horiz {
                        if h.0 > s.0 + EPS { out.push((s.0, s.1, h.0, s.3)); }
                        if h.2 < s.2 - EPS { out.push((h.2, s.1, s.2, s.3)); }
                    } else {
                        if h.1 > s.1 + EPS { out.push((s.0, s.1, s.2, h.1)); }
                        if h.3 < s.3 - EPS { out.push((s.0, h.3, s.2, s.3)); }
                    }
                }
            }
        }
        segs = out;
    }
    segs
}
/// "M1:M6" ranges and plain names, from the routing layer order
fn expand_layers(spec: &str, order: &[String]) -> Vec<String> {
    if let Some((a, b)) = spec.split_once(':') {
        let (i, j) = (order.iter().position(|x| x == a), order.iter().position(|x| x == b));
        if let (Some(i), Some(j)) = (i, j) { return order[i.min(j)..=i.max(j)].to_vec(); }
    }
    vec![spec.to_string()]
}

impl Session {
    pub fn pg_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "connect_global_net" | "globalNetConnect" | "global_net_connect" => self.c_gconn(a),
            "report_global_net_connections" | "report_global_connections" | "report_pg_connections" => self.c_report_gconn(a),
            "clear_global_net_connections" | "clearGlobalNets" => { self.pgx.gconn.clear(); crate::info!("PG-012", "Global net connections cleared"); Ok(String::new()) }
            "add_rings" | "addRing" | "add_ring" => self.c_add_rings(a),
            "add_stripes" | "addStripe" | "add_stripe" => self.c_add_stripes(a),
            "create_followpins" | "create_rails" | "add_followpins" | "addFollowPins" => self.c_followpins(a),
            "sroute" | "route_special" => self.c_sroute(a),
            "generate_vias" | "generateVias" | "add_power_vias" => self.c_gen_vias(a),
            "editPowerVia" | "update_power_vias" | "edit_power_via" => {
                let x = args(a, &["-add_vias", "-delete_vias"]);
                if x.get("-delete_vias").map(|v| v == "1" || v == "true").unwrap_or(false) { self.c_del_vias(a) } else { self.c_gen_vias(a) }
            }
            "delete_power_vias" => self.c_del_vias(a),
            "delete_pg_shapes" | "delete_power_routes" | "delete_special_routes" => self.c_del_pg(a),
            "add_special_wire" | "add_shape" | "add_pg_wire" => self.c_add_special_wire(a),
            "delete_special_wire" | "delete_shape" => self.c_del_special_wire(a),
            "report_power_routes" | "report_pg" | "report_special_routes" => self.c_report_pg(),
            "check_missing_vias" | "verifyPowerVia" | "verify_power_via" | "check_power_vias" => self.c_missing_vias(a),
            "check_drc" | "verify_drc" | "verifyGeometry" => self.c_check_drc(a),
            "check_lvs" | "verify_connectivity" | "verifyConnectivity" => self.c_check_lvs(a),
            "report_markers" | "report_drc_markers" => self.c_report_markers(a),
            "delete_markers" | "clear_drc" | "clearDrc" | "delete_drc_markers" => {
                let x = args(a, &["-tool"]);
                let t = x.get("-tool").cloned();
                let n0 = self.pgx.markers.len();
                self.pgx.markers.retain(|m| t.as_ref().map(|t| t != "all" && t != &m.tool).unwrap_or(false));
                crate::info!("PG-500", "Deleted {} marker(s)", n0 - self.pgx.markers.len());
                Ok((n0 - self.pgx.markers.len()).to_string())
            }
            "write_markers" | "write_drc_markers" | "export_markers" => self.c_write_markers(a),
            "read_markers" | "load_markers" | "import_markers" => self.c_read_markers(a),
            "create_route_rule" | "add_ndr" | "create_ndr" => self.c_add_ndr(a),
            "set_route_attributes" | "setAttribute" | "set_route_rule" | "assign_ndr" => self.c_set_ndr(a),
            "report_route_rules" | "report_ndr" | "report_ndrs" => self.c_report_ndr(),
            "delete_route_rule" | "delete_ndr" => {
                let x = args(a, &["-name"]);
                let n = x.get("-name").cloned().or(x.pos.first().cloned()).unwrap_or_default();
                self.pgx.ndrs.retain(|r| r.name != n);
                self.pgx.net_ndr.retain(|_, r| r != &n);
                crate::info!("PG-412", "Route rule '{}' deleted", n);
                Ok(n)
            }
            _ => return None,
        })
    }

    // ------------------------------------------------------------------ helpers
    fn fp_req(&self) -> Result<&crate::phys::Floorplan, Flow> { self.fp.as_ref().ok_or_else(|| Flow::Err("No floorplan: initialize_floorplan or read_def first (FP-001)".into())) }
    /// routing layer names bottom-up
    pub(crate) fn metal_order(&self) -> Vec<String> {
        let mut v: Vec<String> = self.fp.as_ref().map(|f| f.layers.iter().map(|l| l.name.clone()).collect()).unwrap_or_default();
        for l in &self.lef_layers { if l.kind.eq_ignore_ascii_case("ROUTING") && !v.contains(&l.name) { v.push(l.name.clone()); } }
        v
    }
    fn layer_horiz(&self, l: &str) -> bool {
        if let Some(x) = self.fp.as_ref().and_then(|f| f.layers.iter().find(|q| q.name == l)) { return x.horiz; }
        self.lef_layers.iter().find(|q| q.name == l).map(|q| q.dir.to_uppercase().starts_with('H')).unwrap_or(true)
    }
    pub(crate) fn min_width(&self, l: &str) -> f64 { self.lef_layers.iter().find(|q| q.name == l).map(|q| q.width).filter(|w| *w > 0.0).unwrap_or(0.1) }
    pub(crate) fn min_space(&self, l: &str) -> f64 { self.lef_layers.iter().find(|q| q.name == l).map(|q| if q.spacing > 0.0 { q.spacing } else { q.width }).filter(|w| *w > 0.0).unwrap_or(0.1) }
    /// via rule between two adjacent layers (LEF VIARULE GENERATE, or a default one)
    fn via_rule(&self, lo: &str, hi: &str) -> ViaRule {
        if let Some(r) = self.pgx.via_rules.iter().find(|r| (r.lower == lo && r.upper == hi) || (r.lower == hi && r.upper == lo)) { return r.clone(); }
        let w = self.min_width(hi).max(self.min_width(lo));
        ViaRule { name: format!("{}_{}_DEF", lo, hi), lower: lo.into(), cut: format!("V{}{}", lo, hi), upper: hi.into(), cut_w: w * 0.7, cut_h: w * 0.7, sp_x: w * 1.4, sp_y: w * 1.4, enc_lo: (w * 0.3, w * 0.3), enc_hi: (w * 0.3, w * 0.3) }
    }
    pub(crate) fn pg_nets(&self) -> Vec<String> {
        let mut v: Vec<String> = self.pgx.gconn.iter().filter(|g| g.kind == "pgpin").map(|g| g.net.clone()).collect();
        if let Some(fp) = &self.fp { for s in &fp.special { if is_pg_kind(&s.kind) && !v.contains(&s.net) { v.push(s.net.clone()); } } }
        v.dedup();
        v
    }
    fn shape_rect(s: &SpecialShape) -> Rect { s.rect.unwrap_or_else(|| s.bbox()) }
    fn push_shape(&mut self, name: String, net: &str, layer: &str, kind: &str, r: Rect) {
        let fp = self.fp.as_mut().unwrap();
        fp.special.push(SpecialShape { name, net: net.into(), layer: layer.into(), kind: kind.into(), width: (r.2 - r.0).min(r.3 - r.1), pts: vec![(r.0, r.1), (r.2, r.3)], rect: Some(r), via: None });
    }
    fn macros_placed(&self) -> Vec<(String, Rect, Vec<String>)> {
        let mut v = vec![];
        let Some(nl) = self.nl.as_ref() else { return v };
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            let Some(m) = crate::lef::phys(&self.lef, cl) else { continue };
            if !m.is_block() { continue; }
            if let Some(r) = crate::lef::cell_rect(&self.lef, cl) {
                let mut obs: Vec<String> = m.obs.iter().map(|o| o.0.clone()).collect();
                obs.sort();
                obs.dedup();
                v.push((cl.name.clone(), r, obs));
            }
        }
        v
    }
    /// PG pins of an instance resolved through the global connections: (pin, net, shapes)
    fn inst_pg_pins(&self, c: CellId) -> Vec<(String, String, Vec<(String, Rect)>)> {
        let nl = self.nl.as_ref().unwrap();
        let cl = nl.cell(c);
        let mut out = vec![];
        let m = crate::lef::phys(&self.lef, cl).or_else(|| cl.lib().and_then(|l| self.lef.get(l)));
        let pins: Vec<(String, String)> = match m {
            Some(m) if m.pins.iter().any(|p| p.usage == "POWER" || p.usage == "GROUND") => m.pins.iter().filter(|p| p.usage == "POWER" || p.usage == "GROUND").map(|p| (p.name.clone(), p.usage.clone())).collect(),
            _ => vec![("VDD".into(), "POWER".into()), ("VSS".into(), "GROUND".into())], // standard cells: implicit rail pins
        };
        for (p, _) in pins {
            let mut net = None;
            for g in &self.pgx.gconn {
                if g.kind != "pgpin" || !glob(&g.pin, &p) || !glob(&g.inst, &cl.name) { continue; }
                if !g.module.is_empty() && !cl.name.starts_with(&format!("{}/", g.module)) { continue; }
                if net.is_none() || g.over { net = Some(g.net.clone()); }
            }
            if let Some(n) = net { out.push((p.clone(), n, crate::lef::pin_shapes(&self.lef, cl, &p))); }
        }
        out
    }

    // ------------------------------------------------------------------ global net connections
    fn c_gconn(&mut self, a: &[String]) -> R {
        let x = args(a, &["-type", "-pin", "-pin_base_name", "-inst", "-inst_base_name", "-module", "-net"]);
        let net = x.pos.first().cloned().or(x.get("-net").cloned()).ok_or_else(|| Flow::Err("connect_global_net: net name required (PG-001)".into()))?;
        let kind = match x.get("-type").map(|s| s.to_lowercase().replace('_', "")).as_deref() { Some("tiehi") => "tiehi", Some("tielo") => "tielo", Some("pgpin") | None => "pgpin", Some(o) => return err(&format!("connect_global_net: -type {} (pg_pin | tiehi | tielo) (PG-002)", o)) };
        let pin = x.get("-pin").or(x.get("-pin_base_name")).cloned().unwrap_or(if kind == "pgpin" { net.clone() } else { "*".into() });
        let inst = x.get("-inst").or(x.get("-inst_base_name")).cloned().unwrap_or("*".into());
        let g = GConn { net: net.clone(), kind: kind.into(), pin: pin.clone(), inst: inst.clone(), module: x.get("-module").cloned().unwrap_or_default(), over: x.has("-override") };
        self.pgx.gconn.push(g);
        // count what the rule connects
        let nl = self.nl()?;
        let mut n = 0;
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.is_hport() || matches!(cl.kind, Kind::Gen(_)) || !glob(&inst, &cl.name) { continue; }
            if kind == "pgpin" { if self.inst_pg_pins(c).iter().any(|p| p.1 == net && glob(&pin, &p.0)) { n += 1; } }
            else if cl.lib().and_then(|l| self.libs.iter().find_map(|q| q.cells.get(l))).map(|lc| lc.tie == Some(kind == "tiehi")).unwrap_or(false) { n += 1; }
        }
        crate::info!("PG-010", "Global net connection: {} pin '{}' of instances '{}'{} -> net {} ({} instance(s))", kind, pin, inst, if g_mod(&self.pgx.gconn) { " (module scope)" } else { "" }, net, n);
        Ok(n.to_string())
    }

    fn c_report_gconn(&mut self, a: &[String]) -> R {
        let verbose = a.iter().any(|x| x == "-verbose");
        let nl = self.nl()?;
        crate::out!("****************************************\nReport : global_net_connections\n****************************************");
        for g in &self.pgx.gconn { crate::out!("  {:<6} -type {:<6} -pin {:<8} -inst {}{}{}", g.net, g.kind, g.pin, g.inst, if g.module.is_empty() { String::new() } else { format!(" -module {}", g.module) }, if g.over { " -override" } else { "" }); }
        let mut per: BTreeMap<String, usize> = BTreeMap::new();
        let mut missing: Vec<String> = vec![];
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.is_hport() || matches!(cl.kind, Kind::Gen(_)) { continue; }
            let pins = self.inst_pg_pins(c);
            for p in &pins { *per.entry(p.1.clone()).or_default() += 1; }
            if pins.len() < 2 && cl.lib().and_then(|l| self.libs.iter().find_map(|q| q.cells.get(l))).map(|lc| lc.tie.is_none()).unwrap_or(true) { missing.push(format!("{} ({} PG pin(s) connected)", cl.name, pins.len())); }
        }
        for (n, k) in &per { crate::out!("  net {:<8} {} PG pin(s)", n, k); }
        crate::out!("  {} instance(s) with an unconnected PG pin", missing.len());
        if verbose { for m in missing.iter().take(100) { crate::out!("    {}", m); } }
        Ok(missing.len().to_string())
    }

    // ------------------------------------------------------------------ rings
    fn c_add_rings(&mut self, a: &[String]) -> R {
        let x = args(a, &["-nets", "-type", "-around", "-layer", "-layers", "-width", "-spacing", "-offset", "-blocks"]);
        let nets: Vec<String> = x.get("-nets").map(|s| split_list(s)).ok_or_else(|| Flow::Err("add_rings: -nets {VDD VSS} required (PG-100)".into()))?;
        let fp = self.fp_req()?.clone();
        let order = self.metal_order();
        // -layer {top M5 bottom M5 left M6 right M6} or {M5 M6}
        let lspec: Vec<String> = x.get("-layer").or(x.get("-layers")).map(|s| split_list(s)).unwrap_or_default();
        let side_val = |spec: &[String], side: &str, dflt: &str| -> String {
            if let Some(i) = spec.iter().position(|v| v == side) { return spec.get(i + 1).cloned().unwrap_or(dflt.into()); }
            match spec.len() { 0 => dflt.into(), 1 => spec[0].clone(), _ => if side == "top" || side == "bottom" { spec[0].clone() } else { spec[1].clone() } }
        };
        let hl = order.iter().rev().find(|l| self.layer_horiz(l)).cloned().unwrap_or("M5".into());
        let vl = order.iter().rev().find(|l| !self.layer_horiz(l)).cloned().unwrap_or("M6".into());
        let ly: HashMap<&str, String> = [("top", side_val(&lspec, "top", &hl)), ("bottom", side_val(&lspec, "bottom", &hl)), ("left", side_val(&lspec, "left", &vl)), ("right", side_val(&lspec, "right", &vl))].into_iter().collect();
        for l in ly.values() { if !order.contains(l) { return err(&format!("add_rings: unknown routing layer '{}' (PG-101)", l)); } }
        let wspec: Vec<String> = x.get("-width").map(|s| split_list(s)).unwrap_or_default();
        let wd = |side: &str| -> f64 { side_val(&wspec, side, "2.0").parse().unwrap_or(2.0) };
        let sp = x.get("-spacing").and_then(|s| split_list(s).last().and_then(|v| v.parse::<f64>().ok())).unwrap_or(1.0);
        let off = x.get("-offset").and_then(|s| split_list(s).last().and_then(|v| v.parse::<f64>().ok())).unwrap_or(1.0);
        let ty = x.get("-type").cloned().unwrap_or("core_rings".into());
        let around = x.get("-around").cloned().unwrap_or(if ty.starts_with("block") { "each_block".into() } else { "core".into() });
        let mut targets: Vec<(String, Rect)> = vec![];
        if ty.starts_with("core") && around != "each_block" && around != "selected" {
            let core = fp.core.unwrap_or(fp.place_region());
            targets.push(("core".into(), core));
        } else {
            let pats: Vec<String> = x.get("-blocks").map(|s| split_list(s)).unwrap_or_default();
            let sel: Vec<String> = self.selection.iter().filter_map(|h| crate::cons::Obj::parse(h).map(|o| o.name().to_string())).collect();
            for (n, r, _) in self.macros_placed() {
                let ok = if around == "selected" { sel.contains(&n) } else { pats.is_empty() || pats.iter().any(|p| glob(p, &n)) };
                if ok { targets.push((n, r)); }
            }
            if targets.is_empty() { return err("add_rings: no placed block matches (-blocks / -around selected) (PG-102)"); }
        }
        let nsets = nets.len() as f64;
        let wmax = ["top", "bottom", "left", "right"].iter().map(|s| wd(s)).fold(0.0, f64::max);
        let mut made = 0;
        for (tn, t) in &targets {
            // -center: centre the ring set in the core-to-die gap
            let off_eff = if x.has("-center") && tn == "core" {
                let gapv = (t.0 - fp.die.0).min(t.1 - fp.die.1).min(fp.die.2 - t.2).min(fp.die.3 - t.3);
                ((gapv - (nsets * wmax + (nsets - 1.0) * sp)) / 2.0).max(0.0)
            } else { off };
            for (i, n) in nets.iter().enumerate() {
                let d = off_eff + i as f64 * (wmax + sp);
                let (wt, wb, wl, wr) = (wd("top"), wd("bottom"), wd("left"), wd("right"));
                let outer = (t.0 - d - wl, t.1 - d - wb, t.2 + d + wr, t.3 + d + wt);
                let kind = if tn == "core" { "ring" } else { "block_ring" };
                let base = format!("{}_{}_{}", if tn == "core" { "ring".to_string() } else { format!("bring_{}", tn.replace('/', "_")) }, n, i);
                self.push_shape(format!("{}_top", base), n, &ly["top"], kind, (outer.0, outer.3 - wt, outer.2, outer.3));
                self.push_shape(format!("{}_bottom", base), n, &ly["bottom"], kind, (outer.0, outer.1, outer.2, outer.1 + wb));
                self.push_shape(format!("{}_left", base), n, &ly["left"], kind, (outer.0, outer.1, outer.0 + wl, outer.3));
                self.push_shape(format!("{}_right", base), n, &ly["right"], kind, (outer.2 - wr, outer.1, outer.2, outer.3));
                made += 4;
            }
        }
        crate::info!("PG-110", "add_rings: {} {} for {} around {} target(s) (top/bottom {}/{}, left/right {}/{}, width {}, spacing {}, offset {}): {} shape(s)",
            if ty.starts_with("block") { "block rings" } else { "core rings" }, nets.join(" "), nets.len(), targets.len(), ly["top"], ly["bottom"], ly["left"], ly["right"], wmax, sp, off, made);
        Ok(made.to_string())
    }

    // ------------------------------------------------------------------ stripes
    fn c_add_stripes(&mut self, a: &[String]) -> R {
        let x = args(a, &["-nets", "-layer", "-direction", "-width", "-spacing", "-set_to_set_distance", "-start_offset", "-start", "-stop_offset", "-stop", "-number_of_sets", "-area", "-extend_to", "-start_from"]);
        let nets: Vec<String> = x.get("-nets").map(|s| split_list(s)).ok_or_else(|| Flow::Err("add_stripes: -nets {..} required (PG-120)".into()))?;
        let layer = x.get("-layer").cloned().ok_or_else(|| Flow::Err("add_stripes: -layer required (PG-121)".into()))?;
        if !self.metal_order().contains(&layer) { return err(&format!("add_stripes: unknown routing layer '{}' (PG-122)", layer)); }
        let vert = match x.get("-direction").map(|s| s.to_lowercase()) { Some(d) => d.starts_with('v'), None => !self.layer_horiz(&layer) };
        let w = x.num("-width").unwrap_or(2.0);
        if w < self.min_width(&layer) - EPS { crate::warn!("PG-123", "add_stripes: width {} is below the {} minimum width {}", w, layer, self.min_width(&layer)); }
        let sp = x.num("-spacing").unwrap_or(1.0);
        let fp = self.fp_req()?.clone();
        let core = fp.core.unwrap_or(fp.place_region());
        let area = x.get("-area").and_then(|s| parse_rect(s)).unwrap_or(core);
        let set_w = nets.len() as f64 * w + (nets.len() as f64 - 1.0) * sp;
        let pitch = x.num("-set_to_set_distance").unwrap_or(set_w * 4.0).max(set_w + sp);
        let (lo, hi) = if vert { (area.0, area.2) } else { (area.1, area.3) };
        let start = x.num("-start").unwrap_or(lo + x.num("-start_offset").unwrap_or(pitch / 2.0 - set_w / 2.0));
        let stop = x.num("-stop").unwrap_or(hi - x.num("-stop_offset").unwrap_or(0.0));
        let maxn = x.num("-number_of_sets").map(|v| v as usize).unwrap_or(usize::MAX);
        // horizontal stripes sit on the row boundaries of their own net (followpin positions), so
        // the rail-to-stripe via stacks are not blocked by the other net's stripe
        let rails: Vec<(f64, String)> = if !vert && nets.len() >= 2 && !x.has("-no_snap") {
            let pw = nets.iter().find(|n| { let u = n.to_uppercase(); u.contains("VDD") || u.contains("PWR") }).cloned().unwrap_or(nets[0].clone());
            let gd = nets.iter().find(|n| **n != pw).cloned().unwrap();
            let mut v = vec![];
            for r in self.row_segments().unwrap_or_default() {
                let fs = r.orient.contains('S');
                v.push((r.y, if fs { pw.clone() } else { gd.clone() }));
                v.push((r.y + r.height, if fs { gd.clone() } else { pw.clone() }));
            }
            v.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
            v.dedup_by(|a, b| (a.0 - b.0).abs() < 1e-6);
            v
        } else { vec![] };
        let snap = |c: f64, n: &str| -> f64 {
            rails.iter().filter(|r| r.1 == n).map(|r| r.0 - w / 2.0).min_by(|a, b| (a - c).abs().partial_cmp(&(b - c).abs()).unwrap()).unwrap_or(c)
        };
        // along the stripe: the area, or extended to the rings / die
        let ext = x.get("-extend_to").cloned().unwrap_or("core".into());
        let ring_span = |net: &str| -> Option<Rect> {
            let v: Vec<Rect> = fp.special.iter().filter(|s| s.net == net && s.kind == "ring").map(Self::shape_rect).collect();
            if v.is_empty() { return None; }
            Some(v.iter().fold((f64::MAX, f64::MAX, f64::MIN, f64::MIN), |b, r| (b.0.min(r.0), b.1.min(r.1), b.2.max(r.2), b.3.max(r.3))))
        };
        // block obstruction: stripes on a layer the macro obstructs are broken around it
        let holes: Vec<Rect> = self.macros_placed().into_iter().filter(|m| m.2.contains(&layer)).map(|m| grow(m.1, sp)).collect();
        let lsp = self.min_space(&layer);
        let others: Vec<(String, Rect)> = fp.special.iter().filter(|s| s.layer == layer && is_pg_kind(&s.kind) && s.kind != "pg_via").map(|s| (s.net.clone(), Self::shape_rect(s))).collect();
        let mut made = 0;
        let mut k = 0;
        let mut p = start;
        while p + set_w <= stop + EPS && k < maxn {
            let mut prev_end = f64::MIN;
            for (i, n) in nets.iter().enumerate() {
                let mut c0 = p + i as f64 * (w + sp);
                if !rails.is_empty() {
                    let s0 = snap(c0, n);
                    // keep the spacing to the previous stripe of the set
                    c0 = if s0 >= prev_end + sp - EPS { s0 } else { rails.iter().filter(|r| &r.1 == n && r.0 - w / 2.0 >= prev_end + sp - EPS).map(|r| r.0 - w / 2.0).fold(f64::MAX, f64::min).min(stop) };
                }
                prev_end = c0 + w;
                let (a0, a1) = match (ext.as_str(), ring_span(n)) {
                    ("first_ring" | "ring", Some(rs)) => if vert { (rs.1, rs.3) } else { (rs.0, rs.2) },
                    ("design_boundary" | "die", _) => if vert { (fp.die.1, fp.die.3) } else { (fp.die.0, fp.die.2) },
                    _ => if vert { (area.1, area.3) } else { (area.0, area.2) },
                };
                let r = if vert { (c0, a0, c0 + w, a1) } else { (a0, c0, a1, c0 + w) };
                // stop at shapes of other nets on the same layer (block rings, other rings)
                let mut hs = holes.clone();
                hs.extend(others.iter().filter(|o| &o.0 != n && inter(grow(o.1, lsp), r).is_some()).map(|o| grow(o.1, lsp)));
                for (j, seg) in subtract(r, &hs, !vert).into_iter().enumerate() {
                    self.push_shape(format!("stripe_{}_{}_{}_{}{}", layer, n, k, i, if j > 0 { format!("_{}", j) } else { String::new() }), n, &layer, "stripe", seg);
                    made += 1;
                }
            }
            p += pitch;
            k += 1;
        }
        crate::info!("PG-130", "add_stripes: {} set(s) of {} on {} ({}, width {}, spacing {}, set-to-set {}), {} shape(s){}", k, nets.join(" "), layer, if vert { "vertical" } else { "horizontal" }, w, sp, pitch, made,
            if holes.is_empty() { String::new() } else { format!(", broken around {} block(s) obstructing {}", holes.len(), layer) });
        Ok(made.to_string())
    }

    // ------------------------------------------------------------------ followpins
    fn c_followpins(&mut self, a: &[String]) -> R {
        let x = args(a, &["-nets", "-layer", "-width", "-extend_to", "-area"]);
        let nets: Vec<String> = x.get("-nets").map(|s| split_list(s)).unwrap_or_else(|| vec!["VDD".into(), "VSS".into()]);
        if nets.len() < 2 { return err("create_followpins: -nets {power ground} (PG-140)"); }
        let layer = x.get("-layer").cloned().unwrap_or_else(|| self.metal_order().first().cloned().unwrap_or("M1".into()));
        let w = x.num("-width").unwrap_or((self.min_width(&layer) * 2.0).max(0.12));
        let area = x.get("-area").and_then(|s| parse_rect(s));
        let rows = self.row_segments()?;
        let fp = self.fp_req()?.clone();
        // rail per row boundary: N rows have ground at the bottom, power at the top (FS the reverse)
        let mut rails: BTreeMap<(i64, String), Vec<(f64, f64)>> = BTreeMap::new();
        for r in &rows {
            let fs = r.orient.contains('S');
            let (bot, top) = if fs { (&nets[0], &nets[1]) } else { (&nets[1], &nets[0]) };
            for (y, n) in [(r.y, bot), (r.y + r.height, top)] {
                rails.entry(((y * 1000.0).round() as i64, n.clone())).or_default().push((r.x, r.x1()));
            }
        }
        let ext = x.get("-extend_to").cloned().unwrap_or("core".into());
        let holes: Vec<Rect> = self.macros_placed().into_iter().filter(|m| m.2.contains(&layer) || m.2.is_empty()).map(|m| m.1).collect();
        let mut made = 0;
        let mut conflicts = 0;
        for ((yk, n), mut iv) in rails {
            let y = yk as f64 / 1000.0;
            iv.sort_by(|a, b| a.partial_cmp(b).unwrap());
            let mut merged: Vec<(f64, f64)> = vec![];
            for s in iv { match merged.last_mut() { Some(l) if s.0 <= l.1 + EPS => l.1 = l.1.max(s.1), _ => merged.push(s) } }
            if ext == "ring" || ext == "first_ring" {
                let rs: Vec<Rect> = fp.special.iter().filter(|s| s.net == n && s.kind == "ring" && !self.layer_horiz(&s.layer)).map(Self::shape_rect).filter(|r| r.1 <= y && r.3 >= y).collect();
                if let (Some(l), Some(f)) = (rs.iter().map(|r| r.0).reduce(f64::min), rs.iter().map(|r| r.2).reduce(f64::max)) {
                    if let Some(m) = merged.first_mut() { m.0 = m.0.min(l); }
                    if let Some(m) = merged.last_mut() { m.1 = m.1.max(f); }
                }
            }
            for (k, (x0, x1)) in merged.into_iter().enumerate() {
                let r = (x0, y - w / 2.0, x1, y + w / 2.0);
                if let Some(ar) = area { if inter(r, ar).is_none() { continue; } }
                for (j, seg) in subtract(r, &holes, true).into_iter().enumerate() {
                    self.push_shape(format!("fp_{}_{}_{}_{}", n, yk, k, j), &n, &layer, "followpin", seg);
                    made += 1;
                }
            }
            let _ = &mut conflicts;
        }
        crate::info!("PG-141", "create_followpins: {} rail(s) on {} (width {}), {} at the bottom of N rows / {} at the top, over {} row segment(s){}", made, layer, w, nets[1], nets[0], rows.len(),
            if ext.contains("ring") { ", extended to the core ring" } else { "" });
        Ok(made.to_string())
    }

    // ------------------------------------------------------------------ sroute: block / pad pins
    fn c_sroute(&mut self, a: &[String]) -> R {
        let x = args(a, &["-connect", "-nets", "-layer", "-width", "-strap_width", "-strap_pitch", "-layer_change_range", "-extend_to"]);
        let conn: Vec<String> = x.get("-connect").map(|s| split_list(s)).unwrap_or_else(|| vec!["core_pin".into(), "block_pin".into(), "pad_pin".into()]);
        let nets: Vec<String> = x.get("-nets").map(|s| split_list(s)).unwrap_or_else(|| self.pg_nets());
        if nets.is_empty() { return err("sroute: no PG nets (connect_global_net first, or -nets) (PG-150)"); }
        let mut total = 0;
        for c in &conn {
            let c = c.replace("Pin", "_pin").to_lowercase();
            match c.as_str() {
                "core_pin" | "corepin" => {
                    let mut v: Vec<String> = vec!["-nets".into(), nets.join(" ")];
                    if let Some(l) = x.get("-layer") { v.extend(["-layer".into(), l.clone()]); }
                    if let Some(w) = x.get("-width") { v.extend(["-width".into(), w.clone()]); }
                    v.extend(["-extend_to".into(), x.get("-extend_to").cloned().unwrap_or("ring".into())]);
                    total += self.c_followpins(&v)?.parse::<usize>().unwrap_or(0);
                }
                "block_pin" | "blockpin" | "pad_pin" | "padpin" => total += self.connect_pins(&nets, c.starts_with("pad"), x.num("-strap_width"), x.num("-strap_pitch").unwrap_or(10.0))?,
                "pad_ring" | "padring" | "floating_stripe" | "floatingstripe" | "secondary_power_pin" => crate::info!("PG-151", "sroute: -connect {} has nothing to do in this flow", c),
                o => return err(&format!("sroute: -connect {}: core_pin | block_pin | pad_pin | pad_ring | floating_stripe (PG-152)", o)),
            }
        }
        Ok(total.to_string())
    }

    /// straps from macro / pad PG pins to the nearest shape of the same net, on the pin layer
    fn connect_pins(&mut self, nets: &[String], pads: bool, sw: Option<f64>, pitch: f64) -> Result<usize, Flow> {
        let nl = self.nl()?;
        let fp = self.fp_req()?.clone();
        let mut todo: Vec<(String, String, String, Rect, Rect)> = vec![]; // inst, net, layer, pin rect, cell rect
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            let Some(m) = crate::lef::phys(&self.lef, cl) else { continue };
            if pads != m.is_pad() || (!pads && !m.is_block()) { continue; }
            let Some(cr) = crate::lef::cell_rect(&self.lef, cl) else { continue };
            for (p, n, shapes) in self.inst_pg_pins(c) {
                if !nets.contains(&n) { continue; }
                for (ly, r) in shapes { todo.push((format!("{}/{}", cl.name, p), n.clone(), ly, r, cr)); }
            }
        }
        let die_c = ((fp.die.0 + fp.die.2) / 2.0, (fp.die.1 + fp.die.3) / 2.0);
        let (mut made, mut unconnected) = (0, 0);
        for (pin, net, ly, r, cr) in todo {
            let cc = ((cr.0 + cr.2) / 2.0, (cr.1 + cr.3) / 2.0);
            let (pc, tall) = (((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0), (r.3 - r.1) >= (r.2 - r.0));
            // pads: towards the core; blocks: away from the block centre, across the pin's long side
            let (dx, dy) = if pads {
                let v = (die_c.0 - pc.0, die_c.1 - pc.1);
                if v.0.abs() > v.1.abs() { (v.0.signum(), 0.0) } else { (0.0, v.1.signum()) }
            } else if tall { ((pc.0 - cc.0).signum(), 0.0) } else { (0.0, (pc.1 - cc.1).signum()) };
            let w = sw.unwrap_or_else(|| if pads { ((r.2 - r.0).min(r.3 - r.1) * 0.8).min(10.0) } else { (self.min_width(&ly) * 5.0).max(0.5) });
            // strap positions along the pin
            let along: Vec<f64> = if dx != 0.0 {
                let n = (((r.3 - r.1) / pitch).floor() as usize).max(1);
                (0..n).map(|k| r.1 + (r.3 - r.1) * (k as f64 + 0.5) / n as f64).collect()
            } else {
                let n = (((r.2 - r.0) / pitch).floor() as usize).max(1);
                (0..n).map(|k| r.0 + (r.2 - r.0) * (k as f64 + 0.5) / n as f64).collect()
            };
            let targets: Vec<Rect> = self.fp.as_ref().unwrap().special.iter().filter(|s| s.net == net && matches!(s.kind.as_str(), "ring" | "block_ring" | "stripe")).map(Self::shape_rect).collect();
            for t in along {
                // the strap line from the pin edge outward; first same-net shape it crosses
                let best = targets.iter().filter_map(|q| {
                    if dx != 0.0 {
                        if t < q.1 || t > q.3 { return None; }
                        let d = if dx > 0.0 { q.0 - r.2 } else { r.0 - q.2 };
                        if d < -EPS { return None; }
                        Some((d, if dx > 0.0 { q.2 } else { q.0 }))
                    } else {
                        if t < q.0 || t > q.2 { return None; }
                        let d = if dy > 0.0 { q.1 - r.3 } else { r.1 - q.3 };
                        if d < -EPS { return None; }
                        Some((d, if dy > 0.0 { q.3 } else { q.1 }))
                    }
                }).min_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
                let Some((_, far)) = best else { unconnected += 1; continue };
                // move the strap along the pin until its via stack to the target is free
                let order = self.metal_order();
                let pli = order.iter().position(|l| l == &ly).unwrap_or(0);
                let tgt: Vec<(usize, Rect)> = self.fp.as_ref().unwrap().special.iter().filter(|q| q.net == net && matches!(q.kind.as_str(), "ring" | "block_ring" | "stripe")).filter_map(|q| order.iter().position(|l| l == &q.layer).map(|li| (li, Self::shape_rect(q)))).collect();
                let strap_at = |t: f64| -> Rect { if dx != 0.0 { (if dx > 0.0 { r.0 } else { far }, t - w / 2.0, if dx > 0.0 { far } else { r.2 }, t + w / 2.0) } else { (t - w / 2.0, if dy > 0.0 { r.1 } else { far }, t + w / 2.0, if dy > 0.0 { far } else { r.3 }) } };
                let ok_at = |t: f64| -> bool { let sr = strap_at(t); tgt.iter().filter(|q| q.0 > pli && inter(q.1, sr).is_some()).all(|q| !self.stack_blocked(&net, pli, q.0, inter(q.1, sr).unwrap(), &order)) };
                let (plo, phi) = if dx != 0.0 { (r.1 + w / 2.0, r.3 - w / 2.0) } else { (r.0 + w / 2.0, r.2 - w / 2.0) };
                let t = if ok_at(t) { t } else {
                    match (1..60).flat_map(|k| [t + k as f64 * 0.4, t - k as f64 * 0.4]).find(|q| *q >= plo && *q <= phi && ok_at(*q)) { Some(q) => q, None => { unconnected += 1; continue } }
                };
                let s = if dx != 0.0 { (if dx > 0.0 { r.0 } else { far }, t - w / 2.0, if dx > 0.0 { far } else { r.2 }, t + w / 2.0) } else { (t - w / 2.0, if dy > 0.0 { r.1 } else { far }, t + w / 2.0, if dy > 0.0 { far } else { r.3 }) };
                self.push_shape(format!("strap_{}_{}", pin.replace(['/', '[', ']'], "_"), made), &net, &ly, "strap", s);
                made += 1;
            }
        }
        crate::info!("PG-153", "sroute: {} strap(s) from {} PG pins{}", made, if pads { "pad" } else { "block" }, if unconnected > 0 { format!("; {} strap position(s) with no same-net ring / stripe in reach", unconnected) } else { String::new() });
        Ok(made)
    }

    // ------------------------------------------------------------------ vias
    /// overlaps of same-net PG shapes on different layers: (net, lower idx, upper idx, overlap)
    fn pg_overlaps(&self, nets: &[String], area: Option<Rect>) -> Vec<(String, usize, usize, Rect)> {
        let order = self.metal_order();
        let Some(fp) = self.fp.as_ref() else { return vec![] };
        let sh: Vec<(String, usize, Rect)> = fp.special.iter().filter(|s| is_pg_kind(&s.kind) && s.kind != "pg_via" && (nets.is_empty() || nets.contains(&s.net)))
            .filter_map(|s| order.iter().position(|l| l == &s.layer).map(|li| (s.net.clone(), li, Self::shape_rect(s)))).collect();
        let mut out = vec![];
        let mut seen = HashSet::new();
        // bucket by net for speed
        let mut by: HashMap<&str, Vec<usize>> = HashMap::new();
        for (i, s) in sh.iter().enumerate() { by.entry(s.0.as_str()).or_default().push(i); }
        for idx in by.values() {
            for (k, &i) in idx.iter().enumerate() {
                for &j in &idx[k + 1..] {
                    let (a, b) = (&sh[i], &sh[j]);
                    if a.1 == b.1 { continue; }
                    let Some(r) = inter(a.2, b.2) else { continue };
                    if let Some(ar) = area { if inter(r, ar).is_none() { continue; } }
                    let (lo, hi) = (a.1.min(b.1), a.1.max(b.1));
                    let key = (a.0.clone(), lo, hi, (r.0 * 1000.0) as i64, (r.1 * 1000.0) as i64);
                    if seen.insert(key) { out.push((a.0.clone(), lo, hi, r)); }
                }
            }
        }
        out
    }

    /// a via stack lo..hi at `r` would land on other-net metal of an intermediate layer
    fn stack_blocked(&self, net: &str, lo: usize, hi: usize, r: Rect, order: &[String]) -> bool {
        if hi <= lo + 1 { return false; }
        let fp = self.fp.as_ref().unwrap();
        (lo + 1..hi).any(|li| {
            let l = &order[li];
            let sp = self.min_space(l);
            fp.special.iter().any(|s| s.net != net && is_pg_kind(&s.kind) && (s.layer == *l || s.via.as_ref().map(|v| &v.lower == l || &v.upper == l).unwrap_or(false)) && touch(grow(Self::shape_rect(s), sp), r))
        })
    }

    fn c_gen_vias(&mut self, a: &[String]) -> R {
        let x = args(a, &["-nets", "-bottom_layer", "-top_layer", "-area", "-add_vias", "-via_rule"]);
        if self.fp.is_none() { return err("generate_vias: no floorplan (FP-001)"); }
        let nets: Vec<String> = x.get("-nets").map(|s| split_list(s)).unwrap_or_default();
        let order = self.metal_order();
        let bl = x.get("-bottom_layer").and_then(|l| order.iter().position(|q| q == l)).unwrap_or(0);
        let tl = x.get("-top_layer").and_then(|l| order.iter().position(|q| q == l)).unwrap_or(order.len().saturating_sub(1));
        let area = x.get("-area").and_then(|s| parse_rect(s));
        let ov = self.pg_overlaps(&nets, area);
        let existing: HashSet<(String, String, i64, i64)> = self.fp.as_ref().unwrap().special.iter().filter(|s| s.kind == "pg_via").filter_map(|s| s.via.as_ref().map(|v| (s.net.clone(), v.lower.clone(), (Self::shape_rect(s).0 * 1000.0) as i64, (Self::shape_rect(s).1 * 1000.0) as i64))).collect();
        let (mut made, mut cuts, mut nofit, mut blocked) = (0usize, 0usize, 0usize, 0usize);
        let mut new_sh = vec![];
        for (net, lo, hi, r) in ov {
            if lo < bl || hi > tl { continue; }
            if self.stack_blocked(&net, lo, hi, r, &order) { blocked += 1; continue; }
            for li in lo..hi {
                let (l0, l1) = (&order[li], &order[li + 1]);
                if existing.contains(&(net.clone(), l0.clone(), (r.0 * 1000.0) as i64, (r.1 * 1000.0) as i64)) { continue; }
                let rule = self.via_rule(l0, l1);
                let ex = rule.enc_lo.0.max(rule.enc_hi.0);
                let ey = rule.enc_lo.1.max(rule.enc_hi.1);
                let (uw, uh) = ((r.2 - r.0) - 2.0 * ex, (r.3 - r.1) - 2.0 * ey);
                let cols = if uw + EPS >= rule.cut_w { ((uw + rule.sp_x) / (rule.cut_w + rule.sp_x) + EPS).floor() as usize } else { 0 };
                let rows = if uh + EPS >= rule.cut_h { ((uh + rule.sp_y) / (rule.cut_h + rule.sp_y) + EPS).floor() as usize } else { 0 };
                if cols == 0 || rows == 0 { nofit += 1; continue; }
                let va = ViaArr { rule: rule.name.clone(), lower: l0.clone(), upper: l1.clone(), cols, rows, cut_w: rule.cut_w, cut_h: rule.cut_h, sp_x: rule.sp_x, sp_y: rule.sp_y, enc: (rule.enc_lo.0, rule.enc_lo.1, rule.enc_hi.0, rule.enc_hi.1) };
                cuts += cols * rows;
                new_sh.push(SpecialShape { name: format!("pgvia_{}_{}_{}", net, l0, made), net: net.clone(), layer: rule.cut.clone(), kind: "pg_via".into(), width: 0.0, pts: vec![(r.0, r.1), (r.2, r.3)], rect: Some(r), via: Some(va) });
                made += 1;
            }
        }
        self.fp.as_mut().unwrap().special.extend(new_sh);
        crate::info!("PG-200", "generate_vias: {} via array(s), {} cut(s){}{}", made, cuts, if nofit > 0 { format!("; {} overlap(s) too small for one cut", nofit) } else { String::new() },
            if blocked > 0 { format!("; {} stack(s) skipped: other-net metal on an intermediate layer", blocked) } else { String::new() });
        Ok(made.to_string())
    }

    fn c_del_vias(&mut self, a: &[String]) -> R {
        let x = args(a, &["-nets", "-area", "-delete_vias"]);
        let nets: Vec<String> = x.get("-nets").map(|s| split_list(s)).unwrap_or_default();
        let area = x.get("-area").and_then(|s| parse_rect(s));
        let fp = self.fp.as_mut().ok_or_else(|| Flow::Err("no floorplan".into()))?;
        let n0 = fp.special.len();
        fp.special.retain(|s| !(s.kind == "pg_via" && (nets.is_empty() || nets.contains(&s.net)) && area.map(|a| s.rect.map(|r| inter(r, a).is_some()).unwrap_or(false)).unwrap_or(true)));
        let d = n0 - fp.special.len();
        crate::info!("PG-201", "Deleted {} power via array(s)", d);
        Ok(d.to_string())
    }

    fn c_del_pg(&mut self, a: &[String]) -> R {
        let x = args(a, &["-nets", "-shape", "-shapes", "-area", "-layer"]);
        let nets: Vec<String> = x.get("-nets").map(|s| split_list(s)).unwrap_or_default();
        let kinds: Vec<String> = x.get("-shape").or(x.get("-shapes")).map(|s| split_list(s).iter().map(|k| match k.as_str() { "core_ring" | "corering" => "ring".to_string(), "blockring" => "block_ring".into(), "followpin" | "rail" | "followpins" => "followpin".into(), "via" | "vias" => "pg_via".into(), o => o.to_lowercase() }).collect()).unwrap_or_default();
        let area = x.get("-area").and_then(|s| parse_rect(s));
        let layer = x.get("-layer").cloned();
        let fp = self.fp.as_mut().ok_or_else(|| Flow::Err("no floorplan".into()))?;
        let n0 = fp.special.len();
        fp.special.retain(|s| !(is_pg_kind(&s.kind) && (nets.is_empty() || nets.contains(&s.net)) && (kinds.is_empty() || kinds.contains(&s.kind)) && layer.as_ref().map(|l| l == &s.layer).unwrap_or(true)
            && area.map(|a| inter(Self::shape_rect(s), a).is_some()).unwrap_or(true)));
        let d = n0 - fp.special.len();
        crate::info!("PG-160", "Deleted {} power / ground shape(s)", d);
        Ok(d.to_string())
    }

    fn c_add_special_wire(&mut self, a: &[String]) -> R {
        let x = args(a, &["-net", "-layer", "-width", "-points", "-rect", "-shape"]);
        let net = x.get("-net").cloned().ok_or_else(|| Flow::Err("add_special_wire: -net required (PG-170)".into()))?;
        let layer = x.get("-layer").cloned().ok_or_else(|| Flow::Err("add_special_wire: -layer required (PG-171)".into()))?;
        if self.fp.is_none() { return err("add_special_wire: no floorplan (FP-001)"); }
        let kind = x.get("-shape").cloned().unwrap_or("pg_wire".into());
        let mut n = 0;
        if let Some(r) = x.get("-rect").and_then(|s| parse_rect(s)) {
            self.push_shape(format!("pgw_{}_{}", net, self.fp.as_ref().unwrap().special.len()), &net, &layer, &kind, r);
            n = 1;
        } else {
            let w = x.num("-width").unwrap_or(self.min_width(&layer) * 2.0);
            let v: Vec<f64> = x.get("-points").map(|s| split_list(s).iter().filter_map(|t| t.parse().ok()).collect()).unwrap_or_default();
            if v.len() < 4 { return err("add_special_wire: -points {x0 y0 x1 y1 ...} or -rect {..} (PG-172)"); }
            for k in (0..v.len() - 2).step_by(2) {
                let (x0, y0, x1, y1) = (v[k], v[k + 1], v[k + 2], v[k + 3]);
                let r = (x0.min(x1) - w / 2.0, y0.min(y1) - w / 2.0, x0.max(x1) + w / 2.0, y0.max(y1) + w / 2.0);
                self.push_shape(format!("pgw_{}_{}", net, self.fp.as_ref().unwrap().special.len()), &net, &layer, &kind, r);
                n += 1;
            }
        }
        crate::info!("PG-173", "add_special_wire: {} shape(s) of net {} on {}", n, net, layer);
        Ok(n.to_string())
    }

    fn c_del_special_wire(&mut self, a: &[String]) -> R {
        let x = args(a, &["-net", "-area", "-layer"]);
        let net = x.get("-net").cloned();
        let area = x.get("-area").and_then(|s| parse_rect(s)).ok_or_else(|| Flow::Err("delete_special_wire: -area {..} required (PG-174)".into()))?;
        let layer = x.get("-layer").cloned();
        let fp = self.fp.as_mut().ok_or_else(|| Flow::Err("no floorplan".into()))?;
        let n0 = fp.special.len();
        // shapes touching the area are cut back to outside it (a whole shape inside goes)
        let mut out = vec![];
        for s in std::mem::take(&mut fp.special) {
            let hit = is_pg_kind(&s.kind) && net.as_ref().map(|n| n == &s.net).unwrap_or(true) && layer.as_ref().map(|l| l == &s.layer).unwrap_or(true) && inter(Self::shape_rect(&s), area).is_some();
            if !hit { out.push(s); continue; }
            if s.kind == "pg_via" { continue; }
            let r = Self::shape_rect(&s);
            let horiz = (r.2 - r.0) >= (r.3 - r.1);
            for (k, seg) in subtract(r, &[area], horiz).into_iter().enumerate() {
                let mut t = s.clone();
                t.name = format!("{}_c{}", s.name, k);
                t.rect = Some(seg);
                t.pts = vec![(seg.0, seg.1), (seg.2, seg.3)];
                out.push(t);
            }
        }
        fp.special = out;
        let d = n0 as i64 - fp.special.len() as i64;
        crate::info!("PG-175", "delete_special_wire: shapes cut / removed in ({:.3} {:.3}) ({:.3} {:.3}) ({} shape(s) fewer)", area.0, area.1, area.2, area.3, d);
        Ok(d.to_string())
    }

    fn c_report_pg(&mut self) -> R {
        let fp = self.fp_req()?;
        let mut t: BTreeMap<(String, String, String), (usize, f64)> = BTreeMap::new();
        for s in fp.special.iter().filter(|s| is_pg_kind(&s.kind)) {
            let r = Self::shape_rect(s);
            let e = t.entry((s.net.clone(), s.kind.clone(), s.layer.clone())).or_default();
            e.0 += 1;
            e.1 += if s.kind == "pg_via" { s.via.as_ref().map(|v| (v.cols * v.rows) as f64).unwrap_or(0.0) } else { (r.2 - r.0).max(r.3 - r.1) };
        }
        crate::out!("****************************************\nReport : power_routes\n****************************************\n  {:<8} {:<11} {:<8} {:>7} {:>12}", "net", "shape", "layer", "count", "length / cuts");
        for ((n, k, l), (c, len)) in &t { crate::out!("  {:<8} {:<11} {:<8} {:>7} {:>12.1}", n, k, l, c, len); }
        Ok(t.values().map(|v| v.0).sum::<usize>().to_string())
    }

    // ------------------------------------------------------------------ missing vias
    fn c_missing_vias(&mut self, a: &[String]) -> R {
        let x = args(a, &["-nets", "-error", "-area"]);
        if self.fp.is_none() { return err("check_missing_vias: no floorplan (FP-001)"); }
        let nets: Vec<String> = x.get("-nets").map(|s| split_list(s)).unwrap_or_default();
        let order = self.metal_order();
        let ov = self.pg_overlaps(&nets, x.get("-area").and_then(|s| parse_rect(s)));
        let vias: Vec<(String, String, Rect)> = self.fp.as_ref().unwrap().special.iter().filter(|s| s.kind == "pg_via").filter_map(|s| s.via.as_ref().map(|v| (s.net.clone(), v.lower.clone(), Self::shape_rect(s)))).collect();
        self.pgx.markers.retain(|m| m.tool != "via");
        let lim = x.num("-error").map(|v| v as usize).unwrap_or(10000);
        let mut miss = 0;
        let mut blocked = 0;
        let mut per: BTreeMap<String, usize> = BTreeMap::new();
        for (net, lo, hi, r) in &ov {
            if self.stack_blocked(net, *lo, *hi, *r, &order) { blocked += 1; continue; }
            for li in *lo..*hi {
                let ok = vias.iter().any(|v| &v.0 == net && v.1 == order[li] && inter(v.2, *r).is_some());
                if !ok {
                    miss += 1;
                    *per.entry(net.clone()).or_default() += 1;
                    if miss <= lim { self.pgx.markers.push(Marker { tool: "via".into(), kind: "missing_via".into(), layer: format!("{}-{}", order[li], order[li + 1]), rect: *r, nets: vec![net.clone()], msg: format!("missing via {} -> {} between overlapping {} shapes", order[li], order[li + 1], net) }); }
                }
            }
        }
        crate::info!("PG-300", "check_missing_vias: {} overlap(s) of same-net shapes checked ({} where other-net metal blocks the stack), {} missing via(s){}", ov.len(), blocked, miss,
            if per.is_empty() { String::new() } else { format!(" ({})", per.iter().map(|(n, k)| format!("{} {}", n, k)).collect::<Vec<_>>().join(", ")) });
        Ok(miss.to_string())
    }

    // ------------------------------------------------------------------ geometry for DRC / LVS
    /// every metal shape: (net, layer idx, rect, special?, NDR spacing multiplier)
    fn all_shapes(&self) -> Vec<(String, usize, Rect, bool, f64)> {
        let order = self.metal_order();
        let mut v = vec![];
        if let Some(fp) = &self.fp {
            for s in &fp.special {
                if s.kind == "pg_via" {
                    // via landing pads on both metal layers
                    if let Some(va) = &s.via {
                        let r = Self::shape_rect(s);
                        for l in [&va.lower, &va.upper] { if let Some(li) = order.iter().position(|q| q == l) { v.push((s.net.clone(), li, r, true, 1.0)); } }
                    }
                    continue;
                }
                if let Some(li) = order.iter().position(|q| q == &s.layer) { v.push((s.net.clone(), li, Self::shape_rect(s), true, 1.0)); }
            }
        }
        if let (Some(db), Some(nl)) = (self.routes.as_ref(), self.nl.as_ref()) {
            let hw = db.g * 0.25;
            for (nid, rn) in &db.nets {
                let name = nl.net(*nid).name.clone();
                let sm = self.ndr_of(&name, rn.clock).map(|r| r.smul).unwrap_or(1.0);
                for (n, p) in &rn.tree {
                    if *p == crate::droute::NONE { continue; }
                    let (x0, y0, l0) = db.pos(*n);
                    let (x1, y1, l1) = db.pos(*p);
                    let ln = db.layers.get(l0).map(|l| l.name.clone()).unwrap_or_default();
                    let li = order.iter().position(|q| *q == ln).unwrap_or(l0);
                    if l0 == l1 {
                        v.push((name.clone(), li, (x0.min(x1) - hw, y0.min(y1) - hw, x0.max(x1) + hw, y0.max(y1) + hw), false, sm));
                    } else {
                        for l in [l0, l1] {
                            let ln = db.layers.get(l).map(|q| q.name.clone()).unwrap_or_default();
                            let li = order.iter().position(|q| *q == ln).unwrap_or(l);
                            v.push((name.clone(), li, (x0 - hw, y0 - hw, x0 + hw, y0 + hw), false, sm));
                        }
                    }
                }
            }
        }
        v
    }

    pub(crate) fn ndr_of(&self, net: &str, clock: bool) -> Option<&Ndr> {
        let r = self.pgx.net_ndr.get(net).or_else(|| if clock { self.pgx.net_ndr.get("__clock__") } else { None })?;
        self.pgx.ndrs.iter().find(|n| &n.name == r)
    }

    /// pairs of shapes on the same layer closer than `reach` (bucketed)
    fn near_pairs(shapes: &[(String, usize, Rect, bool, f64)], reach: f64) -> Vec<(usize, usize)> {
        let cell = 5.0f64.max(reach * 4.0);
        let mut grid: HashMap<(usize, i64, i64), Vec<usize>> = HashMap::new();
        for (i, s) in shapes.iter().enumerate() {
            let r = grow(s.2, reach);
            for gx in (r.0 / cell).floor() as i64..=(r.2 / cell).floor() as i64 {
                for gy in (r.1 / cell).floor() as i64..=(r.3 / cell).floor() as i64 {
                    grid.entry((s.1, gx, gy)).or_default().push(i);
                }
            }
        }
        let mut out = HashSet::new();
        for v in grid.values() {
            if v.len() > 4000 { continue; }
            for (a, &i) in v.iter().enumerate() {
                for &j in &v[a + 1..] {
                    if shapes[i].0 == shapes[j].0 { continue; }
                    if gap(shapes[i].2, shapes[j].2) < reach + EPS { out.insert((i.min(j), i.max(j))); }
                }
            }
        }
        out.into_iter().collect()
    }

    fn c_check_drc(&mut self, a: &[String]) -> R {
        let x = args(a, &["-limit", "-area", "-layer", "-error"]);
        let lim = x.num("-limit").or(x.num("-error")).map(|v| v as usize).unwrap_or(10000);
        let area = x.get("-area").and_then(|s| parse_rect(s));
        let only = x.get("-layer").cloned();
        let order = self.metal_order();
        let mut sh = self.all_shapes();
        sh.retain(|s| area.map(|a| touch(s.2, a)).unwrap_or(true) && only.as_ref().map(|l| order.get(s.1) == Some(l)).unwrap_or(true));
        self.pgx.markers.retain(|m| m.tool != "drc");
        let mut counts: BTreeMap<String, usize> = BTreeMap::new();
        let mut mk: Vec<Marker> = vec![];
        // min width of special shapes
        for s in sh.iter().filter(|s| s.3) {
            let ln = &order[s.1];
            let w = (s.2 .2 - s.2 .0).min(s.2 .3 - s.2 .1);
            if w < self.min_width(ln) - EPS {
                *counts.entry(format!("{} min width", ln)).or_default() += 1;
                mk.push(Marker { tool: "drc".into(), kind: "min_width".into(), layer: ln.clone(), rect: s.2, nets: vec![s.0.clone()], msg: format!("width {:.3} < {:.3}", w, self.min_width(ln)) });
            }
        }
        // shorts and spacing between different nets (signal-signal by router-grid occupancy below)
        let maxsp = order.iter().map(|l| self.min_space(l)).fold(0.0, f64::max) * 2.0;
        for (i, j) in Self::near_pairs(&sh, maxsp) {
            let (p, q) = (&sh[i], &sh[j]);
            if !p.3 && !q.3 { continue; }
            let ln = &order[p.1];
            let need = self.min_space(ln) * p.4.max(q.4);
            let (kind, msg) = if let Some(r) = inter(p.2, q.2) { let _ = r; ("short", format!("{} and {} overlap", p.0, q.0)) } else {
                let gv = gap(p.2, q.2);
                if gv + EPS >= need { continue; }
                ("spacing", format!("{} - {} spacing {:.3} < {:.3}", p.0, q.0, gv, need))
            };
            *counts.entry(format!("{} {}", ln, kind)).or_default() += 1;
            let r = inter(p.2, q.2).unwrap_or((p.2 .0.min(q.2 .0).max(p.2 .0.max(q.2 .0) - 0.5), p.2 .1.min(q.2 .1).max(p.2 .1.max(q.2 .1) - 0.5), p.2 .2.max(q.2 .2).min(p.2 .2.min(q.2 .2) + 0.5), p.2 .3.max(q.2 .3).min(p.2 .3.min(q.2 .3) + 0.5)));
            mk.push(Marker { tool: "drc".into(), kind: kind.into(), layer: ln.clone(), rect: (r.0.min(r.2), r.1.min(r.3), r.0.max(r.2), r.1.max(r.3)), nets: vec![p.0.clone(), q.0.clone()], msg });
        }
        // signal grid: shared nodes (shorts) and NDR neighbour spacing
        if let (Some(db), Some(nl)) = (self.routes.as_ref(), self.nl.as_ref()) {
            let mut owner: HashMap<u32, NetId> = HashMap::new();
            let mut shorted: HashSet<u32> = HashSet::new();
            for (nid, rn) in &db.nets { for (n, _) in &rn.tree { if let Some(o) = owner.insert(*n, *nid) { if o != *nid { shorted.insert(*n); } } } }
            for n in &shorted {
                let (px, py, l) = db.pos(*n);
                if area.map(|a| px < a.0 || px > a.2 || py < a.1 || py > a.3).unwrap_or(false) { continue; }
                let nets: Vec<String> = db.nets.iter().filter(|(_, r)| r.tree.iter().any(|t| t.0 == *n)).map(|(k, _)| nl.net(*k).name.clone()).collect();
                let ln = db.layers[l].name.clone();
                *counts.entry(format!("{} short", ln)).or_default() += 1;
                mk.push(Marker { tool: "drc".into(), kind: "short".into(), layer: ln, rect: (px - db.g / 2.0, py - db.g / 2.0, px + db.g / 2.0, py + db.g / 2.0), nets: nets.clone(), msg: format!("{} share a routing track", nets.join(" / ")) });
            }
            for (nid, rn) in &db.nets {
                let name = nl.net(*nid).name.clone();
                let Some(r) = self.ndr_of(&name, rn.clock) else { continue };
                let h = r.halo() as i64;
                if h == 0 { continue; }
                let mut hit = 0;
                for (n, _) in &rn.tree {
                    let (gx, gy, l) = db.xyl(*n);
                    let horiz = db.layers[l].horiz;
                    for d in 1..=h {
                        for s in [-d, d] {
                            let (nx, ny) = if horiz { (gx as i64, gy as i64 + s) } else { (gx as i64 + s, gy as i64) };
                            if nx < 0 || ny < 0 || nx as usize >= db.nx || ny as usize >= db.ny { continue; }
                            let nb = db.node(nx as usize, ny as usize, l);
                            if let Some(o) = owner.get(&nb) { if o != nid { hit += 1; if hit <= 20 { let (px, py, _) = db.pos(*n); mk.push(Marker { tool: "drc".into(), kind: "ndr_spacing".into(), layer: db.layers[l].name.clone(), rect: (px - db.g, py - db.g, px + db.g, py + db.g), nets: vec![name.clone(), nl.net(*o).name.clone()], msg: format!("{} rule {}: neighbour track used by {}", name, r.name, nl.net(*o).name) }); } } }
                        }
                    }
                }
                if hit > 0 { *counts.entry(format!("NDR {} spacing", r.name)).or_default() += hit; }
            }
        }
        let total = mk.len();
        mk.truncate(lim);
        self.pgx.markers.extend(mk);
        crate::out!("****************************************\nReport : check_drc\n****************************************");
        if counts.is_empty() { crate::out!("  No DRC violations"); }
        for (k, v) in &counts { crate::out!("  {:<28} {:>7}", k, v); }
        crate::info!("PG-400", "check_drc: {} shape(s) checked, {} violation(s){}", sh.len(), total, if total > lim { format!(" ({} markers kept)", lim) } else { String::new() });
        Ok(total.to_string())
    }

    fn c_check_lvs(&mut self, a: &[String]) -> R {
        let x = args(a, &["-nets", "-type", "-error", "-report"]);
        let (mut do_s, mut do_o) = (x.has("-shorts"), x.has("-connectivity") || x.has("-opens") || x.has("-open"));
        if !do_s && !do_o { do_s = true; do_o = true; }
        let pats: Vec<String> = x.get("-nets").map(|s| split_list(s)).unwrap_or_default();
        let ty = x.get("-type").cloned().unwrap_or("all".into());
        let (reg, spe) = (ty == "all" || ty == "regular", ty == "all" || ty == "special");
        let nm = |n: &str| pats.is_empty() || pats.iter().any(|p| glob(p, n));
        let order = self.metal_order();
        self.pgx.markers.retain(|m| m.tool != "lvs");
        let mut mk: Vec<Marker> = vec![];
        let mut rep = String::new();
        use std::fmt::Write;
        // ---- shorts
        let mut short_pairs: BTreeMap<(String, String), (usize, Rect, String)> = BTreeMap::new();
        if do_s {
            let sh = self.all_shapes();
            for (i, j) in Self::near_pairs(&sh, 0.0) {
                let (p, q) = (&sh[i], &sh[j]);
                if !(nm(&p.0) || nm(&q.0)) { continue; }
                let Some(r) = inter(p.2, q.2) else { continue };
                if (!p.3 && !q.3 && !reg) || ((p.3 || q.3) && !spe && !reg) { continue; }
                let k = if p.0 < q.0 { (p.0.clone(), q.0.clone()) } else { (q.0.clone(), p.0.clone()) };
                let e = short_pairs.entry(k).or_insert((0, r, order[p.1].clone()));
                e.0 += 1;
            }
            if let (Some(db), Some(nl)) = (self.routes.as_ref(), self.nl.as_ref()) {
                if reg {
                    let mut owner: HashMap<u32, NetId> = HashMap::new();
                    for (nid, rn) in &db.nets {
                        for (n, _) in &rn.tree {
                            if let Some(o) = owner.insert(*n, *nid) {
                                if o != *nid {
                                    let (a1, b1) = (nl.net(o).name.clone(), nl.net(*nid).name.clone());
                                    if !(nm(&a1) || nm(&b1)) { continue; }
                                    let (px, py, l) = db.pos(*n);
                                    let k = if a1 < b1 { (a1, b1) } else { (b1, a1) };
                                    let e = short_pairs.entry(k).or_insert((0, (px - db.g, py - db.g, px + db.g, py + db.g), db.layers[l].name.clone()));
                                    e.0 += 1;
                                }
                            }
                        }
                    }
                }
            }
            let _ = writeln!(rep, "Shorts: {} shorted net pair(s)", short_pairs.len());
            for ((a1, b1), (k, r, l)) in &short_pairs {
                let _ = writeln!(rep, "  SHORT  {} <-> {}  {} overlap(s), first on {} at ({:.3} {:.3})", a1, b1, k, l, (r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0);
                mk.push(Marker { tool: "lvs".into(), kind: "short".into(), layer: l.clone(), rect: *r, nets: vec![a1.clone(), b1.clone()], msg: format!("short {} <-> {} ({} place(s))", a1, b1, k) });
            }
        }
        // ---- opens
        let mut opens: Vec<(String, String)> = vec![];
        if do_o {
            if reg {
                if let (Some(db), Some(nl)) = (self.routes.as_ref(), self.nl.as_ref()) {
                    for (nid, rn) in &db.nets {
                        let name = nl.net(*nid).name.clone();
                        if !nm(&name) { continue; }
                        let tn: HashSet<u32> = rn.tree.iter().map(|t| t.0).collect();
                        let lost: Vec<&(PinRef, u32)> = rn.pins.iter().filter(|p| !tn.contains(&p.1)).collect();
                        if rn.open || (!lost.is_empty() && !rn.tree.is_empty()) || (rn.tree.is_empty() && rn.pins.len() > 1) {
                            let pinname = |p: &PinRef| match p { PinRef::Cell(c, i) => format!("{}/{}", nl.cell(*c).name, nl.cell(*c).pins[*i].name), PinRef::Port(q) => nl.ports[*q].name.clone() };
                            let lostn: Vec<String> = lost.iter().map(|p| pinname(&p.0)).collect();
                            opens.push((name.clone(), format!("{} of {} pin(s) not connected{}", lost.len().max(1), rn.pins.len(), if lostn.is_empty() { String::new() } else { format!(": {}", lostn.iter().take(4).cloned().collect::<Vec<_>>().join(" ")) })));
                            for p in lost.iter().take(8) {
                                let (px, py, l) = db.pos(p.1);
                                mk.push(Marker { tool: "lvs".into(), kind: "open".into(), layer: db.layers[l].name.clone(), rect: (px - db.g * 2.0, py - db.g * 2.0, px + db.g * 2.0, py + db.g * 2.0), nets: vec![name.clone()], msg: format!("open: {} not connected", pinname(&p.0)) });
                            }
                        }
                    }
                } else if self.nl.is_some() {
                    let _ = writeln!(rep, "Regular nets: not routed (no routing database)");
                }
            }
            if spe {
                for net in self.pg_nets() {
                    if !nm(&net) { continue; }
                    // components of the net's geometry (same-layer touch or a via joining layers)
                    let fp = self.fp.as_ref().unwrap();
                    let sh: Vec<(usize, Rect, Option<(String, String)>)> = fp.special.iter().filter(|s| s.net == net && is_pg_kind(&s.kind)).map(|s| (order.iter().position(|q| q == &s.layer).unwrap_or(usize::MAX), Self::shape_rect(s), s.via.as_ref().map(|v| (v.lower.clone(), v.upper.clone())))).collect();
                    if sh.is_empty() { continue; }
                    let n = sh.len();
                    let mut uf: Vec<usize> = (0..n).collect();
                    fn find(u: &mut Vec<usize>, i: usize) -> usize { let mut r = i; while u[r] != r { r = u[r]; } let mut j = i; while u[j] != r { let k = u[j]; u[j] = r; j = k; } r }
                    let lay_of = |i: usize| -> Vec<usize> { match &sh[i].2 { Some((a, b)) => [a, b].iter().filter_map(|l| order.iter().position(|q| q == *l)).collect(), None => vec![sh[i].0] } };
                    for i in 0..n { for j in i + 1..n {
                        let (li, lj) = (lay_of(i), lay_of(j));
                        if li.iter().any(|l| lj.contains(l)) && touch(sh[i].1, sh[j].1) { let (a1, b1) = (find(&mut uf, i), find(&mut uf, j)); uf[a1] = b1; }
                    } }
                    let mut comp: HashMap<usize, (usize, Rect)> = HashMap::new();
                    for i in 0..n {
                        let r = find(&mut uf, i);
                        let e = comp.entry(r).or_insert((0, sh[i].1));
                        e.0 += 1;
                        e.1 = (e.1 .0.min(sh[i].1 .0), e.1 .1.min(sh[i].1 .1), e.1 .2.max(sh[i].1 .2), e.1 .3.max(sh[i].1 .3));
                    }
                    if comp.len() > 1 {
                        let main = comp.values().map(|c| c.0).max().unwrap_or(0);
                        let mut floating: Vec<(usize, Rect)> = comp.values().filter(|c| c.0 != main).cloned().collect();
                        floating.sort_by(|a, b| a.1 .0.partial_cmp(&b.1 .0).unwrap());
                        opens.push((net.clone(), format!("{} piece(s) of geometry ({} floating)", comp.len(), floating.len())));
                        for (k, r) in floating.iter().take(50) {
                            mk.push(Marker { tool: "lvs".into(), kind: "open".into(), layer: String::new(), rect: *r, nets: vec![net.clone()], msg: format!("{} floating piece of {} ({} shape(s)) not connected to the main network", net, net, k) });
                        }
                    }
                    // PG pins of blocks / pads without a touching shape of the net
                    let nl = self.nl.as_ref().unwrap();
                    let mut pin_open = 0;
                    for c in nl.cell_ids() {
                        if crate::lef::phys(&self.lef, nl.cell(c)).is_none() { continue; }
                        for (p, pn, shapes) in self.inst_pg_pins(c) {
                            if pn != net || shapes.is_empty() { continue; }
                            let ok = shapes.iter().any(|(ly, r)| { let li = order.iter().position(|q| q == ly); sh.iter().enumerate().any(|(i, s)| lay_of(i).iter().any(|l| Some(*l) == li) && touch(s.1, *r)) });
                            if !ok {
                                pin_open += 1;
                                mk.push(Marker { tool: "lvs".into(), kind: "open".into(), layer: shapes[0].0.clone(), rect: shapes[0].1, nets: vec![net.clone()], msg: format!("PG pin {}/{} not connected to {}", nl.cell(c).name, p, net) });
                            }
                        }
                    }
                    if pin_open > 0 { opens.push((net.clone(), format!("{} block / pad PG pin(s) not connected", pin_open))); }
                    // standard cells need rails
                    if !fp.special.iter().any(|s| s.net == net && s.kind == "followpin") && nl.cell_ids().iter().any(|c| nl.cell(*c).loc.is_some() && crate::lef::phys(&self.lef, nl.cell(*c)).is_none() && matches!(nl.cell(*c).kind, Kind::Lib(_))) {
                        opens.push((net.clone(), "no followpins: standard-cell PG pins unconnected".into()));
                    }
                }
            }
            let _ = writeln!(rep, "Opens: {} net(s)", opens.len());
            for (n, m) in &opens { let _ = writeln!(rep, "  OPEN   {}  {}", n, m); }
        }
        let (ns, no) = (short_pairs.len(), opens.len());
        self.pgx.markers.extend(mk);
        crate::out!("****************************************\nReport : check_lvs ({}{})\n****************************************\n{}", if do_s { "shorts" } else { "" }, if do_o { if do_s { " + connectivity" } else { "connectivity" } } else { "" }, rep.trim_end());
        if let Some(f) = x.get("-report") { std::fs::write(f, &rep).map_err(|e| Flow::Err(e.to_string()))?; }
        crate::info!("PG-450", "check_lvs: {} shorted net pair(s), {} open net(s); {} marker(s)", ns, no, self.pgx.markers.iter().filter(|m| m.tool == "lvs").count());
        Ok((ns + no).to_string())
    }

    // ------------------------------------------------------------------ markers
    fn c_report_markers(&mut self, a: &[String]) -> R {
        let x = args(a, &["-tool", "-limit", "-kind"]);
        let t = x.get("-tool").cloned();
        let k = x.get("-kind").cloned();
        let lim = x.num("-limit").map(|v| v as usize).unwrap_or(50);
        let v: Vec<&Marker> = self.pgx.markers.iter().filter(|m| t.as_ref().map(|t| t == &m.tool).unwrap_or(true) && k.as_ref().map(|k| k == &m.kind).unwrap_or(true)).collect();
        let mut by: BTreeMap<(String, String), usize> = BTreeMap::new();
        for m in &v { *by.entry((m.tool.clone(), m.kind.clone())).or_default() += 1; }
        crate::out!("****************************************\nReport : markers\n****************************************");
        for ((t, k), n) in &by { crate::out!("  {:<5} {:<14} {:>7}", t, k, n); }
        for (i, m) in v.iter().take(lim).enumerate() { crate::out!("  {:>4} {:<5} {:<12} {:<8} ({:.3} {:.3}) ({:.3} {:.3})  {}", i, m.tool, m.kind, m.layer, m.rect.0, m.rect.1, m.rect.2, m.rect.3, m.msg); }
        Ok(v.len().to_string())
    }

    fn c_write_markers(&mut self, a: &[String]) -> R {
        let x = args(a, &["-format", "-output", "-tool"]);
        let f = x.get("-output").cloned().or(x.pos.first().cloned()).ok_or_else(|| Flow::Err("write_markers: -output file required (PG-510)".into()))?;
        let fmt = x.get("-format").cloned().unwrap_or(if f.ends_with(".json") { "json".into() } else if f.ends_with(".txt") { "text".into() } else { "calibre".into() });
        let t = x.get("-tool").cloned();
        let v: Vec<&Marker> = self.pgx.markers.iter().filter(|m| t.as_ref().map(|t| t == &m.tool).unwrap_or(true)).collect();
        let top = self.nl.as_ref().map(|n| n.name.clone()).unwrap_or("TOP".into());
        let dbu = self.fp.as_ref().map(|f| f.dbu).unwrap_or(1000.0);
        use std::fmt::Write;
        let mut s = String::new();
        match fmt.as_str() {
            "calibre" | "rdb" | "ascii" => {
                // Calibre ASCII results database: one check per (tool, kind, layer)
                let _ = writeln!(s, "{} {}", top, dbu as i64);
                let mut by: BTreeMap<String, Vec<&Marker>> = BTreeMap::new();
                for m in &v { by.entry(format!("{}.{}{}", m.tool.to_uppercase(), m.kind.to_uppercase(), if m.layer.is_empty() { String::new() } else { format!(".{}", m.layer.replace('-', "_")) })).or_default().push(m); }
                let date = "Nov 22 00:00:00 2026";
                for (rule, ms) in &by {
                    // check header: result count, original count, text lines, date; then the text
                    let mut text: Vec<String> = vec![format!("rsynth {} check: {}", ms[0].tool, ms[0].kind)];
                    let mut nets: Vec<String> = ms.iter().flat_map(|m| m.nets.iter().cloned()).collect();
                    nets.sort();
                    nets.dedup();
                    if !nets.is_empty() { text.push(format!("Nets: {}", nets.iter().take(20).cloned().collect::<Vec<_>>().join(" "))); }
                    text.push(ms[0].msg.replace('\n', " "));
                    let _ = writeln!(s, "{}\n{} {} {} {}\n{}", rule, ms.len(), ms.len(), text.len(), date, text.join("\n"));
                    for (i, m) in ms.iter().enumerate() {
                        let u = |v: f64| (v * dbu).round() as i64;
                        let _ = writeln!(s, "p {} 4\n{} {}\n{} {}\n{} {}\n{} {}", i + 1, u(m.rect.0), u(m.rect.1), u(m.rect.2), u(m.rect.1), u(m.rect.2), u(m.rect.3), u(m.rect.0), u(m.rect.3));
                    }
                }
            }
            "text" | "txt" => { for m in &v { let _ = writeln!(s, "{}\t{}\t{}\t{:.4} {:.4} {:.4} {:.4}\t{}\t{}", m.tool, m.kind, m.layer, m.rect.0, m.rect.1, m.rect.2, m.rect.3, m.nets.join(","), m.msg); } }
            "json" => {
                let e: Vec<String> = v.iter().map(|m| format!("{{\"tool\":{:?},\"kind\":{:?},\"layer\":{:?},\"rect\":[{},{},{},{}],\"nets\":[{}],\"msg\":{:?}}}", m.tool, m.kind, m.layer, m.rect.0, m.rect.1, m.rect.2, m.rect.3, m.nets.iter().map(|n| format!("{:?}", n)).collect::<Vec<_>>().join(","), m.msg)).collect();
                s = format!("[{}]\n", e.join(",\n"));
            }
            o => return err(&format!("write_markers: -format {} (calibre | text | json) (PG-511)", o)),
        }
        std::fs::write(&f, s).map_err(|e| Flow::Err(e.to_string()))?;
        crate::info!("PG-512", "Wrote {} marker(s) to '{}' ({} format)", v.len(), f, fmt);
        Ok(f)
    }

    /// Calibre ASCII results database back into markers (tool "import")
    fn c_read_markers(&mut self, a: &[String]) -> R {
        let x = args(a, &["-format", "-tool"]);
        let f = x.pos.first().cloned().ok_or_else(|| Flow::Err("read_markers: file name required (PG-520)".into()))?;
        let tool = x.get("-tool").cloned().unwrap_or("import".into());
        let txt = std::fs::read_to_string(&f).map_err(|e| Flow::Err(format!("read_markers: {}: {}", f, e)))?;
        let lines: Vec<&str> = txt.lines().collect();
        let dbu: f64 = lines.first().and_then(|l| l.split_whitespace().nth(1)).and_then(|v| v.parse().ok()).unwrap_or(1000.0);
        let mut i = 1;
        let mut n = 0;
        while i < lines.len() {
            let rule = lines[i].trim().to_string();
            let hdr: Vec<&str> = lines.get(i + 1).map(|l| l.split_whitespace().collect()).unwrap_or_default();
            if hdr.len() < 3 { break; }
            let cnt: usize = hdr[0].parse().unwrap_or(0);
            let ntext: usize = hdr[2].parse().unwrap_or(0);
            let check_msg = if ntext > 0 { lines.get(i + 1 + ntext).map(|l| l.trim().to_string()).unwrap_or_default() } else { String::new() };
            i += 2 + ntext;
            let parts: Vec<&str> = rule.split('.').collect();
            for _ in 0..cnt {
                let h: Vec<&str> = lines.get(i).map(|l| l.split_whitespace().collect()).unwrap_or_default();
                if h.len() < 3 { break; }
                let nv: usize = h[2].parse().unwrap_or(0);
                i += 1;
                let mut msg = if check_msg.is_empty() { rule.clone() } else { format!("{}: {}", rule, check_msg) };
                while i < lines.len() && (lines[i].starts_with("CN") || lines[i].starts_with("DP") || lines[i].starts_with("CS")) { msg = lines[i][2..].trim().to_string(); i += 1; }
                let mut pts: Vec<(f64, f64)> = vec![];
                for _ in 0..nv {
                    let v: Vec<f64> = lines.get(i).map(|l| l.split_whitespace().filter_map(|t| t.parse().ok()).collect()).unwrap_or_default();
                    if v.len() >= 2 { pts.push((v[0] / dbu, v[1] / dbu)); }
                    if h[0] == "e" && v.len() >= 4 { pts.push((v[2] / dbu, v[3] / dbu)); }
                    i += 1;
                }
                if pts.is_empty() { continue; }
                let r = pts.iter().fold((f64::MAX, f64::MAX, f64::MIN, f64::MIN), |b, p| (b.0.min(p.0), b.1.min(p.1), b.2.max(p.0), b.3.max(p.1)));
                self.pgx.markers.push(Marker { tool: tool.clone(), kind: parts.get(1).map(|s| s.to_lowercase()).unwrap_or(rule.clone()), layer: parts.get(2).cloned().unwrap_or("").to_string(), rect: r, nets: vec![], msg });
                n += 1;
            }
        }
        crate::info!("PG-521", "Read {} marker(s) from '{}'", n, f);
        Ok(n.to_string())
    }

    // ------------------------------------------------------------------ NDR
    fn c_add_ndr(&mut self, a: &[String]) -> R {
        let x = args(a, &["-name", "-preset", "-width_multiplier", "-spacing_multiplier", "-widths", "-width", "-spacings", "-spacing"]);
        let preset = x.get("-preset").map(|s| s.to_lowercase());
        let name = x.get("-name").cloned().or_else(|| preset.as_ref().map(|p| format!("NDR_{}", p.to_uppercase()))).ok_or_else(|| Flow::Err("create_route_rule: -name or -preset required (PG-410)".into()))?;
        let order = self.metal_order();
        let (mut wm, mut sm) = (1.0, 1.0);
        if let Some(p) = &preset {
            match p.as_str() { "1w1s" | "single" => {}, "1w2s" => sm = 2.0, "2w1s" => wm = 2.0, "2w2s" | "double" => { wm = 2.0; sm = 2.0; }, "3w3s" => { wm = 3.0; sm = 3.0; }, o => return err(&format!("create_route_rule: -preset {} (1w1s | 1w2s | 2w1s | 2w2s | 3w3s) (PG-411)", o)) }
        }
        let scalar = |s: &str| -> Option<f64> { let v = split_list(s); if v.len() == 1 { v[0].parse().ok() } else { v.last().and_then(|t| t.parse().ok()) } };
        if let Some(v) = x.get("-width_multiplier") { wm = scalar(v).unwrap_or(wm); }
        if let Some(v) = x.get("-spacing_multiplier") { sm = scalar(v).unwrap_or(sm); }
        let lmap = |s: Option<&String>| -> BTreeMap<String, f64> {
            let mut m = BTreeMap::new();
            let t = s.map(|v| split_list(v)).unwrap_or_default();
            for c in t.chunks(2) { if c.len() == 2 { if let Ok(v) = c[1].parse::<f64>() { for l in expand_layers(&c[0], &order) { m.insert(l, v); } } } }
            m
        };
        let widths = lmap(x.get("-widths").or(x.get("-width")));
        let spacings = lmap(x.get("-spacings").or(x.get("-spacing")));
        // explicit values give the multipliers too
        if !widths.is_empty() { wm = widths.iter().map(|(l, w)| w / self.min_width(l)).fold(1.0, f64::max); }
        if !spacings.is_empty() { sm = spacings.iter().map(|(l, s)| s / self.min_space(l)).fold(1.0, f64::max); }
        let r = Ndr { name: name.clone(), wmul: wm, smul: sm, widths, spacings };
        let halo = r.halo();
        self.pgx.ndrs.retain(|q| q.name != name);
        self.pgx.ndrs.push(r);
        crate::info!("PG-413", "Route rule {}: width x{} spacing x{} (router keeps {} neighbour track(s) free)", name, wm, sm, halo);
        Ok(name)
    }

    fn c_set_ndr(&mut self, a: &[String]) -> R {
        let x = args(a, &["-nets", "-net", "-route_rule", "-non_default_rule", "-rule"]);
        let rule = x.get("-route_rule").or(x.get("-non_default_rule")).or(x.get("-rule")).cloned();
        let reset = x.has("-reset") || rule.as_deref() == Some("");
        if !reset {
            let r = rule.clone().ok_or_else(|| Flow::Err("set_route_attributes: -route_rule <rule> (or -reset) (PG-420)".into()))?;
            if !self.pgx.ndrs.iter().any(|q| q.name == r) { return err(&format!("set_route_attributes: no route rule '{}' (create_route_rule) (PG-421)", r)); }
        }
        let mut names: Vec<String> = vec![];
        if x.has("-clock_nets") { names.push("__clock__".into()); }
        let pats: Vec<String> = x.get("-nets").or(x.get("-net")).map(|s| split_list(s)).unwrap_or_default();
        if let Some(nl) = self.nl.as_ref() {
            for p in &pats {
                let p = crate::cons::Obj::parse(p).map(|o| o.name().to_string()).unwrap_or(p.clone());
                let m: Vec<String> = nl.net_ids().into_iter().map(|n| nl.net(n).name.clone()).filter(|n| glob(&p, n)).collect();
                if m.is_empty() { crate::warn!("PG-422", "set_route_attributes: no net matches '{}'", p); }
                names.extend(m);
            }
        }
        if names.is_empty() { return err("set_route_attributes: -nets {..} or -clock_nets (PG-423)"); }
        for n in &names { if reset { self.pgx.net_ndr.remove(n); } else { self.pgx.net_ndr.insert(n.clone(), rule.clone().unwrap()); } }
        crate::info!("PG-424", "Route rule {} {} {} net(s){}; it applies at the next route_auto / route_eco", rule.clone().unwrap_or("(default)".into()), if reset { "removed from" } else { "set on" },
            names.iter().filter(|n| *n != "__clock__").count(), if names.iter().any(|n| n == "__clock__") { " + all clock nets" } else { "" });
        Ok(names.len().to_string())
    }

    fn c_report_ndr(&mut self) -> R {
        crate::out!("****************************************\nReport : route_rules\n****************************************\n  {:<12} {:>6} {:>6} {:>5}  {}", "rule", "width", "space", "halo", "nets");
        for r in &self.pgx.ndrs {
            let nets: Vec<&String> = self.pgx.net_ndr.iter().filter(|(_, v)| *v == &r.name).map(|(k, _)| k).collect();
            crate::out!("  {:<12} x{:<5} x{:<5} {:>5}  {}{}", r.name, r.wmul, r.smul, r.halo(), nets.len(), if nets.is_empty() { String::new() } else { format!(" ({})", nets.iter().take(8).map(|n| if n.as_str() == "__clock__" { "all clock nets".to_string() } else { n.to_string() }).collect::<Vec<_>>().join(" ")) });
            if !r.widths.is_empty() { crate::out!("      widths   {}", r.widths.iter().map(|(l, w)| format!("{} {}", l, w)).collect::<Vec<_>>().join("  ")); }
            if !r.spacings.is_empty() { crate::out!("      spacings {}", r.spacings.iter().map(|(l, w)| format!("{} {}", l, w)).collect::<Vec<_>>().join("  ")); }
        }
        Ok(self.pgx.ndrs.len().to_string())
    }

    /// DEF NONDEFAULTRULES section lines
    pub(crate) fn ndr_def(&self) -> Vec<String> {
        let order = self.metal_order();
        let dbu = self.fp.as_ref().map(|f| f.dbu).unwrap_or(1000.0);
        self.pgx.ndrs.iter().map(|r| {
            let ls: Vec<String> = order.iter().map(|l| {
                let w = r.widths.get(l).copied().unwrap_or(self.min_width(l) * r.wmul);
                let s = r.spacings.get(l).copied().unwrap_or(self.min_space(l) * r.smul);
                format!("\n    + LAYER {} WIDTH {} SPACING {}", l, (w * dbu).round() as i64, (s * dbu).round() as i64)
            }).collect();
            format!("  - {}{} ;", r.name, ls.join(""))
        }).collect()
    }
}

fn g_mod(g: &[GConn]) -> bool { g.last().map(|x| !x.module.is_empty()).unwrap_or(false) }
