//! DFT: multiplexed-flip-flop scan insertion with DRC (clock / async-reset
//! controllability), clock-domain-aware balanced chain allocation, chain
//! stitching, scan-enable distribution, ICG test-enable hookup.

use crate::liberty::{LibCell, Library};
use crate::netlist::*;
use std::collections::BTreeMap;

#[derive(Clone, Debug, Default)]
pub struct DftCfg {
    pub chain_count: usize,
    pub max_length: Option<usize>,
    pub mix_clocks: bool,
    pub scan_enable: Option<String>,
    pub test_mode: Option<String>,
    pub scan_in: Vec<String>,
    pub scan_out: Vec<String>,
    pub protocol: bool,
    pub chains: Vec<(String, String, Vec<String>)>,
    pub excluded: Vec<String>,
    pub signals: Vec<(String, String, String)>,
}

fn scan_pins(c: &LibCell) -> Option<(String, String)> {
    let si = c.pins.iter().find(|p| p.nextstate_type.as_deref() == Some("scan_in")).or_else(|| c.pins.iter().find(|p| ["SI", "TI", "SD", "SCAN_IN"].contains(&p.name.as_str())))?;
    let se = c.pins.iter().find(|p| p.nextstate_type.as_deref() == Some("scan_enable")).or_else(|| c.pins.iter().find(|p| ["SE", "TE", "SCAN_EN"].contains(&p.name.as_str())))?;
    Some((si.name.clone(), se.name.clone()))
}

/// find the scan equivalent of a non-scan flop: superset of pins, same async structure, same vt
pub fn scan_equiv<'a>(lib: &'a Library, c: &LibCell) -> Option<(&'a LibCell, String, String)> {
    let s = c.seq.as_ref()?;
    let mut best: Option<(&LibCell, String, String)> = None;
    for cand in lib.cells_sorted().into_iter() {
        if !cand.scan || cand.dont_use || cand.retention {
            continue;
        }
        let Some(cs) = &cand.seq else { continue };
        if cs.is_latch != s.is_latch || cs.clear.is_some() != s.clear.is_some() || cs.preset.is_some() != s.preset.is_some() {
            continue;
        }
        if !c.pins.iter().all(|p| cand.pin(&p.name).is_some()) {
            continue;
        }
        let Some((si, se)) = scan_pins(cand) else { continue };
        let score = (cand.vt != c.vt) as i32;
        if best.as_ref().map(|b| score < (b.0.vt != c.vt) as i32 || (score == (b.0.vt != c.vt) as i32 && (cand.drive - c.drive).abs() < (b.0.drive - c.drive).abs())).unwrap_or(true) {
            best = Some((cand, si, se));
        }
    }
    best
}

/// Trace a net backwards through buffers/inverters/ICGs to a primary input.
fn controllable(nl: &Netlist, lib: &Library, mut n: NetId) -> Result<String, String> {
    for _ in 0..64 {
        match nl.driver(n) {
            Some(PinRef::Port(p)) => return Ok(nl.ports[p].name.clone()),
            Some(PinRef::Cell(c, _)) => {
                let cell = nl.cell(c);
                match &cell.kind {
                    Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1) => return Ok("constant".into()),
                    Kind::Lib(l) => {
                        let lc = lib.cells.get(l).ok_or("unknown cell")?;
                        if lc.tie.is_some() {
                            return Ok("constant".into());
                        }
                        if lc.is_buf || lc.is_inv {
                            n = cell.pin_net(&lc.inputs()[0].name).ok_or("floating")?;
                            continue;
                        }
                        if lc.icg.is_some() {
                            let ck = lc.pins.iter().find(|p| p.cg_role.as_deref() == Some("clock")).map(|p| p.name.clone()).ok_or("icg")?;
                            n = cell.pin_net(&ck).ok_or("floating")?;
                            continue;
                        }
                        return Err(format!("driven by {} '{}'", if lc.seq.is_some() { "register" } else { "logic" }, cell.name));
                    }
                    _ => return Err(format!("driven by '{}'", cell.name)),
                }
            }
            None => return Err("undriven".into()),
        }
    }
    Err("too deep".into())
}

pub fn insert(nl: &mut Netlist, lib: &Library, cfg: &mut DftCfg, preview: bool) -> Result<usize, String> {
    let se_name = cfg.scan_enable.clone().unwrap_or("test_se".into());
    // collect flops
    let mut domains: BTreeMap<String, Vec<CellId>> = BTreeMap::new();
    let mut viol = 0;
    cfg.excluded.clear();
    for c in nl.cell_ids() {
        let cell = nl.cell(c);
        let Some(lc) = cell.lib().and_then(|l| lib.cells.get(l)) else { continue };
        let Some(s) = &lc.seq else { continue };
        if s.is_latch || lc.icg.is_some() || cell.frozen() || cell.has_attr("scan_exclude") {
            continue;
        }
        if lc.scan && cell.has_attr("scan") {
            continue;
        }
        let ckp = s.clocked_on.trim_start_matches('!').trim_end_matches('\'').to_string();
        let Some(ckn) = cell.pin_net(&ckp) else { continue };
        match controllable(nl, lib, ckn) {
            Ok(root) => {
                if let Some(cl) = &s.clear {
                    let rp = cl.trim_start_matches('!').trim_end_matches('\'');
                    if let Some(rn) = cell.pin_net(rp) {
                        if let Err(e) = controllable(nl, lib, rn) {
                            crate::warn!("DFT-D3", "Asynchronous reset of '{}' not controllable ({}); register excluded from scan", cell.name, e);
                            cfg.excluded.push(cell.name.clone());
                            viol += 1;
                            continue;
                        }
                    }
                }
                if scan_equiv(lib, lc).is_none() && !lc.scan {
                    crate::warn!("DFT-S1", "No scan equivalent for '{}' ({}); excluded", cell.name, lc.name);
                    cfg.excluded.push(cell.name.clone());
                    continue;
                }
                let key = if cfg.mix_clocks { "all".into() } else { root };
                domains.entry(key).or_default().push(c);
            }
            Err(e) => {
                crate::warn!("DFT-D1", "Clock of register '{}' is not controllable from a primary input ({}); excluded from scan", cell.name, e);
                cfg.excluded.push(cell.name.clone());
                viol += 1;
            }
        }
    }
    let total: usize = domains.values().map(|v| v.len()).sum();
    crate::info!("DFT-100", "DFT DRC: {} scannable register(s) in {} clock domain(s), {} violation(s)", total, domains.len(), viol);
    if total == 0 {
        return Ok(0);
    }
    let mut nch = cfg.chain_count.max(1);
    if let Some(ml) = cfg.max_length {
        nch = nch.max(total.div_ceil(ml));
    }
    nch = nch.max(domains.len().min(nch.max(domains.len())));
    // allocate chains per domain proportional to size
    let mut alloc: Vec<(String, Vec<CellId>)> = vec![];
    let mut remaining = nch;
    let dlen = domains.len();
    for (k, (dom, regs)) in domains.iter().enumerate() {
        let share = if k + 1 == dlen { remaining.max(1) } else { ((regs.len() * nch) as f64 / total as f64).round().max(1.0) as usize };
        let share = share.min(remaining.saturating_sub(dlen - k - 1)).max(1);
        remaining = remaining.saturating_sub(share);
        let mut regs = regs.clone();
        regs.sort_by_key(|c| nl.cell(*c).name.clone());
        let per = regs.len().div_ceil(share);
        for ch in regs.chunks(per.max(1)) {
            alloc.push((dom.clone(), ch.to_vec()));
        }
    }
    cfg.chains.clear();
    if preview {
        for (i, (dom, regs)) in alloc.iter().enumerate() {
            cfg.chains.push((format!("chain{}", i), dom.clone(), regs.iter().map(|c| nl.cell(*c).name.clone()).collect()));
        }
        return Ok(total);
    }
    // ports
    let se = match nl.port_by_name(&se_name) {
        Some(p) => nl.ports[p].net.unwrap(),
        None => {
            let p = nl.add_port(&se_name, Dir::In);
            nl.ports[p].net.unwrap()
        }
    };
    for (i, (dom, regs)) in alloc.iter().enumerate() {
        let si_name = cfg.scan_in.get(i).cloned().unwrap_or(format!("test_si{}", i));
        let so_name = cfg.scan_out.get(i).cloned().unwrap_or(format!("test_so{}", i));
        let mut prev = match nl.port_by_name(&si_name) {
            Some(p) => nl.ports[p].net.unwrap(),
            None => {
                let p = nl.add_port(&si_name, Dir::In);
                nl.ports[p].net.unwrap()
            }
        };
        let mut names = vec![];
        for &c in regs {
            let cell = nl.cell(c).clone();
            let lc = lib.cells.get(cell.lib().unwrap()).unwrap();
            let (sc, sip, sep) = if lc.scan { (lc, scan_pins(lc).unwrap().0, scan_pins(lc).unwrap().1) } else { scan_equiv(lib, lc).unwrap() };
            let pins: Vec<(&str, Dir)> = sc.pins.iter().map(|p| (p.name.as_str(), p.dir.unwrap_or(Dir::In))).collect();
            nl.remove_cell(c);
            let nc = nl.add_cell(&cell.name, Kind::Lib(sc.name.clone()), &pins);
            nl.cell_mut(nc).loc = cell.loc;
            nl.cell_mut(nc).attrs = cell.attrs.clone();
            nl.cell_mut(nc).attrs.push("scan".into());
            for p in &cell.pins {
                if let Some(n) = p.net {
                    nl.connect_name(nc, &p.name, n);
                }
            }
            nl.connect_name(nc, &sip, prev);
            nl.connect_name(nc, &sep, se);
            // next element takes Q
            let q = sc.outputs().iter().find(|o| !o.function.clone().unwrap_or_default().contains('!') && !o.name.ends_with('N')).map(|o| o.name.clone()).unwrap_or(sc.outputs()[0].name.clone());
            prev = match nl.cell(nc).pin_net(&q) {
                Some(n) => n,
                None => {
                    let n = nl.add_net(&format!("{}_so", cell.name));
                    nl.connect_name(nc, &q, n);
                    n
                }
            };
            names.push(cell.name.clone());
        }
        match nl.port_by_name(&so_name) {
            Some(p) => nl.connect_port(p, prev),
            None => {
                let p = nl.add_port(&so_name, Dir::Out);
                let old = nl.ports[p].net.unwrap();
                nl.connect_port(p, prev);
                nl.remove_net(old);
            }
        }
        crate::info!("DFT-200", "Scan chain {} ({} -> {}): {} cells, clock domain '{}'", i, si_name, so_name, names.len(), dom);
        cfg.chains.push((format!("{}:{}", si_name, so_name), dom.clone(), names));
    }
    // ICG test enables
    let tm = cfg.test_mode.clone().and_then(|t| nl.port_by_name(&t)).and_then(|p| nl.ports[p].net).unwrap_or(se);
    let mut nicg = 0;
    for c in nl.cell_ids() {
        let Some(lc) = nl.cell(c).lib().and_then(|l| lib.cells.get(l)) else { continue };
        if lc.icg.is_none() {
            continue;
        }
        if let Some(tp) = lc.pins.iter().find(|p| p.cg_role.as_deref() == Some("test")) {
            nl.connect_name(c, &tp.name, tm);
            nicg += 1;
        }
    }
    if nicg > 0 {
        crate::info!("DFT-210", "Connected test-enable of {} clock-gating cell(s) to '{}'", nicg, nl.net(tm).name);
    }
    nl.sweep_nets();
    cfg.protocol = true;
    Ok(total)
}

// ------------------------------------------------------------------ scan chain reordering
fn find_lc<'a>(libs: &'a [Library], nl: &Netlist, c: CellId) -> Option<&'a LibCell> {
    let l = nl.cell(c).lib()?;
    libs.iter().find_map(|x| x.cells.get(l))
}

/// non-inverted Q output used as scan-out of a scan cell
fn scan_q(lc: &LibCell) -> String {
    lc.outputs().iter().find(|o| !o.function.clone().unwrap_or_default().contains('!') && !o.name.ends_with('N')).map(|o| o.name.clone()).unwrap_or(lc.outputs()[0].name.clone())
}

fn mdist(a: Option<(f64, f64)>, b: Option<(f64, f64)>) -> f64 {
    match (a, b) {
        (Some(p), Some(q)) => (p.0 - q.0).abs() + (p.1 - q.1).abs(),
        _ => 0.0,
    }
}

/// scan wirelength of an ordered chain including the scan-in / scan-out port hops
pub fn chain_length(nl: &Netlist, si: Option<(f64, f64)>, so: Option<(f64, f64)>, cells: &[CellId]) -> f64 {
    let mut l = 0.0;
    let mut prev = si;
    for &c in cells {
        let p = nl.cell(c).loc;
        l += mdist(prev, p);
        prev = p;
    }
    l + mdist(prev, so)
}

/// open-path TSP with fixed (optional) end points: nearest neighbour + 2-opt
fn order_path(pts: &[(f64, f64)], si: Option<(f64, f64)>, so: Option<(f64, f64)>, passes: usize) -> Vec<usize> {
    let n = pts.len();
    if n <= 1 {
        return (0..n).collect();
    }
    let mut used = vec![false; n];
    let mut route = Vec::with_capacity(n);
    let mut cur = si.unwrap_or(pts[0]);
    for _ in 0..n {
        let mut best = usize::MAX;
        let mut bd = f64::INFINITY;
        for (i, p) in pts.iter().enumerate() {
            if !used[i] {
                let d = (p.0 - cur.0).abs() + (p.1 - cur.1).abs();
                if d < bd {
                    bd = d;
                    best = i;
                }
            }
        }
        used[best] = true;
        route.push(best);
        cur = pts[best];
    }
    let at = |route: &Vec<usize>, k: isize| -> Option<(f64, f64)> {
        if k < 0 {
            si
        } else if k as usize >= route.len() {
            so
        } else {
            Some(pts[route[k as usize]])
        }
    };
    let window = if n > 2000 { 300 } else { n };
    for _ in 0..passes {
        let mut improved = false;
        for i in 0..n {
            for j in (i + 1)..n.min(i + window) {
                let a = at(&route, i as isize - 1);
                let b = at(&route, i as isize);
                let c = at(&route, j as isize);
                let d = at(&route, j as isize + 1);
                let delta = mdist(a, c) + mdist(b, d) - mdist(a, b) - mdist(c, d);
                if delta < -1e-9 {
                    route[i..=j].reverse();
                    improved = true;
                }
            }
        }
        if !improved {
            break;
        }
    }
    route
}

pub struct ReorderStat {
    pub chain: String,
    pub cells: usize,
    pub before: f64,
    pub after: f64,
}

/// Reorder (and optionally repartition within a clock domain) scan chains to minimize scan wirelength.
pub fn optimize_chains(nl: &mut Netlist, libs: &[Library], cfg: &mut DftCfg, only: &[String], repartition: bool, passes: usize) -> Result<(Vec<ReorderStat>, usize), String> {
    if cfg.chains.is_empty() {
        return Err("no scan chains (run insert_dft first)".into());
    }
    let port_loc = |nl: &Netlist, n: &str| nl.port_by_name(n).and_then(|p| nl.ports[p].loc);
    // chain index list, with resolved cells
    let mut sel: Vec<usize> = (0..cfg.chains.len()).filter(|&i| only.is_empty() || only.iter().any(|o| crate::netlist::glob(o, &cfg.chains[i].0) || crate::netlist::glob(o, &format!("chain{}", i)))).collect();
    sel.sort();
    let mut cells_of: Vec<Vec<CellId>> = cfg.chains.iter().map(|(_, _, regs)| regs.iter().filter_map(|r| nl.cell_by_name(r)).collect()).collect();
    for &i in &sel {
        if cells_of[i].len() != cfg.chains[i].2.len() {
            return Err(format!("chain '{}': {} scan cell(s) no longer exist", cfg.chains[i].0, cfg.chains[i].2.len() - cells_of[i].len()));
        }
        if let Some(c) = cells_of[i].iter().find(|c| nl.cell(**c).loc.is_none()) {
            return Err(format!("chain '{}': cell '{}' has no location (place the design or read a placed DEF first)", cfg.chains[i].0, nl.cell(*c).name));
        }
    }
    let ends = |nl: &Netlist, cfg: &DftCfg, i: usize| {
        let (si, so) = cfg.chains[i].0.split_once(':').map(|(a, b)| (a.to_string(), b.to_string())).unwrap_or_default();
        (port_loc(nl, &si), port_loc(nl, &so), si, so)
    };
    let before: Vec<f64> = sel.iter().map(|&i| {
        let (a, b, _, _) = ends(nl, cfg, i);
        chain_length(nl, a, b, &cells_of[i])
    }).collect();
    // repartition: per clock domain, pool cells and reassign to chains (lengths preserved) by regret
    if repartition {
        let mut doms: Vec<String> = sel.iter().map(|&i| cfg.chains[i].1.clone()).collect();
        doms.dedup();
        for dom in doms {
            let ch: Vec<usize> = sel.iter().copied().filter(|&i| cfg.chains[i].1 == dom).collect();
            if ch.len() < 2 {
                continue;
            }
            let anchors: Vec<(f64, f64)> = ch.iter().map(|&i| {
                let (a, b, _, _) = ends(nl, cfg, i);
                match (a, b) {
                    (Some(p), Some(q)) => ((p.0 + q.0) / 2.0, (p.1 + q.1) / 2.0),
                    _ => {
                        let v = &cells_of[i];
                        let (sx, sy) = v.iter().fold((0.0, 0.0), |s, c| { let l = nl.cell(*c).loc.unwrap(); (s.0 + l.0, s.1 + l.1) });
                        (sx / v.len().max(1) as f64, sy / v.len().max(1) as f64)
                    }
                }
            }).collect();
            let mut cap: Vec<usize> = ch.iter().map(|&i| cells_of[i].len()).collect();
            let mut pool: Vec<CellId> = ch.iter().flat_map(|&i| cells_of[i].clone()).collect();
            let dist = |c: CellId, k: usize| mdist(nl.cell(c).loc, Some(anchors[k]));
            pool.sort_by(|&x, &y| {
                let r = |c: CellId| {
                    let mut d: Vec<f64> = (0..anchors.len()).map(|k| dist(c, k)).collect();
                    d.sort_by(|a, b| a.partial_cmp(b).unwrap());
                    d.get(1).copied().unwrap_or(0.0) - d[0]
                };
                r(y).partial_cmp(&r(x)).unwrap().then(nl.cell(x).name.cmp(&nl.cell(y).name))
            });
            let mut newc: Vec<Vec<CellId>> = vec![vec![]; ch.len()];
            for c in pool {
                let k = (0..anchors.len()).filter(|&k| cap[k] > 0).min_by(|&a, &b| dist(c, a).partial_cmp(&dist(c, b)).unwrap()).unwrap();
                cap[k] -= 1;
                newc[k].push(c);
            }
            for (k, &i) in ch.iter().enumerate() {
                cells_of[i] = std::mem::take(&mut newc[k]);
            }
        }
    }
    // reorder + restitch
    let se_net = cfg.scan_enable.as_ref().and_then(|s| nl.port_by_name(s)).and_then(|p| nl.ports[p].net);
    let _ = se_net;
    let mut stats = vec![];
    let mut orphan_drivers: Vec<NetId> = vec![];
    for (k, &i) in sel.iter().enumerate() {
        let (sil, sol, si, so) = ends(nl, cfg, i);
        let pts: Vec<(f64, f64)> = cells_of[i].iter().map(|c| nl.cell(*c).loc.unwrap()).collect();
        let ord = order_path(&pts, sil, sol, passes);
        let mut newv: Vec<CellId> = ord.iter().map(|&j| cells_of[i][j]).collect();
        // keep the original order if it was already better (never make a chain longer)
        if !repartition && chain_length(nl, sil, sol, &newv) > before[k] - 1e-9 {
            newv = cells_of[i].clone();
        }
        let Some(sip) = nl.port_by_name(&si).and_then(|p| nl.ports[p].net) else { return Err(format!("scan-in port '{}' not found", si)) };
        let mut prev = sip;
        for &c in &newv {
            let lc = find_lc(libs, nl, c).ok_or_else(|| format!("no library cell for '{}'", nl.cell(c).name))?;
            let (sin, _) = scan_pins(lc).ok_or_else(|| format!("'{}' is not a scan cell", nl.cell(c).name))?;
            if let Some(old) = nl.cell(c).pin_net(&sin) {
                if old != prev {
                    orphan_drivers.push(old);
                }
            }
            nl.connect_name(c, &sin, prev);
            let q = scan_q(lc);
            prev = match nl.cell(c).pin_net(&q) {
                Some(n) => n,
                None => {
                    let n = nl.add_net(&format!("{}_so", nl.cell(c).name));
                    nl.connect_name(c, &q, n);
                    n
                }
            };
        }
        if let Some(p) = nl.port_by_name(&so) {
            if let Some(old) = nl.ports[p].net {
                if old != prev {
                    orphan_drivers.push(old);
                }
            }
            nl.connect_port(p, prev);
        }
        let after = chain_length(nl, sil, sol, &newv);
        stats.push(ReorderStat { chain: cfg.chains[i].0.clone(), cells: newv.len(), before: before[k], after });
        cfg.chains[i].2 = newv.iter().map(|c| nl.cell(*c).name.clone()).collect();
    }
    // remove buffers / delay cells that only fed the old scan connections
    let mut removed = 0;
    let mut work = orphan_drivers;
    while let Some(n) = work.pop() {
        if !nl.net_alive(n) || !nl.loads(n).is_empty() || nl.net(n).conns.iter().any(|p| matches!(p, PinRef::Port(_))) {
            continue;
        }
        if let Some(PinRef::Cell(d, _)) = nl.driver(n) {
            let bufinv = find_lc(libs, nl, d).map(|l| (l.is_buf || l.is_delay) && !l.is_seq()).unwrap_or(false);
            if bufinv && !nl.cell(d).frozen() {
                let ins: Vec<NetId> = nl.cell(d).pins.iter().filter(|p| p.dir == Dir::In).filter_map(|p| p.net).collect();
                nl.remove_cell(d);
                removed += 1;
                work.extend(ins);
            }
        }
    }
    nl.sweep_nets();
    Ok((stats, removed))
}

/// Structurally trace a chain from its scan-in port (through buffers/inverters); returns the cell order.
pub fn trace_chain(nl: &Netlist, libs: &[Library], si_port: &str, max: usize) -> Vec<String> {
    let mut out = vec![];
    let Some(mut n) = nl.port_by_name(si_port).and_then(|p| nl.ports[p].net) else { return out };
    let mut seen = std::collections::HashSet::new();
    'walk: for _ in 0..max {
        // breadth over buffer trees: find the scan cell whose SI is reached from n
        let mut frontier = vec![n];
        let mut steps = 0;
        while let Some(m) = frontier.pop() {
            steps += 1;
            if steps > 64 {
                break;
            }
            for l in nl.loads(m) {
                let PinRef::Cell(c, p) = l else { continue };
                let Some(lc) = find_lc(libs, nl, c) else { continue };
                if let Some((sin, _)) = scan_pins(lc) {
                    if nl.cell(c).pins[p].name == sin && seen.insert(c) {
                        out.push(nl.cell(c).name.clone());
                        match nl.cell(c).pin_net(&scan_q(lc)) {
                            Some(q) => {
                                n = q;
                                continue 'walk;
                            }
                            None => break 'walk,
                        }
                    }
                } else if (lc.is_buf || lc.is_inv || lc.is_delay) && !lc.is_seq() {
                    if let Some(o) = nl.cell(c).pins.iter().find(|q| q.dir == Dir::Out).and_then(|q| q.net) {
                        frontier.push(o);
                    }
                }
            }
        }
        break;
    }
    out
}
