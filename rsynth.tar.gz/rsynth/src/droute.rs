//! Detailed router and RC extraction.
//!
//! * Grid: uniform 3D track grid (pitch `g`, default half a placement site) over all routing
//!   layers; each layer routes in its preferred direction, M1 is for pin access (high cost).
//! * Pins: cell pins are spread across the cell width on M1; ports sit on their assigned layer.
//!   Pin nodes are owned by their net. Routing blockages and macros block their layers.
//! * Each net is grown as a Steiner tree: multi-target A* from every remaining pin to the tree.
//! * Negotiated congestion (PathFinder): node cost = base + history + present * occupancy;
//!   overflowing nets are ripped up and rerouted with rising present/history costs.
//! * Extraction: per-layer R/C per um and via R on the routed tree; per-sink Elmore delay.

use crate::netlist::*;
use std::cmp::Reverse;
use std::collections::{BinaryHeap, HashMap, HashSet};

pub const NONE: u32 = u32::MAX;

#[derive(Clone, Debug)]
pub struct RLayer {
    pub name: String,
    pub horiz: bool,
    /// R in kOhm/um, C in pF/um
    pub r: f64,
    pub c: f64,
}

#[derive(Clone, Debug, Default)]
pub struct RNet {
    pub net: NetId,
    /// tree: (node, parent node) ; root has parent NONE
    pub tree: Vec<(u32, u32)>,
    /// pin -> access node
    pub pins: Vec<(PinRef, u32)>,
    pub sig: u64,
    pub clock: bool,
    pub open: bool,
    /// non-default rule: neighbour tracks kept free on each side, wire width multiplier
    pub halo: u8,
    pub wmul: f32,
    /// layer range for wiring (route -min_layer / -max_layer, antenna layer jumps); 0 / 0 = all
    pub lmin: u8,
    pub lmax: u8,
}

#[derive(Clone, Debug)]
pub struct RouteDb {
    pub x0: f64,
    pub y0: f64,
    pub g: f64,
    pub nx: usize,
    pub ny: usize,
    pub layers: Vec<RLayer>,
    pub via_r: f64,
    pub via_c: f64,
    pub occ: Vec<u16>,
    pub hist: Vec<f32>,
    pub blocked: Vec<bool>,
    pub pin_owner: Vec<u32>,
    pub nets: HashMap<NetId, RNet>,
    pub iterations: usize,
    /// via type per via (keyed by its lower node): (type name, resistance factor)
    pub via_types: HashMap<u32, (String, f64)>,
    /// nodes between the routing tracks of their layer (LEF PITCH / OFFSET or DEF TRACKS):
    /// blocked for wiring; empty when no track pattern is applied
    pub offtrack: Vec<bool>,
    /// LEF minimum-area patches added after routing: node -> net
    pub patches: HashMap<u32, NetId>,
    /// grid nodes between neighbouring tracks, per layer (1 = every grid line is a track)
    pub tstep: Vec<usize>,
    /// LEF spacing per layer in grid steps: another net's metal within this many grid steps is a
    /// spacing conflict (negotiated like a short); empty / 0 = no check
    pub space_k: Vec<usize>,
}

#[derive(Clone, Debug, Default)]
pub struct RouteStats {
    pub nets: usize,
    pub routed: usize,
    pub opens: usize,
    pub shorts: usize,
    pub wl: f64,
    pub vias: usize,
    pub wl_layer: Vec<f64>,
    pub iterations: usize,
}

/// routed RC per net (for STA): total wire cap (pF) and per-load Elmore delay (ns)
#[derive(Clone, Debug, Default)]
pub struct RoutedRc {
    pub wire_c: HashMap<NetId, f64>,
    pub elmore: HashMap<PinRef, f64>,
    /// for SPEF: per net (driver/root node name list) reduced segments (from, to, R, C)
    pub segs: HashMap<NetId, Vec<(String, String, f64, f64)>>,
    /// RC trees for the delay calculator (rcnet)
    pub trees: HashMap<NetId, std::sync::Arc<crate::rcnet::RcTree>>,
    /// coupling capacitance for SPEF: (node, aggressor net, aggressor node, pF)
    pub coupling: HashMap<NetId, Vec<(String, NetId, String, f64)>>,
}

impl RouteDb {
    pub fn new(die: (f64, f64, f64, f64), g: f64, layers: Vec<RLayer>) -> RouteDb {
        let nx = ((die.2 - die.0) / g).ceil() as usize + 1;
        let ny = ((die.3 - die.1) / g).ceil() as usize + 1;
        let n = nx * ny * layers.len();
        RouteDb { x0: die.0, y0: die.1, g, nx, ny, layers, via_r: 0.005, via_c: 0.0001, occ: vec![0; n], hist: vec![0.0; n], blocked: vec![false; n], pin_owner: vec![NONE; n], nets: HashMap::new(), iterations: 0, via_types: HashMap::new(), offtrack: vec![], patches: HashMap::new(), tstep: vec![], space_k: vec![] }
    }
    #[inline]
    pub fn node(&self, x: usize, y: usize, l: usize) -> u32 {
        ((l * self.ny + y) * self.nx + x) as u32
    }
    #[inline]
    pub fn xyl(&self, n: u32) -> (usize, usize, usize) {
        let n = n as usize;
        let x = n % self.nx;
        let y = (n / self.nx) % self.ny;
        let l = n / (self.nx * self.ny);
        (x, y, l)
    }
    pub fn snap(&self, p: (f64, f64)) -> (usize, usize) {
        let x = (((p.0 - self.x0) / self.g).round().max(0.0) as usize).min(self.nx - 1);
        let y = (((p.1 - self.y0) / self.g).round().max(0.0) as usize).min(self.ny - 1);
        (x, y)
    }
    pub fn pos(&self, n: u32) -> (f64, f64, usize) {
        let (x, y, l) = self.xyl(n);
        (self.x0 + x as f64 * self.g, self.y0 + y as f64 * self.g, l)
    }
    /// the node at (x, y, l), or the nearest unblocked node of layer l (on a track)
    pub fn nearest_free(&self, x: usize, y: usize, l: usize) -> u32 {
        let me = self.node(x, y, l);
        if !self.blocked[me as usize] {
            return me;
        }
        for rad in 1..40i64 {
            for dx in -rad..=rad {
                for dy in -rad..=rad {
                    if dx.abs().max(dy.abs()) != rad { continue; }
                    let (nx, ny) = (x as i64 + dx, y as i64 + dy);
                    if nx < 0 || ny < 0 || nx as usize >= self.nx || ny as usize >= self.ny { continue; }
                    let nd = self.node(nx as usize, ny as usize, l);
                    if !self.blocked[nd as usize] { return nd; }
                }
            }
        }
        me
    }
    /// routed metal per layer: (net, rectangle) for every wire segment (preferred-direction runs
    /// merged), with the given wire width per layer (multiplied by the net's NDR width)
    pub fn wire_rects(&self, widths: &[f64]) -> Vec<Vec<(NetId, (f64, f64, f64, f64))>> {
        let mut out: Vec<Vec<(NetId, (f64, f64, f64, f64))>> = vec![vec![]; self.layers.len()];
        for (net, rn) in &self.nets {
            let wm = rn.wmul.max(1.0) as f64;
            for &(n, par) in &rn.tree {
                let (x, y, l) = self.pos(n);
                let w = widths.get(l).copied().unwrap_or(0.1) * wm / 2.0;
                if par == NONE {
                    out[l].push((*net, (x - w, y - w, x + w, y + w)));
                    continue;
                }
                let (px, py, pl) = self.pos(par);
                if pl != l {
                    // via: a landing on both layers
                    out[l].push((*net, (x - w, y - w, x + w, y + w)));
                    let wp = widths.get(pl).copied().unwrap_or(0.1) * wm / 2.0;
                    out[pl].push((*net, (px - wp, py - wp, px + wp, py + wp)));
                    continue;
                }
                out[l].push((*net, (x.min(px) - w, y.min(py) - w, x.max(px) + w, y.max(py) + w)));
            }
        }
        out
    }
    pub fn block_rect(&mut self, r: (f64, f64, f64, f64), layers: &[usize]) {
        let (x0, y0) = self.snap((r.0, r.1));
        let (x1, y1) = self.snap((r.2, r.3));
        for &l in layers {
            for y in y0..=y1 {
                for x in x0..=x1 {
                    let i = self.node(x, y, l) as usize;
                    self.blocked[i] = true;
                }
            }
        }
    }
    fn add_occ(&mut self, rn: &RNet, d: i32) {
        for (n, _) in &rn.tree {
            let o = &mut self.occ[*n as usize];
            *o = (*o as i32 + d).max(0) as u16;
        }
        // NDR: the neighbour tracks across the wire are taken as well (wider wire / double spacing)
        if rn.halo > 0 {
            let mut seen = std::collections::HashSet::new();
            for (n, _) in &rn.tree {
                let (x, y, l) = self.xyl(*n);
                let horiz = self.layers[l].horiz;
                for k in 1..=rn.halo as i64 {
                    for s in [-k, k] {
                        let (nx, ny) = if horiz { (x as i64, y as i64 + s) } else { (x as i64 + s, y as i64) };
                        if nx < 0 || ny < 0 || nx as usize >= self.nx || ny as usize >= self.ny { continue; }
                        let nb = self.node(nx as usize, ny as usize, l);
                        if !seen.insert(nb) { continue; }
                        let o = &mut self.occ[nb as usize];
                        *o = (*o as i32 + d).max(0) as u16;
                    }
                }
            }
        }
    }
}

/// pin access node of a pin (cell pins spread across the cell width on M1; ports on their layer)
pub fn pin_nodes(db: &RouteDb, nl: &Netlist, width: &dyn Fn(CellId) -> f64, port_layer: &dyn Fn(&str) -> usize, macro_side: f64, pins: &[PinRef], lef: &HashMap<String, crate::lef::LefMacro>) -> Vec<(PinRef, u32)> {
    let mut out = vec![];
    for &p in pins {
        match p {
            PinRef::Cell(c, i) => {
                let Some(l) = nl.cell(c).loc else { continue };
                // LEF pin shape: its centre on its layer, moved to the nearest unblocked node
                let sh = crate::lef::pin_shapes(lef, nl.cell(c), &nl.cell(c).pins[i].name);
                if let Some((ly, r)) = sh.first() {
                    let li = db.layers.iter().position(|x| x.name == *ly).unwrap_or(0);
                    let (x, y) = db.snap(((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0));
                    let mut best = db.node(x, y, li);
                    'search: for rad in 0..40i64 {
                        for dx in -rad..=rad {
                            for dy in -rad..=rad {
                                if dx.abs().max(dy.abs()) != rad { continue; }
                                let (nx, ny) = (x as i64 + dx, y as i64 + dy);
                                if nx < 0 || ny < 0 || nx as usize >= db.nx || ny as usize >= db.ny { continue; }
                                let nd = db.node(nx as usize, ny as usize, li);
                                if !db.blocked[nd as usize] { best = nd; break 'search; }
                            }
                        }
                    }
                    out.push((p, best));
                    continue;
                }
                if matches!(nl.cell(c).kind, Kind::BlackBox(_)) || width(c) > 8.0 {
                    // macro: pins spread along the bottom edge, just outside its obstruction
                    let side = if matches!(nl.cell(c).kind, Kind::BlackBox(_)) { macro_side } else { width(c).sqrt().max(2.0) };
                    let np = nl.cell(c).pins.len().max(1);
                    let px = l.0 - side / 2.0 + (i as f64 + 0.5) * side / np as f64;
                    let (x, y) = db.snap((px, l.1 - side / 2.0 - 2.0 * db.g));
                    out.push((p, db.node(x, y, 0)));
                    continue;
                }
                let w = width(c).max(db.g * 2.0);
                let np = nl.cell(c).pins.len().max(1);
                let px = l.0 - w / 2.0 + (i as f64 + 0.5) * w / np as f64;
                let (x, y) = db.snap((px, l.1));
                out.push((p, db.node(x, y, 0)));
            }
            PinRef::Port(q) => {
                let Some(l) = nl.ports[q].loc else { continue };
                let (x, y) = db.snap(l);
                let ly = port_layer(&nl.ports[q].name).min(db.layers.len() - 1);
                out.push((p, db.nearest_free(x, y, ly)));
            }
        }
    }
    out
}

pub fn sig_of(nl: &Netlist, pins: &[(PinRef, u32)]) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut v: Vec<(String, u32)> = pins.iter().map(|(p, n)| (nl.pin_name(*p), *n)).collect();
    v.sort();
    let mut h = std::collections::hash_map::DefaultHasher::new();
    v.hash(&mut h);
    h.finish()
}

struct Search {
    stamp: Vec<u32>,
    cur: u32,
    gcost: Vec<f32>,
    parent: Vec<u32>,
    tmark: Vec<u32>,
}

/// route one net as a tree; returns false if some pin could not be connected
fn route_net(db: &mut RouteDb, s: &mut Search, rn: &mut RNet, pres: f32, p: &RouteParams, net_id: u32) -> bool {
    let (via_cost, m1_cost) = (p.via_cost, p.m1_cost);
    let (lmin, lmax) = (rn.lmin as usize, if rn.lmax == 0 { usize::MAX } else { rn.lmax as usize });
    rn.tree.clear();
    rn.open = false;
    if rn.pins.is_empty() {
        return true;
    }
    s.cur += 1;
    let tstamp = s.cur;
    let root = rn.pins[0].1;
    rn.tree.push((root, NONE));
    s.tmark[root as usize] = tstamp;
    let (mut bx0, mut by0, _) = db.xyl(root);
    let (mut bx1, mut by1) = (bx0, by0);
    // connect pins in order of distance to the root
    let mut rest: Vec<u32> = rn.pins[1..].iter().map(|x| x.1).collect();
    let (rx, ry, _) = db.xyl(root);
    rest.sort_by_key(|n| {
        let (x, y, _) = db.xyl(*n);
        (x as i64 - rx as i64).abs() + (y as i64 - ry as i64).abs()
    });
    let mut ok = true;
    for src in rest {
        if s.tmark[src as usize] == tstamp {
            continue;
        }
        let (sx, sy, _) = db.xyl(src);
        let margin = 12 + ((bx1 - bx0) + (by1 - by0)) / 4;
        let mut found = None;
        for attempt in 0..2 {
            let m = if attempt == 0 { margin } else { db.nx.max(db.ny) };
            let wx0 = bx0.min(sx).saturating_sub(m);
            let wy0 = by0.min(sy).saturating_sub(m);
            let wx1 = (bx1.max(sx) + m).min(db.nx - 1);
            let wy1 = (by1.max(sy) + m).min(db.ny - 1);
            s.cur += 1;
            let st = s.cur;
            let h = |x: usize, y: usize| -> f32 {
                let dx = if x < bx0 { bx0 - x } else if x > bx1 { x - bx1 } else { 0 };
                let dy = if y < by0 { by0 - y } else if y > by1 { y - by1 } else { 0 };
                (dx + dy) as f32
            };
            let mut pq: BinaryHeap<Reverse<(u32, u32)>> = BinaryHeap::new();
            s.stamp[src as usize] = st;
            s.gcost[src as usize] = 0.0;
            s.parent[src as usize] = NONE;
            pq.push(Reverse((((h(sx, sy)) * 64.0) as u32, src)));
            while let Some(Reverse((_, u))) = pq.pop() {
                if s.tmark[u as usize] == tstamp {
                    found = Some(u);
                    break;
                }
                let gu = s.gcost[u as usize];
                let (x, y, l) = db.xyl(u);
                let horiz = db.layers[l].horiz;
                let mut nb: [(i64, i64, i64, f32); 6] = [(0, 0, 0, -1.0); 6];
                let mut k = 0;
                // M1 is pin access only: pins escape by a via to M2 (no lateral M1 wiring)
                // preferred direction cost 1, wrong-way jogs cost `m1_cost` (default 3)
                if l == 0 {
                    // M1: short horizontal escapes only, at a high cost (pins are the M1 owners)
                    nb[k] = (-1, 0, 0, 5.0);
                    nb[k + 1] = (1, 0, 0, 5.0);
                    k += 2;
                } else {
                    let (hc, vc) = if horiz { (1.0, m1_cost) } else { (m1_cost, 1.0) };
                    nb[k] = (-1, 0, 0, hc);
                    nb[k + 1] = (1, 0, 0, hc);
                    nb[k + 2] = (0, -1, 0, vc);
                    nb[k + 3] = (0, 1, 0, vc);
                    k += 4;
                }
                nb[k] = (0, 0, -1, via_cost);
                nb[k + 1] = (0, 0, 1, via_cost);
                for &(dx, dy, dl, c) in nb.iter() {
                    if c < 0.0 {
                        continue;
                    }
                    let (nx, ny, nlay) = (x as i64 + dx, y as i64 + dy, l as i64 + dl);
                    // layer range: no wiring below -min_layer (vias pass through), nothing above -max_layer
                    if dl == 0 && l > 0 && l < lmin { continue; }
                    if nlay as usize > lmax && nlay > 0 { continue; }
                    let c = if dl == 0 { c * p.layer_cost.get(l).copied().unwrap_or(1.0) } else { c };
                    if nx < wx0 as i64 || ny < wy0 as i64 || nx > wx1 as i64 || ny > wy1 as i64 || nlay < 0 || nlay >= db.layers.len() as i64 {
                        continue;
                    }
                    let v = db.node(nx as usize, ny as usize, nlay as usize);
                    let vi = v as usize;
                    if db.blocked[vi] {
                        continue;
                    }
                    // wiring only on the layer's tracks; vias may land between tracks (stacked access)
                    // (a one-step jog between an off-track via landing and the track is allowed)
                    if dl == 0 && l > 0 && !db.offtrack.is_empty() && db.offtrack[u as usize] && db.offtrack[vi] {
                        continue;
                    }
                    let po = db.pin_owner[vi];
                    if po != NONE && po != net_id {
                        continue;
                    }
                    let own = s.tmark[vi] == tstamp;
                    if p.legal_only && !own && db.occ[vi] > 0 { continue; }
                    let mut cong = if own { 0.0 } else { db.hist[vi] + pres * db.occ[vi] as f32 };
                    // litho: another net's wire at a forbidden pitch across the run
                    if dl == 0 && !own && p.fp_cost > 0.0 {
                        if let Some(fs) = p.fp_steps.get(nlay as usize) {
                            for &d in fs {
                                for side in [-d, d] {
                                    let (ax, ay) = if dx != 0 { (nx, ny + side) } else { (nx + side, ny) };
                                    if ax < 0 || ay < 0 || ax as usize >= db.nx || ay as usize >= db.ny { continue; }
                                    let an = db.node(ax as usize, ay as usize, nlay as usize) as usize;
                                    if db.occ[an] > 0 && s.tmark[an] != tstamp { cong += p.fp_cost; }
                                }
                            }
                        }
                    }
                    // LEF spacing: other nets' metal too close on this layer
                    if !own && nlay > 0 {
                        let k = db.space_k.get(nlay as usize).copied().unwrap_or(0) as i64;
                        if k > 0 {
                            let mut hits = 0;
                            'sp: for ex in -k..=k {
                                for ey in -k..=k {
                                    if ex == 0 && ey == 0 { continue; }
                                    let (ax, ay) = (nx + ex, ny + ey);
                                    if ax < 0 || ay < 0 || ax as usize >= db.nx || ay as usize >= db.ny { continue; }
                                    let an = db.node(ax as usize, ay as usize, nlay as usize) as usize;
                                    if db.occ[an] > 0 && s.tmark[an] != tstamp && an != u as usize {
                                        hits += 1;
                                        if hits >= 2 { break 'sp; }
                                    }
                                }
                            }
                            if hits > 0 {
                                if p.legal_only { continue; }
                                cong += pres * hits as f32 + db.hist[vi];
                            }
                        }
                    }
                    if p.adj_cost > 0.0 && dl == 0 && !own {
                        // wire spreading: neighbours on the adjacent tracks (perpendicular to the run)
                        let st = db.tstep.get(nlay as usize).copied().unwrap_or(1).max(1) as i64;
                        for side in [-st, st] {
                            let (ax, ay) = if dx != 0 { (nx, ny + side) } else { (nx + side, ny) };
                            if ax < 0 || ay < 0 || ax as usize >= db.nx || ay as usize >= db.ny { continue; }
                            let an = db.node(ax as usize, ay as usize, nlay as usize) as usize;
                            if db.occ[an] > 0 && s.tmark[an] != tstamp { cong += p.adj_cost; }
                        }
                    }
                    let gv = gu + c + cong;
                    if s.stamp[vi] != st || gv < s.gcost[vi] {
                        s.stamp[vi] = st;
                        s.gcost[vi] = gv;
                        s.parent[vi] = u;
                        let f = gv + h(nx as usize, ny as usize);
                        pq.push(Reverse(((f * 64.0) as u32, v)));
                    }
                }
            }
            if found.is_some() {
                break;
            }
        }
        match found {
            Some(hit) => {
                // walk back from the hit (tree) to src: parent pointers point toward src
                let mut path = vec![];
                let mut u = hit;
                while u != NONE {
                    path.push(u);
                    if u == src {
                        break;
                    }
                    u = s.parent[u as usize];
                }
                // path[0] = hit (in tree) ... path[last] = src
                for w in 1..path.len() {
                    let n = path[w];
                    if s.tmark[n as usize] != tstamp {
                        s.tmark[n as usize] = tstamp;
                        rn.tree.push((n, path[w - 1]));
                        let (x, y, _) = db.xyl(n);
                        bx0 = bx0.min(x);
                        by0 = by0.min(y);
                        bx1 = bx1.max(x);
                        by1 = by1.max(y);
                    }
                }
            }
            None => {
                ok = false;
                rn.open = true;
            }
        }
    }
    db.add_occ(rn, 1);
    ok
}

#[derive(Clone)]
pub struct RouteParams {
    pub max_iter: usize,
    pub via_cost: f32,
    pub m1_cost: f32,
    /// routing order hint (timing-driven: most critical first); nets not listed follow
    pub order: Vec<NetId>,
    /// legal-only reroute (wire spreading): other nets' metal and LEF spacing are hard limits
    pub legal_only: bool,
    /// litho-driven routing: per layer, parallel-wire centre distances (grid steps) to avoid
    pub fp_steps: Vec<Vec<i64>>,
    pub fp_cost: f32,
    /// wire spreading: extra cost per other-net wire on a neighbouring track
    pub adj_cost: f32,
    /// per-layer factor on lateral wiring cost (layer jumps for antenna, timing-driven layers)
    pub layer_cost: Vec<f32>,
}
impl RouteParams {
    pub fn basic(max_iter: usize, via_cost: f32, m1_cost: f32) -> Self {
        RouteParams { max_iter, via_cost, m1_cost, adj_cost: 0.0, layer_cost: vec![], order: vec![], legal_only: false, fp_steps: vec![], fp_cost: 0.0 }
    }
}

/// Route (or reroute) the nets in `todo` with negotiated congestion. Existing routes of other nets
/// stay in place and are only ripped up when they overflow.
pub fn route(db: &mut RouteDb, mut todo: Vec<RNet>, p: &RouteParams) -> RouteStats {
    // deterministic: the same nets route the same way whatever order the caller collected them in
    todo.sort_by_key(|r| r.net);
    let n = db.occ.len();
    let mut s = Search { stamp: vec![0; n], cur: 0, gcost: vec![0.0; n], parent: vec![NONE; n], tmark: vec![0; n] };
    // register pins (owned nodes) and remove old routes of nets being rerouted
    let mut ids: Vec<NetId> = vec![];
    for mut rn in todo {
        if let Some(old) = db.nets.remove(&rn.net) {
            db.add_occ(&old, -1);
            let up = (db.nx * db.ny) as u32;
            for (_, nd) in &old.pins {
                for n in [*nd, *nd + up] {
                    if (n as usize) < db.pin_owner.len() && db.pin_owner[n as usize] == rn.net as u32 {
                        db.pin_owner[n as usize] = NONE;
                    }
                }
            }
        }
        let me = rn.net as u32;
        let up = (db.nx * db.ny) as u32;
        for k in 0..rn.pins.len() {
            let nd = rn.pins[k].1;
            let (x, y, l) = db.xyl(nd);
            let free = |db: &RouteDb, n: u32| -> bool {
                let o = db.pin_owner[n as usize];
                (o == NONE || o == me) && !db.blocked[n as usize]
            };
            let ok_at = |db: &RouteDb, n: u32| -> bool { free(db, n) && (l != 0 || free(db, n + up)) };
            if !ok_at(db, nd) {
                // nudge along the row to the nearest free access point
                let mut best = None;
                for d in 1..40i64 {
                    for xx in [x as i64 - d, x as i64 + d] {
                        if xx < 0 || xx as usize >= db.nx {
                            continue;
                        }
                        let n2 = db.node(xx as usize, y, l);
                        if ok_at(db, n2) {
                            best = Some(n2);
                            break;
                        }
                    }
                    if best.is_some() {
                        break;
                    }
                }
                if let Some(n2) = best {
                    rn.pins[k].1 = n2;
                } else {
                    db.blocked[nd as usize] = false;
                }
            }
            let nd = rn.pins[k].1;
            db.pin_owner[nd as usize] = me;
            if l == 0 {
                db.pin_owner[(nd + up) as usize] = me;
                db.blocked[(nd + up) as usize] = false;
            }
            // off-track pin access: wiring may leave an off-track pin along its own line for a
            // couple of grid steps before it reaches a track
            if !db.offtrack.is_empty() {
                let (px, py, pl) = db.xyl(nd);
                for ll in [pl, pl + 1] {
                    if ll == 0 || ll >= db.layers.len() { continue; }
                    for dx in -6i64..=6 {
                        for dy in -6i64..=6 {
                            let (ax, ay) = (px as i64 + dx, py as i64 + dy);
                            if ax < 0 || ay < 0 || ax as usize >= db.nx || ay as usize >= db.ny { continue; }
                            let an = db.node(ax as usize, ay as usize, ll) as usize;
                            db.offtrack[an] = false;
                        }
                    }
                }
            }
        }
        rn.tree.clear();
        ids.push(rn.net);
        db.nets.insert(rn.net, rn);
    }
    // order: clock nets first, then small nets
    let prio: HashMap<NetId, usize> = p.order.iter().enumerate().map(|(k, n)| (*n, k)).collect();
    ids.sort_by_key(|i| {
        let r = &db.nets[i];
        (!r.clock, prio.get(i).copied().unwrap_or(usize::MAX), r.pins.len(), *i)
    });
    let mut pres = 0.5f32;
    let mut iter = 0;
    let mut work = ids.clone();
    let mut limit = p.max_iter;
    let mut relaxed: Option<Vec<bool>> = None;
    loop {
        for &i in &work {
            let mut rn = db.nets.remove(&i).unwrap();
            if !rn.tree.is_empty() {
                db.add_occ(&rn, -1);
            }
            route_net(db, &mut s, &mut rn, pres, p, i as u32);
            db.nets.insert(i, rn);
        }
        iter += 1;
        // overflow: shared nodes, and other-net metal within the LEF spacing
        let over: Vec<usize> = (0..n).filter(|&k| db.occ[k] > 1).collect();
        let sconf = spacing_conflicts(db);
        if over.is_empty() && sconf.is_empty() {
            break;
        }
        if iter >= limit {
            // shorts left with the track rule: the conflicting nets may wire off-track for a few
            // more rounds (check_route_rules reports that wiring) instead of staying shorted
            if relaxed.is_none() && !over.is_empty() && !db.offtrack.is_empty() && !p.legal_only {
                relaxed = Some(std::mem::take(&mut db.offtrack));
                limit = iter + 8;
            } else {
                break;
            }
        }
        for &k in &over {
            db.hist[k] += 0.4 * (db.occ[k] - 1) as f32;
        }
        for &(k, _) in &sconf {
            db.hist[k as usize] += 0.4;
        }
        pres *= 1.6;
        let oset: HashSet<u32> = over.iter().map(|&k| k as u32).collect();
        let snets: HashSet<NetId> = sconf.iter().map(|c| c.1).collect();
        work = db.nets.iter().filter(|(k, r)| snets.contains(k) || r.tree.iter().any(|(nd, _)| oset.contains(nd))).map(|(k, _)| *k).collect();
        work.sort_by_key(|i| {
            let r = &db.nets[i];
            (!r.clock, prio.get(i).copied().unwrap_or(usize::MAX), r.pins.len(), *i)
        });
    }
    if let Some(o) = relaxed { db.offtrack = o; }
    db.iterations = iter;
    stats(db)
}

/// metal nodes with another net's metal within the layer's LEF spacing (grid steps): (node, net)
pub fn spacing_conflicts(db: &RouteDb) -> Vec<(u32, NetId)> {
    if db.space_k.iter().all(|k| *k == 0) { return vec![]; }
    let mut owner: HashMap<u32, NetId> = HashMap::new();
    let mut ids: Vec<&NetId> = db.nets.keys().collect();
    ids.sort();
    for id in ids { for (nd, _) in &db.nets[id].tree { owner.insert(*nd, *id); } }
    let mut out = vec![];
    for (&nd, &id) in &owner {
        let (x, y, l) = db.xyl(nd);
        let k = db.space_k.get(l).copied().unwrap_or(0) as i64;
        if l == 0 || k == 0 { continue; }
        'n: for ex in -k..=k {
            for ey in -k..=k {
                if ex == 0 && ey == 0 { continue; }
                let (ax, ay) = (x as i64 + ex, y as i64 + ey);
                if ax < 0 || ay < 0 || ax as usize >= db.nx || ay as usize >= db.ny { continue; }
                if let Some(o) = owner.get(&db.node(ax as usize, ay as usize, l)) {
                    if *o != id { out.push((nd, id)); break 'n; }
                }
            }
        }
    }
    out.sort_unstable();
    out
}

pub fn stats(db: &RouteDb) -> RouteStats {
    let mut st = RouteStats { nets: db.nets.len(), wl_layer: vec![0.0; db.layers.len()], iterations: db.iterations, ..Default::default() };
    for r in db.nets.values() {
        if r.open {
            st.opens += 1;
        } else {
            st.routed += 1;
        }
        for (n, p) in &r.tree {
            if *p == NONE {
                continue;
            }
            let (_, _, l1) = db.xyl(*n);
            let (_, _, l2) = db.xyl(*p);
            if l1 != l2 {
                st.vias += 1;
            } else {
                st.wl += db.g;
                st.wl_layer[l1] += db.g;
            }
        }
    }
    st.shorts = db.occ.iter().filter(|o| **o > 1).count();
    st
}

/// Extraction settings (`extract_rc`). Fast mode uses the per-layer R/C as is; detailed mode
/// splits a wire's capacitance into area+fringe (1 - 2f) and two lateral parts f: a lateral part
/// facing a wire of another net on the adjacent track becomes coupling capacitance
/// (x `coupled`), otherwise it goes to ground (x `isolated`).
#[derive(Clone, Copy, Debug)]
pub struct ExtractMode {
    pub detailed: bool,
    pub lateral: f64,
    pub coupled: f64,
    pub isolated: f64,
}
impl Default for ExtractMode {
    fn default() -> Self {
        ExtractMode { detailed: false, lateral: 0.3, coupled: 1.2, isolated: 0.5 }
    }
}

/// Extract per-sink Elmore delays and wire caps. `pin_cap` gives the load pin capacitance.
pub fn extract(db: &RouteDb, pin_cap: &dyn Fn(PinRef) -> f64, name_of: &dyn Fn(PinRef) -> String, nl_is_driver: &dyn Fn(&PinRef) -> bool) -> RoutedRc {
    extract_mode(db, pin_cap, name_of, nl_is_driver, ExtractMode::default())
}

pub fn extract_mode(db: &RouteDb, pin_cap: &dyn Fn(PinRef) -> f64, name_of: &dyn Fn(PinRef) -> String, nl_is_driver: &dyn Fn(&PinRef) -> bool, mode: ExtractMode) -> RoutedRc {
    let mut rc = RoutedRc::default();
    // grid node -> (net, tree index) for coupling look-ups; nodes shared by two nets are skipped
    let mut owner: HashMap<u32, (NetId, usize)> = HashMap::new();
    if mode.detailed {
        let mut dup: HashSet<u32> = HashSet::new();
        for (net, r) in &db.nets {
            for (i, (n, _)) in r.tree.iter().enumerate() {
                if owner.insert(*n, (*net, i)).is_some() {
                    dup.insert(*n);
                }
            }
        }
        for d in dup {
            owner.remove(&d);
        }
    }
    // pass 1: node names per net (pins name their access node, other kept nodes their index)
    let mut names: HashMap<NetId, HashMap<usize, String>> = HashMap::new();
    for (net, r) in &db.nets {
        let idx: HashMap<u32, usize> = r.tree.iter().enumerate().map(|(i, (n, _))| (*n, i)).collect();
        let mut m: HashMap<usize, Vec<String>> = HashMap::new();
        for (p, nd) in &r.pins {
            if let Some(i) = idx.get(nd) {
                m.entry(*i).or_default().push(name_of(*p));
            }
        }
        names.insert(*net, m.into_iter().map(|(k, mut v)| { v.sort(); (k, v[0].clone()) }).collect());
    }
    let mode_name: &'static str = if mode.detailed { "extract-detailed" } else { "extract-fast" };
    let mut kept_name: HashMap<NetId, Vec<String>> = HashMap::new();
    let mut raw_cc: Vec<(NetId, Vec<(String, NetId, usize, f64)>)> = vec![];
    for (net, r) in &db.nets {
        if r.tree.is_empty() {
            continue;
        }
        let idx: HashMap<u32, usize> = r.tree.iter().enumerate().map(|(i, (n, _))| (*n, i)).collect();
        let m = r.tree.len();
        let mut cap = vec![0.0f64; m];
        let mut wcap = vec![0.0f64; m];
        let mut res = vec![0.0f64; m];
        let mut par = vec![usize::MAX; m];
        let mut wire_c = 0.0;
        // coupling: (node, aggressor net, aggressor tree index, pF)
        let mut ccs: Vec<(usize, NetId, usize, f64)> = vec![];
        for (i, (n, p)) in r.tree.iter().enumerate() {
            if *p == NONE {
                continue;
            }
            let Some(&pi) = idx.get(p) else { continue };
            par[i] = pi;
            let (x1, y1, l1) = db.xyl(*n);
            let (x2, y2, l2) = db.xyl(*p);
            let (rr, mut cc) = if l1 != l2 { (db.via_r * db.via_types.get(&if l1 < l2 { *n } else { *p }).map(|v| v.1).unwrap_or(1.0), db.via_c) } else {
                // NDR width: R scales down with the width, area capacitance up (fringe unchanged)
                let w = (r.wmul as f64).max(1.0);
                (db.layers[l1].r * db.g / w, db.layers[l1].c * db.g * (0.5 + 0.5 * w))
            };
            if mode.detailed && l1 == l2 {
                // the two tracks beside this unit segment
                let base = cc;
                cc = base * (1.0 - 2.0 * mode.lateral);
                let horiz = y1 == y2;
                for side in [-1i64, 1] {
                    let nb = |x: usize, y: usize| -> Option<u32> {
                        let (nx, ny) = if horiz { (x as i64, y as i64 + side) } else { (x as i64 + side, y as i64) };
                        if nx < 0 || ny < 0 || nx as usize >= db.nx || ny as usize >= db.ny { None } else { Some(db.node(nx as usize, ny as usize, l1)) }
                    };
                    let a = nb(x1, y1).and_then(|q| owner.get(&q)).filter(|o| o.0 != *net).copied();
                    let b = nb(x2, y2).and_then(|q| owner.get(&q)).filter(|o| o.0 != *net).copied();
                    let lat = base * mode.lateral;
                    match (a, b) {
                        (Some(oa), Some(ob)) if oa.0 == ob.0 => ccs.push((i, oa.0, oa.1, lat * mode.coupled)),
                        (Some(o), _) | (_, Some(o)) => {
                            ccs.push((i, o.0, o.1, 0.5 * lat * mode.coupled));
                            cc += 0.5 * lat * mode.isolated;
                        }
                        _ => cc += lat * mode.isolated,
                    }
                }
            }
            res[i] = rr;
            cap[i] += cc / 2.0;
            cap[pi] += cc / 2.0;
            wcap[i] += cc / 2.0;
            wcap[pi] += cc / 2.0;
            wire_c += cc;
        }
        let mut cpin = vec![0.0f64; m];
        for (pr, nd) in &r.pins {
            if let Some(&i) = idx.get(nd) {
                if i != 0 {
                    let pc = pin_cap(*pr);
                    cap[i] += pc;
                    cpin[i] += pc;
                }
            }
        }
        // downstream caps (tree is in parent-before-child order); coupling counted grounded
        let mut down = cap.clone();
        for (i, _, _, c) in &ccs {
            down[*i] += c;
        }
        for i in (1..m).rev() {
            if par[i] != usize::MAX {
                let d = down[i];
                down[par[i]] += d;
            }
        }
        let mut delay = vec![0.0f64; m];
        for i in 1..m {
            if par[i] != usize::MAX {
                delay[i] = delay[par[i]] + res[i] * down[i];
            }
        }
        for (pr, nd) in &r.pins {
            if let Some(&i) = idx.get(nd) {
                // loads on the driver's own access node have zero wire delay
                if i != 0 || !nl_is_driver(pr) {
                    rc.elmore.insert(*pr, delay[i]);
                }
            }
        }
        let cc_total: f64 = ccs.iter().map(|x| x.3).sum();
        rc.wire_c.insert(*net, wire_c + cc_total);
        // RC tree for the delay calculator (orphans are attached to the root with no R)
        let mut t = crate::rcnet::RcTree { src: mode_name, ..Default::default() };
        for i in 0..m {
            let p = if i == 0 { crate::rcnet::ROOT } else if par[i] == usize::MAX { 0 } else { par[i] as u32 };
            t.add_node(p, if i == 0 { 0.0 } else { res[i] }, cap[i]);
            t.cpin[i] = cpin[i];
        }
        for (pr, nd) in &r.pins {
            if let Some(&i) = idx.get(nd) {
                t.pins.push((*pr, i as u32));
            }
        }
        // put the driver's access node first (it is the root by construction)
        t.cc = ccs.iter().map(|(i, a, _, c)| (*i as u32, *a, *c)).collect();
        rc.trees.insert(*net, std::sync::Arc::new(t));
        // reduced segments for SPEF: keep pins, branch points, layer changes and coupled nodes
        let mut deg = vec![0usize; m];
        for i in 1..m {
            if par[i] != usize::MAX {
                deg[par[i]] += 1;
            }
        }
        let coupled: HashSet<usize> = ccs.iter().map(|x| x.0).collect();
        let pin_names = &names[net];
        let mut pin_at: HashMap<usize, Vec<String>> = HashMap::new();
        for (p, nd) in &r.pins {
            if let Some(i) = idx.get(nd) {
                pin_at.entry(*i).or_default().push(name_of(*p));
            }
        }
        for v in pin_at.values_mut() {
            v.sort();
        }
        let keep = |i: usize| -> bool { i == 0 || deg[i] != 1 || pin_at.contains_key(&i) || coupled.contains(&i) };
        let nm = |i: usize| -> String { pin_names.get(&i).cloned().unwrap_or_else(|| format!("{}", i)) };
        let mut segs = vec![];
        // wire capacitance at the root (driver) node: a capacitance-only entry (from == to)
        if m > 0 && wcap[0] > 0.0 {
            segs.push((nm(0), nm(0), 0.0, wcap[0]));
        }
        for (_, v) in pin_at.iter() {
            for extra in &v[1..] {
                segs.push((v[0].clone(), extra.clone(), 1e-6, 0.0));
            }
        }
        for i in 1..m {
            if !keep(i) || par[i] == usize::MAX {
                continue;
            }
            // walk up to the previous kept node accumulating R and C
            let (mut rr, mut cc) = (0.0, 0.0);
            let mut j = i;
            loop {
                rr += res[j];
                cc += wcap[j];
                let p = par[j];
                if p == usize::MAX || keep(p) {
                    segs.push((nm(p.min(m - 1)), nm(i), rr, cc));
                    break;
                }
                j = p;
            }
        }
        rc.segs.insert(*net, segs);
        // name of the nearest kept node at / above every tree node (aggressor references)
        let mut kn: Vec<String> = Vec::with_capacity(m);
        for i in 0..m {
            let v = if keep(i) || par[i] == usize::MAX { nm(i) } else { kn[par[i]].clone() };
            kn.push(v);
        }
        if !ccs.is_empty() {
            raw_cc.push((*net, ccs.iter().map(|(i, a, j, c)| (nm(*i), *a, *j, *c)).collect()));
        }
        kept_name.insert(*net, kn);
    }
    for (net, v) in raw_cc {
        let cl: Vec<(String, NetId, String, f64)> = v.into_iter().map(|(n, a, j, c)| {
            let an = kept_name.get(&a).and_then(|k| k.get(j)).cloned().unwrap_or_else(|| "0".into());
            (n, a, an, c)
        }).collect();
        rc.coupling.insert(net, cl);
    }
    rc
}

/// DEF NETS routing statements for one net: maximal straight runs per layer, plus vias
pub fn def_routes(db: &RouteDb, r: &RNet, dbu: f64) -> Vec<String> {
    let u = |v: f64| (v * dbu).round() as i64;
    let idx: HashMap<u32, usize> = r.tree.iter().enumerate().map(|(i, (n, _))| (*n, i)).collect();
    let m = r.tree.len();
    let mut nchild = vec![0usize; m];
    for (_, p) in &r.tree {
        if let Some(&pi) = idx.get(p) {
            nchild[pi] += 1;
        }
    }
    let pins: HashSet<u32> = r.pins.iter().map(|x| x.1).collect();
    let dir = |a: u32, b: u32| -> (i64, i64, i64) {
        let (x1, y1, l1) = db.xyl(a);
        let (x2, y2, l2) = db.xyl(b);
        ((x2 as i64 - x1 as i64).signum(), (y2 as i64 - y1 as i64).signum(), l2 as i64 - l1 as i64)
    };
    let mut out = vec![];
    for (i, (n, p)) in r.tree.iter().enumerate() {
        if *p == NONE {
            continue;
        }
        let d = dir(*n, *p);
        if d.2 != 0 {
            let (x, y, l1) = db.pos(*n);
            let (_, _, l2) = db.pos(*p);
            let lo = l1.min(l2);
            let lon = if l1 < l2 { *n } else { *p };
            let vname = db.via_types.get(&lon).map(|v| v.0.clone()).unwrap_or(format!("VIA{}{}", lo + 1, lo + 2));
            out.push(format!("{} ( {} {} ) {}", db.layers[lo].name, u(x), u(y), vname));
            continue;
        }
        // start a run only where the edge below does not continue in the same direction
        let continues_from_child = r.tree.iter().any(|(c, cp)| cp == n && dir(*c, *n) == d) && nchild[i] == 1 && !pins.contains(n);
        if continues_from_child {
            continue;
        }
        // extend toward the root while straight, unbranched and not at a pin
        let mut end = *p;
        loop {
            let Some(&ei) = idx.get(&end) else { break };
            let (_, ep) = r.tree[ei];
            if ep == NONE || nchild[ei] != 1 || pins.contains(&end) || dir(end, ep) != d {
                break;
            }
            end = ep;
        }
        let (x1, y1, l) = db.pos(*n);
        let (x2, y2, _) = db.pos(end);
        out.push(format!("{} ( {} {} ) ( {} {} )", db.layers[l].name, u(x1), u(y1), if x2 == x1 { "*".to_string() } else { u(x2).to_string() }, if y2 == y1 { "*".to_string() } else { u(y2).to_string() }));
    }
    out
}
