//! Delay-calculation commands and parasitic sources.
//!
//!  set_delay_calculation [-model elmore|d2m|awe] [-ceff true|false] [-miller f]
//!                        [-global_route_parasitics true|false] [-layer_thresholds {um um}]
//!  report_delay_calculation [-from drv_pin -to load_pin [-input_slew ns] [-reference]]
//!  check_delay_calculation [-nets n] [-input_slew ns]          models vs transient reference
//!  report_rc_correlation [-nets n]                              global route vs extraction
//!  extract_rc [-mode fast|detailed] [-lateral f] [-coupled k] [-isolated k]
//!  report_net_parasitics -net name                              RC tree summary of one net

use crate::droute::RoutedRc;
use crate::netlist::*;
use crate::rcnet::{self, Model, RcTree};
use crate::session::{args, Session};
use crate::tcl::{err, Flow, R};
use std::collections::HashMap;
use std::sync::Arc;

fn bool_arg(v: &str) -> Option<bool> {
    match v.to_lowercase().as_str() {
        "true" | "1" | "on" | "yes" => Some(true),
        "false" | "0" | "off" | "no" => Some(false),
        _ => None,
    }
}

impl Session {
    pub(crate) fn gr_params(&self) -> crate::grtime::GrParams {
        let th: Vec<f64> = self.app.get("time.gr_layer_thresholds").map(|s| s.split_whitespace().filter_map(|x| x.parse().ok()).collect()).unwrap_or_default();
        let seg = self.appf("time.gr_segment_length");
        crate::grtime::GrParams { layers: self.route_layers(), via_r: 0.005, via_c: 0.0001, thresholds: th, seg_um: if seg > 0.0 { seg } else { 10.0 } }
    }

    fn pin_cap_of(&self, p: PinRef) -> f64 {
        let Some(nl) = self.nl.as_ref() else { return 0.0 };
        match p {
            PinRef::Cell(c, i) => nl.cell(c).lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).and_then(|lc| lc.pin(&nl.cell(c).pins[i].name)).map(|x| x.cap).unwrap_or(0.001),
            PinRef::Port(_) => 0.0,
        }
    }

    /// signature of everything the global-route trees depend on
    fn gr_signature(&self) -> u64 {
        let mut h: u64 = 0xcbf2_9ce4_8422_2325 ^ self.epoch.get();
        let mix = |h: &mut u64, v: u64| { *h ^= v; *h = h.wrapping_mul(0x1000_0000_01b3); };
        if let Some(nl) = self.nl.as_ref() {
            mix(&mut h, nl.cells.len() as u64);
            for c in nl.cell_ids() {
                if let Some((x, y)) = nl.cell(c).loc {
                    mix(&mut h, x.to_bits() ^ y.to_bits().rotate_left(17));
                }
            }
        }
        if let Some(g) = self.fp.as_ref().and_then(|f| f.groute.as_ref()) {
            mix(&mut h, g.wirelength.to_bits());
        }
        for k in ["time.gr_layer_thresholds", "time.gr_segment_length", "time.wire_r_per_um", "time.wire_c_per_um"] {
            for b in self.app.get(k).map(|s| s.as_bytes().to_vec()).unwrap_or_default() {
                mix(&mut h, b as u64);
            }
        }
        h
    }

    /// Global-route timing engine trees (cached); built from the placement and global route.
    pub(crate) fn gr_build(&self) -> Option<(Arc<RoutedRc>, crate::grtime::GrStats)> {
        let nl = self.nl.as_ref()?;
        let fp = self.fp.as_ref()?;
        let p = self.gr_params();
        let cap = |q: PinRef| self.pin_cap_of(q);
        let gr = fp.groute.as_ref().map(|g| &g.net_len);
        let (rc, st) = crate::grtime::build(nl, &p, gr, &cap, &|_| false);
        Some((Arc::new(rc), st))
    }

    pub(crate) fn gr_parasitics(&self) -> Option<Arc<RoutedRc>> {
        if !self.appb("time.global_route_parasitics") || self.fp.is_none() {
            return None;
        }
        let sig = self.gr_signature();
        if let Some((s, rc)) = self.gr_cache.borrow().as_ref() {
            if *s == sig {
                return Some(rc.clone());
            }
        }
        let (rc, st) = self.gr_build()?;
        crate::info!("DC-110", "Global-route timing engine: {} net(s), {} RC node(s), {} Steiner point(s), wirelength {:.1}um, {} net(s) stretched to their global-route length",
            st.nets, st.nodes, st.steiner_pts, st.wl, st.detoured);
        *self.gr_cache.borrow_mut() = Some((sig, rc.clone()));
        Some(rc)
    }

    pub(crate) fn extract_mode(&self) -> crate::droute::ExtractMode {
        let d = crate::droute::ExtractMode::default();
        let f = |k: &str, dv: f64| { let v = self.appf(k); if v > 0.0 { v } else { dv } };
        crate::droute::ExtractMode {
            detailed: self.app.get("extract.mode").map(|s| s == "detailed").unwrap_or(false),
            lateral: f("extract.lateral_fraction", d.lateral).min(0.49),
            coupled: f("extract.coupled_scale", d.coupled),
            isolated: f("extract.isolated_scale", d.isolated),
        }
    }

    /// parasitics the delay calculator currently uses (+ a label)
    fn dc_source(&self) -> Option<(Arc<RoutedRc>, String)> {
        if let Some(rc) = self.spef_rc.values().next() {
            return Some((rc.clone(), "read_parasitics (SPEF)".into()));
        }
        if let Some(rc) = self.routed_rc.clone() {
            let m = if self.extract_mode().detailed { "detailed" } else { "fast" };
            return Some((rc, format!("post-route extraction ({})", m)));
        }
        self.gr_parasitics().map(|rc| (rc, "global-route timing engine".into()))
    }

    fn dc_model(&self) -> Model {
        Model::parse(self.app.get("time.delay_calculation_model").map(|s| s.as_str()).unwrap_or("elmore")).unwrap_or(Model::Elmore)
    }
    fn miller(&self) -> f64 {
        let m = self.appf("time.coupling_miller_factor");
        if m > 0.0 { m } else { 1.0 }
    }

    pub fn dcalc_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "set_delay_calculation" => self.c_set_dc(a),
            "report_delay_calculation" => self.c_report_dc(a),
            "check_delay_calculation" => self.c_check_dc(a),
            "report_rc_correlation" => self.c_rc_corr(a),
            "extract_rc" => self.c_extract_rc(a),
            "report_net_parasitics" => self.c_net_para(a),
            _ => return self.chipfp_cmd(name, a),
        })
    }

    fn c_set_dc(&mut self, a: &[String]) -> R {
        let x = args(a, &["-model", "-ceff", "-miller", "-global_route_parasitics", "-layer_thresholds", "-segment_length"]);
        if let Some(m) = x.get("-model") {
            let Some(md) = Model::parse(m) else { return err(&format!("-model '{}': expected elmore, d2m or awe (DC-001)", m)) };
            self.app.insert("time.delay_calculation_model".into(), md.name().into());
        }
        for (o, k) in [("-ceff", "time.delay_calculation_ceff"), ("-global_route_parasitics", "time.global_route_parasitics")] {
            if let Some(v) = x.get(o) {
                let Some(b) = bool_arg(v) else { return err(&format!("{} '{}': expected true or false (DC-002)", o, v)) };
                self.app.insert(k.into(), b.to_string());
            }
        }
        if let Some(v) = x.get("-miller") {
            match v.parse::<f64>() {
                Ok(f) if (0.0..=4.0).contains(&f) => { self.app.insert("time.coupling_miller_factor".into(), f.to_string()); }
                _ => return err(&format!("-miller '{}': expected a factor in 0..4 (DC-003)", v)),
            }
        }
        if let Some(v) = x.get("-layer_thresholds") {
            let t: Vec<f64> = v.split(|c: char| c.is_whitespace() || c == '{' || c == '}').filter_map(|s| s.parse().ok()).collect();
            if t.is_empty() { return err("-layer_thresholds: expected a list of lengths in um (DC-004)"); }
            self.app.insert("time.gr_layer_thresholds".into(), t.iter().map(|x| x.to_string()).collect::<Vec<_>>().join(" "));
        }
        if let Some(v) = x.get("-segment_length") {
            self.app.insert("time.gr_segment_length".into(), v.clone());
        }
        *self.gr_cache.borrow_mut() = None;
        crate::info!("DC-100", "Delay calculation: model {}, effective capacitance {}, Miller factor {}, global-route parasitics {}",
            self.dc_model().name(), if self.appb("time.delay_calculation_ceff") { "on" } else { "off" }, self.miller(),
            if self.appb("time.global_route_parasitics") { "on" } else { "off" });
        Ok(String::new())
    }

    // ------------------------------------------------------------------ net report
    fn c_report_dc(&mut self, a: &[String]) -> R {
        let mut x = args(a, &["-from", "-to", "-input_slew", "-net"]);
        // -net n / -worst: driver of the net -> its slowest sink
        if x.get("-net").is_some() || x.has("-worst") {
            let (rc, _) = self.dc_source().ok_or_else(|| Flow::Err("no RC parasitics (DC-011)".into()))?;
            let nl = self.nl()?;
            let miller = self.miller();
            let pick = |t: &RcTree| -> Option<(PinRef, PinRef, f64)> {
                let m = t.moments(miller);
                let drv = t.pins.iter().find(|(p, n)| *n == 0 && nl.is_driver(*p))?.0;
                let (ld, e) = t.pins.iter().filter(|(_, n)| *n != 0).map(|(p, n)| (*p, rcnet::elmore(&m[*n as usize]))).max_by(|a, b| a.1.partial_cmp(&b.1).unwrap())?;
                Some((drv, ld, e))
            };
            let sel = match x.get("-net") {
                Some(nm) => {
                    let n = nl.net_by_name(nm).or_else(|| nl.port_by_name(nm).and_then(|p| nl.ports[p].net)).ok_or_else(|| Flow::Err(format!("net '{}' not found (DC-013)", nm)))?;
                    rc.trees.get(&n).and_then(|t| pick(t)).ok_or_else(|| Flow::Err(format!("net '{}' has no RC tree (DC-012)", nm)))?
                }
                // the most resistive net driven by a library cell (so that Ceff can be shown)
                None => rc.trees.values().filter(|t| t.len() < 20000).filter_map(|t| pick(t))
                    .filter(|s| self.drv_arc(s.0).is_some()).max_by(|a, b| a.2.partial_cmp(&b.2).unwrap())
                    .ok_or_else(|| Flow::Err("no RC trees (DC-012)".into()))?,
            };
            x.o.insert("-from".into(), nl.pin_name(sel.0));
            x.o.insert("-to".into(), nl.pin_name(sel.1));
        }
        let (Some(from), Some(to)) = (x.get("-from"), x.get("-to")) else {
            // settings + source summary
            crate::out!("****************************************\nReport : delay_calculation\n****************************************");
            crate::out!("Interconnect model      : {}", self.dc_model().name());
            crate::out!("Effective capacitance   : {}", if self.appb("time.delay_calculation_ceff") { "on (pi model, ramp charge matching)" } else { "off (total capacitance)" });
            crate::out!("Coupling Miller factor  : {}", self.miller());
            crate::out!("Global-route parasitics : {} (layer thresholds {} um)", if self.appb("time.global_route_parasitics") { "on" } else { "off" },
                self.app.get("time.gr_layer_thresholds").cloned().unwrap_or_default());
            crate::out!("Extraction mode         : {}", self.app.get("extract.mode").cloned().unwrap_or_default());
            match self.dc_source() {
                Some((rc, lab)) => {
                    let nodes: usize = rc.trees.values().map(|t| t.len()).sum();
                    let cc: f64 = rc.trees.values().map(|t| t.coupling_cap()).sum();
                    let wc: f64 = rc.trees.values().map(|t| t.wire_cap()).sum();
                    crate::out!("Parasitics in use       : {}: {} RC tree(s), {} node(s), wire cap {:.4} pF of which coupling {:.4} pF", lab, rc.trees.len(), nodes, wc, cc);
                }
                None => crate::out!("Parasitics in use       : none (lumped length-based estimates)"),
            }
            return Ok(String::new());
        };
        let nl = self.nl()?;
        let fp = nl.find_pin(from).ok_or_else(|| Flow::Err(format!("pin '{}' not found (DC-010)", from)))?;
        let tp = nl.find_pin(to).ok_or_else(|| Flow::Err(format!("pin '{}' not found (DC-010)", to)))?;
        let (rc, lab) = self.dc_source().ok_or_else(|| Flow::Err("no RC parasitics: place + global route with -global_route_parasitics true, route, or read_parasitics (DC-011)".into()))?;
        let (net, t) = rc.trees.iter().find(|(_, t)| t.node_of(fp) == Some(0) && t.node_of(tp).is_some())
            .map(|(n, t)| (*n, t.clone())).ok_or_else(|| Flow::Err(format!("no RC tree drives '{}' from '{}' (DC-012)", to, from)))?;
        let sin: f64 = x.get("-input_slew").and_then(|v| v.parse().ok()).unwrap_or(0.05);
        let miller = self.miller();
        let mom = t.moments(miller);
        let nd = t.node_of(tp).unwrap();
        let m = mom[nd];
        crate::out!("****************************************\nReport : delay_calculation\nNet    : {} ({} RC nodes, {} pins, source: {})\nArc    : {} -> {}\n****************************************",
            nl.net(net).name, t.len(), t.pins.len(), lab, from, to);
        crate::out!("Total R {:.4} kOhm   ground C {:.5} pF   coupling C {:.5} pF (Miller {})   pin C {:.5} pF",
            t.total_r(), t.c.iter().sum::<f64>() - t.cpin.iter().sum::<f64>(), t.coupling_cap(), miller, t.cpin.iter().sum::<f64>());
        crate::out!("Moments at the load : m1 {:.6e}  m2 {:.6e}  m3 {:.6e}", m.m1, m.m2, m.m3);
        let p = rcnet::awe(&m);
        if p.n == 2 {
            crate::out!("AWE (2-pole Pade)   : poles {:.4e} {:.4e} 1/ns, residues {:.4} {:.4}", p.p[0], p.p[1], p.k[0], p.k[1]);
        } else {
            crate::out!("AWE                 : 2-pole fit unstable -> 1 pole, tau {:.4e} ns", -1.0 / p.p[0]);
        }
        let reference = x.has("-reference");
        let refr = if reference { Some(t.simulate(1e-6, sin / 0.8, miller, &[nd])[0]) } else { None };
        crate::out!("\nInput slew {:.4} ns (10-90)       wire delay (ns)    output slew (ns){}", sin, if reference { "   delay err  slew err" } else { "" });
        for md in [Model::Elmore, Model::D2m, Model::Awe] {
            let (d, s) = rcnet::wire_delay(md, &m, sin);
            let mut line = format!("  {:<30} {:>14.5} {:>16.5}", match md { Model::Elmore => "Elmore", Model::D2m => "D2M / S2M (PERI)", Model::Awe => "AWE 2-pole ramp response" }, d, s);
            if let Some(r) = refr {
                let rd = r.0 - sin / 0.8 / 2.0;
                let rs = r.2 - r.1;
                line += &format!("   {:>+8.2}%  {:>+8.2}%", 100.0 * (d - rd) / rd.max(1e-12), 100.0 * (s - rs) / rs.max(1e-12));
            }
            crate::out!("{}", line);
        }
        if let Some(r) = refr {
            crate::out!("  {:<30} {:>14.5} {:>16.5}", "reference (transient)", r.0 - sin / 0.8 / 2.0, r.2 - r.1);
        }
        // driver: pi model + Ceff with the driver's tables
        let pi = t.pi_model(&mom, miller);
        crate::out!("\nDriving-point pi model: C1 {:.5} pF  R {:.4} kOhm  C2 {:.5} pF  (Ctotal {:.5} pF)", pi.c1, pi.r, pi.c2, pi.c1 + pi.c2);
        if let Some(arc) = self.drv_arc(fp) {
            let (dt, tr) = arc;
            let (ce, it) = rcnet::ceff_iterate(&pi, &|c| tr.delay(sin, c));
            let ctot = pi.c1 + pi.c2;
            crate::out!("Ceff {:.5} pF after {} iteration(s) ({:.1}% of Ctotal)", ce, it, 100.0 * ce / ctot.max(1e-12));
            crate::out!("  driver delay  at Ctotal {:.5} ns   at Ceff {:.5} ns", dt.delay(sin, ctot), dt.delay(sin, ce));
            crate::out!("  driver slew   at Ctotal {:.5} ns   at Ceff {:.5} ns", tr.delay(sin, ctot), tr.delay(sin, ce));
            if reference {
                // Thevenin driver from the table slope; compare the driver-pin 50 % point of the
                // full RC tree with a lumped Ceff and a lumped Ctotal
                let (c1, c2) = (ctot * 0.5, ctot * 1.5);
                let rd = ((dt.delay(sin, c2) - dt.delay(sin, c1)) / (c2 - c1) / std::f64::consts::LN_2).max(1e-3);
                let t_ramp = (tr.delay(sin, 0.0).max(1e-3)) / 0.8;
                let full = t.simulate(rd, t_ramp, miller, &[0])[0].0;
                let lump = |c: f64| { let mut l = RcTree::default(); l.add_node(rcnet::ROOT, 0.0, c); l.simulate(rd, t_ramp, 1.0, &[0])[0].0 };
                let (le, lt) = (lump(ce), lump(ctot));
                crate::out!("  reference (Thevenin Rd {:.3} kOhm): driver-pin 50% at {:.5} ns; lumped Ceff {:.5} ns ({:+.2}%), lumped Ctotal {:.5} ns ({:+.2}%)",
                    rd, full, le, 100.0 * (le - full) / full, lt, 100.0 * (lt - full) / full);
            }
        } else {
            crate::out!("(driver has no library timing arc: Ceff not evaluated)");
        }
        Ok(String::new())
    }

    /// (delay table, transition table) of the first timing arc into a driver pin
    fn drv_arc(&self, p: PinRef) -> Option<(&crate::liberty::Table, &crate::liberty::Table)> {
        let nl = self.nl.as_ref()?;
        let PinRef::Cell(c, i) = p else { return None };
        let l = nl.cell(c).lib()?;
        let lc = self.libs.iter().find_map(|x| x.cells.get(l))?;
        let pin = lc.pin(&nl.cell(c).pins[i].name)?;
        pin.arcs.iter().find_map(|a| Some((a.cell_rise.as_ref()?, a.rise_tran.as_ref()?)))
    }

    // ------------------------------------------------------------------ models vs reference
    fn c_check_dc(&mut self, a: &[String]) -> R {
        let x = args(a, &["-nets", "-input_slew"]);
        let n: usize = x.get("-nets").and_then(|v| v.parse().ok()).unwrap_or(50);
        let sin: f64 = x.get("-input_slew").and_then(|v| v.parse().ok()).unwrap_or(0.05);
        let (rc, lab) = self.dc_source().ok_or_else(|| Flow::Err("no RC parasitics to check (DC-011)".into()))?;
        let nl = self.nl()?;
        let miller = self.miller();
        // the most resistive nets (largest Elmore delay)
        let mut nets: Vec<(f64, NetId, Arc<RcTree>)> = rc.trees.iter().map(|(k, t)| {
            let m = t.moments(miller);
            (m.iter().map(rcnet::elmore).fold(0.0f64, f64::max), *k, t.clone())
        }).filter(|x| x.0 > 1e-6 && x.2.len() < 20000).collect();
        nets.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap());
        nets.truncate(n);
        // errors: model -> (delay errs %, slew errs %)
        let mut de: HashMap<&'static str, Vec<f64>> = HashMap::new();
        let mut se: HashMap<&'static str, Vec<f64>> = HashMap::new();
        let mut worst: Vec<(f64, String)> = vec![];
        let mut sinks = 0usize;
        for (_, net, t) in &nets {
            let mom = t.moments(miller);
            let loads: Vec<(PinRef, usize)> = t.pins.iter().filter(|(_, nd)| *nd != 0).map(|(p, nd)| (*p, *nd as usize)).collect();
            let nodes: Vec<usize> = loads.iter().map(|x| x.1).collect();
            let refr = t.simulate(1e-6, sin / 0.8, miller, &nodes);
            for (k, (pr, nd)) in loads.iter().enumerate() {
                let r = refr[k];
                let rd = r.0 - sin / 0.8 / 2.0;
                let rs = r.2 - r.1;
                if !(rd.is_finite() && rs.is_finite()) || rd < 1e-5 {
                    continue;
                }
                sinks += 1;
                for md in [Model::Elmore, Model::D2m, Model::Awe] {
                    let (d, s) = rcnet::wire_delay(md, &mom[*nd], sin);
                    de.entry(md.name()).or_default().push(100.0 * (d - rd) / rd);
                    se.entry(md.name()).or_default().push(100.0 * (s - rs) / rs);
                    if md == Model::Awe {
                        worst.push((100.0 * (d - rd) / rd, format!("{} -> {}", nl.net(*net).name, nl.pin_name(*pr))));
                    }
                }
            }
        }
        crate::out!("****************************************\nReport : check_delay_calculation\nSource : {}\nNets   : {} (most resistive), {} sink(s), input slew {:.3} ns, reference = transient RC simulation\n****************************************", lab, nets.len(), sinks, sin);
        crate::out!("{:<10} {:>12} {:>12} {:>12} {:>12} {:>12}", "Model", "delay mean", "delay |max|", "slew mean", "slew |max|", "delay |avg|");
        let stat = |v: &Vec<f64>| -> (f64, f64, f64) {
            if v.is_empty() { return (0.0, 0.0, 0.0); }
            let mean = v.iter().sum::<f64>() / v.len() as f64;
            let amax = v.iter().map(|x| x.abs()).fold(0.0f64, f64::max);
            let aavg = v.iter().map(|x| x.abs()).sum::<f64>() / v.len() as f64;
            (mean, amax, aavg)
        };
        let mut res = vec![];
        for md in ["elmore", "d2m", "awe"] {
            let (dm, dx, da) = stat(de.get(md).unwrap_or(&vec![]));
            let (sm, sx, _) = stat(se.get(md).unwrap_or(&vec![]));
            crate::out!("{:<10} {:>+11.2}% {:>11.2}% {:>+11.2}% {:>11.2}% {:>11.2}%", md, dm, dx, sm, sx, da);
            res.push(format!("{} {:.3}", md, da));
        }
        worst.sort_by(|a, b| b.0.abs().partial_cmp(&a.0.abs()).unwrap());
        if !worst.is_empty() {
            crate::out!("Largest AWE delay errors:");
            for (e, w) in worst.iter().take(5) {
                crate::out!("  {:>+7.2}%  {}", e, w);
            }
        }
        crate::info!("DC-200", "Delay calculation checked on {} sink(s): mean |delay error| {}", sinks, res.join(", "));
        Ok(res.join(" "))
    }

    // ------------------------------------------------------------------ global route vs extraction
    fn c_rc_corr(&mut self, a: &[String]) -> R {
        let x = args(a, &["-nets"]);
        let shown: usize = x.get("-nets").and_then(|v| v.parse().ok()).unwrap_or(10);
        let ext = self.routed_rc.clone().ok_or_else(|| Flow::Err("report_rc_correlation needs routed nets (route_auto / route_opt) (DC-020)".into()))?;
        let (gr, _) = self.gr_build().ok_or_else(|| Flow::Err("no placement (DC-021)".into()))?;
        let nl = self.nl()?;
        let miller = self.miller();
        let sin = 0.05;
        let mut pairs_d: Vec<(f64, f64)> = vec![];
        let mut pairs_c: Vec<(f64, f64)> = vec![];
        let mut rows: Vec<(f64, String, f64, f64)> = vec![];
        for (net, te) in &ext.trees {
            let Some(tg) = gr.trees.get(net) else { continue };
            pairs_c.push((tg.wire_cap(), te.wire_cap()));
            let me = te.moments(miller);
            let mg = tg.moments(miller);
            for (pr, nd) in &te.pins {
                if *nd == 0 { continue; }
                let Some(gn) = tg.node_of(*pr) else { continue };
                let (de, _) = rcnet::wire_delay(Model::Awe, &me[*nd as usize], sin);
                let (dg, _) = rcnet::wire_delay(Model::Awe, &mg[gn], sin);
                pairs_d.push((dg, de));
                rows.push(((dg - de).abs(), format!("{} -> {}", nl.net(*net).name, nl.pin_name(*pr)), dg, de));
            }
        }
        let corr = |v: &[(f64, f64)]| -> (f64, f64, f64) {
            let n = v.len() as f64;
            if n < 2.0 { return (0.0, 0.0, 0.0); }
            let (sx, sy) = (v.iter().map(|p| p.0).sum::<f64>(), v.iter().map(|p| p.1).sum::<f64>());
            let (mx, my) = (sx / n, sy / n);
            let cov: f64 = v.iter().map(|p| (p.0 - mx) * (p.1 - my)).sum();
            let vx: f64 = v.iter().map(|p| (p.0 - mx).powi(2)).sum();
            let vy: f64 = v.iter().map(|p| (p.1 - my).powi(2)).sum();
            let r = if vx > 0.0 && vy > 0.0 { cov / (vx * vy).sqrt() } else { 0.0 };
            (r * r, if sy > 0.0 { sx / sy } else { 0.0 }, v.iter().map(|p| (p.0 - p.1).abs()).sum::<f64>() / n)
        };
        let (r2d, ratd, maed) = corr(&pairs_d);
        let (r2c, ratc, maec) = corr(&pairs_c);
        crate::out!("****************************************\nReport : rc_correlation (global-route timing engine vs post-route extraction)\n****************************************");
        crate::out!("{:<22} {:>8} {:>10} {:>14} {:>16}", "Quantity", "samples", "R^2", "sum GR/extr", "mean |GR-extr|");
        crate::out!("{:<22} {:>8} {:>10.4} {:>14.3} {:>13.5} ns", "sink wire delay (AWE)", pairs_d.len(), r2d, ratd, maed);
        crate::out!("{:<22} {:>8} {:>10.4} {:>14.3} {:>13.5} pF", "net wire cap", pairs_c.len(), r2c, ratc, maec);
        rows.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap());
        if !rows.is_empty() {
            crate::out!("Largest sink differences (GR / extracted, ns):");
            for (_, w, g, e) in rows.iter().take(shown) {
                crate::out!("  {:>9.5} {:>9.5}  {}", g, e, w);
            }
        }
        crate::info!("DC-300", "RC correlation: sink delay R^2 {:.3} (GR/extracted {:.3}), net cap R^2 {:.3} (GR/extracted {:.3})", r2d, ratd, r2c, ratc);
        Ok(format!("{:.4} {:.4} {:.4} {:.4}", r2d, ratd, r2c, ratc))
    }

    // ------------------------------------------------------------------ extraction
    fn c_extract_rc(&mut self, a: &[String]) -> R {
        let x = args(a, &["-mode", "-lateral", "-coupled", "-isolated"]);
        if let Some(m) = x.get("-mode") {
            if m != "fast" && m != "detailed" {
                return err(&format!("-mode '{}': expected fast or detailed (DC-030)", m));
            }
            self.app.insert("extract.mode".into(), m.clone());
        }
        for (o, k) in [("-lateral", "extract.lateral_fraction"), ("-coupled", "extract.coupled_scale"), ("-isolated", "extract.isolated_scale")] {
            if let Some(v) = x.get(o) {
                if v.parse::<f64>().map(|f| f <= 0.0).unwrap_or(true) {
                    return err(&format!("{} '{}': expected a positive number (DC-031)", o, v));
                }
                self.app.insert(k.into(), v.clone());
            }
        }
        if self.routes.is_none() {
            return err("extract_rc: no detailed routes (route_auto first) (DC-032)");
        }
        self.refresh_rc();
        let rc = self.routed_rc.clone().unwrap();
        let wc: f64 = rc.trees.values().map(|t| t.wire_cap()).sum();
        let cc: f64 = rc.trees.values().map(|t| t.coupling_cap()).sum::<f64>().max(0.0);
        let coupled = rc.trees.values().filter(|t| !t.cc.is_empty()).count();
        let nodes: usize = rc.trees.values().map(|t| t.len()).sum();
        let md = self.extract_mode();
        crate::info!("DC-120", "RC extraction ({}): {} net(s), {} RC node(s), wire cap {:.4} pF, coupling {:.4} pF ({:.1}%) on {} net(s)",
            if md.detailed { "detailed" } else { "fast" }, rc.trees.len(), nodes, wc, cc, 100.0 * cc / wc.max(1e-12), coupled);
        Ok(format!("{:.6} {:.6}", wc, cc))
    }

    fn c_net_para(&mut self, a: &[String]) -> R {
        let x = args(a, &["-net"]);
        let nm = x.get("-net").cloned().or_else(|| x.pos.first().cloned()).ok_or_else(|| Flow::Err("report_net_parasitics -net name (CMD-001)".into()))?;
        let nl = self.nl()?;
        let n = nl.net_by_name(&nm).or_else(|| nl.port_by_name(&nm).and_then(|p| nl.ports[p].net)).ok_or_else(|| Flow::Err(format!("net '{}' not found (DC-013)", nm)))?;
        let (rc, lab) = self.dc_source().ok_or_else(|| Flow::Err("no RC parasitics (DC-011)".into()))?;
        let t = rc.trees.get(&n).ok_or_else(|| Flow::Err(format!("net '{}' has no RC tree in {} (DC-012)", nm, lab)))?;
        let miller = self.miller();
        let mom = t.moments(miller);
        let pi = t.pi_model(&mom, miller);
        crate::out!("Net {} ({}): {} nodes, R {:.4} kOhm, wire C {:.5} pF (coupling {:.5} pF to {} aggressor(s)), pi C1 {:.5} R {:.4} C2 {:.5}",
            nm, t.src, t.len(), t.total_r(), t.wire_cap(), t.coupling_cap(),
            t.cc.iter().map(|x| x.1).collect::<std::collections::HashSet<_>>().len(), pi.c1, pi.r, pi.c2);
        crate::out!("  {:<40} {:>10} {:>10} {:>10}", "load", "Elmore", "D2M", "AWE");
        for (pr, nd) in &t.pins {
            if *nd == 0 { continue; }
            let m = &mom[*nd as usize];
            crate::out!("  {:<40} {:>10.5} {:>10.5} {:>10.5}", nl.pin_name(*pr), rcnet::elmore(m), rcnet::d2m(m), rcnet::wire_delay(Model::Awe, m, 0.0).0);
        }
        Ok(String::new())
    }
}
