//! Netlist queries: all_connected, transitive fanin/fanout reports, object selection, current_instance.

use crate::cons::Obj;
use crate::netlist::*;
use crate::session::*;
use crate::tcl::{split_list, to_list, Flow};
use std::collections::{HashSet, VecDeque};

type R = Result<String, Flow>;

fn err<T: Into<String>>(m: T) -> R {
    Err(Flow::Err(m.into()))
}

impl Session {
    /// leaf pins/ports of the physical net containing `n` (through hierarchical boundary pins)
    pub(crate) fn leaf_conns(nl: &Netlist, n: NetId) -> Vec<PinRef> {
        let mut grp = vec![n];
        let mut k = 0;
        // walk up to the root through boundary pins, then down
        while let Some(PinRef::Cell(c, _)) = nl.driver(grp[0]) {
            if !nl.cell(c).is_hport() {
                break;
            }
            match nl.cell(c).pin_net("A") {
                Some(a) if !grp.contains(&a) => grp.insert(0, a),
                _ => break,
            }
        }
        while k < grp.len() {
            let m = grp[k];
            k += 1;
            for l in nl.loads(m) {
                if let PinRef::Cell(c, _) = l {
                    if nl.cell(c).is_hport() {
                        if let Some(y) = nl.cell(c).pin_net("Y") {
                            if !grp.contains(&y) {
                                grp.push(y);
                            }
                        }
                    }
                }
            }
        }
        grp.iter().flat_map(|g| nl.net(*g).conns.clone()).filter(|p| !matches!(p, PinRef::Cell(c, _) if nl.cell(*c).is_hport())).collect()
    }

    fn handle_of(nl: &Netlist, pr: PinRef) -> String {
        match pr {
            PinRef::Port(p) => Obj::Port(nl.ports[p].name.clone()).handle(),
            PinRef::Cell(..) => Obj::Pin(nl.pin_name(pr)).handle(),
        }
    }

    pub(crate) fn query_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        let r = match name {
            "all_connected" => {
                let x = args(a, &[]);
                let leaf = x.has("-leaf");
                let Some(nl) = self.nl.as_ref() else { return Some(err("no design")) };
                let mut out: Vec<String> = vec![];
                for it in x.pos.iter().flat_map(|p| split_list(p)) {
                    // plain names: with -leaf a net is meant first (net -> leaf pins), otherwise a pin/port
                    // first (pin -> its net)
                    let o = Obj::parse(&it).or_else(|| {
                        if leaf && nl.net_by_name(&it).is_some() {
                            Some(Obj::Net(it.clone()))
                        } else if nl.port_by_name(&it).is_some() {
                            Some(Obj::Port(it.clone()))
                        } else if nl.find_pin(&it).is_some() {
                            Some(Obj::Pin(it.clone()))
                        } else if nl.net_by_name(&it).is_some() {
                            Some(Obj::Net(it.clone()))
                        } else if nl.cell_by_name(&it).is_some() {
                            Some(Obj::Cell(it.clone()))
                        } else {
                            None
                        }
                    });
                    match o {
                        Some(Obj::Net(n)) => {
                            let Some(id) = nl.net_by_name(&n) else {
                                crate::warn!("SEL-005", "all_connected: net '{}' not found", n);
                                continue;
                            };
                            let conns = if leaf { Self::leaf_conns(nl, id) } else { nl.net(id).conns.iter().copied().filter(|p| !matches!(p, PinRef::Cell(c, _) if nl.cell(*c).is_hport())).collect() };
                            for pr in conns {
                                if leaf && matches!(pr, PinRef::Port(_)) {
                                    continue; // -leaf: leaf-cell pins only
                                }
                                out.push(Self::handle_of(nl, pr));
                            }
                        }
                        Some(Obj::Pin(p)) | Some(Obj::Port(p)) => {
                            let Some(pr) = nl.find_pin(&p) else { continue };
                            match nl.pin_net(pr) {
                                Some(n) => {
                                    if leaf {
                                        for q in Self::leaf_conns(nl, n) {
                                            if q != pr && !matches!(q, PinRef::Port(_)) {
                                                out.push(Self::handle_of(nl, q));
                                            }
                                        }
                                    } else {
                                        out.push(Obj::Net(nl.net(n).name.clone()).handle());
                                    }
                                }
                                None => crate::warn!("SEL-006", "all_connected: '{}' is not connected", p),
                            }
                        }
                        Some(Obj::Cell(c)) => {
                            if let Some(ci) = nl.cell_by_name(&c) {
                                for p in &nl.cell(ci).pins {
                                    if let Some(n) = p.net {
                                        out.push(Obj::Net(nl.net(n).name.clone()).handle());
                                    }
                                }
                            }
                        }
                        _ => crate::warn!("SEL-005", "all_connected: '{}' is not a net, pin, port or cell", it),
                    }
                }
                let mut seen = HashSet::new();
                out.retain(|h| seen.insert(h.clone()));
                Ok(to_list(&out))
            }
            "report_transitive_fanout" | "report_transitive_fanin" => {
                let fwd = name == "report_transitive_fanout";
                let x = args(a, &["-from", "-to", "-levels", "-max_levels"]);
                let src = if fwd { x.get("-from") } else { x.get("-to") }.cloned().or(x.pos.first().cloned());
                let Some(src) = src else { return Some(err(format!("{}: {} <pins|ports|nets|cells> required", name, if fwd { "-from" } else { "-to" }))) };
                let maxl = x.num("-levels").or(x.num("-max_levels")).map(|v| v as usize).unwrap_or(usize::MAX);
                let ends_only = x.has("-endpoints_only");
                let flat = x.has("-flat");
                let Some(nl) = self.nl.as_ref() else { return Some(err("no design")) };
                let libs = &self.libs;
                let is_seq = |c: CellId| -> bool {
                    let cl = nl.cell(c);
                    matches!(cl.kind, Kind::Gen(GOp::Dff) | Kind::Gen(GOp::Latch) | Kind::BlackBox(_)) || cl.lib().and_then(|l| libs.iter().find_map(|x| x.cells.get(l))).map(|x| x.is_seq()).unwrap_or(false)
                };
                let refn = |c: CellId| -> String {
                    match &nl.cell(c).kind {
                        Kind::Lib(l) => l.clone(),
                        Kind::BlackBox(b) => format!("{} (black box)", b),
                        Kind::Gen(g) => format!("**{:?}**", g),
                    }
                };
                // start points
                let mut starts: Vec<PinRef> = vec![];
                for it in split_list(&src) {
                    let nmx = Obj::parse(&it).map(|o| o.name().to_string()).unwrap_or(it.clone());
                    if let Some(pr) = nl.find_pin(&nmx) {
                        starts.push(pr);
                    } else if let Some(n) = nl.net_by_name(&nmx) {
                        if fwd {
                            starts.extend(nl.driver(n));
                        } else {
                            starts.extend(nl.loads(n));
                        }
                    } else if let Some(c) = nl.cell_by_name(&nmx) {
                        for (i, p) in nl.cell(c).pins.iter().enumerate() {
                            if (p.dir == Dir::Out) == fwd {
                                starts.push(PinRef::Cell(c, i));
                            }
                        }
                    } else {
                        crate::warn!("SEL-005", "{}: '{}' not found", name, nmx);
                    }
                }
                // BFS over pins: net arcs + combinational cell arcs; registers are boundaries
                let mut seen: HashSet<PinRef> = HashSet::new();
                let mut q: VecDeque<(PinRef, usize)> = starts.iter().map(|s| (*s, 0)).collect();
                let mut rows: Vec<(usize, String, String, String, bool)> = vec![];
                for s in &starts {
                    seen.insert(*s);
                }
                while let Some((pr, lvl)) = q.pop_front() {
                    let net = nl.pin_net(pr);
                    let (cellref, is_end) = match pr {
                        PinRef::Port(p) => ("(port)".to_string(), (nl.ports[p].dir == Dir::Out) == fwd || lvl > 0),
                        PinRef::Cell(c, _) => (refn(c), lvl > 0 && is_seq(c) && nl.cell(c).pins.iter().any(|_| true) && !nl.is_driver(pr) == fwd),
                    };
                    if !nl.cell_is_hport(pr) {
                        rows.push((lvl, nl.pin_name(pr), cellref, net.map(|n| nl.net(n).name.clone()).unwrap_or_default(), is_end));
                    }
                    if lvl >= maxl || (lvl > 0 && is_end) {
                        continue;
                    }
                    let mut next: Vec<PinRef> = vec![];
                    let driving = match pr {
                        PinRef::Port(p) => nl.ports[p].dir == Dir::In,
                        PinRef::Cell(..) => nl.is_driver(pr),
                    };
                    if fwd {
                        if driving {
                            if let Some(n) = net {
                                next.extend(nl.loads(n));
                            }
                        } else if let PinRef::Cell(c, _) = pr {
                            if !is_seq(c) {
                                next.extend(nl.cell(c).pins.iter().enumerate().filter(|(_, p)| p.dir == Dir::Out).map(|(i, _)| PinRef::Cell(c, i)));
                            }
                        }
                    } else if !driving {
                        if let Some(n) = net {
                            next.extend(nl.driver(n));
                        }
                    } else if let PinRef::Cell(c, _) = pr {
                        if !is_seq(c) {
                            next.extend(nl.cell(c).pins.iter().enumerate().filter(|(_, p)| p.dir == Dir::In && p.net.is_some()).map(|(i, _)| PinRef::Cell(c, i)));
                        }
                    }
                    for n in next {
                        if seen.insert(n) {
                            // boundary pins are transparent: do not count them as a level
                            let l2 = if nl.cell_is_hport(n) { lvl } else { lvl + 1 };
                            q.push_back((n, l2));
                        }
                    }
                }
                crate::out!("\n****************************************\nReport : {}\n         {} {}\n****************************************", name.trim_start_matches("report_"), if fwd { "-from" } else { "-to" }, abbrev_list(&split_list(&src).iter().map(|s| Obj::parse(s).map(|o| o.name().to_string()).unwrap_or(s.clone())).collect::<Vec<_>>(), 4));
                crate::out!("{:>5}  {:<48} {:<22} {}", "Level", "Pin", "Reference", "Net");
                crate::out!("{}", "-".repeat(100));
                let mut n_end = 0;
                for (lvl, pin, rf, net, end) in &rows {
                    if *end {
                        n_end += 1;
                    }
                    if ends_only && !end {
                        continue;
                    }
                    let ind = if flat { String::new() } else { "  ".repeat((*lvl).min(20)) };
                    crate::out!("{:>5}  {:<48} {:<22} {}{}", lvl, format!("{}{}", ind, pin), rf, net, if *end { "  <- endpoint" } else { "" });
                }
                crate::out!("\n  {} pin(s), {} {} point(s), max level {}", rows.len(), n_end, if fwd { "end" } else { "start" }, rows.iter().map(|r| r.0).max().unwrap_or(0));
                Ok(rows.len().to_string())
            }
            // ------------------------------------------------------------- selection
            "select_obj" | "change_selection" | "add_to_selection" | "remove_from_selection" => {
                let x = args(a, &[]);
                let items: Vec<String> = x.pos.iter().flat_map(|p| split_list(p)).filter(|h| Obj::parse(h).is_some()).collect();
                let add = name == "add_to_selection" || (name == "change_selection" && x.has("-add"));
                let remove = name == "remove_from_selection" || (name == "change_selection" && x.has("-remove"));
                if !add && !remove {
                    self.selection.clear();
                }
                let mut k = 0;
                for h in items {
                    if remove {
                        let before = self.selection.len();
                        self.selection.retain(|s| *s != h);
                        k += before - self.selection.len();
                    } else if !self.selection.contains(&h) {
                        self.selection.push(h);
                        k += 1;
                    }
                }
                crate::info!("SEL-100", "{} {} object(s); selection now has {} object(s)", if remove { "Deselected" } else { "Selected" }, k, self.selection.len());
                Ok(to_list(&self.selection))
            }
            "deselect_all" | "clear_selection" => {
                let n = self.selection.len();
                self.selection.clear();
                crate::info!("SEL-101", "Selection cleared ({} object(s))", n);
                Ok(String::new())
            }
            "get_selection" => Ok(to_list(&self.selection)),
            "report_selection" => {
                crate::out!("\nSelection: {} object(s)", self.selection.len());
                for h in &self.selection {
                    if let Some(o) = Obj::parse(h) {
                        let k = h.split("::").next().unwrap_or("");
                        crate::out!("  {:<6} {}", k, o.name());
                    }
                }
                Ok(self.selection.len().to_string())
            }
            // ------------------------------------------------------------- current_instance
            "current_instance" => {
                let x = args(a, &[]);
                let Some(nl) = self.nl.as_ref() else { return Some(err("no design")) };
                match x.pos.first().map(|s| Obj::parse(s).map(|o| o.name().to_string()).unwrap_or(s.clone())) {
                    None => self.cur_inst.clear(),
                    Some(p) if p == "." => {}
                    Some(p) if p == ".." => {
                        self.cur_inst = self.cur_inst.rsplit_once('/').map(|x| x.0.to_string()).unwrap_or_default();
                    }
                    Some(p) if p == "/" || Some(&p) == self.top.as_ref() => self.cur_inst.clear(),
                    Some(p) => {
                        let full = if let Some(rest) = p.strip_prefix('/') { rest.to_string() } else if self.cur_inst.is_empty() { p.clone() } else { format!("{}/{}", self.cur_inst, p) };
                        if !nl.hier.iter().any(|(h, _)| *h == full) {
                            return Some(err(format!("current_instance: '{}' is not a hierarchical instance", full)));
                        }
                        self.cur_inst = full;
                    }
                }
                let shown = if self.cur_inst.is_empty() { self.top.clone().unwrap_or_default() } else { self.cur_inst.clone() };
                crate::info!("SEL-110", "Current instance is '{}'", shown);
                Ok(shown)
            }
            _ => return None,
        };
        Some(r)
    }
}
