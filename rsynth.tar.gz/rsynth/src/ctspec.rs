//! Clock tree specification ("clocktree.cfg") and clock tree tracing.
//!
//! The spec collects what clock tree synthesis must honour: clock transition, buffer and
//! inverter lists, target skew and latency (global or per clock), max fanout / capacitance,
//! dont_touch / dont_use, clock balance groups, and pin exceptions (ignore, leaf / stop,
//! through, float pins with an insertion delay). `write_clock_tree_spec` dumps a
//! pre-configuration from the current libraries, SDC and settings; `read_clock_tree_spec` (or
//! `clock_opt -spec`) loads one; `trace_clock_tree` (or `clock_opt -trace`) traces the clock
//! networks with the exceptions applied and reports roots, gates, sinks and problems.

use crate::netlist::{Dir, Kind, NetId, PinRef};
use crate::session::{args, Session};
use crate::tcl::{err, split_list, Flow, R};
use std::collections::{BTreeMap, HashSet};
use std::fmt::Write;

#[derive(Clone, Debug)]
pub struct CtsSpec {
    pub clock_transition: Option<f64>,
    pub buffers: Vec<String>,
    pub inverters: Vec<String>,
    pub target_skew: Option<f64>,
    pub target_latency: Option<f64>,
    /// per-clock target latency
    pub latency: Vec<(String, f64)>,
    pub max_fanout: Option<usize>,
    pub max_capacitance: Option<f64>,
    pub honor_dont_touch: bool,
    pub honor_dont_use: bool,
    /// clocks balanced together (one skew group per list); other clocks: own group
    pub balance_groups: Vec<(String, Vec<String>)>,
    pub ignore_pins: Vec<String>,
    pub leaf_pins: Vec<String>,
    pub through_pins: Vec<String>,
    /// hierarchical / macro pins with their internal insertion delay (ns)
    pub float_pins: Vec<(String, f64)>,
    /// file the spec was read from
    pub source: String,
}

impl Default for CtsSpec {
    fn default() -> Self {
        CtsSpec { clock_transition: None, buffers: vec![], inverters: vec![], target_skew: None, target_latency: None, latency: vec![], max_fanout: None, max_capacitance: None,
            honor_dont_touch: true, honor_dont_use: true, balance_groups: vec![], ignore_pins: vec![], leaf_pins: vec![], through_pins: vec![], float_pins: vec![], source: String::new() }
    }
}

fn pin_name(h: &str) -> String {
    crate::cons::Obj::parse(h).map(|o| o.name().to_string()).unwrap_or_else(|| h.to_string())
}
fn lib_name(h: &str) -> String {
    crate::cons::Obj::parse(h).map(|o| o.name().rsplit('/').next().unwrap_or("").to_string()).unwrap_or_else(|| h.to_string())
}

impl CtsSpec {
    pub fn exc(&self) -> crate::cts::TraceExc {
        crate::cts::TraceExc {
            ignore: self.ignore_pins.iter().cloned().collect(),
            leaf: self.leaf_pins.iter().cloned().chain(self.float_pins.iter().map(|f| f.0.clone())).collect(),
            through: self.through_pins.iter().cloned().collect(),
        }
    }
    pub fn float_delay(&self, pin: &str) -> f64 {
        self.float_pins.iter().find(|f| f.0 == pin).map(|f| f.1).unwrap_or(0.0)
    }
    pub fn latency_of(&self, clock: &str) -> Option<f64> {
        self.latency.iter().find(|x| x.0 == clock).map(|x| x.1).or(self.target_latency)
    }

    /// parse a clocktree.cfg: `keyword value(s)` per line; `#` comments; `{ }` lists
    pub fn parse(text: &str) -> Result<CtsSpec, String> {
        let mut s = CtsSpec::default();
        for (ln, raw) in text.lines().enumerate() {
            let line = raw.split('#').next().unwrap_or("").trim();
            if line.is_empty() {
                continue;
            }
            let mut it = line.splitn(2, char::is_whitespace);
            let key = it.next().unwrap_or("").to_lowercase();
            let rest = it.next().unwrap_or("").trim();
            let items: Vec<String> = split_list(rest).iter().flat_map(|x| split_list(x)).collect();
            let num = |v: &str| -> Result<f64, String> { v.trim().parse::<f64>().map_err(|_| format!("line {}: '{}' expects a number, got '{}'", ln + 1, key, v)) };
            let boolv = |v: &str| matches!(v.trim().to_lowercase().as_str(), "true" | "1" | "yes" | "on");
            match key.as_str() {
                "clock_transition" | "max_transition" | "clock_max_transition" => s.clock_transition = Some(num(rest)?),
                "clock_tree_buffer_list" | "buffer_list" | "buffers" => s.buffers = items.iter().map(|x| lib_name(x)).collect(),
                "clock_tree_inv_list" | "clock_tree_inverter_list" | "inverter_list" | "inverters" => s.inverters = items.iter().map(|x| lib_name(x)).collect(),
                "clock_target_skew" | "target_skew" => s.target_skew = Some(num(rest)?),
                "clock_target_latency" | "target_latency" => s.target_latency = Some(num(rest)?),
                "clock_latency" => {
                    if items.len() >= 2 { s.latency.push((items[0].clone(), num(&items[1])?)); } else { s.target_latency = Some(num(rest)?); }
                }
                "clock_max_fanout" | "max_fanout" => s.max_fanout = Some(num(rest)? as usize),
                "clock_max_capacitance" | "max_capacitance" => s.max_capacitance = Some(num(rest)?),
                "honor_dont_touch" | "honour_dont_touch" => s.honor_dont_touch = boolv(rest),
                "honor_dont_use" | "honour_dont_use" => s.honor_dont_use = boolv(rest),
                "balance_clock_group" | "clock_group" | "balance_group" | "skew_group" => {
                    // balance_clock_group name {clk1 clk2}  or  balance_clock_group {clk1 clk2}
                    let parts = split_list(rest);
                    let (n, l) = if parts.len() >= 2 && !parts[0].contains(' ') && split_list(&parts[1]).len() >= 1 && parts.len() == 2 { (parts[0].clone(), split_list(&parts[1])) } else { (format!("group{}", s.balance_groups.len() + 1), items.clone()) };
                    s.balance_groups.push((n, l));
                }
                "ignore_pins" | "ignore_pin" | "exclude_pins" => s.ignore_pins.extend(items.iter().map(|x| pin_name(x))),
                "leaf_pins" | "leaf_pin" | "stop_pins" | "sink_pins" => s.leaf_pins.extend(items.iter().map(|x| pin_name(x))),
                "through_pins" | "through_pin" => s.through_pins.extend(items.iter().map(|x| pin_name(x))),
                "float_pins" | "float_pin" | "macro_model_pins" => {
                    // float_pins { pin delay pin delay ... }
                    let mut k = 0;
                    while k < items.len() {
                        let d = items.get(k + 1).and_then(|v| v.parse::<f64>().ok());
                        s.float_pins.push((pin_name(&items[k]), d.unwrap_or(0.0)));
                        k += if d.is_some() { 2 } else { 1 };
                    }
                }
                _ => return Err(format!("line {}: unknown keyword '{}'", ln + 1, key)),
            }
        }
        Ok(s)
    }
}

/// classification of a traced clock pin
#[derive(Default)]
struct TraceStat {
    nets: usize,
    bufs: Vec<String>,
    invs: Vec<String>,
    icgs: Vec<String>,
    logic: Vec<String>,
    sinks: Vec<String>,
    macros: Vec<String>,
    ports: Vec<String>,
    leaf: Vec<String>,
    float: Vec<String>,
    through: Vec<String>,
    ignored: Vec<String>,
    as_data: Vec<String>,
    dont_touch_nets: Vec<String>,
    dont_use_cells: Vec<String>,
    gen_clock_pins: Vec<String>,
}

impl Session {
    /// spec as configured now (user spec merged with SDC / library / tool defaults)
    pub(crate) fn effective_ctspec(&self) -> CtsSpec {
        let mut s = self.ctspec.clone();
        let appf = |k: &str| self.app.get(k).and_then(|v| v.parse::<f64>().ok()).filter(|v| *v > 0.0);
        if s.clock_transition.is_none() {
            s.clock_transition = appf("cts.max_transition").or_else(|| self.modes.iter().flat_map(|m| m.sdc.clocks.iter().filter_map(|c| c.max_tran)).reduce(f64::min));
        }
        if s.target_skew.is_none() { s.target_skew = appf("cts.target_skew"); }
        if s.target_latency.is_none() { s.target_latency = appf("cts.target_latency"); }
        if s.max_fanout.is_none() { s.max_fanout = appf("cts.max_fanout").map(|v| v as usize); }
        if s.max_capacitance.is_none() { s.max_capacitance = appf("cts.max_capacitance"); }
        let lc = |n: &str| self.libs.iter().find_map(|l| l.cells.get(n));
        if s.buffers.is_empty() {
            s.buffers = split_list(&self.app.get("cts.buffers").cloned().unwrap_or_default());
        }
        if s.buffers.is_empty() {
            // clock buffers of the libraries (by function), clock-specific names first
            let mut v: Vec<(bool, f64, String)> = vec![];
            for l in &self.libs { for (n, c) in &l.cells { if c.is_buf && !v.iter().any(|x| &x.2 == n) { v.push((!n.to_uppercase().contains("CLK"), c.drive, n.clone())); } } }
            v.sort_by(|a, b| a.0.cmp(&b.0).then(a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal)).then(a.2.cmp(&b.2)));
            let clk = v.iter().any(|x| !x.0);
            s.buffers = v.into_iter().filter(|x| !clk || !x.0).map(|x| x.2).take(6).collect();
        }
        if s.inverters.is_empty() {
            let mut v: Vec<(bool, f64, String)> = vec![];
            for l in &self.libs { for (n, c) in &l.cells { if c.is_inv && !v.iter().any(|x| &x.2 == n) { v.push((!n.to_uppercase().contains("CLK"), c.drive, n.clone())); } } }
            v.sort_by(|a, b| a.0.cmp(&b.0).then(a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal)).then(a.2.cmp(&b.2)));
            let clk = v.iter().any(|x| !x.0);
            s.inverters = v.into_iter().filter(|x| !clk || !x.0).map(|x| x.2).take(6).collect();
        }
        if s.honor_dont_use {
            s.buffers.retain(|b| lc(b).map(|c| !c.dont_use).unwrap_or(true));
            s.inverters.retain(|b| lc(b).map(|c| !c.dont_use).unwrap_or(true));
        }
        // per-clock latency from set_clock_latency (network latency) when not given
        for m in &self.modes {
            for c in &m.sdc.clocks {
                if c.net_lat.0 > 0.0 && !s.latency.iter().any(|x| x.0 == c.name) && !c.is_virtual() {
                    s.latency.push((c.name.clone(), c.net_lat.0));
                }
            }
        }
        // generated clocks are balanced with their master unless grouped by the user
        if s.balance_groups.is_empty() {
            for m in self.modes.iter().take(1) {
                for c in &m.sdc.clocks {
                    if let Some(g) = &c.gen {
                        let master = g.master.clone();
                        if let Some(grp) = s.balance_groups.iter_mut().find(|x| x.1.contains(&master)) {
                            if !grp.1.contains(&c.name) { grp.1.push(c.name.clone()); }
                        } else {
                            s.balance_groups.push((format!("{}_group", master), vec![master, c.name.clone()]));
                        }
                    }
                }
            }
        }
        // set_clock_sense -stop_propagation pins are leaf (stop) pins
        for m in &self.modes {
            for (o, k, _) in &m.sdc.clock_sense {
                if *k == 0 && !s.leaf_pins.contains(&o.name().to_string()) { s.leaf_pins.push(o.name().to_string()); }
            }
        }
        s
    }

    pub(crate) fn ctspec_text(&self, s: &CtsSpec) -> String {
        let mut o = String::new();
        let design = self.nl.as_ref().map(|n| n.name.clone()).unwrap_or_default();
        let _ = writeln!(o, "# ---------------------------------------------------------------------------");
        let _ = writeln!(o, "# RSynth clock tree specification (clocktree.cfg) for design '{}'", design);
        let _ = writeln!(o, "# Read with: read_clock_tree_spec clocktree.cfg  or  clock_opt -spec clocktree.cfg");
        let _ = writeln!(o, "# Lists use {{ }}, pins are full names (inst/pin), times in ns, capacitance in pF.");
        let _ = writeln!(o, "# ---------------------------------------------------------------------------");
        let clocks: Vec<&crate::cons::Clock> = self.modes.iter().flat_map(|m| m.sdc.clocks.iter()).filter(|c| !c.is_virtual()).collect();
        let mut seen = HashSet::new();
        let _ = writeln!(o, "\n# clocks: {}", clocks.iter().filter(|c| seen.insert(c.name.clone())).map(|c| format!("{} ({:.3}ns{})", c.name, c.period, if c.gen.is_some() { ", generated" } else { "" })).collect::<Vec<_>>().join(", "));
        let opt = |v: Option<f64>| v.map(|x| format!("{}", x)).unwrap_or_else(|| "0".into());
        let _ = writeln!(o, "\n# ---- design rules on the clock nets");
        let _ = writeln!(o, "clock_transition        {}", opt(s.clock_transition));
        let _ = writeln!(o, "clock_max_fanout        {}", s.max_fanout.unwrap_or(0));
        let _ = writeln!(o, "clock_max_capacitance   {}", opt(s.max_capacitance));
        let _ = writeln!(o, "\n# ---- cells (dont_use cells are dropped when honor_dont_use is true)");
        let _ = writeln!(o, "clock_tree_buffer_list  {{{}}}", s.buffers.join(" "));
        let _ = writeln!(o, "clock_tree_inv_list     {{{}}}", s.inverters.join(" "));
        let _ = writeln!(o, "honor_dont_use          {}", s.honor_dont_use);
        let _ = writeln!(o, "honor_dont_touch        {}", s.honor_dont_touch);
        let _ = writeln!(o, "\n# ---- targets");
        let _ = writeln!(o, "clock_target_skew       {}", opt(s.target_skew));
        let _ = writeln!(o, "clock_target_latency    {}", opt(s.target_latency));
        for (c, l) in &s.latency { let _ = writeln!(o, "clock_latency           {} {}", c, l); }
        let _ = writeln!(o, "\n# ---- balancing: clocks of one group are balanced together; others on their own");
        for (n, g) in &s.balance_groups { let _ = writeln!(o, "balance_clock_group     {} {{{}}}", n, g.join(" ")); }
        let _ = writeln!(o, "\n# ---- pin exceptions");
        let _ = writeln!(o, "# ignore_pins : excluded from the tree (not buffered, not balanced)");
        let _ = writeln!(o, "# leaf_pins   : sinks where tracing stops (balanced as clock pins)");
        let _ = writeln!(o, "# through_pins: tracing continues through the cell (clock dividers, macro clock outputs)");
        let _ = writeln!(o, "# float_pins  : hierarchical / macro clock pins with their internal insertion delay");
        let _ = writeln!(o, "ignore_pins             {{{}}}", s.ignore_pins.join(" "));
        let _ = writeln!(o, "leaf_pins               {{{}}}", s.leaf_pins.join(" "));
        let _ = writeln!(o, "through_pins            {{{}}}", s.through_pins.join(" "));
        let _ = writeln!(o, "float_pins              {{{}}}", s.float_pins.iter().map(|(p, d)| format!("{} {}", p, d)).collect::<Vec<_>>().join(" "));
        o
    }

    /// apply a spec to the CTS settings
    pub(crate) fn apply_ctspec(&mut self, s: CtsSpec) {
        let mut put = |k: &str, v: Option<String>| { if let Some(v) = v { self.app.insert(k.into(), v); } };
        put("cts.max_transition", s.clock_transition.map(|v| v.to_string()));
        put("cts.target_skew", s.target_skew.map(|v| v.to_string()));
        put("cts.target_latency", s.target_latency.map(|v| v.to_string()));
        put("cts.max_fanout", s.max_fanout.map(|v| v.to_string()));
        put("cts.max_capacitance", s.max_capacitance.map(|v| v.to_string()));
        let mut bufs = s.buffers.clone();
        let mut dropped = vec![];
        for b in bufs.iter().chain(s.inverters.iter()) {
            match self.libs.iter().find_map(|l| l.cells.get(b)) {
                None => crate::warn!("CTS-401", "clock tree cell '{}' is not in any library", b),
                Some(c) if c.dont_use && s.honor_dont_use => dropped.push(b.clone()),
                _ => {}
            }
        }
        if !dropped.is_empty() {
            crate::warn!("CTS-402", "honor_dont_use: dont_use cell(s) not used for clock trees: {}", dropped.join(" "));
            bufs.retain(|b| !dropped.contains(b));
        }
        if !bufs.is_empty() { self.app.insert("cts.buffers".into(), bufs.join(" ")); }
        let inv: Vec<String> = s.inverters.iter().filter(|b| !dropped.contains(b)).cloned().collect();
        self.app.insert("cts.inverters".into(), inv.join(" "));
        self.ctspec = s;
    }

    /// structural clock tracing with the spec's exceptions: per clock, roots, gates, sinks, problems
    fn trace_report(&self, pats: &[String], file: Option<&str>, verbose: bool) -> Result<usize, Flow> {
        let nl = self.nl()?;
        let sp = self.effective_ctspec();
        let ex = sp.exc();
        let lc = |c: crate::netlist::CellId| nl.cell(c).lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l)));
        let mut full = String::new();
        let mut total = 0;
        crate::out!("\n****************************************\nReport : clock tree trace\nDesign : {}\n****************************************", nl.name);
        crate::out!("  Exceptions: {} ignore, {} leaf, {} through, {} float pin(s); honor_dont_touch {}, honor_dont_use {}", sp.ignore_pins.len(), sp.leaf_pins.len(), sp.through_pins.len(), sp.float_pins.len(), sp.honor_dont_touch, sp.honor_dont_use);
        // exception pins that do not exist
        for (k, v) in [("ignore", &sp.ignore_pins), ("leaf", &sp.leaf_pins), ("through", &sp.through_pins)] {
            for p in v.iter() { if nl.find_pin(p).is_none() { crate::warn!("CTS-410", "{}_pins: pin '{}' not found", k, p); } }
        }
        for (p, _) in &sp.float_pins { if nl.find_pin(p).is_none() { crate::warn!("CTS-410", "float_pins: pin '{}' not found", p); } }
        let mut seen_clk = HashSet::new();
        let clocks: Vec<crate::cons::Clock> = self.modes.iter().flat_map(|m| m.sdc.clocks.iter().cloned()).filter(|c| !c.is_virtual() && seen_clk.insert(c.name.clone())).filter(|c| pats.is_empty() || pats.iter().any(|p| crate::netlist::glob(p, &c.name))).collect();
        crate::out!("\n  {:<18} {:<26} {:>5} {:>5} {:>5} {:>5} {:>5} {:>7} {:>6} {:>5} {:>5} {:>5} {:>6} {:>6}", "Clock", "Root", "Nets", "Buf", "Inv", "ICG", "Logic", "Sinks", "Macro", "Leaf", "Float", "Ignor", "AsData", "DTnets");
        crate::out!("  {}", "-".repeat(124));
        let mut per: Vec<(String, TraceStat)> = vec![];
        for c in &clocks {
            let roots: Vec<NetId> = c.sources.iter().filter_map(|s| match s {
                crate::cons::Obj::Port(p) => nl.port_by_name(p).and_then(|q| nl.ports[q].net),
                crate::cons::Obj::Pin(p) => nl.find_pin(p).and_then(|q| nl.pin_net(q)),
                _ => None,
            }).collect();
            let root_name = c.sources.iter().map(|o| o.name().to_string()).collect::<Vec<_>>().join(" ");
            let mut st = TraceStat::default();
            let trees = crate::cts::trace_ex(nl, &self.libs, &roots, &ex);
            st.nets = trees.len();
            let mut cells = HashSet::new();
            for (n, sinks, _) in &trees {
                if nl.net(*n).dont_touch && !nl.net(*n).name.contains("cts") { st.dont_touch_nets.push(nl.net(*n).name.clone()); }
                for p in sinks {
                    let pn = nl.pin_name(*p);
                    match *p {
                        PinRef::Port(_) => st.ports.push(pn.clone()),
                        PinRef::Cell(ci, pi) => {
                            let cl = nl.cell(ci);
                            if cl.is_hport() { continue; }
                            if ex.leaf.contains(&pn) {
                                if sp.float_pins.iter().any(|f| f.0 == pn) { st.float.push(format!("{} ({:.3}ns)", pn, sp.float_delay(&pn))); } else { st.leaf.push(pn.clone()); }
                                continue;
                            }
                            if ex.through.contains(&pn) { st.through.push(pn.clone()); }
                            let l = lc(ci);
                            if let Some(l) = l { if l.dont_use && cells.insert(cl.name.clone()) { st.dont_use_cells.push(format!("{} ({})", cl.name, cl.lib().unwrap_or(""))); } }
                            match l {
                                Some(l) if l.seq.is_some() => {
                                    if l.pin(&cl.pins[pi].name).map(|x| x.is_clock).unwrap_or(false) {
                                        st.sinks.push(pn.clone());
                                        if ex.through.contains(&pn) { st.gen_clock_pins.push(pn.clone()); }
                                    } else { st.as_data.push(pn.clone()); }
                                }
                                Some(l) if l.icg.is_some() => if l.pin(&cl.pins[pi].name).map(|x| x.is_clock).unwrap_or(false) { st.icgs.push(cl.name.clone()) } else { st.as_data.push(pn.clone()) },
                                Some(l) if l.is_buf => st.bufs.push(cl.name.clone()),
                                Some(l) if l.is_inv => st.invs.push(cl.name.clone()),
                                Some(l) if !l.outputs().is_empty() => st.logic.push(format!("{} ({})", cl.name, cl.lib().unwrap_or(""))),
                                _ => if matches!(cl.kind, Kind::BlackBox(_)) || self.lef.get(crate::lef::master(cl).unwrap_or("")).map(|m| m.class.starts_with("BLOCK")).unwrap_or(false) { st.macros.push(pn.clone()) } else { st.sinks.push(pn.clone()) },
                            }
                        }
                    }
                }
            }
            // ignored pins on these nets
            for (n, _, _) in &trees { for l in nl.loads(*n) { let pn = nl.pin_name(l); if ex.ignore.contains(&pn) { st.ignored.push(pn); } } }
            for r in &roots { for l in nl.loads(*r) { let pn = nl.pin_name(l); if ex.ignore.contains(&pn) && !st.ignored.contains(&pn) { st.ignored.push(pn); } } }
            let nsink = st.sinks.len() + st.macros.len() + st.leaf.len() + st.float.len() + st.ports.len();
            total += nsink;
            crate::out!("  {:<18} {:<26} {:>5} {:>5} {:>5} {:>5} {:>5} {:>7} {:>6} {:>5} {:>5} {:>5} {:>6} {:>6}", c.name, if root_name.len() > 26 { format!("{}…", &root_name[..25]) } else { root_name.clone() },
                st.nets, st.bufs.len(), st.invs.len(), st.icgs.len(), st.logic.len(), st.sinks.len(), st.macros.len(), st.leaf.len(), st.float.len(), st.ignored.len(), st.as_data.len(), st.dont_touch_nets.len());
            if roots.is_empty() { crate::warn!("CTS-411", "clock '{}': source {} not found in the netlist", c.name, root_name); }
            per.push((c.name.clone(), st));
        }
        // details
        let lim = if verbose { usize::MAX } else { 8 };
        for (c, st) in &per {
            let mut show = |what: &str, v: &Vec<String>, to_out: bool| {
                if v.is_empty() { return; }
                let _ = writeln!(full, "  {} {} ({}):", c, what, v.len());
                for x in v { let _ = writeln!(full, "      {}", x); }
                if to_out {
                    crate::out!("    {:<10} {:<20} {}{}", c, what, v.iter().take(lim).cloned().collect::<Vec<_>>().join(" "), if v.len() > lim { format!(" ... (+{})", v.len() - lim) } else { String::new() });
                }
            };
            crate::out!("");
            show("clock gates", &st.icgs, true);
            show("clock logic", &st.logic, true);
            show("buffers", &st.bufs, verbose);
            show("inverters", &st.invs, verbose);
            show("leaf pins", &st.leaf, true);
            show("float pins", &st.float, true);
            show("through pins", &st.through, true);
            show("ignored pins", &st.ignored, true);
            show("macro sinks", &st.macros, true);
            show("port sinks", &st.ports, true);
            show("sinks", &st.sinks, verbose);
            show("clock as data", &st.as_data, true);
            show("dont_touch nets", &st.dont_touch_nets, true);
            show("dont_use cells", &st.dont_use_cells, true);
            if !st.as_data.is_empty() { crate::warn!("CTS-412", "clock '{}' reaches {} data pin(s) (clock used as data); not balanced", c, st.as_data.len()); }
            if !st.dont_touch_nets.is_empty() && sp.honor_dont_touch { crate::warn!("CTS-413", "clock '{}': {} dont_touch net(s) on the tree are not buffered (honor_dont_touch)", c, st.dont_touch_nets.len()); }
            if !st.dont_use_cells.is_empty() { crate::warn!("CTS-414", "clock '{}': {} existing dont_use cell(s) on the clock tree", c, st.dont_use_cells.len()); }
        }
        if let Some(f) = file {
            let mut o = format!("# clock tree trace of '{}'\n", nl.name);
            o += &full;
            std::fs::write(f, o).map_err(|e| Flow::Err(format!("trace_clock_tree: {}: {}", f, e)))?;
            crate::info!("CTS-420", "Wrote the clock tree trace to '{}'", f);
        }
        crate::info!("CTS-421", "Traced {} clock(s): {} sink(s) in total", per.len(), total);
        Ok(total)
    }

    pub(crate) fn ctspec_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        match name {
            "write_clock_tree_spec" | "create_clock_tree_spec" | "create_ccopt_clock_tree_spec" | "write_ccopt_clock_tree_spec" => {
                let x = args(a, &["-file", "-output", "-filename"]);
                let f = x.get("-file").or(x.get("-output")).or(x.get("-filename")).cloned().or(x.pos.first().cloned()).unwrap_or_else(|| "clocktree.cfg".into());
                let s = self.effective_ctspec();
                let t = self.ctspec_text(&s);
                if let Err(e) = std::fs::write(&f, t) { return Some(err(&format!("{}: {}: {}", name, f, e))); }
                crate::info!("CTS-400", "Wrote the clock tree specification '{}' ({} buffer(s), {} inverter(s), {} balance group(s), {} exception pin(s))", f, s.buffers.len(), s.inverters.len(), s.balance_groups.len(), s.ignore_pins.len() + s.leaf_pins.len() + s.through_pins.len() + s.float_pins.len());
                Some(Ok(f))
            }
            "read_clock_tree_spec" | "source_clock_tree_spec" | "load_clock_tree_spec" => {
                let x = args(a, &["-file"]);
                let Some(f) = x.get("-file").cloned().or(x.pos.first().cloned()) else { return Some(err("read_clock_tree_spec: file required (CTS-403)")) };
                let t = match std::fs::read_to_string(&f) { Ok(t) => t, Err(e) => return Some(err(&format!("read_clock_tree_spec: {}: {}", f, e))) };
                match CtsSpec::parse(&t) {
                    Ok(mut s) => {
                        s.source = f.clone();
                        crate::info!("CTS-404", "Read clock tree specification '{}': transition {}, skew {}, {} buffer(s), {} inverter(s), {} latency target(s), {} balance group(s), ignore {} / leaf {} / through {} / float {} pin(s)",
                            f, s.clock_transition.map(|v| format!("{}", v)).unwrap_or("-".into()), s.target_skew.map(|v| format!("{}", v)).unwrap_or("-".into()), s.buffers.len(), s.inverters.len(),
                            s.latency.len() + s.target_latency.is_some() as usize, s.balance_groups.len(), s.ignore_pins.len(), s.leaf_pins.len(), s.through_pins.len(), s.float_pins.len());
                        self.apply_ctspec(s);
                        Some(Ok(f))
                    }
                    Err(e) => Some(err(&format!("read_clock_tree_spec: {}: {} (CTS-405)", f, e))),
                }
            }
            "set_clock_tree_exceptions" | "set_ccopt_property_pins" => {
                let x = args(a, &["-ignore_pins", "-exclude_pins", "-leaf_pins", "-stop_pins", "-through_pins", "-float_pins", "-float_delay"]);
                let l = |k: &[&str]| -> Vec<String> { k.iter().filter_map(|o| x.get(*o)).flat_map(|v| split_list(v)).map(|h| pin_name(&h)).collect() };
                let rm = x.has("-remove") || x.has("-reset");
                let mut sp = self.ctspec.clone();
                let upd = |v: &mut Vec<String>, new: Vec<String>| { for p in new { if rm { v.retain(|q| q != &p); } else if !v.contains(&p) { v.push(p); } } };
                upd(&mut sp.ignore_pins, l(&["-ignore_pins", "-exclude_pins"]));
                upd(&mut sp.leaf_pins, l(&["-leaf_pins", "-stop_pins"]));
                upd(&mut sp.through_pins, l(&["-through_pins"]));
                let d = x.num("-float_delay").unwrap_or(0.0);
                for p in l(&["-float_pins"]) { sp.float_pins.retain(|f| f.0 != p); if !rm { sp.float_pins.push((p, d)); } }
                if x.has("-clear") { sp.ignore_pins.clear(); sp.leaf_pins.clear(); sp.through_pins.clear(); sp.float_pins.clear(); }
                let n = sp.ignore_pins.len() + sp.leaf_pins.len() + sp.through_pins.len() + sp.float_pins.len();
                self.ctspec = sp;
                Some(Ok(n.to_string()))
            }
            "create_clock_balance_group" | "set_clock_balance_group" | "create_ccopt_skew_group" => {
                let x = args(a, &["-name", "-clocks", "-sources"]);
                let clocks: Vec<String> = x.get("-clocks").or(x.get("-sources")).map(|v| split_list(v)).unwrap_or_default().iter().map(|h| crate::cons::Obj::parse(h).map(|o| o.name().to_string()).unwrap_or(h.clone())).collect();
                if clocks.is_empty() { return Some(err(&format!("{}: -clocks required (CTS-406)", name))); }
                let n = x.get("-name").cloned().unwrap_or_else(|| format!("group{}", self.ctspec.balance_groups.len() + 1));
                self.ctspec.balance_groups.retain(|g| g.0 != n);
                self.ctspec.balance_groups.push((n.clone(), clocks.clone()));
                crate::info!("CTS-407", "Clock balance group '{}': {}", n, clocks.join(" "));
                Some(Ok(n))
            }
            "report_clock_tree_spec" | "report_ccopt_clock_tree_spec" => {
                let s = self.effective_ctspec();
                crate::out!("\n****************************************\nReport : clock tree specification{}\n****************************************", if self.ctspec.source.is_empty() { String::new() } else { format!(" ({})", self.ctspec.source) });
                for l in self.ctspec_text(&s).lines().filter(|l| !l.starts_with('#') && !l.trim().is_empty()) { crate::out!("  {}", l); }
                Some(Ok(String::new()))
            }
            "trace_clock_tree" | "trace_clock_trees" | "check_clock_tree_spec" => {
                let x = args(a, &["-clocks", "-clock", "-file", "-output"]);
                let pats: Vec<String> = x.get("-clocks").or(x.get("-clock")).map(|v| split_list(v)).unwrap_or_default().iter().map(|h| crate::cons::Obj::parse(h).map(|o| o.name().to_string()).unwrap_or(h.clone())).collect();
                let f = x.get("-file").or(x.get("-output")).cloned();
                Some(self.trace_report(&pats, f.as_deref(), x.has("-verbose")).map(|n| n.to_string()))
            }
            _ => None,
        }
    }
}

#[allow(dead_code)]
fn _u(_: Dir, _: BTreeMap<u8, u8>) {}
