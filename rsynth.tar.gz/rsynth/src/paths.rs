//! Timing path enumeration: the k worst paths per endpoint under -from / ordered -through /
//! -to / -exclude / clock / group / transition filters, for setup (max) and hold (min).
//!
//! Best-first (A*) search backwards from each endpoint.  The propagated tag arrivals of the
//! path's launch clock are exact bounds of the remaining prefix, so complete paths come out in
//! exact slack order.  CRPR is computed per path from its own launch clock pin.  Ordered
//! -through stages are tracked as a counter, and a forward pass gives, for every pin, the
//! number of stages a prefix ending there can already have satisfied.  Branches that can no
//! longer satisfy -from / -through are pruned without being expanded.
use crate::netlist::PinRef;
use crate::sta::{Timing, AK, NONE};
use std::cmp::Ordering;
use std::collections::{BinaryHeap, HashSet};

#[derive(Default, Clone)]
pub struct PathQuery {
    pub hold: bool,
    pub from: Option<HashSet<u32>>,
    pub from_clocks: Option<HashSet<u16>>,
    pub through: Vec<HashSet<u32>>,
    pub to: Option<HashSet<u32>>,
    pub to_clocks: Option<HashSet<u16>>,
    pub exclude: HashSet<u32>,
    pub groups: Option<Vec<String>>,
    pub max_paths: usize,
    pub nworst: usize,
    pub slack_lt: Option<f64>,
    pub slack_gt: Option<f64>,
    pub start_rf: Option<u8>,
    pub end_rf: Option<u8>,
    pub unique_pins: bool,
    /// search effort cap per endpoint (popped search states)
    pub max_pops: usize,
}

#[derive(Clone, Debug)]
pub struct PathRes {
    pub ep: usize,
    pub rec: usize,
    /// launch clock pin (NONE for paths starting at an input port / unclocked source)
    pub launch: u32,
    /// data pins from startpoint to endpoint: (node, transition 0=rise 1=fall, arrival)
    pub points: Vec<(u32, u8, f64)>,
    pub arrival: f64,
    pub required: f64,
    pub crpr: f64,
    pub slack: f64,
}

struct St {
    node: u32,
    rf: u8,
    m: usize,
    suffix: f64,
    parent: usize,
    rec: usize,
    done: bool,
    start_at: f64,
    launch: u32,
    slack: f64,
}

#[derive(PartialEq)]
struct Key(f64, usize);
impl Eq for Key {}
impl PartialOrd for Key {
    fn partial_cmp(&self, o: &Self) -> Option<Ordering> {
        Some(self.cmp(o))
    }
}
impl Ord for Key {
    // min-heap on slack bound; ties: completed (larger id later) — deterministic by id
    fn cmp(&self, o: &Self) -> Ordering {
        o.0.partial_cmp(&self.0).unwrap_or(Ordering::Equal).then(o.1.cmp(&self.1))
    }
}

impl<'a> Timing<'a> {
    fn launch_preds(&self, v: u32) -> impl Iterator<Item = u32> + '_ {
        self.fan_in[v as usize].iter().filter_map(move |&ai| {
            let a = &self.arcs[ai as usize];
            matches!(a.k, AK::Launch(..) | AK::GenLaunch(_)).then_some(a.from)
        })
    }
    fn is_start(&self, v: u32) -> bool {
        self.launch_preds(v).next().is_some() || self.tags[v as usize].iter().any(|t| t.start == v && t.clk != crate::sta::NOCLK)
    }

    /// For every node: the largest number of ordered -through stages a valid prefix (from a
    /// -from startpoint) ending at the node can have completed; -1 = not reachable.
    fn stage_reach(&self, q: &PathQuery) -> Vec<i32> {
        let k = q.through.len();
        let adv = |v: u32, mut j: usize| -> usize {
            while j < k && q.through[j].contains(&v) {
                j += 1;
            }
            j
        };
        let mut best = vec![-1i32; self.nodes.len()];
        for &u in &self.topo {
            if q.exclude.contains(&u) || self.consts[u as usize].is_some() {
                best[u as usize] = -1;
                continue;
            }
            if self.is_start(u) && self.from_ok(q, u) {
                // the launch clock pin is the first point of a register path
                let j0 = self.launch_preds(u).map(|lp| adv(lp, 0)).max().unwrap_or(0);
                best[u as usize] = best[u as usize].max(adv(u, j0) as i32);
            }
            let b = best[u as usize];
            if b < 0 {
                continue;
            }
            for &ai in &self.fan_out[u as usize] {
                let a = &self.arcs[ai as usize];
                if matches!(a.k, AK::Launch(..) | AK::GenLaunch(_)) || self.disabled_arcs.contains(&(a.from, a.to)) {
                    continue;
                }
                let v = a.to;
                if q.exclude.contains(&v) {
                    continue;
                }
                let c = adv(v, b as usize) as i32;
                if c > best[v as usize] {
                    best[v as usize] = c;
                }
            }
        }
        best
    }

    fn from_ok(&self, q: &PathQuery, v: u32) -> bool {
        match &q.from {
            None => true,
            Some(f) => f.contains(&v) || self.launch_preds(v).any(|p| f.contains(&p)),
        }
    }

    /// arrival bound of the (clock, edge) data tags at a node
    fn bound(&self, n: u32, rf: u8, clk: u16, ledge: u8, hold: bool) -> f64 {
        let it = self.tags[n as usize].iter().filter(|t| t.clk == clk && t.ledge == ledge);
        if hold {
            it.map(|t| t.atn[rf as usize]).fold(f64::INFINITY, f64::min)
        } else {
            it.map(|t| t.at[rf as usize]).fold(f64::NEG_INFINITY, f64::max)
        }
    }

    /// Enumerate paths over all endpoints; result sorted by slack (worst first).
    pub fn enumerate_paths(&self, q: &PathQuery) -> Vec<PathRes> {
        let reach = self.stage_reach(q);
        let k = q.through.len();
        let mut eps: Vec<usize> = (0..self.endpoints.len())
            .filter(|&i| {
                let e = &self.endpoints[i];
                let s = if q.hold { e.hold_slack } else { e.setup_slack };
                s.is_finite() && q.to.as_ref().map(|t| t.contains(&e.node)).unwrap_or(true) && !q.exclude.contains(&e.node) && reach[e.node as usize] >= k as i32
            })
            .collect();
        let es = |i: usize| if q.hold { self.endpoints[i].hold_slack } else { self.endpoints[i].setup_slack };
        eps.sort_by(|a, b| es(*a).partial_cmp(&es(*b)).unwrap_or(Ordering::Equal));
        let mut out: Vec<PathRes> = vec![];
        for ei in eps {
            if out.len() >= q.max_paths {
                // every path to this endpoint has slack >= its endpoint slack
                let worst_kept = out.iter().map(|p| p.slack).fold(f64::MIN, f64::max);
                if es(ei) >= worst_kept {
                    break;
                }
            }
            if let Some(l) = q.slack_lt {
                if es(ei) >= l {
                    break;
                }
            }
            let mut v = self.enumerate_endpoint(q, ei, &reach);
            out.append(&mut v);
            out.sort_by(|a, b| a.slack.partial_cmp(&b.slack).unwrap_or(Ordering::Equal));
            out.truncate(q.max_paths);
        }
        out
    }

    fn enumerate_endpoint(&self, q: &PathQuery, ei: usize, reach: &[i32]) -> Vec<PathRes> {
        let ep = &self.endpoints[ei];
        let k = q.through.len();
        let mut arena: Vec<St> = vec![];
        let mut heap = BinaryHeap::new();
        for (ri, r) in ep.reqs.iter().enumerate() {
            if r.hold != q.hold {
                continue;
            }
            if q.end_rf.map(|x| x != r.rf).unwrap_or(false) {
                continue;
            }
            if q.from_clocks.as_ref().map(|c| !c.contains(&r.clk)).unwrap_or(false) || q.to_clocks.as_ref().map(|c| !c.contains(&r.cap_clk)).unwrap_or(false) {
                continue;
            }
            if let Some(gs) = &q.groups {
                let g = if r.group.is_empty() { "**default**" } else { &r.group };
                if !gs.iter().any(|p| crate::netlist::glob(p, g) || (p == "**default**" && r.group.is_empty())) {
                    continue;
                }
            }
            let b = self.bound(ep.node, r.rf, r.clk, r.ledge, q.hold);
            if !b.is_finite() {
                continue;
            }
            let lb = if q.hold { b - r.req } else { r.req - b };
            arena.push(St { node: ep.node, rf: r.rf, m: k, suffix: 0.0, parent: usize::MAX, rec: ri, done: false, start_at: 0.0, launch: NONE, slack: lb });
            heap.push(Key(lb, arena.len() - 1));
        }
        let mut res: Vec<PathRes> = vec![];
        let mut seen_pins: HashSet<Vec<u32>> = HashSet::new();
        let mut pops = 0usize;
        let cap = if q.max_pops == 0 { 200_000 } else { q.max_pops };
        while let Some(Key(prio, id)) = heap.pop() {
            pops += 1;
            if pops > cap || res.len() >= q.nworst {
                break;
            }
            if let Some(l) = q.slack_lt {
                if prio >= l {
                    break; // bounds only grow
                }
            }
            if arena[id].done {
                if q.slack_gt.map(|g| arena[id].slack <= g).unwrap_or(false) {
                    continue;
                }
                let p = self.build_path(&arena, id, ei);
                if q.unique_pins {
                    let key: Vec<u32> = p.points.iter().map(|x| x.0).collect();
                    if !seen_pins.insert(key) {
                        continue;
                    }
                }
                res.push(p);
                continue;
            }
            let (v, rf, m0, suffix, rec) = (arena[id].node, arena[id].rf, arena[id].m, arena[id].suffix, arena[id].rec);
            let r = &ep.reqs[rec];
            let mut m = m0;
            while m > 0 && q.through[m - 1].contains(&v) {
                m -= 1;
            }
            // complete here?
            if self.is_start(v) && self.from_ok(q, v) && q.start_rf.map(|x| x == rf).unwrap_or(true) {
                let tg = self.tags[v as usize].iter().filter(|t| t.clk == r.clk && t.ledge == r.ledge).max_by(|a, b| {
                    let (x, y) = if q.hold { (b.atn[rf as usize], a.atn[rf as usize]) } else { (a.at[rf as usize], b.at[rf as usize]) };
                    x.partial_cmp(&y).unwrap_or(Ordering::Equal)
                });
                if let Some(tg) = tg {
                    let sa = if q.hold { tg.atn[rf as usize] } else { tg.at[rf as usize] };
                    let st = if q.hold { tg.startn } else { tg.start };
                    let launch = if st != v { st } else { NONE };
                    // -through the launch clock pin
                    let mut m2 = m;
                    if launch != NONE {
                        while m2 > 0 && q.through[m2 - 1].contains(&launch) {
                            m2 -= 1;
                        }
                    }
                    if sa.is_finite() && m2 == 0 {
                        let arr = sa + suffix;
                        let crpr = if r.crpr_ok && launch != NONE && r.ck != NONE && self.opts.crpr { self.crpr(launch, r.ck, r.clk).0 } else { 0.0 };
                        let slack = if q.hold { arr - (r.req - crpr) } else { r.req + crpr - arr };
                        arena.push(St { node: v, rf, m: 0, suffix, parent: id, rec, done: true, start_at: sa, launch, slack });
                        heap.push(Key(slack, arena.len() - 1));
                    }
                }
            }
            // expand fan-in (data arcs)
            for &ai in &self.fan_in[v as usize] {
                let a = &self.arcs[ai as usize];
                if matches!(a.k, AK::Launch(..) | AK::GenLaunch(_)) || self.disabled_arcs.contains(&(a.from, a.to)) {
                    continue;
                }
                let u = a.from;
                if q.exclude.contains(&u) || self.consts[u as usize].is_some() || reach[u as usize] < m as i32 {
                    continue;
                }
                let dd = if q.hold { &self.arc_dn } else { &self.arc_d };
                for irf in 0..2u8 {
                    let d = dd[ai as usize][irf as usize][rf as usize];
                    if d.is_nan() {
                        continue;
                    }
                    let b = self.bound(u, irf, r.clk, r.ledge, q.hold);
                    if !b.is_finite() {
                        continue;
                    }
                    let suf = suffix + d;
                    let lb = if q.hold { b + suf - r.req } else { r.req - (b + suf) };
                    arena.push(St { node: u, rf: irf, m, suffix: suf, parent: id, rec, done: false, start_at: 0.0, launch: NONE, slack: lb });
                    heap.push(Key(lb, arena.len() - 1));
                }
            }
        }
        res
    }

    fn build_path(&self, arena: &[St], id: usize, ei: usize) -> PathRes {
        let c = &arena[id];
        let total = c.suffix;
        let mut pts = vec![];
        // the completed state duplicates its start node; walk from its parent
        let mut i = c.parent;
        while i != usize::MAX {
            let s = &arena[i];
            pts.push((s.node, s.rf, c.start_at + (total - s.suffix)));
            i = s.parent;
        }
        let r = &self.endpoints[ei].reqs[c.rec];
        let arrival = c.start_at + total;
        // setup: required = req + crpr, slack = required - arrival; hold: required = req - crpr, slack = arrival - required
        let required = if r.hold { arrival - c.slack } else { arrival + c.slack };
        PathRes { ep: ei, rec: c.rec, launch: c.launch, arrival, required, crpr: (required - r.req).abs(), slack: c.slack, points: pts }
    }

    pub fn node_pin(&self, n: u32) -> PinRef {
        self.nodes[n as usize]
    }
}

