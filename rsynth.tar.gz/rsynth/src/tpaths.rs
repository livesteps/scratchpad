//! Timing path collections (`report_timing -collection`, `get_timing_paths`), path / point
//! attributes, `sort_collection`, the text path report built on the path enumerator, and
//! replayable ECO recording (netlist diff) for automatic ECO commands.
use crate::cons::Obj;
use crate::netlist::{Dir, Netlist, PinRef};
use crate::paths::PathQuery;
use crate::session::*;
use crate::sta::NONE;
use crate::tcl::{split_list, to_list, Flow};
use std::collections::{HashMap, HashSet};
type R = Result<String, Flow>;

#[derive(Clone, Debug)]
pub struct TPoint {
    pub obj: String,
    pub name: String,
    pub cell_type: String,
    pub rf: u8,
    pub at: f64,
    pub incr: f64,
    pub slew: f64,
    pub cap: Option<f64>,
    pub cell: Option<String>,
    pub net: Option<String>,
    pub fanout: usize,
    pub loc: Option<(f64, f64)>,
    /// derates of the arc ending here (None for the launch / start point)
    pub der: Option<crate::sta::PointDerate>,
}

#[derive(Clone, Debug)]
pub struct TPath {
    pub id: usize,
    pub scenario: String,
    pub mode: String,
    pub corner: String,
    pub hold: bool,
    pub slack: f64,
    pub arrival: f64,
    pub required: f64,
    pub crpr: f64,
    pub startpoint: String,
    pub endpoint: String,
    pub sp_clock: Option<String>,
    pub ep_clock: Option<String>,
    pub group: String,
    pub sp_desc: String,
    pub ep_desc: String,
    pub launch_edge: f64,
    pub launch_lat: f64,
    pub launch_lat_kind: String,
    pub launch_rise: bool,
    pub ext_delay: Option<f64>,
    pub points: Vec<TPoint>,
    pub req_detail: Vec<(String, f64)>,
    pub levels: usize,
}

const HDL: &str = "timing_path::";
const HPT: &str = "timing_point::";

/// commands whose netlist changes are recorded as an exact, replayable diff
pub const DIFF_CMDS: &[&str] = &["size_cell", "swap_cell", "change_link", "insert_buffer", "add_buffer_on_route", "clone_cell", "eco_clone", "fix_eco_timing", "eco_opt", "fix_eco_drc", "fix_eco_power", "split_fanout", "size_cells"];

fn tcl_word(s: &str) -> String {
    if s.is_empty() || s.chars().any(|c| " \t[]$\\;\"{}".contains(c)) {
        format!("{{{}}}", s)
    } else {
        s.to_string()
    }
}

/// Replayable ECO commands that turn `b` into `a` (cells/nets matched by name).
pub fn netlist_diff(b: &Netlist, a: &Netlist) -> Vec<String> {
    type CM = HashMap<String, (Option<String>, Vec<(String, Option<String>)>)>;
    let cmap = |nl: &Netlist| -> CM {
        nl.cell_ids()
            .into_iter()
            .map(|c| {
                let cl = nl.cell(c);
                (cl.name.clone(), (cl.lib().map(|s| s.to_string()), cl.pins.iter().map(|p| (p.name.clone(), p.net.map(|n| nl.net(n).name.clone()))).collect()))
            })
            .collect()
    };
    let (bc, ac) = (cmap(b), cmap(a));
    let bn: HashSet<String> = b.net_ids().into_iter().map(|n| b.net(n).name.clone()).collect();
    let an: HashSet<String> = a.net_ids().into_iter().filter(|n| !a.net(*n).conns.is_empty()).map(|n| a.net(n).name.clone()).collect();
    let mut out = vec![];
    let mut new_nets: Vec<&String> = an.iter().filter(|n| !bn.contains(*n)).collect();
    new_nets.sort();
    for n in new_nets {
        out.push(format!("create_net {}", tcl_word(n)));
    }
    let mut names: Vec<&String> = ac.keys().collect();
    names.sort();
    let mut disc = vec![];
    let mut conn = vec![];
    for n in &names {
        let (alib, apins) = &ac[*n];
        match bc.get(*n) {
            None => {
                if let Some(l) = alib {
                    out.push(format!("add_instance -name {} -cell {}", tcl_word(n), l));
                }
                for (p, net) in apins {
                    if let Some(net) = net {
                        conn.push(format!("connect -net {} -pin {}", tcl_word(net), tcl_word(&format!("{}/{}", n, p))));
                    }
                }
            }
            Some((blib, bpins)) => {
                if alib != blib {
                    if let Some(l) = alib {
                        out.push(format!("size_cell {} {}", tcl_word(n), l));
                    }
                }
                let bm: HashMap<&String, &Option<String>> = bpins.iter().map(|(p, x)| (p, x)).collect();
                for (p, net) in apins {
                    let old = bm.get(p).copied().cloned().flatten();
                    if &old != net {
                        let pin = tcl_word(&format!("{}/{}", n, p));
                        if old.is_some() {
                            disc.push(format!("disconnect_pin {}", pin));
                        }
                        if let Some(net) = net {
                            conn.push(format!("connect -net {} -pin {}", tcl_word(net), pin));
                        }
                    }
                }
            }
        }
    }
    // ports
    for p in a.port_ids() {
        let ap = &a.ports[p];
        let Some(bp) = b.port_by_name(&ap.name) else { continue };
        let an_ = ap.net.map(|n| a.net(n).name.clone());
        let bn_ = b.ports[bp].net.map(|n| b.net(n).name.clone());
        if an_ != bn_ {
            if bn_.is_some() {
                disc.push(format!("disconnect_pin {}", tcl_word(&ap.name)));
            }
            if let Some(n) = an_ {
                conn.push(format!("connect -net {} -pin {}", tcl_word(&n), tcl_word(&ap.name)));
            }
        }
    }
    out.extend(disc);
    let mut removed: Vec<&String> = bc.keys().filter(|n| !ac.contains_key(*n)).collect();
    removed.sort();
    for n in removed {
        out.push(format!("delete_instance {}", tcl_word(n)));
    }
    out.extend(conn);
    // dont_touch flags on cells and nets
    for c in a.cell_ids() {
        let cl = a.cell(c);
        if cl.is_hport() {
            continue;
        }
        let before = b.cell_by_name(&cl.name).map(|x| b.cell(x).dont_touch).unwrap_or(false);
        if cl.dont_touch != before {
            out.push(format!("set_dont_touch {} {}", tcl_word(&format!("cell::{}", cl.name)), cl.dont_touch));
        }
    }
    for n in a.net_ids() {
        let nn = a.net(n);
        let before = b.net_by_name(&nn.name).map(|x| b.net(x).dont_touch).unwrap_or(false);
        if nn.dont_touch != before {
            out.push(format!("set_dont_touch {} {}", tcl_word(&format!("net::{}", nn.name)), nn.dont_touch));
        }
    }
    let mut gone: Vec<&String> = bn.iter().filter(|n| !an.contains(*n) && a.net_by_name(n).is_none()).collect();
    gone.sort();
    for n in gone {
        out.push(format!("remove_net -force {}", tcl_word(n)));
    }
    out
}

impl Session {
    /// run an automatic ECO command and record its effect as replayable commands
    pub(crate) fn with_eco_diff(&mut self, name: &str, a: &[String]) -> Option<R> {
        let before = self.nl.clone();
        self.in_eco_diff = true;
        let r = self.cmd(name, a);
        self.in_eco_diff = false;
        if let (Some(Ok(_)), Some(b), Some(after)) = (&r, before.as_ref(), self.nl.as_ref()) {
            let lines = netlist_diff(b, after);
            if !lines.is_empty() {
                self.eco_changes.push(format!("# {} {}  ({} netlist change(s))", name, a.join(" "), lines.len()));
                self.eco_changes.extend(lines);
            }
        }
        r
    }

    /// report_timing / get_timing_paths
    pub(crate) fn c_timing_paths(&mut self, a: &[String], force_collection: bool) -> R {
        let vals = [
            "-format",
            "-delay_type", "-max_paths", "-nworst", "-from", "-to", "-through", "-rise_through", "-fall_through", "-exclude", "-scenarios", "-scenario", "-group", "-groups", "-path_type", "-significant_digits",
            "-slack_lesser_than", "-slack_greater_than", "-clock_from", "-from_clock", "-clock_to", "-to_clock", "-rise_from", "-fall_from", "-rise_to", "-fall_to", "-max_effort",
        ];
        let x = args(a, &vals);
        // ordered, repeatable -through
        let mut thr_specs: Vec<String> = vec![];
        let mut i = 0;
        while i < a.len() {
            if (a[i] == "-through" || a[i] == "-rise_through" || a[i] == "-fall_through") && i + 1 < a.len() {
                thr_specs.push(a[i + 1].clone());
                i += 2;
                continue;
            }
            i += 1;
        }
        let collection = force_collection || x.has("-collection");
        let dt = x.get("-delay_type").cloned().unwrap_or_else(|| if x.has("-hold") && x.has("-setup") { "min_max".into() } else if x.has("-hold") { "min".into() } else { "max".into() });
        let kinds: Vec<bool> = match dt.as_str() {
            "min_max" => vec![false, true],
            s if s.starts_with("min") => vec![true],
            _ => vec![false],
        };
        let np = x.num("-max_paths").unwrap_or(1.0).max(1.0) as usize;
        let nw = x.num("-nworst").unwrap_or(1.0).max(1.0) as usize;
        let dig = x.num("-significant_digits").unwrap_or(4.0) as usize;
        let summary = x.get("-path_type").map(|s| s == "summary" || s == "end").unwrap_or(false);
        // columns: -format {..} or the report_timing_format default; -capacitance / -transition_time /
        // -nets / -input_pins-style flags add their columns in front of the delay
        let mut cols: Vec<String> = match x.get("-format") {
            Some(f) => {
                let mut v = vec![];
                for c in split_list(f) {
                    match canon_column(&c) {
                        Some(k) => v.push(k.to_string()),
                        None => return Err(Flow::Err(format!("report_timing -format: unknown column '{}' (see report_timing_format -help) (CMD-010)", c))),
                    }
                }
                v
            }
            None => self.timing_columns.clone(),
        };
        let mut add = |c: &str| {
            if !cols.iter().any(|x| x == c) {
                let at = cols.iter().position(|x| x == "incr").unwrap_or(cols.len());
                cols.insert(at, c.to_string());
            }
        };
        if x.has("-nets") {
            add("fanout");
            add("net");
        }
        if x.has("-fanout") {
            add("fanout");
        }
        if x.has("-capacitance") {
            add("cap");
        }
        if x.has("-transition_time") || x.has("-transition") {
            add("trans");
        }
        // -derate: applied derate; -derates / -derate_details: user / OCV / AOCV / POCV breakdown
        if x.has("-derate") {
            add("derate");
        }
        if x.has("-derates") || x.has("-derate_details") || x.has("-all_derates") {
            for c in ["user_derate", "ocv_derate", "aocv_derate", "pocv_sigma", "derate"] { add(c); }
        }
        let (from_spec, start_rf) = match (x.get("-from"), x.get("-rise_from"), x.get("-fall_from")) {
            (_, Some(s), _) => (Some(s.clone()), Some(0u8)),
            (_, _, Some(s)) => (Some(s.clone()), Some(1u8)),
            (s, _, _) => (s.cloned(), None),
        };
        let (to_spec, end_rf) = match (x.get("-to"), x.get("-rise_to"), x.get("-fall_to")) {
            (_, Some(s), _) => (Some(s.clone()), Some(0u8)),
            (_, _, Some(s)) => (Some(s.clone()), Some(1u8)),
            (s, _, _) => (s.cloned(), None),
        };
        let from = from_spec.map(|s| self.objs(&s, "clock_or_any"));
        let to = to_spec.map(|s| self.objs(&s, "clock_or_any"));
        let thr: Vec<Vec<Obj>> = thr_specs.iter().map(|s| self.objs(s, "any")).collect();
        let excl = x.get("-exclude").map(|s| self.objs(s, "any")).unwrap_or_default();
        let clk_names = |k: &str, k2: &str| -> Option<Vec<String>> { x.get(k).or(x.get(k2)).map(|s| split_list(s).into_iter().map(|c| Obj::parse(&c).map(|o| o.name().to_string()).unwrap_or(c)).collect()) };
        let cfrom = clk_names("-clock_from", "-from_clock");
        let cto = clk_names("-clock_to", "-to_clock");
        let groups: Option<Vec<String>> = x.get("-groups").or(x.get("-group")).map(|g| split_list(g).into_iter().map(|c| Obj::parse(&c).map(|o| o.name().to_string()).unwrap_or(c)).collect());
        let mut handles = vec![];
        let mut printed_any = false;
        for hold in kinds {
            let mut xs = args(a, &vals);
            if let Some(s) = x.get("-scenario") {
                xs.o.insert("-scenarios".into(), s.clone());
            }
            let scens = self.scen_list(&xs, if hold { "hold" } else { "setup" });
            for si in scens {
                let sc = self.scens[si].clone();
                let q0 = PathQuery {
                    hold,
                    max_paths: np,
                    nworst: nw,
                    slack_lt: x.num("-slack_lesser_than"),
                    slack_gt: x.num("-slack_greater_than"),
                    start_rf,
                    end_rf,
                    unique_pins: x.has("-unique_pins"),
                    groups: groups.clone(),
                    max_pops: x.num("-max_effort").map(|v| v as usize).unwrap_or(0),
                    ..Default::default()
                };
                let (from, to, thr, excl, cfrom, cto) = (from.clone(), to.clone(), thr.clone(), excl.clone(), cfrom.clone(), cto.clone());
                let mut paths: Vec<TPath> = self.with_timing(si, |t| {
                    let mut q = q0.clone();
                    let clk_idx = |n: &str| t.cons.clocks.iter().position(|c| crate::netlist::glob(n, &c.name)).map(|i| i as u16);
                    let split = |v: &Option<Vec<Obj>>| -> (Option<HashSet<u32>>, Option<HashSet<u16>>) {
                        match v {
                            None => (None, None),
                            Some(v) => {
                                let ck: HashSet<u16> = v.iter().filter_map(|o| if let Obj::Clock(c) = o { clk_idx(c) } else { None }).collect();
                                let nodes: HashSet<u32> = v.iter().filter(|o| !matches!(o, Obj::Clock(_))).flat_map(|o| t.resolve(o)).collect();
                                let has_pins = v.iter().any(|o| !matches!(o, Obj::Clock(_)));
                                (if has_pins { Some(nodes) } else { None }, if ck.is_empty() { None } else { Some(ck) })
                            }
                        }
                    };
                    let (f, fc) = split(&from);
                    let (tt, tc) = split(&to);
                    q.from = f;
                    q.to = tt;
                    q.from_clocks = fc;
                    q.to_clocks = tc;
                    if let Some(c) = &cfrom {
                        let s: HashSet<u16> = c.iter().filter_map(|n| clk_idx(n)).collect();
                        q.from_clocks = Some(q.from_clocks.map(|x| x.intersection(&s).copied().collect()).unwrap_or(s));
                    }
                    if let Some(c) = &cto {
                        let s: HashSet<u16> = c.iter().filter_map(|n| clk_idx(n)).collect();
                        q.to_clocks = Some(q.to_clocks.map(|x| x.intersection(&s).copied().collect()).unwrap_or(s));
                    }
                    q.through = thr.iter().map(|v| v.iter().flat_map(|o| t.resolve(o)).collect()).collect();
                    q.exclude = excl.iter().flat_map(|o| t.resolve(o)).collect();
                    let res = t.enumerate_paths(&q);
                    res.iter().map(|p| tpath_of(t, p, &sc)).collect()
                })?;
                if paths.is_empty() && !collection {
                    crate::out!("\nScenario {}: No constrained {} paths.", sc.name, if hold { "min" } else { "max" });
                    continue;
                }
                if summary && !collection {
                    crate::out!("\nScenario {}  ({} paths)\n{:<52} {:<28} {:>10}", sc.name, if hold { "min" } else { "max" }, "Endpoint", "Startpoint", "Slack");
                }
                for p in paths.iter_mut() {
                    p.id = self.tpaths.len();
                    if !collection {
                        printed_any = true;
                        if summary {
                            crate::out!("{:<52} {:<28} {:>10.*} {}", obj_name(&p.endpoint), sp_cell(p), dig, p.slack, if p.slack < 0.0 { "(VIOLATED)" } else { "" });
                        } else {
                            print_path(p, dig, &cols);
                        }
                    }
                    handles.push(format!("{}{}", HDL, p.id));
                    self.tpaths.push(p.clone());
                }
            }
        }
        let _ = printed_any;
        if collection {
            Ok(to_list(&handles))
        } else {
            ok()
        }
    }

    pub(crate) fn path_attr(&self, h: &str, at: &str) -> Option<Option<String>> {
        if let Some(id) = h.strip_prefix(HDL) {
            let p = self.tpaths.get(id.parse::<usize>().ok()?)?;
            let f = |x: f64| format!("{:.6}", x).trim_end_matches('0').trim_end_matches('.').to_string();
            let det = |k: &str| p.req_detail.iter().find(|(l, _)| l.starts_with(k)).map(|x| x.1);
            let v = match at {
                "slack" => Some(f(p.slack)),
                "arrival" => Some(f(p.arrival)),
                "required" => Some(f(p.required)),
                "startpoint" => Some(p.startpoint.clone()),
                "endpoint" => Some(p.endpoint.clone()),
                "startpoint_name" => Some(obj_name(&p.startpoint)),
                "endpoint_name" => Some(obj_name(&p.endpoint)),
                "startpoint_clock" => p.sp_clock.as_ref().map(|c| Obj::Clock(c.clone()).handle()),
                "endpoint_clock" => p.ep_clock.as_ref().map(|c| Obj::Clock(c.clone()).handle()),
                "startpoint_clock_latency" => Some(f(p.launch_lat)),
                "endpoint_clock_latency" => det("clock network delay").map(f),
                "startpoint_clock_open_edge_value" => Some(f(p.launch_edge)),
                "endpoint_clock_close_edge_value" => p.req_detail.first().map(|x| f(x.1)),
                "clock_uncertainty" => det("clock uncertainty").map(|v| f(v.abs())),
                "crpr_value" | "common_path_pessimism" | "clock_reconvergence_pessimism" => Some(f(p.crpr)),
                "endpoint_setup_time_value" => det("library setup").or(det("library recovery")).or(det("library clock gating")).map(|v| f(v.abs())),
                "endpoint_hold_time_value" => det("library hold").or(det("library removal")).map(f),
                "startpoint_input_delay_value" => p.ext_delay.map(f),
                "endpoint_output_delay_value" => det("output external delay").map(|v| f(v.abs())),
                "path_group" | "path_group_name" => Some(if p.group.is_empty() { "**default**".into() } else { p.group.clone() }),
                "path_type" | "delay_type" => Some(if p.hold { "min".into() } else { "max".into() }),
                "scenario" | "scenario_name" => Some(p.scenario.clone()),
                "mode" | "mode_name" => Some(p.mode.clone()),
                "corner" | "corner_name" => Some(p.corner.clone()),
                "points" => Some(to_list(&(0..p.points.len()).map(|k| format!("{}{}:{}", HPT, p.id, k)).collect::<Vec<_>>())),
                "cells" => {
                    let mut seen = vec![];
                    for pt in &p.points {
                        if let Some(c) = &pt.cell {
                            let hd = Obj::Cell(c.clone()).handle();
                            if !seen.contains(&hd) {
                                seen.push(hd);
                            }
                        }
                    }
                    Some(to_list(&seen))
                }
                "nets" => {
                    let mut seen: Vec<String> = vec![];
                    for pt in &p.points {
                        if let Some(n) = &pt.net {
                            let hd = Obj::Net(n.clone()).handle();
                            if !seen.contains(&hd) {
                                seen.push(hd);
                            }
                        }
                    }
                    Some(to_list(&seen))
                }
                "num_logic_levels" | "logic_levels" => Some(p.levels.to_string()),
                "num_points" => Some(p.points.len().to_string()),
                "object_class" => Some("timing_path".into()),
                "full_name" | "name" => Some(format!("path_{}", p.id)),
                _ => None,
            };
            return Some(v);
        }
        if let Some(rest) = h.strip_prefix(HPT) {
            let (pi, k) = rest.split_once(':')?;
            let p = self.tpaths.get(pi.parse::<usize>().ok()?)?;
            let pt = p.points.get(k.parse::<usize>().ok()?)?;
            let f = |x: f64| format!("{:.6}", x).trim_end_matches('0').trim_end_matches('.').to_string();
            let v = match at {
                "object" | "pin" => Some(pt.obj.clone()),
                "arrival" => Some(f(pt.at)),
                "incr" | "delay" => Some(f(pt.incr)),
                "rise_fall" => Some(if pt.rf == 0 { "rise".into() } else { "fall".into() }),
                "transition" | "slew" => Some(f(pt.slew)),
                "capacitance" => pt.cap.map(f),
                "slack" => Some(f(p.slack)),
                "cell" => pt.cell.as_ref().map(|c| Obj::Cell(c.clone()).handle()),
                "ref_name" | "lib_cell" => Some(pt.cell_type.clone()),
                "net" => pt.net.as_ref().map(|n| Obj::Net(n.clone()).handle()),
                "fanout" => Some(pt.fanout.to_string()),
                "derate" | "applied_derate" => pt.der.map(|d| format!("{:.4}", d.applied)),
                "user_derate" => pt.der.and_then(|d| d.user).map(|u| format!("{:.4}", u)),
                "ocv_derate" => pt.der.map(|d| format!("{:.4}", d.ocv)),
                "aocv_derate" => pt.der.and_then(|d| d.aocv).map(|a| format!("{:.4}", a.0)),
                "aocv_depth" => pt.der.and_then(|d| d.aocv).map(|a| a.1.to_string()),
                "pocv_sigma" | "variation" => pt.der.and_then(|d| d.pocv_coef.map(|c| f(c * pt.incr.abs()))),
                "object_class" => Some("timing_point".into()),
                "full_name" | "name" => Some(pt.name.clone()),
                _ => None,
            };
            return Some(v);
        }
        None
    }

    /// sort_collection [-descending] [-dictionary] collection {attributes}
    pub(crate) fn c_sort_collection(&self, a: &[String]) -> R {
        let x = args(a, &[]);
        if x.pos.len() < 2 {
            return Err(Flow::Err("sort_collection [-descending] <collection> <attribute(s)> (CMD-001)".into()));
        }
        let items = split_list(&x.pos[0]);
        let keys = split_list(&x.pos[1]);
        let mut v: Vec<(Vec<String>, String)> = items.into_iter().map(|h| (keys.iter().map(|k| self.attr_pub(&h, k).unwrap_or_default()).collect(), h)).collect();
        v.sort_by(|a, b| {
            for (x, y) in a.0.iter().zip(b.0.iter()) {
                let o = match (x.parse::<f64>(), y.parse::<f64>()) {
                    (Ok(p), Ok(q)) => p.partial_cmp(&q).unwrap_or(std::cmp::Ordering::Equal),
                    _ => x.cmp(y),
                };
                if o != std::cmp::Ordering::Equal {
                    return o;
                }
            }
            std::cmp::Ordering::Equal
        });
        if x.has("-descending") {
            v.reverse();
        }
        Ok(to_list(&v.into_iter().map(|x| x.1).collect::<Vec<_>>()))
    }
}

fn obj_name(h: &str) -> String {
    Obj::parse(h).map(|o| o.name().to_string()).unwrap_or(h.to_string())
}
fn sp_cell(p: &TPath) -> String {
    let n = obj_name(&p.startpoint);
    if p.startpoint.starts_with("pin::") {
        n.rsplit_once('/').map(|x| x.0.to_string()).unwrap_or(n)
    } else {
        n
    }
}

fn pin_handle(t: &crate::sta::Timing, n: u32) -> String {
    match t.nodes[n as usize] {
        PinRef::Port(p) => Obj::Port(t.nl.ports[p].name.clone()).handle(),
        pr => Obj::Pin(t.nl.pin_name(pr)).handle(),
    }
}

fn tpath_of(t: &crate::sta::Timing, p: &crate::paths::PathRes, sc: &crate::cons::Scenario) -> TPath {
    let nl = t.nl;
    let ep = &t.endpoints[p.ep];
    let r = &ep.reqs[p.rec];
    let hold = r.hold;
    let clk = r.clk;
    let (rr, ff) = t.clk_edges[clk as usize];
    let le = if r.ledge == 0 { rr } else { ff };
    let ck = &t.cons.clocks[clk as usize];
    let lat = if p.launch != NONE { if hold { t.launch_clock_lat_early(p.launch, clk) } else { t.launch_clock_lat(p.launch, clk) } } else { ck.src_lat.0 };
    let mut pts = vec![];
    let mk = |n: u32, rf: u8, at: f64, incr: f64, first: bool| -> TPoint {
        let pr = t.nodes[n as usize];
        let drv = nl.is_driver(pr);
        let net = nl.pin_net(pr);
        TPoint {
            obj: pin_handle(t, n),
            name: t.node_name(n),
            cell_type: t.cell_type_of(n),
            rf,
            at,
            incr,
            slew: t.pin_slew_timed(pr),
            cap: if drv { net.map(|nn| t.net_c[nn]) } else { None },
            cell: match pr {
                PinRef::Cell(c, _) => Some(nl.cell(c).name.clone()),
                _ => None,
            },
            net: net.map(|nn| nl.net(nn).name.clone()),
            fanout: if drv { net.map(|nn| nl.loads(nn).len()).unwrap_or(0) } else { 0 },
            loc: nl.pin_loc(pr),
            der: if first { None } else { Some(t.point_derates(n, hold, false)) },
        }
    };
    let mut prev = le + lat;
    if p.launch != NONE {
        pts.push(mk(p.launch, if r.ledge == 0 { 0 } else { 1 }, le + lat, 0.0, true));
    }
    let ext = if p.launch == NONE { p.points.first().map(|x| x.2 - (le + lat)) } else { None };
    if let Some(e) = ext {
        prev += e;
    }
    let mut levels = 0;
    for (k, (n, rf, at)) in p.points.iter().enumerate() {
        let pt = mk(*n, *rf, *at, at - prev, k == 0 && p.launch == NONE);
        if k > 0 && pt.cap.is_some() && pt.cell.is_some() {
            levels += 1;
        }
        prev = *at;
        pts.push(pt);
    }
    let desc = |n: u32, start: bool, clk: &Option<String>| -> String {
        match t.nodes[n as usize] {
            PinRef::Port(q) => format!("{} ({} port{})", nl.ports[q].name, if start { "input" } else { "output" }, clk.as_ref().map(|c| format!(" clocked by {}", c)).unwrap_or_default()),
            PinRef::Cell(c, _) => {
                let ty = t.cell_type_of(n);
                let latch = ty.contains("LAT") || ty.contains("Latch");
                let icg = ty.contains("ICG") || ty.contains("CKGT") || ty.contains("CG");
                format!("{} ({} clocked by {})", nl.cell(c).name, if icg { "clock gating element" } else if latch { "positive level-sensitive latch" } else { "rising edge-triggered flip-flop" }, clk.clone().unwrap_or("-".into()))
            }
        }
    };
    let spn = if p.launch != NONE { p.launch } else { p.points[0].0 };
    let lname = Some(ck.name.clone());
    let cname = Some(t.cons.clocks[r.cap_clk as usize].name.clone());
    let mut det = r.detail.clone();
    if p.crpr > 1e-12 {
        det.push(("clock reconvergence pessimism".into(), if hold { -p.crpr } else { p.crpr }));
    }
    TPath {
        id: 0,
        scenario: sc.name.clone(),
        mode: sc.mode.clone(),
        corner: sc.corner.clone(),
        hold,
        slack: p.slack,
        arrival: p.arrival,
        required: p.required,
        crpr: p.crpr,
        startpoint: pin_handle(t, spn),
        endpoint: pin_handle(t, ep.node),
        sp_clock: lname.clone(),
        ep_clock: cname.clone(),
        group: r.group.clone(),
        sp_desc: desc(spn, true, &lname),
        ep_desc: desc(ep.node, false, &cname),
        launch_edge: le,
        launch_lat: lat,
        launch_rise: r.ledge == 0,
        launch_lat_kind: if ck.propagated { "propagated".into() } else { "ideal".into() },
        ext_delay: ext,
        points: pts,
        req_detail: det,
        levels,
    }
}

/// report_timing columns
pub const COLUMNS: &[(&str, &str)] = &[
    ("point", "pin / port name (with the library cell in parentheses when 'cell' is shown next to it)"),
    ("instance", "instance name"),
    ("cell", "library cell (ref_name)"),
    ("fanout", "fanout of the net driven at this point"),
    ("cap", "load capacitance (pF) at driver points"),
    ("trans", "transition (ns)"),
    ("incr", "incremental delay (ns)"),
    ("path", "path arrival time (ns)"),
    ("edge", "rise / fall (r / f)"),
    ("net", "net name at driver points"),
    ("location", "pin location (x y, um)"),
    ("required", "required time at the point (ns)"),
    ("slack", "slack at the point (ns)"),
    ("derate", "derate applied to the arc delay (user / object, else AOCV, else OCV)"),
    ("user_derate", "object derate from set_timing_derate on the cell / lib cell / net (- if none)"),
    ("ocv_derate", "corner OCV derate (set_timing_derate -early / -late, cell or net)"),
    ("aocv_derate", "AOCV derate and depth (d) of the cell arc (AOCV analysis on)"),
    ("pocv_sigma", "POCV sigma of the arc delay (coefficient x delay, ns; POCV analysis on)"),
];

pub fn canon_column(c: &str) -> Option<&'static str> {
    Some(match c.to_lowercase().as_str() {
        "point" | "pin" | "hpin" | "timing_point" | "name" => "point",
        "instance" | "inst" | "instance_name" => "instance",
        "cell" | "ref" | "ref_name" | "lib_cell" | "cell_type" => "cell",
        "fanout" | "fo" => "fanout",
        "cap" | "capacitance" | "load" | "load_cap" => "cap",
        "trans" | "transition" | "slew" | "transition_time" => "trans",
        "incr" | "delay" | "increment" => "incr",
        "path" | "arrival" | "time" => "path",
        "edge" | "rf" | "rise_fall" | "transition_type" => "edge",
        "net" | "net_name" => "net",
        "location" | "loc" | "pin_location" => "location",
        "required" | "required_time" => "required",
        "slack" => "slack",
        "derate" | "applied_derate" | "timing_derate" => "derate",
        "user_derate" | "user" | "object_derate" | "set_timing_derate" => "user_derate",
        "ocv" | "ocv_derate" | "corner_derate" => "ocv_derate",
        "aocv" | "aocv_derate" => "aocv_derate",
        "pocv" | "pocv_sigma" | "socv" | "sigma" | "variation" => "pocv_sigma",
        _ => return None,
    })
}

pub fn default_columns() -> Vec<String> {
    ["point", "cell", "incr", "path", "edge"].iter().map(|s| s.to_string()).collect()
}

fn col_width(c: &str, namew: usize) -> usize {
    match c {
        "point" => namew,
        "instance" => namew.min(44),
        "cell" => 16,
        "net" => 36,
        "location" => 18,
        "edge" => 4,
        "fanout" => 6,
        "aocv_derate" => 12,
        "user_derate" | "ocv_derate" | "derate" => 8,
        _ => 10,
    }
}

fn print_path(p: &TPath, dig: usize, cols: &[String]) {
    let cols: Vec<&str> = cols.iter().map(|s| s.as_str()).collect();
    let has = |c: &str| cols.contains(&c);
    // point and cell side by side: "pin (cell)" in one column, as in the classic report
    let merged = has("point") && has("cell") && cols.iter().position(|c| *c == "cell") == cols.iter().position(|c| *c == "point").map(|i| i + 1);
    let shown: Vec<&str> = cols.iter().copied().filter(|c| !(merged && *c == "cell")).collect();
    let namew = p.points.iter().map(|pt| pt.name.len() + if merged { pt.cell_type.len() + 3 } else { 0 }).max().unwrap_or(20).clamp(30, 70);
    let right = |c: &str| !matches!(c, "point" | "instance" | "cell" | "net" | "location" | "edge");
    let fmt = |c: &str, v: &str| -> String {
        let w = col_width(c, namew);
        if right(c) { format!("{:>w$}", v, w = w) } else { format!("{:<w$}", v, w = w) }
    };
    let line = |vals: &dyn Fn(&str) -> String| -> String {
        let mut s = String::from(" ");
        for c in &shown {
            s.push(' ');
            s.push_str(&fmt(c, &vals(c)));
        }
        s.trim_end().to_string()
    };
    let f = |x: f64| format!("{:.*}", dig, x);
    crate::out!("\n  Startpoint: {}", p.sp_desc);
    crate::out!("  Endpoint: {}", p.ep_desc);
    crate::out!("  Mode: {}   Corner: {}\n  Scenario: {}\n  Path Group: {}\n  Path Type: {}\n", p.mode, p.corner, p.scenario, if p.group.is_empty() { "**default**" } else { &p.group }, if p.hold { "min" } else { "max" });
    let head = line(&|c: &str| {
        match c {
            "point" => if merged { "Point (cell)".into() } else { "Point".into() },
            "instance" => "Instance".into(),
            "cell" => "Cell".into(),
            "fanout" => "Fanout".into(),
            "cap" => "Cap".into(),
            "trans" => "Trans".into(),
            "incr" => "Incr".into(),
            "path" => "Path".into(),
            "edge" => "R/F".into(),
            "net" => "Net".into(),
            "location" => "Location".into(),
            "required" => "Required".into(),
            "slack" => "Slack".into(),
            "derate" => "Derate".into(),
            "user_derate" => "UserDer".into(),
            "ocv_derate" => "OCV".into(),
            "aocv_derate" => "AOCV(d)".into(),
            "pocv_sigma" => "POCVsig".into(),
            _ => String::new(),
        }
    });
    let rule = format!("  {}", "-".repeat(head.len().saturating_sub(2).max(20)));
    crate::out!("{}", head);
    crate::out!("{}", rule);
    // label rows (clock edge, latency, data arrival ...) put the label in the first text column
    let label_col = shown.iter().copied().find(|c| !right(c)).unwrap_or("point");
    let lrow = |label: &str, incr: Option<f64>, path: Option<f64>| -> String {
        line(&|c: &str| {
            if c == label_col {
                label.to_string()
            } else if c == "incr" {
                incr.map(f).unwrap_or_default()
            } else if c == "path" {
                path.map(f).unwrap_or_default()
            } else {
                String::new()
            }
        })
    };
    crate::out!("{}", lrow(&format!("clock {} ({} edge)", p.sp_clock.clone().unwrap_or_default(), if p.launch_rise { "rise" } else { "fall" }), Some(p.launch_edge), Some(p.launch_edge)));
    crate::out!("{}", lrow(&format!("clock network delay ({})", p.launch_lat_kind), Some(p.launch_lat), Some(p.launch_edge + p.launch_lat)));
    if let Some(e) = p.ext_delay {
        let first = p.points.first().map(|x| x.at).unwrap_or(0.0);
        crate::out!("{}", lrow("input external delay", Some(e), Some(first)));
    }
    // required at a point: arrival + slack (setup) / arrival - slack (hold)
    for (k, pt) in p.points.iter().enumerate() {
        let incr = if k == 0 && p.ext_delay.is_some() { 0.0 } else { pt.incr };
        let inst = pt.cell.clone().unwrap_or_default();
        crate::out!(
            "{}",
            line(&|c: &str| match c {
                "point" => if merged { format!("{} ({})", pt.name, pt.cell_type) } else { pt.name.clone() },
                "instance" => inst.clone(),
                "cell" => pt.cell_type.clone(),
                "fanout" => if pt.cap.is_some() { pt.fanout.to_string() } else { String::new() },
                "cap" => pt.cap.map(|c| format!("{:.*}", dig, c)).unwrap_or_default(),
                "trans" => f(pt.slew),
                "incr" => f(incr),
                "path" => f(pt.at),
                "edge" => if pt.rf == 0 { "r".into() } else { "f".into() },
                "net" => if pt.cap.is_some() { pt.net.clone().unwrap_or_default() } else { String::new() },
                "location" => pt.loc.map(|(x, y)| format!("({:.2}, {:.2})", x, y)).unwrap_or_default(),
                "required" => f(if p.hold { pt.at - p.slack } else { pt.at + p.slack }),
                "slack" => f(p.slack),
                "derate" => pt.der.map(|d| format!("{:.3}", d.applied)).unwrap_or_default(),
                "user_derate" => pt.der.map(|d| d.user.map(|u| format!("{:.3}", u)).unwrap_or("-".into())).unwrap_or_default(),
                "ocv_derate" => pt.der.map(|d| format!("{:.3}", d.ocv)).unwrap_or_default(),
                "aocv_derate" => pt.der.map(|d| d.aocv.map(|(a, k)| format!("{:.3}/d{}", a, k)).unwrap_or("-".into())).unwrap_or_default(),
                "pocv_sigma" => pt.der.map(|d| d.pocv_coef.map(|c| format!("{:.*}", dig, c * pt.incr.abs())).unwrap_or("-".into())).unwrap_or_default(),
                _ => String::new(),
            })
        );
    }
    crate::out!("{}\n", lrow("data arrival time", None, Some(p.arrival)));
    let mut acc = 0.0;
    for (k, (lbl, v)) in p.req_detail.iter().enumerate() {
        acc = if k == 0 { *v } else { acc + v };
        crate::out!("{}", lrow(lbl, Some(*v), Some(acc)));
    }
    crate::out!("{}", lrow("data required time", None, Some(p.required)));
    crate::out!("{}", rule);
    if p.hold {
        crate::out!("{}", lrow("data arrival time", None, Some(p.arrival)));
        crate::out!("{}", lrow("data required time", None, Some(-p.required)));
    } else {
        crate::out!("{}", lrow("data required time", None, Some(p.required)));
        crate::out!("{}", lrow("data arrival time", None, Some(-p.arrival)));
    }
    crate::out!("{}", rule);
    crate::out!("{}\n", lrow(&format!("slack ({})", if p.slack < 0.0 { "VIOLATED" } else { "MET" }), None, Some(p.slack)));
}

#[allow(dead_code)]
fn _unused(_: Dir) {}
