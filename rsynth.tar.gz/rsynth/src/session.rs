//! Tool session and command set (Fusion-Compiler-style shell).

use crate::cons::*;
use crate::dft::DftCfg;
use crate::elab::{elaborate, ElabOpts};
use crate::hdl::HdlLib;
use crate::liberty::Library;
use crate::netlist::*;
use crate::opt::Env;
use crate::phys::Floorplan;
use crate::sta::{LibSet, StaOpts, Timing};
use crate::tcl::{self, err, split_list, to_list, Flow, Host, Interp, R};
use crate::upf::Upf;
use std::collections::{BTreeMap, HashMap, HashSet};

pub struct Session {
    pub interp: Interp,
    pub libs: Vec<Library>,
    /// LEF macro abstracts (read_lef) and routing layers
    pub lef: HashMap<String, crate::lef::LefMacro>,
    pub lef_layers: Vec<crate::lef::LefLayer>,
    /// LEF SITE definitions (name, class, size)
    pub lef_sites: Vec<crate::lef::LefSite>,
    /// set_dont_use history (pattern, value), replayed onto libraries read later
    pub dont_use_cmds: Vec<(String, bool)>,
    pub sdc_unsupported: HashSet<String>,
    pub sdc_unsupported_count: std::collections::BTreeMap<String, usize>,
    /// dont_touch on unmapped hierarchies (prefix, value), applied right after mapping
    pub dont_touch_hier: Vec<(String, bool)>,
    /// set_boundary_optimization overrides (instance pattern, value), last wins
    pub bopt: Vec<(String, bool)>,
    /// set_ungroup marks (instance pattern, value)
    pub ungroup_marks: Vec<(String, bool)>,
    /// instances ungrouped so far (re-applied after re-elaboration)
    pub ungrouped: std::collections::BTreeSet<String>,
    pub simple_names: std::collections::BTreeSet<String>,
    pub last_elab: Vec<String>,
    /// ECO change log (replayable command lines)
    pub eco_changes: Vec<String>,
    /// manual route edits (report_route_edits)
    pub route_edits: Vec<String>,
    /// post-mask ECO base snapshot (set_eco_mode -post_mask)
    pub eco_base: Option<crate::ecomask::EcoBase>,
    pub tpaths: Vec<crate::tpaths::TPath>,
    pub in_eco_diff: bool,
    pub user_props: HashMap<(String, String), String>,
    pub user_prop_defaults: HashMap<String, String>,
    pub epoch: std::cell::Cell<u64>,
    pub pin_cache: std::cell::RefCell<(u64, HashMap<Option<usize>, crate::pintime::PinSnap>)>,
    pub prop_scen: std::cell::Cell<Option<usize>>,
    pub phys_cache: std::cell::RefCell<(u64, HashMap<PinRef, (f64, f64, usize)>)>,
    pub spef_rc: HashMap<String, std::sync::Arc<crate::droute::RoutedRc>>,
    pub spef_stats: HashMap<String, crate::spef::SpefStats>,
    pub ann_delays: Vec<((String, String, String), crate::sta::AnnDelay)>,
    pub analysis_type: String,
    pub timing_columns: Vec<String>,
    pub name_rules: HashMap<String, crate::names::NameRules>,
    pub pragma_notes: Vec<String>,
    pub pragmas_applied: usize,
    pub qtm: Option<crate::models::Qtm>,
    pub himpl: Option<crate::hflow::HierImpl>,
    pub opt_ctl: Option<crate::optctl::OptCtl>,
    /// set while place_opt / clock_opt / route_opt run their body (Some(incremental))
    pub flow_body: Option<bool>,
    /// clock nets marked dont_touch by CTS
    pub cts_nets: Vec<String>,
    /// AOCV tables / POCV coefficients
    pub ocv: crate::sta::Ocv,
    /// detailed routes and their extracted RC
    pub routes: Option<crate::droute::RouteDb>,
    pub routed_rc: Option<std::sync::Arc<crate::droute::RoutedRc>>,
    /// global-route timing engine parasitics: (signature, trees)
    pub gr_cache: std::cell::RefCell<Option<(u64, std::sync::Arc<crate::droute::RoutedRc>)>>,
    /// GUI/console selection (object handles)
    pub selection: Vec<String>,
    /// GUI: highlighted power domains and the cell colouring ("hier" | "pd")
    pub pd_hl: Vec<String>,
    /// GUI flyline / schematic selection
    pub gui: crate::guisch::GuiState,
    pub gui_color_by: String,
    /// current_instance scope ("" = top)
    pub cur_inst: String,
    /// true while sync_boundaries re-elaborates (keeps ungroup state)
    pub reelab: bool,
    pub hdl: HdlLib,
    pub nl: Option<Netlist>,
    pub top: Option<String>,
    pub latches: Vec<String>,
    pub multi_inst: Vec<(String, Vec<String>)>,
    pub bbs: Vec<(String, String, &'static str)>,
    pub modes: Vec<Mode>,
    pub corners: Vec<Corner>,
    pub scens: Vec<Scenario>,
    pub cur_mode: usize,
    pub cur_corner: usize,
    pub implicit: (bool, bool, bool),
    pub app: BTreeMap<String, String>,
    pub upf: Upf,
    pub fp: Option<Floorplan>,
    pub dft: DftCfg,
    /// advanced DFT state (OCC, compression, boundary scan, MBIST, patterns)
    pub dftx: crate::dftadv::DftAdv,
    /// power / ground planning, route rules, verification markers
    pub pgx: crate::pg::PgState,
    pub atpg: Option<crate::atpg::PatternSet>,
    pub dont_use: Vec<String>,
    pub bb_designs: HashSet<String>,
    pub activity: Vec<(String, f64)>,
    pub stages_done: Vec<String>,
    pub exit: bool,
    pub uniquified: bool,
    pub cg_exclude: Vec<String>,
    pub golden: Option<Netlist>,
    pub partitions: Vec<crate::part::Partition>,
}

pub(crate) struct A {
    pub pos: Vec<String>,
    pub o: HashMap<String, String>,
    pub f: HashSet<String>,
}
impl A {
    pub fn get(&self, k: &str) -> Option<&String> {
        self.o.get(k)
    }
    pub fn has(&self, k: &str) -> bool {
        self.f.contains(k) || self.o.contains_key(k)
    }
    pub fn num(&self, k: &str) -> Option<f64> {
        self.o.get(k).and_then(|s| s.trim().parse().ok())
    }
}
pub(crate) fn args(a: &[String], vals: &[&str]) -> A {
    let mut r = A { pos: vec![], o: HashMap::new(), f: HashSet::new() };
    let mut i = 0;
    while i < a.len() {
        let x = &a[i];
        let is_opt = x.starts_with('-') && x.len() > 1 && !x[1..].starts_with(|c: char| c.is_ascii_digit() || c == '.');
        if is_opt {
            if vals.contains(&x.as_str()) && i + 1 < a.len() {
                r.o.insert(x.clone(), a[i + 1].clone());
                i += 2;
                continue;
            }
            r.f.insert(x.clone());
        } else {
            r.pos.push(x.clone());
        }
        i += 1;
    }
    r
}
fn fnum(s: &str) -> Result<f64, Flow> {
    s.trim().parse::<f64>().map_err(|_| Flow::Err(format!("expected a number, got '{}' (CMD-009)", s)))
}
pub(crate) fn ok() -> R {
    Ok(String::new())
}
pub(crate) fn e2f(e: String) -> Flow {
    Flow::Err(e)
}

impl Host for Session {
    fn interp(&mut self) -> &mut Interp {
        &mut self.interp
    }
    fn command(&mut self, name: &str, a: &[String]) -> Option<R> {
        self.cmd(name, a)
    }
}

impl Default for Session {
    fn default() -> Self {
        Self::new()
    }
}

impl Session {
    pub fn new() -> Session {
        let mut app = BTreeMap::new();
        for (k, v) in [
            ("hdlin.elaborate.empty_module_as_blackbox", "true"),
            ("hdlin.adder_architecture", "kogge_stone"),
            ("time.enable_preset_clear_arcs", "false"),
            ("compile.clockgate.enable", "false"),
            ("compile.clockgate.min_bitwidth", "3"),
            ("compile.clockgate.max_fanout", "64"),
            ("compile.retiming.enable", "false"),
            ("compile.seqmap.remove_constant_registers", "true"),
            ("compile.seqmap.merge_equal_registers", "true"),
            ("compile.flow.boundary_optimization", "true"),
            ("place.site_width", "0.2"),
            ("place.routing_blockage_density", "60"),
            ("cts.buffers", "BUF_X2_SVT BUF_X4_SVT BUF_X8_SVT"),
            ("route.detail.grid", "0"),
            ("time.aocvm_enable_analysis", "false"),
            ("time.pocvm_enable_analysis", "false"),
            ("time.pocvm_corner_sigma", "3"),
            ("time.pocvm_default_coefficient", "0"),
            ("time.remove_clock_reconvergence_pessimism", "true"),
            ("route_opt.iterations", "2"),
            ("route.detail.max_iterations", "30"),
            ("route.detail.via_cost", "3"),
            ("route.detail.wrong_way_cost", "3"),
            ("route.detail.max_grid_nodes", "120000000"),
            ("route.via_resistance", "0.005"),
            ("cts.delay_cells", "BUF_X1_SVT"),
            ("cts.max_fanout", "16"),
            ("cts.max_capacitance", "0.08"),
            ("cts.max_transition", "0.15"),
            ("cts.target_skew", "0.03"),
            ("cts.target_latency", "0"),
            ("cts.balance_iterations", "12"),
            ("cts.max_transition", "0.15"),
            ("place.macro_default_size", "16"),
            ("place.detail.passes", "3"),
            ("place.legalize", "true"),
            ("compile.flow.autoungroup", "false"),
            ("compile.flow.autoungroup.max_cells", "30"),
            ("compile.flow.autoungroup.mode", "area"),
            ("compile.flow.flatten", "false"),
            ("compile.map.vt", ""),
            ("compile.map.area_recovery", "true"),
            ("opt.tie_cell.max_fanout", "8"),
            ("opt.hfn.threshold", "32"),
            ("opt.hfn.max_fanout", "16"),
            ("opt.timing.max_iterations", "20"),
            ("opt.timing.allow_vt_swap", "true"),
            ("opt.timing.allow_cloning", "true"),
            ("opt.leakage.enable", "true"),
            ("opt.area.recovery", "true"),
            ("opt.recovery.slack_margin", "0.05"),
            ("opt.hold.margin", "0.01"),
            ("opt.vt_order", "UHVT HVT SVT LVT ULVT"),
            ("time.wire_c_per_um", "0.0002"),
            ("time.wire_r_per_um", "0.002"),
            ("time.zero_wire_load", "false"),
            ("time.delay_calculation_model", "elmore"),
            ("time.delay_calculation_ceff", "false"),
            ("time.coupling_miller_factor", "1.0"),
            ("time.global_route_parasitics", "false"),
            ("time.gr_layer_thresholds", "50 200"),
            ("time.gr_segment_length", "10"),
            ("extract.mode", "fast"),
            ("extract.lateral_fraction", "0.3"),
            ("extract.coupled_scale", "1.2"),
            ("extract.isolated_scale", "0.5"),
            ("check_timing.snake_levels", "40"),
            ("check_timing.snake_hier_crossings", "6"),
            ("check_timing.high_fanout", "64"),
            ("power.default_toggle_rate", "0.1"),
            ("place.coarse.iterations", "12"),
            ("place.coarse.max_density", "0.7"),
            ("budget.mode", "proportional"),
            ("budget.ratio", "0.5"),
            ("budget.margin", "0.0"),
            ("place.bin_size", "0"),
            ("route.global.gcell_size", "0"),
            ("dft.scan.style", "multiplexed_flip_flop"),
        ] {
            app.insert(k.to_string(), v.to_string());
        }
        Session {
            interp: Interp::default(),
            libs: vec![],
            lef: HashMap::new(),
            lef_layers: vec![],
            dont_use_cmds: vec![],
            sdc_unsupported: HashSet::new(),
            sdc_unsupported_count: Default::default(),
            dont_touch_hier: vec![],
            bopt: vec![],
            ungroup_marks: vec![],
            ungrouped: Default::default(),
            simple_names: Default::default(),
            last_elab: vec![],
            eco_changes: vec![],
            route_edits: vec![],
            eco_base: None,
            tpaths: vec![],
            in_eco_diff: false,
            user_props: HashMap::new(),
            user_prop_defaults: HashMap::new(),
            epoch: std::cell::Cell::new(0),
            pin_cache: std::cell::RefCell::new((u64::MAX, HashMap::new())),
            prop_scen: std::cell::Cell::new(None),
            phys_cache: std::cell::RefCell::new((u64::MAX, HashMap::new())),
            spef_rc: HashMap::new(),
            spef_stats: HashMap::new(),
            ann_delays: vec![],
            analysis_type: "ocv".into(),
            timing_columns: crate::tpaths::default_columns(),
            name_rules: HashMap::new(),
            pragma_notes: vec![],
            pragmas_applied: 0,
            qtm: None,
            himpl: None,
            opt_ctl: None,
            flow_body: None,
            cts_nets: vec![],
            ocv: Default::default(),
            routes: None,
            routed_rc: None,
            gr_cache: std::cell::RefCell::new(None),
            selection: vec![],
            pd_hl: vec![],
            gui: Default::default(),
            dftx: Default::default(),
            pgx: Default::default(),
            lef_sites: vec![],
            atpg: None,
            gui_color_by: "hier".into(),
            cur_inst: String::new(),
            reelab: false,
            hdl: HdlLib::default(),
            nl: None,
            top: None,
            latches: vec![],
            multi_inst: vec![],
            bbs: vec![],
            modes: vec![Mode { name: "default".into(), sdc: Constraints::default() }],
            corners: vec![Corner::new("default")],
            scens: vec![Scenario { name: "default".into(), mode: "default".into(), corner: "default".into(), active: true, setup: true, hold: true, leakage: true, dynamic: true, max_tran: true, max_cap: true }],
            cur_mode: 0,
            cur_corner: 0,
            implicit: (true, true, true),
            app,
            upf: Upf::default(),
            fp: None,
            dft: DftCfg { chain_count: 1, ..Default::default() },
            dont_use: vec![],
            bb_designs: HashSet::new(),
            activity: vec![],
            stages_done: vec![],
            exit: false,
            uniquified: false,
            cg_exclude: vec![],
            golden: None,
            partitions: vec![],
        }
    }

    pub fn eval(&mut self, script: &str) -> R {
        tcl::eval(self, script)
    }

    pub(crate) fn appb(&self, k: &str) -> bool {
        matches!(self.app.get(k).map(|s| s.as_str()), Some("true") | Some("1"))
    }
    pub(crate) fn appf(&self, k: &str) -> f64 {
        self.app.get(k).and_then(|s| s.parse().ok()).unwrap_or(0.0)
    }
    pub(crate) fn appu(&self, k: &str) -> usize {
        self.appf(k) as usize
    }
    pub(crate) fn sta_opts(&self) -> StaOpts {
        StaOpts { c_per_um: self.appf("time.wire_c_per_um"), r_per_um: self.appf("time.wire_r_per_um"), zero_wire: self.appb("time.zero_wire_load"), use_placement: self.fp.is_some(), preset_clear: self.appb("time.enable_preset_clear_arcs"), route_len: self.fp.as_ref().and_then(|f| f.groute.as_ref()).map(|g| std::sync::Arc::new(g.net_len.clone())), routed: self.routed_rc.clone().or_else(|| self.gr_parasitics()), ocv: Some(std::sync::Arc::new({ let mut o = self.ocv.clone(); o.pocv_default = self.appf("time.pocvm_default_coefficient"); o })), aocv_on: self.appb("time.aocvm_enable_analysis") && self.analysis_type != "single_corner", pocv_k: if self.appb("time.pocvm_enable_analysis") && self.analysis_type != "single_corner" { self.appf("time.pocvm_corner_sigma").max(0.0) } else { 0.0 }, crpr: self.appb("time.remove_clock_reconvergence_pessimism"), spef: self.sta_overrides().0, ann: self.sta_overrides().1, ignore_derates: self.analysis_type == "single_corner",
            dmodel: crate::rcnet::Model::parse(self.app.get("time.delay_calculation_model").map(|s| s.as_str()).unwrap_or("elmore")).unwrap_or(crate::rcnet::Model::Elmore),
            ceff: self.appb("time.delay_calculation_ceff"),
            miller: { let m = self.appf("time.coupling_miller_factor"); if m > 0.0 { m } else { 1.0 } },
            ..Default::default() }
    }
    pub(crate) fn nl(&self) -> Result<&Netlist, Flow> {
        self.nl.as_ref().ok_or_else(|| Flow::Err("No current design; run elaborate/link first (UID-109)".into()))
    }
    pub(crate) fn nlm(&mut self) -> Result<&mut Netlist, Flow> {
        self.nl.as_mut().ok_or_else(|| Flow::Err("No current design; run elaborate/link first (UID-109)".into()))
    }
    fn cons(&mut self) -> &mut Constraints {
        let m = self.cur_mode;
        &mut self.modes[m].sdc
    }
    fn corner_libs(&self, c: &Corner) -> Corner {
        let mut c = c.clone();
        if c.libs.is_empty() {
            c.libs = (0..self.libs.len()).collect();
        }
        c
    }
    pub(crate) fn libset<'a>(&'a self, c: &Corner) -> LibSet<'a> {
        crate::out::libs_for(&self.libs, c)
    }
    pub(crate) fn target_idx(&self) -> usize {
        if let Some(t) = self.app.get("target_library") {
            for n in split_list(t) {
                if let Some(i) = self.libs.iter().position(|l| l.name == n || l.file.ends_with(&n)) {
                    return i;
                }
            }
        }
        for s in self.scens.iter().filter(|s| s.active && s.setup) {
            if let Some(c) = self.corners.iter().find(|c| c.name == s.corner) {
                if let Some(&i) = c.libs.first() {
                    return i;
                }
            }
        }
        0
    }
    pub(crate) fn scen_corner_mode_pub(&self, si: usize) -> (&Constraints, Corner) {
        self.scen_corner_mode(si)
    }
    pub(crate) fn corner_libs_pub(&self, c: &Corner) -> Corner {
        self.corner_libs(c)
    }
    fn scen_corner_mode(&self, si: usize) -> (&Constraints, Corner) {
        let s = &self.scens[si];
        let m = self.modes.iter().find(|m| m.name == s.mode).map(|m| &m.sdc).unwrap_or(&self.modes[0].sdc);
        let c = self.corners.iter().find(|c| c.name == s.corner).cloned().unwrap_or(Corner::new("default"));
        (m, self.corner_libs(&c))
    }
    pub(crate) fn with_timing<X>(&self, si: usize, f: impl FnOnce(&Timing) -> X) -> Result<X, Flow> {
        let nl = self.nl()?;
        let (cons, corner) = self.scen_corner_mode(si);
        let ls = self.libset(&corner);
        let mut t = Timing::new(nl, &ls, cons, &corner, self.sta_opts());
        t.run();
        Ok(f(&t))
    }
    /// -scenario / -view for property queries
    pub(crate) fn scen_opt(&self, x: &A) -> Result<Option<usize>, Flow> {
        match x.get("-scenario").or(x.get("-scenarios")).or(x.get("-view")) {
            None => Ok(None),
            Some(n) => (0..self.scens.len()).find(|&i| &self.scens[i].name == n).map(Some).ok_or_else(|| Flow::Err(format!("Scenario '{}' does not exist (MV-SCN)", n))),
        }
    }
    pub(crate) fn active(&self, kind: &str) -> Vec<usize> {
        (0..self.scens.len())
            .filter(|&i| {
                let s = &self.scens[i];
                s.active
                    && match kind {
                        "setup" => s.setup,
                        "hold" => s.hold,
                        "leakage" => s.leakage,
                        "dynamic" => s.dynamic,
                        _ => true,
                    }
            })
            .collect()
    }
    pub(crate) fn scen_list(&self, a: &A, kind: &str) -> Vec<usize> {
        if let Some(s) = a.get("-scenarios") {
            let names = split_list(s);
            return (0..self.scens.len()).filter(|i| names.iter().any(|n| glob(n, &self.scens[*i].name))).collect();
        }
        let v = self.active(kind);
        if v.is_empty() {
            self.active("")
        } else {
            v
        }
    }

    /// Build the optimization environment (MMMC concurrent)
    pub(crate) fn with_env<X>(&mut self, f: impl FnOnce(&mut Netlist, &Env) -> X) -> Result<X, Flow> {
        if self.libs.is_empty() {
            return err("No libraries loaded (read_lib / set_app_var target_library) (OPT-001)");
        }
        let mut nl = self.nl.take().ok_or_else(|| Flow::Err("No current design (UID-109)".into()))?;
        let corners: Vec<Corner> = self.corners.iter().map(|c| self.corner_libs(c)).collect();
        let mk = |kind: &str| -> Vec<(&Constraints, &Corner, String)> {
            self.active(kind)
                .into_iter()
                .filter_map(|i| {
                    let s = &self.scens[i];
                    let m = self.modes.iter().find(|m| m.name == s.mode)?;
                    let c = corners.iter().find(|c| c.name == s.corner)?;
                    Some((&m.sdc, c, s.name.clone()))
                })
                .collect()
        };
        let mut aon = self.upf.aon_nets.clone();
        aon.extend(self.app.get("opt.aon_nets").map(|s| split_list(s)).unwrap_or_default());
        let env = Env {
            libs: &self.libs,
            target: self.target_idx(),
            setup: mk("setup"),
            hold: mk("hold"),
            opts: self.sta_opts(),
            dont_use: self.dont_use.clone(),
            vt_order: split_list(self.app.get("opt.vt_order").map(|s| s.as_str()).unwrap_or("HVT SVT LVT")),
            aon_nets: aon,
            focus: self.opt_ctl.as_ref().and_then(|c| c.focus.clone()),
            npaths: self.opt_ctl.as_ref().map(|c| c.npaths()).unwrap_or(40),
        };
        let r = f(&mut nl, &env);
        drop(env);
        self.nl = Some(nl);
        Ok(r)
    }

    // ------------------------------------------------------------ object resolution
    fn ports_matching(&self, pat: &str) -> Vec<String> {
        let Some(nl) = &self.nl else { return vec![] };
        let mut v = vec![];
        for p in nl.port_ids() {
            let n = &nl.ports[p].name;
            let base = n.split('[').next().unwrap_or(n);
            if glob(pat, n) || (glob(pat, base) && n.contains('[')) {
                v.push(n.clone());
            }
        }
        v
    }
    pub(crate) fn objs(&self, s: &str, kind: &str) -> Vec<Obj> {
        let mut out = vec![];
        for it in split_list(s) {
            if let Some(o) = Obj::parse(&it) {
                out.push(o);
                continue;
            }
            match kind {
                "clock" => out.push(Obj::Clock(it)),
                "lib_cell" => out.push(Obj::LibCell(it)),
                _ => {
                    let Some(nl) = &self.nl else {
                        out.push(Obj::Port(it));
                        continue;
                    };
                    let ports = self.ports_matching(&it);
                    if !ports.is_empty() && kind != "cell" && kind != "net" {
                        out.extend(ports.into_iter().map(Obj::Port));
                        continue;
                    }
                    if kind == "clock_or_any" && self.modes[self.cur_mode].sdc.clock(&it).is_some() {
                        out.push(Obj::Clock(it));
                        continue;
                    }
                    if nl.find_pin(&it).is_some() && kind != "cell" && kind != "net" {
                        out.push(Obj::Pin(it));
                    } else if nl.cell_by_name(&it).is_some() && kind != "net" {
                        out.push(Obj::Cell(it));
                    } else if nl.net_by_name(&it).is_some() {
                        out.push(Obj::Net(it));
                    } else if it.contains('/') && kind != "cell" && kind != "net" {
                        out.push(Obj::Pin(it)); // resolved later (role-based)
                    } else if it == nl.name {
                        // design object
                    } else {
                        crate::warn!("SEL-005", "Nothing matched for '{}'", it);
                    }
                }
            }
        }
        out
    }
    fn clocks_of(&self, s: Option<&String>) -> Vec<String> {
        match s {
            None => self.modes[self.cur_mode].sdc.clocks.iter().map(|c| c.name.clone()).collect(),
            Some(s) => split_list(s).into_iter().map(|x| Obj::parse(&x).map(|o| o.name().to_string()).unwrap_or(x)).flat_map(|p| {
                let cl: Vec<String> = self.modes[self.cur_mode].sdc.clocks.iter().filter(|c| glob(&p, &c.name)).map(|c| c.name.clone()).collect();
                cl
            }).collect(),
        }
    }

    // ------------------------------------------------------------ dispatcher
    pub fn cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        if !crate::pintime::read_only(name) {
            self.bump_epoch();
        }
        if !self.in_eco_diff && (crate::tpaths::DIFF_CMDS.contains(&name) || crate::dbaccess::DB_ECO_CMDS.contains(&name)) {
            return self.with_eco_diff(name, a);
        }
        if let Some(r) = self.cmdreg_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.ioovl_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.sitecheck_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.objquery_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.guisch_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.dftadv_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.rowtrack_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.physcells_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.pg_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.db_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.tim_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.model_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.xout_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.gds_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.hflow_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.mim_cmd(name, a) {
            return Some(r);
        }
        // set_voltage: the UPF command takes -object_list (supply nets); without it the value is a
        // corner voltage (set_voltage V [-corners c])
        if crate::upf::UPF_CMDS.contains(&name) && !(name == "set_voltage" && !a.iter().any(|x| x == "-object_list")) {
            return Some(self.upf.cmd(name, a).map_err(e2f));
        }
        if let Some(r) = self.pnr_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.eco_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.query_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.fp_cmd(name, a) {
            return Some(r);
        }
        if let Some(r) = self.part_cmd(name, a) {
            return Some(r);
        }
        Some(match name {
            "set_app_var" | "set_app_options" | "set_app_option" => self.c_set_app(name, a),
            "get_app_var" | "get_app_options" | "get_app_option_value" => {
                let x = args(a, &["-name"]);
                let k = x.get("-name").cloned().or(x.pos.first().cloned()).unwrap_or_default();
                Ok(self.app.get(&k).cloned().unwrap_or_default())
            }
            "report_app_options" | "printvar" => {
                let pat = a.first().cloned().unwrap_or("*".into());
                for (k, v) in &self.app {
                    if glob(&pat, k) {
                        crate::out!("  {:<46} {}", k, v);
                    }
                }
                ok()
            }
            "set_host_options" | "set_units" | "set_wire_load_mode" | "set_operating_conditions" | "set_fix_multiple_port_nets" | "set_message_info_default" | "history" | "set_svf" | "set_cost_priority" | "set_isolate_ports" => {
                if name == "set_operating_conditions" {
                    let x = args(a, &["-corner", "-library", "-max", "-min", "-analysis_type"]);
                    if let Some(t) = x.get("-analysis_type") {
                        let flag = match t.as_str() {
                            "bc_wc" | "min_max" => "-min_max",
                            "on_chip_variation" | "ocv" => "-ocv",
                            _ => "-single_corner",
                        };
                        if let Some(Err(e)) = self.cmd("set_analysis_type", &[flag.to_string()]) {
                            return Some(Err(e));
                        }
                    }
                    let c = x.get("-corner").cloned();
                    let ci = c.and_then(|c| self.corners.iter().position(|x| x.name == c)).unwrap_or(self.cur_corner);
                    self.corners[ci].process_label = x.pos.first().cloned().or(x.get("-max").cloned()).unwrap_or_default();
                }
                ok()
            }
            "create_lib" | "open_lib" | "save_lib" | "save_block" | "close_lib" | "copy_block" | "open_block" => {
                crate::info!("LIB-100", "{}: design library handled in-memory", name);
                ok()
            }
            "read_lib" | "read_liberty" | "read_db" => self.c_read_lib(a),
            "set_lib_corner" => {
                let x = args(a, &["-corner"]);
                let c = x.get("-corner").cloned().unwrap_or_default();
                let ci = self.corner_idx(&c, true);
                for l in &x.pos {
                    for n in split_list(l) {
                        if let Some(i) = self.libs.iter().position(|x| x.name == n || x.file.ends_with(&n)) {
                            if !self.corners[ci].libs.contains(&i) {
                                self.corners[ci].libs.push(i);
                            }
                        }
                    }
                }
                ok()
            }
            "analyze" => self.c_analyze(a),
            "read_verilog" | "read_sverilog" | "read_file" => self.c_read_hdl(name, a),
            "read_vhdl" => self.c_read_hdl(name, a),
            "set_blackbox" | "set_black_box" => {
                for d in a {
                    for n in split_list(d) {
                        self.bb_designs.insert(n);
                    }
                }
                ok()
            }
            "elaborate" => self.c_elaborate(a),
            "set_top_module" | "link_block" | "link" | "current_design" => {
                if name == "current_design" && a.is_empty() {
                    return Some(Ok(self.nl.as_ref().map(|n| n.name.clone()).unwrap_or_default()));
                }
                if let Some(t) = a.iter().find(|x| !x.starts_with('-')) {
                    if self.nl.as_ref().map(|n| &n.name != t).unwrap_or(true) && self.hdl.modules.contains_key(t) {
                        return Some(self.c_elaborate(&[t.clone()]));
                    }
                }
                if self.nl.is_none() {
                    if let Some(t) = self.hdl.tops().first().cloned() {
                        return Some(self.c_elaborate(&[t]));
                    }
                    return Some(err("No design to link (LINK-1)"));
                }
                crate::info!("LINK-100", "Design '{}' linked", self.nl.as_ref().unwrap().name);
                Ok(self.nl.as_ref().unwrap().name.clone())
            }
            "uniquify" => self.c_uniquify(),
            "ungroup" => {
                let x = args(a, &["-start_level", "-prefix"]);
                let pats: Vec<String> = x.pos.iter().flat_map(|p| self.objs(p, "cell")).map(|o| o.name().to_string()).chain(x.pos.iter().flat_map(|p| split_list(p)).filter(|p| Obj::parse(p).is_none())).collect();
                let all = x.has("-all");
                if !all && pats.is_empty() {
                    return Some(err("ungroup: give hierarchical cells or -all".to_string()));
                }
                let t = self.ungroup_targets(&pats, all, x.has("-flatten"), x.num("-start_level").map(|v| v as usize).unwrap_or(1));
                if t.is_empty() {
                    crate::warn!("OPT-792", "ungroup: no hierarchical instance matched");
                }
                let already: HashSet<String> = self.nl.as_ref().map(|n| n.ungrouped.iter().cloned().collect()).unwrap_or_default();
                let fresh: Vec<String> = t.iter().filter(|i| !already.contains(*i)).cloned().collect();
                let n = self.do_ungroup(&t, x.has("-simple_names"));
                crate::info!("OPT-793", "Ungrouped {} hierarch{}{}", n, if n == 1 { "y" } else { "ies" }, if n > 0 { format!(": {}", abbrev_list(&fresh, 6)) } else { String::new() });
                Ok(n.to_string())
            }
            "set_ungroup" => {
                let x = args(a, &[]);
                let val = !x.pos.iter().any(|p| p == "false");
                let pats: Vec<String> = x.pos.iter().filter(|p| *p != "true" && *p != "false").flat_map(|p| {
                    let o = self.objs(p, "cell");
                    if o.is_empty() { split_list(p) } else { o.into_iter().map(|o| o.name().to_string()).collect() }
                }).collect();
                for p in &pats {
                    self.ungroup_marks.push((p.clone(), val));
                }
                crate::info!("OPT-794", "set_ungroup {}: {} pattern(s) (applied by the next compile_fusion from initial_map)", val, pats.len());
                Ok(pats.len().to_string())
            }
            "set_flatten" => {
                let x = args(a, &["-effort", "-design"]);
                let val = !x.pos.iter().any(|p| p == "false");
                self.app.insert("compile.flow.flatten".into(), val.to_string());
                crate::info!("OPT-795", "set_flatten {}: the next compile_fusion ungroups the whole hierarchy", val);
                ok()
            }
            "set_boundary_optimization" => {
                let x = args(a, &[]);
                let val = !x.pos.iter().any(|p| p == "false");
                let objs: Vec<String> = x.pos.iter().filter(|p| *p != "true" && *p != "false" && *p != "auto").flat_map(|p| {
                    let o = self.objs(p, "cell");
                    if o.is_empty() { split_list(p) } else { o.into_iter().map(|o| o.name().to_string()).collect() }
                }).collect();
                let top = self.top.clone().unwrap_or_default();
                if objs.is_empty() || x.has("-all") || objs.iter().any(|o| *o == top) {
                    self.app.insert("compile.flow.boundary_optimization".into(), val.to_string());
                    self.bopt.clear();
                } else {
                    for o in &objs {
                        self.bopt.push((o.clone(), val));
                        if !self.bopt.iter().any(|(p, _)| p == &format!("{}/*", o)) {
                            // children inherit unless set separately
                        }
                    }
                }
                let st = if self.nl.as_ref().map(|n| n.mapped).unwrap_or(false) { " (design already mapped: 'false' only affects new elaborations)" } else { "" };
                crate::info!("OPT-796", "set_boundary_optimization {} on {}{}", val, if objs.is_empty() { "the whole design".to_string() } else { abbrev_list(&objs, 4) }, st);
                if val {
                    if let Err(e) = self.sync_boundaries() {
                        return Some(Err(e));
                    }
                }
                ok()
            }
            "report_boundary_optimization" => self.c_report_hierarchy_ext(),
            "read_def" => self.c_read_def(a),
            "write_def" => {
                // write_def [-floorplan] [-netlist] [-sections {..}] [-exclude {..}] [-scanchain] [-no_routing] [-version 5.7|5.8] file
                let x = args(a, &["-sections", "-section", "-exclude", "-version", "-output"]);
                let (Some(fp), Some(nl)) = (&self.fp, &self.nl) else { return Some(err("write_def needs a design and a floorplan (read_def)")) };
                let f = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or("out.def".into());
                let canon = |w: &str| -> Option<Vec<&'static str>> {
                    Some(match w.to_lowercase().as_str() {
                        "die_area" | "diearea" | "die" => vec!["die_area"],
                        "rows" | "row" => vec!["rows"],
                        "tracks" | "track" => vec!["tracks"],
                        "vias" | "via" => vec!["vias"],
                        "components" | "component" | "placement" | "cells" => vec!["components"],
                        "pins" | "pin" | "ports" | "io" => vec!["pins"],
                        "blockages" | "blockage" => vec!["blockages"],
                        "regions" | "region" | "groups" | "bounds" => vec!["regions"],
                        "nets" | "net" => vec!["nets"],
                        "specialnets" | "special" | "supply" | "pg" => vec!["specialnets"],
                        "scanchains" | "scanchain" | "scan" => vec!["scanchains"],
                        "routing" | "routes" | "wires" | "wiring" => vec!["routing", "vias"],
                        "netlist" => vec!["components", "pins", "nets"],
                        "floorplan" => vec!["die_area", "rows", "tracks", "pins", "blockages", "regions", "components"],
                        "all" => crate::phys::DEF_SECTIONS.to_vec(),
                        _ => return None,
                    })
                };
                let mut o = crate::phys::DefOpts::all();
                o.site = self.site_w();
                o.site_name = self.core_site_name();
                if let Some(v) = x.get("-version") {
                    o.version = v.clone();
                }
                let mut want: Vec<String> = vec![];
                if x.has("-floorplan") {
                    want.extend(canon("floorplan").unwrap().into_iter().map(|s| s.to_string()));
                    o.fixed_components_only = true;
                }
                if x.has("-netlist") {
                    want.extend(canon("netlist").unwrap().into_iter().map(|s| s.to_string()));
                }
                if x.has("-scanchain") || x.has("-scan") {
                    want.push("scanchains".into());
                }
                if let Some(l) = x.get("-sections").or(x.get("-section")) {
                    for w in split_list(l) {
                        let Some(c) = canon(&w) else { return Some(err(format!("write_def: unknown section '{}' (valid: {}, netlist, floorplan, all) (DEF-010)", w, crate::phys::DEF_SECTIONS.join(" ")))) };
                        if c.contains(&"components") && !x.has("-floorplan") {
                            o.fixed_components_only = false;
                        }
                        want.extend(c.into_iter().map(|s| s.to_string()));
                    }
                    if x.has("-floorplan") && split_list(l).iter().any(|w| canon(w).map(|c| c.contains(&"components")).unwrap_or(false)) {
                        o.fixed_components_only = false;
                    }
                }
                if !want.is_empty() {
                    if !want.iter().any(|w| w == "die_area") {
                        want.push("die_area".into());
                    }
                    o.sections = want.into_iter().collect();
                }
                if let Some(l) = x.get("-exclude") {
                    for w in split_list(l) {
                        let Some(c) = canon(&w) else { return Some(err(format!("write_def: unknown section '{}' in -exclude (DEF-010)", w))) };
                        for k in c {
                            o.sections.remove(k);
                        }
                    }
                }
                if x.has("-no_routing") {
                    o.sections.remove("routing");
                    o.sections.remove("vias");
                }
                o.scanchains = self
                    .dft
                    .chains
                    .iter()
                    .enumerate()
                    .map(|(i, (n, _, regs))| {
                        let (si, so) = n.split_once(':').unwrap_or((n, n));
                        let mut e = format!("  - chain{}\n    + START PIN {}\n    + FLOATING", i, si);
                        for r in regs {
                            e.push_str(&format!(" {} ( IN SI ) ( OUT Q )", r));
                        }
                        e.push_str(&format!("\n    + STOP PIN {} ;", so));
                        e
                    })
                    .collect();
                o.supplies = self.upf.supply_nets.keys().map(|n| (n.clone(), !(n.to_uppercase().contains("VSS") || n.to_uppercase().contains("GND")))).collect();
                o.ndr = self.ndr_def();
                o.net_ndr = self.pgx.net_ndr.iter().filter(|(k, _)| k.as_str() != "__clock__").map(|(k, v)| (k.clone(), v.clone())).collect();
                if let (Some(r), Some(db), Some(nl)) = (self.pgx.net_ndr.get("__clock__"), self.routes.as_ref(), self.nl.as_ref()) {
                    for (nid, rn) in &db.nets { if rn.clock { o.net_ndr.entry(nl.net(*nid).name.clone()).or_insert(r.clone()); } }
                }
                crate::phys::write_def_sections(&f, nl, fp, self.routes.as_ref(), &o).map_err(|e| Flow::Err(e.to_string())).map(|w| {
                    crate::info!("DEF-200", "Wrote DEF '{}' (sections: {}{})", f, w.join(" "), if o.fixed_components_only && w.iter().any(|s| s == "components") { "; fixed cells and macros only" } else { "" });
                    f
                })
            }
            "load_upf" | "read_upf" => self.c_load_upf(a),
            "commit_upf" => self.c_commit_upf(),
            "check_mv_design" => {
                let tl = self.target_idx();
                let (Some(nl), Some(lib)) = (&self.nl, self.libs.get(tl)) else { return Some(err("check_mv_design needs a mapped design")) };
                let v = self.upf.check(nl, lib);
                crate::out!("\n**** check_mv_design ****");
                for l in &v {
                    crate::out!("  {}", l);
                }
                let n = v.iter().filter(|x| x.starts_with("MV-")).count();
                crate::out!("  {} multi-voltage violation(s)", n);
                Ok(n.to_string())
            }
            "report_power_domains" | "report_pst" | "report_mv_design" | "report_upf" => {
                for l in self.upf.report() {
                    crate::out!("{}", l);
                }
                ok()
            }
            "save_upf" | "write_upf" => {
                let f = a.iter().find(|x| !x.starts_with('-')).cloned().unwrap_or("out.upf".into());
                let mut s = format!("# UPF written by RSynth\n");
                for l in &self.upf.log {
                    s.push_str(l);
                    s.push('\n');
                }
                std::fs::write(&f, s).map(|_| f).map_err(|e| Flow::Err(e.to_string()))
            }
            // MMMC
            "create_mode" => {
                let m = a.iter().find(|x| !x.starts_with('-')).cloned().unwrap_or_default();
                if self.implicit.0 {
                    self.implicit.0 = false;
                    if self.modes[0].sdc.clocks.is_empty() && self.modes[0].sdc.raw.is_empty() {
                        self.modes.clear();
                    }
                }
                if !self.modes.iter().any(|x| x.name == m) {
                    self.modes.push(Mode { name: m.clone(), sdc: Constraints::default() });
                }
                self.cur_mode = self.modes.iter().position(|x| x.name == m).unwrap();
                Ok(m)
            }
            "create_corner" => {
                let c = a.iter().find(|x| !x.starts_with('-')).cloned().unwrap_or_default();
                let i = self.corner_idx(&c, true);
                self.cur_corner = i;
                Ok(c)
            }
            "create_scenario" => self.c_create_scenario(a),
            "current_mode" => {
                if let Some(m) = a.first() {
                    match self.modes.iter().position(|x| &x.name == m) {
                        Some(i) => self.cur_mode = i,
                        None => return Some(err(format!("Mode '{}' does not exist", m))),
                    }
                }
                Ok(self.modes[self.cur_mode].name.clone())
            }
            "current_corner" => {
                if let Some(c) = a.first() {
                    match self.corners.iter().position(|x| &x.name == c) {
                        Some(i) => self.cur_corner = i,
                        None => return Some(err(format!("Corner '{}' does not exist", c))),
                    }
                }
                Ok(self.corners[self.cur_corner].name.clone())
            }
            "current_scenario" => {
                if let Some(s) = a.first() {
                    let Some(sc) = self.scens.iter().find(|x| &x.name == s).cloned() else { return Some(err(format!("Scenario '{}' does not exist (MV-SCN)", s))) };
                    self.cur_mode = self.modes.iter().position(|m| m.name == sc.mode).unwrap_or(0);
                    self.cur_corner = self.corners.iter().position(|c| c.name == sc.corner).unwrap_or(0);
                    return Some(Ok(sc.name));
                }
                Ok(self.scens.iter().find(|s| s.mode == self.modes[self.cur_mode].name && s.corner == self.corners[self.cur_corner].name).map(|s| s.name.clone()).unwrap_or_default())
            }
            "set_scenario_status" => {
                let x = args(a, &["-active", "-setup", "-hold", "-leakage_power", "-dynamic_power", "-max_transition", "-max_capacitance"]);
                let b = |k: &str, d: bool| x.get(k).map(|v| v == "true" || v == "1").unwrap_or(d);
                let names: Vec<String> = x.pos.iter().flat_map(|p| split_list(p)).collect();
                for s in self.scens.iter_mut().filter(|s| names.iter().any(|n| glob(n, &s.name))) {
                    s.active = b("-active", s.active);
                    s.setup = b("-setup", s.setup);
                    s.hold = b("-hold", s.hold);
                    s.leakage = b("-leakage_power", s.leakage);
                    s.dynamic = b("-dynamic_power", s.dynamic);
                    s.max_tran = b("-max_transition", s.max_tran);
                    s.max_cap = b("-max_capacitance", s.max_cap);
                }
                ok()
            }
            "report_scenarios" | "report_modes" | "report_corners" => {
                crate::out!("\n{:<18} {:<10} {:<10} {:<7} {:<6} {:<5} {:<8} {:<8}", "Scenario", "Mode", "Corner", "Active", "Setup", "Hold", "Leakage", "Dynamic");
                for s in &self.scens {
                    crate::out!("{:<18} {:<10} {:<10} {:<7} {:<6} {:<5} {:<8} {:<8}", s.name, s.mode, s.corner, s.active, s.setup, s.hold, s.leakage, s.dynamic);
                }
                crate::out!("\n{:<10} {:<40} {:<22} {:<14} {}", "Corner", "Libraries", "Derate(late/early)", "RC scale", "PVT (process / V / T)");
                for c in &self.corners {
                    let libs: Vec<String> = if c.libs.is_empty() { vec!["(all)".into()] } else { c.libs.iter().map(|i| self.libs[*i].name.clone()).collect() };
                    let f = |v: Option<f64>, u: &str| v.map(|x| format!("{}{}", x, u)).unwrap_or("-".into());
                    crate::out!("{:<10} {:<40} {:<22} {:<14} {} / {} / {}", c.name, libs.join(","), format!("{:.3}/{:.3}", c.late_cell, c.early_cell), format!("R{} C{}", c.r_scale, c.c_scale), if c.process_label.is_empty() { "-" } else { &c.process_label }, f(c.voltage, "V"), f(c.temperature, "C"));
                }
                ok()
            }
            "remove_scenarios" => {
                let names: Vec<String> = a.iter().flat_map(|p| split_list(p)).collect();
                self.scens.retain(|s| !names.iter().any(|n| glob(n, &s.name)));
                ok()
            }
            "set_timing_derate" | "c_derate_internal" => self.c_derate(a),
            "read_aocvm" | "read_ocvm" => self.c_read_ocvm(a),
            "report_ocvm" | "report_aocvm" => self.c_report_ocvm(a),
            "remove_ocvm" | "remove_aocvm" => {
                self.ocv = crate::sta::Ocv::default();
                self.app.insert("time.aocvm_enable_analysis".into(), "false".into());
                self.app.insert("time.pocvm_enable_analysis".into(), "false".into());
                ok()
            }
            "set_parasitic_parameters" | "set_corner_rc_scale" => {
                let x = args(a, &["-corner", "-corners", "-r_scale", "-c_scale", "-late_spec", "-early_spec"]);
                let cs = x.get("-corner").or(x.get("-corners")).map(|s| split_list(s)).unwrap_or(vec![self.corners[self.cur_corner].name.clone()]);
                for c in cs {
                    let i = self.corner_idx(&c, true);
                    if let Some(r) = x.num("-r_scale") {
                        self.corners[i].r_scale = r;
                    }
                    if let Some(v) = x.num("-c_scale") {
                        self.corners[i].c_scale = v;
                    }
                }
                ok()
            }
            "set_temperature" | "set_voltage" | "set_process_number" | "set_process_label" => {
                let x = args(a, &["-corners", "-corner", "-object_list"]);
                let cs = x.get("-corners").or(x.get("-corner")).map(|s| split_list(s)).unwrap_or(vec![self.corners[self.cur_corner].name.clone()]);
                let v = x.pos.first().and_then(|s| s.parse::<f64>().ok());
                for c in cs {
                    let i = self.corner_idx(&c, true);
                    match name {
                        "set_temperature" => self.corners[i].temperature = v,
                        "set_voltage" => {
                            if x.get("-object_list").is_none() {
                                self.corners[i].voltage = v
                            }
                        }
                        _ => self.corners[i].process_label = x.pos.first().cloned().unwrap_or_default(),
                    }
                }
                ok()
            }
            "read_sdc" => {
                let x = args(a, &["-mode", "-scenario"]);
                if let Some(m) = x.get("-mode") {
                    if let Some(i) = self.modes.iter().position(|q| &q.name == m) {
                        self.cur_mode = i;
                    }
                }
                let f = x.pos.first().cloned().unwrap_or_default();
                let s = match std::fs::read_to_string(&f) {
                    Ok(s) => s,
                    Err(e) => return Some(err(format!("cannot read SDC '{}': {}", f, e))),
                };
                crate::info!("SDC-001", "Reading SDC '{}' into mode '{}'", f, self.modes[self.cur_mode].name);
                let n0 = crate::log::count(crate::log::Sev::Error);
                let r = self.eval(&s);
                let ne = crate::log::count(crate::log::Sev::Error) - n0;
                r.map(|_| format!("{} error(s)", ne))
            }
            // SDC
            "create_clock" => self.c_create_clock(a),
            "create_generated_clock" => self.c_gen_clock(a),
            "set_clock_uncertainty" | "set_clock_latency" | "set_clock_transition" | "set_propagated_clock" => self.c_clock_attr(name, a),
            "set_input_delay" | "set_output_delay" => self.c_io_delay(name == "set_input_delay", a),
            "set_false_path" | "set_multicycle_path" | "set_max_delay" | "set_min_delay" => self.c_exception(name, a),
            "set_disable_timing" => {
                let x = args(a, &["-from", "-to"]);
                let objs: Vec<Obj> = x.pos.iter().flat_map(|p| {
                    let v = self.objs(p, "any");
                    if v.is_empty() { vec![Obj::LibCell(p.clone())] } else { v }
                }).collect();
                for o in objs {
                    self.cons().disabled.push((o, x.get("-from").cloned(), x.get("-to").cloned()));
                }
                self.rawsdc(name, a);
                ok()
            }
            "set_case_analysis" => {
                let v = a.first().map(|s| s == "1" || s == "one" || s == "rising").unwrap_or(false);
                let objs: Vec<Obj> = a[1..].iter().flat_map(|p| self.objs(p, "any")).collect();
                for o in objs {
                    self.cons().case.push((o, v));
                }
                self.rawsdc(name, a);
                ok()
            }
            "set_clock_groups" => {
                let kind = if a.iter().any(|x| x == "-asynchronous") { "asynchronous" } else if a.iter().any(|x| x.contains("exclusive")) { "exclusive" } else { "asynchronous" };
                let mut groups = vec![];
                let mut i = 0;
                while i < a.len() {
                    if a[i] == "-group" && i + 1 < a.len() {
                        groups.push(self.clocks_of(Some(&a[i + 1])));
                        i += 2;
                        continue;
                    }
                    i += 1;
                }
                self.cons().clock_groups.push((kind.into(), groups));
                self.rawsdc(name, a);
                ok()
            }
            "set_max_transition" | "set_max_fanout" | "set_max_capacitance" => self.c_drv_limit(name, a),
            "set_input_transition" => {
                let x = args(a, &[]);
                let v = fnum(x.pos.first().map(|s| s.as_str()).unwrap_or("0")).unwrap_or(0.0);
                let objs: Vec<Obj> = x.pos[1..].iter().flat_map(|p| self.objs(p, "port")).collect();
                for o in objs {
                    self.cons().input_tran.push((o, v));
                }
                self.rawsdc(name, a);
                ok()
            }
            "set_driving_cell" => {
                let x = args(a, &["-lib_cell", "-pin", "-library", "-from_pin"]);
                let cell = x.get("-lib_cell").cloned().unwrap_or_default();
                let tran = self.libs.iter().find_map(|l| l.cells.get(&cell)).and_then(|c| c.outputs().first().and_then(|o| o.arcs.first().and_then(|a| a.rise_tran.as_ref().map(|t| t.delay(0.05, 0.005))))).unwrap_or(0.05);
                let objs: Vec<Obj> = x.pos.iter().flat_map(|p| self.objs(p, "port")).collect();
                for o in objs {
                    self.cons().driving_cell.push((o.clone(), cell.clone()));
                    self.cons().input_tran.push((o, tran));
                }
                self.rawsdc(name, a);
                ok()
            }
            "set_load" => {
                let x = args(a, &[]);
                let v = fnum(x.pos.first().map(|s| s.as_str()).unwrap_or("0")).unwrap_or(0.0);
                let objs: Vec<Obj> = x.pos[1..].iter().flat_map(|p| self.objs(p, "port")).collect();
                for o in objs {
                    self.cons().loads.push((o, v));
                }
                self.rawsdc(name, a);
                ok()
            }
            "set_wire_load_model" => {
                let x = args(a, &["-name", "-library"]);
                self.cons().wire_load_model = x.get("-name").cloned().or(x.pos.first().cloned());
                self.rawsdc(name, a);
                ok()
            }
            "set_max_area" => {
                self.cons().max_area = a.first().and_then(|s| s.parse().ok());
                self.rawsdc(name, a);
                ok()
            }
            "set_clock_gating_check" => {
                let x = args(a, &["-setup", "-hold"]);
                if let Some(v) = x.num("-setup") {
                    self.cons().cg_setup = v;
                }
                if let Some(v) = x.num("-hold") {
                    self.cons().cg_hold = v;
                }
                self.rawsdc(name, a);
                ok()
            }
            "set_data_check" => {
                let x = args(a, &["-from", "-to", "-setup", "-hold", "-rise_from", "-fall_from", "-rise_to", "-fall_to"]);
                let f = x.get("-from").or(x.get("-rise_from")).or(x.get("-fall_from")).map(|s| self.objs(s, "pin")).unwrap_or_default();
                let t = x.get("-to").or(x.get("-rise_to")).or(x.get("-fall_to")).map(|s| self.objs(s, "pin")).unwrap_or_default();
                let v = x.num("-setup").or(x.pos.first().and_then(|s| s.parse().ok())).unwrap_or(0.0);
                if let (Some(f), Some(t)) = (f.first(), t.first()) {
                    self.cons().data_checks.push((f.clone(), t.clone(), v));
                }
                self.rawsdc(name, a);
                ok()
            }
            "set_ideal_network" | "set_ideal_net" => {
                let objs: Vec<Obj> = a.iter().filter(|x| !x.starts_with('-')).flat_map(|p| self.objs(p, "any")).collect();
                self.cons().ideal_nets.extend(objs);
                self.rawsdc(name, a);
                ok()
            }
            // SDC 2.1 commands accepted for compatibility but not acted on: never abort read_sdc,
            // warn once per command name, and keep the text so write_sdc reproduces it.
            "set_max_time_borrow" | "set_min_capacitance" | "set_drive" | "set_resistance" | "set_fanout_load" | "set_port_fanout_number"
            | "set_ideal_latency" | "set_ideal_transition" | "set_annotated_delay" | "set_clock_exclusivity" | "set_disable_clock_gating_check"
            | "set_max_skew" | "set_min_porosity" | "set_wire_load_min_block_size" | "set_wire_load_selection_group"
            | "set_logic_dc" | "set_logic_one" | "set_logic_zero" | "set_level_shifter_strategy" | "set_level_shifter_threshold"
            | "set_hierarchy_separator" | "remove_clock" | "remove_clock_groups" | "remove_input_delay"
            | "remove_output_delay" | "reset_path" => {
                if self.sdc_unsupported.insert(name.to_string()) {
                    crate::warn!("SDC-900", "{} is recognized but not supported by RSynth; constraint ignored (kept for write_sdc). Further occurrences are counted in report_constraints", name);
                }
                *self.sdc_unsupported_count.entry(name.to_string()).or_insert(0) += 1;
                if !name.starts_with("remove_") && name != "reset_path" {
                    self.rawsdc(name, a);
                }
                ok()
            }
            // ---------------------------------------------------------- path groups / margins
            "group_path" | "create_path_groups" | "create_path_group" => {
                let x = args(a, &["-name", "-from", "-to", "-through", "-weight", "-critical_range", "-priority"]);
                if x.has("-auto") {
                    // standard IO path groups: in2reg, reg2out, in2out (reg2reg stays in the clock groups)
                    let ins: Vec<Obj> = self.nl().map(|nl| nl.port_ids().into_iter().filter(|p| nl.ports[*p].dir == Dir::In).map(|p| Obj::Port(nl.ports[p].name.clone())).collect()).unwrap_or_default();
                    let clkports: HashSet<String> = self.cons().clocks.iter().flat_map(|c| c.sources.iter().map(|o| o.name().to_string())).collect();
                    let ins: Vec<Obj> = ins.into_iter().filter(|o| !clkports.contains(o.name())).collect();
                    let outs: Vec<Obj> = self.nl().map(|nl| nl.port_ids().into_iter().filter(|p| nl.ports[*p].dir != Dir::In).map(|p| Obj::Port(nl.ports[p].name.clone())).collect()).unwrap_or_default();
                    let regs: Vec<Obj> = self.nl().map(|nl| nl.cell_ids().into_iter().filter(|c| {
                        let cell = nl.cell(*c);
                        matches!(cell.kind, Kind::Gen(GOp::Dff) | Kind::Gen(GOp::Latch)) || cell.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|x| x.seq.is_some()).unwrap_or(false)
                    }).map(|c| Obj::Cell(nl.cell(c).name.clone())).collect()).unwrap_or_default();
                    let w = x.num("-weight").unwrap_or(1.0);
                    let cr = x.num("-critical_range");
                    let cons = self.cons();
                    for (nm, f, t) in [("in2reg", ins.clone(), regs.clone()), ("reg2out", regs.clone(), outs.clone()), ("in2out", ins, outs)] {
                        cons.path_groups.retain(|g| g.name != nm);
                        cons.path_groups.push(crate::cons::PathGroup { name: nm.into(), from: f, to: t, weight: w, critical_range: cr });
                    }
                    crate::info!("TIM-300", "Created path groups in2reg, reg2out, in2out (reg2reg paths stay in their clock groups)");
                    return Some(Ok("in2reg reg2out in2out".into()));
                }
                if x.has("-default") {
                    let w = x.num("-weight");
                    let cr = x.num("-critical_range");
                    let e = self.cons().group_opts.entry("**default**".into()).or_insert((None, None));
                    if w.is_some() { e.0 = w; }
                    if cr.is_some() { e.1 = cr; }
                    return Some(ok());
                }
                let Some(nm) = x.get("-name").cloned() else { return Some(err(format!("{}: -name is required (or -auto / -default)", name))) };
                if x.get("-through").is_some() {
                    crate::warn!("TIM-301", "{} -name {}: -through is not supported for path groups; grouping uses -from/-to only", name, nm);
                }
                let from: Vec<Obj> = x.get("-from").map(|f| self.objs(f, "clock_or_any")).unwrap_or_default();
                let to: Vec<Obj> = x.get("-to").map(|f| self.objs(f, "clock_or_any")).unwrap_or_default();
                if x.get("-from").is_some() && from.is_empty() || x.get("-to").is_some() && to.is_empty() {
                    crate::warn!("TIM-302", "{} -name {}: -from/-to matched no objects", name, nm);
                }
                let w = x.num("-weight").unwrap_or(1.0);
                let cr = x.num("-critical_range");
                let cons = self.cons();
                if let Some(g) = cons.path_groups.iter_mut().find(|g| g.name == nm) {
                    // adding to an existing group: extend its definition (group_path semantics)
                    g.from.extend(from);
                    g.to.extend(to);
                    if x.get("-weight").is_some() { g.weight = w; }
                    if cr.is_some() { g.critical_range = cr; }
                } else {
                    cons.path_groups.push(crate::cons::PathGroup { name: nm.clone(), from, to, weight: w, critical_range: cr });
                }
                self.rawsdc("group_path", a);
                Ok(nm)
            }
            "delete_path_groups" | "remove_path_groups" | "remove_path_group" => {
                let x = args(a, &[]);
                let cons = self.cons();
                let before = cons.path_groups.len();
                if x.has("-all") {
                    cons.path_groups.clear();
                    cons.group_opts.retain(|k, _| k == "**default**");
                } else {
                    let names: Vec<String> = x.pos.iter().flat_map(|p| split_list(p)).collect();
                    for n in &names {
                        if !cons.path_groups.iter().any(|g| crate::netlist::glob(n, &g.name)) {
                            crate::warn!("TIM-303", "{}: no path group '{}'", name, n);
                        }
                    }
                    cons.path_groups.retain(|g| !names.iter().any(|n| crate::netlist::glob(n, &g.name)));
                    cons.group_opts.retain(|k, _| !names.iter().any(|n| crate::netlist::glob(n, k)));
                }
                let n = before - self.cons().path_groups.len();
                crate::info!("TIM-304", "Removed {} path group(s); their paths return to the clock groups", n);
                Ok(n.to_string())
            }
            "set_path_group_options" => {
                let x = args(a, &["-weight", "-weights", "-critical_range", "-group", "-groups", "-scenarios"]);
                let w = x.num("-weight").or(x.num("-weights"));
                let cr = x.num("-critical_range");
                if w.is_none() && cr.is_none() {
                    return Some(err("set_path_group_options: give -weight and/or -critical_range".to_string()));
                }
                let mut names: Vec<String> = x.pos.iter().chain(x.get("-group")).chain(x.get("-groups")).flat_map(|p| split_list(p)).collect();
                let cons = self.cons();
                let known: Vec<String> = cons.path_groups.iter().map(|g| g.name.clone()).chain(cons.clocks.iter().map(|c| c.name.clone())).chain(std::iter::once("**default**".to_string())).collect();
                if x.has("-all") || names.is_empty() {
                    names = known.clone();
                }
                let mut n = 0;
                for pat in names {
                    let hits: Vec<String> = known.iter().filter(|k| crate::netlist::glob(&pat, k)).cloned().collect();
                    if hits.is_empty() {
                        crate::warn!("TIM-305", "set_path_group_options: no path group '{}' (user groups or clock names)", pat);
                    }
                    for h in hits {
                        let e = cons.group_opts.entry(h).or_insert((None, None));
                        if w.is_some() { e.0 = w; }
                        if cr.is_some() { e.1 = cr; }
                        n += 1;
                    }
                }
                Ok(n.to_string())
            }
            "report_path_groups" | "report_path_group" => self.c_report_path_groups(a),
            "set_critical_range" => {
                // set_critical_range <value> [design] : critical range for all path groups of the current mode
                let x = args(a, &[]);
                let Some(v) = x.pos.iter().find_map(|p| p.parse::<f64>().ok()) else { return Some(err("set_critical_range: value required".to_string())) };
                if v < 0.0 {
                    return Some(err("set_critical_range: value must be >= 0".to_string()));
                }
                self.cons().critical_range_all = Some(v);
                crate::info!("TIM-306", "Critical range {} for all path groups of mode '{}' (group_path / set_path_group_options values take precedence)", v, self.modes[self.cur_mode].name);
                self.rawsdc(name, a);
                ok()
            }
            "remove_critical_range" | "reset_critical_range" => {
                self.cons().critical_range_all = None;
                ok()
            }
            "set_path_margin" => {
                let x = args(a, &["-from", "-to", "-through", "-rise_from", "-fall_from", "-rise_to", "-fall_to"]);
                let Some(v) = x.pos.iter().find_map(|p| p.parse::<f64>().ok()) else { return Some(err("set_path_margin: margin value required".to_string())) };
                if x.get("-through").is_some() {
                    crate::warn!("TIM-310", "set_path_margin: -through is not supported; margin applied by -from/-to only");
                }
                let (mut su, mut ho) = (x.has("-setup"), x.has("-hold"));
                if !su && !ho {
                    su = true;
                    ho = true;
                }
                let from: Vec<Obj> = x.get("-from").or(x.get("-rise_from")).or(x.get("-fall_from")).map(|f| self.objs(f, "clock_or_any")).unwrap_or_default();
                let to: Vec<Obj> = x.get("-to").or(x.get("-rise_to")).or(x.get("-fall_to")).map(|f| self.objs(f, "clock_or_any")).unwrap_or_default();
                self.cons().path_margins.push(crate::cons::PathMargin { from, to, setup: su, hold: ho, value: v });
                self.rawsdc(name, a);
                ok()
            }
            "remove_path_margin" | "reset_path_margin" => {
                let n = self.cons().path_margins.len();
                self.cons().path_margins.clear();
                Ok(n.to_string())
            }
            "set_clock_sense" | "set_sense" => {
                let x = args(a, &["-clocks", "-clock", "-type", "-pulse"]);
                let ty = x.get("-type").map(|s| s.as_str()).unwrap_or("clock");
                if name == "set_sense" && ty != "clock" {
                    crate::warn!("SDC-210", "set_sense -type {}: data sense is not supported; command ignored", ty);
                    return Some(ok());
                }
                if x.get("-pulse").is_some() {
                    crate::warn!("SDC-211", "{} -pulse (pulse clocks) is not supported; command ignored", name);
                    return Some(ok());
                }
                let kind = if x.has("-stop_propagation") {
                    0u8
                } else if x.has("-positive") {
                    1
                } else if x.has("-negative") {
                    2
                } else {
                    return Some(err(format!("{}: one of -stop_propagation, -positive, -negative is required", name)));
                };
                let clocks: Vec<String> = x.get("-clocks").or(x.get("-clock")).map(|c| split_list(c).iter().map(|s| Obj::parse(s).map(|o| o.name().to_string()).unwrap_or(s.clone())).collect()).unwrap_or_default();
                let objs: Vec<Obj> = x.pos.iter().flat_map(|p| self.objs(p, "pin")).collect();
                if objs.is_empty() {
                    crate::warn!("SDC-212", "{}: no pins matched; command ignored", name);
                }
                let n = objs.len();
                self.cons().clock_sense.extend(objs.into_iter().map(|o| (o, kind, clocks.clone())));
                self.rawsdc(name, a);
                Ok(n.to_string())
            }
            "set_min_pulse_width" => {
                let x = args(a, &[]);
                let v = x.pos.first().and_then(|s| s.parse().ok()).unwrap_or(0.0);
                let o = x.pos.get(1).and_then(|p| self.objs(p, "clock_or_any").into_iter().next());
                self.cons().min_pulse_width.push((o, v));
                self.rawsdc(name, a);
                ok()
            }
            "set_max_dynamic_power" | "set_max_leakage_power" => {
                let v = a.first().and_then(|s| s.parse().ok());
                if name.contains("dynamic") {
                    self.cons().max_dynamic_power = v
                } else {
                    self.cons().max_leakage_power = v
                }
                ok()
            }
            "set_switching_activity" => {
                let x = args(a, &["-toggle_rate", "-static_probability", "-clock", "-type"]);
                let tr = x.num("-toggle_rate").unwrap_or(0.1);
                for p in &x.pos {
                    for o in self.objs(p, "any") {
                        let n = match &o {
                            Obj::Port(p) => self.nl.as_ref().and_then(|nl| nl.port_by_name(p).and_then(|q| nl.ports[q].net)).map(|n| self.nl.as_ref().unwrap().net(n).name.clone()),
                            Obj::Net(n) => Some(n.clone()),
                            Obj::Pin(p) => self.nl.as_ref().and_then(|nl| nl.find_pin(p).and_then(|pr| nl.pin_net(pr))).map(|n| self.nl.as_ref().unwrap().net(n).name.clone()),
                            _ => None,
                        };
                        if let Some(n) = n {
                            self.activity.push((n, tr));
                        }
                    }
                }
                ok()
            }
            "set_dont_touch" | "set_dont_touch_network" | "set_size_only" => {
                let x = args(a, &[]);
                let val = !x.pos.iter().any(|p| p == "false");
                let objs: Vec<Obj> = x.pos.iter().filter(|p| *p != "true" && *p != "false").flat_map(|p| self.objs(p, "any")).collect();
                let size_only = name == "set_size_only";
                let mut deferred = vec![];
                let Ok(nl) = self.nlm() else { return Some(err(format!("{}: no design", name))) };
                let mut n = 0;
                let mark = |nl: &mut Netlist, c: CellId| {
                    if size_only {
                        nl.cell_mut(c).attrs.retain(|a| a != "size_only");
                        if val {
                            nl.cell_mut(c).attrs.push("size_only".into());
                        }
                    } else {
                        nl.cell_mut(c).dont_touch = val;
                    }
                };
                for o in objs {
                    match &o {
                        Obj::Cell(cn) => {
                            if let Some(c) = nl.cell_by_name(cn) {
                                mark(nl, c);
                                n += 1;
                            } else {
                                // hierarchical instance: everything below it
                                let pre = format!("{}/", cn);
                                let inside: Vec<CellId> = nl.cell_ids().into_iter().filter(|&c| nl.cell(c).name.starts_with(&pre)).collect();
                                if inside.is_empty() {
                                    crate::warn!("SDC-230", "{}: '{}' matches no cell", name, cn);
                                    continue;
                                }
                                if !size_only && inside.iter().any(|&c| nl.cell(c).gop().is_some()) {
                                    // unmapped hierarchy: freeze after technology mapping
                                    deferred.push((pre.clone(), val));
                                    crate::info!("SDC-231", "{} on unmapped hierarchy '{}' ({} cells): it will be mapped, then preserved from initial_map on (Fusion Compiler would leave it unmapped)", name, cn, inside.len());
                                    n += inside.len();
                                    continue;
                                }
                                for c in &inside {
                                    mark(nl, *c);
                                }
                                if !size_only {
                                    nl.frozen_hier.retain(|f| f != cn);
                                    if val {
                                        nl.frozen_hier.push(cn.clone());
                                    }
                                    for ni in nl.net_ids() {
                                        if nl.net(ni).name.starts_with(&pre) {
                                            nl.net_mut(ni).dont_touch = val;
                                        }
                                    }
                                }
                                n += inside.len();
                            }
                        }
                        Obj::Net(x) if !size_only => {
                            if let Some(i) = nl.net_by_name(x) {
                                nl.net_mut(i).dont_touch = val;
                                n += 1;
                            }
                        }
                        Obj::Port(p) if !size_only => {
                            if let Some(net) = nl.port_by_name(p).and_then(|q| nl.ports[q].net) {
                                nl.net_mut(net).dont_touch = val;
                                n += 1;
                            }
                        }
                        _ => {}
                    }
                }
                if name == "set_dont_touch_network" {
                    crate::info!("SDC-232", "set_dont_touch_network: the named nets are preserved; propagation through buffers/combinational logic is not performed");
                }
                self.dont_touch_hier.extend(deferred);
                Ok(n.to_string())
            }
            "set_dont_use" => {
                let x = args(a, &[]);
                let val = !x.pos.iter().any(|p| p == "false");
                let mut total = 0;
                for p in x.pos.iter().filter(|p| *p != "true" && *p != "false") {
                    for it in split_list(p) {
                        let full = Obj::parse(&it).map(|o| o.name().to_string()).unwrap_or(it);
                        // "lib/cell" -> restrict to that library; bare "cell" -> all libraries
                        let (libpat, n) = match full.rsplit_once('/') {
                            Some((l, c)) => (Some(l.to_string()), c.to_string()),
                            None => (None, full.clone()),
                        };
                        if val {
                            if !self.dont_use.contains(&n) {
                                self.dont_use.push(n.clone());
                            }
                        } else {
                            self.dont_use.retain(|d| d != &n);
                        }
                        self.dont_use_cmds.push((n.clone(), val));
                        let mut hit = 0;
                        for lib in self.libs.iter_mut() {
                            if libpat.as_deref().map(|l| crate::netlist::glob(l, &lib.name)).unwrap_or(true) {
                                hit += Self::mark_dont_use(lib, &n, val);
                            }
                        }
                        if hit == 0 && !self.libs.is_empty() {
                            crate::warn!("SDC-220", "set_dont_use: '{}' matches no library cell", full);
                        }
                        total += hit;
                    }
                }
                Ok(total.to_string())
            }
            // collections
            "get_ports" | "get_pins" | "get_cells" | "get_nets" | "get_clocks" | "get_lib_cells" | "get_designs" | "get_libs" | "get_lib_pins" => self.c_get(name, a),
            "all_inputs" | "all_outputs" => {
                let x = args(a, &[]);
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                let clockports: HashSet<String> = if x.has("-no_clocks") { self.modes[self.cur_mode].sdc.clocks.iter().flat_map(|c| c.sources.iter().map(|o| o.name().to_string())).collect() } else { HashSet::new() };
                let v: Vec<String> = nl.port_ids().into_iter().filter(|p| (nl.ports[*p].dir == Dir::In) == (name == "all_inputs") && !clockports.contains(&nl.ports[*p].name)).map(|p| Obj::Port(nl.ports[p].name.clone()).handle()).collect();
                Ok(to_list(&v))
            }
            "all_clocks" => Ok(to_list(&self.modes[self.cur_mode].sdc.clocks.iter().map(|c| Obj::Clock(c.name.clone()).handle()).collect::<Vec<_>>())),
            "all_registers" => self.c_all_registers(a),
            "all_fanout" | "all_fanin" => self.c_fan(name, a),
            "sizeof_collection" => Ok(split_list(a.first().map(|s| s.as_str()).unwrap_or("")).len().to_string()),
            "get_object_name" => Ok(to_list(&split_list(a.first().map(|s| s.as_str()).unwrap_or("")).iter().map(|x| if x.starts_with("timing_") { self.attr(x, "full_name").unwrap_or(x.clone()) } else { Obj::parse(x).map(|o| o.name().to_string()).unwrap_or(x.clone()) }).collect::<Vec<_>>())),
            "add_to_collection" | "append_to_collection" => {
                if name == "append_to_collection" {
                    let v = self.interp.get(&a[0]).unwrap_or_default();
                    let r = format!("{} {}", v, a.get(1).cloned().unwrap_or_default()).trim().to_string();
                    self.interp.set(&a[0], &r);
                    return Some(Ok(r));
                }
                let mut v = split_list(a.first().map(|s| s.as_str()).unwrap_or(""));
                for x in split_list(a.get(1).map(|s| s.as_str()).unwrap_or("")) {
                    if !v.contains(&x) {
                        v.push(x)
                    }
                }
                Ok(to_list(&v))
            }
            "remove_from_collection" => {
                let r = split_list(a.get(1).map(|s| s.as_str()).unwrap_or(""));
                Ok(to_list(&split_list(a.first().map(|s| s.as_str()).unwrap_or("")).into_iter().filter(|x| !r.contains(x)).collect::<Vec<_>>()))
            }
            "index_collection" => {
                let v = split_list(a.first().map(|s| s.as_str()).unwrap_or(""));
                let i: usize = a.get(1).and_then(|s| s.parse().ok()).unwrap_or(0);
                Ok(v.get(i).cloned().unwrap_or_default())
            }
            "filter_collection" => Ok(self.filter(&split_list(a.first().map(|s| s.as_str()).unwrap_or("")), a.get(1).map(|s| s.as_str()).unwrap_or(""))),
            "foreach_in_collection" => {
                if a.len() < 3 {
                    return Some(err("foreach_in_collection var collection body"));
                }
                let items = split_list(&a[1]);
                for it in items {
                    self.interp.set(&a[0], &it);
                    match self.eval(&a[2]) {
                        Err(Flow::Break) => break,
                        Err(Flow::Continue) => {}
                        Err(e) => return Some(Err(e)),
                        Ok(_) => {}
                    }
                }
                ok()
            }
            "get_attribute" | "get_attr" => self.c_get_attr(a),
            // compile
            "compile_fusion" | "compile" | "compile_ultra" => self.c_compile(name, a),
            "insert_clock_gating" | "set_clock_gating_options" | "set_clock_gate_style" => {
                let x = args(a, &["-minimum_bitwidth", "-max_fanout", "-exclude"]);
                self.app.insert("compile.clockgate.enable".into(), "true".into());
                if let Some(v) = x.get("-minimum_bitwidth") {
                    self.app.insert("compile.clockgate.min_bitwidth".into(), v.clone());
                }
                if let Some(v) = x.get("-max_fanout") {
                    self.app.insert("compile.clockgate.max_fanout".into(), v.clone());
                }
                if let Some(v) = x.get("-exclude") {
                    self.cg_exclude.extend(split_list(v).into_iter().map(|s| Obj::parse(&s).map(|o| o.name().to_string()).unwrap_or(s)));
                }
                if name == "insert_clock_gating" && self.nl.as_ref().map(|n| !n.mapped).unwrap_or(false) {
                    let lib = self.target_idx();
                    let mb = self.appu("compile.clockgate.min_bitwidth");
                    let mf = self.appu("compile.clockgate.max_fanout");
                    let ex = self.cg_exclude.clone();
                    let n = crate::genopt::insert_clock_gating(self.nl.as_mut().unwrap(), &self.libs[lib], mb, mf, &ex);
                    return Some(Ok(n.to_string()));
                }
                ok()
            }
            "optimize_registers" | "set_optimize_registers" | "pipeline_design" => {
                if name == "set_optimize_registers" {
                    let on = !a.iter().any(|x| x == "false");
                    self.app.insert("compile.retiming.enable".into(), on.to_string());
                    return Some(ok());
                }
                let x = args(a, &["-max_moves", "-stages"]);
                let k = x.num("-max_moves").unwrap_or(16.0) as usize;
                self.with_env(|nl, env| crate::opt::retime(nl, env, k)).map(|n| {
                    crate::info!("OPT-1901", "optimize_registers: {} retiming move(s)", n);
                    n.to_string()
                })
            }
            "remove_buffer_trees" | "remove_buffers" => {
                if name == "remove_buffers" && !a.is_empty() {
                    let names: Vec<String> = a.iter().flat_map(|p| split_list(p)).map(|s| Obj::parse(&s).map(|o| o.name().to_string()).unwrap_or(s)).collect();
                    return Some(self.with_env(|nl, env| {
                        let mut n = 0;
                        for c in names {
                            if let Some(ci) = nl.cell_by_name(&c) {
                                if let Some(lc) = nl.cell(ci).lib().and_then(|l| env.lc(l)) {
                                    if lc.is_buf {
                                        let ai = nl.cell(ci).pin_net(&lc.inputs()[0].name);
                                        let yo = nl.cell(ci).pin_net(&lc.outputs()[0].name);
                                        if let (Some(ai), Some(yo)) = (ai, yo) {
                                            nl.remove_cell(ci);
                                            crate::genopt::merge_named(nl, ai, yo);
                                            n += 1;
                                        }
                                    }
                                }
                            }
                        }
                        n.to_string()
                    }));
                }
                self.with_env(|nl, env| crate::opt::remove_buffer_trees(nl, env).to_string())
            }
            "insert_buffer_tree" | "create_buffer_tree" | "split_fanout" => {
                let x = args(a, &["-net", "-nets", "-max_fanout", "-lib_cell"]);
                let nets: Vec<String> = x.get("-net").or(x.get("-nets")).map(|s| split_list(s)).unwrap_or(x.pos.clone()).into_iter().map(|s| Obj::parse(&s).map(|o| o.name().to_string()).unwrap_or(s)).collect();
                let mf = x.num("-max_fanout").unwrap_or(16.0) as usize;
                let aon = x.has("-always_on");
                self.with_env(|nl, env| {
                    let mut t = 0;
                    for n in nets {
                        let id = nl.net_by_name(&n).or_else(|| nl.port_by_name(&n).and_then(|p| nl.ports[p].net));
                        if let Some(id) = id {
                            let k = crate::opt::buffer_net(nl, env, id, mf, None, aon || env.aon_nets.contains(&n), "GBUF_");
                            crate::info!("OPT-1710", "Buffer tree for global net '{}': {} buffer(s), max fanout {}", n, k, mf);
                            t += k;
                        } else {
                            crate::warn!("SEL-005", "Net '{}' not found", n);
                        }
                    }
                    t.to_string()
                })
            }
            // ECO
            "size_cell" | "swap_cell" | "change_link" => {
                if a.len() < 2 {
                    return Some(err("size_cell <cells> <lib_cell>"));
                }
                let lc = Obj::parse(&a[a.len() - 1]).map(|o| o.name().to_string()).unwrap_or(a[a.len() - 1].clone());
                let lc = lc.rsplit('/').next().unwrap_or(&lc).to_string();
                let cells: Vec<String> = split_list(&a[a.len() - 2]).into_iter().map(|s| Obj::parse(&s).map(|o| o.name().to_string()).unwrap_or(s)).collect();
                let exists = self.libs.iter().any(|l| l.cells.contains_key(&lc));
                if !exists {
                    return Some(err(format!("Library cell '{}' not found (ECO-002)", lc)));
                }
                let target = self.libs.iter().find_map(|l| l.cells.get(&lc)).unwrap().clone();
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let mut n = 0;
                for c in cells {
                    match nl.cell_by_name(&c) {
                        Some(ci) => {
                            let ok_pins = nl.cell(ci).pins.iter().all(|p| p.net.is_none() || target.pin(&p.name).is_some());
                            if !ok_pins {
                                crate::error!("ECO-003", "Cannot size '{}' to '{}': pin mismatch", c, lc);
                                continue;
                            }
                            crate::opt::swap_cell(nl, ci, &lc);
                            crate::info!("ECO-100", "ECO: {} -> {}", c, lc);
                            n += 1;
                        }
                        None => crate::warn!("SEL-005", "Cell '{}' not found", c),
                    }
                }
                Ok(n.to_string())
            }
            "insert_buffer" | "add_buffer_on_route" => {
                let x = args(a, &["-lib_cell", "-new_cell_names", "-new_net_names"]);
                let lc = x.get("-lib_cell").cloned().or(x.pos.get(1).cloned()).unwrap_or_default();
                let lc = lc.rsplit('/').next().unwrap_or(&lc).to_string();
                let Some(buf) = self.libs.iter().find_map(|l| l.cells.get(&lc)).cloned() else { return Some(err(format!("Library cell '{}' not found", lc))) };
                let objs = self.objs(x.pos.first().map(|s| s.as_str()).unwrap_or(""), "any");
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let mut n = 0;
                for o in objs {
                    match o {
                        Obj::Net(nn) => {
                            if let Some(id) = nl.net_by_name(&nn) {
                                let loads = nl.loads(id);
                                crate::opt::insert_buffer(nl, id, &loads, &buf, "eco_buf_");
                                n += 1;
                            }
                        }
                        Obj::Pin(p) | Obj::Port(p) => {
                            if let Some(pr) = nl.find_pin(&p) {
                                if let Some(id) = nl.pin_net(pr) {
                                    if nl.is_load(pr) {
                                        crate::opt::insert_buffer(nl, id, &[pr], &buf, "eco_buf_");
                                    } else {
                                        let loads = nl.loads(id);
                                        crate::opt::insert_buffer(nl, id, &loads, &buf, "eco_buf_");
                                    }
                                    n += 1;
                                }
                            }
                        }
                        _ => {}
                    }
                }
                crate::info!("ECO-110", "Inserted {} buffer(s) ({})", n, lc);
                Ok(n.to_string())
            }
            "clone_cell" | "eco_clone" => {
                let x = args(a, &["-loads", "-cell"]);
                let cname = x.get("-cell").cloned().or(x.pos.first().cloned()).map(|s| Obj::parse(&s).map(|o| o.name().to_string()).unwrap_or(s)).unwrap_or_default();
                let loads: Vec<String> = x.get("-loads").map(|s| split_list(s)).unwrap_or_default().into_iter().map(|s| Obj::parse(&s).map(|o| o.name().to_string()).unwrap_or(s)).collect();
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let Some(c) = nl.cell_by_name(&cname) else { return Some(err(format!("Cell '{}' not found", cname))) };
                let cell = nl.cell(c).clone();
                let nm = nl.fresh(&format!("{}_clone", cell.name));
                let k = nl.add_cell(&nm, cell.kind.clone(), &cell.pins.iter().map(|p| (p.name.as_str(), p.dir)).collect::<Vec<_>>());
                nl.cell_mut(k).loc = cell.loc;
                nl.cell_mut(k).attrs.push("clone".into());
                let mut outnet = None;
                for (i, p) in cell.pins.iter().enumerate() {
                    if p.dir == Dir::In {
                        if let Some(n) = p.net {
                            nl.connect(k, i, n);
                        }
                    } else if outnet.is_none() && p.net.is_some() {
                        let nn = nl.add_net(&format!("{}_{}", nm, p.name));
                        nl.connect(k, i, nn);
                        outnet = Some(nn);
                    }
                }
                let mut moved = 0;
                let orig_out = cell.pins.iter().find(|p| p.dir == Dir::Out && p.net.is_some()).and_then(|p| p.net);
                if let Some(nn) = outnet {
                    for l in loads {
                        if let Some(pr) = nl.find_pin(&l) {
                            if nl.pin_net(pr) != orig_out || nl.is_driver(pr) {
                                crate::warn!("ECO-121", "clone_cell: '{}' is not a load of '{}'; skipped", l, cname);
                                continue;
                            }
                            match pr {
                                PinRef::Cell(lc, lp) => nl.connect(lc, lp, nn),
                                PinRef::Port(pp) => nl.connect_port(pp, nn),
                            }
                            moved += 1;
                        }
                    }
                }
                crate::info!("ECO-120", "Cloned '{}' -> '{}' ({} load(s) moved; sequential={})", cname, nm, moved, matches!(cell.kind, Kind::Lib(ref l) if l.contains("DFF") || l.contains("LAT")));
                Ok(nm)
            }
            "fix_eco_timing" | "eco_opt" | "fix_eco_drc" | "fix_eco_power" => {
                let x = args(a, &["-type", "-types", "-max_iterations"]);
                let ty = x.get("-type").or(x.get("-types")).cloned().unwrap_or(if name == "fix_eco_drc" { "drc".into() } else if name == "fix_eco_power" { "power".into() } else { "setup".into() });
                let it = x.num("-max_iterations").unwrap_or(10.0) as usize;
                let hm = self.appf("opt.hold.margin");
                let mg = self.appf("opt.recovery.slack_margin");
                self.with_env(|nl, env| {
                    let mut out = vec![];
                    for t in split_list(&ty) {
                        match t.as_str() {
                            "setup" | "timing" => {
                                let s = crate::opt::optimize_timing(nl, env, it, true, false);
                                out.push(format!("setup: {} upsize, {} vt-swap, {} pin-swap", s.upsized, s.vt_swapped, s.pin_swaps));
                            }
                            "hold" => out.push(format!("hold: {} buffer(s)", crate::opt::fix_hold(nl, env, hm, it))),
                            "drc" | "drv" | "max_transition" | "max_capacitance" | "max_fanout" => {
                                let (s, b) = crate::opt::fix_drv(nl, env, it);
                                out.push(format!("drv: {} sized, {} buffers", s, b));
                            }
                            "power" | "leakage" | "area" => {
                                let (v, d) = crate::opt::recover_power_area(nl, env, t != "area", t == "area" || t == "power", mg);
                                out.push(format!("recovery: {} vt-swap, {} downsize", v, d));
                            }
                            _ => {}
                        }
                    }
                    for o in &out {
                        crate::info!("ECO-200", "{}: {}", name, o);
                    }
                    out.join("; ")
                })
            }
            // cleanup / sanity
            "remove_unconnected_ports" | "remove_unused_ports" | "cleanup_design" | "resolve_multidriven" | "remove_unused_logic" => self.c_cleanup(name, a),
            // DFT
            "set_dft_signal" => {
                let x = args(a, &["-type", "-port", "-view", "-active_state", "-hookup_pin", "-timing"]);
                let ty = x.get("-type").cloned().unwrap_or_default();
                let port = x.get("-port").map(|s| self.objs(s, "port").first().map(|o| o.name().to_string()).unwrap_or(s.clone())).unwrap_or_default();
                match ty.as_str() {
                    "ScanEnable" => self.dft.scan_enable = Some(port.clone()),
                    "TestMode" | "Constant" => self.dft.test_mode = Some(port.clone()),
                    "ScanDataIn" => self.dft.scan_in.push(port.clone()),
                    "ScanDataOut" => self.dft.scan_out.push(port.clone()),
                    _ => {}
                }
                self.dft.signals.push((ty, port, x.get("-active_state").cloned().unwrap_or("1".into())));
                ok()
            }
            "set_scan_configuration" => {
                let x = args(a, &["-chain_count", "-max_length", "-clock_mixing", "-style"]);
                if let Some(v) = x.num("-chain_count") {
                    self.dft.chain_count = v as usize;
                }
                if let Some(v) = x.num("-max_length") {
                    self.dft.max_length = Some(v as usize);
                }
                if let Some(v) = x.get("-clock_mixing") {
                    self.dft.mix_clocks = v.contains("mix") && v != "no_mix";
                }
                ok()
            }
            "set_scan_element" => {
                let val = a.first().map(|s| s == "true").unwrap_or(true);
                let objs: Vec<Obj> = a.iter().skip(1).flat_map(|p| self.objs(p, "cell")).collect();
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                for o in objs {
                    if let Some(c) = nl.cell_by_name(o.name()) {
                        if !val {
                            nl.cell_mut(c).attrs.push("scan_exclude".into());
                        }
                    }
                }
                ok()
            }
            "create_test_protocol" => {
                self.dft.protocol = true;
                crate::info!("DFT-010", "Test protocol created (scan enable: {}, test mode: {})", self.dft.scan_enable.clone().unwrap_or("test_se (auto)".into()), self.dft.test_mode.clone().unwrap_or("-".into()));
                ok()
            }
            "dft_drc" | "preview_dft" | "insert_dft" => {
                let preview = name != "insert_dft";
                let lib = self.target_idx();
                if self.libs.is_empty() {
                    return Some(err("no libraries"));
                }
                let mut cfg = self.dft.clone();
                let Some(nl) = self.nl.as_mut() else { return Some(err("no design")) };
                if !nl.mapped {
                    return Some(err("insert_dft requires a mapped design (run compile_fusion -to initial_map or later) (DFT-001)"));
                }
                let r = crate::dft::insert(nl, &self.libs[lib], &mut cfg, preview);
                self.dft = cfg;
                if preview {
                    for (n, d, regs) in &self.dft.chains {
                        crate::out!("  preview {}: {} cells (domain {})", n, regs.len(), d);
                    }
                }
                r.map(|n| n.to_string()).map_err(e2f)
            }
            "optimize_scan_chain" | "optimize_scan_chains" | "reorder_scan_chains" => {
                let x = args(a, &["-chains", "-effort", "-max_passes"]);
                let only: Vec<String> = x.get("-chains").map(|c| split_list(c)).unwrap_or_default();
                let passes = x.num("-max_passes").map(|v| v as usize).unwrap_or(match x.get("-effort").map(|s| s.as_str()) {
                    Some("low") => 0,
                    Some("high") => 50,
                    _ => 10,
                });
                let repart = x.has("-repartition") || x.has("-cross_chains");
                let mut cfg = std::mem::take(&mut self.dft);
                let r = match self.nl.as_mut() {
                    Some(nl) => crate::dft::optimize_chains(nl, &self.libs, &mut cfg, &only, repart, passes),
                    None => Err("no design".to_string()),
                };
                self.dft = cfg;
                match r {
                    Err(e) => Err(e2f(format!("optimize_scan_chain: {}", e))),
                    Ok((stats, removed)) => {
                        crate::out!("\n{:<28} {:>7} {:>14} {:>14} {:>9}", "Chain", "Cells", "Before (um)", "After (um)", "Change");
                        let (mut tb, mut ta) = (0.0, 0.0);
                        for st in &stats {
                            tb += st.before;
                            ta += st.after;
                            crate::out!("{:<28} {:>7} {:>14.1} {:>14.1} {:>8.1}%", st.chain, st.cells, st.before, st.after, if st.before > 0.0 { 100.0 * (st.after - st.before) / st.before } else { 0.0 });
                        }
                        crate::out!("{:<28} {:>7} {:>14.1} {:>14.1} {:>8.1}%", "Total", stats.iter().map(|s| s.cells).sum::<usize>(), tb, ta, if tb > 0.0 { 100.0 * (ta - tb) / tb } else { 0.0 });
                        crate::info!("DFT-300", "Scan chain reordering{}: wirelength {:.1}um -> {:.1}um; {} orphaned scan-path buffer(s) removed. Re-run hold fixing (e.g. compile_fusion -from final_opto) for the new scan connections", if repart { " with repartitioning" } else { "" }, tb, ta, removed);
                        Ok(format!("{:.3}", ta))
                    }
                }
            }
            "check_scan_chains" => {
                let nl = match self.nl() { Ok(n) => n, Err(e) => return Some(Err(e)) };
                let mut bad = 0;
                for (n, _, regs) in &self.dft.chains {
                    let si = n.split_once(':').map(|x| x.0).unwrap_or(n);
                    let tr = crate::dft::trace_chain(nl, &self.libs, si, regs.len() + 1);
                    if &tr == regs {
                        crate::out!("  {:<24} OK ({} cells traced from '{}')", n, tr.len(), si);
                    } else {
                        bad += 1;
                        let k = tr.iter().zip(regs.iter()).take_while(|(a, b)| a == b).count();
                        crate::error!("DFT-310", "Scan chain {}: traced {} cell(s), expected {}; first difference at position {}", n, tr.len(), regs.len(), k);
                    }
                }
                Ok(bad.to_string())
            }
            "report_scan_chains" | "report_scan_configuration" => {
                crate::out!("\nScan chains: {}", self.dft.chains.len());
                let wl: Vec<f64> = match self.nl.as_ref() {
                    Some(nl) => self.dft.chains.iter().map(|(n, _, regs)| {
                        let (si, so) = n.split_once(':').unwrap_or((n, n));
                        let cl: Vec<CellId> = regs.iter().filter_map(|r| nl.cell_by_name(r)).collect();
                        let pl = |p: &str| nl.port_by_name(p).and_then(|q| nl.ports[q].loc);
                        crate::dft::chain_length(nl, pl(si), pl(so), &cl)
                    }).collect(),
                    None => vec![0.0; self.dft.chains.len()],
                };
                for (k, (n, d, regs)) in self.dft.chains.iter().enumerate() {
                    crate::out!("  {:<24} length {:>5}  clock domain '{}'  scan wirelength {:.1}um", n, regs.len(), d, wl[k]);
                    if a.iter().any(|x| x == "-verbose") {
                        for r in regs {
                            crate::out!("      {}", r);
                        }
                    }
                }
                if !self.dft.excluded.is_empty() {
                    crate::out!("  excluded: {}", self.dft.excluded.join(", "));
                }
                ok()
            }
            "write_scan_def" | "write_test_protocol" => {
                let f = a.iter().find(|x| !x.starts_with('-') && *x != "-output").cloned().unwrap_or("scan.def".into());
                let mut s = String::new();
                if name == "write_scan_def" {
                    s.push_str(&format!("VERSION 5.8 ;\nDESIGN {} ;\nSCANCHAINS {} ;\n", self.nl.as_ref().map(|n| n.name.clone()).unwrap_or_default(), self.dft.chains.len()));
                    for (i, (n, _, regs)) in self.dft.chains.iter().enumerate() {
                        let (si, so) = n.split_once(':').unwrap_or((n, n));
                        s.push_str(&format!("  - chain{}\n    + START PIN {}\n    + FLOATING", i, si));
                        for r in regs {
                            s.push_str(&format!(" {} ( IN SI ) ( OUT Q )", r));
                        }
                        s.push_str(&format!("\n    + STOP PIN {} ;\n", so));
                    }
                    s.push_str("END SCANCHAINS\nEND DESIGN\n");
                } else {
                    s.push_str("STIL 1.0;\n// RSynth test protocol (skeleton)\nSignals {\n");
                    for (t, p, v) in &self.dft.signals {
                        s.push_str(&format!("  \"{}\" In; // {} active {}\n", p, t, v));
                    }
                    s.push_str("}\n");
                }
                std::fs::write(&f, s).map(|_| f).map_err(|e| Flow::Err(e.to_string()))
            }
            // reports
            "report_timing" => self.c_timing_paths(a, false),
            "get_timing_paths" => self.c_timing_paths(a, true),
            "remove_design" | "remove_designs" => {
                // remove_design [-all] [design]: clear the design (libraries, modes, corners stay)
                let had = self.nl.as_ref().map(|n| n.name.clone()).unwrap_or_default();
                self.nl = None;
                self.golden = None;
                self.fp = None;
                self.routes = None;
                self.routed_rc = None;
                self.spef_rc.clear();
                self.spef_stats.clear();
                self.ann_delays.clear();
                self.tpaths.clear();
                self.eco_changes.clear();
                self.top = None;
                if a.iter().any(|x| x == "-all") {
                    self.hdl = Default::default();
                    self.pragmas_applied = 0;
                }
                self.bump_epoch();
                crate::info!("DES-100", "Removed design '{}'{}", had, if a.iter().any(|x| x == "-all") { " and all analyzed design units" } else { "" });
                Ok(had)
            }
            "report_pragmas" | "report_synthesis_pragmas" => {
                crate::out!("\n****************************************\nReport : pragmas\n****************************************");
                crate::out!("  {:<36} {:>6}  {:<22} {}", "File", "Line", "Directive", "Argument");
                for (f, p) in &self.hdl.pragmas {
                    crate::out!("  {:<36} {:>6}  {:<22} {}", f, p.line, p.kind, p.args);
                }
                if !self.pragma_notes.is_empty() {
                    crate::out!("\n  Effects in the elaborated design:");
                    for n in &self.pragma_notes {
                        crate::out!("    {}", n);
                    }
                }
                Ok(self.hdl.pragmas.len().to_string())
            }
            "report_timing_format" | "set_report_timing_format" | "set_timing_report_format" => {
                // report_timing_format [{columns}] [-transition] [-capacitance] [-fanout] [-derate] [-user_derate] [-ocv] [-aocv] [-pocv] [-derates] [-remove] [-reset] [-help]
                let x = args(a, &[]);
                if x.has("-help") || x.has("-list") {
                    crate::out!("report_timing columns:");
                    for (c, d) in crate::tpaths::COLUMNS {
                        crate::out!("  {:<12} {}", c, d);
                    }
                    return Some(ok());
                }
                if x.has("-reset") {
                    self.timing_columns = crate::tpaths::default_columns();
                } else if let Some(f) = x.pos.first() {
                    let mut v = vec![];
                    for c in split_list(f) {
                        match crate::tpaths::canon_column(&c) {
                            Some(k) => v.push(k.to_string()),
                            None => return Some(err(format!("{}: unknown column '{}' (use -help for the list) (CMD-010)", name, c))),
                        }
                    }
                    if !v.iter().any(|c| c == "point" || c == "instance") {
                        v.insert(0, "point".into());
                    }
                    self.timing_columns = v;
                }
                // -transition / -capacitance / -fanout: add (or with -remove, drop) the pin transition,
                // output-pin load capacitance and output-pin fanout columns, placed before 'incr'
                let mut extra: Vec<&str> = [("-transition", "trans"), ("-transition_time", "trans"), ("-capacitance", "cap"), ("-fanout", "fanout"),
                    ("-user_derate", "user_derate"), ("-ocv", "ocv_derate"), ("-ocv_derate", "ocv_derate"), ("-aocv", "aocv_derate"), ("-aocv_derate", "aocv_derate"),
                    ("-pocv", "pocv_sigma"), ("-pocv_sigma", "pocv_sigma"), ("-derate", "derate")]
                    .iter().filter(|(f, _)| x.has(f)).map(|(_, c)| *c).collect();
                // -derates: the whole breakdown (user, OCV, AOCV, POCV sigma, applied)
                if x.has("-derates") || x.has("-all_derates") { extra.extend(["user_derate", "ocv_derate", "aocv_derate", "pocv_sigma", "derate"]); }
                for c in extra {
                    if x.has("-remove") {
                        self.timing_columns.retain(|k| k != c);
                    } else if !self.timing_columns.iter().any(|k| k == c) {
                        let at = self.timing_columns.iter().position(|k| k == "incr").unwrap_or(self.timing_columns.len());
                        self.timing_columns.insert(at, c.to_string());
                    }
                }
                crate::info!("TIM-360", "report_timing columns: {}", self.timing_columns.join(" "));
                Ok(to_list(&self.timing_columns))
            }
            "sort_collection" => self.c_sort_collection(a),
            "reset_eco_changes" | "clear_eco_changes" => {
                let n = self.eco_changes.len();
                self.eco_changes.clear();
                crate::info!("ECO-301", "Cleared {} recorded ECO change(s)", n);
                Ok(n.to_string())
            }
            "report_qor" => self.c_report_qor(a),
            "report_constraints" | "report_constraint" => self.c_report_constraints(a),
            "report_area" => self.c_report_area(a),
            "report_power" => self.c_report_power(a),
            "report_threshold_voltage_group" | "report_vt" => self.c_report_vt(),
            "report_clock_gating" => self.c_report_cg(),
            "report_clocks" | "report_clock" => self.c_report_clocks(a),
            "report_clock_crossing" | "report_clock_crossings" | "report_cdc" => self.c_report_clock_crossing(a),
            "report_net_fanout" | "report_high_fanout" => {
                let x = args(a, &["-threshold"]);
                let th = x.num("-threshold").unwrap_or(16.0) as usize;
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                let mut v: Vec<(usize, String)> = nl.net_ids().into_iter().map(|n| (nl.loads(n).len(), nl.net(n).name.clone())).filter(|x| x.0 >= th).collect();
                v.sort_by(|a, b| b.0.cmp(&a.0));
                crate::out!("\n{:<50} {:>8}", "Net", "Fanout");
                for (f, n) in v {
                    crate::out!("{:<50} {:>8}", n, f);
                }
                ok()
            }
            "report_reference" | "report_cell" => self.c_report_ref(name, a),
            "report_design" | "report_design_mismatch" => self.c_report_design(),
            "report_lib" => {
                for l in &self.libs {
                    crate::out!("{}", l.summary());
                    if a.iter().any(|x| x == "-cells") {
                        for n in &l.cell_order {
                            let c = &l.cells[n];
                            crate::out!("   {:<20} area {:>7.3} leak {:>9.3}nW vt {:<5} drive {:>4} {}{}{}{}", c.name, c.area, c.leakage, c.vt, c.drive, if c.is_seq() { "seq " } else { "" }, if c.dont_use { "dont_use " } else { "" }, if c.scan { "scan " } else { "" }, if c.always_on { "aon" } else { "" });
                        }
                    }
                }
                ok()
            }
            "report_hierarchy" => {
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                let _ = nl;
                return Some(self.c_report_hierarchy_ext());
            }
            "report_exceptions" => {
                for e in &self.modes[self.cur_mode].sdc.exceptions {
                    crate::out!("  {:?} from={:?} through={:?} to={:?} setup={} hold={}", e.kind, e.from.iter().map(|o| o.name()).collect::<Vec<_>>(), e.through.iter().map(|o| o.name()).collect::<Vec<_>>(), e.to.iter().map(|o| o.name()).collect::<Vec<_>>(), e.setup, e.hold);
                }
                ok()
            }
            "report_ports" | "report_port" => {
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                let cons = &self.modes[self.cur_mode].sdc;
                crate::out!("\n{:<28} {:<6} {:<26} {:<26}", "Port", "Dir", "Input delay (clk max/min)", "Output delay");
                for p in nl.port_ids() {
                    let pt = &nl.ports[p];
                    let f = |inp: bool| cons.io.iter().filter(|x| x.is_input == inp && x.obj.name() == pt.name).map(|x| format!("{} {:?}/{:?}", x.clock.clone().unwrap_or("-".into()), x.max, x.min)).collect::<Vec<_>>().join(",");
                    crate::out!("{:<28} {:<6} {:<26} {:<26}", pt.name, format!("{:?}", pt.dir), f(true), f(false));
                }
                ok()
            }
            "report_timing_derate" => {
                for c in &self.corners {
                    crate::out!("  corner {:<10} cell late {:.3} early {:.3}  net late {:.3} early {:.3}", c.name, c.late_cell, c.early_cell, c.late_net, c.early_net);
                }
                ok()
            }
            "check_timing" => self.c_check_timing(a),
            "check_design" | "check_netlist" | "analyze_design_violations" => self.c_check_design(name, a),
            "check_library" => {
                for l in &self.libs {
                    let ties = l.cells.values().filter(|c| c.tie.is_some()).count();
                    let icg = l.cells.values().filter(|c| c.icg.is_some()).count();
                    let scan = l.cells.values().filter(|c| c.scan).count();
                    let iso = l.cells.values().filter(|c| c.is_iso).count();
                    let ls = l.cells.values().filter(|c| c.is_ls).count();
                    let ret = l.cells.values().filter(|c| c.retention).count();
                    let aon = l.cells.values().filter(|c| c.always_on).count();
                    crate::out!("{}\n   tie={} icg={} scan={} iso={} ls={} retention={} always_on={}", l.summary(), ties, icg, scan, iso, ls, ret, aon);
                    for c in l.cells.values() {
                        if c.outputs().is_empty() && !c.is_switch {
                            crate::warn!("LIB-201", "Cell {} has no output pins", c.name);
                        }
                        if c.is_comb() && c.outputs()[0].arcs.is_empty() {
                            crate::warn!("LIB-202", "Combinational cell {} has no timing arcs", c.name);
                        }
                    }
                }
                ok()
            }
            // writers
            "write_verilog" | "write" => {
                let f = a.iter().filter(|x| !x.starts_with('-')).last().cloned().unwrap_or("out.v".into());
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                let flat = a.iter().any(|x| x == "-flat" || x == "-flatten" || x == "-no_hierarchy");
                let libs = &self.libs;
                let is_lib = |n: &str| libs.iter().any(|l| l.cells.contains_key(n));
                let r = if flat { crate::out::write_verilog(nl, &f, &is_lib).map(|_| 0) } else { crate::out::write_verilog_hier(nl, &f, &is_lib) };
                r.map_err(|e| Flow::Err(e.to_string())).map(|nm| {
                    crate::info!("OUT-100", "Wrote Verilog netlist '{}' ({} cells, {}, {})", f, nl.num_cells(), if nl.mapped { "mapped" } else { "GENERIC/unmapped" }, if nm > 0 { format!("hierarchical: {} module(s) below top", nm) } else { "flat".to_string() });
                    f
                })
            }
            "write_parasitics" | "write_spef" => {
                let x = args(a, &["-output", "-format", "-corner", "-corners"]);
                let prefix = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or("out".into());
                let corners: Vec<String> = x.get("-corner").or(x.get("-corners")).map(|s| split_list(s)).unwrap_or_else(|| self.scens.iter().filter(|s| s.active).map(|s| s.corner.clone()).collect::<std::collections::BTreeSet<_>>().into_iter().collect());
                let mut files = vec![];
                for cn in corners {
                    let Some(si) = self.scens.iter().position(|s| s.corner == cn) else {
                        crate::warn!("OUT-201", "No scenario uses corner '{}'; skipped", cn);
                        continue;
                    };
                    let f = format!("{}.{}.spef", prefix.trim_end_matches(".spef"), cn);
                    let ff = f.clone();
                    let r = self.with_timing(si, |t| crate::out::write_spef(t, &ff, &cn));
                    match r {
                        Ok(Ok(())) => {
                            crate::info!("OUT-200", "Wrote SPEF '{}' (corner {}, {} parasitics)", f, t_corner_name(&self.scens[si]), if self.routed_rc.is_some() { "extracted from detailed routes" } else { "estimated" });
                            files.push(f)
                        }
                        Ok(Err(e)) => return Some(err(e.to_string())),
                        Err(e) => return Some(Err(e)),
                    }
                }
                Ok(to_list(&files))
            }
            "write_sdc" => {
                let x = args(a, &["-mode", "-output"]);
                let f = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or("out.sdc".into());
                let m = x.get("-mode").and_then(|m| self.modes.iter().position(|q| &q.name == m)).unwrap_or(self.cur_mode);
                let s = format!("# SDC written by RSynth (mode {})\n{}\n", self.modes[m].name, self.modes[m].sdc.raw.join("\n"));
                std::fs::write(&f, s).map(|_| f).map_err(|e| Flow::Err(e.to_string()))
            }
            // shell
            "redirect" => {
                let x = args(a, &["-file", "-variable"]);
                let append = x.has("-append");
                let body = x.pos.last().cloned().unwrap_or_default();
                let file = x.get("-file").cloned().or(if x.pos.len() >= 2 { Some(x.pos[0].clone()) } else { None });
                crate::log::push_redirect();
                let r = self.eval(&body);
                let s = crate::log::pop_redirect();
                if let Some(v) = x.get("-variable") {
                    self.interp.set(v, &s);
                } else if let Some(f) = file {
                    use std::io::Write;
                    let fh = std::fs::OpenOptions::new().create(true).append(append).write(true).truncate(!append).open(&f);
                    if let Ok(mut fh) = fh {
                        let _ = fh.write_all(s.as_bytes());
                    }
                }
                r.map(|_| String::new())
            }
            "sh" | "exec" => {
                let c = a.join(" ");
                match std::process::Command::new("sh").arg("-c").arg(&c).output() {
                    Ok(o) => Ok(String::from_utf8_lossy(&o.stdout).trim_end().to_string()),
                    Err(e) => err(e.to_string()),
                }
            }
            "date" => Ok(format!("{:?}", std::time::SystemTime::now())),
            "getenv" => Ok(std::env::var(a.first().map(|s| s.as_str()).unwrap_or("")).unwrap_or_default()),
            "exit" | "quit" => {
                self.exit = true;
                ok()
            }
            "set_message_info" => {
                let x = args(a, &["-id", "-limit"]);
                if let (Some(id), Some(l)) = (x.get("-id"), x.num("-limit")) {
                    crate::log::set_limit(id, l as usize);
                }
                ok()
            }
            "suppress_message" | "unsuppress_message" => {
                for id in a.iter().flat_map(|x| split_list(x)) {
                    crate::log::suppress(&id, name == "suppress_message");
                }
                ok()
            }
            "report_messages" | "print_message_info" => {
                crate::log::summary();
                ok()
            }
            "verify_equivalence" | "check_equivalence" | "verify" => {
                let x = args(a, &["-cycles", "-constants", "-resets", "-seed", "-reference"]);
                let cycles = x.num("-cycles").unwrap_or(2000.0) as usize;
                let mut consts = HashMap::new();
                if let Some(c) = x.get("-constants") {
                    let l = split_list(c);
                    for p in l.chunks(2) {
                        if p.len() == 2 {
                            consts.insert(p[0].clone(), p[1] == "1");
                        }
                    }
                }
                let resets = x.get("-resets").map(|s| split_list(s)).unwrap_or_default();
                let (Some(g), Some(r)) = (&self.golden, &self.nl) else { return Some(err("verify_equivalence: need an elaborated reference and a current design")) };
                let seed = x.num("-seed").unwrap_or(12345.0) as u64;
                match crate::sim::equivalence(g, r, &self.libs, cycles, &consts, &resets, seed) {
                    Ok(res) => {
                        crate::out!("\n**** verify_equivalence (random co-simulation vs. elaborated RTL) ****\n  cycles {}  compared outputs {}  mismatches {}", res.cycles, res.compared_outputs, res.mismatches.len());
                        if !res.unverifiable.is_empty() {
                            crate::warn!("EQV-110", "{} output(s) unverifiable: driven by multi-driven nets in the reference ({})", res.unverifiable.len(), res.unverifiable.join(", "));
                        }
                        for (c, o, a, b) in res.mismatches.iter().take(20) {
                            crate::out!("    cycle {:>6}  {:<24} reference={} revised={}", c, o, *a as u8, *b as u8);
                        }
                        if res.mismatches.is_empty() {
                            crate::info!("EQV-100", "Verification SUCCEEDED: {} outputs matched over {} cycles", res.compared_outputs, res.cycles);
                        } else {
                            crate::error!("EQV-200", "Verification FAILED: {} mismatch(es)", res.mismatches.len());
                        }
                        Ok(res.mismatches.len().to_string())
                    }
                    Err(e) => err(e),
                }
            }
            "help" | "man" => {
                self.help(a.first().map(|s| s.as_str()));
                ok()
            }
            _ => return None,
        })
    }

    pub(crate) fn rawsdc(&mut self, name: &str, a: &[String]) {
        let txt = format!("{} {}", name, a.iter().map(|x| {
            let objs = split_list(x);
            if objs.iter().all(|o| Obj::parse(o).is_some()) && !objs.is_empty() {
                let kind = Obj::parse(&objs[0]).map(|o| match o {
                    Obj::Port(_) => "get_ports",
                    Obj::Pin(_) => "get_pins",
                    Obj::Cell(_) => "get_cells",
                    Obj::Net(_) => "get_nets",
                    Obj::Clock(_) => "get_clocks",
                    Obj::LibCell(_) => "get_lib_cells",
                }).unwrap_or("get_ports");
                format!("[{} {{{}}}]", kind, objs.iter().map(|o| Obj::parse(o).unwrap().name().to_string()).collect::<Vec<_>>().join(" "))
            } else {
                tcl::quote(x)
            }
        }).collect::<Vec<_>>().join(" "));
        self.cons().raw.push(txt);
    }

    fn corner_idx(&mut self, c: &str, create: bool) -> usize {
        if let Some(i) = self.corners.iter().position(|x| x.name == c) {
            return i;
        }
        if create {
            if self.implicit.1 {
                self.implicit.1 = false;
                if self.corners.len() == 1 && self.corners[0].name == "default" && !self.scens.iter().any(|s| s.corner == "default" && !(self.implicit.2 && s.name == "default")) {
                    let libs = self.corners[0].libs.clone();
                    self.corners.clear();
                    let mut cc = Corner::new(c);
                    cc.libs = libs;
                    self.corners.push(cc);
                    return 0;
                }
            }
            self.corners.push(Corner::new(c));
            return self.corners.len() - 1;
        }
        0
    }

    fn c_set_app(&mut self, name: &str, a: &[String]) -> R {
        let (k, v) = if name == "set_app_var" {
            (a.first().cloned().unwrap_or_default(), a.get(1).cloned().unwrap_or_default())
        } else {
            let x = args(a, &["-name", "-value", "-list"]);
            if let Some(l) = x.get("-list") {
                let kv = split_list(l);
                for p in kv.chunks(2) {
                    if p.len() == 2 {
                        self.app.insert(p[0].clone(), p[1].clone());
                    }
                }
                return ok();
            }
            (x.get("-name").cloned().unwrap_or_default(), x.get("-value").cloned().unwrap_or_default())
        };
        if k == "target_library" || k == "link_library" {
            for f in split_list(&v) {
                if f == "*" || f.is_empty() {
                    continue;
                }
                if !self.libs.iter().any(|l| l.file == f || l.name == f) && (f.ends_with(".lib") || std::path::Path::new(&f).exists()) {
                    self.c_read_lib(&[f.clone()])?;
                }
            }
        }
        self.app.insert(k.clone(), v.clone());
        Ok(v)
    }

    fn c_read_lib(&mut self, a: &[String]) -> R {
        let x = args(a, &["-corner", "-corners"]);
        let mut names = vec![];
        for f in x.pos.iter().flat_map(|p| split_list(p)) {
            let lib = Library::load(&f).map_err(e2f)?;
            crate::info!("LIB-001", "Loaded {}", lib.summary());
            if lib.n_ccs > 0 {
                crate::info!("LIB-010", "Library '{}' contains CCS timing ({} arcs); delay calculation uses the NLDM tables, CCS receiver caps used for loads", lib.name, lib.n_ccs);
            }
            if lib.n_ecsm > 0 {
                crate::info!("LIB-011", "Library '{}' contains ECSM data ({} arcs); NLDM tables used for delay calculation", lib.name, lib.n_ecsm);
            }
            if lib.n_ccsn > 0 {
                crate::info!("LIB-012", "Library '{}' contains CCS-noise models on {} pins (retained; noise analysis not performed)", lib.name, lib.n_ccsn);
            }
            names.push(lib.name.clone());
            let idx = self.libs.len();
            self.libs.push(lib);
            // dont_use set before this library was read still applies to it
            let du: Vec<(String, bool)> = self.dont_use_cmds.clone();
            for (pat, v) in du {
                Self::mark_dont_use(&mut self.libs[idx], &pat, v);
            }
            if let Some(cs) = x.get("-corner").or(x.get("-corners")) {
                for c in split_list(cs) {
                    let ci = self.corner_idx(&c, true);
                    self.corners[ci].libs.push(idx);
                }
            }
        }
        Ok(to_list(&names))
    }

    fn c_analyze(&mut self, a: &[String]) -> R {
        let x = args(a, &["-format", "-define", "-library", "-work", "-search_path", "-lib"]);
        let fmt = x.get("-format").cloned().unwrap_or("sverilog".into());
        if let Some(d) = x.get("-define") {
            for def in split_list(d) {
                let (k, v) = def.split_once('=').unwrap_or((&def, ""));
                self.hdl.pre.defines.insert(k.to_string(), (vec![], v.to_string()));
            }
        }
        if let Some(sp) = x.get("-search_path") {
            self.hdl.pre.incdirs.extend(split_list(sp));
        }
        let bb = x.has("-blackbox");
        let mut all = vec![];
        for f in x.pos.iter().flat_map(|p| split_list(p)) {
            let r = if fmt == "vhdl" || fmt == "vhd" || f.ends_with(".vhd") || f.ends_with(".vhdl") { self.hdl.read_vhdl(&f, bb) } else { self.hdl.read_sv(&f, bb) };
            match r {
                Ok(n) => {
                    crate::info!("VER-1", "Analyzed '{}' ({}): {}", f, fmt, n.join(", "));
                    all.extend(n);
                }
                Err(e) => {
                    crate::error!("VER-2", "{}", e);
                    return err(e);
                }
            }
        }
        if bb {
            for n in &all {
                crate::info!("VER-BB", "[BLACKBOX] '{}' imported as black box (ports only, no implementation)", n);
            }
        }
        Ok(to_list(&all))
    }
    fn c_read_hdl(&mut self, name: &str, a: &[String]) -> R {
        let x = args(a, &["-top", "-format", "-define"]);
        let mut v = vec!["-format".to_string(), if name == "read_vhdl" { "vhdl".into() } else { x.get("-format").cloned().unwrap_or("sverilog".into()) }];
        if let Some(d) = x.get("-define") {
            v.push("-define".into());
            v.push(d.clone());
        }
        if x.has("-blackbox") || x.has("-netlist_blackbox") {
            v.push("-blackbox".into());
        }
        v.extend(x.pos.iter().cloned());
        let r = self.c_analyze(&v)?;
        if let Some(t) = x.get("-top") {
            self.c_elaborate(&[t.clone()])?;
        }
        Ok(r)
    }

    fn c_elaborate(&mut self, a: &[String]) -> R {
        let x = args(a, &["-parameters", "-architecture", "-library"]);
        let top = x.pos.first().cloned().or_else(|| self.hdl.tops().first().cloned()).ok_or_else(|| Flow::Err("elaborate: no top design given".into()))?;
        let mut tp = vec![];
        if let Some(p) = x.get("-parameters") {
            for kv in p.split(|c| c == ',' || c == ' ').filter(|s| !s.is_empty()) {
                if let Some((k, v)) = kv.split_once('=') {
                    let v = v.trim().trim_matches('"');
                    let val = if let Some(h) = v.strip_prefix("0x") { i128::from_str_radix(h, 16).unwrap_or(0) } else { v.parse::<i128>().unwrap_or(0) };
                    tp.push((k.trim().to_string(), val));
                }
            }
        }
        let mut lib_cells = HashMap::new();
        for l in &self.libs {
            for (n, c) in &l.cells {
                lib_cells.entry(n.clone()).or_insert_with(|| c.pins.iter().map(|p| (p.name.clone(), p.dir.unwrap_or(Dir::In))).collect::<Vec<_>>());
            }
        }
        if !self.reelab {
            // a user-issued elaborate starts a fresh hierarchy (ungroup state belongs to the old design)
            self.ungrouped.clear();
            self.simple_names.clear();
            self.ungroup_marks.clear();
            self.cur_inst.clear();
            self.selection.clear();
        }
        let mut bl = self.bopt.clone();
        // ungrouped instances never keep boundary pins
        for u in &self.ungrouped {
            bl.push((u.clone(), true));
        }
        let opts = ElabOpts { empty_as_blackbox: self.appb("hdlin.elaborate.empty_module_as_blackbox"), top_params: tp, blackboxes: self.bb_designs.clone(), adder: self.app.get("hdlin.adder_architecture").cloned().unwrap_or("kogge_stone".into()), lib_cells, boundary_default: self.appb("compile.flow.boundary_optimization"), boundary: bl };
        self.last_elab = a.iter().filter(|x| *x != "-keep_reference").cloned().collect();
        crate::info!("ELAB-100", "Elaborating design '{}'", top);
        let r = elaborate(&self.hdl, &top, opts).map_err(|e| {
            crate::error!("ELAB-900", "{}", e);
            Flow::Err(e)
        })?;
        let mut nl = r.netlist;
        let rc = self.appb("compile.seqmap.remove_constant_registers");
        let st = if nl.mapped {
            // gate-level netlist: only sweep assign-buffers, keep library cells untouched
            crate::genopt::sweep(&mut nl, false, false)
        } else {
            crate::genopt::sweep(&mut nl, false, rc)
        };
        if nl.mapped {
            crate::info!("LINK-200", "Linked gate-level netlist '{}' against technology libraries ({} library cells)", nl.name, nl.cell_ids().iter().filter(|c| nl.cell(**c).lib().is_some()).count());
        }
        let nff = nl.cell_ids().iter().filter(|c| nl.cell(**c).gop() == Some(GOp::Dff)).count();
        let nlat = nl.cell_ids().iter().filter(|c| nl.cell(**c).gop() == Some(GOp::Latch)).count();
        crate::info!("ELAB-101", "Elaborated '{}': {} ports, {} generic cells ({} flops, {} latches, {} black boxes), {} nets; swept {} buffers, {} constants, {} dead cells", nl.name, nl.port_ids().len(), nl.num_cells(), nff, nlat, r.blackboxes.len(), nl.num_nets(), st.buffers, st.consts, st.dead);
        for (m, insts) in &r.multi_inst {
            crate::info!("ELAB-200", "Design '{}' instantiated {} times (non-uniquified): {}", m, insts.len(), abbrev_list(insts, 8));
        }
        self.latches = r.latches;
        self.pragma_notes = r.pragma_notes.clone();
        for n in &r.pragma_notes {
            crate::info!("ELAB-150", "Pragma {}", n);
        }
        self.multi_inst = r.multi_inst;
        self.bbs = r.blackboxes;
        self.top = Some(top.clone());
        if !x.has("-keep_reference") || self.golden.is_none() {
            self.golden = Some(nl.clone());
        } else {
            crate::info!("EQV-001", "Keeping previously elaborated design as verification reference");
        }
        let nhp: usize = nl.hport_count().values().sum();
        if nhp > 0 {
            crate::info!("ELAB-410", "Boundary optimization off for {} instance(s): {} boundary pin(s) preserved", nl.hport_count().len(), nhp);
        }
        nl.ungrouped = self.ungrouped.iter().filter(|u| nl.hier.iter().any(|(i, _)| i == *u)).cloned().collect();
        nl.simple_names = self.simple_names.clone();
        self.nl = Some(nl);
        self.stages_done.clear();
        self.uniquified = false;
        self.apply_pragmas()?;
        Ok(top)
    }

    /// design-level synthesis pragmas: keep_signal_name, embedded dc_tcl scripts; others reported
    fn apply_pragmas(&mut self) -> Result<(), Flow> {
        let ps: Vec<(String, crate::hdl::lex::Pragma)> = self.hdl.pragmas[self.pragmas_applied.min(self.hdl.pragmas.len())..].to_vec();
        self.pragmas_applied = self.hdl.pragmas.len();
        let mut script: Vec<(String, usize, String)> = vec![];
        for (f, p) in &ps {
            match p.kind.as_str() {
                "keep_signal_name" => {
                    let Some(nl) = self.nl.as_mut() else { continue };
                    let sig = p.args.clone();
                    let mut n = 0;
                    for id in nl.net_ids() {
                        let nm = nl.net(id).name.clone();
                        let leaf = nm.rsplit('/').next().unwrap_or(&nm);
                        let base = leaf.split('[').next().unwrap_or(leaf);
                        if leaf == sig || base == sig {
                            nl.net_mut(id).dont_touch = true;
                            n += 1;
                        }
                    }
                    crate::info!("ELAB-151", "Pragma keep_signal_name \"{}\" ({}:{}): {} net(s) kept (dont_touch)", sig, f, p.line, n);
                }
                "dc_tcl" => script.push((f.clone(), p.line, p.args.clone())),
                "full_case" | "parallel_case" | "translate_off" | "translate_on" | "dc_tcl_script_begin" | "dc_tcl_script_end" | "dc_script_begin" | "dc_script_end" => {}
                "sync_set_reset" | "async_set_reset" | "sync_set_reset_local" | "async_set_reset_local" => {
                    crate::info!("ELAB-152", "Pragma {} \"{}\" ({}:{}): reset kept as the last D-input condition (as elaborated from if-reset coding)", p.kind, p.args, f, p.line);
                }
                "one_hot" | "one_cold" | "infer_mux" | "infer_onehot_mux" | "infer_multibit" | "dont_infer_multibit" | "enum" | "state_vector" | "keep" | "template" => {
                    crate::info!("ELAB-153", "Pragma {} {}({}:{}) recorded; no structural effect in this tool", p.kind, if p.args.is_empty() { String::new() } else { format!("\"{}\" ", p.args) }, f, p.line);
                }
                other => crate::warn!("ELAB-154", "Unknown synthesis pragma '{}' at {}:{} ignored", other, f, p.line),
            }
        }
        if !script.is_empty() {
            let text: String = script.iter().map(|x| x.2.clone()).collect::<Vec<_>>().join("\n");
            crate::info!("ELAB-155", "Running embedded dc_tcl script ({} line(s) from {})", script.len(), script[0].0);
            if let Err(e) = self.eval(&text) {
                let m = match e {
                    Flow::Err(m) => m,
                    _ => "script stopped".into(),
                };
                crate::warn!("ELAB-156", "Embedded dc_tcl script failed: {}", m);
            }
        }
        Ok(())
    }

    /// boundary optimization wanted for an instance (app option default + set_boundary_optimization)
    fn bopt_of(&self, inst: &str) -> bool {
        if self.ungrouped.contains(inst) {
            return true;
        }
        let mut v = self.appb("compile.flow.boundary_optimization");
        for (p, b) in &self.bopt {
            if glob(p, inst) {
                v = *b;
            }
        }
        v
    }

    /// Bring boundary pins in line with the boundary-optimization settings: open boundaries by
    /// dissolving pins; preserving a boundary on an unmapped design needs re-elaboration.
    fn sync_boundaries(&mut self) -> Result<(), Flow> {
        let Some(nl) = self.nl.as_ref() else { return Ok(()) };
        let have = nl.hport_count();
        let insts: Vec<String> = nl.hier.iter().map(|(i, _)| i.clone()).collect();
        let open: HashSet<String> = insts.iter().filter(|i| have.contains_key(*i) && self.bopt_of(i)).cloned().collect();
        let need: Vec<String> = insts.iter().filter(|i| !have.contains_key(*i) && !self.bopt_of(i)).cloned().collect();
        if !open.is_empty() {
            let n = self.nl.as_mut().unwrap().dissolve_hports(&|i| open.contains(i));
            crate::info!("OPT-780", "Boundary optimization enabled on {} instance(s): {} boundary pin(s) removed", open.len(), n);
        }
        if need.is_empty() {
            return Ok(());
        }
        if self.nl.as_ref().unwrap().mapped || !self.stages_done.is_empty() {
            crate::warn!("OPT-781", "Boundary optimization turned off for {} instance(s) after mapping (e.g. '{}'): cross-boundary optimization already done cannot be undone; setting applies to new elaborations", need.len(), need[0]);
            return Ok(());
        }
        if self.last_elab.is_empty() {
            return Ok(());
        }
        // re-elaborate, keeping per-cell physical data and attributes
        crate::info!("ELAB-411", "Re-elaborating '{}' to preserve {} hierarchy boundar{} (boundary optimization off; elaboration-time folding must not cross them)", self.top.clone().unwrap_or_default(), need.len(), if need.len() == 1 { "y" } else { "ies" });
        let nl = self.nl.as_ref().unwrap();
        let mut keep: HashMap<String, (Option<(f64, f64)>, bool, bool, Vec<String>)> = HashMap::new();
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.loc.is_some() || cl.fixed || cl.dont_touch || !cl.attrs.is_empty() {
                keep.insert(cl.name.clone(), (cl.loc, cl.fixed, cl.dont_touch, cl.attrs.clone()));
            }
        }
        let ploc: HashMap<String, (f64, f64)> = nl.port_ids().into_iter().filter_map(|p| nl.ports[p].loc.map(|l| (nl.ports[p].name.clone(), l))).collect();
        let frozen = nl.frozen_hier.clone();
        let mut args = self.last_elab.clone();
        args.push("-keep_reference".into());
        self.reelab = true;
        let r = self.c_elaborate(&args);
        self.reelab = false;
        r?;
        let nl = self.nl.as_mut().unwrap();
        for c in nl.cell_ids() {
            let nm = nl.cell(c).name.clone();
            if let Some((l, f, dt, at)) = keep.get(&nm) {
                let cl = nl.cell_mut(c);
                cl.loc = *l;
                cl.fixed = *f;
                cl.dont_touch |= *dt;
                for a in at {
                    if !cl.attrs.contains(a) {
                        cl.attrs.push(a.clone());
                    }
                }
            }
        }
        for p in nl.port_ids() {
            if let Some(l) = ploc.get(&nl.ports[p].name) {
                nl.ports[p].loc = Some(*l);
            }
        }
        nl.frozen_hier = frozen;
        Ok(())
    }

    /// ungroup instances: dissolve their boundary pins and drop them from the written hierarchy
    fn do_ungroup(&mut self, insts: &[String], simple: bool) -> usize {
        let Some(nl) = self.nl.as_mut() else { return 0 };
        let set: HashSet<String> = insts.iter().filter(|i| !nl.ungrouped.contains(*i)).cloned().collect();
        if set.is_empty() {
            return 0;
        }
        nl.dissolve_hports(&|i| set.contains(i));
        for i in &set {
            nl.ungrouped.insert(i.clone());
            self.ungrouped.insert(i.clone());
            if simple {
                nl.simple_names.insert(i.clone());
                self.simple_names.insert(i.clone());
            }
        }
        set.len()
    }

    /// instance list for ungroup-style commands: explicit cells, -all (top-level children), -flatten (with descendants)
    fn ungroup_targets(&self, pats: &[String], all: bool, flatten: bool, start_level: usize) -> Vec<String> {
        let Some(nl) = self.nl.as_ref() else { return vec![] };
        let insts: Vec<String> = nl.hier.iter().map(|(i, _)| i.clone()).collect();
        let level = |i: &str| i.matches('/').count() + 1;
        let mut out: Vec<String> = vec![];
        if all {
            for i in &insts {
                if (flatten && level(i) >= start_level.max(1)) || (!flatten && level(i) == start_level.max(1)) {
                    out.push(i.clone());
                }
            }
        } else {
            for p in pats {
                for i in &insts {
                    if glob(p, i) || (flatten && i.starts_with(&format!("{}/", p))) {
                        out.push(i.clone());
                    }
                }
            }
        }
        out.sort();
        out.dedup();
        out
    }

    /// compile-time auto-ungroup (area: small hierarchies; delay: hierarchies on violating paths) + set_ungroup marks
    fn auto_ungroup(&mut self, mode: &str) -> usize {
        let crit_names: Vec<String> = if mode == "delay" {
            self.with_env(|nl, env| {
                let a = env.analyze(nl, 50);
                a.crit.iter().flatten().filter_map(|p| if let PinRef::Cell(c, _) = p { Some(nl.cell(*c).name.clone()) } else { None }).collect::<Vec<_>>()
            }).unwrap_or_default()
        } else {
            vec![]
        };
        let Some(nl) = self.nl.as_ref() else { return 0 };
        let maxc = self.appu("compile.flow.autoungroup.max_cells");
        let mut targets: Vec<String> = vec![];
        let kept: Vec<String> = nl.kept_hier().into_iter().map(|x| x.0).collect();
        let marked = |i: &str| -> Option<bool> {
            let mut v = None;
            for (p, b) in &self.ungroup_marks {
                if glob(p, i) {
                    v = Some(*b);
                }
            }
            v
        };
        let frozen = |i: &str| nl.frozen_hier.iter().any(|f| i == f || i.starts_with(&format!("{}/", f)));
        let parts: HashSet<String> = self.partitions.iter().map(|p| p.inst.clone()).collect();
        // leaf cells per instance (direct + below)
        let mut cnt: HashMap<String, usize> = HashMap::new();
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.is_hport() || matches!(cl.kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) {
                continue;
            }
            for i in &kept {
                if cl.name.starts_with(&format!("{}/", i)) {
                    *cnt.entry(i.clone()).or_insert(0) += 1;
                }
            }
        }
        let mut crit: HashSet<String> = HashSet::new();
        for n in &crit_names {
            for i in &kept {
                if n.starts_with(&format!("{}/", i)) {
                    crit.insert(i.clone());
                }
            }
        }
        for i in &kept {
            if frozen(i) || parts.contains(i) || nl.frozen_hier.contains(i) {
                continue;
            }
            match marked(i) {
                Some(true) => targets.push(i.clone()),
                Some(false) => {}
                None if mode == "area" && cnt.get(i).copied().unwrap_or(0) <= maxc => targets.push(i.clone()),
                None if mode == "delay" && crit.contains(i) => targets.push(i.clone()),
                None => {}
            }
        }
        let n = self.do_ungroup(&targets, false);
        if n > 0 {
            crate::info!("OPT-790", "Auto-ungroup ({}): {} hierarch{} ungrouped: {}", mode, n, if n == 1 { "y" } else { "ies" }, abbrev_list(&targets, 6));
        }
        n
    }


    fn c_report_hierarchy_ext(&mut self) -> R {
        let nl = self.nl()?;
        let hp = nl.hport_count();
        let mut cnt: HashMap<&str, usize> = HashMap::new();
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.is_hport() || matches!(cl.kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) {
                continue;
            }
            for (i, _) in &nl.hier {
                if cl.name.starts_with(i.as_str()) && cl.name.as_bytes().get(i.len()) == Some(&b'/') {
                    *cnt.entry(i.as_str()).or_insert(0) += 1;
                }
            }
        }
        crate::out!("\nHierarchy of '{}'  (boundary: opt = optimized across, kept = boundary pins preserved)", nl.name);
        crate::out!("  {:<46} {:<22} {:>7} {:<14} {}", "Instance", "Module", "Cells", "Boundary", "Status");
        for (i, m) in &nl.hier {
            let depth = i.matches('/').count();
            let name = format!("{}{}", "  ".repeat(depth), i.rsplit('/').next().unwrap_or(i));
            let b = match hp.get(i) {
                Some(n) => format!("kept ({} pins)", n),
                None => "opt".into(),
            };
            let st = if nl.ungrouped.contains(i) { "ungrouped" } else { "hierarchical" };
            crate::out!("  {:<46} {:<22} {:>7} {:<14} {}", name, m, cnt.get(i.as_str()).copied().unwrap_or(0), b, st);
        }
        Ok(nl.kept_hier().len().to_string())
    }

    fn c_uniquify(&mut self) -> R {
        if self.multi_inst.is_empty() {
            crate::info!("OPT-1100", "All designs are already unique");
            return ok();
        }
        let Some(nl) = self.nl.as_mut() else { return err("no design") };
        let mut n = 0;
        for (m, insts) in &self.multi_inst {
            for (k, i) in insts.iter().enumerate() {
                if let Some(h) = nl.hier.iter_mut().find(|(x, _)| x == i) {
                    let base = m.split('#').next().unwrap_or(m);
                    h.1 = format!("{}_{}", base, k);
                    n += 1;
                }
            }
            crate::info!("OPT-1101", "Uniquified {} instances of '{}'", insts.len(), m);
        }
        self.multi_inst.clear();
        self.uniquified = true;
        Ok(n.to_string())
    }

    fn c_read_def(&mut self, a: &[String]) -> R {
        let f = a.iter().find(|x| !x.starts_with('-')).cloned().ok_or_else(|| Flow::Err("read_def: file required".into()))?;
        let nl = self.nlm()?;
        let mut fp = crate::phys::read_def(&f, nl).map_err(e2f)?;
        if let Some(l) = crate::fplan::lef_route_layers(&self.lef_layers) { fp.layers = l; }
        if let Some(old) = &self.fp {
            fp.merge_user(old);
            crate::info!("FP-010", "Re-read DEF: kept {} user floorplan object(s) created by commands", old.pblk.iter().filter(|x| x.source != "def").count() + old.rblk.iter().filter(|x| x.source != "def").count() + old.bounds.iter().filter(|x| x.source != "def").count() + old.guides.len() + old.feeds.len() + old.bundles.len() + old.pin_cons.len());
        }
        crate::info!("FP-011", "DEF floorplan objects: {} placement blockage(s), {} routing blockage(s), {} region/group bound(s)", fp.pblk.len(), fp.rblk.len(), fp.bounds.len());
        crate::info!("DEF-100", "Read DEF '{}': die ({:.1},{:.1})-({:.1},{:.1}) um, {} rows, {} placed components ({} fixed), {} pins, {} unmatched component(s)", f, fp.die.0, fp.die.1, fp.die.2, fp.die.3, fp.rows, fp.placed, fp.fixed, fp.pins, fp.unmatched.len());
        if !fp.special.is_empty() || !fp.bumps.is_empty() {
            let mut k: std::collections::BTreeMap<&str, usize> = std::collections::BTreeMap::new();
            for s in &fp.special { *k.entry(s.kind.as_str()).or_default() += 1; }
            crate::info!("DEF-101", "DEF special wiring: {} shape(s) [{}], {} bump(s) ({} assigned)", fp.special.len(), k.iter().map(|(a, b)| format!("{} {}", a, b)).collect::<Vec<_>>().join(", "), fp.bumps.len(), fp.bumps.iter().filter(|b| !b.net.is_empty()).count());
        }
        for u in fp.unmatched.iter().take(5) {
            crate::warn!("DEF-110", "DEF component '{}' not found in design (will be ignored)", u);
        }
        self.fp = Some(fp);
        self.auto_pins();
        ok()
    }

    fn c_load_upf(&mut self, a: &[String]) -> R {
        let x = args(a, &["-scope", "-version"]);
        let f = x.pos.first().cloned().ok_or_else(|| Flow::Err("load_upf: file required".into()))?;
        let s = std::fs::read_to_string(&f).map_err(|e| Flow::Err(format!("cannot read {}: {}", f, e)))?;
        crate::info!("UPF-010", "Loading UPF '{}'", f);
        self.upf.files.push(f.clone());
        self.eval(&s)?;
        crate::info!("UPF-011", "UPF loaded: {} domain(s), {} isolation, {} level-shifter, {} retention strategies, {} power switch(es), {} PST(s)", self.upf.domains.len(), self.upf.iso.len(), self.upf.ls.len(), self.upf.ret.len(), self.upf.switches.len(), self.upf.psts.len());
        ok()
    }
    fn c_commit_upf(&mut self) -> R {
        if !self.upf.loaded {
            return err("No UPF loaded (UPF-002)");
        }
        let tl = self.target_idx();
        let Some(nl) = self.nl.as_mut() else { return err("no design") };
        if !nl.mapped {
            crate::info!("UPF-400", "commit_upf deferred until mapping (compile_fusion logic_opto)");
            return ok();
        }
        let (i, l, r) = self.upf.commit(nl, &self.libs[tl]).map_err(e2f)?;
        crate::info!("UPF-401", "commit_upf: inserted {} isolation cell(s), {} level shifter(s), mapped {} retention register(s); {} always-on net(s)", i, l, r, self.upf.aon_nets.len());
        Ok(format!("{} {} {}", i, l, r))
    }

    fn c_create_scenario(&mut self, a: &[String]) -> R {
        let x = args(a, &["-name", "-mode", "-corner"]);
        let mode = x.get("-mode").cloned().unwrap_or(self.modes[self.cur_mode].name.clone());
        let corner = x.get("-corner").cloned().unwrap_or(self.corners[self.cur_corner].name.clone());
        let name = x.get("-name").cloned().or(x.pos.first().cloned()).unwrap_or(format!("{}_{}", mode, corner));
        if !self.modes.iter().any(|m| m.name == mode) {
            return err(format!("Mode '{}' does not exist (create_mode first)", mode));
        }
        if !self.corners.iter().any(|c| c.name == corner) {
            return err(format!("Corner '{}' does not exist (create_corner first)", corner));
        }
        if self.implicit.2 {
            self.implicit.2 = false;
            self.scens.retain(|s| s.name != "default");
        }
        if !self.scens.iter().any(|s| s.name == name) {
            self.scens.push(Scenario { name: name.clone(), mode: mode.clone(), corner: corner.clone(), active: true, setup: true, hold: true, leakage: true, dynamic: true, max_tran: true, max_cap: true });
        }
        self.cur_mode = self.modes.iter().position(|m| m.name == mode).unwrap();
        self.cur_corner = self.corners.iter().position(|c| c.name == corner).unwrap();
        crate::info!("MV-001", "Created scenario '{}' (mode {}, corner {})", name, mode, corner);
        Ok(name)
    }

    fn c_derate(&mut self, a: &[String]) -> R {
        let x = args(a, &["-corners", "-corner"]);
        let v = x.pos.first().map(|s| fnum(s)).transpose()?.unwrap_or(1.0);
        let cs = x.get("-corners").or(x.get("-corner")).map(|s| split_list(s)).unwrap_or(vec![self.corners[self.cur_corner].name.clone()]);
        let late = x.has("-late") || !x.has("-early");
        let early = x.has("-early") || !x.has("-late");
        let cell = x.has("-cell_delay") || !x.has("-net_delay");
        let net = x.has("-net_delay") || !x.has("-cell_delay");
        // -clock / -data: which path type (default both)
        let clock = x.has("-clock") || !x.has("-data");
        let data = x.has("-data") || !x.has("-clock");
        for c in cs {
            let i = self.corner_idx(&c, true);
            let cc = &mut self.corners[i];
            // keep the clock values when only the data derate changes
            if data && !clock {
                if cc.late_cell_clk.is_none() { cc.late_cell_clk = Some(cc.late_cell); }
                if cc.early_cell_clk.is_none() { cc.early_cell_clk = Some(cc.early_cell); }
                if cc.late_net_clk.is_none() { cc.late_net_clk = Some(cc.late_net); }
                if cc.early_net_clk.is_none() { cc.early_net_clk = Some(cc.early_net); }
            }
            let set = |slot: &mut f64, clk: &mut Option<f64>, on: bool| {
                if !on {
                    return;
                }
                if data {
                    *slot = v;
                }
                if clock {
                    *clk = Some(v);
                }
            };
            set(&mut cc.late_cell, &mut cc.late_cell_clk, late && cell);
            set(&mut cc.early_cell, &mut cc.early_cell_clk, early && cell);
            set(&mut cc.late_net, &mut cc.late_net_clk, late && net);
            set(&mut cc.early_net, &mut cc.early_net_clk, early && net);
        }
        self.rawsdc("set_timing_derate", a);
        ok()
    }

    /// Synopsys AOCV / POCV (ocvm) side files
    fn c_read_ocvm(&mut self, a: &[String]) -> R {
        let x = args(a, &["-corners", "-corner"]);
        let Some(f) = x.pos.first() else { return Err(Flow::Err("read_aocvm: file name required".into())) };
        let txt = std::fs::read_to_string(f).map_err(|e| Flow::Err(format!("read_aocvm: {}: {}", f, e)))?;
        let mut kv: HashMap<String, String> = HashMap::new();
        let mut naocv = 0;
        let mut npocv = 0;
        let mut pocv_file = false;
        let lines: Vec<String> = {
            // join continuation lines (trailing backslash) and table rows that follow "table:"
            let mut v: Vec<String> = vec![];
            for l in txt.lines() {
                let l = l.split('#').next().unwrap_or("").trim().to_string();
                if l.is_empty() {
                    continue;
                }
                if !l.contains(':') && !v.is_empty() {
                    let last = v.last_mut().unwrap();
                    last.push(' ');
                    last.push_str(l.trim_end_matches('\\'));
                } else {
                    v.push(l.trim_end_matches('\\').to_string());
                }
            }
            v
        };
        let has = |kv: &HashMap<String, String>, k: &str, w: &str| kv.get(k).map(|s| s.split_whitespace().any(|t| t == w)).unwrap_or(true);
        for l in lines {
            let Some((k, v)) = l.split_once(':') else { continue };
            let (k, v) = (k.trim().to_string(), v.trim().to_string());
            if k == "ocvm_type" && v.contains("pocvm") {
                pocv_file = true;
            }
            if k == "table" || k == "coefficient" {
                let spec = kv.get("object_spec").cloned().unwrap_or("*".into());
                if k == "coefficient" || pocv_file {
                    let c: f64 = v.split_whitespace().next().and_then(|t| t.parse().ok()).ok_or_else(|| Flow::Err(format!("read_ocvm: bad coefficient '{}'", v)))?;
                    if kv.get("delay_type").map(|d| d.contains("net")).unwrap_or(false) {
                        self.ocv.pocv_net = c;
                    } else {
                        self.ocv.pocv.push((spec, c));
                    }
                    npocv += 1;
                } else {
                    let nums = |key: &str| -> Vec<f64> { kv.get(key).map(|s| s.split_whitespace().filter_map(|t| t.parse().ok()).collect()).unwrap_or_default() };
                    let depths = { let d = nums("depth"); if d.is_empty() { vec![1.0] } else { d } };
                    let dists = { let d = nums("distance"); if d.is_empty() { vec![0.0] } else { d } };
                    let vals: Vec<f64> = v.split_whitespace().filter_map(|t| t.parse().ok()).collect();
                    if vals.len() != depths.len() * dists.len() {
                        return Err(Flow::Err(format!("read_aocvm: table for '{}' has {} values, expected {} (depth {} x distance {})", spec, vals.len(), depths.len() * dists.len(), depths.len(), dists.len())));
                    }
                    let tbl: Vec<Vec<f64>> = vals.chunks(depths.len()).map(|c| c.to_vec()).collect();
                    self.ocv.aocv.push(crate::sta::AocvTable { pattern: spec, late: has(&kv, "derate_type", "late"), early: has(&kv, "derate_type", "early"), clock: has(&kv, "path_type", "clock"), data: has(&kv, "path_type", "data"), depths, dists, tbl });
                    naocv += 1;
                }
                continue;
            }
            kv.insert(k, v);
        }
        if naocv > 0 {
            self.app.insert("time.aocvm_enable_analysis".into(), "true".into());
        }
        if npocv > 0 {
            self.app.insert("time.pocvm_enable_analysis".into(), "true".into());
        }
        crate::info!("OCV-100", "Read '{}': {} AOCV table(s), {} POCV coefficient(s){}", f, naocv, npocv, if naocv + npocv > 0 { " (analysis enabled)" } else { "" });
        Ok((naocv + npocv).to_string())
    }

    fn c_report_ocvm(&mut self, a: &[String]) -> R {
        let x = args(a, &["-type"]);
        let ty = x.get("-type").cloned().unwrap_or_default();
        crate::out!("\n****************************************\nReport : ocvm\n****************************************");
        crate::out!("  AOCV analysis : {}   ({} table(s))", self.appb("time.aocvm_enable_analysis"), self.ocv.aocv.len());
        crate::out!("  POCV analysis : {}   (corner sigma {}, {} coefficient(s), default {}, net {})", self.appb("time.pocvm_enable_analysis"), self.appf("time.pocvm_corner_sigma"), self.ocv.pocv.len(), self.appf("time.pocvm_default_coefficient"), self.ocv.pocv_net);
        crate::out!("  CRPR          : {}", self.appb("time.remove_clock_reconvergence_pessimism"));
        if ty != "pocvm" {
            for t in &self.ocv.aocv {
                crate::out!("  AOCV {:<18} {}{} {}{}  depth {:?}  distance {:?}", t.pattern, if t.late { "late " } else { "" }, if t.early { "early" } else { "" }, if t.clock { "clock " } else { "" }, if t.data { "data" } else { "" }, t.depths, t.dists);
            }
            if let Some(si) = (0..self.scens.len()).find(|&i| self.scens[i].active && self.scens[i].setup) {
                if self.nl.is_some() {
                    let r = self.with_timing(si, |t| {
                        let n = t.aocv_der.len();
                        let dmax = t.aocv_depth.values().copied().max().unwrap_or(0);
                        let dmin = t.aocv_depth.values().copied().min().unwrap_or(0);
                        let (lo, hi) = t.aocv_der.values().fold((f64::MAX, f64::MIN), |a, f| (a.0.min(f[0]), a.1.max(f[0])));
                        (n, dmin, dmax, lo, hi)
                    });
                    if let Ok((n, dmin, dmax, lo, hi)) = r {
                        crate::out!("  Cells with AOCV derates: {}  (GBA depth {}..{}, late data derate {:.4}..{:.4})", n, dmin, dmax, if n > 0 { lo } else { 0.0 }, if n > 0 { hi } else { 0.0 });
                    }
                }
            }
        }
        if ty != "aocvm" {
            for (p, c) in &self.ocv.pocv {
                crate::out!("  POCV {:<18} coefficient {}", p, c);
            }
        }
        Ok(String::new())
    }

    fn c_create_clock(&mut self, a: &[String]) -> R {
        let x = args(a, &["-name", "-period", "-waveform", "-comment"]);
        let period = fnum(x.get("-period").ok_or_else(|| Flow::Err("create_clock: -period required (CMD-004)".into()))?)?;
        let wf: Vec<f64> = x.get("-waveform").map(|w| split_list(w).iter().filter_map(|s| s.parse().ok()).collect()).unwrap_or(vec![0.0, period / 2.0]);
        let srcs: Vec<Obj> = x.pos.iter().flat_map(|p| self.objs(p, "any")).collect();
        let name = x.get("-name").cloned().or(srcs.first().map(|o| o.name().to_string())).ok_or_else(|| Flow::Err("create_clock: -name or source required".into()))?;
        if period <= 0.0 {
            return err("create_clock: period must be positive");
        }
        let c = Clock { name: name.clone(), period, rise: wf[0], fall: *wf.get(1).unwrap_or(&(period / 2.0)), sources: srcs.clone(), gen: None, propagated: false, src_lat: (0.0, 0.0), net_lat: (0.0, 0.0), unc_setup: 0.0, unc_hold: 0.0, transition: 0.0, max_tran: None };
        let cons = self.cons();
        if let Some(i) = cons.clock(&name) {
            cons.clocks[i] = c;
        } else {
            cons.clocks.push(c);
        }
        if srcs.is_empty() {
            crate::info!("SDC-010", "Created virtual clock '{}' (period {})", name, period);
        }
        self.rawsdc("create_clock", a);
        Ok(Obj::Clock(name).handle())
    }
    fn c_gen_clock(&mut self, a: &[String]) -> R {
        let x = args(a, &["-name", "-source", "-divide_by", "-multiply_by", "-edges", "-master_clock", "-duty_cycle", "-edge_shift"]);
        let tgt: Vec<Obj> = x.pos.iter().flat_map(|p| self.objs(p, "any")).collect();
        let src = x.get("-source").and_then(|s| self.objs(s, "any").into_iter().next()).ok_or_else(|| Flow::Err("create_generated_clock: -source required".into()))?;
        let name = x.get("-name").cloned().or(tgt.first().map(|o| o.name().to_string())).unwrap_or_default();
        let cons = &self.modes[self.cur_mode].sdc;
        let master = x.get("-master_clock").cloned().or_else(|| {
            cons.clocks.iter().find(|c| c.sources.iter().any(|s| s.name() == src.name())).map(|c| c.name.clone())
        }).or(cons.clocks.first().map(|c| c.name.clone())).ok_or_else(|| Flow::Err("create_generated_clock: cannot determine master clock".into()))?;
        let mp = cons.clocks.iter().find(|c| c.name == master).map(|c| c.period).unwrap_or(1.0);
        let div = x.num("-divide_by").unwrap_or(1.0);
        let mul = x.num("-multiply_by").unwrap_or(1.0);
        let edges = x.get("-edges").map(|e| split_list(e).iter().filter_map(|s| s.parse().ok()).collect());
        let p = mp * div / mul;
        let g = GenClock { master: master.clone(), source: src, divide: div, multiply: mul, invert: x.has("-invert"), edges };
        let c = Clock { name: name.clone(), period: p, rise: 0.0, fall: p / 2.0, sources: tgt, gen: Some(g), propagated: false, src_lat: (0.0, 0.0), net_lat: (0.0, 0.0), unc_setup: 0.0, unc_hold: 0.0, transition: 0.0, max_tran: None };
        self.cons().clocks.push(c);
        self.rawsdc("create_generated_clock", a);
        Ok(Obj::Clock(name).handle())
    }
    fn c_clock_attr(&mut self, name: &str, a: &[String]) -> R {
        let x = args(a, &["-from", "-to", "-rise_from", "-fall_from", "-rise_to", "-fall_to"]);
        let (val, rest): (f64, Vec<String>) = if name == "set_propagated_clock" { (0.0, x.pos.clone()) } else { (fnum(x.pos.first().map(|s| s.as_str()).unwrap_or("0"))?, x.pos[1.min(x.pos.len())..].to_vec()) };
        let mut clocks: Vec<String> = vec![];
        for r in &rest {
            for it in split_list(r) {
                match Obj::parse(&it) {
                    Some(Obj::Clock(c)) => clocks.push(c),
                    Some(o) => {
                        // pin/port object: clocks sourced there
                        let cs: Vec<String> = self.modes[self.cur_mode].sdc.clocks.iter().filter(|c| c.sources.iter().any(|s| s.name() == o.name())).map(|c| c.name.clone()).collect();
                        clocks.extend(cs);
                    }
                    None => clocks.extend(self.clocks_of(Some(&it))),
                }
            }
        }
        if let Some(t) = x.get("-to").or(x.get("-rise_to")).or(x.get("-fall_to")) {
            clocks.extend(self.clocks_of(Some(t)));
        }
        if clocks.is_empty() {
            if rest.is_empty() && x.get("-to").is_none() {
                clocks = self.clocks_of(None);
            } else {
                crate::warn!("SDC-020", "{}: no clocks matched", name);
            }
        }
        let setup = x.has("-setup") || !x.has("-hold");
        let hold = x.has("-hold") || !x.has("-setup");
        let src = x.has("-source");
        let mx = x.has("-max") || !x.has("-min");
        let mn = x.has("-min") || !x.has("-max");
        let cons = self.cons();
        for cn in clocks {
            let Some(i) = cons.clock(&cn) else { continue };
            let c = &mut cons.clocks[i];
            match name {
                "set_clock_uncertainty" => {
                    if setup {
                        c.unc_setup = val
                    }
                    if hold {
                        c.unc_hold = val
                    }
                }
                "set_clock_latency" => {
                    let l = if src { &mut c.src_lat } else { &mut c.net_lat };
                    if mx {
                        l.0 = val
                    }
                    if mn {
                        l.1 = val
                    }
                }
                "set_clock_transition" => c.transition = val,
                _ => c.propagated = true,
            }
        }
        self.rawsdc(name, a);
        ok()
    }
    fn c_io_delay(&mut self, input: bool, a: &[String]) -> R {
        let x = args(a, &["-clock", "-reference_pin"]);
        let v = fnum(x.pos.first().map(|s| s.as_str()).unwrap_or("0"))?;
        let clock = x.get("-clock").map(|c| Obj::parse(c).map(|o| o.name().to_string()).unwrap_or(c.clone()));
        if let Some(c) = &clock {
            if self.modes[self.cur_mode].sdc.clock(c).is_none() {
                crate::error!("SDC-030", "Clock '{}' not defined for set_{}_delay", c, if input { "input" } else { "output" });
            }
        }
        let objs: Vec<Obj> = x.pos[1..].iter().flat_map(|p| self.objs(p, "port")).collect();
        if objs.is_empty() {
            crate::warn!("SDC-031", "set_{}_delay: no objects", if input { "input" } else { "output" });
        }
        let add = x.has("-add_delay");
        let (mx, mn) = (x.has("-max") || !x.has("-min"), x.has("-min") || !x.has("-max"));
        let cf = x.has("-clock_fall");
        let cons = self.cons();
        for o in objs {
            if let Some(e) = cons.io.iter_mut().find(|e| e.is_input == input && e.obj.name() == o.name() && e.clock == clock && e.clock_fall == cf) {
                if mx {
                    e.max = Some(v)
                }
                if mn {
                    e.min = Some(v)
                }
                continue;
            }
            if !add {
                cons.io.retain(|e| !(e.is_input == input && e.obj.name() == o.name()));
            }
            cons.io.push(IoDelay { obj: o, clock: clock.clone(), clock_fall: cf, max: if mx { Some(v) } else { None }, min: if mn { Some(v) } else { None }, is_input: input });
        }
        self.rawsdc(if input { "set_input_delay" } else { "set_output_delay" }, a);
        ok()
    }
    fn c_exception(&mut self, name: &str, a: &[String]) -> R {
        let x = args(a, &["-from", "-to", "-through", "-rise_from", "-fall_from", "-rise_to", "-fall_to", "-rise_through", "-fall_through", "-comment"]);
        let mut through = vec![];
        let mut i = 0;
        while i < a.len() {
            if a[i].ends_with("through") && i + 1 < a.len() {
                through.extend(self.objs(&a[i + 1], "any"));
                i += 2;
                continue;
            }
            i += 1;
        }
        let from = x.get("-from").or(x.get("-rise_from")).or(x.get("-fall_from")).map(|s| self.objs(s, "clock_or_any")).unwrap_or_default();
        let to = x.get("-to").or(x.get("-rise_to")).or(x.get("-fall_to")).map(|s| self.objs(s, "clock_or_any")).unwrap_or_default();
        let setup = x.has("-setup") || !x.has("-hold");
        let hold = x.has("-hold") || !x.has("-setup");
        let kind = match name {
            "set_false_path" => ExKind::False,
            // SDC: a setup multicycle counts capture-clock cycles (-end) unless -start is given; a
            // hold multicycle counts launch-clock cycles (-start) unless -end is given
            "set_multicycle_path" => ExKind::Multicycle(fnum(x.pos.first().map(|s| s.as_str()).unwrap_or("1"))?, if x.has("-hold") { !x.has("-end") } else { x.has("-start") }),
            "set_max_delay" => ExKind::MaxDelay(fnum(x.pos.first().map(|s| s.as_str()).unwrap_or("0"))?),
            _ => ExKind::MinDelay(fnum(x.pos.first().map(|s| s.as_str()).unwrap_or("0"))?),
        };
        let (setup, hold) = match kind {
            ExKind::MaxDelay(_) => (true, false),
            ExKind::MinDelay(_) => (false, true),
            ExKind::Multicycle(..) => (setup && !x.has("-hold"), x.has("-hold")),
            _ => (setup, hold),
        };
        if name != "set_multicycle_path" && (x.has("-start") || x.has("-end")) {
            crate::warn!("SDC-041", "{}: -start/-end apply to set_multicycle_path only; ignored here", name);
        }
        if name == "set_multicycle_path" && x.has("-start") && x.has("-end") {
            return err("set_multicycle_path: -start and -end are mutually exclusive (SDC-042)");
        }
        if from.is_empty() && to.is_empty() && through.is_empty() {
            crate::warn!("SDC-040", "{}: no -from/-to/-through objects; ignored", name);
            return ok();
        }
        self.cons().exceptions.push(Exception { kind, from, through, to, setup, hold, rise_from: None });
        self.rawsdc(name, a);
        ok()
    }
    fn c_drv_limit(&mut self, name: &str, a: &[String]) -> R {
        let x = args(a, &[]);
        let v = fnum(x.pos.first().map(|s| s.as_str()).unwrap_or("0"))?;
        let design = self.nl.as_ref().map(|n| n.name.clone()).unwrap_or_default();
        let targets: Vec<String> = x.pos[1..].iter().flat_map(|p| split_list(p)).collect();
        let global = targets.is_empty() || targets.iter().any(|t| *t == design || t == "[current_design]" || t.starts_with("design::"));
        let clock_only = x.has("-clock_path");
        let cons = self.cons();
        if global && !clock_only {
            match name {
                "set_max_transition" => cons.max_tran = Some(v),
                "set_max_fanout" => cons.max_fanout = Some(v),
                _ => cons.max_cap = Some(v),
            }
        }
        let tg2: Vec<String> = targets.into_iter().filter(|t| *t != design).collect();
        for t in tg2 {
            let o = Obj::parse(&t).unwrap_or(Obj::Net(t.clone()));
            match (&o, name) {
                (Obj::Clock(c), "set_max_transition") => {
                    if let Some(i) = self.cons().clock(c) {
                        self.cons().clocks[i].max_tran = Some(v);
                    }
                }
                (_, "set_max_transition") => self.cons().obj_max_tran.push((o, v)),
                (_, "set_max_fanout") => self.cons().obj_max_fanout.push((o, v)),
                _ => self.cons().obj_max_cap.push((o, v)),
            }
        }
        self.rawsdc(name, a);
        ok()
    }

    fn c_get(&mut self, name: &str, a: &[String]) -> R {
        let x = args(a, &["-filter", "-of_objects", "-of"]);
        let hier = x.has("-hierarchical") || x.has("-hier");
        let regexp = x.has("-regexp");
        let nocase = x.has("-nocase");
        // regular expressions keep their backslashes: split on whitespace only (no Tcl list parsing)
        let mut pats: Vec<String> = if x.pos.is_empty() {
            vec![if regexp { ".*".into() } else { "*".into() }]
        } else if regexp {
            x.pos.iter().flat_map(|p| p.split_whitespace().map(|t| t.to_string()).collect::<Vec<_>>()).collect()
        } else {
            x.pos.iter().flat_map(|p| split_list(p)).collect()
        };
        // current_instance scope: patterns are relative to it
        let scope = if matches!(name, "get_cells" | "get_nets" | "get_pins") && !self.cur_inst.is_empty() { Some(self.cur_inst.clone()) } else { None };
        if let Some(sc) = &scope {
            let esc_sc: String = if regexp { sc.chars().flat_map(|c| if "[](){}.*+?^$|\\".contains(c) { vec!['\\', c] } else { vec![c] }).collect() } else { sc.clone() };
            pats = pats.into_iter().map(|p| if let Some(abs) = p.strip_prefix('/') { abs.to_string() } else { format!("{}/{}", esc_sc, p) }).collect();
        }
        let rx_cache: std::cell::RefCell<HashMap<String, Option<crate::regex::Regex>>> = Default::default();
        let gm = |p: &str, t: &str| -> bool {
            let (p2, t2) = if nocase { (p.to_lowercase(), t.to_lowercase()) } else { (p.to_string(), t.to_string()) };
            if regexp {
                let mut c = rx_cache.borrow_mut();
                let r = c.entry(p2.clone()).or_insert_with(|| crate::regex::Regex::new(&p2).ok());
                r.as_ref().map(|r| r.full_match(&t2)).unwrap_or(false)
            } else {
                glob(&p2, &t2)
            }
        };
        if regexp {
            for p in &pats {
                if let Err(e) = crate::regex::Regex::new(p) {
                    return Err(Flow::Err(format!("{}: bad regular expression '{}': {}", name, p, e)));
                }
            }
        }
        let mut out: Vec<String> = vec![];
        let quiet = x.has("-quiet");
        if name == "get_clocks" {
            for p in &pats {
                let m: Vec<String> = self.modes[self.cur_mode].sdc.clocks.iter().filter(|c| glob(p, &c.name)).map(|c| Obj::Clock(c.name.clone()).handle()).collect();
                if m.is_empty() && !quiet {
                    crate::warn!("SEL-004", "Nothing matched for clock '{}'", p);
                }
                out.extend(m);
            }
            return Ok(to_list(&out));
        }
        if name == "get_lib_cells" || name == "get_libs" || name == "get_lib_pins" {
            for p in &pats {
                let (lp, cp) = p.split_once('/').map(|(a, b)| (a.to_string(), b.to_string())).unwrap_or(("*".into(), p.clone()));
                for l in &self.libs {
                    if !glob(&lp, &l.name) {
                        continue;
                    }
                    if name == "get_libs" {
                        if glob(p, &l.name) {
                            out.push(l.name.clone());
                        }
                        continue;
                    }
                    for c in &l.cell_order {
                        if glob(&cp, c) {
                            out.push(Obj::LibCell(format!("{}/{}", l.name, c)).handle());
                        }
                    }
                }
            }
            out.dedup();
            return Ok(to_list(&out));
        }
        if name == "get_designs" {
            return Ok(to_list(&self.hdl.order.iter().filter(|n| pats.iter().any(|p| glob(p, n))).cloned().collect::<Vec<_>>()));
        }
        let nl = self.nl()?;
        // -of_objects
        if let Some(of) = x.get("-of_objects").or(x.get("-of")) {
            for it in split_list(of) {
                let o = Obj::parse(&it);
                match (name, o) {
                    ("get_pins", Some(Obj::Cell(c))) => {
                        if let Some(ci) = nl.cell_by_name(&c) {
                            for p in &nl.cell(ci).pins {
                                out.push(Obj::Pin(format!("{}/{}", c, p.name)).handle());
                            }
                        }
                    }
                    ("get_pins", Some(Obj::Net(n))) | ("get_cells", Some(Obj::Net(n))) | ("get_ports", Some(Obj::Net(n))) => {
                        if let Some(ni) = nl.net_by_name(&n) {
                            for pr in &nl.net(ni).conns {
                                match (name, pr) {
                                    ("get_pins", PinRef::Cell(..)) => out.push(Obj::Pin(nl.pin_name(*pr)).handle()),
                                    ("get_cells", PinRef::Cell(c, _)) => out.push(Obj::Cell(nl.cell(*c).name.clone()).handle()),
                                    ("get_ports", PinRef::Port(p)) => out.push(Obj::Port(nl.ports[*p].name.clone()).handle()),
                                    _ => {}
                                }
                            }
                        }
                    }
                    ("get_nets", Some(Obj::Pin(p))) | ("get_nets", Some(Obj::Port(p))) => {
                        if let Some(n) = nl.find_pin(&p).and_then(|pr| nl.pin_net(pr)) {
                            out.push(Obj::Net(nl.net(n).name.clone()).handle());
                        }
                    }
                    ("get_cells", Some(Obj::Pin(p))) => {
                        if let Some(i) = p.rfind('/') {
                            out.push(Obj::Cell(p[..i].to_string()).handle());
                        }
                    }
                    _ => {}
                }
            }
            out.dedup();
            let out = self.filter(&out, x.get("-filter").map(|s| s.as_str()).unwrap_or(""));
            return Ok(out);
        }
        for p in &pats {
            let before = out.len();
            match name {
                "get_ports" => {
                    if regexp || nocase {
                        for q in nl.port_ids() {
                            let n = &nl.ports[q].name;
                            let base = n.split('[').next().unwrap_or(n);
                            if gm(p, n) || (gm(p, base) && n.contains('[')) {
                                out.push(Obj::Port(n.clone()).handle());
                            }
                        }
                    } else {
                        out.extend(self.ports_matching(p).into_iter().map(|n| Obj::Port(n).handle()))
                    }
                }
                "get_cells" => {
                    // without -hierarchical a pattern is matched level by level (wildcards do not cross '/'),
                    // and hierarchical instances at that level are returned too (Fusion Compiler semantics)
                    let seg_match = |pat: &str, name: &str| -> bool {
                        if regexp {
                            return gm(pat, name);
                        }
                        let ps: Vec<&str> = pat.split('/').collect();
                        let ns: Vec<&str> = name.split('/').collect();
                        ps.len() == ns.len() && ps.iter().zip(ns.iter()).all(|(a, b)| gm(a, b))
                    };
                    for c in nl.cell_ids() {
                        let cn = &nl.cell(c).name;
                        if matches!(nl.cell(c).kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) || nl.cell(c).is_hport() {
                            continue;
                        }
                        let leaf = cn.rsplit('/').next().unwrap_or(cn);
                        if (hier && (gm(p, cn) || gm(p, leaf))) || (!hier && seg_match(p, cn)) {
                            out.push(Obj::Cell(cn.clone()).handle());
                        }
                    }
                    if !hier {
                        for (h, _) in &nl.hier {
                            if seg_match(p, h) && !out.iter().any(|o| Obj::parse(o).map(|x| x.name() == h).unwrap_or(false)) {
                                out.push(Obj::Cell(h.clone()).handle());
                            }
                        }
                    }
                    if out.len() == before {
                        // no leaf cell matched: try hierarchical instances (the netlist is flat, so
                        // hierarchy cells are the name prefixes of leaf cells)
                        let mut seen = std::collections::BTreeSet::new();
                        for c in nl.cell_ids() {
                            let cn = &nl.cell(c).name;
                            let mut end = 0;
                            while let Some(i) = cn[end..].find('/') {
                                end += i;
                                seen.insert(&cn[..end]);
                                end += 1;
                            }
                        }
                        for h in seen {
                            let leaf = h.rsplit('/').next().unwrap_or(h);
                            if gm(p, h) || (hier && gm(p, leaf)) {
                                out.push(Obj::Cell(h.to_string()).handle());
                            }
                        }
                    }
                }
                "get_nets" => {
                    for n in nl.net_ids() {
                        let nn = &nl.net(n).name;
                        let leaf = nn.rsplit('/').next().unwrap_or(nn);
                        if gm(p, nn) || (hier && gm(p, leaf)) {
                            out.push(Obj::Net(nn.clone()).handle());
                        }
                    }
                }
                "get_pins" => {
                    let (cp, pp) = p.rsplit_once('/').map(|(a, b)| (a.to_string(), b.to_string())).unwrap_or(("*".into(), p.clone()));
                    for c in nl.cell_ids() {
                        if let Some((inst, port)) = nl.hier_pin_of(c) {
                            // hierarchical pin, named inst/port
                            let leaf = inst.rsplit('/').next().unwrap_or(&inst);
                            if (gm(&cp, &inst) || (hier && gm(&cp, leaf))) && gm(&pp, &port) {
                                out.push(Obj::Pin(format!("{}/{}", inst, port)).handle());
                            }
                            continue;
                        }
                        let cn = &nl.cell(c).name;
                        let leaf = cn.rsplit('/').next().unwrap_or(cn);
                        if gm(&cp, cn) || (hier && gm(&cp, leaf)) {
                            for pin in &nl.cell(c).pins {
                                if gm(&pp, &pin.name) {
                                    out.push(Obj::Pin(format!("{}/{}", cn, pin.name)).handle());
                                }
                            }
                        }
                    }
                    if out.len() == before && nl.find_hier_pin(&cp, &pp).is_some() {
                        out.push(Obj::Pin(p.clone()).handle());
                    }
                    if out.len() == before {
                        // role-based (pre-map pin names like CK on generic flops)
                        if nl.cell_by_name(&cp).is_some() {
                            out.push(Obj::Pin(p.clone()).handle());
                        }
                    }
                }
                _ => {}
            }
            // a name that no longer exists after change_names resolves through the rename aliases
            if out.len() == before && !regexp {
                match name {
                    "get_cells" => {
                        if let Some(c) = nl.cell_by_name(p) {
                            out.push(Obj::Cell(nl.cell(c).name.clone()).handle());
                        }
                    }
                    "get_nets" => {
                        if let Some(n) = nl.net_by_name(p) {
                            out.push(Obj::Net(nl.net(n).name.clone()).handle());
                        }
                    }
                    "get_ports" => {
                        if let Some(q) = nl.port_by_name(p) {
                            out.push(Obj::Port(nl.ports[q].name.clone()).handle());
                        }
                    }
                    _ => {}
                }
            }
            if out.len() == before && !quiet {
                crate::warn!("SEL-005", "Nothing matched for {} '{}'", name.trim_start_matches("get_"), p);
            }
        }
        if let Some(sc) = &scope {
            let pre = format!("{}/", sc);
            out.retain(|h| Obj::parse(h).map(|o| o.name().starts_with(&pre)).unwrap_or(false));
        }
        let mut seen = HashSet::new();
        out.retain(|h| seen.insert(h.clone()));
        let out = self.filter_rx(&out, x.get("-filter").map(|s| s.as_str()).unwrap_or(""), regexp, nocase);
        Ok(out)
    }
    pub(crate) fn attr_pub(&self, h: &str, at: &str) -> Option<String> {
        self.attr(h, at)
    }
    fn attr(&self, h: &str, at: &str) -> Option<String> {
        if let Some(v) = self.path_attr(h, at) {
            return v;
        }
        if let Some(v) = self.pin_time_attr(h, at) {
            return v;
        }
        let o = Obj::parse(h)?;
        let nl = self.nl.as_ref()?;
        match (&o, at) {
            (_, "full_name") | (_, "name") => Some(if at == "name" { o.name().rsplit('/').next().unwrap_or(o.name()).to_string() } else { o.name().to_string() }),
            (Obj::Cell(c), "ref_name") => nl.cell_by_name(c).map(|ci| match &nl.cell(ci).kind {
                Kind::Lib(l) => l.clone(),
                Kind::BlackBox(m) => m.clone(),
                Kind::Gen(g) => format!("**{:?}**", g).to_uppercase(),
            }),
            (Obj::Cell(c), "is_sequential") => nl.cell_by_name(c).map(|ci| {
                let cell = nl.cell(ci);
                (matches!(cell.kind, Kind::Gen(GOp::Dff) | Kind::Gen(GOp::Latch)) || cell.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|x| x.is_seq()).unwrap_or(false)).to_string()
            }),
            (Obj::Cell(c), "is_black_box") => nl.cell_by_name(c).map(|ci| matches!(nl.cell(ci).kind, Kind::BlackBox(_)).to_string()),
            (Obj::Cell(c), "area") => nl.cell_by_name(c).map(|ci| nl.cell(ci).lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|x| x.area).unwrap_or(0.0).to_string()),
            (Obj::Cell(c), "location") => nl.cell_by_name(c).and_then(|ci| nl.cell(ci).loc).map(|(x, y)| format!("{} {}", x, y)),
            (Obj::Cell(c), "threshold_voltage_group") => nl.cell_by_name(c).and_then(|ci| nl.cell(ci).lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|x| x.vt.clone())),
            (Obj::Port(p), "direction") => nl.port_by_name(p).map(|i| match nl.ports[i].dir {
                Dir::In => "in".into(),
                Dir::Out => "out".into(),
                Dir::InOut => "inout".into(),
            }),
            (Obj::Pin(p), "direction") => nl.find_pin(p).map(|pr| if nl.is_driver(pr) { "out".into() } else { "in".into() }),
            (Obj::Pin(p), "net_name") | (Obj::Port(p), "net_name") => nl.find_pin(p).and_then(|pr| nl.pin_net(pr)).map(|n| nl.net(n).name.clone()),
            (Obj::Net(n), "fanout") => nl.net_by_name(n).map(|i| nl.loads(i).len().to_string()),
            (Obj::Clock(c), "period") => self.modes[self.cur_mode].sdc.clocks.iter().find(|x| &x.name == c).map(|x| x.period.to_string()),
            _ => None,
        }
    }
    fn c_get_attr(&mut self, a: &[String]) -> R {
        let x = args(a, &["-name", "-objects", "-scenario", "-scenarios", "-view"]);
        self.prop_scen.set(self.scen_opt(&x)?);
        let objs = x.get("-objects").cloned().or(x.pos.first().cloned()).unwrap_or_default();
        let at = x.get("-name").cloned().or(x.pos.get(1).cloned()).unwrap_or_default();
        let v: Vec<String> = split_list(&objs).iter().filter_map(|h| self.prop_of(h, &at)).collect();
        self.prop_scen.set(None);
        Ok(if v.len() == 1 { v[0].clone() } else { to_list(&v) })
    }
    fn filter(&self, items: &[String], expr: &str) -> String {
        self.filter_rx(items, expr, false, false)
    }
    /// -filter evaluation; with -regexp, =~ / !~ take regular expressions (whole-value match)
    fn filter_rx(&self, items: &[String], expr: &str, regexp: bool, nocase: bool) -> String {
        if expr.trim().is_empty() {
            return to_list(items);
        }
        // supports: attr == val, attr != val, attr =~ pattern, && combinations
        let conds: Vec<(String, String, String)> = expr
            .split("&&")
            .filter_map(|c| {
                let c = c.trim().trim_matches(|x| x == '(' || x == ')');
                for op in ["==", "!=", "=~", "!~", "<=", ">=", "<", ">"] {
                    if let Some((l, r)) = c.split_once(op) {
                        return Some((l.trim().to_string(), op.to_string(), r.trim().trim_matches('"').to_string()));
                    }
                }
                if c.starts_with('!') {
                    return Some((c[1..].trim().to_string(), "==".into(), "false".into()));
                }
                Some((c.trim().to_string(), "==".into(), "true".into()))
            })
            .collect();
        let v: Vec<String> = items
            .iter()
            .filter(|h| {
                conds.iter().all(|(at, op, val)| {
                    let a = self.attr(h, at).unwrap_or_default();
                    let (a, val) = if nocase { (a.to_lowercase(), val.to_lowercase()) } else { (a, val.clone()) };
                    let rm = |v: &str, t: &str| -> bool { crate::regex::Regex::new(v).map(|r| r.full_match(t)).unwrap_or(false) };
                    match op.as_str() {
                        "==" => a == val || (!regexp && glob(&val, &a)),
                        "!=" => a != val && (regexp || !glob(&val, &a)),
                        "=~" => if regexp { rm(&val, &a) } else { glob(&val, &a) },
                        "<" | "<=" | ">" | ">=" => match (a.parse::<f64>(), val.parse::<f64>()) {
                            (Ok(x), Ok(y)) => match op.as_str() { "<" => x < y, "<=" => x <= y, ">" => x > y, _ => x >= y },
                            _ => false,
                        },
                        _ => if regexp { !rm(&val, &a) } else { !glob(&val, &a) },
                    }
                })
            })
            .cloned()
            .collect();
        to_list(&v)
    }
    fn c_all_registers(&mut self, a: &[String]) -> R {
        let x = args(a, &["-clock"]);
        let nl = self.nl()?;
        let mut out = vec![];
        let want_clk = x.get("-clock").map(|c| self.clocks_of(Some(c)));
        let clk_reach: Option<HashSet<String>> = if want_clk.is_some() {
            let si = self.active("setup").first().copied().unwrap_or(0);
            let wc = want_clk.clone().unwrap();
            self.with_timing(si, |t| {
                let mut s = HashSet::new();
                for &ck in &t.clk_pins {
                    if t.ctags[ck as usize].iter().any(|c| wc.contains(&t.cons.clocks[c.clk as usize].name)) {
                        if let PinRef::Cell(c, _) = t.nodes[ck as usize] {
                            s.insert(nl.cell(c).name.clone());
                        }
                    }
                }
                s
            }).ok()
        } else {
            None
        };
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            let lc = cell.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l)));
            let seq = matches!(cell.kind, Kind::Gen(GOp::Dff) | Kind::Gen(GOp::Latch)) || lc.map(|x| x.seq.is_some()).unwrap_or(false);
            if !seq {
                continue;
            }
            if let Some(s) = &clk_reach {
                if !s.contains(&cell.name) {
                    continue;
                }
            }
            let is_latch = matches!(cell.kind, Kind::Gen(GOp::Latch)) || lc.and_then(|x| x.seq.as_ref()).map(|s| s.is_latch).unwrap_or(false);
            if x.has("-edge_triggered") && is_latch || x.has("-level_sensitive") && !is_latch {
                continue;
            }
            let pins_of = |pred: &dyn Fn(&str, Dir) -> bool| -> Vec<String> { cell.pins.iter().filter(|p| pred(&p.name, p.dir)).map(|p| Obj::Pin(format!("{}/{}", cell.name, p.name)).handle()).collect() };
            if x.has("-clock_pins") {
                out.extend(pins_of(&|n, _| {
                    lc.and_then(|l| l.pin(n)).map(|p| p.is_clock).unwrap_or(n == "CK" || n == "G")
                }));
            } else if x.has("-data_pins") {
                out.extend(pins_of(&|n, d| d == Dir::In && (n == "D" || lc.and_then(|l| l.pin(n)).map(|p| !p.is_clock && p.nextstate_type.as_deref() != Some("scan_enable")).unwrap_or(false)) && !n.starts_with('R') && !n.starts_with('S')));
            } else if x.has("-output_pins") {
                out.extend(pins_of(&|_, d| d == Dir::Out));
            } else {
                out.push(Obj::Cell(cell.name.clone()).handle());
            }
        }
        Ok(to_list(&out))
    }
    fn c_fan(&mut self, name: &str, a: &[String]) -> R {
        let x = args(a, &["-from", "-to", "-levels"]);
        let nl = self.nl()?;
        let start = x.get("-from").or(x.get("-to")).cloned().unwrap_or_default();
        let objs = self.objs(&start, "any");
        let lv = x.num("-levels").unwrap_or(1000.0) as usize;
        let mut seen: HashSet<String> = HashSet::new();
        let mut q: Vec<(NetId, usize)> = vec![];
        for o in &objs {
            if let Some(n) = nl.find_pin(o.name()).and_then(|pr| nl.pin_net(pr)).or(nl.net_by_name(o.name())) {
                q.push((n, 0));
            }
        }
        let fwd = name == "all_fanout";
        let mut out = vec![];
        while let Some((n, d)) = q.pop() {
            if d > lv {
                continue;
            }
            let pins = if fwd { nl.loads(n) } else { nl.drivers(n) };
            for pr in pins {
                let pn = nl.pin_name(pr);
                if !seen.insert(pn.clone()) {
                    continue;
                }
                out.push(match pr {
                    PinRef::Port(_) => Obj::Port(pn).handle(),
                    _ => Obj::Pin(pn).handle(),
                });
                if let PinRef::Cell(c, _) = pr {
                    let cell = nl.cell(c);
                    let seq = matches!(cell.kind, Kind::Gen(GOp::Dff)) || cell.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|x| x.is_seq()).unwrap_or(false);
                    if seq && !x.has("-trace_arcs") {
                        continue;
                    }
                    for p in &cell.pins {
                        if (fwd && p.dir == Dir::Out) || (!fwd && p.dir == Dir::In) {
                            if let Some(nn) = p.net {
                                q.push((nn, d + 1));
                            }
                        }
                    }
                }
            }
        }
        Ok(to_list(&out))
    }

    // ------------------------------------------------------------ compile flow
    fn c_compile(&mut self, name: &str, a: &[String]) -> R {
        let x = args(a, &["-from", "-to", "-map_effort", "-area_effort", "-auto_ungroup", "-start_level"]);
        if x.has("-no_boundary_optimization") {
            self.app.insert("compile.flow.boundary_optimization".into(), "false".into());
        } else if x.has("-boundary_optimization") {
            self.app.insert("compile.flow.boundary_optimization".into(), "true".into());
        }
        const STAGES: &[&str] = &["initial_map", "logic_opto", "initial_place", "initial_drc", "initial_opto", "final_place", "final_opto"];
        if self.libs.is_empty() {
            return err("No technology libraries loaded (OPT-001)");
        }
        if self.nl.is_none() {
            return err("No design to compile; run elaborate (UID-109)");
        }
        let from = x.get("-from").cloned().unwrap_or_else(|| if self.nl.as_ref().unwrap().mapped { "logic_opto".into() } else { "initial_map".into() });
        let to = x.get("-to").cloned().unwrap_or("final_opto".into());
        let (Some(fi), Some(ti)) = (STAGES.iter().position(|s| *s == from), STAGES.iter().position(|s| *s == to)) else { return err(format!("{}: unknown stage (valid: {})", name, STAGES.join(" "))) };
        if x.has("-check_only") {
            return self.c_check_design("check_design", &[]);
        }
        let physical = self.fp.is_some() || name == "place_opt";
        // hierarchy handling before optimization starts
        self.sync_boundaries()?;
        let flatten = x.has("-flatten") || x.has("-ungroup_all") || self.appb("compile.flow.flatten");
        if flatten {
            let t = self.ungroup_targets(&[], true, true, x.num("-start_level").map(|v| v as usize).unwrap_or(1));
            let n = self.do_ungroup(&t, x.has("-simple_names"));
            crate::info!("OPT-791", "{}: flattened {} hierarch{} (boundaries opened)", name, n, if n == 1 { "y" } else { "ies" });
        } else if !x.has("-no_autoungroup") && fi == 0 && !self.nl.as_ref().unwrap().mapped {
            let mode = x.get("-auto_ungroup").cloned().or_else(|| if self.appb("compile.flow.autoungroup") { self.app.get("compile.flow.autoungroup.mode").cloned() } else { None });
            if let Some(m) = mode {
                self.auto_ungroup(&m);
            } else if !self.ungroup_marks.is_empty() {
                self.auto_ungroup("marks");
            }
        }
        crate::info!("FLW-001", "{} -from {} -to {} ({}; {} active scenario(s))", name, from, to, if physical { "physical" } else { "logical (no floorplan: placement stages skipped, wire-load/zero-wire RC)" }, self.active("").len());
        for st in &STAGES[fi..=ti] {
            let t0 = std::time::Instant::now();
            crate::out!("\n==== {} : {} ====", name, st);
            self.stage(st, physical)?;
            self.stages_done.push(st.to_string());
            if let Ok(q) = self.with_env(|nl, env| {
                let a = env.analyze(nl, 0);
                (a.wns, a.tns, a.whs, a.drv.len(), nl.num_cells())
            }) {
                let area = self.total_area();
                crate::out!("  [{:<13}] WNS {:>8.4}  TNS {:>9.4}  WHS {:>8.4}  DRV {:>4}  cells {:>6}  area {:>10.3}  ({:.2}s)", st, q.0, q.1, q.2, q.3, q.4, area, t0.elapsed().as_secs_f64());
            }
        }
        ok()
    }
    pub(crate) fn total_area(&self) -> f64 {
        let Some(nl) = &self.nl else { return 0.0 };
        nl.cell_ids().iter().filter_map(|c| nl.cell(*c).lib()).filter_map(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|c| c.area).sum()
    }
    pub(crate) fn stage(&mut self, st: &str, physical: bool) -> Result<(), Flow> {
        let tl = self.target_idx();
        match st {
            "initial_map" => {
                let nl = self.nl.as_mut().unwrap();
                if nl.mapped {
                    crate::info!("FLW-010", "Design already mapped; skipping initial_map");
                    return Ok(());
                }
                let mr = self.app.get("compile.seqmap.merge_equal_registers").map(|v| v == "true").unwrap_or(true);
                let st0 = crate::genopt::sweep(nl, mr, true);
                crate::info!("OPT-100", "Generic optimization: {} constants propagated, {} buffers swept, {} redundant/dead cells removed, {} shared, {} constant regs, {} unloaded regs, {} equal regs merged", st0.consts, st0.buffers, st0.dead, st0.merged, st0.const_regs, st0.unloaded_regs, st0.equal_regs);
                if self.appb("compile.clockgate.enable") {
                    let mb = self.appu("compile.clockgate.min_bitwidth");
                    let mf = self.appu("compile.clockgate.max_fanout");
                    let ex = self.cg_exclude.clone();
                    let n = crate::genopt::insert_clock_gating(self.nl.as_mut().unwrap(), &self.libs[tl], mb, mf, &ex);
                    crate::info!("PWR-731", "Clock gating: {} register(s) gated", n);
                    let nl = self.nl.as_mut().unwrap();
                    crate::genopt::sweep(nl, mr, true);
                }
                let vt = self.app.get("compile.map.vt").cloned().filter(|s| !s.is_empty());
                let mo = crate::techmap::MapOpts { vt, area_recovery: self.appb("compile.map.area_recovery"), dont_use: self.dont_use.clone(), max_cuts: 10 };
                let nl = self.nl.as_mut().unwrap();
                let s = crate::techmap::map(nl, &self.libs[tl], &mo).map_err(e2f)?;
                for (pre, v) in self.dont_touch_hier.clone() {
                    let mut k = 0;
                    for c in nl.cell_ids() {
                        if nl.cell(c).name.starts_with(&pre) {
                            nl.cell_mut(c).dont_touch = v;
                            k += 1;
                        }
                    }
                    for ni in nl.net_ids() {
                        if nl.net(ni).name.starts_with(&pre) {
                            nl.net_mut(ni).dont_touch = v;
                        }
                    }
                    let hn = pre.trim_end_matches('/').to_string();
                    nl.frozen_hier.retain(|f| *f != hn);
                    if v {
                        nl.frozen_hier.push(hn.clone());
                    }
                    crate::info!("SDC-233", "dont_touch applied to {} mapped cell(s) under '{}'", k, hn);
                }
                crate::info!("OPT-200", "Technology mapping to '{}': {} combinational + {} sequential cells, {} inverters added, comb area {:.3}", self.libs[tl].name, s.comb, s.seq, s.inv_added, s.area);
            }
            "logic_opto" => {
                let shared = self.with_env(|nl, env| {
                    let r = crate::opt::remove_buffer_trees(nl, env);
                    let s = crate::opt::share_logic(nl, 32);
                    (r, s)
                })?;
                crate::info!("OPT-300", "Logic optimization: {} buffer-tree cells removed, {} cells shared", shared.0, shared.1);
                if self.appb("compile.retiming.enable") {
                    let n = self.with_env(|nl, env| crate::opt::retime(nl, env, 32))?;
                    crate::info!("OPT-1901", "Retiming: {} register move(s)", n);
                }
                if self.upf.loaded && !self.upf.committed {
                    self.c_commit_upf()?;
                }
            }
            "initial_place" | "final_place" => {
                if st == "final_place" && self.upf.committed {
                    // incremental MV insertion for crossings created after commit (DFT, ECO, retention control)
                    let nl = self.nl.as_mut().unwrap();
                    let (i, l, r) = self.upf.commit(nl, &self.libs[tl]).map_err(e2f)?;
                    if i + l + r > 0 {
                        crate::info!("UPF-402", "Incremental MV insertion: {} isolation, {} level shifter(s), {} retention for new domain crossings", i, l, r);
                    }
                }
                if !physical {
                    crate::info!("FLW-020", "{}: skipped (no floorplan)", st);
                    return Ok(());
                }
                let die = self.fp.as_ref().map(|f| f.die).unwrap();
                let ps = self.fp_place(false)?;
                let (r, g) = self.with_env(|nl, env| crate::opt::move_registers(nl, env, die))?;
                self.fp_enforce()?;
                crate::info!("PLC-100", "{}: placed {} cell(s) honoring {} bound(s)/{} blockage(s) (util {:.1}%, {} overflow bins); physically-aware moves: {} register(s), {} clock gate(s)", st, ps.placed, self.fp.as_ref().unwrap().bounds.len(), self.fp.as_ref().unwrap().pblk.len(), ps.util * 100.0, ps.overflow_bins, r, g);
                self.fp_route(true)?;
            }
            "initial_drc" => {
                let ctl = self.opt_ctl.clone();
                if ctl.as_ref().map(|c| !c.drv).unwrap_or(false) {
                    crate::info!("OPT-920", "initial_drc: skipped (DRV fixing not selected)");
                    return Ok(());
                }
                let tf = self.appu("opt.tie_cell.max_fanout");
                let du = self.dont_use.clone();
                let nl = self.nl.as_mut().unwrap();
                crate::opt::insert_ties(nl, &self.libs[tl], tf, &du);
                let th = self.appu("opt.hfn.threshold");
                let mf = self.appu("opt.hfn.max_fanout");
                let glob = ctl.as_ref().map(|c| c.global_ok()).unwrap_or(true);
                let di = ctl.as_ref().map(|c| c.iters(6)).unwrap_or(6);
                let (h, d) = self.with_env(|nl, env| {
                    let h = if glob { crate::opt::high_fanout_synthesis(nl, env, th, mf, false) } else { 0 };
                    let d = crate::opt::fix_drv(nl, env, di);
                    (h, d)
                })?;
                if physical {
                    self.fp_enforce()?;
                }
                crate::info!("OPT-400", "DRC fixing: {} HFS buffer(s); {} cell(s) upsized and {} buffer(s) inserted for max_transition/max_capacitance/max_fanout", h, d.0, d.1);
            }
            "initial_opto" | "final_opto" => {
                let ctl = self.opt_ctl.clone();
                let it = self.appu("opt.timing.max_iterations");
                let vt = self.appb("opt.timing.allow_vt_swap");
                let cl = self.appb("opt.timing.allow_cloning");
                let (it, vt, cl) = match &ctl {
                    Some(c) => (c.iters(it), c.allow_vt(vt), c.allow_clone(cl)),
                    None => (it, vt, cl),
                };
                let (do_setup, do_hold, do_drv, do_power, glob) = match &ctl {
                    Some(c) => (c.setup, c.hold, c.drv, c.power, c.global_ok()),
                    None => (true, true, true, true, true),
                };
                if st == "final_opto" && glob {
                    let (dc, sh) = self.with_env(|nl, env| (crate::opt::declone(nl, env, 32), crate::opt::share_logic(nl, 32)))?;
                    if dc + sh > 0 {
                        crate::info!("OPT-710", "Decloned {} cell(s), shared {} equivalent cell(s)", dc, sh);
                    }
                }
                if do_setup {
                    let s = self.with_env(|nl, env| crate::opt::optimize_timing(nl, env, it, vt, cl))?;
                    crate::info!("OPT-500", "{}: timing optimization {} iteration(s): {} upsized, {} Multi-Vt swaps, {} pin swaps, {} clones", st, s.iterations, s.upsized, s.vt_swapped, s.pin_swaps, s.clones);
                }
                if do_drv {
                    let di = ctl.as_ref().map(|c| c.iters(4)).unwrap_or(4);
                    let d = self.with_env(|nl, env| crate::opt::fix_drv(nl, env, di))?;
                    if d.0 + d.1 > 0 {
                        crate::info!("OPT-401", "{}: DRV {} sized, {} buffers", st, d.0, d.1);
                    }
                }
                if st == "final_opto" {
                    let hm = self.appf("opt.hold.margin");
                    if do_hold && !self.active("hold").is_empty() {
                        let hi = ctl.as_ref().map(|c| c.iters(4)).unwrap_or(4);
                        let h = self.with_env(|nl, env| crate::opt::fix_hold(nl, env, hm, hi))?;
                        crate::info!("OPT-600", "Hold fixing: {} delay cell(s)", h);
                    }
                    // power/area recovery is a global step: not with -endpoints, and only when selected
                    if !(do_power && ctl.as_ref().map(|c| c.focus.is_none()).unwrap_or(true)) {
                        if do_setup {
                            let s2 = self.with_env(|nl, env| crate::opt::optimize_timing(nl, env, 6, vt, false))?;
                            if s2.upsized + s2.vt_swapped > 0 {
                                crate::info!("OPT-501", "final timing repair: {} upsized, {} Vt swaps", s2.upsized, s2.vt_swapped);
                            }
                        }
                        self.nl.as_mut().unwrap().sweep_nets();
                        return Ok(());
                    }
                    let leak = self.appb("opt.leakage.enable") && !self.active("leakage").is_empty();
                    let area = self.appb("opt.area.recovery");
                    let mg = self.appf("opt.recovery.slack_margin");
                    let (v, dn) = self.with_env(|nl, env| crate::opt::recover_power_area(nl, env, leak, area, mg))?;
                    crate::info!("OPT-700", "Power/area recovery: {} cell(s) swapped to higher Vt (leakage), {} downsized (area)", v, dn);
                    // final timing touch-up (sizing only)
                    let s2 = self.with_env(|nl, env| crate::opt::optimize_timing(nl, env, 6, vt, false))?;
                    if s2.upsized + s2.vt_swapped > 0 {
                        crate::info!("OPT-501", "final timing repair: {} upsized, {} Vt swaps", s2.upsized, s2.vt_swapped);
                    }
                    self.nl.as_mut().unwrap().sweep_nets();
                }
            }
            _ => {}
        }
        Ok(())
    }

    fn c_cleanup(&mut self, name: &str, a: &[String]) -> R {
        let x = args(a, &[]);
        let nl = self.nlm()?;
        let all = name == "cleanup_design" && x.f.is_empty();
        let mut msgs = vec![];
        if name == "remove_unconnected_ports" || name == "remove_unused_ports" || x.has("-unused_ports") || all {
            let mut n = 0;
            for p in nl.port_ids() {
                let Some(net) = nl.ports[p].net else {
                    nl.remove_port(p);
                    n += 1;
                    continue;
                };
                let dangling = match nl.ports[p].dir {
                    Dir::In => nl.loads(net).is_empty() && nl.net(net).conns.len() == 1,
                    Dir::Out => nl.drivers(net).is_empty() && nl.net(net).conns.len() == 1,
                    _ => false,
                };
                if dangling && (x.has("-force") || name == "remove_unused_ports" || name == "cleanup_design") {
                    crate::info!("OPT-1300", "Removing unconnected port '{}'", nl.ports[p].name);
                    nl.remove_port(p);
                    n += 1;
                } else if dangling {
                    crate::info!("OPT-1301", "Port '{}' is unconnected (use -force to remove top-level ports)", nl.ports[p].name);
                }
            }
            nl.sweep_nets();
            msgs.push(format!("{} port(s) removed", n));
        }
        if name == "resolve_multidriven" || x.has("-multidriven") || all {
            let mut n = 0;
            for net in nl.net_ids() {
                let d = nl.drivers(net);
                if d.len() > 1 {
                    for extra in &d[1..] {
                        if let PinRef::Cell(c, p) = *extra {
                            crate::warn!("OPT-1310", "Multi-driven net '{}': disconnecting extra driver {} (kept {})", nl.net(net).name, nl.pin_name(*extra), nl.pin_name(d[0]));
                            nl.disconnect(c, p);
                            n += 1;
                        }
                    }
                }
            }
            msgs.push(format!("{} extra driver(s) disconnected", n));
        }
        if x.has("-undriven") || all {
            let mut n = 0;
            for net in nl.net_ids() {
                if nl.drivers(net).is_empty() && nl.loads(net).iter().any(|l| matches!(l, PinRef::Cell(..))) {
                    let z = crate::genopt::const_net(nl, false);
                    crate::warn!("OPT-1320", "Undriven net '{}' tied to logic 0", nl.net(net).name);
                    nl.merge_net(z, net);
                    n += 1;
                }
            }
            msgs.push(format!("{} undriven net(s) tied low", n));
        }
        if x.has("-loops") || all {
            let loops = crate::checks::structural_loops(nl);
            for (k, l) in loops.iter().enumerate() {
                crate::warn!("OPT-1330", "Combinational feedback loop {} through {} cell(s): {} (breaking for timing via set_disable_timing on '{}')", k + 1, l.len(), l.join(" -> "), l[0]);
            }
            let first: Vec<String> = loops.iter().map(|l| l[0].clone()).collect();
            for c in first {
                self.cons().disabled.push((Obj::Cell(c.clone()), None, None));
                self.cons().raw.push(format!("set_disable_timing [get_cells {{{}}}]", c));
            }
            msgs.push(format!("{} loop(s) broken", loops.len()));
        }
        if name == "remove_unused_logic" || x.has("-dangling") || all {
            let nl = self.nlm()?;
            let mut st = crate::genopt::GenStats::default();
            let n = crate::genopt::remove_dead(nl, &mut st);
            nl.sweep_nets();
            msgs.push(format!("{} dangling cell(s) removed", n));
        }
        for m in &msgs {
            crate::info!("OPT-1340", "{}: {}", name, m);
        }
        Ok(msgs.join("; "))
    }

    // ------------------------------------------------------------ reports
    fn c_report_path_groups(&mut self, a: &[String]) -> R {
        let x = args(a, &["-scenarios"]);
        let scens = self.scen_list(&x, "setup");
        let m = self.cur_mode;
        let pg = self.modes[m].sdc.path_groups.clone();
        crate::out!("\n****************************************\nReport : path_groups (mode {})\n****************************************", self.modes[m].name);
        crate::out!("{:<20} {:>7} {:>9}  {}", "Group", "Weight", "CritRng", "Definition");
        let desc = |v: &[Obj]| -> String {
            if v.is_empty() { return "*".into(); }
            let mut s: Vec<String> = v.iter().take(3).map(|o| o.name().to_string()).collect();
            if v.len() > 3 { s.push(format!("... (+{})", v.len() - 3)); }
            s.join(" ")
        };
        for g in &pg {
            let (w, cr) = self.modes[m].sdc.group_weight_cr(&g.name);
            let crs = cr.map(|c| format!("{:.4}", c)).unwrap_or_else(|| "-".into());
            crate::out!("{:<20} {:>7.2} {:>9}  -from {{{}}} -to {{{}}}", g.name, w, crs, desc(&g.from), desc(&g.to));
        }
        for c in self.modes[m].sdc.clocks.clone() {
            let (w, cr) = self.modes[m].sdc.group_weight_cr(&c.name);
            let crs = cr.map(|c| format!("{:.4}", c)).unwrap_or_else(|| "-".into());
            crate::out!("{:<20} {:>7.2} {:>9}  clock group (paths captured by '{}')", c.name, w, crs, c.name);
        }
        for si in scens {
            let sc = self.scens[si].clone();
            self.with_timing(si, |t| {
                crate::out!("\n  Scenario {}\n  {:<20} {:>11} {:>10} {:>11} {:>6} {:>8}", sc.name, "Group", "WorstSlack", "WNS", "TNS", "NVP", "Endpts");
                for (g, w, tn, nv, ne, ws) in t.group_summary() {
                    let wss = if ws.is_finite() { format!("{:.4}", ws) } else { "-".into() };
                    crate::out!("  {:<20} {:>11} {:>10.4} {:>11.4} {:>6} {:>8}", g, wss, w, tn, nv, ne);
                }
            })?;
        }
        Ok((pg.len()).to_string())
    }

    fn c_report_qor(&mut self, a: &[String]) -> R {
        let x = args(a, &["-scenarios"]);
        let scens = self.scen_list(&x, "");
        let nl = self.nl()?;
        crate::out!("\n****************************************\nReport : qor\nDesign : {}\n****************************************", nl.name);
        let mut worst = (0.0f64, 0.0f64, 0.0f64, 0.0f64);
        let mut rows = vec![];
        for si in scens {
            let sc = self.scens[si].clone();
            let r = self.with_timing(si, |t| (t.wns, t.tns, t.nvp, t.whs, t.ths, t.nvh, t.drv.iter().filter(|d| d.kind == "max_transition").count(), t.drv.iter().filter(|d| d.kind == "max_capacitance").count(), t.drv.iter().filter(|d| d.kind == "max_fanout").count(), t.endpoints.len(), t.unconstrained.len()))?;
            worst.0 = worst.0.min(r.0);
            worst.1 = worst.1.min(r.1);
            worst.2 = worst.2.min(r.3);
            worst.3 = worst.3.min(r.4);
            rows.push((sc, r));
        }
        crate::out!("\n{:<16} {:>9} {:>10} {:>5} {:>9} {:>10} {:>5} {:>6} {:>6} {:>6} {:>7} {:>7}", "Scenario", "WNS", "TNS", "NVP", "WHS", "THS", "NVH", "MaxTr", "MaxCap", "MaxFo", "Endpts", "Uncons");
        for (sc, r) in &rows {
            crate::out!("{:<16} {:>9.4} {:>10.4} {:>5} {:>9.4} {:>10.4} {:>5} {:>6} {:>6} {:>6} {:>7} {:>7}", sc.name, r.0, r.1, r.2, if sc.hold { r.3 } else { 0.0 }, if sc.hold { r.4 } else { 0.0 }, if sc.hold { r.5 } else { 0 }, r.6, r.7, r.8, r.9, r.10);
        }
        // per path group (setup)
        let gscens: Vec<usize> = rows.iter().filter(|(sc, _)| sc.setup).filter_map(|(sc, _)| self.scens.iter().position(|s| s.name == sc.name)).collect();
        if !gscens.is_empty() {
            crate::out!("\n{:<16} {:<20} {:>11} {:>9} {:>10} {:>5}", "Scenario", "Path Group", "WorstSlack", "WNS", "TNS", "NVP");
            for si in gscens {
                let nm = self.scens[si].name.clone();
                self.with_timing(si, |t| {
                    for (g, w, tn, nv, _, ws) in t.group_summary() {
                        let wss = if ws.is_finite() { format!("{:.4}", ws) } else { "-".into() };
                        crate::out!("{:<16} {:<20} {:>11} {:>9.4} {:>10.4} {:>5}", nm, g, wss, w, tn, nv);
                    }
                })?;
            }
        }
        // area / cell stats
        let (mut comb, mut seq, mut bi, mut bb, mut gen, mut area, mut seqa, mut leak) = (0, 0, 0, 0, 0, 0.0, 0.0, 0.0);
        for c in nl.cell_ids() {
            match &nl.cell(c).kind {
                Kind::Lib(l) => {
                    if let Some(lc) = self.libs.iter().find_map(|x| x.cells.get(l)) {
                        area += lc.area;
                        leak += lc.leakage;
                        if lc.is_seq() {
                            seq += 1;
                            seqa += lc.area;
                        } else {
                            comb += 1;
                            if lc.is_buf || lc.is_inv {
                                bi += 1
                            }
                        }
                    }
                }
                Kind::BlackBox(_) => bb += 1,
                Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1) => {}
                Kind::Gen(_) if nl.cell(c).is_hport() => {}
                Kind::Gen(_) => gen += 1,
            }
        }
        crate::out!("\n  Cell count            {:>10}\n  Combinational cells   {:>10}\n  Sequential cells      {:>10}\n  Buffers/Inverters     {:>10}\n  Black boxes           {:>10}\n  Generic (unmapped)    {:>10}\n  Total cell area       {:>10.3}\n  Sequential area       {:>10.3}\n  Leakage (target lib)  {:>10.3} uW", comb + seq + bb + gen, comb, seq, bi, bb, gen, area, seqa, leak / 1000.0);
        crate::out!("\n  Design WNS {:.4}  TNS {:.4}  WHS {:.4}  THS {:.4}", worst.0, worst.1, worst.2, worst.3);
        if let Some(ma) = self.modes[self.cur_mode].sdc.max_area {
            crate::out!("  max_area {:.3}: {}", ma, if area <= ma { "MET" } else { "VIOLATED" });
        }
        Ok(format!("{} {}", worst.0, worst.1))
    }

    /// report_constraint [-all_violators] [-max_delay|-setup] [-min_delay|-hold] [-max_transition]
    ///   [-max_capacitance] [-max_fanout] [-drv_violation_type {types}] [-verbose]
    ///   [-significant_digits n] [-scenarios s] [object_list]
    fn c_report_constraints(&mut self, a: &[String]) -> R {
        let x = args(a, &["-scenarios", "-drv_violation_type", "-significant_digits", "-max_lines"]);
        let dig = x.num("-significant_digits").unwrap_or(4.0) as usize;
        let verbose = x.has("-verbose");
        let drv_types: Option<Vec<String>> = x.get("-drv_violation_type").map(|s| split_list(s).into_iter().map(|t| t.trim_start_matches('-').to_string()).collect());
        if let Some(v) = &drv_types {
            for t in v {
                if !["max_transition", "max_capacitance", "max_fanout"].contains(&t.as_str()) {
                    return Err(Flow::Err(format!("report_constraint: -drv_violation_type '{}' (use max_transition, max_capacitance, max_fanout) (CMD-010)", t)));
                }
            }
        }
        let sel_flags = ["-max_delay", "-setup", "-min_delay", "-hold", "-max_transition", "-max_capacitance", "-max_fanout"];
        let any_sel = sel_flags.iter().any(|f| x.has(f)) || drv_types.is_some();
        let all = x.has("-all_violators") || !any_sel;
        let only = |k: &str| -> bool {
            let drv = ["max_transition", "max_capacitance", "max_fanout"].contains(&k.trim_start_matches('-'));
            if let Some(v) = &drv_types {
                if drv {
                    return v.iter().any(|t| t == k.trim_start_matches('-'));
                }
                // -drv_violation_type alone: DRV only
                if !sel_flags[..4].iter().any(|f| x.has(f)) {
                    return false;
                }
            }
            !any_sel || x.has(k)
        };
        // object filter (pins, ports, nets, cells)
        let objs: Vec<String> = x.pos.iter().flat_map(|p| self.objs(p, "any")).map(|o| o.name().to_string()).collect();
        let nl = self.nl()?;
        let obj_ok = |name: &str, net: Option<crate::netlist::NetId>| -> bool {
            if objs.is_empty() {
                return true;
            }
            objs.iter().any(|o| {
                o == name || name.starts_with(&format!("{}/", o)) || net.map(|n| nl.net(n).name == *o || nl.net(n).conns.iter().any(|p| nl.pin_name(*p) == *o || matches!(p, crate::netlist::PinRef::Cell(c, _) if nl.cell(*c).name == *o))).unwrap_or(false)
            })
        };
        let scens = self.scen_list(&x, "");
        if !self.sdc_unsupported_count.is_empty() {
            crate::out!("\nIgnored (unsupported) SDC commands:");
            for (k, v) in &self.sdc_unsupported_count {
                crate::out!("  {:<34} {} occurrence(s)", k, v);
            }
        }
        let mut total = 0;
        for si in scens {
            let sc = self.scens[si].clone();
            let n = self.with_timing(si, |t| {
                let mut n = 0;
                crate::out!("\n****************************************\nReport : constraint {}\nScenario: {}\n****************************************", if all { "-all_violators" } else { "" }, sc.name);
                if sc.setup && (only("-max_delay") || only("-setup")) {
                    let mut v: Vec<_> = t.endpoints.iter().filter(|e| e.setup_slack < 0.0 && obj_ok(&e.name, None)).collect();
                    v.sort_by(|a, b| a.setup_slack.partial_cmp(&b.setup_slack).unwrap());
                    crate::out!("\n  max_delay/setup ({} violator(s))", v.len());
                    if !v.is_empty() {
                        crate::out!("    {:<56} {:>12} {:>12} {:>12}", "Endpoint", "Required", "Actual", "Slack");
                    }
                    for e in v {
                        crate::out!("    {:<56} {:>12.*} {:>12.*} {:>12.*} (VIOLATED)", e.name, dig, e.setup_req, dig, e.arrival, dig, e.setup_slack);
                        n += 1;
                    }
                }
                if sc.hold && (only("-min_delay") || only("-hold")) {
                    let mut v: Vec<_> = t.endpoints.iter().filter(|e| e.hold_slack < 0.0 && obj_ok(&e.name, None)).collect();
                    v.sort_by(|a, b| a.hold_slack.partial_cmp(&b.hold_slack).unwrap());
                    crate::out!("\n  min_delay/hold ({} violator(s))", v.len());
                    for e in v {
                        crate::out!("    {:<56} {:>12.*} (VIOLATED)", e.name, dig, e.hold_slack);
                        n += 1;
                    }
                }
                for k in ["max_transition", "max_capacitance", "max_fanout"] {
                    if !only(&format!("-{}", k)) {
                        continue;
                    }
                    let mut v: Vec<_> = t.drv.iter().filter(|d| d.kind == k && obj_ok(&d.obj, Some(d.net))).collect();
                    v.sort_by(|a, b| (a.limit - a.actual).partial_cmp(&(b.limit - b.actual)).unwrap());
                    let lim = match k {
                        "max_transition" => t.cons.max_tran,
                        "max_fanout" => t.cons.max_fanout,
                        _ => t.cons.max_cap,
                    };
                    crate::out!("\n  {} ({} violator(s)){}", k, v.len(), lim.map(|l| format!("   design limit {:.*}", dig, l)).unwrap_or_else(|| "   (library / object limits)".into()));
                    if !v.is_empty() {
                        crate::out!("    {:<52} {:>12} {:>12} {:>12}", if k == "max_transition" { "Pin" } else { "Net" }, "Required", "Actual", "Slack");
                    }
                    for d in v {
                        crate::out!("    {:<52} {:>12.*} {:>12.*} {:>12.*} (VIOLATED)", d.obj, dig, d.limit, dig, d.actual, dig, d.limit - d.actual);
                        if verbose {
                            let net = &nl.net(d.net).name;
                            let drv = nl.driver(d.net).map(|p| format!("{} ({})", nl.pin_name(p), match p { crate::netlist::PinRef::Cell(c, _) => nl.cell(c).lib().unwrap_or("-").to_string(), _ => "port".into() })).unwrap_or("-".into());
                            crate::out!("        net {}  driver {}  fanout {}  load {:.*} pF", net, drv, nl.loads(d.net).len(), dig, t.net_c[d.net]);
                        }
                        n += 1;
                    }
                }
                n
            })?;
            total += n;
        }
        Ok(total.to_string())
    }

    fn c_report_area(&mut self, a: &[String]) -> R {
        let nl = self.nl()?;
        let mut by_h: BTreeMap<String, (usize, f64)> = BTreeMap::new();
        let (mut comb, mut seq, mut bi, mut tot, mut bb, mut nets) = (0.0, 0.0, 0.0, 0.0, 0, nl.num_nets());
        let _ = &mut nets;
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            let ar = match &cell.kind {
                Kind::Lib(l) => self.libs.iter().find_map(|x| x.cells.get(l)).map(|lc| {
                    if lc.is_seq() {
                        seq += lc.area
                    } else {
                        comb += lc.area;
                        if lc.is_buf || lc.is_inv {
                            bi += lc.area
                        }
                    }
                    lc.area
                }).unwrap_or(0.0),
                Kind::BlackBox(_) => {
                    bb += 1;
                    0.0
                }
                _ => 0.0,
            };
            tot += ar;
            let h = cell.name.split('/').next().filter(|_| cell.name.contains('/')).unwrap_or("(top)").to_string();
            let e = by_h.entry(h).or_default();
            e.0 += 1;
            e.1 += ar;
        }
        crate::out!("\n****************************************\nReport : area\nDesign : {}\n****************************************", nl.name);
        crate::out!("Number of ports:            {:>10}\nNumber of nets:             {:>10}\nNumber of cells:            {:>10}\nNumber of black boxes:      {:>10}\n\nCombinational area:         {:>10.3}\nBuf/Inv area:               {:>10.3}\nNoncombinational area:      {:>10.3}\nMacro/Black Box area:       {:>10.3}\nTotal cell area:            {:>10.3}", nl.port_ids().len(), nl.num_nets(), nl.num_cells(), bb, comb, bi, seq, 0.0, tot);
        if a.iter().any(|x| x == "-hierarchy" || x == "-hier") {
            crate::out!("\n{:<30} {:>8} {:>12} {:>7}", "Hierarchical instance", "Cells", "Area", "%");
            for (h, (n, ar)) in by_h {
                crate::out!("{:<30} {:>8} {:>12.3} {:>6.1}%", h, n, ar, if tot > 0.0 { ar / tot * 100.0 } else { 0.0 });
            }
        }
        Ok(format!("{:.3}", tot))
    }

    fn c_report_power(&mut self, a: &[String]) -> R {
        let x = args(a, &["-scenarios"]);
        let scens = self.scen_list(&x, "leakage");
        let tr = self.appf("power.default_toggle_rate");
        crate::out!("\n****************************************\nReport : power (statistical; default toggle rate {} per clock)\n****************************************", tr);
        crate::out!("{:<16} {:>12} {:>12} {:>12} {:>12} {:>12}", "Scenario", "Internal mW", "Switch mW", "Leakage mW", "Total mW", "Clock mW");
        for si in scens {
            let sc = self.scens[si].clone();
            let (_, corner) = self.scen_corner_mode(si);
            let ls = self.libset(&corner);
            let act = self.activity.clone();
            let p = self.with_timing(si, |t| crate::out::power(t, &ls, tr, &act))?;
            crate::out!("{:<16} {:>12.6} {:>12.6} {:>12.6} {:>12.6} {:>12.6}", sc.name, p.internal_mw, p.switching_mw, p.leakage_mw, p.internal_mw + p.switching_mw + p.leakage_mw, p.clock_mw);
            if a.iter().any(|x| x == "-verbose") {
                for (vt, (n, l)) in &p.by_vt {
                    crate::out!("      Vt {:<6} cells {:>6} leakage {:>10.6} mW", vt, n, l);
                }
            }
        }
        ok()
    }
    fn c_report_vt(&mut self) -> R {
        let nl = self.nl()?;
        let mut m: BTreeMap<String, (usize, f64, f64)> = BTreeMap::new();
        for c in nl.cell_ids() {
            if let Some(lc) = nl.cell(c).lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))) {
                let e = m.entry(lc.vt.clone()).or_default();
                e.0 += 1;
                e.1 += lc.area;
                e.2 += lc.leakage;
            }
        }
        let (tn, ta, tl) = m.values().fold((0, 0.0, 0.0), |a, b| (a.0 + b.0, a.1 + b.1, a.2 + b.2));
        crate::out!("\n{:<8} {:>8} {:>7} {:>12} {:>7} {:>14} {:>7}", "Vt", "Cells", "%", "Area", "%", "Leakage(nW)", "%");
        for (vt, (n, ar, lk)) in &m {
            crate::out!("{:<8} {:>8} {:>6.1}% {:>12.3} {:>6.1}% {:>14.3} {:>6.1}%", vt, n, *n as f64 / tn.max(1) as f64 * 100.0, ar, ar / ta.max(1e-9) * 100.0, lk, lk / tl.max(1e-9) * 100.0);
        }
        ok()
    }
    fn c_report_cg(&mut self) -> R {
        let nl = self.nl()?;
        let mut icgs = 0usize;
        let mut gated = 0usize;
        let mut total = 0usize;
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            let lc = cell.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l)));
            if lc.map(|x| x.icg.is_some()).unwrap_or(false) {
                icgs += 1;
                let out = lc.unwrap().pins.iter().find(|p| p.cg_role.as_deref() == Some("out")).map(|p| p.name.clone());
                if let Some(n) = out.and_then(|o| cell.pin_net(&o)) {
                    gated += nl.loads(n).len();
                }
            }
            if lc.map(|x| x.seq.is_some() && x.icg.is_none()).unwrap_or(false) || cell.gop() == Some(GOp::Dff) {
                total += 1;
            }
        }
        crate::out!("\nClock gating summary\n  Clock-gating elements      {:>8}\n  Gated registers            {:>8} ({:.1}%)\n  Ungated registers          {:>8}\n  Total registers            {:>8}", icgs, gated, gated as f64 / total.max(1) as f64 * 100.0, total.saturating_sub(gated), total);
        ok()
    }
    fn c_report_clocks(&mut self, a: &[String]) -> R {
        let x = args(a, &["-mode", "-modes", "-clocks", "-scenarios"]);
        let want: Vec<String> = x.pos.iter().chain(x.get("-clocks")).flat_map(|p| split_list(p)).map(|c| Obj::parse(&c).map(|o| o.name().to_string()).unwrap_or(c)).collect();
        let modes: Vec<usize> = match x.get("-mode").or(x.get("-modes")) {
            Some(m) => split_list(m).iter().filter_map(|n| self.modes.iter().position(|mm| mm.name == *n)).collect(),
            None => (0..self.modes.len()).collect(),
        };
        let (show_attr, show_skew, show_groups) = (x.has("-attributes") || !(x.has("-skew") || x.has("-groups")), x.has("-skew") || x.has("-attributes"), x.has("-groups") || !(x.has("-skew") || x.has("-attributes")));
        // register sinks per clock (first active setup scenario of each mode)
        let mut sinks: HashMap<(usize, String), usize> = HashMap::new();
        for &mi in &modes {
            let mname = self.modes[mi].name.clone();
            if let Some(si) = (0..self.scens.len()).find(|&i| self.scens[i].mode == mname && self.scens[i].active) {
                if self.nl.is_some() {
                    let r = self.with_timing(si, |t| {
                        let mut m: HashMap<String, usize> = HashMap::new();
                        for &ck in t.clk_pins.iter().collect::<HashSet<_>>() {
                            for c in t.ctags[ck as usize].iter().map(|c| c.clk).collect::<HashSet<_>>() {
                                *m.entry(t.cons.clocks[c as usize].name.clone()).or_insert(0) += 1;
                            }
                        }
                        m
                    });
                    if let Ok(m) = r {
                        for (k, v) in m {
                            sinks.insert((mi, k), v);
                        }
                    }
                }
            }
        }
        let mut n = 0;
        for &mi in &modes {
            let m = &self.modes[mi];
            let clocks: Vec<&crate::cons::Clock> = m.sdc.clocks.iter().filter(|c| want.is_empty() || want.iter().any(|w| crate::netlist::glob(w, &c.name))).collect();
            crate::out!("\n****************************************\nReport : clocks   Mode: {}\n****************************************", m.name);
            crate::out!("Attributes: p - propagated, i - ideal, G - generated, V - virtual\n");
            if show_attr {
                crate::out!("{:<14} {:>9} {:>9} {:<6} {:<20} {:>7}  {}", "Clock", "Period", "Freq/MHz", "Attrs", "Waveform", "Sinks", "Sources");
                crate::out!("{}", "-".repeat(96));
                for c in &clocks {
                    let mut at = String::from(if c.propagated { "p" } else { "i" });
                    if c.gen.is_some() { at.push_str(",G"); }
                    if c.is_virtual() { at.push_str(",V"); }
                    let f = if c.period > 0.0 { 1000.0 / c.period } else { 0.0 };
                    let sk = sinks.get(&(mi, c.name.clone())).map(|v| v.to_string()).unwrap_or_else(|| "-".into());
                    let srcs = if c.is_virtual() { "(none)".to_string() } else { c.sources.iter().map(|s| s.name().to_string()).collect::<Vec<_>>().join(" ") };
                    crate::out!("{:<14} {:>9.4} {:>9.2} {:<6} {:<20} {:>7}  {}", c.name, c.period, f, at, format!("{{{} {}}}", c.rise, c.fall), sk, srcs);
                    n += 1;
                }
                let gens: Vec<_> = clocks.iter().filter(|c| c.gen.is_some()).collect();
                if !gens.is_empty() {
                    crate::out!("\n{:<14} {:<14} {:<28} {:<24} {}", "Generated", "Master", "Master source", "Relation", "Inverted");
                    for c in gens {
                        let g = c.gen.as_ref().unwrap();
                        let rel = if let Some(e) = &g.edges { format!("edges {:?}", e) } else if g.multiply > 1.0 { format!("multiply_by {}", g.multiply) } else { format!("divide_by {}", g.divide) };
                        crate::out!("{:<14} {:<14} {:<28} {:<24} {}", c.name, g.master, g.source.name(), rel, if g.invert { "yes" } else { "no" });
                    }
                }
            }
            if show_skew {
                crate::out!("\n{:<14} {:>10} {:>10} {:>12} {:>12} {:>12} {:>12} {:>10}", "Clock", "Unc setup", "Unc hold", "SrcLat max", "SrcLat min", "NetLat max", "NetLat min", "Transition");
                for c in &clocks {
                    crate::out!("{:<14} {:>10.4} {:>10.4} {:>12.4} {:>12.4} {:>12.4} {:>12.4} {:>10.4}", c.name, c.unc_setup, c.unc_hold, c.src_lat.0, c.src_lat.1, c.net_lat.0, c.net_lat.1, c.transition);
                }
            }
            if show_groups && !m.sdc.clock_groups.is_empty() {
                crate::out!("\nClock groups:");
                for (kind, gs) in &m.sdc.clock_groups {
                    crate::out!("  -{:<22} {}", kind, gs.iter().map(|g| format!("{{{}}}", g.join(" "))).collect::<Vec<_>>().join("  "));
                }
            }
        }
        Ok(n.to_string())
    }

    fn c_report_clock_crossing(&mut self, a: &[String]) -> R {
        let x = args(a, &["-scenarios", "-from", "-to", "-max_endpoints"]);
        let verbose = x.has("-verbose");
        let maxe = x.num("-max_endpoints").map(|v| v as usize).unwrap_or(if verbose { usize::MAX } else { 10 });
        let fpat: Vec<String> = x.get("-from").map(|p| split_list(p).iter().map(|c| Obj::parse(c).map(|o| o.name().to_string()).unwrap_or(c.clone())).collect()).unwrap_or_default();
        let tpat: Vec<String> = x.get("-to").map(|p| split_list(p).iter().map(|c| Obj::parse(c).map(|o| o.name().to_string()).unwrap_or(c.clone())).collect()).unwrap_or_default();
        let scens = self.scen_list(&x, "setup");
        let nl = self.nl()?;
        let libs = &self.libs;
        let lc_of = |c: CellId| nl.cell(c).lib().and_then(|l| libs.iter().find_map(|x| x.cells.get(l)));
        let is_seq = |c: CellId| lc_of(c).map(|l| l.seq.is_some()).unwrap_or(false) || matches!(nl.cell(c).kind, Kind::Gen(GOp::Dff) | Kind::Gen(GOp::Latch));
        let clk_net = |c: CellId| -> Option<NetId> {
            let lc = lc_of(c)?;
            nl.cell(c).pins.iter().find(|p| lc.pin(&p.name).map(|lp| lp.is_clock).unwrap_or(false)).and_then(|p| p.net)
        };
        // classify an untimed register-data crossing endpoint
        let classify = |d: PinRef| -> (&'static str, bool) {
            let PinRef::Cell(c, p) = d else { return ("output port", false) };
            // driver of the D net through buffers/inverters
            let mut comb = false;
            if let Some(mut n) = nl.cell(c).pins[p].net {
                for _ in 0..16 {
                    match nl.driver(n) {
                        Some(PinRef::Cell(dc, _)) => {
                            if is_seq(dc) {
                                break;
                            }
                            let bufinv = lc_of(dc).map(|l| l.is_buf || l.is_inv).unwrap_or(false);
                            if !bufinv {
                                comb = true;
                                break;
                            }
                            let Some(inp) = nl.cell(dc).pins.iter().find(|q| q.dir == Dir::In).and_then(|q| q.net) else { break };
                            n = inp;
                        }
                        _ => break,
                    }
                }
            }
            let ck = clk_net(c);
            let outs: Vec<NetId> = nl.cell(c).pins.iter().filter(|q| q.dir == Dir::Out).filter_map(|q| q.net).collect();
            let mut loads = 0;
            let mut stage2 = false;
            for o in outs {
                for l in nl.loads(o) {
                    loads += 1;
                    if let PinRef::Cell(lc2, lp) = l {
                        let is_ck = lc_of(lc2).and_then(|lcc| lcc.pin(&nl.cell(lc2).pins[lp].name)).map(|x| x.is_clock).unwrap_or(false);
                        if is_seq(lc2) && !is_ck && ck.is_some() && clk_net(lc2) == ck {
                            stage2 = true;
                        }
                    }
                }
            }
            let st = match (stage2, loads) {
                (true, 1) => "2-FF synchronizer",
                (true, _) => "synchronizer (stage-1 fans out)",
                _ => "UNSYNCHRONIZED",
            };
            (st, comb)
        };
        let mut total_unsync = 0;
        for si in scens {
            let sc = self.scens[si].clone();
            let rows = self.with_timing(si, |t| {
                let cn = |k: u16| t.cons.clocks[k as usize].name.clone();
                let keep = |l: &str, c: &str| (fpat.is_empty() || fpat.iter().any(|p| crate::netlist::glob(p, l))) && (tpat.is_empty() || tpat.iter().any(|p| crate::netlist::glob(p, c)));
                let mut pairs: Vec<(String, String, usize, f64, usize, usize)> = t.xing.iter().map(|((l, c), x)| (cn(*l), cn(*c), x.timed.len(), x.worst, x.false_path.len(), x.asynch.len())).filter(|r| keep(&r.0, &r.1)).collect();
                pairs.sort_by(|a, b| (&a.0, &a.1).cmp(&(&b.0, &b.1)));
                let eps: Vec<(String, String, String, String, char, bool, PinRef)> = t.xing_eps.iter().filter(|e| keep(&cn(e.launch), &cn(e.capture))).map(|e| (cn(e.launch), cn(e.capture), t.node_name(e.node), t.node_name(e.start), e.kind, e.asynch, t.nodes[e.node as usize])).collect();
                (pairs, eps)
            })?;
            let (pairs, eps) = rows;
            crate::out!("\n****************************************\nReport : clock_crossing   Scenario: {}\n****************************************", sc.name);
            if pairs.is_empty() {
                crate::out!("No clock-domain crossings.");
                continue;
            }
            // classify untimed endpoints
            let mut cls: Vec<(String, String, String, String, char, bool, &'static str, bool)> = vec![];
            for (l, c, ep, sp, k, asy, pr) in eps {
                let (st, comb) = match k {
                    'D' => classify(pr),
                    'R' => ("async reset crossing", false),
                    'G' => ("clock-gating enable crossing", false),
                    _ => ("to output port", false),
                };
                cls.push((l, c, ep, sp, k, asy, st, comb));
            }
            crate::out!("{:<12} {:<12} {:>7} {:>11} {:>7} {:>7} {:>7} {:>8}  {}", "Launch", "Capture", "Timed", "WorstSlack", "FalseP", "Async", "Synced", "Unsync", "Status");
            crate::out!("{}", "-".repeat(100));
            for (l, c, nt, w, nf, na) in &pairs {
                let mine: Vec<_> = cls.iter().filter(|r| &r.0 == l && &r.1 == c).collect();
                let synced = mine.iter().filter(|r| r.6.starts_with("2-FF") || r.6.starts_with("synchronizer")).count();
                let unsync = mine.iter().filter(|r| r.6 == "UNSYNCHRONIZED" || r.7).count();
                total_unsync += unsync;
                let status = if nf + na == 0 {
                    "synchronous (timed)".to_string()
                } else if unsync > 0 {
                    format!("VIOLATION: {} unsafe endpoint(s)", unsync)
                } else if *nt > 0 {
                    "mixed: partly timed, untimed part synchronized".into()
                } else {
                    "asynchronous, synchronized".into()
                };
                let ws = if *nt > 0 && w.is_finite() { format!("{:.4}", w) } else { "-".into() };
                crate::out!("{:<12} {:<12} {:>7} {:>11} {:>7} {:>7} {:>7} {:>8}  {}", l, c, nt, ws, nf, na, synced, unsync, status);
            }
            let bad: Vec<_> = cls.iter().filter(|r| r.6 == "UNSYNCHRONIZED" || r.7 || verbose).collect();
            if !bad.is_empty() {
                crate::out!("\n{} untimed crossing endpoint(s){}:", bad.len(), if verbose { "" } else { " needing attention" });
                crate::out!("  {:<10} {:<10} {:<4} {:<44} {:<34} {}", "Launch", "Capture", "Kind", "Endpoint", "Startpoint", "Status");
                for r in bad.iter().take(maxe) {
                    let st = if r.7 { format!("{}; combinational logic before first flop (glitch risk)", r.6) } else { r.6.to_string() };
                    crate::out!("  {:<10} {:<10} {:<4} {:<44} {:<34} {}{}", r.0, r.1, r.4, r.2, r.3, st, if r.5 { "" } else { " [false_path]" });
                }
                if bad.len() > maxe {
                    crate::out!("  ... {} more (use -verbose or -max_endpoints)", bad.len() - maxe);
                }
            }
        }
        if total_unsync > 0 {
            crate::warn!("TIM-400", "report_clock_crossing: {} unsafe clock-domain crossing endpoint(s)", total_unsync);
        }
        Ok(total_unsync.to_string())
    }
    fn c_report_ref(&mut self, name: &str, a: &[String]) -> R {
        let nl = self.nl()?;
        if name == "report_cell" && !a.is_empty() {
            for o in a.iter().filter(|x| !x.starts_with('-')).flat_map(|x| self.objs(x, "cell")) {
                if let Some(c) = nl.cell_by_name(o.name()) {
                    let cell = nl.cell(c);
                    crate::out!("{} ({:?}) loc={:?} attrs={:?}", cell.name, cell.kind, cell.loc, cell.attrs);
                    if a.iter().any(|x| x == "-connections") {
                        for p in &cell.pins {
                            crate::out!("   {:<8} {:?}  {}", p.name, p.dir, p.net.map(|n| nl.net(n).name.clone()).unwrap_or("-".into()));
                        }
                    }
                }
            }
            return ok();
        }
        let mut m: BTreeMap<String, (usize, f64)> = BTreeMap::new();
        for c in nl.cell_ids() {
            let (k, ar) = match &nl.cell(c).kind {
                Kind::Lib(l) => (l.clone(), self.libs.iter().find_map(|x| x.cells.get(l)).map(|x| x.area).unwrap_or(0.0)),
                Kind::BlackBox(b) => (format!("{} [BLACKBOX]", b), 0.0),
                Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1) => continue,
                Kind::Gen(g) => (format!("**{:?}** (generic)", g), 0.0),
            };
            let e = m.entry(k).or_default();
            e.0 += 1;
            e.1 += ar;
        }
        crate::out!("\n{:<28} {:>8} {:>12}", "Reference", "Count", "Area");
        for (k, (n, ar)) in m {
            crate::out!("{:<28} {:>8} {:>12.3}", k, n, ar);
        }
        ok()
    }
    fn c_report_design(&mut self) -> R {
        let nl = self.nl()?;
        crate::out!("\nDesign: {}  ({})\n  ports {}  nets {}  cells {}\n  libraries: {}\n  modes {}  corners {}  scenarios {} ({} active)\n  floorplan: {}\n  UPF: {}\n  stages completed: {}", nl.name, if nl.mapped { "mapped" } else { "generic" }, nl.port_ids().len(), nl.num_nets(), nl.num_cells(), self.libs.iter().map(|l| l.name.clone()).collect::<Vec<_>>().join(", "), self.modes.len(), self.corners.len(), self.scens.len(), self.active("").len(), self.fp.as_ref().map(|f| format!("{:?}", f.die)).unwrap_or("none".into()), if self.upf.loaded { format!("{} domains, committed={}", self.upf.domains.len(), self.upf.committed) } else { "none".into() }, self.stages_done.join(" "));
        for (i, m, r) in &self.bbs {
            crate::out!("  [BLACKBOX:{}] {} ({})", r, i, m);
        }
        ok()
    }

    fn c_check_timing(&mut self, a: &[String]) -> R {
        let x = args(a, &["-include", "-exclude", "-scenarios"]);
        let inc = x.get("-include").map(|s| split_list(s));
        let exc = x.get("-exclude").map(|s| split_list(s)).unwrap_or_default();
        let o = crate::checks::CheckOpts { snake_levels: self.appu("check_timing.snake_levels"), snake_hier: self.appu("check_timing.snake_hier_crossings"), hfn: self.appu("check_timing.high_fanout"), verbose: x.has("-verbose") };
        let scens = self.scen_list(&x, "");
        let mut total = 0;
        for si in scens {
            crate::out!("\nScenario: {}", self.scens[si].name);
            let inc2 = inc.clone();
            let exc2 = exc.clone();
            total += self.with_timing(si, |t| crate::checks::check_timing(t, &o, &|k: &str| inc2.as_ref().map(|v| v.iter().any(|x| x == k)).unwrap_or(true) && !exc2.iter().any(|x| x == k)))?;
        }
        if !self.latches.is_empty() {
            crate::out!("  Elaboration-inferred latches: {}", self.latches.len());
            for l in &self.latches {
                crate::out!("      {}", l);
            }
        }
        Ok(total.to_string())
    }
    fn c_check_design(&mut self, name: &str, a: &[String]) -> R {
        let verbose = a.iter().any(|x| x == "-verbose");
        let nl = self.nl()?;
        let d = crate::checks::design_issues(nl);
        crate::out!("\n****************************************\nReport : {}\nDesign : {}\n****************************************", name, nl.name);
        let mut n = 0;
        use crate::checks::print_issues as pi;
        n += pi("Unused (unloaded) input ports", &d.unused_inputs, verbose, "LINT-28");
        n += pi("Undriven output ports", &d.undriven_outputs, verbose, "LINT-29");
        n += pi("Output ports driven by constants", &d.const_outputs, verbose, "LINT-52");
        n += pi("Feedthrough ports", &d.feedthroughs, verbose, "LINT-29b");
        n += pi("Multi-driven nets/pins", &d.multidriven, verbose, "LINT-4");
        n += pi("Undriven / floating cell inputs", &d.undriven_inputs, verbose, "LINT-58");
        n += pi("Unloaded cell outputs", &d.unloaded_outputs, verbose, "LINT-2");
        let loops: Vec<String> = d.comb_loops.iter().enumerate().map(|(i, l)| format!("loop {} ({} cells): {}", i + 1, l.len(), l.join(" -> "))).collect();
        n += pi("Combinational feedback loops", &loops, true, "LINT-14");
        let nonuniq: Vec<String> = self.multi_inst.iter().map(|(m, i)| format!("{} instantiated {}x (non-uniquified): {}", m, i.len(), abbrev_list(i, 8))).collect();
        n += pi("Non-uniquified designs", &nonuniq, verbose, "LINT-45");
        let bb: Vec<String> = self.bbs.iter().map(|(i, m, r)| format!("[{}] {} ({})", match *r {
            "empty" => "EMPTY MODULE",
            "unresolved" => "UNRESOLVED BLACKBOX",
            _ => "BLACKBOX",
        }, i, m)).collect();
        n += pi("Black boxes / empty modules", &bb, true, "LINK-5");
        n += pi("Inferred latches", &self.latches, verbose, "ELAB-302");
        crate::out!("\n  {}: {} issue(s)", name, n);
        Ok(n.to_string())
    }

    fn help(&self, topic: Option<&str>) {
        self.help_cmd(topic);
    }
    pub(crate) fn help_groups(&self, topic: Option<&str>) {
        let groups = HELP_GROUPS;
        for (g, cmds) in groups {
            if topic.map(|t| g.to_lowercase().contains(&t.to_lowercase()) || cmds.iter().any(|c| c.starts_with(t))).unwrap_or(true) {
                crate::out!("{}:", g);
                for c in *cmds {
                    if topic.map(|t| g.to_lowercase().contains(&t.to_lowercase()) || c.starts_with(t)).unwrap_or(true) {
                        crate::out!("    {}", c);
                    }
                }
            }
        }
    }
}

/// curated help groups (syntax lines); every other command is listed from the registry
pub const HELP_GROUPS: &[(&str, &[&str])] = &[
            ("Setup", &["read_lib", "set_app_var", "set_app_options", "report_app_options", "set_dont_use", "check_library", "report_lib"]),
            ("Design input", &["analyze", "read_verilog", "read_sverilog", "read_vhdl", "elaborate", "link_block", "set_top_module", "set_blackbox", "uniquify", "read_def", "load_upf"]),
            ("MMMC", &["create_mode", "create_corner", "create_scenario", "current_scenario", "set_scenario_status", "read_lib -corner", "set_lib_corner", "set_timing_derate", "set_parasitic_parameters", "report_scenarios"]),
            ("Constraints (SDC)", &["create_clock", "create_generated_clock", "set_clock_uncertainty", "set_clock_latency", "set_clock_transition", "set_propagated_clock", "set_input_delay", "set_output_delay", "set_false_path", "set_multicycle_path", "set_max_delay", "set_min_delay", "set_disable_timing", "set_case_analysis", "set_clock_groups", "set_max_transition", "set_max_fanout", "set_max_capacitance", "set_input_transition", "set_driving_cell", "set_load", "set_wire_load_model", "set_clock_gating_check", "set_data_check", "set_min_pulse_width", "set_dont_touch", "read_sdc", "write_sdc"]),
            ("Optimization", &["compile_fusion [-from|-to initial_map logic_opto initial_place initial_drc initial_opto final_place final_opto]", "insert_clock_gating", "set_clock_gating_options", "optimize_registers", "remove_buffer_trees", "insert_buffer_tree", "commit_upf"]),
            ("ECO", &["eco_create_ports {names|bus[msb:lsb]|bus[*] -bus_width N} -direction in|out|inout", "eco_delete_ports {names|patterns}", "add_instance -name n -cell lib_cell [-location {x y}]", "delete_instance {cells|patterns|hier_inst} | -inst {pats} [-physical_only] [-force]", "create_net / remove_net", "disconnect_pin {pins} [-net n]", "connect -net n -pin {pins} [-punch_ports|-no_punch_ports] [-auto_disconnect_existing] [-force]  (aliases connect_net, connect_pins -driver -loads)", "eco_add_repeater -cell buf|inv (-net n | -pin {loads}) [-stage_count N] [-name prefix]", "eco_delete_repeater [-buff] [-inv_pairs] {cells} | -net {nets} | -all", "eco_sizecell -inst {cells} (-cell lib | -autoup | -autodown)", "eco_change_cell -inst {cells} -cell lib [-force]", "report_eco_changes, write_eco_changes file", "size_cell", "insert_buffer", "clone_cell", "fix_eco_timing -type setup|hold|drc|power"]),
            ("Query/selection", &["all_inputs/all_outputs/all_clocks", "all_registers [-clock_pins|-data_pins] [-clock c]", "all_connected [-leaf] obj", "get_cells/get_nets/get_pins/get_ports [-hier] [-regexp] [-nocase] [-filter expr]", "current_instance [inst|..|/]", "report_transitive_fanout -from objs [-levels N] [-endpoints_only]", "report_transitive_fanin -to objs ...", "select_obj / add_to_selection / remove_from_selection / deselect_all / get_selection / report_selection", "check_timing -verbose"]),
            ("Delay calculation / extraction", &["set_delay_calculation [-model elmore|d2m|awe] [-ceff true|false] [-miller f] [-global_route_parasitics true|false] [-layer_thresholds {um um}] [-segment_length um]", "report_delay_calculation [-worst | -net n | -from drv -to load] [-input_slew ns] [-reference]", "check_delay_calculation [-nets n] [-input_slew ns]", "report_rc_correlation [-nets n]", "extract_rc [-mode fast|detailed] [-lateral f] [-coupled k] [-isolated k]", "report_net_parasitics -net n"]),
            ("GUI", &["gtk_gui  (GTK GUI, KLayout-style; aliases gui_start, gui_show, gui_open, win; or start rsynth with -gui; build with --features gtk)", "gui_zoom [-fit | -rect {x0 y0 x1 y1} | -cells pats] [-margin um]", "gui_stop / gui_hide (inside the GUI console)", "gui_show_flylines [-cells pats | -all_macros | -all_std_cells | -all_cells] [-macros_only | -std_cells_only] [-add | -remove | -clear] [-exclude_nets pats] [-max_fanout n] [-macro_to_macro | -all_connections] [-color_by net|macro]", "gui_show_schematic [-cells pats] [-depth n] [-max_cells n] [-all]", "gui_trace_schematic -pin inst/pin|port [-levels n] [-to_endpoint] [-direction fanout|fanin]  (schematic pin double-click)", "gui_deselect_all", "gui_write_image file.png|svg [-rect {x0 y0 x1 y1}] [-width w] [-height h] [-show {rows tracks ...}] [-hide {...}]", "write_schematic file.svg|png [-cells pats] [-depth n] [-all]", "gui_write_state file.json", "write_clock_tree -output file.json [-clocks pats]"]),
            ("Help", &["help [command | pattern | -all]  (man)", "shell: Tab completes commands / -options / $vars / files (Tab Tab lists); ^A ^E ^B ^F ^K ^U ^W ^Y ^T ^D ^L ^P ^N ^R ^C, Alt-B/F/D", "list_commands [pattern] [-area a] [-aliases]", "write_command_list file.csv|.tsv|.md [-format csv|tsv|md]"]),
            ("Chip floorplan / IO", &["read_lef files / report_lef [pattern]", "initialize_floorplan [-die_width w -die_height h | -die_size {w h} | -boundary {{..}}] [-core_width w -core_height h | -core_size {w h} | -core_boundary {{..}}] [-core_utilization u] [-aspect_ratio h/w] [-core2die_spacing {s | l b r t}] [-row_height h] [-no_pins]", "place_io_pins [-ports pats] [-bus_name pats] [-auto_group_bus] [-direction {top|bottom|left|right ..}] [-layer L] [-width w] [-depth d] [-track_pitch n] [-offset um] [-spacing um] [-refine] [-random_place [-seed n]]", "snap_pins_to_tracks [-ports pats]", "move_objects -objects {cells ports} (-to {x y} | -delta {dx dy}) [-orientation N|S|E|W|FN|FS|FE|FW] [-fixed true|false]", "place_macros [-cells pats] [-group_by module|none] [-spacing um] [-halo um]", "snap_macros_to_grid [-cells pats] [-grid {gx gy}] [-origin core|die]", "report_flylines [-cells pats]", "create_pad_ring -pad_ring_order_config_file f [-corner_cell C] [-corner_orientation {ll N lr FN ul FS ur S}] [-filler_cells {..}] [-bond_pad_cell B] [-bond_style inline|staggered] [-stagger_gap um] [-pad_spacing um] [-distribute even|abut] [-ring_offset um] [-no_insert]", "report_pad_ring", "check_bond_pads [-min_pitch um] [-min_row_pitch um]", "check_esd [-max_clamp_distance um] [-max_signals_per_supply n] [-clamp_cells {..}] [-breaker_cells {..}]", "create_seal_ring -width w [-height h] -layers {..} [-offset um] [-chamfer um] [-net n]"]),
            ("Flip-chip", &["create_bump_array -cell BUMP -pitch p [-pitch_y p] [-layer AP] [-pattern full|staggered|perimeter] [-rings n] [-margin um] [-area {..}] [-prefix p]", "delete_bumps {patterns}", "create_area_io [-input_cell AIO_IN] [-output_cell AIO_OUT] [-ports pats] [-placement channels|ring] [-inset um]", "assign_bumps -power_nets {..} -ground_nets {..} [-supply_pattern checker|rows|center] [-pad_cells pats | -signals ports] [-signal_rings n]", "optimize_bump_assignment [-iterations n] [-crossing_weight um] [-swap_supplies]", "route_rdl [-layer AP] [-width w] [-spacing s] [-allow_45] [-nets pats]", "report_bumps", "write_bumps -format def|gds|text file [-gds_layer n]  (write_bump_def, write_bump_gds)"]),
            ("Placement pre-checks", &["check_row_site [-verbose]  (check_placement_sites): std cells vs LEF SITE / DEF ROW / placement grid",
                "check_io_overlaps [-verbose]  (check_pad_overlaps): IO pads / corners / fillers / area IO / macros overlapping or outside the die",
                "place_detail / legalize_placement run both checks first and abort on any problem; -skip_site_check bypasses the ROW / SITE part"]),
            ("Query & measure", &["query_objects -name {objs} [-type cell|net|port|pin]  (query_object, dbQuery): properties by tab (General / Geometry / Pins / Library, Routing / Connections)",
                "gui_query_object -name obj  (shows it in the GUI QUERY pane)", "gui_add_ruler -from {x y} -to {x y}  (add_ruler): distance, dx, dy, Manhattan, angle", "measure_distance -from {x y} -to {x y}", "report_rulers", "gui_clear_rulers  (clear_rulers)"]),
            ("Power planning (Innovus-style)", &["connect_global_net NET -type pg_pin|tiehi|tielo [-pin_base_name P] [-inst_base_name pats] [-module m] [-override]  (globalNetConnect)", "report_global_net_connections / clear_global_net_connections",
                "add_rings -nets {VDD VSS} [-type core_rings|block_rings] [-around core|each_block|selected] [-blocks pats] -layer {top L bottom L left L right L} -width w -spacing s -offset o [-center 1]  (addRing)",
                "add_stripes -nets {..} -layer L -direction vertical|horizontal -width w -spacing s [-set_to_set_distance d] [-start_offset o] [-stop o] [-number_of_sets n] [-area {..}] [-extend_to first_ring|design_boundary] [-no_snap]  (addStripe)",
                "create_followpins -nets {VDD VSS} [-layer M1] [-width w] [-extend_to ring|core]  (create_rails, add_followpins)", "sroute -connect core_pin|block_pin|pad_pin -nets {..} [-layer L] [-width w]  (route_special)",
                "generate_vias [-nets {..}] [-layers M1:M6] [-area {..}]  (generateVias, editPowerVia -add_vias 1, update_power_vias)", "delete_power_vias [-nets {..}] [-area {..}]  (editPowerVia -delete_vias 1)",
                "add_special_wire -net n -layer L (-rect {x0 y0 x1 y1} | -points {..} -width w)  /  delete_special_wire [-net n] [-layer L] -area {..}", "delete_pg_shapes [-nets ..] [-kind ring|stripe|followpin|strap]", "report_power_routes"]),
            ("Physical verification / markers", &["check_drc [-layers {..}] [-area {..}] [-limit n]  (verify_drc)", "check_lvs [-shorts] [-connectivity|-opens] [-nets pats] [-type all|signal|pg] [-report file]  (verify_connectivity)",
                "check_missing_vias [-nets {..}]  (verifyPowerVia, check_power_vias)", "report_markers [-tool drc|lvs|via] [-limit n]", "delete_markers [-tool t]  (clear_drc)",
                "write_markers -format calibre|text|json -output file", "read_markers -tool calibre file.rdb"]),
            ("Non-default routing rules", &["create_route_rule -name R (-preset 1w1s|1w2s|2w1s|2w2s|3w3s | -width_multiplier w -spacing_multiplier s | -widths {L w ..} -spacings {L s ..})  (add_ndr)",
                "set_route_attributes (-nets pats | -clock_nets) (-route_rule R | -reset)  (setAttribute -net n -non_default_rule R, assign_ndr)", "report_route_rules  (report_ndr) / delete_route_rule R"]),
            ("Route edits", &["add_wire -net n -layer L -points {x0 y0 x1 y1 ..}", "delete_wire -net n [-layer L] [-area {x0 y0 x1 y1}]", "cut_wire -net n -at {x y} [-layer L] [-gap um]", "add_via -net n -at {x y} -from L1 -to L2 [-type VIA23_2CUT]", "delete_via -net n -at {x y} [-from L1 -to L2]", "swap_via -to_type T [-from_type pat] [-nets pats] [-area {..}]", "get_route_segments -net n [-layer L]", "report_route_edits"]),
            ("Spare / gate-array / mask ECO", &["insert_spare_cells -cells {lib n ..} [-modules pats] [-groups_per_module n] [-tie_cell TIELO] [-prefix spare] [-placement distributed|clustered]", "report_spare_cells", "insert_gate_array_fillers [-cells {GFILL4 GFILL2 GFILL1}] [-area {..}]", "eco_netlist -by_verilog_file f [-apply]", "eco_place", "set_eco_mode -post_mask true|false [-metal_layers {..}] [-allow_base_changes true|false]", "eco_remap_post_mask -use spare|gate_array|both [-max_distance um] [-allow_function_mapping]", "check_eco_mask [-metal_layers {..}]"]),
            ("Power domains / voltage areas", &["create_voltage_area -power_domains PD -region {{x0 y0} {x1 y1}} [-name VA] [-guard_band {gx gy}]", "report_voltage_areas [-verbose]", "get_voltage_areas [-of_objects PD]", "remove_voltage_areas [-all] [names]", "get_power_domains [pattern] [-of_objects cells]", "gui_highlight_power_domain [-add|-remove|-clear] [-color_by power_domain|hierarchy] [PDs]", "gui_get_highlighted_power_domains"]),
            ("Rows / tracks / physical cells", &["create_row [-site s] [-area {x1 y1 x2 y2}] [-spacing s] [-no_abut] [-no_flip] [-flip_first_row] [-num_rows n]  (createRow)",
                "cut_row [-area {..} | -selected | -objects pats] [-halo h] [-left_gap l -right_gap r -top_gap t -bottom_gap b] [-site s] [-min_row_width w]  (cutRow)",
                "delete_row -all | -area {..} | -site s | names  (deleteRow)", "report_rows [-verbose]",
                "create_track -layer {..} [-dir X|Y] [-start s] [-step p] [-num n] [-mask m] [-add]  (createTrack)",
                "add_tracks [-honor_pitch] [-offsets {layer dir off ...}] [-pitches {layer dir pitch ...}] [-non_preferred] [-layers {..}]", "delete_tracks [-layer {..}] [-dir X|Y] [-all]", "report_tracks",
                "add_endcaps [-pre_cap c] [-post_cap c] [-prefix p]  (addEndCap)", "add_well_taps -cell c -cell_interval um [-checkerboard] [-prefix p]  (addWellTap)",
                "add_decaps [-cells {..}] [-count n] [-area {..}]  (addDeCap)", "add_fillers [-cells {..}] [-area {..}] [-prefix FILL]  (addFiller)",
                "delete_fillers | delete_decaps | delete_well_taps | delete_endcaps [-prefix p] [-cells {..}] [-area {..}]  (deleteFiller ...)", "report_physical_cells",
                "delete_instance -inst {pats} [-physical_only] [-force]",
                "unplace [-inst pats] [-all_std_cells] [-macros] [-physical_cells] [-pads] [-all] [-area {..}] [-override_fixed]  (unplaceAllInsts, unplaceAllBlocks)"]),
            ("DFT", &["set_dft_signal", "set_scan_configuration", "create_test_protocol", "dft_drc", "preview_dft", "insert_dft", "report_scan_chains", "write_scan_def",
                "insert_occ [-clocks {ports}] [-pulses n] [-test_clock name] [-atspeed_port name]",
                "insert_scan_compression -channels n | -ratio r [-clock port]",
                "insert_boundary_scan [-idcode hex] [-ir_length n] [-exclude_ports pats]", "write_bsdl file",
                "insert_mbist [-memories pats] [-algorithm mats+|march_c-|march_c+|march_x|march_y|march_b|checkerboard] [-control pins|tap] [-reset port]",
                "insert_lockup_latches", "restitch_scan_chains [-chain_count n] [-placement]",
                "write_test_mode_sdc -mode shift|capture|atspeed|bscan|mbist -output f [-shift_period ns]",
                "create_test_mode_scenarios [-modes {..}] [-shift_period ns] [-corner c] [-directory d]",
                "check_dft [-verbose]", "report_dft", "write_dft_ip dir"]),
            ("ATPG / test patterns", &["create_test_patterns [-fault_model stuck_at|transition] [-capture slow|atspeed] [-random_patterns n] [-abort_limit n] [-max_patterns n] [-seed n] [-no_compression]",
                "report_atpg [-faults]", "write_test_patterns -format stil|stil_flat|verilog -output f [-period ns] [-fast_period ns]",
                "write_simulation_models file.v", "write_mbist_testbench file [-clock_period ns]", "write_bscan_testbench file [-tck_period ns]"]),
            ("Checks", &["check_timing [-include {...}] [-verbose]", "check_design", "check_netlist", "check_mv_design", "cleanup_design [-unused_ports -multidriven -undriven -loops -dangling]"]),
            ("Reports", &["report_timing", "report_timing_format [{columns}] [-transition] [-capacitance] [-fanout] [-derate] [-user_derate] [-ocv] [-aocv] [-pocv] [-derates] [-remove] [-reset] [-help]", "report_qor", "report_constraints -all_violators", "report_area [-hierarchy]", "report_power", "report_threshold_voltage_group", "report_clock_gating", "report_clocks", "report_reference", "report_net_fanout", "report_design", "report_hierarchy", "report_power_domains", "report_exceptions", "report_ports"]),
            ("Output", &["write_verilog", "write_parasitics -output prefix [-corner c]", "write_def", "write_sdc", "save_upf"]),
];

fn t_corner_name(s: &Scenario) -> String {
    s.corner.clone()
}

impl Session {
    /// Set/clear the dont_use flag on every cell of `lib` matching `pat`; returns the match count.
    pub(crate) fn mark_dont_use(lib: &mut crate::liberty::Library, pat: &str, val: bool) -> usize {
        let mut n = 0;
        for c in lib.cells.values_mut() {
            if crate::netlist::glob(pat, &c.name) {
                c.dont_use = val;
                n += 1;
            }
        }
        n
    }
}

/// Join at most `n` names, then "... (+K more)" so huge instance arrays don't flood the log.
pub(crate) fn abbrev_list(v: &[String], n: usize) -> String {
    if v.len() <= n {
        v.join(", ")
    } else {
        format!("{}, ... (+{} more)", v[..n].join(", "), v.len() - n)
    }
}
