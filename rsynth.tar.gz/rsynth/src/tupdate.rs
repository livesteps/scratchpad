//! update_timing [-full]: explicit timing update after SDC / MMMC / derate / OCV edits, and the
//! MMMC edit commands that go with it (update_constraint_mode, update_delay_corner,
//! update_analysis_view, set_analysis_view). Each scenario keeps a signature of what its timing
//! depends on; an incremental update re-times only the scenarios whose inputs changed and says
//! what changed, -full re-times all of them and drops every cached timing result.

use crate::session::{args, Session};
use crate::tcl::{err, split_list, R};
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

#[derive(Clone, Debug, Default)]
pub struct TState {
    /// signatures: constraints, corner (libraries, derates, RC), OCV / app settings, design, parasitics
    pub sig: [u64; 5],
    pub res: Option<(f64, f64, usize, f64, f64, usize, usize)>,
}

const PARTS: [&str; 5] = ["constraints", "corner / derates", "OCV / analysis settings", "netlist / placement", "parasitics"];

fn h<T: std::fmt::Debug>(v: &T) -> u64 {
    let mut s = DefaultHasher::new();
    format!("{:?}", v).hash(&mut s);
    s.finish()
}

impl Session {
    fn timing_sig(&self, si: usize) -> [u64; 5] {
        let sc = &self.scens[si];
        let m = self.modes.iter().find(|m| m.name == sc.mode).map(|m| h(&m.sdc)).unwrap_or(0);
        let c = self.corners.iter().find(|c| c.name == sc.corner).map(|c| h(c)).unwrap_or(0);
        let app: Vec<(&String, &String)> = self.app.iter().filter(|(k, _)| k.starts_with("time.") || k.starts_with("timing")).collect();
        let o = h(&(format!("{:?}", self.ocv), &self.analysis_type, app, self.ann_delays.len()));
        let d = match &self.nl {
            Some(nl) => {
                let mut s = DefaultHasher::new();
                nl.name.hash(&mut s);
                for c in nl.cell_ids() {
                    let cl = nl.cell(c);
                    cl.name.hash(&mut s);
                    format!("{:?}", cl.kind).hash(&mut s);
                    if let Some((x, y)) = cl.loc { ((x * 1000.0) as i64, (y * 1000.0) as i64).hash(&mut s); }
                    for p in &cl.pins { p.net.hash(&mut s); }
                }
                s.finish()
            }
            None => 0,
        };
        let p = h(&(self.routes.is_some(), self.routed_rc.is_some(), self.spef_rc.keys().collect::<Vec<_>>(), self.spef_stats.len()));
        [m, c, o, d, p]
    }

    pub(crate) fn tupdate_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        match name {
            "update_timing" | "timing_update" | "updateTiming" => {
                let x = args(a, &["-scenarios", "-views"]);
                if self.nl.is_none() { return Some(err("update_timing: no design (UID-109)")); }
                let full = x.has("-full");
                let scens: Vec<usize> = match x.get("-scenarios").or(x.get("-views")) {
                    Some(v) => { let n = split_list(v); (0..self.scens.len()).filter(|i| n.iter().any(|p| crate::netlist::glob(p, &self.scens[*i].name))).collect() }
                    None => self.active(""),
                };
                if full {
                    // drop every cached timing result
                    self.tpaths.clear();
                    *self.pin_cache.borrow_mut() = (u64::MAX, Default::default());
                    *self.gr_cache.borrow_mut() = None;
                    self.phys_cache.borrow_mut().0 = u64::MAX;
                }
                self.bump_epoch();
                crate::out!("\n****************************************\nReport : update_timing{}\nDesign : {}\n****************************************", if full { " -full" } else { "" }, self.nl.as_ref().unwrap().name);
                crate::out!("  {:<16} {:<10} {:<10} {:<11} {:>9} {:>10} {:>5} {:>9} {:>10} {:>5} {:>7} {:>7}  {}", "Scenario", "Mode", "Corner", "Status", "WNS", "TNS", "NVP", "WHS", "THS", "NVH", "Endpts", "ms", "Changed");
                let mut updated = 0;
                for si in scens {
                    let sc = self.scens[si].clone();
                    let sig = self.timing_sig(si);
                    let prev = self.tupd.get(&sc.name).cloned();
                    let changed: Vec<&str> = match &prev {
                        Some(p) => (0..5).filter(|k| p.sig[*k] != sig[*k]).map(|k| PARTS[k]).collect(),
                        None => vec!["first update"],
                    };
                    let stale = full || !changed.is_empty() || prev.as_ref().map(|p| p.res.is_none()).unwrap_or(true);
                    let t0 = std::time::Instant::now();
                    let res = if stale {
                        match self.with_timing(si, |t| (t.wns, t.tns, t.nvp, t.whs, t.ths, t.nvh, t.endpoints.len())) {
                            Ok(r) => Some(r),
                            Err(e) => { crate::warn!("TIM-701", "update_timing: scenario '{}': {}", sc.name, match e { crate::tcl::Flow::Err(s) => s, _ => String::new() }); None }
                        }
                    } else { prev.as_ref().and_then(|p| p.res) };
                    let ms = t0.elapsed().as_secs_f64() * 1000.0;
                    if stale { updated += 1; }
                    let st = if !stale { "up to date" } else if full { "full" } else { "updated" };
                    let (w, tn, nv, wh, th, nh, ne) = res.unwrap_or((0.0, 0.0, 0, 0.0, 0.0, 0, 0));
                    crate::out!("  {:<16} {:<10} {:<10} {:<11} {:>9.4} {:>10.4} {:>5} {:>9.4} {:>10.4} {:>5} {:>7} {:>7.1}  {}", sc.name, sc.mode, sc.corner, st, w, tn, nv, if sc.hold { wh } else { 0.0 }, if sc.hold { th } else { 0.0 }, if sc.hold { nh } else { 0 }, ne, if stale { ms } else { 0.0 },
                        if changed.is_empty() { if full { "(forced)".to_string() } else { "-".to_string() } } else { changed.join(", ") });
                    self.tupd.insert(sc.name.clone(), TState { sig, res });
                }
                crate::info!("TIM-700", "update_timing{}: {} scenario(s) re-timed", if full { " -full" } else { "" }, updated);
                Some(Ok(updated.to_string()))
            }
            "report_timing_update_status" | "timing_update_status" | "report_timing_status" => {
                crate::out!("\n  {:<16} {:<12}  {}", "Scenario", "Status", "Changed since the last update_timing");
                let mut stale = 0;
                for si in 0..self.scens.len() {
                    let sc = self.scens[si].name.clone();
                    let sig = self.timing_sig(si);
                    let (st, ch) = match self.tupd.get(&sc) {
                        None => ("not updated", "-".to_string()),
                        Some(p) => { let c: Vec<&str> = (0..5).filter(|k| p.sig[*k] != sig[*k]).map(|k| PARTS[k]).collect(); if c.is_empty() { ("up to date", "-".into()) } else { ("stale", c.join(", ")) } }
                    };
                    if st != "up to date" { stale += 1; }
                    crate::out!("  {:<16} {:<12}  {}", sc, st, ch);
                }
                Some(Ok(stale.to_string()))
            }
            // ---- MMMC edits (Innovus style)
            "update_constraint_mode" => {
                let x = args(a, &["-name", "-sdc_files", "-ilm_sdc_files"]);
                let Some(m) = x.get("-name").cloned() else { return Some(err("update_constraint_mode: -name required (MV-101)")) };
                let Some(mi) = self.modes.iter().position(|q| q.name == m) else { return Some(err(&format!("update_constraint_mode: mode '{}' does not exist (MV-102)", m))) };
                let files = x.get("-sdc_files").map(|v| split_list(v)).unwrap_or_default();
                if !x.has("-append") { self.modes[mi].sdc = Default::default(); }
                let cur = self.cur_mode;
                self.cur_mode = mi;
                let mut r = Ok(String::new());
                for f in &files {
                    if let Some(e) = self.cmd("read_sdc", &[f.clone()]) { if e.is_err() { r = e; break; } }
                }
                self.cur_mode = cur;
                // clock trees built: their clocks stay propagated
                if !self.cts_nets.is_empty() { self.set_all_propagated(true); }
                crate::info!("MV-103", "Constraint mode '{}' {} from {} SDC file(s); run update_timing", m, if x.has("-append") { "extended" } else { "reloaded" }, files.len());
                Some(r.map(|_| m))
            }
            "update_delay_corner" | "update_corner" => {
                let x = args(a, &["-name", "-library_set", "-libs", "-temperature", "-voltage", "-process", "-r_scale", "-c_scale", "-spef", "-late_cell_derate", "-early_cell_derate", "-late_net_derate", "-early_net_derate"]);
                let Some(cn) = x.get("-name").cloned() else { return Some(err("update_delay_corner: -name required (MV-104)")) };
                let Some(ci) = self.corners.iter().position(|c| c.name == cn) else { return Some(err(&format!("update_delay_corner: corner '{}' does not exist (MV-105)", cn))) };
                let mut what = vec![];
                if let Some(v) = x.get("-library_set").or(x.get("-libs")) {
                    let names = split_list(v);
                    let ids: Vec<usize> = names.iter().filter_map(|n| self.libs.iter().position(|l| crate::netlist::glob(n, &l.name))).collect();
                    if ids.is_empty() { return Some(err(&format!("update_delay_corner: no library matches {} (MV-106)", v))); }
                    self.corners[ci].libs = ids;
                    what.push("libraries");
                }
                let c = &mut self.corners[ci];
                if let Some(v) = x.num("-temperature") { c.temperature = Some(v); what.push("temperature"); }
                if let Some(v) = x.num("-voltage") { c.voltage = Some(v); what.push("voltage"); }
                if let Some(v) = x.get("-process") { c.process_label = v.clone(); what.push("process"); }
                if let Some(v) = x.num("-r_scale") { c.r_scale = v; what.push("R scale"); }
                if let Some(v) = x.num("-c_scale") { c.c_scale = v; what.push("C scale"); }
                if let Some(v) = x.get("-spef") { c.spef = Some(v.clone()); what.push("SPEF"); }
                if let Some(v) = x.num("-late_cell_derate") { c.late_cell = v; what.push("late cell derate"); }
                if let Some(v) = x.num("-early_cell_derate") { c.early_cell = v; what.push("early cell derate"); }
                if let Some(v) = x.num("-late_net_derate") { c.late_net = v; what.push("late net derate"); }
                if let Some(v) = x.num("-early_net_derate") { c.early_net = v; what.push("early net derate"); }
                crate::info!("MV-107", "Delay corner '{}' updated: {}; run update_timing", cn, if what.is_empty() { "nothing".to_string() } else { what.join(", ") });
                Some(Ok(cn))
            }
            "update_analysis_view" | "update_scenario" => {
                let x = args(a, &["-name", "-constraint_mode", "-mode", "-delay_corner", "-corner"]);
                let Some(v) = x.get("-name").cloned() else { return Some(err("update_analysis_view: -name required (MV-108)")) };
                let Some(si) = self.scens.iter().position(|s| s.name == v) else { return Some(err(&format!("update_analysis_view: view / scenario '{}' does not exist (MV-109)", v))) };
                if let Some(m) = x.get("-constraint_mode").or(x.get("-mode")) {
                    if !self.modes.iter().any(|q| &q.name == m) { return Some(err(&format!("update_analysis_view: mode '{}' does not exist (MV-102)", m))); }
                    self.scens[si].mode = m.clone();
                }
                if let Some(c) = x.get("-delay_corner").or(x.get("-corner")) {
                    if !self.corners.iter().any(|q| &q.name == c) { return Some(err(&format!("update_analysis_view: corner '{}' does not exist (MV-105)", c))); }
                    self.scens[si].corner = c.clone();
                }
                crate::info!("MV-110", "Analysis view '{}': mode {}, corner {}; run update_timing", v, self.scens[si].mode, self.scens[si].corner);
                Some(Ok(v))
            }
            "set_analysis_view" | "set_analysis_views" => {
                let x = args(a, &["-setup", "-hold", "-leakage", "-dynamic"]);
                let pick = |k: &str| -> Option<Vec<String>> { x.get(k).map(|v| split_list(v)) };
                let (su, ho) = (pick("-setup"), pick("-hold"));
                if su.is_none() && ho.is_none() { return Some(err("set_analysis_view: -setup and / or -hold views required (MV-111)")); }
                for (k, l) in [("setup", &su), ("hold", &ho)] {
                    if let Some(l) = l { for v in l.iter() { if !self.scens.iter().any(|s| &s.name == v) { return Some(err(&format!("set_analysis_view: -{} view '{}' does not exist (MV-109)", k, v))); } } }
                }
                for s in self.scens.iter_mut() {
                    if let Some(l) = &su { s.setup = l.contains(&s.name); }
                    if let Some(l) = &ho { s.hold = l.contains(&s.name); }
                    s.active = s.setup || s.hold || s.leakage || s.dynamic;
                }
                crate::info!("MV-112", "Analysis views: setup {{{}}} hold {{{}}}", self.scens.iter().filter(|s| s.setup).map(|s| s.name.clone()).collect::<Vec<_>>().join(" "), self.scens.iter().filter(|s| s.hold).map(|s| s.name.clone()).collect::<Vec<_>>().join(" "));
                Some(Ok(String::new()))
            }
            // ---- free / reset the design so the same session can load again
            "free_design" | "freeDesign" | "reset_session" => {
                let keep_libs = a.iter().any(|x| x == "-keep_libs" || x == "-keep_libraries");
                let keep_app = a.iter().any(|x| x == "-keep_app_options" || x == "-keep_app_vars");
                let design = self.nl.as_ref().map(|n| n.name.clone()).unwrap_or_default();
                let (nlib, nlef) = (self.libs.len(), self.lef.len());
                let mut fresh = Session::new();
                std::mem::swap(&mut fresh.interp, &mut self.interp);
                if keep_libs {
                    fresh.libs = std::mem::take(&mut self.libs);
                    fresh.lef = std::mem::take(&mut self.lef);
                    fresh.lef_layers = std::mem::take(&mut self.lef_layers);
                    fresh.lef_sites = std::mem::take(&mut self.lef_sites);
                    fresh.pgx.via_rules = std::mem::take(&mut self.pgx.via_rules);
                    fresh.dont_use_cmds = std::mem::take(&mut self.dont_use_cmds);
                    fresh.corners = std::mem::take(&mut self.corners);
                    for c in fresh.corners.iter_mut() { c.obj_derates.clear(); }
                }
                if keep_app { fresh.app = std::mem::take(&mut self.app); }
                *self = fresh;
                crate::info!("DES-110", "Freed design '{}'{}: netlist, floorplan, routes, constraints, scenarios, CTS / PG / DFT state{}; the session can load a design again",
                    if design.is_empty() { "(none)".to_string() } else { design }, if keep_libs { String::new() } else { format!(", {} libraries, {} LEF macros", nlib, nlef) }, if keep_app { "; app options kept" } else { "" });
                Some(Ok(String::new()))
            }
            "reset_design" => {
                // DC style: remove the constraints and user attributes of the current design, keep the netlist
                if self.nl.is_none() { return Some(err("reset_design: no design (UID-109)")); }
                let n = self.modes.len();
                for m in self.modes.iter_mut() { m.sdc = Default::default(); }
                for c in self.corners.iter_mut() {
                    c.late_cell = 1.0; c.early_cell = 1.0; c.late_net = 1.0; c.early_net = 1.0;
                    c.late_cell_clk = None; c.early_cell_clk = None; c.late_net_clk = None; c.early_net_clk = None;
                    c.obj_derates.clear();
                }
                self.ann_delays.clear();
                self.user_props.clear();
                self.ctspec = Default::default();
                self.tupd.clear();
                self.tpaths.clear();
                if let Some(nl) = self.nl.as_mut() {
                    for c in nl.cell_ids() { let cl = nl.cell_mut(c); if !cl.has_attr("cts") && !cl.has_attr("hier_port") { cl.dont_touch = false; } cl.attrs.retain(|a| a != "size_only"); }
                    for net in nl.net_ids() { nl.net_mut(net).dont_touch = false; }
                }
                self.bump_epoch();
                crate::info!("DES-111", "reset_design: constraints of {} mode(s), derates, annotated delays, dont_touch / size_only and user attributes removed; netlist kept", n);
                Some(Ok(String::new()))
            }
            _ => None,
        }
    }
}
