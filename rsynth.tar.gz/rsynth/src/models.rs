//! Timing-model export:
//!   * Liberty writer (NLDM lookup tables)
//!   * extract_model / write_etm: extracted timing model, characterized by re-timing the block
//!     with zero I/O delays over input-transition x output-load sweeps (setup/hold constraint
//!     arcs to clock pins, clock->output arcs, combinational arcs, output transitions, pin caps)
//!   * QTM: create_qtm_model / create_qtm_port / set_qtm_port_load / create_qtm_delay_arc /
//!     create_qtm_constraint_arc / report_qtm_model / save_qtm_model (write_qtm)
//!   * write_lib: Liberty model of the current design's ports (e.g. a stub Verilog module) from
//!     user-given delays, constraints and slopes
//!   * create_ilm / write_ilm: interface logic model netlist (input->first register, last
//!     register->output, combinational I/O paths, the clock trees of those registers), with an
//!     interface-timing comparison against the full design
//!   * write_ndm: an NDM-style bundle directory (ETM .lib + LEF abstract + ILM netlist + manifest);
//!     it is not the binary Synopsys NDM format
use crate::cons::{Constraints, IoDelay, Obj};
use crate::netlist::{Dir, Netlist, PinRef};
use crate::paths::PathQuery;
use crate::session::*;
use crate::sta::{LibSet, Timing};
use crate::tcl::{split_list, Flow};
use std::collections::{BTreeMap, HashMap, HashSet};
use std::fmt::Write;
type R = Result<String, Flow>;

fn err(m: impl Into<String>) -> R {
    Err(Flow::Err(m.into()))
}

// ------------------------------------------------------------------ Liberty model

#[derive(Clone, Debug, Default)]
pub struct Tbl {
    pub i1: Vec<f64>,
    pub i2: Vec<f64>,
    pub v: Vec<Vec<f64>>,
    /// a 1-D delay table indexed by output load (total_output_net_capacitance) instead of the
    /// input transition, e.g. clock->output arcs
    pub load_axis: bool,
}
impl Tbl {
    pub fn scalar(x: f64) -> Tbl {
        Tbl { i1: vec![], i2: vec![], v: vec![vec![x]], load_axis: false }
    }
    pub fn by_load(i1: Vec<f64>, v: Vec<f64>) -> Tbl {
        Tbl { i1, i2: vec![], v: vec![v], load_axis: true }
    }
}

#[derive(Clone, Debug, Default)]
pub struct ArcM {
    pub related: String,
    pub ttype: String,
    pub sense: Option<String>,
    pub rise: Option<Tbl>,
    pub fall: Option<Tbl>,
    pub rise_tr: Option<Tbl>,
    pub fall_tr: Option<Tbl>,
    /// constraint arc (rise_constraint / fall_constraint)
    pub constraint: bool,
}

#[derive(Clone, Debug, Default)]
pub struct PinM {
    pub name: String,
    pub dir: String,
    pub cap: f64,
    pub clock: bool,
    pub max_cap: Option<f64>,
    pub max_tran: Option<f64>,
    pub arcs: Vec<ArcM>,
}

#[derive(Clone, Debug, Default)]
pub struct CellM {
    pub lib: String,
    pub name: String,
    pub area: f64,
    pub model_type: String,
    pub comment: String,
    pub pins: Vec<PinM>,
    pub voltage: f64,
    pub temperature: f64,
}

fn fl(x: f64) -> String {
    let s = format!("{:.6}", x);
    let s = s.trim_end_matches('0').trim_end_matches('.').to_string();
    if s.is_empty() || s == "-0" {
        "0".into()
    } else {
        s
    }
}

pub fn write_liberty(c: &CellM) -> String {
    let mut s = String::new();
    // collect the table templates used
    let mut tmpl: BTreeMap<String, (String, Vec<f64>, Option<String>, Vec<f64>)> = BTreeMap::new();
    let name_of = |t: &Tbl, constraint: bool, tmpl: &mut BTreeMap<String, (String, Vec<f64>, Option<String>, Vec<f64>)>| -> String {
        if t.i1.is_empty() {
            return "scalar".into();
        }
        let (v1, v2) = if constraint { ("constrained_pin_transition", Some("related_pin_transition")) } else if t.load_axis { ("total_output_net_capacitance", None) } else { ("input_net_transition", Some("total_output_net_capacitance")) };
        let key = format!("{}_{}x{}_{}", if constraint { "ctmpl" } else { "dtmpl" }, t.i1.len(), t.i2.len(), tmpl.len());
        // reuse an identical template
        for (k, (a, i1, b, i2)) in tmpl.iter() {
            if a == v1 && *i1 == t.i1 && *i2 == t.i2 && b.as_deref() == (if t.i2.is_empty() { None } else { v2 }) {
                return k.clone();
            }
        }
        tmpl.insert(key.clone(), (v1.to_string(), t.i1.clone(), if t.i2.is_empty() { None } else { v2.map(|x| x.to_string()) }, t.i2.clone()));
        key
    };
    // pre-assign template names
    let mut assigned: Vec<Vec<[String; 4]>> = vec![];
    for p in &c.pins {
        let mut v = vec![];
        for a in &p.arcs {
            let n = |t: &Option<Tbl>, tmpl: &mut BTreeMap<_, _>| t.as_ref().map(|t| name_of(t, a.constraint, tmpl)).unwrap_or_default();
            v.push([n(&a.rise, &mut tmpl), n(&a.fall, &mut tmpl), n(&a.rise_tr, &mut tmpl), n(&a.fall_tr, &mut tmpl)]);
        }
        assigned.push(v);
    }
    let _ = writeln!(s, "/* {} */", c.comment);
    let _ = writeln!(s, "library ({}) {{", c.lib);
    let _ = writeln!(s, "  delay_model : table_lookup ;\n  time_unit : \"1ns\" ;\n  voltage_unit : \"1V\" ;\n  current_unit : \"1mA\" ;\n  pulling_resistance_unit : \"1kohm\" ;\n  leakage_power_unit : \"1nW\" ;\n  capacitive_load_unit (1, pf) ;");
    let _ = writeln!(s, "  nom_process : 1 ;\n  nom_voltage : {} ;\n  nom_temperature : {} ;", fl(c.voltage), fl(c.temperature));
    let _ = writeln!(s, "  input_threshold_pct_rise : 50 ;\n  input_threshold_pct_fall : 50 ;\n  output_threshold_pct_rise : 50 ;\n  output_threshold_pct_fall : 50 ;\n  slew_lower_threshold_pct_rise : 20 ;\n  slew_upper_threshold_pct_rise : 80 ;\n  slew_lower_threshold_pct_fall : 20 ;\n  slew_upper_threshold_pct_fall : 80 ;");
    for (k, (v1, i1, v2, i2)) in &tmpl {
        let _ = writeln!(s, "  lu_table_template ({}) {{\n    variable_1 : {} ;", k, v1);
        if let Some(v2) = v2 {
            let _ = writeln!(s, "    variable_2 : {} ;", v2);
        }
        let _ = writeln!(s, "    index_1 (\"{}\") ;", i1.iter().map(|x| fl(*x)).collect::<Vec<_>>().join(", "));
        if v2.is_some() {
            let _ = writeln!(s, "    index_2 (\"{}\") ;", i2.iter().map(|x| fl(*x)).collect::<Vec<_>>().join(", "));
        }
        let _ = writeln!(s, "  }}");
    }
    let _ = writeln!(s, "  cell ({}) {{\n    area : {} ;\n    dont_touch : true ;\n    dont_use : true ;\n    interface_timing : true ;\n    timing_model_type : \"{}\" ;", c.name, fl(c.area), c.model_type);
    let table = |s: &mut String, kind: &str, t: &Tbl, tn: &str| {
        let _ = writeln!(s, "        {} ({}) {{", kind, tn);
        if !t.i1.is_empty() {
            let _ = writeln!(s, "          index_1 (\"{}\") ;", t.i1.iter().map(|x| fl(*x)).collect::<Vec<_>>().join(", "));
            if !t.i2.is_empty() {
                let _ = writeln!(s, "          index_2 (\"{}\") ;", t.i2.iter().map(|x| fl(*x)).collect::<Vec<_>>().join(", "));
            }
        }
        let rows: Vec<String> = t.v.iter().map(|r| format!("\"{}\"", r.iter().map(|x| fl(*x)).collect::<Vec<_>>().join(", "))).collect();
        let _ = writeln!(s, "          values ({}) ;\n        }}", rows.join(", \\\n                  "));
    };
    for (pi, p) in c.pins.iter().enumerate() {
        let _ = writeln!(s, "    pin (\"{}\") {{\n      direction : {} ;", p.name, p.dir);
        if p.dir != "output" {
            let _ = writeln!(s, "      capacitance : {} ;", fl(p.cap));
        }
        if p.clock {
            let _ = writeln!(s, "      clock : true ;");
        }
        if let Some(m) = p.max_cap {
            let _ = writeln!(s, "      max_capacitance : {} ;", fl(m));
        }
        if let Some(m) = p.max_tran {
            let _ = writeln!(s, "      max_transition : {} ;", fl(m));
        }
        for (ai, a) in p.arcs.iter().enumerate() {
            let tn = &assigned[pi][ai];
            let _ = writeln!(s, "      timing () {{\n        related_pin : \"{}\" ;\n        timing_type : {} ;", a.related, a.ttype);
            if let Some(se) = &a.sense {
                let _ = writeln!(s, "        timing_sense : {} ;", se);
            }
            let (rk, fk) = if a.constraint { ("rise_constraint", "fall_constraint") } else { ("cell_rise", "cell_fall") };
            if let Some(t) = &a.rise {
                table(&mut s, rk, t, &tn[0]);
            }
            if let Some(t) = &a.fall {
                table(&mut s, fk, t, &tn[1]);
            }
            if let Some(t) = &a.rise_tr {
                table(&mut s, "rise_transition", t, &tn[2]);
            }
            if let Some(t) = &a.fall_tr {
                table(&mut s, "fall_transition", t, &tn[3]);
            }
            let _ = writeln!(s, "      }}");
        }
        let _ = writeln!(s, "    }}");
    }
    let _ = writeln!(s, "  }}\n}}");
    s
}

// ------------------------------------------------------------------ QTM

#[derive(Clone, Debug, Default)]
pub struct Qtm {
    pub name: String,
    pub ports: Vec<(String, String)>,
    pub loads: HashMap<String, f64>,
    pub tran: HashMap<String, f64>,
    /// (from, to, value, edge rise/fall/both, is_clock_edge)
    pub delays: Vec<(String, String, f64, String)>,
    /// (setup|hold, clock, data, value, edge)
    pub cons: Vec<(String, String, String, f64, String)>,
    pub area: f64,
}

// ------------------------------------------------------------------ session commands

impl Session {
    pub(crate) fn model_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "extract_model" | "write_etm" | "create_etm" => self.c_extract_model(a),
            "write_lib" | "write_stub_lib" | "create_lib_model" => self.c_write_lib_stub(a),
            "create_qtm_model" => {
                let n = a.iter().find(|x| !x.starts_with('-')).cloned().unwrap_or("qtm".into());
                self.qtm = Some(Qtm { name: n.clone(), ..Default::default() });
                crate::info!("QTM-100", "Created quick timing model '{}'", n);
                Ok(n)
            }
            "create_qtm_port" | "set_qtm_port_load" | "set_qtm_port_transition" | "create_qtm_delay_arc" | "create_qtm_constraint_arc" | "set_qtm_area" | "report_qtm_model" | "save_qtm_model" | "write_qtm" => self.c_qtm(name, a),
            "create_ilm" | "write_ilm" => self.c_write_ilm(a),
            "write_ndm" | "create_ndm" | "write_frame" => self.c_write_ndm(a),
            "write_lef" | "write_lef_abstract" => {
                let x = args(a, &["-output"]);
                let f = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or("out.lef".into());
                let s = match self.lef_abstract() {
                    Ok(s) => s,
                    Err(e) => return Some(Err(e)),
                };
                Some(std::fs::write(&f, s).map(|_| f.clone()).map_err(|e| Flow::Err(e.to_string()))).unwrap()
            }
            _ => return None,
        })
    }

    fn c_qtm(&mut self, name: &str, a: &[String]) -> R {
        let x = args(a, &["-type", "-value", "-from", "-to", "-edge", "-output", "-format", "-ports"]);
        let Some(q) = self.qtm.as_mut() else { return err(format!("{}: no QTM model; use create_qtm_model first (QTM-001)", name)) };
        let edge = x.get("-edge").cloned().unwrap_or("both".into());
        let names = |s: &str| -> Vec<String> { split_list(s).into_iter().map(|p| Obj::parse(&p).map(|o| o.name().to_string()).unwrap_or(p)).collect() };
        match name {
            "create_qtm_port" => {
                let ty = x.get("-type").cloned().unwrap_or("input".into());
                if !["input", "output", "inout", "clock"].contains(&ty.as_str()) {
                    return err(format!("create_qtm_port: -type must be input, output, inout or clock (QTM-002)"));
                }
                let mut n = 0;
                for p in x.pos.iter().flat_map(|p| names(p)) {
                    q.ports.retain(|(a, _)| a != &p);
                    q.ports.push((p, ty.clone()));
                    n += 1;
                }
                Ok(n.to_string())
            }
            "set_qtm_port_load" | "set_qtm_port_transition" => {
                let Some(v) = x.num("-value").or(x.pos.iter().find_map(|p| p.parse().ok())) else { return err(format!("{}: -value required", name)) };
                let ps: Vec<String> = x.pos.iter().filter(|p| p.parse::<f64>().is_err()).flat_map(|p| names(p)).collect();
                for p in &ps {
                    if name == "set_qtm_port_load" {
                        q.loads.insert(p.clone(), v);
                    } else {
                        q.tran.insert(p.clone(), v);
                    }
                }
                Ok(ps.len().to_string())
            }
            "set_qtm_area" => {
                q.area = x.num("-value").or(x.pos.iter().find_map(|p| p.parse().ok())).unwrap_or(0.0);
                Ok(fl(q.area))
            }
            "create_qtm_delay_arc" => {
                let (Some(f), Some(t), Some(v)) = (x.get("-from"), x.get("-to"), x.num("-value")) else { return err("create_qtm_delay_arc: -from -to -value required (QTM-003)") };
                for fr in names(f) {
                    for to in names(t) {
                        q.delays.push((fr.clone(), to, v, edge.clone()));
                    }
                }
                Ok(String::new())
            }
            "create_qtm_constraint_arc" => {
                let kind = if x.has("-hold") { "hold" } else { "setup" };
                let (Some(f), Some(t), Some(v)) = (x.get("-from"), x.get("-to"), x.num("-value")) else { return err("create_qtm_constraint_arc: -setup|-hold -from clock -to port -value required (QTM-004)") };
                for fr in names(f) {
                    for to in names(t) {
                        q.cons.push((kind.into(), fr.clone(), to, v, edge.clone()));
                    }
                }
                Ok(String::new())
            }
            "report_qtm_model" => {
                crate::out!("\n  QTM model {}  (area {})", q.name, fl(q.area));
                for (p, t) in &q.ports {
                    crate::out!("    port {:<24} {:<7} load {}", p, t, q.loads.get(p).map(|v| fl(*v)).unwrap_or("-".into()));
                }
                for (f, t, v, e) in &q.delays {
                    crate::out!("    delay      {} -> {}  {} ({})", f, t, fl(*v), e);
                }
                for (k, f, t, v, e) in &q.cons {
                    crate::out!("    {:<10} {} -> {}  {} ({})", k, f, t, fl(*v), e);
                }
                Ok(q.name.clone())
            }
            _ => {
                // save_qtm_model / write_qtm
                let base = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or(q.name.clone());
                let f = if base.ends_with(".lib") { base } else { format!("{}.lib", base) };
                let q = q.clone();
                let is_clock = |p: &str| q.ports.iter().any(|(a, t)| a == p && t == "clock");
                let mut pins = vec![];
                for (p, t) in &q.ports {
                    let mut pm = PinM { name: p.clone(), dir: if t == "output" { "output".into() } else if t == "inout" { "inout".into() } else { "input".into() }, cap: q.loads.get(p).copied().unwrap_or(0.0), clock: t == "clock", ..Default::default() };
                    let tr = q.tran.get(p).copied().unwrap_or(0.05);
                    for (fr, to, v, e) in &q.delays {
                        if to != p {
                            continue;
                        }
                        let clk = is_clock(fr);
                        pm.arcs.push(ArcM {
                            related: fr.clone(),
                            ttype: if clk { if e == "fall" { "falling_edge".into() } else { "rising_edge".into() } } else { "combinational".into() },
                            sense: if clk { None } else { Some("non_unate".into()) },
                            rise: Some(Tbl::scalar(*v)),
                            fall: Some(Tbl::scalar(*v)),
                            rise_tr: Some(Tbl::scalar(tr)),
                            fall_tr: Some(Tbl::scalar(tr)),
                            constraint: false,
                        });
                    }
                    for (k, fr, to, v, e) in &q.cons {
                        if to != p {
                            continue;
                        }
                        pm.arcs.push(ArcM {
                            related: fr.clone(),
                            ttype: format!("{}_{}", k, if e == "fall" { "falling" } else { "rising" }),
                            rise: Some(Tbl::scalar(*v)),
                            fall: Some(Tbl::scalar(*v)),
                            constraint: true,
                            ..Default::default()
                        });
                    }
                    pins.push(pm);
                }
                let c = CellM { lib: format!("{}_lib", q.name), name: q.name.clone(), area: q.area, model_type: "quick".into(), comment: format!("Quick timing model {} written by RSynth", q.name), pins, voltage: 1.0, temperature: 25.0 };
                std::fs::write(&f, write_liberty(&c)).map_err(|e| Flow::Err(format!("{}: {}", f, e)))?;
                crate::info!("QTM-200", "Wrote QTM '{}' as Liberty '{}' ({} ports, {} delay arcs, {} constraint arcs)", q.name, f, q.ports.len(), q.delays.len(), q.cons.len());
                Ok(f)
            }
        }
    }

    /// write_lib from the current design's ports (e.g. an elaborated stub module)
    fn c_write_lib_stub(&mut self, a: &[String]) -> R {
        let x = args(
            a,
            &["-output", "-cell_name", "-library_name", "-clock", "-clocks", "-related_clock", "-setup", "-hold", "-clk_to_q", "-clock_to_output", "-delay", "-comb_delay", "-input_cap", "-max_transition", "-max_capacitance", "-area", "-k_load", "-k_tran", "-out_tran", "-index_1", "-index_2", "-comb_arcs", "-voltage", "-temperature"],
        );
        let nl = self.nl()?;
        let cell = x.get("-cell_name").cloned().unwrap_or(nl.name.clone());
        let f = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or(format!("{}.lib", cell));
        let clocks: Vec<String> = x.get("-clock").or(x.get("-clocks")).or(x.get("-related_clock")).map(|s| split_list(s).into_iter().map(|p| Obj::parse(&p).map(|o| o.name().to_string()).unwrap_or(p)).collect()).unwrap_or_default();
        for c in &clocks {
            if nl.port_by_name(c).is_none() {
                return err(format!("write_lib: clock port '{}' is not a port of {} (LIB-301)", c, nl.name));
            }
        }
        let num = |k: &str, d: f64| x.num(k).unwrap_or(d);
        let i1: Vec<f64> = x.get("-index_1").map(|s| split_list(s).iter().filter_map(|v| v.parse().ok()).collect()).unwrap_or(vec![0.01, 0.05, 0.2]);
        let i2: Vec<f64> = x.get("-index_2").map(|s| split_list(s).iter().filter_map(|v| v.parse().ok()).collect()).unwrap_or(vec![0.001, 0.01, 0.05]);
        let (kl, kt) = (num("-k_load", 2.0), num("-k_tran", 0.3));
        let out_tr = num("-out_tran", 0.03);
        let d2 = |base: f64| Tbl { i1: i1.clone(), i2: i2.clone(), v: i1.iter().map(|t| i2.iter().map(|l| base + kl * l + kt * t).collect()).collect(), load_axis: false };
        let t2 = || Tbl { i1: i1.clone(), i2: i2.clone(), v: i1.iter().map(|t| i2.iter().map(|l| out_tr + 2.0 * kl * l + 0.1 * t).collect()).collect(), load_axis: false };
        let c1 = |base: f64| Tbl { i1: i1.clone(), i2: vec![], v: vec![i1.iter().map(|t| base + 0.2 * t).collect()], load_axis: false };
        let clk_q = |base: f64| Tbl::by_load(i2.clone(), i2.iter().map(|l| base + kl * l).collect());
        let clk_q_tr = || Tbl::by_load(i2.clone(), i2.iter().map(|l| out_tr + 2.0 * kl * l).collect());
        let inputs: Vec<String> = nl.port_ids().into_iter().filter(|p| nl.ports[*p].dir != Dir::Out).map(|p| nl.ports[p].name.clone()).collect();
        let outputs: Vec<String> = nl.port_ids().into_iter().filter(|p| nl.ports[*p].dir != Dir::In).map(|p| nl.ports[p].name.clone()).collect();
        let comb = x.has("-comb_arcs") || clocks.is_empty() || x.get("-delay").or(x.get("-comb_delay")).is_some();
        let mut pins = vec![];
        for p in &inputs {
            let mut pm = PinM { name: p.clone(), dir: "input".into(), cap: num("-input_cap", 0.002), clock: clocks.contains(p), max_tran: x.num("-max_transition"), ..Default::default() };
            if !pm.clock {
                for c in &clocks {
                    pm.arcs.push(ArcM { related: c.clone(), ttype: "setup_rising".into(), rise: Some(c1(num("-setup", 0.1))), fall: Some(c1(num("-setup", 0.1))), constraint: true, ..Default::default() });
                    pm.arcs.push(ArcM { related: c.clone(), ttype: "hold_rising".into(), rise: Some(c1(num("-hold", 0.02))), fall: Some(c1(num("-hold", 0.02))), constraint: true, ..Default::default() });
                }
            }
            pins.push(pm);
        }
        for p in &outputs {
            let mut pm = PinM { name: p.clone(), dir: "output".into(), max_cap: x.num("-max_capacitance").or(Some(i2.last().copied().unwrap_or(0.1))), max_tran: x.num("-max_transition"), ..Default::default() };
            for c in &clocks {
                let v = num("-clk_to_q", num("-clock_to_output", 0.25));
                pm.arcs.push(ArcM { related: c.clone(), ttype: "rising_edge".into(), rise: Some(clk_q(v)), fall: Some(clk_q(v)), rise_tr: Some(clk_q_tr()), fall_tr: Some(clk_q_tr()), ..Default::default() });
            }
            if comb {
                for i in inputs.iter().filter(|i| !clocks.contains(i)) {
                    let v = num("-delay", num("-comb_delay", 0.2));
                    pm.arcs.push(ArcM { related: i.clone(), ttype: "combinational".into(), sense: Some("non_unate".into()), rise: Some(d2(v)), fall: Some(d2(v)), rise_tr: Some(t2()), fall_tr: Some(t2()), ..Default::default() });
                }
            }
            pins.push(pm);
        }
        let c = CellM {
            lib: x.get("-library_name").cloned().unwrap_or(format!("{}_lib", cell)),
            name: cell.clone(),
            area: num("-area", 100.0),
            model_type: "stub".into(),
            comment: format!("Liberty model of '{}' ports written by RSynth write_lib (user-specified timing)", nl.name),
            pins,
            voltage: num("-voltage", 0.8),
            temperature: num("-temperature", 25.0),
        };
        std::fs::write(&f, write_liberty(&c)).map_err(|e| Flow::Err(format!("{}: {}", f, e)))?;
        crate::info!("LIB-300", "Wrote Liberty model '{}' for cell {}: {} input(s), {} output(s), clocks {:?}{}", f, cell, inputs.len(), outputs.len(), clocks, if comb { ", combinational arcs" } else { "" });
        Ok(f)
    }

    // ------------------------------------------------------------------ ETM

    /// characterize the block: returns the Liberty cell model
    pub(crate) fn characterize(&self, si: usize, trs: &[f64], loads: &[f64], early: bool) -> Result<CellM, Flow> {
        let nl = self.nl()?;
        let sc = self.scens[si].clone();
        let mode = self.modes.iter().find(|m| m.name == sc.mode).map(|m| m.sdc.clone()).unwrap_or_else(|| self.modes[0].sdc.clone());
        let corner = self.corners.iter().find(|c| c.name == sc.corner).cloned().unwrap_or(crate::cons::Corner::new("default"));
        let corner = self.corner_libs_pub(&corner);
        let ls = self.libset(&corner);
        // clock source ports
        let mut clock_port: HashMap<String, String> = HashMap::new(); // port -> clock
        for c in &mode.clocks {
            if c.gen.is_some() || c.is_virtual() {
                continue;
            }
            for s in &c.sources {
                if let Obj::Port(p) = s {
                    clock_port.insert(p.clone(), c.name.clone());
                }
            }
        }
        // the clock an I/O port is timed against: its existing delay's clock, else the first clock
        let first_clk = mode.clocks.iter().find(|c| !c.is_virtual() && c.gen.is_none()).map(|c| c.name.clone());
        let io_clock = |p: &str| -> Option<String> {
            mode.io.iter().find(|d| d.obj.name() == p).and_then(|d| d.clock.clone()).filter(|c| mode.clocks.iter().any(|k| &k.name == c && !k.is_virtual())).or(first_clk.clone())
        };
        let inputs: Vec<usize> = nl.port_ids().into_iter().filter(|p| nl.ports[*p].dir != Dir::Out && !clock_port.contains_key(&nl.ports[*p].name)).collect();
        let outputs: Vec<usize> = nl.port_ids().into_iter().filter(|p| nl.ports[*p].dir != Dir::In).collect();
        // characterization constraints: same clocks and exceptions, zero I/O delays, no uncertainty
        let build = |tr: f64, ld: f64| -> Constraints {
            let mut c = mode.clone();
            for k in c.clocks.iter_mut() {
                k.unc_setup = 0.0;
                k.unc_hold = 0.0;
            }
            c.io.clear();
            for &p in &inputs {
                let n = &nl.ports[p].name;
                if let Some(ck) = io_clock(n) {
                    c.io.push(IoDelay { obj: Obj::Port(n.clone()), clock: Some(ck), clock_fall: false, max: Some(0.0), min: Some(0.0), is_input: true });
                }
            }
            for &p in &outputs {
                let n = &nl.ports[p].name;
                if let Some(ck) = io_clock(n) {
                    c.io.push(IoDelay { obj: Obj::Port(n.clone()), clock: Some(ck), clock_fall: false, max: Some(0.0), min: Some(0.0), is_input: false });
                }
            }
            c.driving_cell.clear();
            c.input_tran = inputs.iter().map(|p| (Obj::Port(nl.ports[*p].name.clone()), tr)).collect();
            c.loads = outputs.iter().map(|p| (Obj::Port(nl.ports[*p].name.clone()), ld)).collect();
            c.path_margins.clear();
            c
        };
        type Key = (usize, usize, u8); // (from port, to port, rf)
        let nt = trs.len();
        let nlds = loads.len();
        let mut setup: HashMap<(usize, u8), Vec<f64>> = HashMap::new(); // input, rf -> per tr
        let mut hold: HashMap<(usize, u8), Vec<f64>> = HashMap::new();
        let mut c2o: HashMap<(usize, u8), Vec<f64>> = HashMap::new(); // output, rf -> per load
        let mut c2o_tr: HashMap<(usize, u8), Vec<f64>> = HashMap::new();
        let mut comb: HashMap<Key, Vec<Vec<f64>>> = HashMap::new();
        let mut comb_tr: HashMap<Key, Vec<Vec<f64>>> = HashMap::new();
        let mut in_cap: HashMap<usize, f64> = HashMap::new();
        let opts = self.sta_opts();
        for (ti, &tr) in trs.iter().enumerate() {
            for (li, &ld) in loads.iter().enumerate() {
                let cons = build(tr, ld);
                let mut t = Timing::new(nl, &ls, &cons, &corner, opts.clone());
                t.run();
                let node = |p: usize| t.idx.get(&PinRef::Port(p)).copied();
                let reg_eps: HashSet<u32> = t.endpoints.iter().filter(|e| !e.is_port).map(|e| e.node).collect();
                let q1 = |from: Option<u32>, to: Option<HashSet<u32>>, hold: bool, srf: Option<u8>, erf: Option<u8>| -> Option<crate::paths::PathRes> {
                    let q = PathQuery { hold, from: from.map(|f| [f].into_iter().collect()), to, max_paths: 1, nworst: 1, start_rf: srf, end_rf: erf, max_pops: 20_000, ..Default::default() };
                    t.enumerate_paths(&q).into_iter().next()
                };
                for &p in &inputs {
                    let Some(nd) = node(p) else { continue };
                    if ti == 0 && li == 0 {
                        in_cap.insert(p, nl.ports[p].net.map(|n| t.net_c[n]).unwrap_or(0.0));
                    }
                    if li == 0 {
                        for rf in 0..2u8 {
                            if let Some(ps) = q1(Some(nd), Some(reg_eps.clone()), false, Some(rf), None) {
                                // setup time = how much earlier than the clock edge data must arrive
                                let per = t.clk_period.get(t.endpoints[ps.ep].reqs[ps.rec].cap_clk as usize).copied().unwrap_or(0.0);
                                setup.entry((p, rf)).or_insert_with(|| vec![f64::NAN; nt])[ti] = per - ps.slack;
                            }
                            if let Some(ph) = q1(Some(nd), Some(reg_eps.clone()), true, Some(rf), None) {
                                hold.entry((p, rf)).or_insert_with(|| vec![f64::NAN; nt])[ti] = -ph.slack;
                            }
                        }
                    }
                    // combinational input -> output
                    for &o in &outputs {
                        let Some(on) = node(o) else { continue };
                        for rf in 0..2u8 {
                            if let Some(pc) = q1(Some(nd), Some([on].into_iter().collect()), early, None, Some(rf)) {
                                if pc.launch == crate::sta::NONE {
                                    comb.entry((p, o, rf)).or_insert_with(|| vec![vec![f64::NAN; nlds]; nt])[ti][li] = pc.arrival;
                                    let sl = t.pin_slew_timed(PinRef::Port(o));
                                    comb_tr.entry((p, o, rf)).or_insert_with(|| vec![vec![f64::NAN; nlds]; nt])[ti][li] = sl;
                                }
                            }
                        }
                    }
                }
                if ti == 0 {
                    // clock -> output (register launched)
                    for &o in &outputs {
                        let Some(on) = node(o) else { continue };
                        for rf in 0..2u8 {
                            let q = PathQuery { hold: early, to: Some([on].into_iter().collect()), max_paths: 8, nworst: 8, end_rf: Some(rf), max_pops: 20_000, ..Default::default() };
                            if let Some(pc) = t.enumerate_paths(&q).into_iter().find(|p| p.launch != crate::sta::NONE) {
                                let le = 0.0;
                                c2o.entry((o, rf)).or_insert_with(|| vec![f64::NAN; nlds])[li] = pc.arrival - le;
                                c2o_tr.entry((o, rf)).or_insert_with(|| vec![f64::NAN; nlds])[li] = t.pin_slew_timed(PinRef::Port(o));
                            }
                        }
                    }
                }
            }
        }
        // assemble the cell
        let fill = |v: &[f64]| -> Vec<f64> {
            let last = v.iter().copied().filter(|x| x.is_finite()).last().unwrap_or(0.0);
            v.iter().map(|x| if x.is_finite() { *x } else { last }).collect()
        };
        let fill2 = |v: &[Vec<f64>]| -> Vec<Vec<f64>> { v.iter().map(|r| fill(r)).collect() };
        let mut pins: Vec<PinM> = vec![];
        let mut clk_pins: Vec<(usize, String)> = clock_port.iter().filter_map(|(p, c)| nl.port_by_name(p).map(|i| (i, c.clone()))).collect();
        clk_pins.sort();
        for (p, _) in &clk_pins {
            pins.push(PinM { name: nl.ports[*p].name.clone(), dir: "input".into(), cap: nl.ports[*p].net.map(|_| 0.0).unwrap_or(0.0), clock: true, ..Default::default() });
        }
        let clock_port_of = |p: usize| -> Option<String> {
            let ck = io_clock(&nl.ports[p].name)?;
            clock_port.iter().find(|(_, c)| **c == ck).map(|(port, _)| port.clone())
        };
        for &p in &inputs {
            let mut pm = PinM { name: nl.ports[p].name.clone(), dir: "input".into(), cap: in_cap.get(&p).copied().unwrap_or(0.0), ..Default::default() };
            if let Some(cp) = clock_port_of(p) {
                for (kind, m) in [("setup_rising", &setup), ("hold_rising", &hold)] {
                    let r = m.get(&(p, 0));
                    let f = m.get(&(p, 1));
                    if r.is_some() || f.is_some() {
                        let mk = |v: Option<&Vec<f64>>| v.map(|v| Tbl { i1: trs.to_vec(), i2: vec![], v: vec![fill(v)], load_axis: false });
                        pm.arcs.push(ArcM { related: cp.clone(), ttype: kind.into(), rise: mk(r).or(mk(f)), fall: mk(f).or(mk(r)), constraint: true, ..Default::default() });
                    }
                }
            }
            pins.push(pm);
        }
        let gmt = mode.max_tran;
        for &o in &outputs {
            let mut pm = PinM { name: nl.ports[o].name.clone(), dir: "output".into(), max_cap: Some(loads.last().copied().unwrap_or(0.1).max(0.0)), max_tran: gmt, ..Default::default() };
            if let Some(cp) = clock_port_of(o) {
                let r = c2o.get(&(o, 0));
                let f = c2o.get(&(o, 1));
                if r.is_some() || f.is_some() {
                    let mk = |v: Option<&Vec<f64>>| v.map(|v| Tbl::by_load(loads.to_vec(), fill(v)));
                    let rt = c2o_tr.get(&(o, 0));
                    let ft = c2o_tr.get(&(o, 1));
                    pm.arcs.push(ArcM { related: cp.clone(), ttype: "rising_edge".into(), rise: mk(r).or(mk(f)), fall: mk(f).or(mk(r)), rise_tr: mk(rt).or(mk(ft)), fall_tr: mk(ft).or(mk(rt)), ..Default::default() });
                }
            }
            for &i in &inputs {
                let r = comb.get(&(i, o, 0));
                let f = comb.get(&(i, o, 1));
                if r.is_none() && f.is_none() {
                    continue;
                }
                let mk = |v: Option<&Vec<Vec<f64>>>| v.map(|v| Tbl { i1: trs.to_vec(), i2: loads.to_vec(), v: fill2(v), load_axis: false });
                let rt = comb_tr.get(&(i, o, 0));
                let ft = comb_tr.get(&(i, o, 1));
                pm.arcs.push(ArcM { related: nl.ports[i].name.clone(), ttype: "combinational".into(), sense: Some("non_unate".into()), rise: mk(r).or(mk(f)), fall: mk(f).or(mk(r)), rise_tr: mk(rt).or(mk(ft)), fall_tr: mk(ft).or(mk(rt)), ..Default::default() });
            }
            pins.push(pm);
        }
        let area: f64 = nl.cell_ids().iter().filter_map(|c| nl.cell(*c).lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|lc| lc.area)).sum();
        Ok(CellM {
            lib: format!("{}_{}_etm", nl.name, sc.corner),
            name: nl.name.clone(),
            area,
            model_type: "extracted".into(),
            comment: format!("Extracted timing model of {} (scenario {}, corner {}) written by RSynth", nl.name, sc.name, sc.corner),
            pins,
            voltage: corner.voltage.unwrap_or(0.8),
            temperature: corner.temperature.unwrap_or(25.0),
        })
    }

    fn c_extract_model(&mut self, a: &[String]) -> R {
        let x = args(a, &["-output", "-format", "-scenario", "-scenarios", "-transitions", "-loads", "-cell_name", "-library_name", "-delay_type"]);
        let dtype = x.get("-delay_type").map(|s| s.to_lowercase());
        if let Some(d) = &dtype {
            if d != "min" && d != "max" {
                return err("extract_model: -delay_type must be min or max (ETM-003)");
            }
        }
        if let Some(fm) = x.get("-format") {
            if !split_list(fm).iter().any(|f| f == "lib") {
                return err(format!("extract_model: format '{}' not supported (lib) (ETM-001)", fm));
            }
        }
        let scen: Vec<usize> = match x.get("-scenario").or(x.get("-scenarios")) {
            Some(s) => split_list(s).iter().filter_map(|n| self.scens.iter().position(|k| &k.name == n)).collect(),
            None => self.active("setup").into_iter().take(1).collect(),
        };
        if scen.is_empty() {
            return err("extract_model: no scenario (ETM-002)");
        }
        let trs: Vec<f64> = x.get("-transitions").map(|s| split_list(s).iter().filter_map(|v| v.parse().ok()).collect()).unwrap_or(vec![0.01, 0.05, 0.2]);
        let lds: Vec<f64> = x.get("-loads").map(|s| split_list(s).iter().filter_map(|v| v.parse().ok()).collect()).unwrap_or(vec![0.001, 0.01, 0.05]);
        let base = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or(self.nl()?.name.clone());
        let mut files = vec![];
        for si in &scen {
            let t0 = std::time::Instant::now();
            // delay arcs carry the late (max) values, or the early (min) ones for a scenario that
            // only checks hold (or with -delay_type min); constraint arcs carry both checks
            let sc = &self.scens[*si];
            let early = match dtype.as_deref() {
                Some(d) => d == "min",
                None => sc.hold && !sc.setup,
            };
            if dtype.is_none() && sc.hold && sc.setup {
                crate::warn!("ETM-110", "extract_model: scenario {} checks setup and hold; delay arcs carry max values (write a -delay_type min model for hold)", sc.name);
            }
            let mut c = self.characterize(*si, &trs, &lds, early)?;
            c.comment = format!("{} ({} delays)", c.comment, if early { "min" } else { "max" });
            if let Some(n) = x.get("-cell_name") {
                c.name = n.clone();
            }
            if let Some(n) = x.get("-library_name") {
                c.lib = n.clone();
            }
            let f = if scen.len() == 1 && base.ends_with(".lib") { base.clone() } else { format!("{}{}.lib", base.trim_end_matches(".lib"), if scen.len() > 1 { format!("_{}", self.scens[*si].name) } else { String::new() }) };
            std::fs::write(&f, write_liberty(&c)).map_err(|e| Flow::Err(format!("{}: {}", f, e)))?;
            let na: usize = c.pins.iter().map(|p| p.arcs.len()).sum();
            crate::info!("ETM-100", "Wrote extracted timing model '{}' (scenario {}, {} delays): {} pins, {} timing arcs, {}x{} characterization points, {:.2}s", f, self.scens[*si].name, if early { "min" } else { "max" }, c.pins.len(), na, trs.len(), lds.len(), t0.elapsed().as_secs_f64());
            files.push(f);
        }
        Ok(files.join(" "))
    }

    // ------------------------------------------------------------------ ILM

    /// interface logic: (cells kept, interface registers)
    pub(crate) fn interface_logic(&self) -> Result<(HashSet<usize>, usize), Flow> {
        let nl = self.nl()?;
        let is_seq = |c: usize| nl.cell(c).lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|lc| lc.seq.is_some() || lc.icg.is_some()).unwrap_or(false) || matches!(nl.cell(c).gop(), Some(crate::netlist::GOp::Dff) | Some(crate::netlist::GOp::Latch));
        let mut keep: HashSet<usize> = HashSet::new();
        let mut regs: HashSet<usize> = HashSet::new();
        // forward from inputs to the first registers
        let mut st: Vec<usize> = vec![];
        for p in nl.port_ids() {
            if nl.ports[p].dir == Dir::Out {
                continue;
            }
            if let Some(n) = nl.ports[p].net {
                for l in crate::session::Session::leaf_conns(nl, n) {
                    if let PinRef::Cell(c, _) = l {
                        st.push(c);
                    }
                }
            }
        }
        while let Some(c) = st.pop() {
            if !keep.insert(c) {
                continue;
            }
            if is_seq(c) {
                regs.insert(c);
                continue;
            }
            for pn in &nl.cell(c).pins {
                if pn.dir == Dir::Out {
                    if let Some(n) = pn.net {
                        for l in nl.loads(n) {
                            if let PinRef::Cell(c2, _) = l {
                                st.push(c2);
                            }
                        }
                    }
                }
            }
        }
        // backward from outputs to the last registers
        let mut st: Vec<usize> = vec![];
        for p in nl.port_ids() {
            if nl.ports[p].dir == Dir::In {
                continue;
            }
            if let Some(n) = nl.ports[p].net {
                if let Some(PinRef::Cell(c, _)) = nl.driver(n) {
                    st.push(c);
                }
            }
        }
        let mut back: HashSet<usize> = HashSet::new();
        while let Some(c) = st.pop() {
            if !back.insert(c) {
                continue;
            }
            keep.insert(c);
            if is_seq(c) {
                regs.insert(c);
                continue;
            }
            for pn in &nl.cell(c).pins {
                if pn.dir == Dir::In {
                    if let Some(n) = pn.net {
                        if let Some(PinRef::Cell(c2, _)) = nl.driver(n) {
                            st.push(c2);
                        }
                    }
                }
            }
        }
        // clock (and asynchronous control) networks of the interface registers back to ports
        let mut st: Vec<usize> = vec![];
        for &r in &regs {
            for pn in &nl.cell(r).pins {
                if pn.dir == Dir::In && pn.name != "D" && pn.name != "SI" && pn.name != "SE" {
                    if let Some(n) = pn.net {
                        if let Some(PinRef::Cell(c2, _)) = nl.driver(n) {
                            st.push(c2);
                        }
                    }
                }
            }
        }
        let mut ck: HashSet<usize> = HashSet::new();
        while let Some(c) = st.pop() {
            if !ck.insert(c) || (is_seq(c) && nl.cell(c).lib().map(|l| !l.starts_with("ICG")).unwrap_or(true) && !regs.contains(&c)) {
                continue;
            }
            keep.insert(c);
            for pn in &nl.cell(c).pins {
                if pn.dir == Dir::In {
                    if let Some(n) = pn.net {
                        if let Some(PinRef::Cell(c2, _)) = nl.driver(n) {
                            st.push(c2);
                        }
                    }
                }
            }
        }
        // side loads: every load of an interface net stays (as a load; its own fanout is cut)
        let mut side = vec![];
        for &c in &keep {
            for pn in &nl.cell(c).pins {
                if pn.dir == Dir::Out {
                    if let Some(n) = pn.net {
                        for l in nl.loads(n) {
                            if let PinRef::Cell(c2, _) = l {
                                if !keep.contains(&c2) {
                                    side.push(c2);
                                }
                            }
                        }
                    }
                }
            }
        }
        keep.extend(side);
        Ok((keep, regs.len()))
    }

    pub(crate) fn ilm_netlist(&self) -> Result<(Netlist, usize, usize), Flow> {
        let (keep, nregs) = self.interface_logic()?;
        let mut ilm = self.nl()?.clone();
        let total = ilm.cell_ids().len();
        for c in ilm.cell_ids() {
            let k = keep.contains(&c) || ilm.cell(c).is_hport() || matches!(ilm.cell(c).gop(), Some(crate::netlist::GOp::C0) | Some(crate::netlist::GOp::C1));
            if !k {
                ilm.remove_cell(c);
            }
        }
        ilm.sweep_nets();
        let _ = total;
        Ok((ilm, keep.len(), nregs))
    }

    fn c_write_ilm(&mut self, a: &[String]) -> R {
        let x = args(a, &["-output", "-scenario"]);
        let base = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or(format!("{}_ilm", self.nl()?.name));
        let (ilm, kept, nregs) = self.ilm_netlist()?;
        let full_cells = self.nl()?.num_cells();
        let f = if base.ends_with(".v") { base.clone() } else { format!("{}.v", base) };
        let libs = &self.libs;
        let is_lib = |n: &str| libs.iter().any(|l| l.cells.contains_key(n));
        crate::out::write_verilog(&ilm, &f, &is_lib).map_err(|e| Flow::Err(e.to_string()))?;
        // interface timing: the worst input->register, register->output and input->output paths
        // of the ILM must match the full design
        let si = match x.get("-scenario") {
            Some(s) => self.scens.iter().position(|k| &k.name == s).ok_or_else(|| Flow::Err(format!("write_ilm: scenario '{}' does not exist", s)))?,
            None => self.active("setup").first().copied().unwrap_or(0),
        };
        let iface = |nl: &Netlist| -> Result<(f64, f64, usize), Flow> {
            let (cons, corner) = self.scen_corner_mode_pub(si);
            let ls = self.libset(&corner);
            let mut t = Timing::new(nl, &ls, cons, &corner, self.sta_opts());
            t.run();
            let ins: HashSet<u32> = nl.port_ids().into_iter().filter(|p| nl.ports[*p].dir != Dir::Out).filter_map(|p| t.idx.get(&PinRef::Port(p)).copied()).collect();
            let outs: HashSet<u32> = nl.port_ids().into_iter().filter(|p| nl.ports[*p].dir != Dir::In).filter_map(|p| t.idx.get(&PinRef::Port(p)).copied()).collect();
            let qi = PathQuery { from: Some(ins), max_paths: 1, nworst: 1, ..Default::default() };
            let qo = PathQuery { to: Some(outs), max_paths: 1, nworst: 1, ..Default::default() };
            let a = t.enumerate_paths(&qi).first().map(|p| p.slack).unwrap_or(f64::INFINITY);
            let b = t.enumerate_paths(&qo).first().map(|p| p.slack).unwrap_or(f64::INFINITY);
            Ok((a, b, t.endpoints.len()))
        };
        let (fa, fb, _) = iface(self.nl()?)?;
        let (ia, ib, _) = iface(&ilm)?;
        let ok = (fa - ia).abs() < 1e-6 && (fb - ib).abs() < 1e-6;
        crate::info!("ILM-100", "Wrote interface logic model '{}': {} of {} cells kept ({} interface registers); worst input-side slack {:.4} (full {:.4}), output-side {:.4} (full {:.4}) - interface timing {}", f, kept, full_cells, nregs, ia, fa, ib, fb, if ok { "matches" } else { "DIFFERS" });
        if !ok {
            crate::warn!("ILM-110", "ILM interface timing differs from the full design (side loads of interface nets are not kept)");
        }
        Ok(f)
    }

    // ------------------------------------------------------------------ abstract + NDM bundle

    pub(crate) fn lef_abstract(&self) -> Result<String, Flow> {
        let nl = self.nl()?;
        let (x0, y0, x1, y1) = match &self.fp {
            Some(fp) => fp.die,
            None => {
                let area: f64 = nl.cell_ids().iter().filter_map(|c| nl.cell(*c).lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|lc| lc.area)).sum();
                let s = (area / 0.7).sqrt().max(10.0);
                (0.0, 0.0, s, s)
            }
        };
        let mut s = String::new();
        let _ = writeln!(s, "VERSION 5.8 ;\nBUSBITCHARS \"[]\" ;\nDIVIDERCHAR \"/\" ;\nUNITS\n  DATABASE MICRONS 1000 ;\nEND UNITS\n");
        let _ = writeln!(s, "MACRO {}\n  CLASS BLOCK ;\n  ORIGIN 0 0 ;\n  FOREIGN {} 0 0 ;\n  SIZE {} BY {} ;\n  SYMMETRY X Y ;", nl.name, nl.name, fl(x1 - x0), fl(y1 - y0));
        let clocks: HashSet<String> = self.modes[self.cur_mode].sdc.clocks.iter().flat_map(|c| c.sources.iter().filter_map(|o| if let Obj::Port(p) = o { Some(p.clone()) } else { None })).collect();
        for p in nl.port_ids() {
            let pt = &nl.ports[p];
            let dir = match pt.dir {
                Dir::In => "INPUT",
                Dir::Out => "OUTPUT",
                Dir::InOut => "INOUT",
            };
            let _ = writeln!(s, "  PIN {}\n    DIRECTION {} ;\n    USE {} ;", pt.name, dir, if clocks.contains(&pt.name) { "CLOCK" } else { "SIGNAL" });
            if let (Some((x, y)), Some(fp)) = (pt.loc, self.fp.as_ref()) {
                let (side, layer, _) = fp.pin_info.get(&pt.name).cloned().unwrap_or(("bottom".into(), "M3".into(), String::new()));
                let (w, d) = crate::fplan::pin_shape(&fp.block_pins, &fp.layers, &layer);
                let (rx0, ry0, rx1, ry1) = match side.as_str() {
                    "left" => (x, y - w / 2.0, x + d, y + w / 2.0),
                    "right" => (x - d, y - w / 2.0, x, y + w / 2.0),
                    "top" => (x - w / 2.0, y - d, x + w / 2.0, y),
                    _ => (x - w / 2.0, y, x + w / 2.0, y + d),
                };
                let _ = writeln!(s, "    PORT\n      LAYER {} ;\n        RECT {} {} {} {} ;\n    END", layer, fl(rx0 - x0), fl(ry0 - y0), fl(rx1 - x0), fl(ry1 - y0));
            }
            let _ = writeln!(s, "  END {}", pt.name);
        }
        let _ = writeln!(s, "  OBS");
        let lays: Vec<String> = self.fp.as_ref().map(|f| f.layers.iter().take(4).map(|l| l.name.clone()).collect()).unwrap_or(vec!["M1".into(), "M2".into(), "M3".into(), "M4".into()]);
        for l in lays {
            let _ = writeln!(s, "    LAYER {} ;\n      RECT 0 0 {} {} ;", l, fl(x1 - x0), fl(y1 - y0));
        }
        let _ = writeln!(s, "  END\nEND {}\n\nEND LIBRARY", nl.name);
        Ok(s)
    }

    fn c_write_ndm(&mut self, a: &[String]) -> R {
        let x = args(a, &["-output", "-scenario"]);
        let nm = self.nl()?.name.clone();
        let dir = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or(format!("{}.ndm", nm));
        std::fs::create_dir_all(&dir).map_err(|e| Flow::Err(format!("write_ndm: {}: {}", dir, e)))?;
        let lib = format!("{}/{}.lib", dir, nm);
        let mut v = vec!["-output".to_string(), lib.clone()];
        if let Some(s) = x.get("-scenario") {
            v.push("-scenario".into());
            v.push(s.clone());
        }
        self.c_extract_model(&v)?;
        let lef = format!("{}/{}.lef", dir, nm);
        std::fs::write(&lef, self.lef_abstract()?).map_err(|e| Flow::Err(e.to_string()))?;
        let ilm = format!("{}/{}_ilm.v", dir, nm);
        self.c_write_ilm(&["-output".to_string(), ilm.clone()])?;
        let man = format!("{}/manifest.txt", dir);
        std::fs::write(
            &man,
            format!("# RSynth NDM-style block bundle (not the binary Synopsys NDM format)\ndesign {}\ntiming_view {}\nframe_view {}\ninterface_netlist {}\n", nm, lib.rsplit('/').next().unwrap(), lef.rsplit('/').next().unwrap(), ilm.rsplit('/').next().unwrap()),
        )
        .map_err(|e| Flow::Err(e.to_string()))?;
        crate::info!("NDM-100", "Wrote NDM-style bundle '{}': timing (ETM .lib), frame (LEF abstract), interface netlist (ILM), manifest. This is an open-format bundle, not a binary Synopsys NDM library", dir);
        Ok(dir)
    }
}

#[allow(dead_code)]
fn _u(_: &LibSet) {}
