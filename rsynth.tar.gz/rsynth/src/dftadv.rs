//! Advanced DFT: on-chip clock controllers, scan compression, boundary scan (IEEE 1149.1 TAP +
//! BSR, BSDL), memory BIST (march algorithms, collars, pin or TAP control), lockup latches and
//! scan restitching, test-mode SDC / scenarios and DFT sanity checks.
//!
//!  insert_occ [-clocks {ports}] [-pulses n] [-test_clock name] [-atspeed_port name]
//!  insert_scan_compression -channels n [-ratio r]
//!  insert_boundary_scan [-idcode hex] [-ir_length n] [-exclude_ports pats]
//!  write_bsdl file
//!  insert_mbist -memories pats [-algorithm march_c-] [-control pins|tap] [-reset port]
//!  write_mbist_testbench file [-clock_period ns] [-inject_fault]
//!  insert_lockup_latches | restitch_scan_chains [-chain_count n] [-placement]
//!  write_test_mode_sdc -mode shift|capture|atspeed|bscan|mbist -output f [-shift_period ns]
//!  create_test_mode_scenarios [-modes {..}] [-shift_period ns]
//!  check_dft [-verbose]           report_dft

use crate::dftip::*;
use crate::netlist::*;
use crate::session::{args, Session};
use crate::tcl::{err, split_list, Flow, R};
use std::collections::HashMap;

#[derive(Clone, Debug, Default)]
pub struct DftAdv {
    pub test_mode: Option<String>,
    pub scan_en: Option<String>,
    pub test_clk: Option<String>,
    pub atspeed: Option<String>,
    /// (clock port, OCC instance, at-speed pulses)
    pub occ: Vec<(String, String, usize)>,
    pub edt: Option<EdtState>,
    pub tap: Option<TapState>,
    pub mbist: Vec<MbistState>,
    /// chains as stitched: (name, cells SI -> SO, scan-in, scan-out) where scan-in / scan-out are
    /// ports, or `edt:k` for chains behind the compressor
    pub chains: Vec<(String, Vec<String>, String, String)>,
    pub lockups: usize,
    pub notes: Vec<String>,
}

#[derive(Clone, Debug)]
pub struct EdtState {
    pub inst: String,
    pub channels: usize,
    pub chains: usize,
    pub lfsr: usize,
    pub taps: Vec<usize>,
    pub inject: Vec<usize>,
    pub ps: Vec<Vec<usize>>,
    pub comp: Vec<Vec<usize>>,
    pub init_cycles: usize,
    pub ci: Vec<String>,
    pub co: Vec<String>,
    pub clear: String,
    pub enable: String,
}

#[derive(Clone, Debug)]
pub struct TapState {
    pub inst: String,
    pub ir_len: usize,
    pub idcode: u32,
    /// (port, kind in/out) in BSR order (cell 0 is next to TDO)
    pub cells: Vec<(String, String)>,
    pub ports: [String; 5], // tck tms tdi trst_n tdo
    pub user: Vec<(String, u32)>,
}

#[derive(Clone, Debug)]
pub struct MbistState {
    pub inst: String,
    pub memories: Vec<(String, String, usize, usize, usize)>, // instance, master, abits, dbits, words
    pub algorithm: String,
    pub control: String,
    pub en: String,
    pub start: String,
    pub done: String,
    pub fail: String,
    pub reset: String,
    pub clock: String,
}

fn port_net(nl: &mut Netlist, name: &str, dir: Dir) -> NetId {
    match nl.port_by_name(name) {
        Some(p) => match nl.ports[p].net { Some(n) => n, None => { let n = nl.add_net(name); nl.connect_port(p, n); n } },
        None => { let p = nl.add_port(name, dir); nl.ports[p].net.unwrap() }
    }
}

/// move the cell input pins on `from` (except cells accepted by `keep`) to `to`
fn move_loads(nl: &mut Netlist, from: NetId, to: NetId, keep: &dyn Fn(&Netlist, CellId) -> bool) -> usize {
    let conns: Vec<PinRef> = nl.net(from).conns.clone();
    let mut k = 0;
    for pr in conns {
        if let PinRef::Cell(c, i) = pr {
            if nl.cell(c).pins[i].dir == Dir::Out || keep(nl, c) { continue; }
            nl.disconnect(c, i);
            nl.connect(c, i, to);
            k += 1;
        }
    }
    k
}

fn has_cell(s: &Session, n: &str) -> bool {
    s.libs.iter().any(|l| l.cells.contains_key(n))
}

impl Session {
    pub fn dftadv_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "insert_occ" | "insert_clock_controllers" => self.c_insert_occ(a),
            "insert_scan_compression" | "insert_compression" | "insert_edt" => self.c_insert_edt(a),
            "insert_boundary_scan" | "insert_bsd" | "insert_jtag" => self.c_insert_bscan(a),
            "write_bsdl" => self.c_write_bsdl(a),
            "insert_mbist" | "insert_memory_bist" => self.c_insert_mbist(a),
            "write_mbist_testbench" => self.c_mbist_tb(a),
            "write_bscan_testbench" | "write_jtag_testbench" => self.c_bscan_tb(a),
            "insert_lockup_latches" => self.c_lockups(a, false),
            "restitch_scan_chains" | "stitch_scan_chains" => self.c_lockups(a, true),
            "write_test_mode_sdc" => self.c_test_sdc(a),
            "create_test_mode_scenarios" => self.c_test_scen(a),
            "check_dft" | "check_test" | "dft_sanity" => self.c_check_dft(a),
            "report_dft" | "report_dft_configuration" => self.c_report_dft(a),
            "write_dft_ip" => self.c_write_ip(a),
            _ => return self.atpg_cmd(name, a),
        })
    }

    /// scan chains as known to the advanced DFT state (picked up from insert_dft on first use)
    pub(crate) fn adv_chains(&mut self) -> Vec<(String, Vec<String>, String, String)> {
        if self.dftx.chains.is_empty() {
            self.dftx.chains = self.dft.chains.iter().map(|(n, _, regs)| {
                let (si, so) = n.split_once(':').map(|(a, b)| (a.to_string(), b.to_string())).unwrap_or((n.clone(), n.clone()));
                (n.clone(), regs.clone(), si, so)
            }).collect();
        }
        self.dftx.chains.clone()
    }

    fn tm_se(&mut self) -> (String, String) {
        let tm = self.dftx.test_mode.clone().or(self.dft.test_mode.clone()).unwrap_or("test_mode".into());
        let se = self.dftx.scan_en.clone().or(self.dft.scan_enable.clone()).unwrap_or("test_se".into());
        self.dftx.test_mode = Some(tm.clone());
        self.dftx.scan_en = Some(se.clone());
        if self.dft.test_mode.is_none() { self.dft.test_mode = Some(tm.clone()); }
        (tm, se)
    }

    // ------------------------------------------------------------------ OCC
    fn c_insert_occ(&mut self, a: &[String]) -> R {
        let x = args(a, &["-clocks", "-pulses", "-test_clock", "-atspeed_port"]);
        let pulses = x.num("-pulses").unwrap_or(2.0) as usize;
        let clocks: Vec<String> = match x.get("-clocks") {
            Some(c) => split_list(c),
            None => {
                let mut v: Vec<String> = self.dft.chains.iter().map(|c| c.1.clone()).filter(|d| d != "all").collect();
                if v.is_empty() { v = self.cons_clock_ports(); }
                v.sort();
                v.dedup();
                v
            }
        };
        if clocks.is_empty() {
            return err("insert_occ: no clock (give -clocks {ports}) (DFT-400)");
        }
        let (tm, se) = self.tm_se();
        let tclk = x.get("-test_clock").cloned().unwrap_or("test_clk".into());
        let atp = x.get("-atspeed_port").cloned().unwrap_or("test_atspeed".into());
        let has_icg = has_cell(self, "ICG_X1_SVT");
        let ip = self.compile_ip("rsdft_occ", &occ_rtl("rsdft_occ", pulses, has_icg)).map_err(|e| Flow::Err(format!("insert_occ: {} (DFT-401)", e)))?;
        let mut done = 0;
        for c in &clocks {
            if self.dftx.occ.iter().any(|o| &o.0 == c) { continue; }
            let nl = self.nl.as_mut().ok_or_else(|| Flow::Err("no design".into()))?;
            let Some(p) = nl.port_by_name(c) else { return err(&format!("insert_occ: clock port '{}' not found (DFT-402)", c)) };
            let cn = nl.ports[p].net.ok_or_else(|| Flow::Err(format!("insert_occ: '{}' is unconnected", c)))?;
            let tnet = port_net(nl, &tclk, Dir::In);
            let tmn = port_net(nl, &tm, Dir::In);
            let sen = port_net(nl, &se, Dir::In);
            let atn = port_net(nl, &atp, Dir::In);
            let out = nl.add_net(&format!("{}_occ", c));
            let inst = format!("u_dft_occ_{}", c.replace(['[', ']', '/'], "_"));
            let conn: HashMap<String, NetId> = [("fast_clk", cn), ("test_clk", tnet), ("test_mode", tmn), ("scan_en", sen), ("atspeed", atn), ("clk_out", out)].iter().map(|(k, v)| (k.to_string(), *v)).collect();
            // the loads move before the OCC is added, so its own fast_clk pin stays on the port
            let nl = self.nl.as_mut().unwrap();
            let moved = move_loads(nl, cn, out, &|_, _| false);
            self.graft(&ip, &inst, &conn).map_err(|e| Flow::Err(format!("insert_occ: {}", e)))?;
            crate::info!("DFT-410", "OCC '{}' on clock '{}': {} clock load(s) re-driven; shift = {}, slow capture = 1 {} pulse, at-speed capture = {} '{}' pulse(s) (test_mode '{}', scan enable '{}', at-speed select '{}')",
                inst, c, moved, tclk, tclk, pulses, c, tm, se, atp);
            self.dftx.occ.push((c.clone(), inst, pulses));
            done += 1;
        }
        self.dftx.test_clk = Some(tclk);
        self.dftx.atspeed = Some(atp);
        Ok(done.to_string())
    }

    /// clock ports from the SDC (create_clock sources)
    fn cons_clock_ports(&self) -> Vec<String> {
        let Some(nl) = self.nl.as_ref() else { return vec![] };
        let mut v = vec![];
        for p in nl.port_ids() {
            let n = &nl.ports[p].name;
            if ["clk", "clock", "ck"].iter().any(|k| n.to_lowercase() == *k || n.to_lowercase().ends_with(&format!("_{}", k))) { v.push(n.clone()); }
        }
        v
    }

    // ------------------------------------------------------------------ compression
    fn c_insert_edt(&mut self, a: &[String]) -> R {
        let x = args(a, &["-channels", "-ratio", "-clock"]);
        if self.dftx.edt.is_some() { return err("insert_scan_compression: already inserted (DFT-420)"); }
        let chains = self.adv_chains();
        if chains.is_empty() { return err("insert_scan_compression: no scan chains (insert_dft first) (DFT-421)"); }
        let n = chains.len();
        let ch = x.num("-channels").map(|v| v as usize).or_else(|| x.num("-ratio").map(|r| ((n as f64) / r).ceil() as usize)).unwrap_or((n / 4).max(1)).clamp(1, n);
        let (_tm, se) = self.tm_se();
        let cfg = edt_cfg(ch, n);
        let ip = self.compile_ip("rsdft_edt", &edt_rtl("rsdft_edt", &cfg)).map_err(|e| Flow::Err(format!("insert_scan_compression: {} (DFT-422)", e)))?;
        let clk_port = x.get("-clock").cloned().or_else(|| self.dft.chains.first().map(|c| c.1.clone()).filter(|d| d != "all")).or_else(|| self.cons_clock_ports().first().cloned())
            .ok_or_else(|| Flow::Err("insert_scan_compression: give -clock (DFT-423)".into()))?;
        let nl = self.nl.as_mut().unwrap();
        let mut clk = nl.port_by_name(&clk_port).and_then(|p| nl.ports[p].net).ok_or_else(|| Flow::Err(format!("clock port '{}' not found", clk_port)))?;
        // behind an OCC the decompressor / compactor run on the controlled clock (test clock in shift)
        if let Some(n) = nl.net_by_name(&format!("{}_occ", clk_port)) { clk = n; }
        let sen = port_net(nl, &se, Dir::In);
        let clr = port_net(nl, "test_edt_clear", Dir::In);
        let en = port_net(nl, "test_comp_en", Dir::In);
        let mut conn: HashMap<String, NetId> = [("clk", clk), ("scan_en", sen), ("edt_clear", clr), ("comp_en", en)].iter().map(|(k, v)| (k.to_string(), *v)).collect();
        let (mut ci, mut co) = (vec![], vec![]);
        for j in 0..ch {
            let (i, o) = (format!("test_ci{}", j), format!("test_co{}", j));
            conn.insert(format!("chan_in[{}]", j), port_net(nl, &i, Dir::In));
            let on = nl.add_net(&format!("{}_n", o));
            let p = nl.add_port(&o, Dir::Out);
            let old = nl.ports[p].net.unwrap();
            nl.connect_port(p, on);
            nl.remove_net(old);
            conn.insert(format!("chan_out[{}]", j), on);
            ci.push(i);
            co.push(o);
        }
        let mut new_chains = vec![];
        for (k, (name, cells, si, so)) in chains.iter().enumerate() {
            // scan-in: the first cell's SI moves from the port to the decompressor output
            let sin = nl.add_net(&format!("u_dft_edt/chain_si_{}", k));
            if let Some(p) = nl.port_by_name(si) {
                let pn = nl.ports[p].net.unwrap();
                move_loads(nl, pn, sin, &|_, _| false);
                nl.remove_port(p);
                if nl.net(pn).conns.is_empty() { nl.remove_net(pn); }
            }
            conn.insert(format!("chain_si[{}]", k), sin);
            // scan-out: the last cell's Q feeds the compactor
            let qn = match nl.port_by_name(so) {
                Some(p) => { let q = nl.ports[p].net.unwrap(); nl.remove_port(p); q }
                None => return err(&format!("insert_scan_compression: scan-out port '{}' of {} not found (DFT-424)", so, name)),
            };
            conn.insert(format!("chain_so[{}]", k), qn);
            new_chains.push((format!("edt_chain{}", k), cells.clone(), format!("edt:{}", k), format!("edt:{}", k)));
        }
        self.graft(&ip, "u_dft_edt", &conn).map_err(|e| Flow::Err(format!("insert_scan_compression: {}", e)))?;
        let maxl = chains.iter().map(|c| c.1.len()).max().unwrap_or(0);
        crate::info!("DFT-425", "Scan compression: {} channel(s) -> {} internal chain(s) (ratio {:.1}x, max chain length {}), {}-bit decompressor, {} initialisation cycle(s), XOR compactor; scan-in {} / scan-out {}",
            ch, n, n as f64 / ch as f64, maxl, cfg.lfsr, cfg.init_cycles, ci.join(" "), co.join(" "));
        self.dftx.edt = Some(EdtState { inst: "u_dft_edt".into(), channels: ch, chains: n, lfsr: cfg.lfsr, taps: cfg.taps, inject: cfg.inject, ps: cfg.ps, comp: cfg.comp, init_cycles: cfg.init_cycles, ci, co, clear: "test_edt_clear".into(), enable: "test_comp_en".into() });
        self.dftx.chains = new_chains;
        Ok(ch.to_string())
    }

    // ------------------------------------------------------------------ boundary scan
    fn dft_ports(&self) -> Vec<String> {
        let mut v: Vec<String> = vec![];
        for o in [&self.dftx.test_mode, &self.dftx.scan_en, &self.dftx.test_clk, &self.dftx.atspeed, &self.dft.test_mode, &self.dft.scan_enable] { if let Some(s) = o { v.push(s.clone()); } }
        for (_, _, si, so) in &self.dftx.chains { v.push(si.clone()); v.push(so.clone()); }
        for c in &self.dft.chains { if let Some((a, b)) = c.0.split_once(':') { v.push(a.into()); v.push(b.into()); } }
        if let Some(e) = &self.dftx.edt { v.extend(e.ci.iter().cloned()); v.extend(e.co.iter().cloned()); v.push(e.clear.clone()); v.push(e.enable.clone()); }
        for o in &self.dftx.occ { v.push(o.0.clone()); }
        for m in &self.dftx.mbist { v.extend([m.en.clone(), m.start.clone(), m.done.clone(), m.fail.clone(), m.reset.clone()]); }
        if let Some(t) = &self.dftx.tap { v.extend(t.ports.iter().cloned()); }
        v
    }

    fn c_insert_bscan(&mut self, a: &[String]) -> R {
        let x = args(a, &["-idcode", "-ir_length", "-exclude_ports"]);
        if self.dftx.tap.is_some() { return err("insert_boundary_scan: already inserted (DFT-430)"); }
        let idcode = x.get("-idcode").and_then(|s| u32::from_str_radix(s.trim_start_matches("0x").trim_start_matches("32'h"), 16).ok()).unwrap_or(0x1A5B_C001);
        let ir = x.num("-ir_length").map(|v| v as usize).unwrap_or(4).max(4);
        let excl: Vec<String> = x.get("-exclude_ports").map(|s| split_list(s)).unwrap_or_default();
        let mut skip = self.dft_ports();
        skip.extend(self.cons_clock_ports());
        let rc = self.reset_clock_ports();
        if !rc.is_empty() { crate::info!("DFT-435", "Boundary scan: clock / asynchronous set-reset port(s) {} kept off the boundary register (test-controlled in scan mode)", rc.join(" ")); }
        skip.extend(rc);
        let nl = self.nl.as_ref().ok_or_else(|| Flow::Err("no design".into()))?;
        // ports driving clock pins are not boundary-scanned
        let mut cells: Vec<(String, String)> = vec![];
        let mut ids: Vec<PortId> = nl.port_ids();
        ids.sort_by_key(|p| nl.ports[*p].name.clone());
        for p in ids {
            let pt = &nl.ports[p];
            if pt.net.is_none() || skip.contains(&pt.name) || excl.iter().any(|e| glob(e, &pt.name)) { continue; }
            match pt.dir { Dir::In => cells.push((pt.name.clone(), "in".into())), Dir::Out => cells.push((pt.name.clone(), "out".into())), _ => {} }
        }
        let user = [("user_scan", 8u32), ("user_mbist", 9u32)];
        let ip = self.compile_ip("rsdft_tap", &tap_bsr_rtl(&cells, idcode, ir, &user)).map_err(|e| Flow::Err(format!("insert_boundary_scan: {} (DFT-431)", e)))?;
        let nl = self.nl.as_mut().unwrap();
        let tp = ["tck", "tms", "tdi", "trst_n", "tdo"];
        let mut conn: HashMap<String, NetId> = HashMap::new();
        for t in &tp[..4] { conn.insert(t.to_string(), port_net(nl, t, Dir::In)); }
        let tdo = nl.add_net("tdo_n");
        let p = nl.add_port("tdo", Dir::Out);
        let old = nl.ports[p].net.unwrap();
        nl.connect_port(p, tdo);
        nl.remove_net(old);
        conn.insert("tdo".into(), tdo);
        for (k, (port, kind)) in cells.iter().enumerate() {
            let p = nl.port_by_name(port).unwrap();
            let n = nl.ports[p].net.unwrap();
            if kind == "in" {
                let core = nl.add_net(&format!("{}_bsr", port));
                move_loads(nl, n, core, &|_, _| false);
                conn.insert(format!("bs_pi[{}]", k), n);
                conn.insert(format!("bs_po[{}]", k), core);
            } else {
                let pad = nl.add_net(&format!("{}_pad", port));
                nl.connect_port(p, pad);
                conn.insert(format!("bs_core[{}]", k), n);
                conn.insert(format!("bs_po[{}]", k), pad);
            }
        }
        // unused BSR inputs: tie through a constant
        let zero = { let z = nl.add_net("u_dft_tap/tie0"); nl.add_gen("u_dft_tap/tie0_c", GOp::C0, &[], z); z };
        for k in 0..cells.len().max(1) {
            let kind = cells.get(k).map(|c| c.1.as_str()).unwrap_or("in");
            if kind == "in" { conn.insert(format!("bs_core[{}]", k), zero); } else { conn.insert(format!("bs_pi[{}]", k), zero); }
            if cells.is_empty() { conn.insert(format!("bs_pi[{}]", k), zero); }
        }
        for b in 0..8 {
            let t = nl.add_net(&format!("u_dft_tap/user_tdr_in[{}]", b));
            nl.add_gen(&format!("u_dft_tap/user_tdr_in_tie{}", b), GOp::C0, &[], t);
            conn.insert(format!("user_tdr_in[{}]", b), t);
        }
        let pm = self.graft(&ip, "u_dft_tap", &conn).map_err(|e| Flow::Err(format!("insert_boundary_scan: {}", e)))?;
        let _ = pm;
        let nin = cells.iter().filter(|c| c.1 == "in").count();
        crate::info!("DFT-432", "Boundary scan: TAP (tck tms tdi trst_n tdo), {}-bit IR, IDCODE 0x{:08X}, {}-cell boundary register ({} input, {} output cell(s)); instructions EXTEST INTEST SAMPLE/PRELOAD IDCODE CLAMP HIGHZ BYPASS USER_SCAN USER_MBIST",
            ir, idcode | 1, cells.len(), nin, cells.len() - nin);
        self.dftx.tap = Some(TapState { inst: "u_dft_tap".into(), ir_len: ir, idcode: idcode | 1, cells, ports: tp.map(|s| s.to_string()), user: user.iter().map(|(a, b)| (a.to_string(), *b)).collect() });
        // memories already under TAP control: hook them now
        Ok(String::new())
    }

    /// ports reaching clock or asynchronous set / reset pins of sequential cells (through buffers / inverters)
    pub(crate) fn reset_clock_ports(&self) -> Vec<String> {
        let Some(nl) = self.nl.as_ref() else { return vec![] };
        let lib = self.target_idx();
        let mut v: Vec<String> = vec![];
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.attrs.iter().any(|a| a.starts_with("dft_ip:")) { continue; }
            let Some(lc) = cl.lib().and_then(|l| self.libs[lib].cells.get(l).or_else(|| self.libs.iter().find_map(|x| x.cells.get(l)))) else { continue };
            let mut pins: Vec<String> = vec![];
            if let Some(sq) = &lc.seq { for p in [Some(sq.clocked_on.clone()), sq.clear.clone(), sq.preset.clone()].into_iter().flatten() { pins.push(p.trim_start_matches('!').trim_end_matches('\'').to_string()); } }
            if lc.icg.is_some() { if let Some(p) = lc.pins.iter().find(|p| p.is_clock) { pins.push(p.name.clone()); } }
            for p in pins {
                let Some(mut n) = cl.pin_net(&p) else { continue };
                for _ in 0..32 {
                    match nl.driver(n) {
                        Some(PinRef::Port(pt)) => { let nm = nl.ports[pt].name.clone(); if !v.contains(&nm) { v.push(nm); } break; }
                        Some(PinRef::Cell(d, _)) => {
                            let dc = nl.cell(d);
                            let l = dc.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l)));
                            let bi = dc.is_hport() || matches!(dc.kind, Kind::Gen(GOp::Buf) | Kind::Gen(GOp::Not)) || l.map(|x| x.is_buf || x.is_inv).unwrap_or(false);
                            if !bi { break; }
                            match dc.pins.iter().find(|q| q.dir == Dir::In).and_then(|q| q.net) { Some(x) => n = x, None => break }
                        }
                        None => break,
                    }
                }
            }
        }
        v.sort();
        v
    }

    fn c_write_bsdl(&mut self, a: &[String]) -> R {
        let x = args(a, &["-output"]);
        let f = x.get("-output").cloned().or(x.pos.first().cloned()).ok_or_else(|| Flow::Err("write_bsdl: file name required".into()))?;
        let t = self.dftx.tap.clone().ok_or_else(|| Flow::Err("write_bsdl: no boundary scan (insert_boundary_scan) (DFT-433)".into()))?;
        let nl = self.nl()?;
        let ent = nl.name.clone();
        let mut s = format!("-- BSDL generated by rsynth for {}\nentity {} is\n  generic (PHYSICAL_PIN_MAP : string := \"DEFAULT\");\n  port (\n", ent, ent);
        let mut pl: Vec<String> = vec![];
        for p in nl.port_ids() {
            let pt = &nl.ports[p];
            let d = match pt.dir { Dir::In => "in", Dir::Out => "out", _ => "inout" };
            pl.push(format!("    {} : {} bit", pt.name.replace(['[', ']'], "_").trim_end_matches('_'), d));
        }
        s += &pl.join(";\n");
        s += "\n  );\n  use STD_1149_1_2001.all;\n  attribute COMPONENT_CONFORMANCE of ";
        s += &format!("{} : entity is \"STD_1149_1_2001\";\n  attribute PIN_MAP of {} : entity is PHYSICAL_PIN_MAP;\n  constant DEFAULT : PIN_MAP_STRING := \"\";\n", ent, ent);
        s += &format!("  attribute TAP_SCAN_IN    of tdi    : signal is true;\n  attribute TAP_SCAN_MODE  of tms    : signal is true;\n  attribute TAP_SCAN_OUT   of tdo    : signal is true;\n  attribute TAP_SCAN_CLOCK of tck    : signal is (10.0e6, BOTH);\n  attribute TAP_SCAN_RESET of trst_n : signal is true;\n");
        let ir = t.ir_len;
        let code = |v: u32| format!("{:0w$b}", v, w = ir);
        s += &format!("  attribute INSTRUCTION_LENGTH of {} : entity is {};\n  attribute INSTRUCTION_OPCODE of {} : entity is\n", ent, ir, ent);
        let mut ops = vec![format!("\"EXTEST ({})\"", code(0)), format!("\"SAMPLE ({})\"", code(1)), format!("\"PRELOAD ({})\"", code(1)), format!("\"IDCODE ({})\"", code(2)), format!("\"INTEST ({})\"", code(3)), format!("\"CLAMP ({})\"", code(4)), format!("\"HIGHZ ({})\"", code(5))];
        for (u, c) in &t.user { ops.push(format!("\"{} ({})\"", u.to_uppercase(), code(*c))); }
        ops.push(format!("\"BYPASS ({})\"", code((1 << ir) - 1)));
        s += &format!("    {};\n", ops.join(" &\n    "));
        s += &format!("  attribute INSTRUCTION_CAPTURE of {} : entity is \"{}\";\n", ent, code(1));
        s += &format!("  attribute IDCODE_REGISTER of {} : entity is \"{:032b}\";\n", ent, t.idcode);
        s += &format!("  attribute REGISTER_ACCESS of {} : entity is \"BOUNDARY (EXTEST, SAMPLE, PRELOAD, INTEST, CLAMP), BYPASS (BYPASS, HIGHZ), DEVICE_ID (IDCODE)\";\n", ent);
        s += &format!("  attribute BOUNDARY_LENGTH of {} : entity is {};\n  attribute BOUNDARY_REGISTER of {} : entity is\n", ent, t.cells.len(), ent);
        let br: Vec<String> = t.cells.iter().enumerate().map(|(k, (p, kind))| {
            let pn = p.replace(['[', ']'], "_").trim_end_matches('_').to_string();
            if kind == "in" { format!("    \"{} (BC_1, {}, input, X)\"", k, pn) } else { format!("    \"{} (BC_1, {}, output2, X)\"", k, pn) }
        }).collect();
        s += &br.join(" &\n");
        s += ";\nend ";
        s += &ent;
        s += ";\n";
        std::fs::write(&f, s).map_err(|e| Flow::Err(e.to_string()))?;
        crate::info!("DFT-434", "Wrote BSDL '{}' ({} boundary cells, IR {} bits)", f, t.cells.len(), ir);
        Ok(f)
    }

    // ------------------------------------------------------------------ MBIST
    pub(crate) fn mem_port_pub(&self, c: CellId) -> Option<MemPort> { self.mem_port(c) }
    fn mem_port(&self, c: CellId) -> Option<MemPort> {
        let nl = self.nl.as_ref()?;
        let cl = nl.cell(c);
        let names: Vec<String> = cl.pins.iter().map(|p| p.name.clone()).collect();
        let bus = |pre: &[&str]| -> Option<(String, usize)> {
            for p in pre {
                let n = names.iter().filter(|x| x.starts_with(&format!("{}[", p))).count();
                if n > 0 { return Some((p.to_string(), n)); }
            }
            None
        };
        let one = |pre: &[&str]| -> Option<String> { pre.iter().find(|p| names.iter().any(|x| x == *p)).map(|s| s.to_string()) };
        let (a, ab) = bus(&["A", "ADDR", "AD", "ADR"])?;
        let (d, db) = bus(&["D", "DI", "DIN", "WD"])?;
        let (q, _) = bus(&["Q", "DO", "DOUT", "RD"])?;
        let clk = one(&["CLK", "CK", "CLKA", "CP"])?;
        let ce = one(&["CE", "CS", "ME", "EN", "CEN", "CSN", "MEB"])?;
        let we = one(&["WE", "WEN", "WEB", "RW"])?;
        let m = cl.lib().unwrap_or("").to_uppercase();
        let words = m.split(|c: char| c == '_').find_map(|t| {
            let t = t.split('X').next()?;
            if let Some(k) = t.strip_suffix('K') { k.parse::<usize>().ok().map(|v| v * 1024) } else { t.parse::<usize>().ok() }
        }).filter(|w| *w > 1 && *w <= (1usize << ab)).unwrap_or(1usize << ab);
        Some(MemPort { inst: cl.name.clone(), abits: ab, dbits: db, words, clk, ce: ce.clone(), we: we.clone(), addr: a, din: d, dout: q, ce_low: ce.ends_with('N') || ce.ends_with('B'), we_low: we.ends_with('N') || we.ends_with('B') })
    }

    fn c_insert_mbist(&mut self, a: &[String]) -> R {
        let x = args(a, &["-memories", "-algorithm", "-control", "-reset"]);
        let pats: Vec<String> = x.get("-memories").map(|s| split_list(s)).unwrap_or_else(|| vec!["*".into()]);
        let alg = x.get("-algorithm").cloned().unwrap_or("march_c-".into());
        let control = x.get("-control").cloned().unwrap_or("pins".into());
        let (tm, _) = self.tm_se();
        if control == "tap" && self.dftx.tap.is_none() { return err("insert_mbist: -control tap needs insert_boundary_scan first (DFT-440)"); }
        let nl = self.nl.as_ref().ok_or_else(|| Flow::Err("no design".into()))?;
        let mems: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| {
            let cl = nl.cell(*c);
            let is_mem = matches!(cl.kind, Kind::BlackBox(_)) || crate::lef::phys(&self.lef, cl).map(|m| m.is_block()).unwrap_or(false);
            is_mem && pats.iter().any(|p| glob(p, &cl.name)) && !cl.attrs.iter().any(|a| a.starts_with("mbist:"))
        }).collect();
        if mems.is_empty() { return err("insert_mbist: no memory matches (DFT-441)"); }
        // group by clock net: one controller per clock
        let mut groups: Vec<(NetId, Vec<(CellId, MemPort)>)> = vec![];
        for c in mems {
            let Some(mp) = self.mem_port(c) else { crate::warn!("DFT-442", "insert_mbist: '{}' has no recognisable memory pins (CLK/CE/WE/A/D/Q); skipped", nl.cell(c).name); continue };
            let Some(ck) = nl.cell(c).pin_net(&mp.clk) else { continue };
            match groups.iter_mut().find(|g| g.0 == ck) { Some(g) => g.1.push((c, mp)), None => groups.push((ck, vec![(c, mp)])) }
        }
        let mut total = 0;
        for (gi, (ck, list)) in groups.into_iter().enumerate() {
            let inst = format!("u_dft_mbist{}", gi);
            let ports: Vec<MemPort> = list.iter().map(|(_, m)| MemPort { inst: m.inst.clone(), abits: m.abits, dbits: m.dbits, words: m.words, clk: m.clk.clone(), ce: m.ce.clone(), we: m.we.clone(), addr: m.addr.clone(), din: m.din.clone(), dout: m.dout.clone(), ce_low: m.ce_low, we_low: m.we_low }).collect();
            let rtl = mbist_rtl(&format!("rsdft_mbist{}", gi), &ports, &alg).map_err(|e| Flow::Err(format!("insert_mbist: {} (DFT-443)", e)))?;
            let ip = self.compile_ip(&format!("rsdft_mbist{}", gi), &rtl).map_err(|e| Flow::Err(format!("insert_mbist: {} (DFT-444)", e)))?;
            let tap = self.dftx.tap.clone();
            let nl = self.nl.as_mut().unwrap();
            let mut conn: HashMap<String, NetId> = HashMap::new();
            conn.insert("clk".into(), ck);
            let sfx = if gi == 0 { String::new() } else { gi.to_string() };
            let (en_n, st_n, rst_n, done_n, fail_n);
            let (en_s, st_s, done_s, fail_s, rst_s);
            if control == "tap" {
                let t = tap.unwrap();
                let tdr = |nl: &Netlist, k: usize| nl.net_by_name(&format!("{}/user_tdr[{}]", t.inst, k));
                en_n = tdr(nl, 2 * gi).ok_or_else(|| Flow::Err("TAP user register not found".into()))?;
                st_n = tdr(nl, 2 * gi + 1).ok_or_else(|| Flow::Err("TAP user register not found".into()))?;
                rst_n = port_net(nl, &t.ports[3], Dir::In);
                // status: the TAP user-register capture inputs (their constant ties are removed)
                let mut st = vec![];
                for k in [2 * gi, 2 * gi + 1] {
                    let n = nl.net_by_name(&format!("{}/user_tdr_in[{}]", t.inst, k)).ok_or_else(|| Flow::Err("TAP user register capture input not found".into()))?;
                    if let Some(tie) = nl.cell_by_name(&format!("{}/user_tdr_in_tie{}", t.inst, k)) { nl.remove_cell(tie); }
                    st.push(n);
                }
                done_n = st[0];
                fail_n = st[1];
                en_s = format!("{}:user_tdr[{}]", t.inst, 2 * gi); st_s = format!("{}:user_tdr[{}]", t.inst, 2 * gi + 1);
                done_s = format!("{}:user_tdr_in[{}]", t.inst, 2 * gi); fail_s = format!("{}:user_tdr_in[{}]", t.inst, 2 * gi + 1); rst_s = t.ports[3].clone();
            } else {
                en_s = format!("mbist_en{}", sfx); st_s = format!("mbist_start{}", sfx); done_s = format!("mbist_done{}", sfx); fail_s = format!("mbist_fail{}", sfx);
                rst_s = x.get("-reset").cloned().unwrap_or("mbist_rst_n".into());
                en_n = port_net(nl, &en_s, Dir::In);
                st_n = port_net(nl, &st_s, Dir::In);
                rst_n = port_net(nl, &rst_s, Dir::In);
                done_n = nl.add_net(&format!("{}_n", done_s));
                let p = nl.add_port(&done_s, Dir::Out); let o = nl.ports[p].net.unwrap(); nl.connect_port(p, done_n); nl.remove_net(o);
                fail_n = nl.add_net(&format!("{}_n", fail_s));
                let p = nl.add_port(&fail_s, Dir::Out); let o = nl.ports[p].net.unwrap(); nl.connect_port(p, fail_n); nl.remove_net(o);
            }
            for (k, v) in [("bist_en", en_n), ("start", st_n), ("rst_n", rst_n), ("done", done_n), ("fail", fail_n)] { conn.insert(k.into(), v); }
            conn.insert("test_mode".into(), port_net(nl, &tm, Dir::In));
            // collars: functional nets stay on the f*_ ports, memory pins move to m*_ nets
            for (k, (c, m)) in list.iter().enumerate() {
                let pin_bits = |base: &str, w: usize| -> Vec<String> { (0..w).map(|i| format!("{}[{}]", base, i)).collect() };
                let mut map: Vec<(String, String, String)> = vec![(m.ce.clone(), format!("f{}_ce", k), format!("m{}_ce", k)), (m.we.clone(), format!("f{}_we", k), format!("m{}_we", k))];
                for (i, p) in pin_bits(&m.addr, m.abits).into_iter().enumerate() { map.push((p, format!("f{}_a[{}]", k, i), format!("m{}_a[{}]", k, i))); }
                for (i, p) in pin_bits(&m.din, m.dbits).into_iter().enumerate() { map.push((p, format!("f{}_d[{}]", k, i), format!("m{}_d[{}]", k, i))); }
                for (pin, f, mm) in map {
                    let pi = nl.cell(*c).pin(&pin).ok_or_else(|| Flow::Err(format!("memory pin {} missing", pin)))?;
                    let fnet = match nl.cell(*c).pins[pi].net { Some(n) => n, None => { let z = nl.add_net(&format!("{}/{}_open", inst, pin)); nl.add_gen(&format!("{}/{}_tie", inst, pin.replace(['[', ']'], "_")), GOp::C0, &[], z); z } };
                    let mnet = nl.add_net(&format!("{}/{}_{}", inst, m.inst.replace('/', "_"), pin));
                    nl.disconnect(*c, pi);
                    nl.connect(*c, pi, mnet);
                    conn.insert(f, fnet);
                    conn.insert(mm, mnet);
                }
                for i in 0..m.dbits {
                    // memory Q -> collar (m*_q); the functional Q net is driven by the collar's bypass mux (f*_q)
                    let pin = format!("{}[{}]", m.dout, i);
                    let pi = nl.cell(*c).pin(&pin).ok_or_else(|| Flow::Err(format!("memory pin {} missing", pin)))?;
                    let mq = nl.add_net(&format!("{}/{}_{}", inst, m.inst.replace('/', "_"), pin));
                    let fq = match nl.cell(*c).pins[pi].net { Some(n) => n, None => nl.add_net(&format!("{}/{}_{}_open", inst, m.inst.replace('/', "_"), pin)) };
                    nl.disconnect(*c, pi);
                    nl.connect(*c, pi, mq);
                    conn.insert(format!("m{}_q[{}]", k, i), mq);
                    conn.insert(format!("f{}_q[{}]", k, i), fq);
                }
                nl.cell_mut(*c).attrs.push(format!("mbist:{}", inst));
            }
            self.graft(&ip, &inst, &conn).map_err(|e| Flow::Err(format!("insert_mbist: {}", e)))?;
            let names: Vec<String> = list.iter().map(|(_, m)| format!("{} ({}x{})", m.inst, m.words, m.dbits)).collect();
            crate::info!("DFT-445", "MBIST controller '{}' ({}, {} control): {} memory(ies): {}", inst, alg, control, list.len(), names.join(", "));
            self.dftx.mbist.push(MbistState { inst: inst.clone(), memories: list.iter().map(|(c, m)| (m.inst.clone(), self.nl.as_ref().unwrap().cell(*c).lib().unwrap_or("").to_string(), m.abits, m.dbits, m.words)).collect(),
                algorithm: alg.clone(), control: control.clone(), en: en_s, start: st_s, done: done_s, fail: fail_s, reset: rst_s, clock: self.nl.as_ref().unwrap().net(ck).name.clone() });
            total += list.len();
        }
        Ok(total.to_string())
    }

    /// gate-level MBIST simulation testbench (with behavioural memory models)
    fn c_mbist_tb(&mut self, a: &[String]) -> R {
        let x = args(a, &["-clock_period", "-netlist", "-models"]);
        let f = x.pos.first().cloned().ok_or_else(|| Flow::Err("write_mbist_testbench: file name required".into()))?;
        if self.dftx.mbist.is_empty() { return err("write_mbist_testbench: no MBIST inserted (DFT-446)"); }
        let per = x.num("-clock_period").unwrap_or(10.0);
        let nl = self.nl()?;
        let top = nl.name.clone();
        let m0 = &self.dftx.mbist[0];
        let fast_clocks: Vec<String> = self.mbist_clock_ports();
        let mut s = format!("`timescale 1ns/1ps\n// rsynth MBIST testbench for {}: runs {} on every memory and checks done / fail\nmodule tb_mbist;\n", top, m0.algorithm);
        let inputs: Vec<(String, usize)> = self.port_list(Dir::In);
        let outputs: Vec<(String, usize)> = self.port_list(Dir::Out);
        let inn: Vec<String> = inputs.iter().map(|x| x.0.clone()).collect();
        let outn: Vec<String> = outputs.iter().map(|x| x.0.clone()).collect();
        s += &tb_decls(&inn, "reg");
        s += &tb_decls(&outn, "wire");
        let all: Vec<String> = inn.iter().chain(outn.iter()).cloned().collect();
        s += &format!("  {} dut (\n{}\n  );\n", top, tb_conns(&all));
        let tap = self.dftx.tap.clone();
        s += "  integer errors = 0, cyc = 0;\n";
        for c in &fast_clocks { s += &format!("  always #{} {} = ~{};\n", per / 2.0, tb_ref(c), tb_ref(c)); }
        let use_tap = self.dftx.mbist.iter().any(|m| m.control == "tap");
        if use_tap { s += &jtag_tasks(per * 4.0); }
        s += "  initial begin\n";
        for (p, _) in &inputs { s += &format!("    {} = 0;\n", tb_ref(p)); }
        for (p, _) in &inputs { if p.ends_with("_n") || p.ends_with("rstn") || p.ends_with("_b") { s += &format!("    {} = 0;\n", tb_ref(p)); } }
        s += &format!("    #({});\n", per * 3.0);
        for (p, _) in &inputs { if (p.ends_with("_n") || p.ends_with("rstn")) && !p.starts_with("trst") { s += &format!("    {} = 1;\n", tb_ref(p)); } }
        if use_tap {
            let t = tap.clone().unwrap();
            s += "    trst_n = 1;\n    jtag_reset();\n";
            let all_en: u32 = (0..self.dftx.mbist.len()).map(|g| 1u32 << (2 * g)).sum();
            let all_go: u32 = (0..self.dftx.mbist.len()).map(|g| 3u32 << (2 * g)).sum();
            s += &format!("    jtag_ir({}, {});\n    jtag_dr8(8'h{:02x});\n    jtag_dr8(8'h{:02x});\n", t.ir_len, t.user.iter().find(|u| u.0 == "user_mbist").map(|u| u.1).unwrap_or(9), all_en, all_go);
            let cycles: usize = self.dftx.mbist.iter().map(|m| mbist_cycles(m)).max().unwrap_or(1000);
            s += &format!("    #({:.1});\n    jtag_dr8_read(8'h{:02x});\n", cycles as f64 * per * 1.2 + 200.0, all_go);
            for g in 0..self.dftx.mbist.len() {
                s += &format!("    if (tdr_val[{}] !== 1'b1) begin $display(\"MBIST group {} NOT DONE\"); errors = errors + 1; end\n    if (tdr_val[{}] !== 1'b0) begin $display(\"MBIST group {} FAIL\"); errors = errors + 1; end\n", 2 * g, g, 2 * g + 1, g);
            }
        } else {
            for m in &self.dftx.mbist {
                s += &format!("    {} = 1;\n", tb_ref(&m.reset));
                s += &format!("    {} = 1;\n    #({});\n    {} = 1;\n    #({});\n    {} = 0;\n", tb_ref(&m.en), per * 2.0, tb_ref(&m.start), per * 2.0, tb_ref(&m.start));
            }
            let cycles: usize = self.dftx.mbist.iter().map(|m| mbist_cycles(m)).max().unwrap_or(1000);
            s += &format!("    #({:.1});\n", cycles as f64 * per * 1.1 + 100.0);
            for m in &self.dftx.mbist {
                s += &format!("    if ({} !== 1'b1) begin $display(\"MBIST {} NOT DONE\"); errors = errors + 1; end\n    if ({} !== 1'b0) begin $display(\"MBIST {} FAIL\"); errors = errors + 1; end\n", tb_ref(&m.done), m.inst, tb_ref(&m.fail), m.inst);
            }
        }
        s += "    if (errors == 0) $display(\"MBIST PASSED\"); else $display(\"MBIST FAILED: %0d error(s)\", errors);\n    $finish;\n  end\nendmodule\n";
        std::fs::write(&f, s).map_err(|e| Flow::Err(e.to_string()))?;
        crate::info!("DFT-447", "Wrote MBIST testbench '{}' ({} controller(s); define RSYNTH_INJECT_FAULT in the memory models to see the failure detected)", f, self.dftx.mbist.len());
        Ok(f)
    }

    /// IEEE 1149.1 conformance-style testbench: TAP reset, IDCODE, BYPASS, SAMPLE, PRELOAD + EXTEST
    fn c_bscan_tb(&mut self, a: &[String]) -> R {
        let x = args(a, &["-tck_period"]);
        let f = x.pos.first().cloned().ok_or_else(|| Flow::Err("write_bscan_testbench: file name required".into()))?;
        let t = self.dftx.tap.clone().ok_or_else(|| Flow::Err("write_bscan_testbench: no boundary scan (DFT-436)".into()))?;
        let per = x.num("-tck_period").unwrap_or(100.0);
        let top = self.nl()?.name.clone();
        let inn: Vec<String> = self.port_list(Dir::In).into_iter().map(|p| p.0).collect();
        let outn: Vec<String> = self.port_list(Dir::Out).into_iter().map(|p| p.0).collect();
        let n = t.cells.len();
        let mut s = format!("`timescale 1ns/1ps\n// rsynth boundary-scan testbench for {}: TAP reset, IDCODE, BYPASS, SAMPLE, PRELOAD + EXTEST ({} BSR cells, IR {} bits)\nmodule tb_bscan;\n", top, n, t.ir_len);
        s += &tb_decls(&inn, "reg");
        s += &tb_decls(&outn, "wire");
        let all: Vec<String> = inn.iter().chain(outn.iter()).cloned().collect();
        s += &format!("  {} dut (\n{}\n  );\n  integer errors = 0, i;\n  reg [1023:0] dr_out, pat;\n", top, tb_conns(&all));
        s += &jtag_tasks(per);
        s += &format!(r#"  task jtag_dr(input integer n, input [1023:0] v); integer k; begin
    jtag_clk(1, 0); jtag_clk(0, 0); jtag_clk(0, 0);
    for (k = 0; k < n; k = k + 1) begin tms = (k == n - 1); tdi = v[k]; #({h}); tck = 1; #({q}); dr_out[k] = tdo; #({q}); tck = 0; end
    jtag_clk(1, 0); jtag_clk(0, 0); end endtask
"#, h = per / 2.0, q = per / 4.0);
        s += "  initial begin\n";
        for p in &inn { s += &format!("    {} = 0;\n", tb_ref(p)); }
        s += &format!("    #({p}); trst_n = 1; #({p}); jtag_reset();\n", p = per);
        // IDCODE (reset instruction)
        s += &format!("    jtag_dr(32, 0);\n    if (dr_out[31:0] !== 32'h{:08x}) begin $display(\"IDCODE FAIL: %h expected {:08x}\", dr_out[31:0]); errors = errors + 1; end else $display(\"IDCODE ok: %h\", dr_out[31:0]);\n", t.idcode, t.idcode);
        // BYPASS
        s += &format!("    jtag_ir({}, {});\n    jtag_dr(9, 9'b110110010);\n    if (dr_out[8:1] !== 8'b10110010 || dr_out[0] !== 1'b0) begin $display(\"BYPASS FAIL: %b\", dr_out[8:0]); errors = errors + 1; end else $display(\"BYPASS ok\");\n", t.ir_len, (1u32 << t.ir_len) - 1);
        // SAMPLE: drive the input pins, capture, check the input cells
        let mut seed: u64 = 0x9E3779B97F4A7C15;
        let mut bits: Vec<u8> = vec![];
        for _ in 0..n { seed ^= seed << 13; seed ^= seed >> 7; seed ^= seed << 17; bits.push((seed & 1) as u8); }
        for (k, (p, kind)) in t.cells.iter().enumerate() { if kind == "in" { s += &format!("    {} = {};\n", tb_ref(p), bits[k]); } }
        s += &format!("    jtag_ir({}, 1);\n    jtag_dr({}, 0);\n", t.ir_len, n);
        for (k, (p, kind)) in t.cells.iter().enumerate() { if kind == "in" { s += &format!("    if (dr_out[{k}] !== 1'b{b}) begin $display(\"SAMPLE FAIL cell {k} ({p})\"); errors = errors + 1; end\n", k = k, b = bits[k], p = p); } }
        // PRELOAD a pattern, then EXTEST drives it on the output pins
        let pat: String = (0..n).rev().map(|k| if bits[k] == 1 { '0' } else { '1' }).collect();
        s += &format!("    pat = {}'b{};\n    jtag_dr({}, pat);\n    jtag_ir({}, 0);\n    #({});\n", n.max(1), if pat.is_empty() { "0".to_string() } else { pat }, n, t.ir_len, per);
        for (k, (p, kind)) in t.cells.iter().enumerate() { if kind != "in" { s += &format!("    if ({p} !== 1'b{b}) begin $display(\"EXTEST FAIL cell {k} ({pn}) = %b\", {p}); errors = errors + 1; end\n", p = tb_ref(p), b = 1 - bits[k], k = k, pn = p); } }
        // EXTEST capture: input pins observed through the BSR while in EXTEST
        s += &format!("    jtag_dr({}, pat);\n", n);
        for (k, (p, kind)) in t.cells.iter().enumerate() { if kind == "in" { s += &format!("    if (dr_out[{k}] !== 1'b{b}) begin $display(\"EXTEST capture FAIL cell {k} ({p})\"); errors = errors + 1; end\n", k = k, b = bits[k], p = p); } }
        s += "    jtag_reset();\n    if (errors == 0) $display(\"BOUNDARY SCAN PASSED\"); else $display(\"BOUNDARY SCAN FAILED: %0d error(s)\", errors);\n    $finish;\n  end\nendmodule\n";
        std::fs::write(&f, s).map_err(|e| Flow::Err(e.to_string()))?;
        crate::info!("DFT-437", "Wrote boundary-scan testbench '{}' (IDCODE, BYPASS, SAMPLE, PRELOAD, EXTEST on {} cells)", f, n);
        Ok(f)
    }

    fn mbist_clock_ports(&self) -> Vec<String> {
        let Some(nl) = self.nl.as_ref() else { return vec![] };
        let mut v: Vec<String> = vec![];
        for m in &self.dftx.mbist {
            // the memory clock net traced back to a port (through the OCC in functional mode)
            let mut name = m.clock.clone();
            if let Some(o) = self.dftx.occ.iter().find(|o| name == format!("{}_occ", o.0)) { name = o.0.clone(); }
            if nl.port_by_name(&name).is_some() { v.push(name); } else if let Some(c) = self.cons_clock_ports().first() { v.push(c.clone()); }
        }
        v.sort();
        v.dedup();
        v
    }

    /// (port base name, width) for the testbench declarations (bus bits grouped)
    pub(crate) fn port_list(&self, dir: Dir) -> Vec<(String, usize)> {
        let Some(nl) = self.nl.as_ref() else { return vec![] };
        let mut m: Vec<(String, usize)> = vec![];
        let mut ids = nl.port_ids();
        ids.sort_by_key(|p| nl.ports[*p].name.clone());
        for p in ids {
            let pt = &nl.ports[p];
            if pt.dir != dir || !pt.alive { continue; }
            m.push((pt.name.clone(), 1));
        }
        m
    }

    // ------------------------------------------------------------------ lockup latches / restitch
    fn c_lockups(&mut self, a: &[String], restitch: bool) -> R {
        let x = args(a, &["-chain_count"]);
        let placed = self.nl.as_ref().map(|nl| self.dft.chains.iter().flat_map(|c| c.2.iter()).all(|c| nl.cell_by_name(c).map(|id| nl.cell(id).loc.is_some()).unwrap_or(false))).unwrap_or(false);
        if restitch && !placed {
            if self.dftx.edt.is_some() { return err("restitch_scan_chains: chains are behind the compressor; restitch before insert_scan_compression (DFT-453)"); }
            let n = x.num("-chain_count").map(|v| v as usize).unwrap_or(self.dft.chains.len()).max(1);
            self.logical_restitch(n).map_err(|e| Flow::Err(format!("restitch_scan_chains: {} (DFT-454)", e)))?;
            self.dftx.chains.clear();
            self.adv_chains();
        } else if restitch {
            // re-order (placement aware when placed) and rebalance via the existing optimiser
            if let Some(n) = x.num("-chain_count") { self.dft.chain_count = n as usize; }
            let mut v = vec!["-effort".to_string(), "high".to_string()];
            if x.has("-placement") || x.num("-chain_count").is_some() { v.push("-repartition".into()); }
            if self.dftx.edt.is_none() {
                if let Some(Err(e)) = self.cmd("optimize_scan_chain", &v) { return Err(e); }
                self.dftx.chains.clear();
                self.adv_chains();
            } else {
                crate::warn!("DFT-450", "restitch_scan_chains: chains are behind the compressor; reordered within chains only");
                if let Some(Err(e)) = self.cmd("optimize_scan_chain", &["-effort".into(), "high".into()]) { return Err(e); }
                let old = self.dftx.chains.clone();
                self.dftx.chains = old.into_iter().zip(self.dft.chains.iter()).map(|(o, n)| (o.0, n.2.clone(), o.2, o.3)).collect();
            }
        }
        // lockup latches between consecutive cells of different clock domains
        let chains = self.adv_chains();
        let lat = if has_cell(self, "DLH_X1_SVT") { "DLH_X1_SVT".to_string() } else { return err("insert_lockup_latches: no latch cell (DLH) in the library (DFT-451)") };
        let inv = self.libs.iter().flat_map(|l| l.cells.keys()).find(|k| k.starts_with("INV_X1")).cloned().unwrap_or("INV_X1_SVT".into());
        let lib = self.target_idx();
        let nl = self.nl.as_mut().unwrap();
        let clk_root = |nl: &Netlist, c: CellId| -> Option<NetId> {
            let lc = self.libs[lib].cells.get(nl.cell(c).lib()?)?;
            let ck = lc.seq.as_ref()?.clocked_on.trim_start_matches('!').to_string();
            let mut n = nl.cell(c).pin_net(&ck)?;
            // through buffers / inverters to the root
            for _ in 0..64 {
                let Some(PinRef::Cell(d, _)) = nl.driver(n) else { break };
                let dc = nl.cell(d);
                let is_buf = dc.is_hport() || dc.lib().and_then(|l| self.libs[lib].cells.get(l)).map(|l| l.is_buf || l.is_inv).unwrap_or(false);
                if !is_buf { break; }
                let Some(i) = dc.pins.iter().find(|p| p.dir == Dir::In).and_then(|p| p.net) else { break };
                n = i;
            }
            Some(n)
        };
        let mut added = 0;
        for (_, cells, _, _) in &chains {
            for w in cells.windows(2) {
                let (Some(a), Some(b)) = (nl.cell_by_name(&w[0]), nl.cell_by_name(&w[1])) else { continue };
                let (Some(ra), Some(rb)) = (clk_root(nl, a), clk_root(nl, b)) else { continue };
                if ra == rb { continue; }
                // b's SI comes from a's Q: insert a latch transparent while a's clock is low
                let Some(sip) = nl.cell(b).pins.iter().position(|p| p.name == "SI") else { continue };
                let Some(qn) = nl.cell(b).pins[sip].net else { continue };
                if matches!(nl.driver(qn), Some(PinRef::Cell(d, _)) if nl.cell(d).has_attr("lockup")) { continue; }
                let ck = nl.cell(a).pin_net("CK").unwrap_or(ra);
                let ckb = nl.add_net(&format!("{}_lockup_ckb", w[1]));
                let li = nl.add_cell(&format!("{}_lockup_inv", w[1]), Kind::Lib(inv.clone()), &[("A", Dir::In), ("Y", Dir::Out)]);
                nl.connect_name(li, "A", ck);
                nl.connect_name(li, "Y", ckb);
                let lq = nl.add_net(&format!("{}_lockup_q", w[1]));
                let l = nl.add_cell(&format!("{}_lockup", w[1]), Kind::Lib(lat.clone()), &[("D", Dir::In), ("G", Dir::In), ("Q", Dir::Out)]);
                nl.connect_name(l, "D", qn);
                nl.connect_name(l, "G", ckb);
                nl.connect_name(l, "Q", lq);
                nl.disconnect(b, sip);
                nl.connect(b, sip, lq);
                for c in [l, li] { nl.cell_mut(c).attrs.push("lockup".into()); nl.cell_mut(c).dont_touch = true; }
                added += 1;
            }
        }
        self.dftx.lockups += added;
        crate::info!("DFT-452", "{}{} lockup latch(es) inserted between clock domains (total {})", if restitch { "Scan chains restitched; " } else { "" }, added, self.dftx.lockups);
        Ok(added.to_string())
    }

    /// re-partition the scan cells into `n` balanced chains (per clock domain unless mixing is allowed)
    fn logical_restitch(&mut self, n: usize) -> Result<(), String> {
        let old = self.dft.chains.clone();
        if old.is_empty() { return Err("no scan chains (insert_dft first)".into()); }
        let mut doms: Vec<(String, Vec<String>)> = vec![];
        for (_, d, regs) in &old {
            let d = if self.dft.mix_clocks { "all".to_string() } else { d.clone() };
            match doms.iter_mut().find(|x| x.0 == d) { Some(x) => x.1.extend(regs.iter().cloned()), None => doms.push((d, regs.clone())) }
        }
        let total: usize = doms.iter().map(|d| d.1.len()).sum();
        let n = n.max(doms.len());
        let mut alloc: Vec<(String, Vec<String>)> = vec![];
        let mut left = n;
        for (k, (d, regs)) in doms.iter().enumerate() {
            let share = if k + 1 == doms.len() { left } else { ((n * regs.len()) as f64 / total as f64).round().max(1.0) as usize }.min(left.saturating_sub(doms.len() - k - 1)).max(1);
            left = left.saturating_sub(share);
            let per = regs.len().div_ceil(share);
            for ch in regs.chunks(per.max(1)) { alloc.push((d.clone(), ch.to_vec())); }
        }
        let nl = self.nl.as_mut().ok_or("no design")?;
        // tear down the old stitching (lockup latches included; insert_lockup_latches re-adds them)
        let lk: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| nl.cell(*c).has_attr("lockup")).collect();
        for c in lk { nl.remove_cell(c); }
        self.dftx.lockups = 0;
        for (name, _, regs) in &old {
            for c in regs { if let Some(id) = nl.cell_by_name(c) { if let Some(i) = nl.cell(id).pin("SI") { nl.disconnect(id, i); } } }
            if let Some((si, so)) = name.split_once(':') {
                if let Some(p) = nl.port_by_name(si) { let pn = nl.ports[p].net; nl.remove_port(p); if let Some(pn) = pn { if nl.net(pn).conns.is_empty() { nl.remove_net(pn); } } }
                if let Some(p) = nl.port_by_name(so) { nl.remove_port(p); }
            }
        }
        let mut chains = vec![];
        for (i, (d, regs)) in alloc.iter().enumerate() {
            let (si, so) = (format!("test_si{}", i), format!("test_so{}", i));
            let p = nl.add_port(&si, Dir::In);
            let mut prev = nl.ports[p].net.unwrap();
            for c in regs {
                let id = nl.cell_by_name(c).ok_or(format!("scan cell {} missing", c))?;
                let i = nl.cell(id).pin("SI").ok_or(format!("{} has no SI pin", c))?;
                nl.connect(id, i, prev);
                prev = match nl.cell(id).pin_net("Q") { Some(q) => q, None => { let q = nl.add_net(&format!("{}_so", c)); nl.connect_name(id, "Q", q); q } };
            }
            let p = nl.add_port(&so, Dir::Out);
            let o = nl.ports[p].net.unwrap();
            nl.connect_port(p, prev);
            nl.remove_net(o);
            crate::info!("DFT-455", "Scan chain {} ({} -> {}): {} cells, clock domain '{}' (restitched)", i, si, so, regs.len(), d);
            chains.push((format!("{}:{}", si, so), d.clone(), regs.clone()));
        }
        self.dft.chains = chains;
        self.dft.chain_count = alloc.len();
        Ok(())
    }

    // ------------------------------------------------------------------ test-mode SDC
    pub(crate) fn test_sdc_text(&self, mode: &str, shift_period: f64) -> Result<String, String> {
        let nl = self.nl.as_ref().ok_or("no design")?;
        let has = |p: &str| nl.port_by_name(p).is_some();
        let d = &self.dftx;
        let tm = d.test_mode.clone().or(self.dft.test_mode.clone()).unwrap_or("test_mode".into());
        let se = d.scan_en.clone().or(self.dft.scan_enable.clone()).unwrap_or("test_se".into());
        let mut s = format!("# rsynth test-mode SDC: {} mode\n", mode);
        let func_clocks: Vec<(String, f64)> = self.func_clock_periods();
        let tclk = d.test_clk.clone().filter(|t| has(t));
        let case = |s: &mut String, p: &str, v: u8| { if has(p) { *s += &format!("set_case_analysis {} [get_ports {{{}}}]\n", v, p); } };
        let scan_clocks: Vec<String> = match &tclk { Some(t) => vec![t.clone()], None => func_clocks.iter().map(|c| c.0.clone()).collect() };
        match mode {
            "shift" | "capture" | "atspeed" => {
                if mode == "atspeed" {
                    for (c, p) in &func_clocks { s += &format!("create_clock -name {} -period {} [get_ports {{{}}}]\n", c, p, c); }
                    if let Some(t) = &tclk { s += &format!("create_clock -name {} -period {} [get_ports {{{}}}]\nset_clock_groups -physically_exclusive -group [get_clocks {}] -group [get_clocks {{{}}}]\n", t, shift_period, t, t, func_clocks.iter().map(|c| c.0.clone()).collect::<Vec<_>>().join(" ")); }
                } else {
                    for c in &scan_clocks { s += &format!("create_clock -name {} -period {} [get_ports {{{}}}]\n", c, shift_period, c); }
                    if tclk.is_some() { for (c, _) in &func_clocks { case(&mut s, c, 0); } }
                }
                case(&mut s, &tm, 1);
                case(&mut s, &se, if mode == "shift" { 1 } else { 0 });
                if let Some(a) = &d.atspeed { case(&mut s, a, if mode == "atspeed" { 1 } else { 0 }); }
                if let Some(e) = &d.edt { case(&mut s, &e.enable, 1); }
                if let Some(t) = &d.tap { case(&mut s, &t.ports[3], 0); }
                for m in &d.mbist { if has(&m.en) { case(&mut s, &m.en, 0); } }
                let ck = scan_clocks.first().cloned().unwrap_or("clk".into());
                let io = (shift_period * 0.2 * 100.0).round() / 100.0;
                let mut ins: Vec<String> = vec![];
                let mut outs: Vec<String> = vec![];
                for (_, _, si, so) in &d.chains { if has(si) { ins.push(si.clone()); } if has(so) { outs.push(so.clone()); } }
                if let Some(e) = &d.edt { ins.extend(e.ci.iter().cloned()); outs.extend(e.co.iter().cloned()); }
                if !ins.is_empty() { s += &format!("set_input_delay {} -clock {} [get_ports {{{}}}]\n", io, ck, ins.join(" ")); }
                if !outs.is_empty() { s += &format!("set_output_delay {} -clock {} [get_ports {{{}}}]\n", io, ck, outs.join(" ")); }
                if has(&se) && mode != "shift" { s += &format!("set_false_path -from [get_ports {{{}}}]\n", se); }
                if mode == "atspeed" { s += "# at-speed capture: launch and capture by the OCC fast pulses; scan-in / out paths are shift-only\n"; if !ins.is_empty() { s += &format!("set_false_path -from [get_ports {{{}}}]\n", ins.join(" ")); } }
            }
            "bscan" => {
                if let Some(t) = &d.tap {
                    s += &format!("create_clock -name tck -period {} [get_ports {{{}}}]\n", shift_period, t.ports[0]);
                    s += &format!("set_input_delay {} -clock tck [get_ports {{{} {}}}]\nset_output_delay {} -clock tck -clock_fall [get_ports {{{}}}]\n", shift_period * 0.2, t.ports[1], t.ports[2], shift_period * 0.2, t.ports[4]);
                    s += &format!("set_false_path -from [get_ports {{{}}}]\n", t.ports[3]);
                } else { return Err("no boundary scan".into()); }
                case(&mut s, &tm, 0);
            }
            "mbist" => {
                for (c, p) in &func_clocks { s += &format!("create_clock -name {} -period {} [get_ports {{{}}}]\n", c, p, c); }
                case(&mut s, &tm, 0);
                for m in &d.mbist { if has(&m.en) { case(&mut s, &m.en, 1); s += &format!("set_false_path -from [get_ports {{{}}}]\n", m.start); } }
            }
            _ => return Err(format!("unknown mode '{}': shift, capture, atspeed, bscan, mbist", mode)),
        }
        Ok(s)
    }

    /// functional clocks and their periods from the current SDC (fallback 2 ns)
    pub(crate) fn func_clock_periods_pub(&self) -> Vec<(String, f64)> { self.func_clock_periods() }
    fn func_clock_periods(&self) -> Vec<(String, f64)> {
        let mut v: Vec<(String, f64)> = vec![];
        if let Some(m) = self.modes.get(self.cur_mode) {
            for c in &m.sdc.clocks {
                if c.gen.is_some() { continue; }
                for s in &c.sources {
                    let n = s.name().to_string();
                    if Some(&n) != self.dftx.test_clk.as_ref() && !v.iter().any(|x| x.0 == n) && !n.starts_with("test_") { v.push((n, c.period)); }
                }
            }
        }
        if v.is_empty() { for c in self.cons_clock_ports() { v.push((c, 2.0)); } }
        v
    }

    fn c_test_sdc(&mut self, a: &[String]) -> R {
        let x = args(a, &["-mode", "-output", "-shift_period"]);
        let mode = x.get("-mode").cloned().unwrap_or("shift".into());
        let f = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or(format!("test_{}.sdc", mode));
        let s = self.test_sdc_text(&mode, x.num("-shift_period").unwrap_or(100.0)).map_err(|e| Flow::Err(format!("write_test_mode_sdc: {} (DFT-460)", e)))?;
        std::fs::write(&f, s).map_err(|e| Flow::Err(e.to_string()))?;
        crate::info!("DFT-461", "Wrote {} mode SDC '{}'", mode, f);
        Ok(f)
    }

    fn c_test_scen(&mut self, a: &[String]) -> R {
        let x = args(a, &["-modes", "-shift_period", "-corner", "-directory"]);
        let mut modes: Vec<String> = x.get("-modes").map(|s| split_list(s)).unwrap_or_else(|| vec!["shift".into(), "capture".into()]);
        if x.get("-modes").is_none() {
            if !self.dftx.occ.is_empty() { modes.push("atspeed".into()); }
            if self.dftx.tap.is_some() { modes.push("bscan".into()); }
            if !self.dftx.mbist.is_empty() { modes.push("mbist".into()); }
        }
        let per = x.num("-shift_period").unwrap_or(100.0);
        let corner = x.get("-corner").cloned().or_else(|| self.corners.first().map(|c| c.name.clone())).ok_or_else(|| Flow::Err("create_test_mode_scenarios: no corner".into()))?;
        let dir = x.get("-directory").cloned().unwrap_or(std::env::temp_dir().join(format!("rsynth_test_sdc_{}", std::process::id())).to_string_lossy().to_string());
        let _ = std::fs::create_dir_all(&dir);
        let mut made = vec![];
        for m in &modes {
            let s = self.test_sdc_text(m, per).map_err(|e| Flow::Err(format!("create_test_mode_scenarios: {} (DFT-462)", e)))?;
            let f = format!("{}/test_{}.sdc", dir, m);
            std::fs::write(&f, s).map_err(|e| Flow::Err(e.to_string()))?;
            let mode = format!("test_{}", m);
            let scen = format!("test_{}_{}", m, corner);
            let script = format!("create_mode {mode}\nread_sdc -mode {mode} {f}\ncreate_scenario -name {scen} -mode {mode} -corner {corner}\n", mode = mode, f = f, scen = scen, corner = corner);
            crate::log::push_redirect();
            let r = self.eval(&script);
            let out = crate::log::pop_redirect();
            if let Err(Flow::Err(e)) = r { return Err(Flow::Err(format!("create_test_mode_scenarios: {}: {}\n{}", m, e, out))); }
            made.push(scen);
        }
        crate::info!("DFT-463", "Test-mode scenarios: {} (SDC in {}); report_timing -scenarios <name> / optimisation now consider them", made.join(" "), dir);
        Ok(made.join(" "))
    }

    // ------------------------------------------------------------------ sanity checks
    fn c_check_dft(&mut self, a: &[String]) -> R {
        let verbose = a.iter().any(|x| x == "-verbose");
        let mut rows: Vec<(&str, String, bool)> = vec![];
        let nl = self.nl()?;
        let has = |p: &str| nl.port_by_name(p).is_some();
        let d = self.dftx.clone();
        let chains = if d.chains.is_empty() { self.dft.chains.iter().map(|(n, _, r)| { let (a, b) = n.split_once(':').unwrap_or((n, n)); (n.clone(), r.clone(), a.to_string(), b.to_string()) }).collect() } else { d.chains.clone() };
        // 1. scan chain structure: every SI pin is driven by the previous cell's Q (or a lockup latch)
        let mut broken = vec![];
        let lib = self.target_idx();
        for (name, cells, si, so) in &chains {
            for (i, c) in cells.iter().enumerate() {
                let Some(id) = nl.cell_by_name(c) else { broken.push(format!("{}: cell {} missing", name, c)); continue };
                let sin = nl.cell(id).pin_net("SI");
                let mut drv = sin.and_then(|n| nl.driver(n));
                // through a lockup latch
                if let Some(PinRef::Cell(l, _)) = drv { if nl.cell(l).has_attr("lockup") { drv = nl.cell(l).pin_net("D").and_then(|n| nl.driver(n)); } }
                let ok = if i == 0 {
                    match drv { Some(PinRef::Port(p)) => nl.ports[p].name == *si, Some(PinRef::Cell(c2, _)) => si.starts_with("edt:") && nl.cell(c2).has_attr("dft_ip:u_dft_edt"), None => false }
                } else {
                    match drv { Some(PinRef::Cell(p, _)) => nl.cell(p).name == cells[i - 1], _ => false }
                };
                if !ok { broken.push(format!("{}: SI of {} (position {}) not driven by {}", name, c, i, if i == 0 { si.clone() } else { cells[i - 1].clone() })); }
            }
            if let (Some(last), false) = (cells.last(), so.starts_with("edt:")) {
                let q = nl.cell_by_name(last).and_then(|c| nl.cell(c).pin_net("Q"));
                if !q.map(|n| nl.net(n).conns.iter().any(|pr| matches!(pr, PinRef::Port(p) if nl.ports[*p].name == *so))).unwrap_or(false) { broken.push(format!("{}: last cell {} does not reach {}", name, last, so)); }
            }
        }
        rows.push(("S1 scan chain connectivity", format!("{} chain(s), {} cell(s){}", chains.len(), chains.iter().map(|c| c.1.len()).sum::<usize>(), if broken.is_empty() { String::new() } else { format!(": {}", broken.iter().take(3).cloned().collect::<Vec<_>>().join("; ")) }), broken.is_empty() && !chains.is_empty()));
        // 2. chain balance
        let lens: Vec<usize> = chains.iter().map(|c| c.1.len()).collect();
        let (mn, mx) = (lens.iter().min().copied().unwrap_or(0), lens.iter().max().copied().unwrap_or(0));
        rows.push(("S2 chain balance", format!("lengths {}..{}", mn, mx), mx <= mn * 2 + 2 || chains.len() < 2));
        // 3. scan cells are scan flops with SE on the scan-enable port
        let se = d.scan_en.clone().or(self.dft.scan_enable.clone()).unwrap_or("test_se".into());
        let sen = nl.port_by_name(&se).and_then(|p| nl.ports[p].net);
        let mut bad_se = 0;
        for (_, cells, _, _) in &chains { for c in cells { if let Some(id) = nl.cell_by_name(c) { let n = nl.cell(id).pin_net("SE"); if n != sen && !trace_to(nl, n, sen) { bad_se += 1; } } } }
        rows.push(("S3 scan enable", format!("port '{}', {} cell(s) not on it", se, bad_se), bad_se == 0 && sen.is_some()));
        // 4. clocks of scan cells controllable (through OCC or from a port)
        let mut unc = 0;
        for (_, cells, _, _) in &chains {
            for c in cells {
                let Some(id) = nl.cell_by_name(c) else { continue };
                let ok = nl.cell(id).pin_net("CK").map(|n| clock_controllable(nl, &self.libs[lib], n, 0)).unwrap_or(false);
                if !ok { unc += 1; if verbose { crate::out!("  C1 uncontrollable clock: {}", c); } }
            }
        }
        rows.push(("C1 scan clocks controllable", format!("{} cell(s) with uncontrollable clock", unc), unc == 0));
        // 5. async set / reset of scan cells driven from ports
        let mut ar = 0;
        for (_, cells, _, _) in &chains {
            for c in cells {
                let Some(id) = nl.cell_by_name(c) else { continue };
                let Some(lc) = nl.cell(id).lib().and_then(|l| self.libs[lib].cells.get(l)) else { continue };
                for p in [lc.seq.as_ref().and_then(|s| s.clear.clone()), lc.seq.as_ref().and_then(|s| s.preset.clone())].into_iter().flatten() {
                    let pn = p.trim_start_matches('!').trim_end_matches('\'');
                    if let Some(n) = nl.cell(id).pin_net(pn) { if !clock_controllable(nl, &self.libs[lib], n, 0) { ar += 1; } }
                }
            }
        }
        rows.push(("R1 async set/reset controllable", format!("{} pin(s) not controllable", ar), ar == 0));
        // 6. X sources reaching scan cells
        let bb = nl.cell_ids().into_iter().filter(|c| matches!(nl.cell(*c).kind, Kind::BlackBox(_))).count();
        rows.push(("X1 X sources (black boxes)", format!("{} black box(es){}", bb, if bb > 0 { " - their outputs are X in capture (masked)" } else { "" }), true));
        // 7. combinational loops
        let loops = comb_loops(nl, &self.libs[lib]);
        rows.push(("L1 combinational loops", format!("{}", loops), loops == 0));
        // 8. test ports
        let tm = d.test_mode.clone().or(self.dft.test_mode.clone());
        rows.push(("P1 test-mode / scan-enable ports", format!("test_mode {}, scan_en {}", tm.clone().unwrap_or("-".into()), se), tm.map(|t| has(&t)).unwrap_or(d.occ.is_empty() && d.edt.is_none()) && has(&se)));
        // 9. OCC
        if !d.occ.is_empty() {
            let ok = d.occ.iter().all(|o| nl.net_by_name(&format!("{}_occ", o.0)).map(|n| !nl.loads(n).is_empty()).unwrap_or(false) && nl.port_by_name(&o.0).and_then(|p| nl.ports[p].net).map(|n| nl.loads(n).iter().all(|l| matches!(l, PinRef::Cell(c, _) if nl.cell(*c).attrs.iter().any(|a| a.starts_with("dft_ip:"))))).unwrap_or(false));
            rows.push(("O1 OCC clock re-drive", format!("{} clock(s), {} pulse(s) at speed", d.occ.len(), d.occ.iter().map(|o| o.2).max().unwrap_or(0)), ok));
        }
        // 10. compression
        if let Some(e) = &d.edt {
            let ok = e.ci.iter().chain(e.co.iter()).all(|p| has(p)) && e.chains == chains.len();
            rows.push(("E1 compression structure", format!("{} channel(s) / {} chain(s), {}-bit decompressor", e.channels, e.chains, e.lfsr), ok));
        }
        // 11. boundary scan
        if let Some(t) = &d.tap {
            let ok = t.ports.iter().all(|p| has(p)) && t.cells.iter().all(|(p, _)| has(p));
            let missing: Vec<String> = nl.port_ids().into_iter().map(|p| nl.ports[p].name.clone()).filter(|p| !t.cells.iter().any(|c| &c.0 == p) && !self.dft_ports().contains(p) && !self.cons_clock_ports().contains(p) && !self.reset_clock_ports().contains(p)).collect();
            rows.push(("B1 boundary scan", format!("TAP + {} BSR cell(s){}", t.cells.len(), if missing.is_empty() { String::new() } else { format!("; not covered: {}", missing.join(" ")) }), ok && missing.is_empty()));
        }
        // 12. MBIST
        if !d.mbist.is_empty() {
            let mems = nl.cell_ids().into_iter().filter(|c| matches!(nl.cell(*c).kind, Kind::BlackBox(_)) && self.mem_port(*c).is_some()).count();
            let cov: usize = d.mbist.iter().map(|m| m.memories.len()).sum();
            rows.push(("M1 memory BIST coverage", format!("{} of {} memory(ies) under BIST ({})", cov, mems, d.mbist.iter().map(|m| m.algorithm.clone()).collect::<Vec<_>>().join(", ")), cov == mems));
        }
        // 13. protocol / patterns readiness
        rows.push(("T1 test protocol", if self.dft.protocol { "defined".to_string() } else { "missing (create_test_protocol)".into() }, self.dft.protocol || !chains.is_empty()));
        crate::out!("****************************************\nReport : check_dft (DFT sanity)\n****************************************");
        let mut fails = 0;
        for (k, v, ok) in &rows {
            if !ok { fails += 1; }
            crate::out!("  {:<34} {:<6} {}", k, if *ok { "PASS" } else { "FAIL" }, v);
        }
        if verbose { for b in &broken { crate::out!("    {}", b); } }
        crate::info!("DFT-470", "DFT sanity: {} check(s), {} failure(s)", rows.len(), fails);
        Ok(fails.to_string())
    }

    fn c_report_dft(&mut self, _a: &[String]) -> R {
        let d = self.dftx.clone();
        let chains = self.adv_chains();
        crate::out!("****************************************\nReport : dft_configuration\n****************************************");
        crate::out!("  test mode / scan enable : {} / {}", d.test_mode.clone().unwrap_or("-".into()), d.scan_en.clone().unwrap_or("-".into()));
        crate::out!("  scan chains             : {} ({} cells, max length {})", chains.len(), chains.iter().map(|c| c.1.len()).sum::<usize>(), chains.iter().map(|c| c.1.len()).max().unwrap_or(0));
        crate::out!("  lockup latches          : {}", d.lockups);
        for o in &d.occ { crate::out!("  OCC                     : {} on {} ({} at-speed pulses, test clock {})", o.1, o.0, o.2, d.test_clk.clone().unwrap_or("-".into())); }
        if let Some(e) = &d.edt { crate::out!("  compression             : {} -> {} chains ({:.1}x), {}-bit decompressor, {} init cycle(s)", e.channels, e.chains, e.chains as f64 / e.channels as f64, e.lfsr, e.init_cycles); }
        if let Some(t) = &d.tap { crate::out!("  boundary scan           : IR {} bits, IDCODE 0x{:08X}, {} BSR cells", t.ir_len, t.idcode, t.cells.len()); }
        for m in &d.mbist { crate::out!("  MBIST                   : {} {} ({} control) on {}", m.inst, m.algorithm, m.control, m.memories.iter().map(|x| x.0.clone()).collect::<Vec<_>>().join(" ")); }
        Ok(String::new())
    }

    fn c_write_ip(&mut self, a: &[String]) -> R {
        let dir = a.first().cloned().unwrap_or("dft_ip".into());
        let _ = std::fs::create_dir_all(&dir);
        let mut n = 0;
        let has_icg = has_cell(self, "ICG_X1_SVT");
        if let Some(o) = self.dftx.occ.first() { std::fs::write(format!("{}/rsdft_occ.sv", dir), occ_rtl("rsdft_occ", o.2, has_icg)).ok(); n += 1; }
        if let Some(e) = &self.dftx.edt { let c = EdtCfg { channels: e.channels, chains: e.chains, lfsr: e.lfsr, taps: e.taps.clone(), inject: e.inject.clone(), ps: e.ps.clone(), comp: e.comp.clone(), init_cycles: e.init_cycles }; std::fs::write(format!("{}/rsdft_edt.sv", dir), edt_rtl("rsdft_edt", &c)).ok(); n += 1; }
        if let Some(t) = &self.dftx.tap { let u: Vec<(&str, u32)> = t.user.iter().map(|(a, b)| (a.as_str(), *b)).collect(); std::fs::write(format!("{}/rsdft_tap.sv", dir), tap_bsr_rtl(&t.cells, t.idcode, t.ir_len, &u)).ok(); n += 1; }
        crate::info!("DFT-480", "Wrote {} DFT IP RTL file(s) to '{}'", n, dir);
        Ok(n.to_string())
    }
}

/// testbench reference to a port bit: `a[3]` stays a bus-bit select of bus `a`
pub(crate) fn tb_ref(p: &str) -> String {
    match split_bit(p) { Some((b, i)) => format!("{}[{}]", vname(&b), i), None => vname(p) }
}
fn split_bit(p: &str) -> Option<(String, usize)> {
    let (b, r) = p.strip_suffix(']')?.rsplit_once('[')?;
    let i = r.parse::<usize>().ok()?;
    if b.is_empty() || b.contains('[') { return None; }
    Some((b.to_string(), i))
}
/// declarations grouping bus bits (`kw [msb:0] base;`)
pub(crate) fn tb_decls(names: &[String], kw: &str) -> String {
    let mut order: Vec<String> = vec![];
    let mut w: HashMap<String, Option<usize>> = HashMap::new();
    for n in names {
        let (b, i) = match split_bit(n) { Some((b, i)) => (b, Some(i)), None => (n.clone(), None) };
        if !w.contains_key(&b) { order.push(b.clone()); w.insert(b.clone(), i); } else if let (Some(Some(m)), Some(i)) = (w.get(&b).cloned(), i) { w.insert(b, Some(m.max(i))); }
    }
    order.iter().map(|b| match w[b] { Some(m) => format!("  {} [{}:0] {};\n", kw, m, vname(b)), None => format!("  {} {};\n", kw, vname(b)) }).collect()
}
/// `.base(base)` connections for every port (bus bits grouped)
pub(crate) fn tb_conns(names: &[String]) -> String {
    let mut order: Vec<String> = vec![];
    for n in names { let b = split_bit(n).map(|x| x.0).unwrap_or(n.clone()); if !order.contains(&b) { order.push(b); } }
    order.iter().map(|b| format!("    .{}({})", vname(b), vname(b))).collect::<Vec<_>>().join(",\n")
}

pub(crate) fn vname(p: &str) -> String {
    if p.chars().all(|c| c.is_ascii_alphanumeric() || c == '_') && !p.chars().next().map(|c| c.is_ascii_digit()).unwrap_or(true) { p.to_string() } else { format!("\\{} ", p) }
}

fn mbist_cycles(m: &MbistState) -> usize {
    let ops: usize = march(&m.algorithm).map(|e| e.iter().map(|x| x.1.len()).sum()).unwrap_or(10);
    ops * m.memories.iter().map(|x| x.4).max().unwrap_or(1) + 50
}

/// JTAG driver tasks for testbenches (TCK period `p` ns)
pub(crate) fn jtag_tasks(p: f64) -> String {
    format!(r#"  reg [7:0] tdr_val;
  task jtag_clk(input tms_v, input tdi_v); begin tms = tms_v; tdi = tdi_v; #({h}); tck = 1; #({h}); tck = 0; end endtask
  task jtag_reset; integer i; begin for (i = 0; i < 6; i = i + 1) jtag_clk(1, 0); jtag_clk(0, 0); end endtask
  task jtag_ir(input integer n, input integer v); integer i; begin
    jtag_clk(1, 0); jtag_clk(1, 0); jtag_clk(0, 0); jtag_clk(0, 0);
    for (i = 0; i < n; i = i + 1) jtag_clk(i == n - 1, (v >> i) & 1);
    jtag_clk(1, 0); jtag_clk(0, 0); end endtask
  task jtag_dr8(input [7:0] v); integer i; begin
    jtag_clk(1, 0); jtag_clk(0, 0); jtag_clk(0, 0);
    for (i = 0; i < 8; i = i + 1) jtag_clk(i == 7, v[i]);
    jtag_clk(1, 0); jtag_clk(0, 0); end endtask
  task jtag_dr8_read(input [7:0] v); integer i; begin
    jtag_clk(1, 0); jtag_clk(0, 0); jtag_clk(0, 0);
    for (i = 0; i < 8; i = i + 1) begin tms = (i == 7); tdi = v[i]; #({h}); tck = 1; #({q}); tdr_val[i] = tdo; #({q}); tck = 0; end
    jtag_clk(1, 0); jtag_clk(0, 0); end endtask
"#, h = p / 2.0, q = p / 4.0)
}

/// net `n` reaches `target` through buffers / hierarchy ports
fn trace_to(nl: &Netlist, n: Option<NetId>, target: Option<NetId>) -> bool {
    let (Some(mut n), Some(t)) = (n, target) else { return false };
    for _ in 0..64 {
        if n == t { return true; }
        let Some(PinRef::Cell(d, _)) = nl.driver(n) else { return false };
        let dc = nl.cell(d);
        let ins: Vec<NetId> = dc.pins.iter().filter(|p| p.dir == Dir::In).filter_map(|p| p.net).collect();
        if ins.len() != 1 { return false; }
        n = ins[0];
    }
    false
}

/// clock / reset net controllable from a port (through combinational logic, ICGs, OCCs)
fn clock_controllable(nl: &Netlist, lib: &crate::liberty::Library, n: NetId, depth: usize) -> bool {
    if depth > 40 { return false; }
    let r = clock_controllable_inner(nl, lib, n, depth);
    if !r && std::env::var("RSYNTH_DFT_DEBUG").is_ok() { eprintln!("uncontrollable net {} driver {:?}", nl.net(n).name, nl.driver(n).map(|d| match d { PinRef::Cell(c, _) => format!("{} {:?}", nl.cell(c).name, nl.cell(c).kind), PinRef::Port(p) => nl.ports[p].name.clone() })); }
    r
}
fn clock_controllable_inner(nl: &Netlist, lib: &crate::liberty::Library, n: NetId, depth: usize) -> bool {
    match nl.driver(n) {
        Some(PinRef::Port(_)) => true,
        None => false,
        Some(PinRef::Cell(d, _)) => {
            let dc = nl.cell(d);
            if let Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1) = dc.kind { return true; }
            // sequential cells (OCC pulse counters) count through their clock / data
            let lc = dc.lib().and_then(|l| lib.cells.get(l));
            if lc.map(|l| l.tie.is_some()).unwrap_or(false) { return true; }
            if lc.and_then(|l| l.seq.as_ref()).map(|s| !s.is_latch).unwrap_or(false) && lc.map(|l| l.icg.is_none()).unwrap_or(true) { return dc.has_attr("dft_ip:") || dc.attrs.iter().any(|a| a.starts_with("dft_ip:")); }
            dc.pins.iter().filter(|p| p.dir == Dir::In).filter_map(|p| p.net).all(|i| clock_controllable(nl, lib, i, depth + 1))
        }
    }
}

/// number of combinational strongly-connected loops among library / generic cells
fn comb_loops(nl: &Netlist, lib: &crate::liberty::Library) -> usize {
    let comb = |c: CellId| { let cl = nl.cell(c); match cl.lib().and_then(|l| lib.cells.get(l)) { Some(lc) => lc.seq.is_none() && lc.icg.is_none(), None => matches!(cl.kind, Kind::Gen(_)) || cl.is_hport() } };
    let ids: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| comb(*c)).collect();
    let mut state: HashMap<CellId, u8> = HashMap::new();
    let mut loops = 0;
    for &s in &ids {
        if state.get(&s).copied().unwrap_or(0) != 0 { continue; }
        let mut stack: Vec<(CellId, Vec<CellId>, usize)> = vec![];
        let succ = |c: CellId| -> Vec<CellId> { nl.cell(c).pins.iter().filter(|p| p.dir == Dir::Out).filter_map(|p| p.net).flat_map(|n| nl.loads(n)).filter_map(|pr| if let PinRef::Cell(x, _) = pr { Some(x) } else { None }).filter(|x| comb(*x)).collect() };
        state.insert(s, 1);
        stack.push((s, succ(s), 0));
        while let Some(top) = stack.last_mut() {
            if top.2 < top.1.len() {
                let v = top.1[top.2];
                top.2 += 1;
                match state.get(&v).copied().unwrap_or(0) { 1 => loops += 1, 0 => { state.insert(v, 1); let sv = succ(v); stack.push((v, sv, 0)); } _ => {} }
            } else { state.insert(top.0, 2); stack.pop(); }
        }
    }
    loops
}
