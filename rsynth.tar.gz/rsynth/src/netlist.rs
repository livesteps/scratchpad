//! Flat, hierarchical-name-preserving netlist database.
//! Cells keep their full hierarchical instance path (`u_core/u_alu/add_12`),
//! so hierarchy-based features (UPF domains, reports, uniquification checks)
//! work on the flattened database.

use std::collections::BTreeMap;
use std::collections::HashMap;

pub type CellId = usize;
pub type NetId = usize;
pub type PortId = usize;

#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
pub enum Dir {
    In,
    Out,
    InOut,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash, PartialOrd, Ord)]
pub enum PinRef {
    Cell(CellId, usize),
    Port(PortId),
}

/// Generic (technology independent) operators.
/// Pin conventions: Buf/Not: A->Y ; 2-in gates A,B->Y ; Mux S,A,B->Y (Y = S?B:A)
/// C0/C1: Y ; Dff: D,CK,Q[,RN][,SN] (active low async) ; Latch: D,G,Q[,RN]
#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
pub enum GOp {
    Buf,
    Not,
    And,
    Or,
    Xor,
    Nand,
    Nor,
    Xnor,
    Mux,
    C0,
    C1,
    Dff,
    Latch,
}

#[derive(Clone, PartialEq, Debug)]
pub enum Kind {
    Gen(GOp),
    Lib(String),
    BlackBox(String),
}

#[derive(Clone, Debug)]
pub struct Pin {
    pub name: String,
    pub dir: Dir,
    pub net: Option<NetId>,
}

#[derive(Clone, Debug)]
pub struct Cell {
    pub name: String,
    pub kind: Kind,
    pub pins: Vec<Pin>,
    pub dont_touch: bool,
    pub loc: Option<(f64, f64)>,
    pub fixed: bool,
    /// free-form attributes (e.g. "empty_module", "unresolved", "iso", "ls", "scan")
    pub attrs: Vec<String>,
}

#[derive(Clone, Debug, Default)]
pub struct Net {
    pub name: String,
    pub conns: Vec<PinRef>,
    pub dont_touch: bool,
}

#[derive(Clone, Debug)]
pub struct Port {
    pub name: String,
    pub dir: Dir,
    pub net: Option<NetId>,
    pub loc: Option<(f64, f64)>,
    pub alive: bool,
}

#[derive(Clone, Debug, Default)]
pub struct Netlist {
    pub name: String,
    pub cells: Vec<Option<Cell>>,
    pub nets: Vec<Option<Net>>,
    pub ports: Vec<Port>,
    cmap: HashMap<String, CellId>,
    nmap: HashMap<String, NetId>,
    pmap: HashMap<String, PortId>,
    uid: usize,
    /// hierarchical instance path -> module name (records the original hierarchy)
    pub hier: Vec<(String, String)>,
    pub mapped: bool,
    /// hierarchical instances under set_dont_touch: no new cells are hosted inside them
    pub frozen_hier: Vec<String>,
    /// hierarchical instances removed by ungroup / flatten (merged into their parent on write)
    pub ungrouped: std::collections::BTreeSet<String>,
    /// ungrouped instances whose cells are written with leaf (simple) names
    pub simple_names: std::collections::BTreeSet<String>,
    /// old -> new names after change_names (cells, nets, ports, hierarchical instances)
    pub aliases: HashMap<String, String>,
    /// original port bit of a hierarchical instance bound to a net (instance, port bit, net); kept
    /// current through net merges so the hierarchical writer can restore port names
    pub port_alias: Vec<(String, String, NetId)>,
    /// declared packed range (left, right) of bus ports: "port" for the top, "inst:port" for
    /// hierarchical instances, so netlists keep [0:15] vs [15:0] and the full interface width
    pub bus_ranges: HashMap<String, (i64, i64)>,
    /// scalar top-level ports whose (escaped) name looks like a bus bit, e.g. \out[0]
    pub scalar_ports: std::collections::HashSet<String>,
}

impl Cell {
    pub fn pin(&self, n: &str) -> Option<usize> {
        self.pins.iter().position(|p| p.name == n)
    }
    pub fn pin_net(&self, n: &str) -> Option<NetId> {
        self.pin(n).and_then(|i| self.pins[i].net)
    }
    pub fn gop(&self) -> Option<GOp> {
        if let Kind::Gen(g) = self.kind {
            Some(g)
        } else {
            None
        }
    }
    pub fn lib(&self) -> Option<&str> {
        if let Kind::Lib(s) = &self.kind {
            Some(s)
        } else {
            None
        }
    }
    pub fn has_attr(&self, a: &str) -> bool {
        self.attrs.iter().any(|x| x == a)
    }
    /// dont_touch or size_only: no removal, restructuring, pin swap, cloning, retiming or
    /// reconnection. Sizing / Vt swap is still allowed for size_only cells (check `dont_touch`).
    /// hierarchical boundary pin (boundary optimization off)
    pub fn is_hport(&self) -> bool {
        self.has_attr("hier_port")
    }
    /// (instance, port bit, is_input) of a boundary pin
    pub fn hport(&self) -> Option<(String, String, bool)> {
        let a = self.attrs.iter().find(|a| a.starts_with("hp:"))?;
        let rest = &a[3..];
        let (inst_port, dir) = rest.rsplit_once(':')?;
        let (inst, port) = inst_port.rsplit_once(':')?;
        Some((inst.to_string(), port.to_string(), dir == "i"))
    }
    pub fn frozen(&self) -> bool {
        self.dont_touch || self.has_attr("size_only")
    }
    pub fn hier_prefix(&self) -> &str {
        match self.name.rfind('/') {
            Some(i) => &self.name[..i],
            None => "",
        }
    }
}

impl Netlist {
    /// Move a host hierarchy out of any dont_touch hierarchy (to the frozen block's parent).
    pub fn outside_frozen(&self, h: &str) -> String {
        let mut h = h.to_string();
        loop {
            let Some(f) = self.frozen_hier.iter().find(|f| h == **f || h.starts_with(&format!("{}/", f))) else { return h };
            h = f.rsplit_once('/').map(|x| x.0.to_string()).unwrap_or_default();
        }
    }
    pub fn new(name: &str) -> Self {
        Netlist { name: name.to_string(), ..Default::default() }
    }
    pub fn fresh(&mut self, prefix: &str) -> String {
        loop {
            self.uid += 1;
            let n = format!("{}{}", prefix, self.uid);
            if !self.cmap.contains_key(&n) && !self.nmap.contains_key(&n) {
                return n;
            }
        }
    }
    pub fn add_net(&mut self, name: &str) -> NetId {
        let mut nm = name.to_string();
        if self.nmap.contains_key(&nm) {
            nm = self.fresh(&format!("{}_", name));
        }
        let id = self.nets.len();
        self.nets.push(Some(Net { name: nm.clone(), ..Default::default() }));
        self.nmap.insert(nm, id);
        id
    }
    pub fn net(&self, n: NetId) -> &Net {
        self.nets[n].as_ref().expect("dead net")
    }
    pub fn net_mut(&mut self, n: NetId) -> &mut Net {
        self.nets[n].as_mut().expect("dead net")
    }
    pub fn net_alive(&self, n: NetId) -> bool {
        self.nets.get(n).map(|x| x.is_some()).unwrap_or(false)
    }
    pub fn cell(&self, c: CellId) -> &Cell {
        self.cells[c].as_ref().expect("dead cell")
    }
    pub fn cell_mut(&mut self, c: CellId) -> &mut Cell {
        self.cells[c].as_mut().expect("dead cell")
    }
    pub fn cell_alive(&self, c: CellId) -> bool {
        self.cells.get(c).map(|x| x.is_some()).unwrap_or(false)
    }
    pub fn net_by_name(&self, n: &str) -> Option<NetId> {
        self.nmap.get(n).copied().filter(|&i| self.net_alive(i)).or_else(|| self.alias_of(n, "net").and_then(|a| self.nmap.get(&a).copied().filter(|&i| self.net_alive(i))))
    }
    pub fn cell_by_name(&self, n: &str) -> Option<CellId> {
        self.cmap.get(n).copied().filter(|&i| self.cell_alive(i)).or_else(|| self.alias_of(n, "cell").and_then(|a| self.cmap.get(&a).copied().filter(|&i| self.cell_alive(i))))
    }
    pub fn port_by_name(&self, n: &str) -> Option<PortId> {
        self.pmap.get(n).copied().filter(|&i| self.ports[i].alive).or_else(|| self.alias_of(n, "port").and_then(|a| self.pmap.get(&a).copied().filter(|&i| self.ports[i].alive)))
    }
    /// new name of a renamed object (also through a renamed hierarchical prefix)
    fn alias_of(&self, n: &str, kind: &str) -> Option<String> {
        if self.aliases.is_empty() {
            return None;
        }
        if let Some(a) = self.aliases.get(&format!("{}:{}", kind, n)) {
            return Some(a.clone());
        }
        // renamed kept-hierarchy instance prefix
        let mut cut = n.len();
        while let Some(i) = n[..cut].rfind('/') {
            if let Some(a) = self.aliases.get(&format!("hier:{}", &n[..i])) {
                let nn = format!("{}{}", a, &n[i..]);
                return self.aliases.get(&format!("{}:{}", kind, nn)).cloned().or(Some(nn));
            }
            cut = i;
        }
        None
    }
    pub fn add_alias(&mut self, kind: &str, old: &str, new: &str) {
        self.aliases.insert(format!("{}:{}", kind, old), new.to_string());
    }
    pub fn rename_port(&mut self, p: PortId, name: &str) {
        let old = self.ports[p].name.clone();
        self.pmap.remove(&old);
        self.pmap.insert(name.to_string(), p);
        self.ports[p].name = name.to_string();
    }
    pub fn rename_net(&mut self, n: NetId, name: &str) {
        if self.nmap.contains_key(name) {
            return;
        }
        let old = self.net(n).name.clone();
        self.nmap.remove(&old);
        self.nmap.insert(name.to_string(), n);
        self.net_mut(n).name = name.to_string();
    }
    pub fn rename_cell(&mut self, c: CellId, name: &str) {
        let old = self.cell(c).name.clone();
        self.cmap.remove(&old);
        self.cmap.insert(name.to_string(), c);
        self.cell_mut(c).name = name.to_string();
    }

    pub fn add_port(&mut self, name: &str, dir: Dir) -> PortId {
        let n = self.add_net(name);
        let id = self.ports.len();
        self.ports.push(Port { name: name.to_string(), dir, net: Some(n), loc: None, alive: true });
        self.pmap.insert(name.to_string(), id);
        self.net_mut(n).conns.push(PinRef::Port(id));
        id
    }
    pub fn remove_port(&mut self, p: PortId) {
        if let Some(n) = self.ports[p].net.take() {
            self.net_mut(n).conns.retain(|x| *x != PinRef::Port(p));
        }
        self.ports[p].alive = false;
        let nm = self.ports[p].name.clone();
        self.pmap.remove(&nm);
    }
    pub fn port_ids(&self) -> Vec<PortId> {
        (0..self.ports.len()).filter(|&i| self.ports[i].alive).collect()
    }

    pub fn add_cell(&mut self, name: &str, kind: Kind, pins: &[(&str, Dir)]) -> CellId {
        let mut nm = name.to_string();
        if self.cmap.contains_key(&nm) {
            nm = self.fresh(&format!("{}_", name));
        }
        let id = self.cells.len();
        self.cells.push(Some(Cell {
            name: nm.clone(),
            kind,
            pins: pins.iter().map(|(n, d)| Pin { name: n.to_string(), dir: *d, net: None }).collect(),
            dont_touch: false,
            loc: None,
            fixed: false,
            attrs: vec![],
        }));
        self.cmap.insert(nm, id);
        id
    }
    pub fn add_gen(&mut self, name: &str, op: GOp, ins: &[NetId], out: NetId) -> CellId {
        let names: &[&str] = match op {
            GOp::Buf | GOp::Not => &["A", "Y"],
            GOp::Mux => &["S", "A", "B", "Y"],
            GOp::C0 | GOp::C1 => &["Y"],
            _ => &["A", "B", "Y"],
        };
        let pins: Vec<(&str, Dir)> =
            names.iter().enumerate().map(|(i, n)| (*n, if i + 1 == names.len() { Dir::Out } else { Dir::In })).collect();
        let c = self.add_cell(name, Kind::Gen(op), &pins);
        for (i, n) in ins.iter().enumerate() {
            self.connect(c, i, *n);
        }
        let last = names.len() - 1;
        self.connect(c, last, out);
        c
    }

    pub fn connect(&mut self, c: CellId, pin: usize, n: NetId) {
        self.disconnect(c, pin);
        self.cell_mut(c).pins[pin].net = Some(n);
        self.net_mut(n).conns.push(PinRef::Cell(c, pin));
    }
    pub fn connect_name(&mut self, c: CellId, pin: &str, n: NetId) -> bool {
        match self.cell(c).pin(pin) {
            Some(i) => {
                self.connect(c, i, n);
                true
            }
            None => false,
        }
    }
    pub fn disconnect(&mut self, c: CellId, pin: usize) {
        if let Some(n) = self.cell_mut(c).pins[pin].net.take() {
            if let Some(net) = self.nets[n].as_mut() {
                net.conns.retain(|x| *x != PinRef::Cell(c, pin));
            }
        }
    }
    pub fn connect_port(&mut self, p: PortId, n: NetId) {
        if let Some(o) = self.ports[p].net.take() {
            self.net_mut(o).conns.retain(|x| *x != PinRef::Port(p));
        }
        self.ports[p].net = Some(n);
        self.net_mut(n).conns.push(PinRef::Port(p));
    }
    pub fn remove_cell(&mut self, c: CellId) {
        let np = self.cell(c).pins.len();
        for i in 0..np {
            self.disconnect(c, i);
        }
        let nm = self.cell(c).name.clone();
        self.cmap.remove(&nm);
        self.cells[c] = None;
    }
    pub fn remove_net(&mut self, n: NetId) {
        if !self.net_alive(n) {
            return;
        }
        let conns = self.net(n).conns.clone();
        for pr in conns {
            match pr {
                PinRef::Cell(c, p) => self.disconnect(c, p),
                PinRef::Port(p) => {
                    self.ports[p].net = None;
                }
            }
        }
        let nm = self.net(n).name.clone();
        self.nmap.remove(&nm);
        self.nets[n] = None;
    }
    /// Move every connection of `from` onto `into` and delete `from`.
    /// Remove boundary pins of instances matching `pred` (opening those boundaries for optimization).
    pub fn dissolve_hports(&mut self, pred: &dyn Fn(&str) -> bool) -> usize {
        let mut n = 0;
        for c in self.cell_ids() {
            if !self.cell_alive(c) || !self.cell(c).is_hport() {
                continue;
            }
            let Some((inst, _, _)) = self.cell(c).hport() else { continue };
            if !pred(&inst) {
                continue;
            }
            let a = self.cell(c).pin_net("A");
            let y = self.cell(c).pin_net("Y");
            self.remove_cell(c);
            if let (Some(a), Some(y)) = (a, y) {
                // keep the driver side's net; a port net always survives
                let y_has_port = self.net(y).conns.iter().any(|p| matches!(p, PinRef::Port(_)));
                if y_has_port && !self.net(a).conns.iter().any(|p| matches!(p, PinRef::Port(_))) {
                    self.merge_net(y, a);
                } else {
                    self.merge_net(a, y);
                }
            }
            n += 1;
        }
        n
    }
    /// boundary pin count per instance
    pub fn hport_count(&self) -> BTreeMap<String, usize> {
        let mut m = BTreeMap::new();
        for c in self.cell_ids() {
            if let Some((i, _, _)) = self.cell(c).hport() {
                *m.entry(i).or_insert(0) += 1;
            }
        }
        m
    }
    pub fn merge_net(&mut self, into: NetId, from: NetId) {
        if into == from {
            return;
        }
        let conns = std::mem::take(&mut self.net_mut(from).conns);
        for pr in conns {
            match pr {
                PinRef::Cell(c, p) => self.cell_mut(c).pins[p].net = Some(into),
                PinRef::Port(p) => self.ports[p].net = Some(into),
            }
            self.net_mut(into).conns.push(pr);
        }
        if self.net(from).dont_touch {
            self.net_mut(into).dont_touch = true;
        }
        for a in self.port_alias.iter_mut() {
            if a.2 == from {
                a.2 = into;
            }
        }
        let nm = self.net(from).name.clone();
        self.nmap.remove(&nm);
        self.nets[from] = None;
    }

    pub fn is_driver(&self, pr: PinRef) -> bool {
        match pr {
            PinRef::Cell(c, p) => matches!(self.cell(c).pins[p].dir, Dir::Out | Dir::InOut),
            PinRef::Port(p) => matches!(self.ports[p].dir, Dir::In | Dir::InOut),
        }
    }
    pub fn is_load(&self, pr: PinRef) -> bool {
        match pr {
            PinRef::Cell(c, p) => matches!(self.cell(c).pins[p].dir, Dir::In | Dir::InOut),
            PinRef::Port(p) => matches!(self.ports[p].dir, Dir::Out | Dir::InOut),
        }
    }
    pub fn drivers(&self, n: NetId) -> Vec<PinRef> {
        self.net(n).conns.iter().copied().filter(|p| self.is_driver(*p)).collect()
    }
    pub fn driver(&self, n: NetId) -> Option<PinRef> {
        self.net(n).conns.iter().copied().find(|p| self.is_driver(*p))
    }
    pub fn loads(&self, n: NetId) -> Vec<PinRef> {
        self.net(n).conns.iter().copied().filter(|p| self.is_load(*p)).collect()
    }
    pub fn driver_cell(&self, n: NetId) -> Option<CellId> {
        match self.driver(n) {
            Some(PinRef::Cell(c, _)) => Some(c),
            _ => None,
        }
    }
    pub fn cell_ids(&self) -> Vec<CellId> {
        (0..self.cells.len()).filter(|&i| self.cells[i].is_some()).collect()
    }
    pub fn net_ids(&self) -> Vec<NetId> {
        (0..self.nets.len()).filter(|&i| self.nets[i].is_some()).collect()
    }
    pub fn pin_name(&self, pr: PinRef) -> String {
        match pr {
            PinRef::Cell(c, p) => format!("{}/{}", self.cell(c).name, self.cell(c).pins[p].name),
            PinRef::Port(p) => self.ports[p].name.clone(),
        }
    }
    pub fn pin_net(&self, pr: PinRef) -> Option<NetId> {
        match pr {
            PinRef::Cell(c, p) => self.cell(c).pins[p].net,
            PinRef::Port(p) => self.ports[p].net,
        }
    }
    pub fn pin_loc(&self, pr: PinRef) -> Option<(f64, f64)> {
        match pr {
            PinRef::Cell(c, _) => self.cell(c).loc,
            PinRef::Port(p) => self.ports[p].loc,
        }
    }
    /// Resolve "inst/pin" or a port name to a PinRef.
    pub fn find_pin(&self, s: &str) -> Option<PinRef> {
        if let Some(p) = self.port_by_name(s) {
            return Some(PinRef::Port(p));
        }
        let i = s.rfind('/')?;
        if let Some(c) = self.cell_by_name(&s[..i]) {
            if let Some(p) = self.cell(c).pin(&s[i + 1..]) {
                return Some(PinRef::Cell(c, p));
            }
        }
        self.find_hier_pin(&s[..i], &s[i + 1..])
    }
    /// hierarchical pin `inst/port` (boundary pin of an instance kept with boundary optimization
    /// off): the pin on the outside of the boundary (A of an input port, Y of an output port)
    pub fn find_hier_pin(&self, inst: &str, port: &str) -> Option<PinRef> {
        let c = self.cell_by_name(&format!("{}/__hp_{}", inst, port))?;
        let cl = self.cell(c);
        if !cl.is_hport() {
            return None;
        }
        let input = cl.attrs.iter().any(|a| a.starts_with("hp:") && a.ends_with(":i"));
        let p = cl.pins.iter().position(|x| x.dir == if input { Dir::In } else { Dir::Out })?;
        Some(PinRef::Cell(c, p))
    }
    /// (instance, port) of a hierarchical boundary cell
    pub fn hier_pin_of(&self, c: CellId) -> Option<(String, String)> {
        let cl = self.cell(c);
        if !cl.is_hport() {
            return None;
        }
        let a = cl.attrs.iter().find(|a| a.starts_with("hp:"))?;
        let body = &a[3..a.len() - 2];
        let (inst, port) = body.rsplit_once(':')?;
        Some((inst.to_string(), port.to_string()))
    }
    /// cell count excluding hierarchical boundary pins
    /// pin belongs to a hierarchical boundary pin cell
    pub fn cell_is_hport(&self, pr: PinRef) -> bool {
        matches!(pr, PinRef::Cell(c, _) if self.cell(c).is_hport())
    }
    pub fn num_cells(&self) -> usize {
        self.cells.iter().filter(|c| c.as_ref().map(|c| !c.is_hport()).unwrap_or(false)).count()
    }
    /// hierarchy instances still present (not ungrouped)
    pub fn kept_hier(&self) -> Vec<(String, String)> {
        self.hier.iter().filter(|(i, _)| !self.ungrouped.contains(i)).cloned().collect()
    }
    pub fn num_nets(&self) -> usize {
        self.nets.iter().filter(|c| c.is_some()).count()
    }
    /// Remove nets with no connections.
    pub fn sweep_nets(&mut self) {
        for n in self.net_ids() {
            if self.net(n).conns.is_empty() {
                self.remove_net(n);
            }
        }
    }
}

/// Simple glob match supporting `*` and `?` (used for get_* collections).
pub fn glob(pat: &str, s: &str) -> bool {
    fn rec(p: &[u8], s: &[u8]) -> bool {
        match (p.first(), s.first()) {
            (None, None) => true,
            (Some(b'*'), _) => rec(&p[1..], s) || (!s.is_empty() && rec(p, &s[1..])),
            (Some(b'?'), Some(_)) => rec(&p[1..], &s[1..]),
            (Some(a), Some(b)) if a == b => rec(&p[1..], &s[1..]),
            _ => false,
        }
    }
    rec(pat.as_bytes(), s.as_bytes())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn connectivity_and_merge() {
        let mut nl = Netlist::new("t");
        let a = nl.add_port("a", Dir::In);
        let y = nl.add_port("y", Dir::Out);
        let (na, ny) = (nl.ports[a].net.unwrap(), nl.ports[y].net.unwrap());
        let m = nl.add_net("m");
        nl.add_gen("u1", GOp::Not, &[na], m);
        nl.add_gen("u2", GOp::Buf, &[m], ny);
        assert_eq!(nl.loads(m).len(), 1);
        assert!(nl.driver(ny).is_some());
        nl.merge_net(m, ny);
        assert_eq!(nl.loads(m).len(), 2);
        assert!(glob("u_*/q_reg[*]", "u_core/q_reg[3]"));
    }
}

impl crate::odb::Odb for Netlist {
    fn put(&self, w: &mut crate::odb::W) {
        self.name.put(w); self.cells.put(w); self.nets.put(w); self.ports.put(w); self.uid.put(w);
        self.hier.put(w); self.mapped.put(w); self.frozen_hier.put(w); self.ungrouped.put(w); self.simple_names.put(w);
        self.aliases.put(w); self.port_alias.put(w); self.bus_ranges.put(w); self.scalar_ports.put(w);
    }
    fn get(r: &mut crate::odb::Rd) -> Result<Self, String> {
        use crate::odb::Odb;
        let mut nl = Netlist { name: Odb::get(r)?, cells: Odb::get(r)?, nets: Odb::get(r)?, ports: Odb::get(r)?, uid: Odb::get(r)?, ..Default::default() };
        nl.hier = Odb::get(r)?; nl.mapped = Odb::get(r)?; nl.frozen_hier = Odb::get(r)?; nl.ungrouped = Odb::get(r)?; nl.simple_names = Odb::get(r)?;
        nl.aliases = Odb::get(r)?; nl.port_alias = Odb::get(r)?; nl.bus_ranges = Odb::get(r)?; nl.scalar_ports = Odb::get(r)?;
        // name indices
        for (i, c) in nl.cells.iter().enumerate() { if let Some(c) = c { nl.cmap.insert(c.name.clone(), i); } }
        for (i, n) in nl.nets.iter().enumerate() { if let Some(n) = n { nl.nmap.insert(n.name.clone(), i); } }
        for (i, p) in nl.ports.iter().enumerate() { if p.alive { nl.pmap.insert(p.name.clone(), i); } }
        Ok(nl)
    }
}
