//! Native GTK 4 GUI (`rsynth -gui`, feature "gtk"): KLayout-style layout view on a black
//! background, schematic tab, and the Tcl interpreter at the bottom. It reads the same state
//! document (gui.rs) and runs the Tcl commands (gui_show_flylines,
//! gui_show_schematic, gui_highlight_power_domain, create_placement_blockage, ...), so a script
//! saved from the GUI replays in the shell.

use crate::json::J;
use crate::session::Session;
use gtk::prelude::*;
use gtk::{cairo, gdk, gio, glib};
use gtk4 as gtk;
use std::cell::{OnceCell, RefCell};
use std::collections::HashMap;
use std::rc::Rc;

// ----------------------------------------------------------------------------------- colours
type Rgb = (f64, f64, f64);
fn hex(h: &str) -> Rgb {
    let v = u32::from_str_radix(h.trim_start_matches('#'), 16).unwrap_or(0xffffff);
    (((v >> 16) & 255) as f64 / 255.0, ((v >> 8) & 255) as f64 / 255.0, (v & 255) as f64 / 255.0)
}
fn hsl(h: f64, s: f64, l: f64) -> Rgb {
    let c = (1.0 - (2.0 * l - 1.0).abs()) * s;
    let hp = (h.rem_euclid(360.0)) / 60.0;
    let x = c * (1.0 - (hp % 2.0 - 1.0).abs());
    let (r, g, b) = match hp as i32 { 0 => (c, x, 0.0), 1 => (x, c, 0.0), 2 => (0.0, c, x), 3 => (0.0, x, c), 4 => (x, 0.0, c), _ => (c, 0.0, x) };
    let m = l - c / 2.0;
    (r + m, g + m, b + m)
}
const PAL: [&str; 10] = ["#4c78a8", "#f58518", "#54a24b", "#b279a2", "#e45756", "#72b7b2", "#eeca3b", "#9d755d", "#bab0ac", "#ff9da6"];
const PDPAL: [&str; 10] = ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e", "#e6ab02", "#a6761d", "#1f78b4", "#b15928", "#6a3d9a"];
/// KLayout-like metal colours
fn metal(i: usize, name: &str) -> Rgb {
    if name == "AP" { return hex("#ff9f1a"); }
    hex(["#5a8cff", "#ff4d4d", "#3cd23c", "#e040fb", "#00d0d0", "#e8e830", "#ff8c00", "#a0a0ff", "#ff80c0", "#80ff80"][i % 10])
}
/// colour + stipple of a LEF layer: routing layers follow the metal palette (same colour as the
/// drawn wires and pin shapes), cuts are white cross-hatched, others grey
fn lef_style(st: &J, name: &str) -> (Rgb, u8) {
    const ST: [u8; 6] = [0, 3, 4, 5, 1, 6];
    let lefl = st.get("lef_layers").arr();
    let kind = lefl.iter().find(|l| l.get("n").s() == name).map(|l| l.get("k").s().to_uppercase()).unwrap_or_else(|| "ROUTING".into());
    let rl: Vec<String> = { let r: Vec<String> = st.get("routes").get("layers").arr().iter().map(|x| x.s().to_string()).collect();
        if r.is_empty() { lefl.iter().filter(|l| l.get("k").s().eq_ignore_ascii_case("ROUTING")).map(|l| l.get("n").s().to_string()).collect() } else { r } };
    match kind.as_str() {
        "ROUTING" => { let i = rl.iter().position(|l| l == name).unwrap_or(name.trim_start_matches(|c: char| !c.is_ascii_digit()).parse::<usize>().unwrap_or(1).saturating_sub(1)); (metal(i, name), ST[i % ST.len()]) }
        "CUT" => (hex("#f0f0f0"), 1),
        "MASTERSLICE" => (hex("#8c8c8c"), 7),
        "IMPLANT" => (hex("#b07cff"), 2),
        "OVERLAP" => (hex("#d0d0d0"), 9),
        _ => (hex("#a0a0a0"), 2),
    }
}
fn set(cr: &cairo::Context, c: Rgb, a: f64) {
    cr.set_source_rgba(c.0, c.1, c.2, a);
}
/// screen-fixed stipple pattern (KLayout style): 0 = /, 1 = cross, 2 = dots, 3 = \\, 4 = horizontal,
/// 5 = vertical, 6 = grid, 7 = dense dots, 8 = solid, 9 = hollow
fn stipple(c: Rgb, kind: u8, a: f64) -> Option<cairo::SurfacePattern> {
    if kind == 9 { return None; }
    let n = 8;
    let surf = cairo::ImageSurface::create(cairo::Format::ARgb32, n, n).ok()?;
    {
        let cr = cairo::Context::new(&surf).ok()?;
        cr.set_source_rgba(c.0, c.1, c.2, a);
        for k in 0..n {
            match kind {
                0 => cr.rectangle(k as f64, (n - 1 - k) as f64, 1.0, 1.0),
                1 => { cr.rectangle(k as f64, (n - 1 - k) as f64, 1.0, 1.0); cr.rectangle(k as f64, k as f64, 1.0, 1.0); }
                3 => cr.rectangle(k as f64, k as f64, 1.0, 1.0),
                4 => if k == 0 { cr.rectangle(0.0, 0.0, n as f64, 1.0); } else if k == 4 { cr.rectangle(0.0, 4.0, n as f64, 1.0); },
                5 => if k == 0 { cr.rectangle(0.0, 0.0, 1.0, n as f64); } else if k == 4 { cr.rectangle(4.0, 0.0, 1.0, n as f64); },
                6 => if k == 0 { cr.rectangle(0.0, 0.0, n as f64, 1.0); cr.rectangle(0.0, 0.0, 1.0, n as f64); },
                7 => if k % 2 == 0 { for j in (0..n).step_by(2) { cr.rectangle(k as f64, j as f64, 1.0, 1.0); } },
                8 => if k == 0 { cr.rectangle(0.0, 0.0, n as f64, n as f64); },
                _ => if k % 4 == 0 { cr.rectangle(k as f64, k as f64, 1.0, 1.0); cr.rectangle(k as f64, ((k + 4) % n) as f64, 1.0, 1.0); },
            }
        }
        let _ = cr.fill();
    }
    let p = cairo::SurfacePattern::create(&surf);
    p.set_extend(cairo::Extend::Repeat);
    Some(p)
}

// ----------------------------------------------------------------------------------- state
#[derive(Clone)]
struct View { s: f64, ox: f64, oy: f64 }

struct Ui {
    st: J,
    view: View,
    need_fit: bool,
    size: (f64, f64),
    vis: Vec<(&'static str, &'static str, bool)>,
    rvis: HashMap<String, bool>,
    tool: usize,
    opt: HashMap<&'static str, String>,
    drag: Option<(f64, f64, f64, f64, u32, View)>,
    mouse: (f64, f64),
    sel: Option<String>,
    /// boundary of the last clicked non-cell object (for zoom-to-selection)
    sel_rect: Option<(f64, f64, f64, f64)>,
    fly_click: bool,
    script: Vec<String>,
    hist: Vec<String>,
    hpos: usize,
    sch: Option<SchG>,
    sview: View,
    ssize: (f64, f64),
    sch_fit: bool,
    sch_sel: Option<String>,
    sdrag: Option<(f64, f64, View)>,
    zoom_k: i64,
    pending_zoom: Option<(f64, f64, f64, f64)>,
    /// net highlighted in the layout (clicked wire / special shape / schematic pin)
    hl_net: Option<String>,
    /// points of the wire being drawn (Wire tool)
    wpts: Vec<(f64, f64)>,
    /// current marker (Prev / Next)
    mk_i: Option<usize>,
    /// schematic: pin names on all cells
    sch_pins: bool,
    /// schematic: right-button zoom box (screen coordinates)
    sband: Option<(f64, f64, f64, f64)>,
    sch_hl_net: Option<String>,
    /// ruler: first point of a two-click measurement
    rstart: Option<(f64, f64)>,
    /// last object shown in the query panel
    queried: Option<(String, String)>,
    /// QUERY pane pages: (kind, name) of the selected objects, current page
    qlist: Vec<(String, String)>,
    qpos: usize,
    /// properties of the last clicked non-netlist object (blockage, marker, ...) for Q
    last_hit: Option<(String, String, Option<QTabs>)>,
    /// instances selected in the layout, highlighted in the schematic
    sch_msel: std::collections::HashSet<String>,
    /// selected top-level ports and pins (layout highlight)
    sel_ports: std::collections::HashSet<String>,
    sel_pins: std::collections::HashSet<String>,
    /// pin markers of the selected instances: (x, y, pin, connected)
    pin_marks: Vec<(f64, f64, String, bool)>,
    /// the current left drag pans the view (Ctrl / middle button) instead of drawing a selection box
    drag_pan: bool,
}

const TOOLS: [&str; 11] = ["Select / pan", "Placement blockage", "Routing blockage", "Route guide", "Bound", "Voltage area", "Wire (manual / NDR route)", "Via", "Delete wires", "PG / special wire", "Ruler (measure)"];
const T_RULER: usize = 10;
const T_WIRE: usize = 6;
const T_VIA: usize = 7;
const T_DEL: usize = 8;
const T_PGW: usize = 9;

/// FPObjects class of a special shape
fn special_class(kind: &str) -> &'static str {
    match kind {
        "ring" | "block_ring" => "pgrings",
        "stripe" => "pgstripes",
        "followpin" => "pgrails",
        "pg_via" => "pgvias",
        "strap" | "pg_wire" | "blockwire" | "special_wire" => "specialnets",
        _ => "special",
    }
}
fn is_ground(n: &str) -> bool {
    let u = n.to_uppercase();
    u.contains("VSS") || u.contains("GND") || u.starts_with("VSS")
}

impl Ui {
    fn new() -> Ui {
        let vis = vec![
            ("die", "Die / core", true), ("rows", "Rows", false), ("tracks", "Tracks", false), ("cells", "Standard cells", true), ("phys", "Physical cells (fill / tap / end cap)", true), ("macros", "Macros", true), ("pads", "IO pads", true),
            ("pins", "IO pins", true), ("mpins", "Macro pin shapes", true), ("pblk", "Placement blockages", true), ("rblk", "Routing blockages", true),
            ("guides", "Route guides", true), ("bounds", "Bounds", true), ("vas", "Voltage areas", true), ("cong", "Congestion map", false),
            ("fly", "Flylines", true), ("special", "Seal ring / RDL", true),
            ("pgrings", "PG rings (core / block)", true), ("pgstripes", "PG stripes", true), ("pgrails", "PG followpins (std-cell rails)", true), ("pgvias", "PG via arrays", true),
            ("specialnets", "Special nets (straps / PG wires)", true), ("fills", "Metal fill", true), ("markers", "DRC / LVS markers", true), ("bumps", "Bumps", true), ("bonds", "Bond pads", true),
            ("vias", "Vias", true), ("labels", "Labels", true),
        ];
        let mut opt = HashMap::new();
        for (k, v) in [("pk", "hard"), ("pp", "50"), ("rl", "M1 M2"), ("gn", ""), ("gu", ""), ("vpd", ""), ("vg", "0"), ("bk", "soft"), ("bm", ""), ("wn", ""), ("wl", "M2"), ("wl2", "M3"), ("wr", "(default)"), ("dk", "signal wires"), ("pw", ""), ("rs", "manufacturing grid (0.005)"), ("ra", "any angle"), ("rgv", "0.1")] { opt.insert(k, v.to_string()); }
        Ui { st: J::Null, view: View { s: 1.0, ox: 0.0, oy: 0.0 }, need_fit: true, size: (800.0, 600.0), vis, rvis: HashMap::new(), tool: 0, opt, drag: None, mouse: (0.0, 0.0),
            sel: None, sel_rect: None, fly_click: true, script: vec![], hist: vec![], hpos: 0, sch: None, sview: View { s: 1.0, ox: 0.0, oy: 0.0 }, ssize: (800.0, 600.0), sch_fit: true, sch_sel: None, sdrag: None, zoom_k: 0, pending_zoom: None,
            hl_net: None, wpts: vec![], mk_i: None, sch_pins: true, sband: None, sch_hl_net: None, rstart: None, queried: None,
            qlist: vec![], qpos: 0, last_hit: None, sch_msel: Default::default(), sel_ports: Default::default(), sel_pins: Default::default(), pin_marks: vec![], drag_pan: false }
    }
    fn on(&self, k: &str) -> bool {
        self.vis.iter().find(|v| v.0 == k).map(|v| v.2).unwrap_or(true)
    }
    fn w2s(&self, x: f64, y: f64) -> (f64, f64) {
        (x * self.view.s + self.view.ox, self.size.1 - (y * self.view.s + self.view.oy))
    }
    fn s2w(&self, px: f64, py: f64) -> (f64, f64) {
        ((px - self.view.ox) / self.view.s, ((self.size.1 - py) - self.view.oy) / self.view.s)
    }
    fn fit(&mut self) {
        let Some(d) = self.st.get("die").rect() else { return };
        let m = 24.0;
        let (w, h) = ((d.2 - d.0).max(1e-3), (d.3 - d.1).max(1e-3));
        self.view.s = ((self.size.0 - 2.0 * m) / w).min((self.size.1 - 2.0 * m) / h).max(1e-6);
        self.view.ox = m - d.0 * self.view.s + ((self.size.0 - 2.0 * m) - w * self.view.s) / 2.0;
        self.view.oy = m - d.1 * self.view.s + ((self.size.1 - 2.0 * m) - h * self.view.s) / 2.0;
    }
    fn zoom_rect(&mut self, r: (f64, f64, f64, f64)) {
        let m = 24.0;
        let (w, h) = ((r.2 - r.0).max(1e-3), (r.3 - r.1).max(1e-3));
        self.view.s = ((self.size.0 - 2.0 * m) / w).min((self.size.1 - 2.0 * m) / h).max(1e-6);
        self.view.ox = m - r.0 * self.view.s + ((self.size.0 - 2.0 * m) - w * self.view.s) / 2.0;
        self.view.oy = m - r.1 * self.view.s + ((self.size.1 - 2.0 * m) - h * self.view.s) / 2.0;
    }
    fn zoom(&mut self, f: f64, px: f64, py: f64) {
        let (wx, wy) = self.s2w(px, py);
        self.view.s *= f;
        self.view.ox = px - wx * self.view.s;
        self.view.oy = (self.size.1 - py) - wy * self.view.s;
    }
    /// bounding box of everything selected: clicked object, selected cells, flyline cells
    fn sel_bbox(&self) -> Option<(f64, f64, f64, f64)> {
        let st = &self.st;
        let mut names: Vec<String> = st.get("sel").arr().iter().map(|x| x.s().to_string()).collect();
        names.extend(st.get("fly").get("macros").arr().iter().map(|x| x.s().to_string()));
        if let Some(n) = &self.sel { names.push(n.clone()); }
        let mut bb: Option<(f64, f64, f64, f64)> = self.sel_rect;
        let mut add = |r: (f64, f64, f64, f64)| { bb = Some(match bb { Some(b) => (b.0.min(r.0), b.1.min(r.1), b.2.max(r.2), b.3.max(r.3)), None => r }); };
        if !names.is_empty() {
            for c in st.get("cells").arr() {
                let a = c.arr();
                if a.len() < 4 || !names.iter().any(|n| n == a[0].s()) { continue; }
                let (w, h) = if a.len() >= 10 { (a[8].f(), a[9].f()) } else { (a[3].f(), a[3].f()) };
                add((a[1].f() - w / 2.0, a[2].f() - h / 2.0, a[1].f() + w / 2.0, a[2].f() + h / 2.0));
            }
            for p in st.get("ports").arr() { if names.iter().any(|n| n == p.at(0).s()) { add((p.at(1).f(), p.at(2).f(), p.at(1).f(), p.at(2).f())); } }
        }
        bb
    }
    /// centre the selection in the window, at a size that leaves context around it
    fn zoom_sel(&mut self) -> bool {
        let Some(r) = self.sel_bbox() else { return false };
        let die = self.st.get("die").rect().unwrap_or((0.0, 0.0, 100.0, 100.0));
        let minw = ((die.2 - die.0).max(die.3 - die.1) / 200.0).max(1.0);
        let (cx, cy) = ((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0);
        let (w, h) = (((r.2 - r.0) * 1.6).max(minw), ((r.3 - r.1) * 1.6).max(minw));
        self.zoom_rect((cx - w / 2.0, cy - h / 2.0, cx + w / 2.0, cy + h / 2.0));
        true
    }
    /// ruler snap step (um), 0 = off
    fn ruler_grid(&self) -> f64 {
        let m = self.opt.get("rs").map(|s| s.as_str()).unwrap_or("");
        if m.starts_with("off") { 0.0 }
        else if m.starts_with("manufacturing") { 0.005 }
        else if m.starts_with("routing") { let g = self.st.get("routes").get("w").f(); if g > 0.0 { g } else { 0.005 } }
        else if m.starts_with("custom") { self.opt.get("rgv").and_then(|v| v.trim().parse::<f64>().ok()).filter(|v| *v > 0.0).unwrap_or(0.1) }
        else { m.split_whitespace().next().and_then(|v| v.parse().ok()).unwrap_or(0.005) }
    }
    /// ruler end point: snapped to the grid, constrained by the angle mode relative to `from`
    fn ruler_pt(&self, px: f64, py: f64, from: Option<(f64, f64)>) -> (f64, f64) {
        let (x, y) = self.s2w(px, py);
        let g = self.ruler_grid();
        let sn = |v: f64| if g > 0.0 { (v / g).round() * g } else { v };
        let Some((x0, y0)) = from else { return (sn(x), sn(y)) };
        let (dx, dy) = (x - x0, y - y0);
        match self.opt.get("ra").map(|s| s.as_str()).unwrap_or("") {
            "orthogonal" => if dx.abs() >= dy.abs() { (sn(x), y0) } else { (x0, sn(y)) },
            "45 degree" => {
                let a = (dy.atan2(dx) / std::f64::consts::FRAC_PI_4).round() * std::f64::consts::FRAC_PI_4;
                let (c, s) = (a.cos(), a.sin());
                let l = dx * c + dy * s;
                if c.abs() > 0.1 && s.abs() > 0.1 { let d = sn(l * c.abs()); (x0 + d * c.signum(), y0 + d * s.signum()) } else { (sn(x0 + l * c), sn(y0 + l * s)) }
            }
            _ => (sn(x), sn(y)),
        }
    }
    /// snap a wire point to the routing grid, orthogonal to the previous point
    fn wire_pt(&self, px: f64, py: f64) -> (f64, f64) {
        let (mut x, mut y) = self.s2w(px, py);
        let g = self.st.get("routes").get("w").f();
        if g > 0.0 { x = (x / g).round() * g; y = (y / g).round() * g; }
        if let Some(&(lx, ly)) = self.wpts.last() { if (x - lx).abs() >= (y - ly).abs() { y = ly; } else { x = lx; } }
        (x, y)
    }
    fn pdhl(&self) -> Vec<String> {
        self.st.get("pdhl").arr().iter().map(|x| x.s().to_string()).collect()
    }
}

// ----------------------------------------------------------------------------------- layout drawing
fn rect_s(ui: &Ui, r: (f64, f64, f64, f64)) -> (f64, f64, f64, f64) {
    let (a, b) = ui.w2s(r.0, r.3);
    let (c, d) = ui.w2s(r.2, r.1);
    (a, b, (c - a).max(0.5), (d - b).max(0.5))
}
fn label(cr: &cairo::Context, ui: &Ui, t: &str, x: f64, y: f64, c: Rgb, size: f64) {
    if !ui.on("labels") { return; }
    set(cr, c, 1.0);
    cr.set_font_size(size);
    cr.move_to(x, y);
    let _ = cr.show_text(t);
}
fn shape(cr: &cairo::Context, ui: &Ui, r: (f64, f64, f64, f64), c: Rgb, kind: u8, fill_a: f64, lw: f64, dash: bool) {
    let (x, y, w, h) = rect_s(ui, r);
    if fill_a > 0.0 {
        if let Some(p) = stipple(c, kind, fill_a) {
            let _ = cr.set_source(&p);
            cr.rectangle(x, y, w, h);
            let _ = cr.fill();
        }
    }
    set(cr, c, 1.0);
    cr.set_line_width(lw);
    if dash { cr.set_dash(&[5.0, 3.0], 0.0); }
    cr.rectangle(x + 0.5, y + 0.5, w, h);
    let _ = cr.stroke();
    cr.set_dash(&[], 0.0);
}

fn draw_layout(cr: &cairo::Context, ui: &Ui) {
    let (w, h) = ui.size;
    cr.set_source_rgb(0.0, 0.0, 0.0);
    cr.rectangle(0.0, 0.0, w, h);
    let _ = cr.fill();
    cr.select_font_face("Sans", cairo::FontSlant::Normal, cairo::FontWeight::Normal);
    let st = &ui.st;
    let Some(die) = st.get("die").rect() else {
        label(cr, ui, "No floorplan (read_def / initialize_floorplan)", 20.0, 30.0, hex("#c0c0c0"), 14.0);
        return;
    };
    let pdhl = ui.pdhl();
    let pds = st.get("pds").arr();
    let pdc = |i: i64| if i < 0 { hex("#999999") } else { hex(PDPAL[i as usize % 10]) };
    // die, core, rows
    if ui.on("die") {
        shape(cr, ui, die, hex("#ffffff"), 0, 0.0, 1.2, false);
        if let Some(c) = st.get("core").rect() { shape(cr, ui, c, hex("#808080"), 0, 0.0, 1.0, true); }
    }
    let row_h = st.get("row_h").f();
    // explicit rows (create_row / cut_row): outline per row segment, orientation tick
    let rowl = st.get("rowl").arr();
    if ui.on("rows") && !rowl.is_empty() && row_h * ui.view.s > 3.0 {
        cr.set_line_width(0.7);
        for r in rowl {
            let a = r.arr();
            if a.len() < 5 { continue; }
            let (sx, sy, sw, sh) = rect_s(ui, (a[0].f(), a[1].f(), a[2].f(), a[3].f()));
            if sx > ui.size.0 || sy > ui.size.1 || sx + sw < 0.0 || sy + sh < 0.0 { continue; }
            cr.set_source_rgba(0.45, 0.45, 0.45, 1.0);
            cr.rectangle(sx + 0.5, sy + 0.5, sw - 1.0, sh - 1.0);
            let _ = cr.stroke();
            // N: tick at the bottom-left, FS: at the top-left (where the ground rail is)
            if sh > 8.0 {
                let ty = if a[4].s().contains('S') { sy + 2.0 } else { sy + sh - 2.0 };
                cr.move_to(sx + 1.0, ty);
                cr.line_to(sx + (sh * 0.5).min(8.0), ty);
                let _ = cr.stroke();
            }
        }
    } else if ui.on("rows") && row_h > 0.0 && row_h * ui.view.s > 3.0 {
        let reg = st.get("core").rect().unwrap_or(die);
        cr.set_source_rgba(0.35, 0.35, 0.35, 1.0);
        cr.set_line_width(0.6);
        let mut y = reg.1;
        while y <= reg.3 + 1e-6 {
            let (a, b) = ui.w2s(reg.0, y);
            let (c, _) = ui.w2s(reg.2, y);
            cr.move_to(a, b.round() + 0.5);
            cr.line_to(c, b.round() + 0.5);
            y += row_h;
        }
        let _ = cr.stroke();
    }
    // routing tracks (zoomed in enough to resolve them)
    if ui.on("tracks") {
        cr.set_line_width(0.5);
        for t in st.get("tracks").arr() {
            let a = t.arr();
            if a.len() < 5 { continue; }
            let (ly, dir, start, num, step) = (a[0].s(), a[1].s(), a[2].f(), a[3].i().max(0) as usize, a[4].f());
            if step * ui.view.s < 4.0 || !ui.rvis.get(ly).copied().unwrap_or(true) { continue; }
            let (c, _) = lef_style(st, ly);
            set(cr, c, 0.35);
            // only the tracks inside the window
            let (wx0, wy1) = ui.s2w(0.0, 0.0);
            let (wx1, wy0) = ui.s2w(ui.size.0, ui.size.1);
            let (lo, hi) = if dir == "X" { (wx0, wx1) } else { (wy0, wy1) };
            let k0 = (((lo - start) / step).floor().max(0.0)) as usize;
            let k1 = ((((hi - start) / step).ceil().max(0.0)) as usize).min(num);
            for k in k0..k1 {
                let v = start + k as f64 * step;
                if dir == "X" { let (sx, _) = ui.w2s(v, 0.0); cr.move_to(sx.round() + 0.5, 0.0); cr.line_to(sx.round() + 0.5, ui.size.1); }
                else { let (_, sy) = ui.w2s(0.0, v); cr.move_to(0.0, sy.round() + 0.5); cr.line_to(ui.size.0, sy.round() + 0.5); }
            }
            let _ = cr.stroke();
        }
    }
    // congestion
    if ui.on("cong") {
        let g = st.get("cong");
        if !g.is_null() {
            let (nx, ny, gg) = (g.get("nx").i() as usize, g.get("ny").i() as usize, g.get("g").f());
            let u = g.get("u").arr();
            for j in 0..ny {
                for i in 0..nx {
                    let v = u.get(j * nx + i).map(|x| x.f()).unwrap_or(0.0);
                    if v < 0.05 { continue; }
                    let x0 = die.0 + i as f64 * gg;
                    let y0 = die.1 + j as f64 * gg;
                    let (x, y, ww, hh) = rect_s(ui, (x0, y0, (x0 + gg).min(die.2), (y0 + gg).min(die.3)));
                    let c = hsl(120.0 - 120.0 * v.min(1.2) / 1.2, 0.85, 0.5);
                    set(cr, c, (0.12 + 0.35 * v).min(0.5));
                    cr.rectangle(x, y, ww, hh);
                    let _ = cr.fill();
                }
            }
        }
    }
    // bounds, voltage areas, blockages, guides
    if ui.on("bounds") {
        for b in st.get("bounds").arr() {
            if pds.iter().any(|d| d.get("van").s() == b.get("n").s() && !b.get("n").s().is_empty()) { continue; }
            let Some(r) = b.get("r").rect() else { continue };
            let k = b.get("k").s();
            let c = hex(if k == "exclusive" { "#2ca02c" } else if k == "hard" { "#54a24b" } else { "#8fbf7f" });
            shape(cr, ui, r, c, 2, 0.5, 1.2, k == "soft");
            let (x, y, _, _) = rect_s(ui, r);
            label(cr, ui, &format!("{} ({})", b.get("n").s(), k), x + 3.0, y + 12.0, c, 11.0);
        }
    }
    if ui.on("vas") {
        for (i, d) in pds.iter().enumerate() {
            let Some(r) = d.get("va").rect() else { continue };
            let on = pdhl.iter().any(|n| n == d.get("n").s());
            let c = pdc(i as i64);
            shape(cr, ui, r, c, 2, if on { 0.9 } else { 0.45 }, if on { 3.0 } else { 1.4 }, false);
            if let Some(vi) = d.get("vin").rect() { if vi != r { shape(cr, ui, vi, c, 0, 0.0, 1.0, true); } }
            let (x, y, _, _) = rect_s(ui, r);
            let v = d.get("v");
            label(cr, ui, &format!("{} · {}{}{}", d.get("van").s(), d.get("n").s(), if v.is_null() { String::new() } else { format!(" {:.2}V", v.f()) }, if d.get("sw").b() { " (switchable)" } else { "" }), x + 3.0, y + 12.0, c, 11.0);
        }
    }
    if ui.on("pblk") {
        for b in st.get("pblk").arr() {
            let n = b.get("n").s();
            if n.contains("__guard_") { continue; }
            let Some(r) = b.get("r").rect() else { continue };
            let k = b.get("k").s();
            let c = hex(if k.starts_with("soft") { "#ff7f0e" } else if k.starts_with("partial") { "#bcbd22" } else { "#d62728" });
            shape(cr, ui, r, c, 0, 0.8, 1.2, false);
            let (x, y, _, _) = rect_s(ui, r);
            label(cr, ui, &format!("{} {}", n, k), x + 3.0, y + 12.0, c, 10.0);
        }
    }
    if ui.on("rblk") {
        for b in st.get("rblk").arr() {
            let Some(r) = b.get("r").rect() else { continue };
            let c = hex("#1f77b4");
            shape(cr, ui, r, c, 1, 0.8, 1.2, false);
            let (x, y, _, _) = rect_s(ui, r);
            label(cr, ui, &format!("{} [{}]", b.get("n").s(), b.get("l").s()), x + 3.0, y + 12.0, c, 10.0);
        }
    }
    if ui.on("guides") {
        for g in st.get("guides").arr() {
            let Some(r) = g.get("r").rect() else { continue };
            let c = hex("#17becf");
            shape(cr, ui, r, c, 2, 0.4, 1.0, true);
            let (x, y, _, _) = rect_s(ui, r);
            label(cr, ui, g.get("n").s(), x + 3.0, y + 12.0, c, 10.0);
        }
    }
    // cells
    let colorby_pd = st.get("colorby").s() == "pd";
    let sel: Vec<&str> = st.get("sel").arr().iter().map(|x| x.s()).collect();
    let fly_cells: Vec<&str> = st.get("fly").get("macros").arr().iter().map(|x| x.s()).collect();
    for c in st.get("cells").arr() {
        let a = c.arr();
        if a.len() < 8 { continue; }
        let (name, x, y, t, gi, fixed, di) = (a[0].s(), a[1].f(), a[2].f(), a[4].s(), a[5].i(), a[6].i(), a[7].i());
        let (cw, ch) = if a.len() >= 10 { (a[8].f(), a[9].f()) } else { (a[3].f(), a[3].f()) };
        let kind = match t { "b" => "macros", "p" => "pads", "f" => "phys", _ => "cells" };
        if !ui.on(kind) { continue; }
        let r = (x - cw / 2.0, y - ch / 2.0, x + cw / 2.0, y + ch / 2.0);
        let dom = if di >= 0 { pds.get(di as usize) } else { None };
        let lit = pdhl.is_empty() || dom.map(|d| pdhl.iter().any(|n| n == d.get("n").s())).unwrap_or(false);
        let col = match t {
            "b" => hex("#c8c8c8"),
            "p" => hex("#a0a0ff"),
            "f" => hex("#6e6e6e"),
            _ => if colorby_pd { pdc(di) } else { hex(PAL[gi.max(0) as usize % 10]) },
        };
        let (sx, sy, sw, sh) = rect_s(ui, r);
        if sx > ui.size.0 || sy > ui.size.1 || sx + sw < 0.0 || sy + sh < 0.0 { continue; }
        let alpha = if lit { 1.0 } else { 0.18 };
        if sw < 2.0 && sh < 2.0 {
            set(cr, col, alpha);
            cr.rectangle(sx, sy, sw.max(1.0), sh.max(1.0));
            let _ = cr.fill();
        } else {
            let k = match t { "b" | "p" => 1, "s" => 2, "f" => 7, _ => 0 };
            if let Some(p) = stipple(col, k, 0.85 * alpha) { let _ = cr.set_source(&p); cr.rectangle(sx, sy, sw, sh); let _ = cr.fill(); }
            set(cr, col, alpha);
            cr.set_line_width(if t == "b" || t == "p" { 1.6 } else if fixed != 0 { 1.4 } else { 0.8 });
            cr.rectangle(sx + 0.5, sy + 0.5, sw - 1.0, sh - 1.0);
            let _ = cr.stroke();
            if t == "u" { set(cr, hex("#e377c2"), alpha); cr.set_line_width(2.0); cr.rectangle(sx, sy, sw, sh); let _ = cr.stroke(); }
            if t == "i" { set(cr, col, alpha); cr.move_to(sx, sy); cr.line_to(sx + sw, sy + sh); cr.move_to(sx + sw, sy); cr.line_to(sx, sy + sh); let _ = cr.stroke(); }
            // KLayout-style instance labels when there is room
            if sw > 40.0 && sh > 12.0 && ui.on("labels") {
                let short = if t == "b" || t == "p" { name } else { name.rsplit('/').next().unwrap_or(name) };
                cr.set_font_size(((sh * 0.18).min(14.0)).max(8.0));
                if let Ok(ext) = cr.text_extents(short) {
                    if ext.width() < sw - 4.0 {
                        set(cr, col, alpha);
                        cr.move_to(sx + (sw - ext.width()) / 2.0, sy + sh / 2.0 + ext.height() / 2.0);
                        let _ = cr.show_text(short);
                    }
                }
            }
        }
        if let Some(d) = dom {
            if let Some(vi) = d.get("vin").rect() {
                if lit && (!pdhl.is_empty() || colorby_pd) && !(x >= vi.0 && x <= vi.2 && y >= vi.1 && y <= vi.3) {
                    set(cr, hex("#ff3030"), 1.0);
                    cr.set_line_width(2.0);
                    cr.move_to(sx, sy); cr.line_to(sx + sw, sy + sh); cr.move_to(sx + sw, sy); cr.line_to(sx, sy + sh);
                    let _ = cr.stroke();
                }
            }
        }
        let is_sel = sel.contains(&name) || ui.sel.as_deref() == Some(name);
        let is_fly = fly_cells.contains(&name);
        if is_sel || is_fly {
            set(cr, if is_sel { hex("#ffffff") } else { hex("#ff9f1a") }, 1.0);
            cr.set_line_width(2.2);
            cr.rectangle(sx - 2.0, sy - 2.0, sw + 4.0, sh + 4.0);
            let _ = cr.stroke();
        }
    }
    // macro / pad pin shapes
    if ui.on("mpins") && ui.view.s > 0.5 {
        let ls: Vec<String> = st.get("routes").get("layers").arr().iter().map(|x| x.s().to_string()).collect();
        for p in st.get("mpins").arr() {
            let Some(r) = p.at(0).rect() else { continue };
            let ly = p.at(1).s();
            let _ = &ls;
            if !ui.rvis.get(ly).copied().unwrap_or(true) { continue; }
            let (c, kd) = lef_style(st, ly);
            shape(cr, ui, r, c, kd, 0.9, 1.0, false);
            let (x, y, ww, _) = rect_s(ui, r);
            if ww > 14.0 { label(cr, ui, p.at(2).s(), x + 1.0, y - 2.0, c, 8.0); }
        }
    }
    // routed wires and vias
    let rt = st.get("routes");
    if !rt.is_null() {
        let ls: Vec<String> = rt.get("layers").arr().iter().map(|x| x.s().to_string()).collect();
        let lw = (rt.get("w").f() * 0.6 * ui.view.s).clamp(0.6, 6.0);
        cr.set_line_cap(cairo::LineCap::Square);
        let hl_i: Option<i64> = ui.hl_net.as_ref().and_then(|n| rt.get("nets").arr().iter().position(|x| x.s() == n).map(|i| i as i64));
        let any_hl = ui.hl_net.is_some();
        for li in 0..ls.len() {
            if !ui.rvis.get(&ls[li]).copied().unwrap_or(true) { continue; }
            set(cr, metal(li, &ls[li]), if any_hl { 0.3 } else { 0.85 });
            cr.set_line_width(lw);
            let mut any = false;
            for s in rt.get("segs").arr() {
                let a = s.arr();
                if a.len() < 5 || a[0].i() as usize != li { continue; }
                let (x1, y1) = ui.w2s(a[1].f(), a[2].f());
                let (x2, y2) = ui.w2s(a[3].f(), a[4].f());
                cr.move_to(x1, y1);
                cr.line_to(x2, y2);
                any = true;
            }
            if any { let _ = cr.stroke(); }
        }
        if let Some(hi) = hl_i {
            // highlighted net on top: bright, wider, layer colour core
            for s in rt.get("segs").arr() {
                let a = s.arr();
                if a.len() < 6 || a[5].i() != hi { continue; }
                let li = a[0].i() as usize;
                let (x1, y1) = ui.w2s(a[1].f(), a[2].f());
                let (x2, y2) = ui.w2s(a[3].f(), a[4].f());
                set(cr, hex("#ffffff"), 1.0);
                cr.set_line_width(lw + 3.0);
                cr.move_to(x1, y1); cr.line_to(x2, y2);
                let _ = cr.stroke();
                set(cr, metal(li, ls.get(li).map(|s| s.as_str()).unwrap_or("")), 1.0);
                cr.set_line_width(lw);
                cr.move_to(x1, y1); cr.line_to(x2, y2);
                let _ = cr.stroke();
            }
        }
        cr.set_line_cap(cairo::LineCap::Butt);
        if ui.on("vias") {
            let z = (lw * 1.6).max(2.0);
            for v in rt.get("vias").arr() {
                let a = v.arr();
                if a.len() < 3 { continue; }
                let (x, y) = ui.w2s(a[0].f(), a[1].f());
                let lo = a[2].i() as usize;
                set(cr, hex("#ffffff"), 0.8);
                cr.set_line_width(0.8);
                cr.rectangle(x - z / 2.0, y - z / 2.0, z, z);
                let _ = cr.stroke();
                let _ = lo;
            }
        }
    }
    // metal fill (add_metal_fill): outlined, faint
    if ui.on("fills") {
        let (vx0, vy1) = ui.s2w(0.0, 0.0);
        let (vx1, vy0) = ui.s2w(ui.size.0, ui.size.1);
        for f in st.get("fills").arr().iter() {
            let ly = f.at(0).s();
            if !ui.rvis.get(ly).copied().unwrap_or(true) { continue; }
            let Some(r) = f.at(1).rect() else { continue };
            if r.2 < vx0 || r.0 > vx1 || r.3 < vy0 || r.1 > vy1 { continue; }
            let c = metal(ly.trim_start_matches('M').parse::<usize>().unwrap_or(7).saturating_sub(1), ly);
            let (x, y, ww, hh) = rect_s(ui, r);
            set(cr, c, 0.18);
            cr.rectangle(x, y, ww.max(1.0), hh.max(1.0));
            let _ = cr.fill_preserve();
            set(cr, c, 0.45);
            cr.set_line_width(0.6);
            let _ = cr.stroke();
        }
    }
    // special wiring, bond pads, bumps
    {
        // draw order: rails, stripes, rings, straps / wires, seal ring / RDL, then via arrays on top
        let order = ["pgrails", "pgstripes", "pgrings", "specialnets", "special", "pgvias"];
        let specials = st.get("special").arr();
        let (vx0, vy1) = ui.s2w(0.0, 0.0);
        let (vx1, vy0) = ui.s2w(ui.size.0, ui.size.1);
        for cls in order {
        if !ui.on(cls) { continue; }
        for s in specials.iter() {
            let ly = s.at(0).s();
            let kind = s.at(1).s();
            if special_class(kind) != cls { continue; }
            if !ly.is_empty() && !ui.rvis.get(ly).copied().unwrap_or(true) && cls != "pgvias" { continue; }
            let net = s.at(5).s();
            let lit = ui.hl_net.as_deref().map(|h| h == net).unwrap_or(true);
            let c = if kind == "seal_ring" { hex("#b0b0b0") } else if cls == "special" { metal(ly.trim_start_matches('M').parse::<usize>().unwrap_or(7).saturating_sub(1), ly) } else { lef_style(st, ly).0 };
            if let Some(r) = s.at(4).rect() {
                if r.2 < vx0 || r.0 > vx1 || r.3 < vy0 || r.1 > vy1 { continue; }
                if cls == "pgvias" {
                    let v = s.at(6);
                    let (x, y, ww, hh) = rect_s(ui, r);
                    set(cr, hex("#ffffff"), if lit { 0.9 } else { 0.25 });
                    cr.set_line_width(0.8);
                    cr.rectangle(x + 0.5, y + 0.5, ww, hh);
                    let _ = cr.stroke();
                    let (cols, rows, cw, ch, sx, sy) = (v.at(0).i().max(1) as usize, v.at(1).i().max(1) as usize, v.at(2).f(), v.at(3).f(), v.at(4).f(), v.at(5).f());
                    if !v.is_null() && cw * ui.view.s >= 2.0 && cols * rows <= 400 {
                        // individual cuts
                        let (tw, th) = (cols as f64 * cw + (cols - 1) as f64 * sx, rows as f64 * ch + (rows - 1) as f64 * sy);
                        let (ox, oy) = ((r.0 + r.2) / 2.0 - tw / 2.0, (r.1 + r.3) / 2.0 - th / 2.0);
                        set(cr, hex(if is_ground(net) { "#7fa8ff" } else { "#ff8a8a" }), if lit { 0.95 } else { 0.25 });
                        for i in 0..cols { for j in 0..rows {
                            let cx = ox + i as f64 * (cw + sx);
                            let cy = oy + j as f64 * (ch + sy);
                            let (a, b, w2, h2) = rect_s(ui, (cx, cy, cx + cw, cy + ch));
                            cr.rectangle(a, b, w2, h2);
                        } }
                        let _ = cr.fill();
                    } else if ww > 3.0 {
                        cr.move_to(x, y); cr.line_to(x + ww, y + hh); cr.move_to(x + ww, y); cr.line_to(x, y + hh);
                        let _ = cr.stroke();
                    }
                    continue;
                }
                let kd = match cls { "pgrings" => 1, "pgstripes" => 2, "pgrails" => 0, "specialnets" => 3, _ => 1 };
                if lit {
                    shape(cr, ui, r, c, kd, 0.8, 1.0, false);
                } else {
                    let (x, y, ww, hh) = rect_s(ui, r);
                    set(cr, c, 0.22);
                    cr.rectangle(x, y, ww, hh);
                    let _ = cr.fill();
                }
                if cls != "special" && lit {
                    // net-coloured edge: power red, ground blue
                    let (x, y, ww, hh) = rect_s(ui, r);
                    set(cr, hex(if is_ground(net) { "#5a8cff" } else { "#ff4d4d" }), 1.0);
                    cr.set_line_width(if ui.hl_net.is_some() { 2.0 } else { 0.8 });
                    cr.rectangle(x + 0.5, y + 0.5, ww, hh);
                    let _ = cr.stroke();
                    if (ww > 60.0 && hh > 9.0) || (hh > 60.0 && ww > 9.0) {
                        if ww >= hh { label(cr, ui, net, x + 4.0, y + hh / 2.0 + 3.0, hex("#ffffff"), 8.0); }
                        else { label(cr, ui, net, x + 1.0, y + 12.0, hex("#ffffff"), 8.0); }
                    }
                }
            } else {
                let pts: Vec<f64> = s.at(3).arr().iter().map(|v| v.f()).collect();
                if pts.len() >= 4 {
                    set(cr, c, 0.85);
                    cr.set_line_width((s.at(2).f() * ui.view.s).max(1.0));
                    let (x, y) = ui.w2s(pts[0], pts[1]);
                    cr.move_to(x, y);
                    for k in (2..pts.len() - 1).step_by(2) { let (x, y) = ui.w2s(pts[k], pts[k + 1]); cr.line_to(x, y); }
                    let _ = cr.stroke();
                }
            }
        }
        }
    }
    if ui.on("bonds") {
        for b in st.get("bonds").arr() { if let Some(r) = b.rect() { shape(cr, ui, r, hex("#ffd700"), 2, 0.7, 1.2, false); } }
    }
    if ui.on("bumps") {
        for b in st.get("bumps").arr() {
            let a = b.arr();
            if a.len() < 6 { continue; }
            let (x, y) = ui.w2s(a[1].f(), a[2].f());
            let rr = a[3].f() / 2.0 * ui.view.s;
            let c = match a[4].s() { "power" => hex("#ff4d4d"), "ground" => hex("#5a8cff"), "signal" => hex("#3cd23c"), _ => hex("#909090") };
            set(cr, c, 1.0);
            cr.set_line_width(1.4);
            // octagonal bump outline
            for k in 0..=8 {
                let t = (k as f64 + 0.5) * std::f64::consts::PI / 4.0;
                let (px, py) = (x + rr * t.cos(), y + rr * t.sin());
                if k == 0 { cr.move_to(px, py); } else { cr.line_to(px, py); }
            }
            let _ = cr.stroke_preserve();
            set(cr, c, 0.18);
            let _ = cr.fill();
            if rr > 18.0 && !a[5].s().is_empty() { label(cr, ui, a[5].s(), x - rr * 0.8, y + 4.0, c, 9.0); }
        }
    }
    // flylines
    let fly = st.get("fly");
    if ui.on("fly") && !fly.is_null() {
        let by_macro = fly.get("color").s() == "macro";
        cr.set_line_width(1.0);
        for l in fly.get("l").arr() {
            let a = l.arr();
            if a.len() < 6 { continue; }
            let c = if by_macro { hex(PAL[a[5].i() as usize % 10]) } else { hsl(a[4].f() * 137.5, 0.8, 0.6) };
            set(cr, c, 0.8);
            let (x1, y1) = ui.w2s(a[0].f(), a[1].f());
            let (x2, y2) = ui.w2s(a[2].f(), a[3].f());
            cr.move_to(x1, y1);
            cr.line_to(x2, y2);
            let _ = cr.stroke();
            cr.rectangle(x2 - 1.5, y2 - 1.5, 3.0, 3.0);
            let _ = cr.fill();
        }
    }
    // pin markers of the selected instances; selected pins
    if !ui.pin_marks.is_empty() {
        let (x0, y0, x1, y1) = (0.0, 0.0, ui.size.0, ui.size.1);
        let z = (ui.view.s * 0.08).clamp(2.0, 5.0);
        for (px, py, pn, conn) in &ui.pin_marks {
            let (x, y) = ui.w2s(*px, *py);
            if x < x0 || y < y0 || x > x1 || y > y1 { continue; }
            let full = ui.sel_pins.contains(pn);
            let pn = pn.rsplit('/').next().unwrap_or(pn);
            set(cr, if full { hex("#ffd000") } else if *conn { hex("#4fc3ff") } else { hex("#808080") }, 1.0);
            cr.rectangle(x - z, y - z, 2.0 * z, 2.0 * z);
            if full { let _ = cr.fill(); } else { cr.set_line_width(1.0); let _ = cr.stroke(); }
            if ui.view.s > 6.0 { label(cr, ui, pn, x + z + 2.0, y - z, hex("#9fd8ff"), 9.0); }
        }
    }
    // IO pins
    if ui.on("pins") {
        for p in st.get("ports").arr() {
            let a = p.arr();
            if a.len() < 6 { continue; }
            let (x, y) = ui.w2s(a[1].f(), a[2].f());
            let z = 5.0;
            let src = a[5].s();
            set(cr, hex(if src.starts_with("bundle") { "#9467bd" } else { "#ff5a5a" }), 1.0);
            match a[3].s() {
                "left" => { cr.move_to(x, y - z); cr.line_to(x + z, y); cr.line_to(x, y + z); }
                "right" => { cr.move_to(x, y - z); cr.line_to(x - z, y); cr.line_to(x, y + z); }
                "top" => { cr.move_to(x - z, y); cr.line_to(x, y + z); cr.line_to(x + z, y); }
                _ => { cr.move_to(x - z, y); cr.line_to(x, y - z); cr.line_to(x + z, y); }
            }
            cr.close_path();
            let _ = cr.fill();
            if ui.sel_ports.contains(a[0].s()) {
                set(cr, hex("#ffffff"), 1.0);
                cr.set_line_width(2.0);
                cr.arc(x, y, z + 4.0, 0.0, std::f64::consts::TAU);
                let _ = cr.stroke();
                label(cr, ui, a[0].s(), x + 8.0, y - 6.0, hex("#ffffff"), 10.0);
            }
            if ui.view.s > 3.0 { label(cr, ui, a[0].s(), x + 6.0, y - 4.0, hex("#ff8080"), 9.0); }
        }
    }
    // DRC / LVS / via markers
    if ui.on("markers") {
        for (i, m) in st.get("markers").arr().iter().enumerate() {
            let tool = m.at(0).s();
            let r = (m.at(3).f(), m.at(4).f(), m.at(5).f(), m.at(6).f());
            let (x, y, ww, hh) = rect_s(ui, r);
            let (cx, cy) = (x + ww / 2.0, y + hh / 2.0);
            let (ww, hh) = (ww.max(7.0), hh.max(7.0));
            let (x, y) = (cx - ww / 2.0, cy - hh / 2.0);
            if x > ui.size.0 || y > ui.size.1 || x + ww < 0.0 || y + hh < 0.0 { continue; }
            let col = match (tool, m.at(1).s()) {
                ("lvs", k) if k.contains("open") || k.contains("float") || k.contains("unconn") => hex("#40ff80"),
                ("lvs", _) => hex("#ff40ff"),
                ("via", _) => hex("#ffd000"),
                ("import", _) | ("calibre", _) => hex("#ff9f1a"),
                _ => hex("#ff3030"),
            };
            let cur = ui.mk_i == Some(i);
            set(cr, col, 1.0);
            cr.set_line_width(if cur { 2.6 } else { 1.4 });
            cr.rectangle(x, y, ww, hh);
            cr.move_to(x, y); cr.line_to(x + ww, y + hh); cr.move_to(x + ww, y); cr.line_to(x, y + hh);
            let _ = cr.stroke();
            if cur {
                cr.arc(cx, cy, ww.max(hh) / 2.0 + 8.0, 0.0, 6.3);
                let _ = cr.stroke();
                label(cr, ui, m.at(7).s(), x + ww + 6.0, y - 2.0, col, 10.0);
            }
        }
    }
    // wire being drawn
    if ui.tool == T_WIRE && !ui.wpts.is_empty() {
        set(cr, hex("#ffffff"), 1.0);
        cr.set_line_width(2.0);
        let (x, y) = ui.w2s(ui.wpts[0].0, ui.wpts[0].1);
        cr.move_to(x, y);
        for p in &ui.wpts[1..] { let (x, y) = ui.w2s(p.0, p.1); cr.line_to(x, y); }
        let _ = cr.stroke();
        let nxt = ui.wire_pt(ui.mouse.0, ui.mouse.1);
        let l = ui.wpts.last().unwrap();
        let (a, b) = ui.w2s(l.0, l.1);
        let (c, d) = ui.w2s(nxt.0, nxt.1);
        cr.set_dash(&[4.0, 3.0], 0.0);
        cr.move_to(a, b); cr.line_to(c, d);
        let _ = cr.stroke();
        cr.set_dash(&[], 0.0);
        for p in &ui.wpts { let (x, y) = ui.w2s(p.0, p.1); cr.rectangle(x - 2.5, y - 2.5, 5.0, 5.0); }
        let _ = cr.fill();
    }
    // rulers (persistent, from the session) and the one being measured
    for r in st.get("rulers").arr() { draw_ruler(cr, ui, (r.at(0).f(), r.at(1).f()), (r.at(2).f(), r.at(3).f()), false); }
    if ui.tool == T_RULER {
        let live = match (&ui.drag, ui.rstart) {
            (Some((x0, y0, x1, y1, 1, _)), None) if (x1 - x0).abs() + (y1 - y0).abs() > 3.0 => { let a = ui.ruler_pt(*x0, *y0, None); Some((a, ui.ruler_pt(*x1, *y1, Some(a)))) }
            (_, Some(a)) => Some((a, ui.ruler_pt(ui.mouse.0, ui.mouse.1, Some(a)))),
            _ => None,
        };
        if let Some((a, b)) = live { draw_ruler(cr, ui, a, b, true); }
        // snap cursor
        let p = ui.ruler_pt(ui.mouse.0, ui.mouse.1, None);
        let (cx, cy) = ui.w2s(p.0, p.1);
        set(cr, hex("#ffd700"), 0.9);
        cr.set_line_width(1.0);
        cr.move_to(cx - 6.0, cy); cr.line_to(cx + 6.0, cy); cr.move_to(cx, cy - 6.0); cr.line_to(cx, cy + 6.0);
        let _ = cr.stroke();
    }
    // rubber band
    if let Some((x0, y0, x1, y1, b, _)) = &ui.drag {
        let boxsel = ui.tool == 0 && *b == 1 && !ui.drag_pan;
        if (ui.tool > 0 && ui.tool != T_WIRE && ui.tool != T_VIA && ui.tool != T_RULER && *b == 1) || *b == 3 || boxsel {
            set(cr, if *b == 3 { hex("#ffd700") } else if boxsel { hex("#4fc3ff") } else { hex("#ffffff") }, 1.0);
            cr.set_dash(&[4.0, 3.0], 0.0);
            cr.set_line_width(1.0);
            cr.rectangle(x0.min(*x1), y0.min(*y1), (x1 - x0).abs(), (y1 - y0).abs());
            let _ = cr.stroke();
            cr.set_dash(&[], 0.0);
        }
    }
    // scale bar (KLayout ruler style)
    let um = 10f64.powf((80.0 / ui.view.s).log10().floor());
    let px = um * ui.view.s;
    set(cr, hex("#c0c0c0"), 1.0);
    cr.set_line_width(1.0);
    cr.move_to(12.0, h - 14.0); cr.line_to(12.0 + px, h - 14.0);
    cr.move_to(12.0, h - 18.0); cr.line_to(12.0, h - 10.0);
    cr.move_to(12.0 + px, h - 18.0); cr.line_to(12.0 + px, h - 10.0);
    let _ = cr.stroke();
    cr.set_font_size(10.0);
    cr.move_to(16.0 + px, h - 10.0);
    let _ = cr.show_text(&format!("{} um", um));
}

/// ruler: measured line, end ticks, dx / dy legs for diagonals, label with distance and angle
fn draw_ruler(cr: &cairo::Context, ui: &Ui, a: (f64, f64), b: (f64, f64), live: bool) {
    let (x0, y0) = ui.w2s(a.0, a.1);
    let (x1, y1) = ui.w2s(b.0, b.1);
    let (dx, dy) = (b.0 - a.0, b.1 - a.1);
    let d = (dx * dx + dy * dy).sqrt();
    let col = if live { hex("#ffffff") } else { hex("#ffd700") };
    // legs of the right triangle (diagonal measurements)
    if dx.abs() > 1e-9 && dy.abs() > 1e-9 {
        set(cr, col, 0.45);
        cr.set_line_width(1.0);
        cr.set_dash(&[3.0, 3.0], 0.0);
        cr.move_to(x0, y0); cr.line_to(x1, y0); cr.line_to(x1, y1);
        let _ = cr.stroke();
        cr.set_dash(&[], 0.0);
        cr.set_font_size(9.0);
        set(cr, col, 0.8);
        cr.move_to((x0 + x1) / 2.0 - 20.0, y0 + if y1 < y0 { 12.0 } else { -4.0 });
        let _ = cr.show_text(&format!("dx {:.3}", dx));
        cr.move_to(x1 + 4.0, (y0 + y1) / 2.0);
        let _ = cr.show_text(&format!("dy {:.3}", dy));
    }
    set(cr, col, 1.0);
    cr.set_line_width(if live { 1.5 } else { 1.8 });
    cr.move_to(x0, y0); cr.line_to(x1, y1);
    let _ = cr.stroke();
    // end ticks perpendicular to the ruler
    let (l, ux, uy) = { let l = ((x1 - x0).powi(2) + (y1 - y0).powi(2)).sqrt().max(1e-9); (l, (x1 - x0) / l, (y1 - y0) / l) };
    let _ = l;
    for (px, py) in [(x0, y0), (x1, y1)] { cr.move_to(px - uy * 6.0, py + ux * 6.0); cr.line_to(px + uy * 6.0, py - ux * 6.0); }
    // small ticks along the ruler every scale-bar unit
    let um = 10f64.powf((60.0 / ui.view.s).log10().floor());
    let n = (d / um).floor() as usize;
    if n > 0 && n < 200 {
        for k in 1..=n {
            let t = k as f64 * um / d;
            let (px, py) = (x0 + (x1 - x0) * t, y0 + (y1 - y0) * t);
            let s = if k % 5 == 0 { 4.0 } else { 2.0 };
            cr.move_to(px - uy * s, py + ux * s); cr.line_to(px + uy * s, py - ux * s);
        }
    }
    let _ = cr.stroke();
    let txt = format!("{:.3} um  ∠{:.1}°", d, dy.atan2(dx).to_degrees());
    cr.set_font_size(11.0);
    let (mx, my) = ((x0 + x1) / 2.0, (y0 + y1) / 2.0);
    if let Ok(e) = cr.text_extents(&txt) {
        set(cr, hex("#000000"), 0.7);
        cr.rectangle(mx + 6.0, my - 18.0, e.width() + 8.0, 16.0);
        let _ = cr.fill();
        set(cr, col, 1.0);
        cr.move_to(mx + 10.0, my - 6.0);
        let _ = cr.show_text(&txt);
    }
}

// ----------------------------------------------------------------------------------- picking
enum Hit { Port(usize), Cell(usize), Pblk(usize), Rblk(usize), Guide(usize), Pd(usize), Bound(usize), Seg(usize), Special(usize), Marker(usize), Point(f64, f64) }

fn pick(ui: &Ui, px: f64, py: f64) -> Hit {
    let (x, y) = ui.s2w(px, py);
    let st = &ui.st;
    let r = 6.0 / ui.view.s;
    // the nearest port within 6 px
    let mut bp: Option<(usize, f64)> = None;
    for (i, p) in st.get("ports").arr().iter().enumerate() {
        let (dx, dy) = ((p.at(1).f() - x).abs(), (p.at(2).f() - y).abs());
        if dx < r && dy < r && bp.map(|b| dx.max(dy) < b.1).unwrap_or(true) { bp = Some((i, dx.max(dy))); }
    }
    if let Some((i, _)) = bp { return Hit::Port(i); }
    // markers: inside a small one, or on the edge of a large one
    if ui.on("markers") {
        let die = st.get("die").rect().unwrap_or((0.0, 0.0, 1.0, 1.0));
        let big = (die.2 - die.0) * (die.3 - die.1) * 0.01;
        for (i, m) in st.get("markers").arr().iter().enumerate() {
            let (x0, y0, x1, y1) = (m.at(3).f(), m.at(4).f(), m.at(5).f(), m.at(6).f());
            let pad = 4.0 / ui.view.s;
            let inside = x >= x0 - pad && x <= x1 + pad && y >= y0 - pad && y <= y1 + pad;
            let edge = inside && (x - x0 < pad * 2.0 || x1 - x < pad * 2.0 || y - y0 < pad * 2.0 || y1 - y < pad * 2.0);
            if inside && ((x1 - x0) * (y1 - y0) < big || edge) { return Hit::Marker(i); }
        }
    }
    // routed wires (within 3 px); an instance under the cursor wins over the wires above it
    let rt = st.get("routes");
    let over_cell = st.get("cells").arr().iter().any(|c| {
        let a = c.arr();
        if a.len() < 10 { return false; }
        let kind = match a[4].s() { "b" => "macros", "p" => "pads", "f" => "phys", _ => "cells" };
        kind != "phys" && ui.on(kind) && (a[1].f() - x).abs() <= a[8].f() / 2.0 && (a[2].f() - y).abs() <= a[9].f() / 2.0
    });
    if !rt.is_null() && !over_cell {
        let ls: Vec<&str> = rt.get("layers").arr().iter().map(|x| x.s()).collect();
        let tol = 3.0 / ui.view.s + rt.get("w").f() * 0.3;
        let mut bestd = f64::MAX;
        let mut bi = None;
        for (i, sg) in rt.get("segs").arr().iter().enumerate() {
            let a = sg.arr();
            if a.len() < 5 { continue; }
            if !ui.rvis.get(*ls.get(a[0].i() as usize).unwrap_or(&"")).copied().unwrap_or(true) { continue; }
            let (x1, y1, x2, y2) = (a[1].f().min(a[3].f()), a[2].f().min(a[4].f()), a[1].f().max(a[3].f()), a[2].f().max(a[4].f()));
            if x < x1 - tol || x > x2 + tol || y < y1 - tol || y > y2 + tol { continue; }
            let d = if x2 - x1 >= y2 - y1 { (y - y1).abs() } else { (x - x1).abs() };
            if d < bestd { bestd = d; bi = Some(i); }
        }
        if let Some(i) = bi { return Hit::Seg(i); }
    }
    // special shapes drawn on top of cells (not the followpins, which sit on every row)
    let spec_hit = |rails: bool| -> Option<usize> {
        let mut best: Option<(usize, f64)> = None;
        for (i, s) in st.get("special").arr().iter().enumerate() {
            let cls = special_class(s.at(1).s());
            if (cls == "pgrails") != rails || !ui.on(cls) { continue; }
            let Some(q) = s.at(4).rect() else { continue };
            let pad = 2.0 / ui.view.s;
            if x >= q.0 - pad && x <= q.2 + pad && y >= q.1 - pad && y <= q.3 + pad {
                let ar = (q.2 - q.0) * (q.3 - q.1) * if cls == "pgvias" { 0.01 } else { 1.0 };
                if best.map(|b| ar < b.1).unwrap_or(true) { best = Some((i, ar)); }
            }
        }
        best.map(|b| b.0)
    };
    if let Some(i) = spec_hit(false) { return Hit::Special(i); }
    let mut best: Option<(usize, f64)> = None;
    for (i, c) in st.get("cells").arr().iter().enumerate() {
        let a = c.arr();
        if a.len() < 8 { continue; }
        let (cw, ch) = if a.len() >= 10 { (a[8].f(), a[9].f()) } else { (a[3].f(), a[3].f()) };
        let kind = match a[4].s() { "b" => "macros", "p" => "pads", "f" => "phys", _ => "cells" };
        if !ui.on(kind) { continue; }
        let (hw, hh) = ((cw / 2.0).max(r * 0.5), (ch / 2.0).max(r * 0.5));
        if (a[1].f() - x).abs() <= hw && (a[2].f() - y).abs() <= hh {
            let ar = cw * ch;
            if best.map(|b| ar < b.1).unwrap_or(true) { best = Some((i, ar)); }
        }
    }
    if let Some((i, _)) = best { return Hit::Cell(i); }
    if let Some(i) = spec_hit(true) { return Hit::Special(i); }
    let inr = |q: &J| q.rect().map(|q| x >= q.0 && x <= q.2 && y >= q.1 && y <= q.3).unwrap_or(false);
    for (i, b) in st.get("pblk").arr().iter().enumerate() { if inr(b.get("r")) && !b.get("n").s().contains("__guard_") { return Hit::Pblk(i); } }
    for (i, b) in st.get("rblk").arr().iter().enumerate() { if inr(b.get("r")) { return Hit::Rblk(i); } }
    for (i, b) in st.get("guides").arr().iter().enumerate() { if inr(b.get("r")) { return Hit::Guide(i); } }
    for (i, d) in st.get("pds").arr().iter().enumerate() { if inr(d.get("va")) { return Hit::Pd(i); } }
    for (i, b) in st.get("bounds").arr().iter().enumerate() { if inr(b.get("r")) { return Hit::Bound(i); } }
    Hit::Point(x, y)
}

fn describe(ui: &Ui, h: &Hit) -> String {
    let st = &ui.st;
    let esc = |s: &str| glib::markup_escape_text(s).to_string();
    match h {
        Hit::Port(i) => { let p = st.get("ports").at(*i); format!("<b>{}</b> port ({})\nside {} · layer {}\nat ({:.3}, {:.3})\nsource {}", esc(p.at(0).s()), p.at(6).s(), p.at(3).s(), p.at(4).s(), p.at(1).f(), p.at(2).f(), p.at(5).s()) }
        Hit::Cell(i) => {
            let c = st.get("cells").at(*i);
            let g = st.get("groups").at(c.at(5).i().max(0) as usize).s();
            let d = st.get("pds").at(c.at(7).i().max(0) as usize);
            let (w, hh) = (c.at(8).f(), c.at(9).f());
            format!("<b>{}</b>\ncentre ({:.3}, {:.3}) · {:.3} × {:.3} um\ntype {} · group {}{}{}", esc(c.at(0).s()), c.at(1).f(), c.at(2).f(), w, hh,
                match c.at(4).s() { "b" => "macro", "p" => "IO pad", "f" => "physical-only cell", "s" => "sequential", "i" => "ICG", "u" => "iso / LS", "o" => "buffer", _ => "standard cell" }, esc(g),
                if c.at(6).i() != 0 { " · fixed" } else { "" }, if c.at(7).i() >= 0 { format!("\npower domain {}", esc(d.get("n").s())) } else { String::new() })
        }
        Hit::Pblk(i) => { let b = st.get("pblk").at(*i); format!("<b>{}</b> placement blockage\ntype {}", esc(b.get("n").s()), b.get("k").s()) }
        Hit::Rblk(i) => { let b = st.get("rblk").at(*i); format!("<b>{}</b> routing blockage\nlayers {}", esc(b.get("n").s()), b.get("l").s()) }
        Hit::Guide(i) => { let b = st.get("guides").at(*i); format!("<b>{}</b> route guide\nnets {}", esc(b.get("n").s()), esc(b.get("nets").s())) }
        Hit::Bound(i) => { let b = st.get("bounds").at(*i); format!("<b>{}</b> bound ({})\nmembers {}", esc(b.get("n").s()), b.get("k").s(), esc(b.get("m").s())) }
        Hit::Pd(i) => {
            let d = st.get("pds").at(*i);
            format!("<b>{}</b> power domain {}\nvoltage area {}\ncells {} ({} placed, {} outside VA)\niso / LS / ret {} / {} / {}", esc(d.get("n").s()),
                if d.get("sw").b() { "(switchable)" } else { "(always-on)" }, esc(d.get("van").s()), d.get("c").i(), d.get("pl").i(), d.get("out").i(), d.get("iso").i(), d.get("ls").i(), d.get("ret").i())
        }
        Hit::Seg(i) => {
            let rt = st.get("routes");
            let a = rt.get("segs").at(*i);
            let net = rt.get("nets").at(a.at(5).i().max(0) as usize).s();
            let ly = rt.get("layers").at(a.at(0).i().max(0) as usize).s();
            let len: f64 = rt.get("segs").arr().iter().filter(|s| s.at(5).i() == a.at(5).i()).map(|s| (s.at(3).f() - s.at(1).f()).abs() + (s.at(4).f() - s.at(2).f()).abs()).sum();
            format!("<b>{}</b> net (routed wire)\nsegment {} ({:.3}, {:.3}) – ({:.3}, {:.3})\nnet wirelength {:.2} um\nnet highlighted · Route menu: NDR / re-route", esc(net), ly, a.at(1).f(), a.at(2).f(), a.at(3).f(), a.at(4).f(), len)
        }
        Hit::Special(i) => {
            let s = st.get("special").at(*i);
            let r = s.at(4).rect().unwrap_or((0.0, 0.0, 0.0, 0.0));
            let v = s.at(6);
            format!("<b>{}</b> {} on {}\nrect ({:.3}, {:.3}) – ({:.3}, {:.3}){}{}", esc(s.at(5).s()), s.at(1).s().replace('_', " "), s.at(0).s(), r.0, r.1, r.2, r.3,
                if s.at(2).f() > 0.0 { format!("\nwidth {:.3} um", s.at(2).f()) } else { String::new() },
                if v.is_null() { String::new() } else { format!("\nvia {}..{} · {} × {} cuts", v.at(6).s(), v.at(7).s(), v.at(0).i(), v.at(1).i()) })
        }
        Hit::Marker(i) => {
            let m = st.get("markers").at(*i);
            format!("<b>{} marker</b> {} {}\n{}\nat ({:.3}, {:.3}) – ({:.3}, {:.3}){}", m.at(0).s().to_uppercase(), esc(m.at(1).s()), esc(m.at(2).s()), esc(m.at(7).s()), m.at(3).f(), m.at(4).f(), m.at(5).f(), m.at(6).f(),
                { let n: Vec<&str> = m.at(8).arr().iter().map(|x| x.s()).collect(); if n.is_empty() { String::new() } else { format!("\nnets {}", esc(&n.join(" "))) } })
        }
        Hit::Point(x, y) => format!("({:.3}, {:.3}) um", x, y),
    }
}
/// net of a hit (wire, special shape, single-net marker)
fn hit_net(ui: &Ui, h: &Hit) -> Option<String> {
    let st = &ui.st;
    match h {
        Hit::Seg(i) => { let rt = st.get("routes"); Some(rt.get("nets").at(rt.get("segs").at(*i).at(5).i().max(0) as usize).s().to_string()) }
        Hit::Special(i) => Some(st.get("special").at(*i).at(5).s().to_string()).filter(|s| !s.is_empty()),
        Hit::Marker(i) => st.get("markers").at(*i).at(8).arr().first().map(|x| x.s().to_string()),
        _ => None,
    }
}

/// coordinate for commands: up to 4 decimals, trailing zeros removed
fn f3s(v: f64) -> String {
    let s = format!("{:.4}", v);
    let s = s.trim_end_matches('0').trim_end_matches('.').to_string();
    if s == "-0" { "0".into() } else { s }
}
fn f2(v: f64) -> String {
    let s = format!("{:.2}", v);
    s.trim_end_matches('0').trim_end_matches('.').to_string()
}
/// the command the drawing tools emit
fn mkcmd(ui: &Ui, r: (f64, f64, f64, f64)) -> String {
    let b = format!("-boundary {{{{{} {}}} {{{} {}}}}}", f2(r.0), f2(r.1), f2(r.2), f2(r.3));
    let o = |k: &str| ui.opt.get(k).cloned().unwrap_or_default();
    match ui.tool {
        1 => { let k = o("pk"); format!("create_placement_blockage {} -type {}{}", b, k, if k == "partial" { format!(" -blocked_percentage {}", o("pp")) } else { String::new() }) }
        2 => { let l = o("rl"); format!("create_routing_blockage {}{}", b, if l.trim().is_empty() { String::new() } else { format!(" -layers {{{}}}", l.trim()) }) }
        3 => { let (n, u) = (o("gn"), o("gu")); format!("create_route_guide {}{}{}", b, if n.trim().is_empty() { String::new() } else { format!(" -nets {{{}}}", n.trim()) }, if u.trim().is_empty() { String::new() } else { format!(" -track_utilization {}", u.trim()) }) }
        4 => format!("create_bound {} -type {} {{{}}}", b, o("bk"), if o("bm").trim().is_empty() { "u_core".to_string() } else { o("bm").trim().to_string() }),
        T_DEL => {
            let (n, l) = (o("wn"), o("wl"));
            let area = format!("-area {{{} {} {} {}}}", f2(r.0), f2(r.1), f2(r.2), f2(r.3));
            if o("dk").starts_with("special") { format!("delete_special_wire{}{} {}", if n.trim().is_empty() { String::new() } else { format!(" -net {}", n.trim()) }, if l == "(all)" { String::new() } else { format!(" -layer {}", l) }, area) }
            else { format!("delete_wire -net {}{} {}", if n.trim().is_empty() { "?".to_string() } else { n.trim().to_string() }, if l == "(all)" { String::new() } else { format!(" -layer {}", l) }, area) }
        }
        T_PGW => format!("add_special_wire -net {} -layer {} -rect {{{} {} {} {}}}", if o("wn").trim().is_empty() { "VDD".to_string() } else { o("wn").trim().to_string() }, o("wl"), f2(r.0), f2(r.1), f2(r.2), f2(r.3)),
        5 => { let g = o("vg"); format!("create_voltage_area -power_domains {} -region {{{{{} {}}} {{{} {}}}}}{}", o("vpd"), f2(r.0), f2(r.1), f2(r.2), f2(r.3), if g.trim().is_empty() || g.trim() == "0" { String::new() } else { format!(" -guard_band {{{}}}", g.trim()) }) }
        _ => String::new(),
    }
}

// ----------------------------------------------------------------------------------- schematic
#[derive(Clone, Debug)]
struct SNode { name: String, f: String, ins: Vec<String>, outs: Vec<String>, seq: bool, port: bool, dir: String, lv: i64, y: f64, h: f64, x: f64, w: f64, sc: usize, b: f64 }
struct SchG { n: Vec<SNode>, nc: usize, nets: Vec<(String, Option<(i64, usize)>, Vec<(i64, usize)>, i64)>, col_x: HashMap<i64, f64>, col_w: HashMap<i64, f64>, chan: HashMap<i64, usize>, width: f64, max_y: f64, back_n: usize }

fn sch_layout(d: &J) -> Option<SchG> {
    let cells = d.get("cells").arr();
    if cells.is_empty() { return None; }
    let mut n: Vec<SNode> = cells.iter().map(|c| SNode { name: c.at(0).s().into(), f: c.at(1).s().into(),
        ins: c.at(3).arr().iter().map(|x| x.s().to_string()).collect(), outs: c.at(4).arr().iter().map(|x| x.s().to_string()).collect(),
        seq: c.at(5).i() != 0, port: false, dir: String::new(), lv: 0, y: 0.0, h: 0.0, x: 0.0, w: 0.0, sc: 0, b: 0.0 }).collect();
    let nc = n.len();
    let ep = |e: &J| -> Option<(i64, usize)> { if e.is_null() { None } else { Some((e.at(0).i(), e.at(1).i().max(0) as usize)) } };
    let nets: Vec<(String, Option<(i64, usize)>, Vec<(i64, usize)>, i64)> = d.get("nets").arr().iter().map(|x| (x.at(0).s().to_string(), ep(x.at(1)), x.at(2).arr().iter().filter_map(|e| ep(e)).collect(), x.at(3).i())).collect();
    let mut succ: Vec<Vec<usize>> = vec![vec![]; nc];
    let mut seen = std::collections::HashSet::new();
    for (_, dr, ld, _) in &nets {
        let Some(dr) = dr else { continue };
        if dr.0 < 0 { continue; }
        for l in ld { if l.0 >= 0 && l.0 != dr.0 && seen.insert((dr.0, l.0)) { succ[dr.0 as usize].push(l.0 as usize); } }
    }
    // DFS from input-fed cells; back edges (register loops) are cut; longest path levels
    let mut starts: Vec<usize> = vec![];
    for (_, dr, ld, _) in &nets { if let Some(dr) = dr { if dr.0 < 0 { for l in ld { if l.0 >= 0 { starts.push(l.0 as usize); } } } } }
    starts.extend(0..nc);
    let mut stt = vec![0u8; nc];
    let mut back = std::collections::HashSet::new();
    let mut order = vec![];
    for s0 in starts {
        if stt[s0] != 0 { continue; }
        let mut stack = vec![(s0, 0usize)];
        stt[s0] = 1;
        while let Some(top) = stack.last_mut() {
            let u = top.0;
            if top.1 < succ[u].len() {
                let v = succ[u][top.1];
                top.1 += 1;
                if stt[v] == 1 { back.insert((u, v)); } else if stt[v] == 0 { stt[v] = 1; stack.push((v, 0)); }
            } else { stt[u] = 2; order.push(u); stack.pop(); }
        }
    }
    order.reverse();
    for &u in &order { for &v in &succ[u].clone() { if !back.contains(&(u, v)) { n[v].lv = n[v].lv.max(n[u].lv + 1); } } }
    let lmax = n.iter().map(|x| x.lv).max().unwrap_or(0);
    for p in d.get("ports").arr() {
        let dir = p.at(1).s().to_string();
        n.push(SNode { name: p.at(0).s().into(), f: String::new(), ins: vec![], outs: vec![], seq: false, port: true, lv: if dir == "in" { -1 } else { lmax + 1 }, dir, y: 0.0, h: 20.0, x: 0.0, w: 0.0, sc: 0, b: 0.0 });
    }
    let idx = |e: (i64, usize)| -> usize { if e.0 >= 0 { e.0 as usize } else { nc + (-1 - e.0) as usize } };
    let mut nb: Vec<Vec<usize>> = vec![vec![]; n.len()];
    for (_, dr, ld, _) in &nets {
        let es: Vec<usize> = dr.iter().copied().chain(ld.iter().copied()).map(idx).collect();
        for &a in &es { for &b in &es { if a != b { nb[a].push(b); } } }
    }
    let mut lvls: Vec<i64> = n.iter().map(|x| x.lv).collect();
    lvls.sort();
    lvls.dedup();
    let mut cols: HashMap<i64, Vec<usize>> = HashMap::new();
    for (i, x) in n.iter().enumerate() { cols.entry(x.lv).or_default().push(i); }
    let gate_h = |x: &SNode| if x.port { 20.0 } else { (16.0 * x.ins.len().max(x.outs.len()).max(1) as f64 + 10.0).max(34.0) + if x.f == "MACRO" || x.f == "PAD" { 30.0 } else { 0.0 } };
    for x in n.iter_mut() { x.h = gate_h(x); }
    let place = |n: &mut Vec<SNode>, cols: &HashMap<i64, Vec<usize>>| { for l in cols.values() { let mut y = 0.0; for &i in l { n[i].y = y; y += n[i].h + 22.0; } } };
    place(&mut n, &cols);
    for it in 0..6 {
        let seq: Vec<i64> = if it % 2 == 1 { lvls.iter().rev().copied().collect() } else { lvls.clone() };
        for l in seq {
            let col = cols.get_mut(&l).unwrap();
            for &i in col.iter() { let ns = &nb[i]; n[i].b = if ns.is_empty() { n[i].y } else { ns.iter().map(|&q| n[q].y + n[q].h / 2.0).sum::<f64>() / ns.len() as f64 }; }
            col.sort_by(|a, b| n[*a].b.partial_cmp(&n[*b].b).unwrap());
            let mut y = 0.0;
            for &i in col.iter() { n[i].y = y; y += n[i].h + 22.0; }
        }
    }
    let gw = |x: &SNode| if x.port { 70.0 } else if x.f == "MACRO" || x.f == "PAD" { 120.0 } else if x.seq { 64.0 } else { 56.0 };
    let area: f64 = n.iter().map(|x| (x.h + 22.0) * (gw(x) + 60.0)).sum();
    let ht = 560f64.max(area.sqrt() * 0.9);
    let mut sub: HashMap<i64, usize> = HashMap::new();
    for &l in &lvls {
        let col = &cols[&l];
        let h = col.last().map(|&i| n[i].y + n[i].h).unwrap_or(0.0);
        let k = ((h / ht).ceil() as usize).max(1);
        sub.insert(l, k);
        if k > 1 {
            let per = (col.len() + k - 1) / k;
            let mut y = 0.0;
            let mut cur = 0;
            for (j, &i) in col.iter().enumerate() { let sc = j / per; if sc != cur { cur = sc; y = 0.0; } n[i].sc = sc; n[i].y = y; y += n[i].h + 22.0; }
        }
    }
    let mut col_w = HashMap::new();
    let mut chan: HashMap<i64, usize> = HashMap::new();
    for &l in &lvls { let w = cols[&l].iter().map(|&i| gw(&n[i])).fold(0.0, f64::max); let k = sub[&l] as f64; col_w.insert(l, k * w + (k - 1.0) * 28.0); chan.insert(l, 0); }
    for (_, dr, _, _) in &nets { if let Some(dr) = dr { *chan.get_mut(&n[idx(*dr)].lv).unwrap() += 1; } }
    let mut col_x = HashMap::new();
    let mut x = 0.0;
    for &l in &lvls { col_x.insert(l, x); x += col_w[&l] + (40.0 + 5.0 * chan[&l] as f64).min(260.0); }
    for i in 0..n.len() {
        let l = n[i].lv;
        let k = sub[&l] as f64;
        let w = (col_w[&l] - (k - 1.0) * 28.0) / k;
        let g = gw(&n[i]);
        n[i].x = col_x[&l] + n[i].sc as f64 * (w + 28.0) + (w - g) / 2.0;
        n[i].w = g;
    }
    let max_y = n.iter().map(|q| q.y + q.h).fold(0.0, f64::max);
    Some(SchG { n, nc, nets, col_x, col_w, chan, width: x, max_y, back_n: 0 })
}

fn inv_out(f: &str) -> bool {
    ["INV", "NAND", "NOR", "XNOR", "AOI", "OAI", "CLKINV"].iter().any(|p| f.starts_with(p))
}
fn pin_xy(g: &SchG, e: (i64, usize), out: bool) -> (f64, f64) {
    if e.0 < 0 {
        let p = &g.n[g.nc + (-1 - e.0) as usize];
        return (if p.dir == "in" { p.x + p.w } else { p.x }, p.y + p.h / 2.0);
    }
    let c = &g.n[e.0 as usize];
    let list = if out { &c.outs } else { &c.ins };
    let k = list.len().max(1) as f64;
    (if out { c.x + c.w + if inv_out(&c.f) { 7.0 } else { 0.0 } } else { c.x }, c.y + c.h * (e.1 as f64 + 1.0) / (k + 1.0))
}

fn draw_sch(cr: &cairo::Context, ui: &Ui, w: f64, h: f64, bg: bool) {
    if bg { cr.set_source_rgb(0.04, 0.04, 0.05); cr.rectangle(0.0, 0.0, w, h); let _ = cr.fill(); }
    cr.select_font_face("Sans", cairo::FontSlant::Normal, cairo::FontWeight::Normal);
    let Some(g) = ui.sch.as_ref() else {
        let d = ui.st.get("sch");
        let msg = if d.get("hint").s().is_empty() { "No netlist loaded".to_string() } else { d.get("hint").s().to_string() };
        set(cr, hex("#a0a0a0"), 1.0);
        cr.set_font_size(13.0);
        cr.move_to(20.0, 30.0);
        let _ = cr.show_text(&msg);
        return;
    };
    let _ = cr.save();
    cr.translate(ui.sview.ox, ui.sview.oy);
    cr.scale(ui.sview.s, ui.sview.s);
    let ink = hex("#d8d8d8");
    let mute = hex("#909090");
    // highlighted nets of the selected cell
    let seli = ui.sch_sel.as_ref().and_then(|s| g.n[..g.nc].iter().position(|c| &c.name == s));
    let mut track: HashMap<i64, usize> = HashMap::new();
    let mut back_k = 0usize;
    for (ni, (nm, dr, ld, off)) in g.nets.iter().enumerate() {
        let hl = if let Some(h) = &ui.sch_hl_net { h == nm } else { seli.map(|i| dr.map(|d| d.0 == i as i64).unwrap_or(false) || ld.iter().any(|l| l.0 == i as i64)).unwrap_or(false) };
        let col = if hl { hex("#ffd000") } else { hsl(ni as f64 * 137.5, 0.55, 0.62) };
        set(cr, col, 1.0);
        cr.set_line_width(if hl { 2.4 } else { 1.0 } / ui.sview.s.max(0.3) * ui.sview.s.min(1.0).max(0.6));
        let Some(dr) = dr else {
            for l in ld {
                let (lx, ly) = pin_xy(g, *l, false);
                cr.move_to(lx - 18.0, ly); cr.line_to(lx, ly);
                let _ = cr.stroke();
                cr.set_font_size(8.0);
                set(cr, mute, 1.0);
                if let Ok(e) = cr.text_extents(nm) { cr.move_to(lx - 20.0 - e.width(), ly - 2.0); let _ = cr.show_text(nm); }
                set(cr, col, 1.0);
            }
            continue;
        };
        let so_i = if dr.0 >= 0 { dr.0 as usize } else { g.nc + (-1 - dr.0) as usize };
        let so = &g.n[so_i];
        let (dx, dy) = pin_xy(g, *dr, true);
        let k = *track.get(&so.lv).unwrap_or(&0);
        track.insert(so.lv, k + 1);
        let cw = (40.0 + 5.0 * g.chan[&so.lv] as f64).min(260.0);
        let ntr = (((cw - 24.0) / 5.0).floor() as usize).max(1);
        let xt = g.col_x[&so.lv] + g.col_w[&so.lv] + 14.0 + (k % ntr) as f64 * 5.0;
        for l in ld {
            let lo_i = if l.0 >= 0 { l.0 as usize } else { g.nc + (-1 - l.0) as usize };
            let lo = &g.n[lo_i];
            let (lx, ly) = pin_xy(g, *l, false);
            cr.move_to(dx, dy);
            if lo.lv > so.lv {
                cr.line_to(xt, dy); cr.line_to(xt, ly); cr.line_to(lx, ly);
                if ld.len() > 1 { let _ = cr.stroke(); cr.arc(xt, ly, 1.8, 0.0, 6.3); let _ = cr.fill(); continue; }
            } else {
                let yb = g.max_y + 26.0 + (back_k % 40) as f64 * 5.0;
                back_k += 1;
                let xl = lx - 8.0 - (back_k % 4) as f64 * 3.0;
                cr.line_to(xt, dy); cr.line_to(xt, yb); cr.line_to(xl, yb); cr.line_to(xl, ly); cr.line_to(lx, ly);
            }
            let _ = cr.stroke();
        }
        if *off > 0 { cr.set_font_size(8.0); cr.move_to(dx + 4.0, dy - 3.0); let _ = cr.show_text(&format!("+{}", off)); }
    }
    // gates
    for (i, c) in g.n.iter().enumerate() {
        let (x, y, w, h) = (c.x, c.y, c.w, c.h);
        let sel = Some(i) == seli || ui.sch_msel.contains(&c.name);
        let stroke = if sel { hex("#ffd000") } else { ink };
        cr.set_line_width(if sel { 2.4 } else { 1.3 });
        if c.port {
            // signal flows left to right: input ports point into the design (tip right, at the wire),
            // output ports point out of it (flat side at the wire, tip right), inout ports are hexagons
            if c.dir == "in" { cr.move_to(x, y); cr.line_to(x + w - 8.0, y); cr.line_to(x + w, y + h / 2.0); cr.line_to(x + w - 8.0, y + h); cr.line_to(x, y + h); }
            else if c.dir == "inout" { cr.move_to(x + 8.0, y); cr.line_to(x + w - 8.0, y); cr.line_to(x + w, y + h / 2.0); cr.line_to(x + w - 8.0, y + h); cr.line_to(x + 8.0, y + h); cr.line_to(x, y + h / 2.0); }
            else { cr.move_to(x, y); cr.line_to(x + w - 8.0, y); cr.line_to(x + w, y + h / 2.0); cr.line_to(x + w - 8.0, y + h); cr.line_to(x, y + h); }
            cr.close_path();
            let pc = match c.dir.as_str() { "in" => "#5ad25a", "inout" => "#ffb000", _ => "#ff6b6b" };
            set(cr, hex(pc), 0.25);
            let _ = cr.fill_preserve();
            set(cr, if sel { hex("#ffd000") } else { hex(pc) }, 1.0);
            let _ = cr.stroke();
            set(cr, ink, 1.0);
            cr.set_font_size(9.0);
            if let Ok(e) = cr.text_extents(&c.name) { cr.move_to(x + w / 2.0 - e.width() / 2.0, y + h / 2.0 + 3.0); let _ = cr.show_text(&c.name); }
            continue;
        }
        let f = c.f.as_str();
        let boxy;
        if ["INV", "BUF", "CLKBUF", "CLKINV", "DLY"].iter().any(|p| f.starts_with(p)) {
            cr.move_to(x, y + 4.0); cr.line_to(x + w - 2.0, y + h / 2.0); cr.line_to(x, y + h - 4.0); cr.close_path(); boxy = false;
        } else if f.starts_with("AND") || f.starts_with("NAND") {
            cr.move_to(x, y); cr.line_to(x + w - h / 2.0, y); cr.arc(x + w - h / 2.0, y + h / 2.0, h / 2.0, -std::f64::consts::FRAC_PI_2, std::f64::consts::FRAC_PI_2); cr.line_to(x, y + h); cr.close_path(); boxy = false;
        } else if f.starts_with("OR") || f.starts_with("NOR") || f.starts_with("XOR") || f.starts_with("XNOR") {
            cr.move_to(x, y); cr.curve_to(x + w * 0.4, y, x + w * 0.8, y + h * 0.15, x + w, y + h / 2.0); cr.curve_to(x + w * 0.8, y + h * 0.85, x + w * 0.4, y + h, x, y + h); cr.curve_to(x + w * 0.2, y + h * 0.66, x + w * 0.2, y + h * 0.33, x, y); boxy = false;
        } else if f.starts_with("MUX") {
            cr.move_to(x, y); cr.line_to(x + w, y + h * 0.2); cr.line_to(x + w, y + h * 0.8); cr.line_to(x, y + h); cr.close_path(); boxy = false;
        } else {
            cr.rectangle(x, y, w, h); boxy = true;
        }
        set(cr, if f == "MACRO" || f == "PAD" { hex("#3a3a3a") } else { hex("#1c1f24") }, 1.0);
        let _ = cr.fill_preserve();
        set(cr, stroke, 1.0);
        let _ = cr.stroke();
        if f.starts_with("XOR") || f.starts_with("XNOR") { cr.move_to(x - 5.0, y); cr.curve_to(x + w * 0.2 - 5.0, y + h * 0.33, x + w * 0.2 - 5.0, y + h * 0.66, x - 5.0, y + h); let _ = cr.stroke(); }
        if inv_out(f) { cr.arc(x + w + 3.5, y + h / 2.0, 3.5, 0.0, 6.3); let _ = cr.stroke(); }
        cr.set_font_size(8.0);
        if !boxy && ui.sch_pins {
            // pin names outside non-rectangular symbols
            set(cr, mute, 1.0);
            cr.set_font_size(7.0);
            for (k, p) in c.ins.iter().enumerate() { let (px, py) = pin_xy(g, (i as i64, k), false); if let Ok(e) = cr.text_extents(p) { cr.move_to(px - 2.0 - e.width(), py - 2.0); let _ = cr.show_text(p); } }
            for (k, p) in c.outs.iter().enumerate() { let (px, py) = pin_xy(g, (i as i64, k), true); cr.move_to(px + 2.0, py - 2.0); let _ = cr.show_text(p); }
            cr.set_font_size(8.0);
        }
        if boxy {
            set(cr, mute, if ui.sch_pins { 1.0 } else { 0.0 });
            for (k, p) in c.ins.iter().enumerate() { cr.move_to(x + 3.0, y + h * (k as f64 + 1.0) / (c.ins.len() as f64 + 1.0) + 3.0); let _ = cr.show_text(p); }
            for (k, p) in c.outs.iter().enumerate() { if let Ok(e) = cr.text_extents(p) { cr.move_to(x + w - 3.0 - e.width(), y + h * (k as f64 + 1.0) / (c.outs.len() as f64 + 1.0) + 3.0); let _ = cr.show_text(p); } }
            if c.seq {
                if let Some(k) = c.ins.iter().position(|p| ["CK", "CLK", "C", "G", "GN", "CP", "EN"].contains(&p.as_str())) {
                    let py = y + h * (k as f64 + 1.0) / (c.ins.len() as f64 + 1.0);
                    set(cr, stroke, 1.0);
                    cr.move_to(x, py - 5.0); cr.line_to(x + 7.0, py); cr.line_to(x, py + 5.0);
                    let _ = cr.stroke();
                }
            }
        }
        set(cr, ink, 1.0);
        cr.set_font_size(9.0);
        if let Ok(e) = cr.text_extents(f) { cr.move_to(x + w / 2.0 - e.width() / 2.0, if boxy { y + 11.0 } else { y + h / 2.0 + 3.0 }); let _ = cr.show_text(f); }
        let short = c.name.rsplit('/').next().unwrap_or(&c.name);
        set(cr, mute, 1.0);
        if let Ok(e) = cr.text_extents(short) { cr.move_to(x + w / 2.0 - e.width() / 2.0, y + h + 10.0); let _ = cr.show_text(short); }
    }
    let _ = cr.restore();
    if let Some((x0, y0, x1, y1)) = ui.sband {
        set(cr, hex("#ffd700"), 1.0);
        cr.set_dash(&[4.0, 3.0], 0.0);
        cr.set_line_width(1.0);
        cr.rectangle(x0.min(x1), y0.min(y1), (x1 - x0).abs(), (y1 - y0).abs());
        let _ = cr.stroke();
        cr.set_dash(&[], 0.0);
    }
}

fn sch_fit(ui: &mut Ui) {
    let Some(g) = ui.sch.as_ref() else { return };
    let (w, h) = (g.width.max(200.0) + 40.0, g.max_y + 26.0 + (g.back_n.min(40) as f64) * 5.0 + 260.0);
    let s = ((ui.ssize.0 - 20.0) / w).min((ui.ssize.1 - 20.0) / h).clamp(0.02, 4.0);
    ui.sview = View { s, ox: 10.0 + 20.0 * s, oy: 10.0 + 20.0 * s };
}
fn sch_zoom(ui: &mut Ui, f: f64, px: f64, py: f64) {
    let (wx, wy) = ((px - ui.sview.ox) / ui.sview.s, (py - ui.sview.oy) / ui.sview.s);
    ui.sview.s = (ui.sview.s * f).clamp(0.005, 40.0);
    ui.sview.ox = px - wx * ui.sview.s;
    ui.sview.oy = py - wy * ui.sview.s;
}
fn sch_zoom_rect(ui: &mut Ui, r: (f64, f64, f64, f64)) {
    let (w, h) = ((r.2 - r.0).max(1.0), (r.3 - r.1).max(1.0));
    let s = ((ui.ssize.0 - 20.0) / w).min((ui.ssize.1 - 20.0) / h).clamp(0.005, 40.0);
    ui.sview = View { s, ox: ui.ssize.0 / 2.0 - (r.0 + w / 2.0) * s, oy: ui.ssize.1 / 2.0 - (r.1 + h / 2.0) * s };
}
/// pin under the mouse: (instance or port, pin name ("" for a port), net)
fn sch_pick_pin(ui: &Ui, px: f64, py: f64) -> Option<(String, String, Option<String>)> {
    let g = ui.sch.as_ref()?;
    let (x, y) = ((px - ui.sview.ox) / ui.sview.s, (py - ui.sview.oy) / ui.sview.s);
    let tol = (5.0 / ui.sview.s).clamp(2.5, 9.0);
    let net_of = |e: (i64, usize), out: bool| -> Option<String> {
        g.nets.iter().find(|n| if out { n.1 == Some(e) } else { n.2.contains(&e) }).map(|n| n.0.clone())
    };
    let near = |p: (f64, f64)| (p.0 - x).abs() <= tol * 1.6 && (p.1 - y).abs() <= tol;
    for (i, c) in g.n[..g.nc].iter().enumerate() {
        if x < c.x - 20.0 || x > c.x + c.w + 20.0 || y < c.y - 8.0 || y > c.y + c.h + 8.0 { continue; }
        for (k, p) in c.ins.iter().enumerate() { if near(pin_xy(g, (i as i64, k), false)) { return Some((c.name.clone(), p.clone(), net_of((i as i64, k), false))); } }
        for (k, p) in c.outs.iter().enumerate() { if near(pin_xy(g, (i as i64, k), true)) { return Some((c.name.clone(), p.clone(), net_of((i as i64, k), true))); } }
    }
    for (j, p) in g.n[g.nc..].iter().enumerate() {
        if x >= p.x - 2.0 && x <= p.x + p.w + 2.0 && y >= p.y - 2.0 && y <= p.y + p.h + 2.0 {
            let e = (-1 - j as i64, 0usize);
            return Some((p.name.clone(), String::new(), net_of(e, p.dir == "in").or_else(|| net_of(e, p.dir != "in"))));
        }
    }
    None
}
fn sch_pick(ui: &Ui, px: f64, py: f64) -> Option<String> {
    let g = ui.sch.as_ref()?;
    let (x, y) = ((px - ui.sview.ox) / ui.sview.s, (py - ui.sview.oy) / ui.sview.s);
    g.n[..g.nc].iter().find(|c| x >= c.x - 2.0 && x <= c.x + c.w + 8.0 && y >= c.y - 2.0 && y <= c.y + c.h + 2.0).map(|c| c.name.clone())
}

// ----------------------------------------------------------------------------------- application
#[allow(deprecated)]
struct W {
    win: gtk::ApplicationWindow,
    nb: gtk::Notebook,
    lay: gtk::DrawingArea,
    sch: gtk::DrawingArea,
    tv: gtk::TextView,
    entry: gtk::Entry,
    status: gtk::Label,
    info: gtk::Label,
    layers: gtk::Box,
    lef: gtk::Box,
    pdbox: gtk::Box,
    flylabel: gtk::Label,
    legend: gtk::Box,
    toolopts: gtk::Box,
    tools: Vec<gtk::ToggleButton>,
    schcells: gtk::Entry,
    schdepth: gtk::SpinButton,
    schstat: gtk::Label,
    title: gtk::Label,
    mklabel: gtk::Label,
    qbook: gtk::Notebook,
    ctstore: gtk::TreeStore,
    ctview: gtk::TreeView,
    ctclock: gtk::DropDown,
    ctsinks: gtk::CheckButton,
    ctsum: gtk::Label,
    qtitle: gtk::Label,
    qprev: gtk::Button,
    qnext: gtk::Button,
    qpage: gtk::Label,
    schtrace: gtk::SpinButton,
    schend: gtk::CheckButton,
}

struct G {
    sess: RefCell<Session>,
    ui: RefCell<Ui>,
    w: OnceCell<W>,
    app: gtk::Application,
}

type Gr = Rc<G>;

fn w(g: &Gr) -> &W {
    g.w.get().expect("widgets")
}

fn log_out(g: &Gr, t: &str) {
    let tv = &w(g).tv;
    let b = tv.buffer();
    let mut end = b.end_iter();
    b.insert(&mut end, t);
    if !t.ends_with('\n') { let mut end = b.end_iter(); b.insert(&mut end, "\n"); }
    // keep the transcript bounded
    if b.line_count() > 6000 { let mut s = b.start_iter(); let mut e = b.iter_at_line(b.line_count() - 5000).unwrap_or(b.end_iter()); b.delete(&mut s, &mut e); }
    b.place_cursor(&b.end_iter());
    let m = b.get_insert();
    tv.scroll_mark_onscreen(&m);
}

fn refresh(g: &Gr) {
    let js = crate::gui::state_json_ext(&g.sess.borrow(), true);
    let st = J::parse(&js).unwrap_or(J::Null);
    {
        let mut ui = g.ui.borrow_mut();
        let had_die = ui.st.get("die").rect();
        let new_die = st.get("die").rect();
        if had_die != new_die { ui.need_fit = true; }
        let sch_changed = ui.st.get("sch") != st.get("sch");
        let qchanged = ui.st.get("query") != st.get("query");
        for l in st.get("routes").get("layers").arr() { ui.rvis.entry(l.s().to_string()).or_insert(true); }
        ui.st = st;
        let (zk, zr) = { let z = ui.st.get("zoom"); (if z.is_null() { None } else { Some(z.get("k").i()) }, z.get("r").rect()) };
        if let Some(k) = zk { if k != ui.zoom_k { ui.zoom_k = k; ui.pending_zoom = zr; } }
        if sch_changed || ui.sch.is_none() {
            ui.sch = sch_layout(ui.st.get("sch"));
            ui.sch_fit = true;
        }
        if qchanged { ui.queried = None; }
    }
    rebuild_panels(g);
    // a query from the command line (gui_query_object) or a refreshed object
    let q = { let ui = g.ui.borrow(); let q = ui.st.get("query"); if q.is_null() { None } else { Some((q.at(0).s().to_string(), q.at(1).s().to_string())) } };
    let shown = g.ui.borrow().queried.clone();
    match (q, shown) {
        // new command-line query
        (Some((k, n)), None) => { show_query(g, &k, &n); }
        // keep the shown netlist object up to date (placement / routing changed)
        (_, Some((k, n))) if ["instance", "net", "port", "pin"].contains(&k.as_str()) => { show_query(g, &k, &n); update_qnav(g); }
        _ => {}
    }
    w(g).lay.queue_draw();
    w(g).sch.queue_draw();
}

fn run_cmd(g: &Gr, cmd: &str) {
    let c = cmd.trim().to_string();
    if c.is_empty() { return; }
    log_out(g, &format!("rsynth> {}", c));
    {
        let mut ui = g.ui.borrow_mut();
        ui.script.push(c.clone());
        if ui.hist.last() != Some(&c) { ui.hist.push(c.clone()); }
        ui.hpos = ui.hist.len();
    }
    if ["gui_stop", "exit_gui", "gui_hide", "gui_close", "exit", "quit"].contains(&c.as_str()) {
        if c == "exit" || c == "quit" { g.sess.borrow_mut().exit = true; }
        w(g).win.close();
        return;
    }
    crate::log::push_redirect();
    let r = g.sess.borrow_mut().eval(&c);
    let mut out = crate::log::pop_redirect();
    match r {
        Ok(v) => { if !v.is_empty() { out.push_str(&v); out.push('\n'); } }
        Err(crate::tcl::Flow::Err(e)) => out.push_str(&format!("Error: {}\n", e)),
        Err(_) => {}
    }
    crate::log::out(&format!("[gtk] {}", c));
    if !out.is_empty() { log_out(g, out.trim_end()); }
    if g.sess.borrow().exit { w(g).win.close(); return; }
    refresh(g);
    if c.starts_with("gui_show_schematic") || c.starts_with("gui_schematic") || c.starts_with("show_schematic") { w(g).nb.set_current_page(Some(1)); }
}

fn swatch(c: Rgb, kind: u8) -> gtk::DrawingArea {
    let d = gtk::DrawingArea::new();
    d.set_content_width(22);
    d.set_content_height(12);
    d.set_draw_func(move |_, cr, w, h| {
        cr.set_source_rgb(0.0, 0.0, 0.0);
        cr.paint().ok();
        if let Some(p) = stipple(c, kind, 0.9) { let _ = cr.set_source(&p); cr.rectangle(0.0, 0.0, w as f64, h as f64); let _ = cr.fill(); }
        cr.set_source_rgb(c.0, c.1, c.2);
        cr.set_line_width(1.0);
        cr.rectangle(0.5, 0.5, w as f64 - 1.0, h as f64 - 1.0);
        let _ = cr.stroke();
    });
    d
}

fn clear_box(b: &gtk::Box) {
    while let Some(c) = b.first_child() { b.remove(&c); }
}

fn layer_color(k: &str) -> (Rgb, u8) {
    match k {
        "die" => (hex("#ffffff"), 9), "rows" => (hex("#595959"), 9), "tracks" => (hex("#707070"), 4), "phys" => (hex("#6e6e6e"), 7), "cells" => (hex(PAL[0]), 0), "macros" => (hex("#c8c8c8"), 1), "pads" => (hex("#a0a0ff"), 1),
        "pins" => (hex("#ff5a5a"), 9), "mpins" => (hex("#5a8cff"), 1), "pblk" => (hex("#d62728"), 0), "rblk" => (hex("#1f77b4"), 1), "guides" => (hex("#17becf"), 2),
        "bounds" => (hex("#54a24b"), 2), "vas" => (hex("#7570b3"), 2), "cong" => (hex("#e3a33a"), 2), "fly" => (hex("#ff9f1a"), 9), "special" => (hex("#b0b0b0"), 1),
        "bumps" => (hex("#3cd23c"), 2), "bonds" => (hex("#ffd700"), 2), "vias" => (hex("#ffffff"), 1),
        "pgrings" => (hex("#ff6060"), 1), "pgstripes" => (hex("#e07a2a"), 2), "pgrails" => (hex("#d0b030"), 1), "pgvias" => (hex("#ffffff"), 4), "specialnets" => (hex("#40c0c0"), 2), "markers" => (hex("#ff3030"), 9),
        _ => (hex("#a0a0a0"), 9),
    }
}

fn rebuild_panels(g: &Gr) {
    let wd = w(g);
    let ui = g.ui.borrow();
    let st = &ui.st;
    // ---- layers (right, KLayout layer list)
    clear_box(&wd.layers);
    let mk = |name: &str, c: Rgb, k: u8, on: bool| -> (gtk::Box, gtk::CheckButton) {
        let row = gtk::Box::new(gtk::Orientation::Horizontal, 6);
        let cb = gtk::CheckButton::new();
        cb.set_active(on);
        row.append(&cb);
        row.append(&swatch(c, k));
        let l = gtk::Label::new(Some(name));
        l.set_xalign(0.0);
        row.append(&l);
        (row, cb)
    };
    for (k, name, on) in ui.vis.clone() {
        let (c, kind) = layer_color(k);
        let (row, cb) = mk(name, c, kind, on);
        let g2 = g.clone();
        cb.connect_toggled(move |cb| { if let Some(v) = g2.ui.borrow_mut().vis.iter_mut().find(|v| v.0 == k) { v.2 = cb.is_active(); } w(&g2).lay.queue_draw(); });
        wd.layers.append(&row);
    }
    // ---- LEF layers tab
    clear_box(&wd.lef);
    let mut names: Vec<(String, String, String)> = st.get("lef_layers").arr().iter().map(|l| (l.get("n").s().to_string(), l.get("k").s().to_uppercase(), l.get("d").s().to_lowercase())).collect();
    for l in st.get("routes").get("layers").arr() { if !names.iter().any(|n| n.0 == l.s()) { names.push((l.s().to_string(), "ROUTING".into(), String::new())); } }
    if names.is_empty() {
        let l = gtk::Label::new(Some("No LEF layers (read_lef with a technology LEF)"));
        l.add_css_class("dim");
        l.set_xalign(0.0);
        wd.lef.append(&l);
    } else {
        let brow = gtk::Box::new(gtk::Orientation::Horizontal, 4);
        let ball = gtk::Button::with_label("All");
        let bnone = gtk::Button::with_label("None");
        brow.append(&ball);
        brow.append(&bnone);
        wd.lef.append(&brow);
        let mut cbs: Vec<gtk::CheckButton> = vec![];
        for (n, k, d) in &names {
            let (c, kd) = lef_style(st, n);
            let txt = format!("{}  <span size=\"small\" foreground=\"#8a8a8a\">{}{}</span>", glib::markup_escape_text(n), k.to_lowercase(), if d.is_empty() { String::new() } else { format!(" · {}", if d.starts_with('h') { "H" } else { "V" }) });
            let row = gtk::Box::new(gtk::Orientation::Horizontal, 6);
            let cb = gtk::CheckButton::new();
            cb.set_active(ui.rvis.get(n).copied().unwrap_or(true));
            row.append(&cb);
            row.append(&swatch(c, kd));
            let l = gtk::Label::new(None);
            l.set_markup(&txt);
            l.set_xalign(0.0);
            row.append(&l);
            let g2 = g.clone();
            let n2 = n.clone();
            cb.connect_toggled(move |cb| { g2.ui.borrow_mut().rvis.insert(n2.clone(), cb.is_active()); w(&g2).lay.queue_draw(); });
            wd.lef.append(&row);
            cbs.push(cb);
        }
        let c2 = cbs.clone();
        ball.connect_clicked(move |_| for c in &c2 { c.set_active(true); });
        bnone.connect_clicked(move |_| for c in &cbs { c.set_active(false); });
    }
    // ---- power domains
    clear_box(&wd.pdbox);
    let pds = st.get("pds").arr();
    let hl = ui.pdhl();
    if pds.is_empty() {
        let l = gtk::Label::new(Some("No UPF loaded (load_upf)"));
        l.add_css_class("dim");
        l.set_xalign(0.0);
        wd.pdbox.append(&l);
    } else {
        let cby = gtk::DropDown::from_strings(&["Colour by hierarchy", "Colour by power domain"]);
        cby.set_selected(if st.get("colorby").s() == "pd" { 1 } else { 0 });
        let g2 = g.clone();
        cby.connect_selected_notify(move |d| { let c = if d.selected() == 1 { "power_domain" } else { "hierarchy" }; let g3 = g2.clone(); glib::idle_add_local_once(move || run_cmd(&g3, &format!("gui_highlight_power_domain -color_by {}", c))); });
        wd.pdbox.append(&cby);
        for (i, d) in pds.iter().enumerate() {
            let n = d.get("n").s().to_string();
            let on = hl.contains(&n);
            let b = gtk::ToggleButton::new();
            let row = gtk::Box::new(gtk::Orientation::Horizontal, 6);
            row.append(&swatch(hex(PDPAL[i % 10]), 2));
            let v = d.get("v");
            let l = gtk::Label::new(Some(&format!("{}  {}{} · {} cells{}", n, if v.is_null() { String::new() } else { format!("{:.2}V ", v.f()) }, if d.get("sw").b() { "switchable" } else { "always-on" }, d.get("c").i(), if d.get("out").i() > 0 { format!(" · {} outside VA", d.get("out").i()) } else { String::new() })));
            l.set_xalign(0.0);
            row.append(&l);
            b.set_child(Some(&row));
            b.set_active(on);
            let g2 = g.clone();
            let n2 = n.clone();
            b.connect_clicked(move |_| {
                let g3 = g2.clone();
                let n3 = n2.clone();
                let cmd = if on { "gui_highlight_power_domain -clear".to_string() } else { format!("gui_highlight_power_domain {}", n3) };
                glib::idle_add_local_once(move || run_cmd(&g3, &cmd));
            });
            wd.pdbox.append(&b);
        }
    }
    // ---- flylines
    let fly = st.get("fly");
    wd.flylabel.set_text(&if fly.is_null() { "Click a macro or standard cell (shift-click: add) to show the flylines of all its pins".to_string() } else {
        format!("{} cell(s) · {} pin(s) · {} flyline(s) · {} net(s)", fly.get("macros").arr().len(), fly.get("pins").i(), fly.get("l").arr().len(), fly.get("nets").arr().len())
    });
    // ---- legend (hierarchy groups)
    clear_box(&wd.legend);
    let pdmode = st.get("colorby").s() == "pd";
    let items: Vec<(String, Rgb)> = if pdmode { pds.iter().enumerate().map(|(i, d)| (d.get("n").s().to_string(), hex(PDPAL[i % 10]))).collect() }
        else { st.get("groups").arr().iter().enumerate().map(|(i, x)| (x.s().to_string(), hex(PAL[i % 10]))).collect() };
    for (n, c) in items.iter().take(40) {
        let row = gtk::Box::new(gtk::Orientation::Horizontal, 6);
        row.append(&swatch(*c, 0));
        let l = gtk::Label::new(Some(n));
        l.set_xalign(0.0);
        row.append(&l);
        wd.legend.append(&row);
    }
    // ---- markers
    {
        let ms = st.get("markers").arr();
        let mut by: std::collections::BTreeMap<String, usize> = Default::default();
        for m in ms { *by.entry(format!("{} {}", m.at(0).s(), m.at(1).s())).or_default() += 1; }
        let ndr = st.get("ndrs").arr().len();
        wd.mklabel.set_text(&if ms.is_empty() { format!("No markers{}", if ndr > 0 { format!(" · {} NDR rule(s)", ndr) } else { String::new() }) } else {
            format!("{} marker(s){}\n{}", ms.len(), if ndr > 0 { format!(" · {} NDR rule(s)", ndr) } else { String::new() }, by.iter().map(|(k, v)| format!("  {}: {}", k, v)).collect::<Vec<_>>().join("\n"))
        });
    }
    // ---- header / status
    let nc = st.get("cells").arr().len();
    let cong = st.get("cong");
    wd.title.set_text(&format!("{} · {} cells · {} pins{}", st.get("design").s(), nc, st.get("ports").arr().len(),
        if cong.is_null() { String::new() } else { format!(" · GR wirelength {:.0} um, overflow {:.1}", cong.get("wl").f(), cong.get("ov").f()) }));
    let sd = st.get("sch");
    wd.schstat.set_text(&match &ui.sch {
        Some(sg) => format!("{} cell(s), {} port(s), {} net(s){}{}", sg.nc, sg.n.len() - sg.nc, sg.nets.len(), if sd.get("trunc").b() { " · truncated" } else { "" },
            if sd.get("seed").arr().is_empty() { " · whole design".to_string() } else { format!(" · around {} (depth {})", sd.get("seed").arr().iter().map(|x| x.s()).collect::<Vec<_>>().join(" "), sd.get("depth").i()) }),
        None => format!("{} cells in design", sd.get("total").i()),
    });
}

fn rebuild_toolopts(g: &Gr) {
    let wd = w(g);
    clear_box(&wd.toolopts);
    let tool = g.ui.borrow().tool;
    let entry = |k: &'static str, ph: &str| {
        let e = gtk::Entry::new();
        e.set_placeholder_text(Some(ph));
        e.set_text(&g.ui.borrow().opt.get(k).cloned().unwrap_or_default());
        let g2 = g.clone();
        e.connect_changed(move |e| { g2.ui.borrow_mut().opt.insert(k, e.text().to_string()); });
        wd.toolopts.append(&e);
    };
    let dd = |k: &'static str, items: &[&str]| {
        let d = gtk::DropDown::from_strings(items);
        let cur = g.ui.borrow().opt.get(k).cloned().unwrap_or_default();
        d.set_selected(items.iter().position(|x| *x == cur).unwrap_or(0) as u32);
        let v: Vec<String> = items.iter().map(|s| s.to_string()).collect();
        let g2 = g.clone();
        d.connect_selected_notify(move |d| { g2.ui.borrow_mut().opt.insert(k, v[d.selected() as usize].clone()); });
        g.ui.borrow_mut().opt.insert(k, items[d.selected() as usize].to_string());
        wd.toolopts.append(&d);
    };
    match tool {
        1 => { dd("pk", &["hard", "soft", "partial"]); entry("pp", "blocked % (partial)"); }
        2 => entry("rl", "layers (empty = all)"),
        3 => { entry("gn", "nets (attract)"); entry("gu", "track utilization %"); }
        4 => { dd("bk", &["soft", "hard", "exclusive"]); entry("bm", "cells / hierarchy, e.g. u_core"); }
        T_RULER => {
            let l = gtk::Label::new(Some("Snap"));
            l.set_xalign(0.0);
            wd.toolopts.append(&l);
            dd("rs", &["manufacturing grid (0.005)", "routing grid", "0.01 um", "0.1 um", "1 um", "custom", "off"]);
            entry("rgv", "custom grid (um)");
            let l = gtk::Label::new(Some("Angle"));
            l.set_xalign(0.0);
            wd.toolopts.append(&l);
            dd("ra", &["any angle", "orthogonal", "45 degree"]);
            let bc = gtk::Button::with_label("Clear rulers (Shift+K)");
            let g2 = g.clone();
            bc.connect_clicked(move |_| run_cmd(&g2, "gui_clear_rulers"));
            wd.toolopts.append(&bc);
            let br = gtk::Button::with_label("Report rulers");
            let g2 = g.clone();
            br.connect_clicked(move |_| run_cmd(&g2, "report_rulers"));
            wd.toolopts.append(&br);
            let l = gtk::Label::new(Some("Drag, or click start and end point. Distance, dx, dy, angle and Manhattan length are reported; diagonals show their legs. Esc cancels."));
            l.add_css_class("dim");
            l.set_wrap(true);
            l.set_xalign(0.0);
            wd.toolopts.append(&l);
            return;
        }
        T_WIRE | T_VIA | T_DEL | T_PGW => {
            let st = g.ui.borrow().st.clone();
            let mut ml: Vec<String> = st.get("mlayers").arr().iter().map(|x| x.s().to_string()).collect();
            if ml.is_empty() { ml = st.get("routes").get("layers").arr().iter().map(|x| x.s().to_string()).collect(); }
            if ml.is_empty() { ml = (1..=6).map(|i| format!("M{}", i)).collect(); }
            let hl = g.ui.borrow().hl_net.clone();
            if let Some(h) = hl { if g.ui.borrow().opt.get("wn").map(|s| s.is_empty()).unwrap_or(true) { g.ui.borrow_mut().opt.insert("wn", h); } }
            entry("wn", if tool == T_PGW { "net (VDD / VSS / ...)" } else { "net (click a wire to pick it)" });
            if tool == T_DEL { dd("dk", &["signal wires", "special (PG) shapes"]); }
            let mut lay: Vec<&str> = vec![];
            if tool == T_DEL { lay.push("(all)"); }
            lay.extend(ml.iter().map(|s| s.as_str()));
            dd("wl", &lay);
            if tool == T_VIA { let l2: Vec<&str> = ml.iter().map(|s| s.as_str()).collect(); dd("wl2", &l2); }
            if tool == T_WIRE {
                let nd: Vec<String> = std::iter::once("(default)".to_string()).chain(st.get("ndrs").arr().iter().map(|x| x.s().to_string())).collect();
                let r: Vec<&str> = nd.iter().map(|s| s.as_str()).collect();
                dd("wr", &r);
                let bf = gtk::Button::with_label("Finish wire (Enter / right-click)");
                let g2 = g.clone();
                bf.connect_clicked(move |_| finish_wire(&g2));
                wd.toolopts.append(&bf);
            }
            let hint = match tool {
                T_WIRE => "Click points (orthogonal, snapped to the routing grid); Enter or right-click finishes, Backspace undoes a point, Esc cancels. With an NDR selected the net gets that rule first.",
                T_VIA => "Click on a wire or pin of the net: adds a via stack between the two layers.",
                T_DEL => "Drag a rectangle: deletes the net's wires (or PG shapes) inside it.",
                _ => "Drag a rectangle: adds a PG / special wire of the net on the layer.",
            };
            let l = gtk::Label::new(Some(hint));
            l.add_css_class("dim");
            l.set_wrap(true);
            l.set_xalign(0.0);
            wd.toolopts.append(&l);
            return;
        }
        5 => {
            let pds: Vec<String> = g.ui.borrow().st.get("pds").arr().iter().filter(|d| !d.get("top").b()).map(|d| d.get("n").s().to_string()).collect();
            if pds.is_empty() { let l = gtk::Label::new(Some("No switchable / child power domains: load_upf first")); l.add_css_class("dim"); l.set_wrap(true); wd.toolopts.append(&l); }
            else { let r: Vec<&str> = pds.iter().map(|s| s.as_str()).collect(); dd("vpd", &r); entry("vg", "guard band (um): g or gx gy"); }
        }
        _ => {}
    }
    if tool > 0 {
        let l = gtk::Label::new(Some("Drag a rectangle: the command goes to the interpreter line (Enter runs it)"));
        l.add_css_class("dim");
        l.set_wrap(true);
        l.set_xalign(0.0);
        wd.toolopts.append(&l);
    }
}

/// run the wire drawn with the Wire tool
fn finish_wire(g: &Gr) {
    let (pts, net, ly, ndr) = {
        let mut ui = g.ui.borrow_mut();
        let p = std::mem::take(&mut ui.wpts);
        (p, ui.opt.get("wn").cloned().unwrap_or_default(), ui.opt.get("wl").cloned().unwrap_or_else(|| "M2".into()), ui.opt.get("wr").cloned().unwrap_or_default())
    };
    w(g).lay.queue_draw();
    if pts.len() < 2 { log_out(g, "Wire: click at least two points first."); return; }
    if net.trim().is_empty() { log_out(g, "Wire: set the net first (click one of its wires, or type it)."); return; }
    let net = net.trim().to_string();
    if !ndr.is_empty() && ndr != "(default)" { run_cmd(g, &format!("set_route_attributes -nets {{{}}} -route_rule {}", net, ndr)); }
    let p: Vec<String> = pts.iter().map(|(x, y)| format!("{} {}", f2(*x), f2(*y))).collect();
    run_cmd(g, &format!("add_wire -net {} -layer {} -points {{{}}}", net, ly, p.join(" ")));
}
/// select marker `i` (or step), zoom to it and describe it
fn goto_marker(g: &Gr, step: i64) {
    let (desc, ok) = {
        let mut ui = g.ui.borrow_mut();
        let n = ui.st.get("markers").arr().len();
        if n == 0 { drop(ui); w(g).info.set_text("No markers: run Check DRC / Check LVS / Missing vias"); return; }
        let i = match ui.mk_i { Some(i) => ((i as i64 + step).rem_euclid(n as i64)) as usize, None => if step < 0 { n - 1 } else { 0 } };
        ui.mk_i = Some(i);
        let m = ui.st.get("markers").at(i).clone();
        let (x0, y0, x1, y1) = (m.at(3).f(), m.at(4).f(), m.at(5).f(), m.at(6).f());
        let (cx, cy) = ((x0 + x1) / 2.0, (y0 + y1) / 2.0);
        let sz = ((x1 - x0).max(y1 - y0) * 2.5).max(12.0);
        ui.zoom_rect((cx - sz / 2.0, cy - sz / 2.0, cx + sz / 2.0, cy + sz / 2.0));
        ui.hl_net = m.at(8).arr().first().map(|x| x.s().to_string());
        (format!("[{}/{}] {}", i + 1, n, describe(&ui, &Hit::Marker(i))), true)
    };
    if ok { w(g).info.set_markup(&desc); }
    w(g).lay.queue_draw();
}

type QTabs = Vec<(String, Vec<(String, String)>)>;
/// fill the query panel: one notebook page per tab, a two-column property grid on each
fn show_query_tabs(g: &Gr, kind: &str, name: &str, tabs: &QTabs) {
    let wd = w(g);
    let cur = wd.qbook.current_page();
    while wd.qbook.n_pages() > 0 { wd.qbook.remove_page(Some(0)); }
    wd.qtitle.set_markup(&format!("<b>{}</b>  {}", glib::markup_escape_text(name), glib::markup_escape_text(kind)));
    for (t, rows) in tabs {
        let grid = gtk::Grid::new();
        grid.set_column_spacing(8);
        grid.set_row_spacing(2);
        grid.set_margin_top(4);
        grid.set_margin_start(4);
        for (i, (k, v)) in rows.iter().enumerate() {
            let kl = gtk::Label::new(Some(k));
            kl.add_css_class("dim");
            kl.set_xalign(0.0);
            kl.set_yalign(0.0);
            let vl = gtk::Label::new(Some(v));
            vl.set_xalign(0.0);
            vl.set_wrap(true);
            vl.set_wrap_mode(gtk::pango::WrapMode::WordChar);
            vl.set_selectable(true);
            vl.set_max_width_chars(28);
            grid.attach(&kl, 0, i as i32, 1, 1);
            grid.attach(&vl, 1, i as i32, 1, 1);
        }
        if rows.is_empty() { grid.attach(&gtk::Label::new(Some("(none)")), 0, 0, 1, 1); }
        let sc = gtk::ScrolledWindow::builder().child(&grid).hscrollbar_policy(gtk::PolicyType::Never).min_content_height(120).vexpand(true).build();
        wd.qbook.append_page(&sc, Some(&gtk::Label::new(Some(t))));
    }
    if let Some(c) = cur { if c < wd.qbook.n_pages() { wd.qbook.set_current_page(Some(c)); } }
    g.ui.borrow_mut().queried = Some((kind.to_string(), name.to_string()));
}
/// query a netlist object (instance / net / port / pin) through the session
fn show_query(g: &Gr, kind: &str, name: &str) -> bool {
    let r = g.sess.borrow().query_object(kind, name);
    match r {
        Some((k, n, t)) => { show_query_tabs(g, &k, &n, &t); true }
        None => false,
    }
}
fn r3(r: (f64, f64, f64, f64)) -> String { format!("({:.3}, {:.3}) – ({:.3}, {:.3})", r.0, r.1, r.2, r.3) }
fn geo_rows(r: (f64, f64, f64, f64)) -> Vec<(String, String)> {
    vec![("Bounding box".into(), r3(r)), ("Width × height".into(), format!("{:.3} × {:.3} um", r.2 - r.0, r.3 - r.1)), ("Area".into(), format!("{:.3} um²", (r.2 - r.0) * (r.3 - r.1)))]
}
/// query whatever was clicked in the layout
fn show_tabs_or_object(g: &Gr, kind: &str, name: &str, tabs: Option<&QTabs>) {
    match tabs {
        Some(t) => show_query_tabs(g, kind, name, t),
        None => { if !show_query(g, kind, name) { show_query_tabs(g, kind, name, &vec![("General".into(), vec![("Name".into(), name.to_string())])]); } }
    }
}
/// (kind, name, properties) of a layout hit; netlist objects (None) are queried through the session
fn hit_tabs(g: &Gr, h: &Hit) -> (String, String, Option<QTabs>) {
    let (kind, name, tabs): (String, String, Option<QTabs>) = {
        let ui = g.ui.borrow();
        let st = &ui.st;
        match h {
            Hit::Cell(i) => ("instance".into(), st.get("cells").at(*i).at(0).s().to_string(), None),
            Hit::Port(i) => ("port".into(), st.get("ports").at(*i).at(0).s().to_string(), None),
            Hit::Seg(_) => ("net".into(), hit_net(&ui, h).unwrap_or_default(), None),
            Hit::Special(i) => {
                let sh = st.get("special").at(*i);
                let r = sh.at(4).rect().unwrap_or((0.0, 0.0, 0.0, 0.0));
                let mut gen = vec![("Net".into(), sh.at(5).s().to_string()), ("Kind".into(), sh.at(1).s().replace('_', " ")), ("Layer".into(), sh.at(0).s().to_string()), ("Class".into(), special_class(sh.at(1).s()).to_string())];
                if sh.at(2).f() > 0.0 { gen.push(("Width".into(), format!("{:.3} um", sh.at(2).f()))); }
                let mut t: QTabs = vec![("General".into(), gen), ("Geometry".into(), geo_rows(r))];
                let v = sh.at(6);
                if !v.is_null() {
                    t.push(("Via".into(), vec![("Layers".into(), format!("{} → {}", v.at(6).s(), v.at(7).s())), ("Cuts".into(), format!("{} cols × {} rows = {}", v.at(0).i(), v.at(1).i(), v.at(0).i() * v.at(1).i())),
                        ("Cut size".into(), format!("{:.3} × {:.3} um", v.at(2).f(), v.at(3).f())), ("Cut spacing".into(), format!("{:.3} × {:.3} um", v.at(4).f(), v.at(5).f()))]));
                }
                ("special shape".into(), format!("{} {}", sh.at(5).s(), sh.at(1).s()), Some(t))
            }
            Hit::Marker(i) => {
                let m = st.get("markers").at(*i);
                let r = (m.at(3).f(), m.at(4).f(), m.at(5).f(), m.at(6).f());
                let nets: Vec<String> = m.at(8).arr().iter().map(|x| x.s().to_string()).collect();
                ("marker".into(), format!("{} {} #{}", m.at(0).s(), m.at(1).s(), i + 1), Some(vec![
                    ("General".into(), vec![("Tool".into(), m.at(0).s().to_string()), ("Kind".into(), m.at(1).s().to_string()), ("Layer".into(), m.at(2).s().to_string()), ("Message".into(), m.at(7).s().to_string()), ("Nets".into(), nets.join(" "))]),
                    ("Geometry".into(), geo_rows(r)),
                ]))
            }
            Hit::Pblk(i) | Hit::Rblk(i) | Hit::Guide(i) | Hit::Bound(i) => {
                let (key, kind) = match h { Hit::Pblk(_) => ("pblk", "placement blockage"), Hit::Rblk(_) => ("rblk", "routing blockage"), Hit::Guide(_) => ("guides", "route guide"), _ => ("bounds", "bound") };
                let o = st.get(key).at(*i);
                let r = o.get("r").rect().unwrap_or((0.0, 0.0, 0.0, 0.0));
                let mut gen: Vec<(String, String)> = vec![];
                if let J::Obj(m) = o { for (k, v) in m { if k != "r" { gen.push((k.clone(), match v { J::Str(s) => s.clone(), J::Num(n) => format!("{}", n), J::Arr(a) => a.iter().map(|x| x.s().to_string()).collect::<Vec<_>>().join(" "), J::Bool(b) => b.to_string(), _ => String::new() })); } } }
                (kind.into(), o.get("n").s().to_string(), Some(vec![("General".into(), gen), ("Geometry".into(), geo_rows(r))]))
            }
            Hit::Pd(i) => {
                let o = st.get("pds").at(*i);
                ("power domain".into(), o.get("n").s().to_string(), Some(vec![("General".into(), vec![("Name".into(), o.get("n").s().to_string())]), ("Geometry".into(), o.get("va").rect().map(geo_rows).unwrap_or_default())]))
            }
            Hit::Point(x, y) => ("point".into(), format!("({:.3}, {:.3})", x, y), Some(vec![("General".into(), vec![("Location".into(), format!("({:.3}, {:.3}) um", x, y)), ("Object".into(), "nothing here".into())])])),
        }
    };
    (kind, name, tabs)
}

// ----------------------------------------------------------------------------------- selection
/// session object handle -> (query kind, name)
fn handle_kind(h: &str) -> Option<(String, String)> {
    let (k, n) = h.split_once("::")?;
    let kind = match k { "cell" => "instance", "pin" => "pin", "port" => "port", "net" => "net", _ => return None };
    Some((kind.to_string(), n.to_string()))
}
/// Change the selection (mode 0 replace, 1 add, 2 toggle) and update everything that follows it:
/// layout highlight and pin markers, flylines of the selected instances / pins / ports, the
/// schematic highlight (the schematic is rebuilt around the selection when needed) and, with
/// `props`, the paginated QUERY pane. A plain click does not query (Q does).
fn apply_selection(g: &Gr, items: Vec<String>, mode: u8, props: bool) {
    let sel: Vec<String> = {
        let mut s = g.sess.borrow_mut();
        match mode {
            0 => s.selection = items.clone(),
            1 => { for h in &items { if !s.selection.contains(h) { s.selection.push(h.clone()); } } }
            _ => { for h in &items { if let Some(k) = s.selection.iter().position(|x| x == h) { s.selection.remove(k); } else { s.selection.push(h.clone()); } } }
        }
        s.selection.clone()
    };
    let (mut cells, mut pins, mut ports) = (vec![], vec![], vec![]);
    for h in &sel {
        match h.split_once("::") {
            Some(("cell", n)) => cells.push(n.to_string()),
            Some(("pin", n)) => pins.push(n.to_string()),
            Some(("port", n)) => ports.push(n.to_string()),
            _ => {}
        }
    }
    let owners: Vec<String> = pins.iter().filter_map(|p| p.rsplit_once('/').map(|x| x.0.to_string())).collect();
    let mcells: Vec<String> = cells.iter().chain(owners.iter()).cloned().collect();
    let marks = if mcells.len() <= 50 { g.sess.borrow().gui_pin_marks(&mcells) } else { vec![] };
    let (fly, missing) = {
        let mut ui = g.ui.borrow_mut();
        ui.sel = cells.last().cloned().or_else(|| owners.last().cloned());
        ui.sel_rect = None;
        ui.sch_msel = cells.iter().chain(owners.iter()).cloned().collect();
        ui.sch_sel = ui.sel.clone();
        ui.sel_ports = ports.iter().cloned().collect();
        ui.sel_pins = pins.iter().cloned().collect();
        ui.pin_marks = marks;
        ui.hl_net = sel.iter().rev().find_map(|h| h.strip_prefix("net::").map(|x| x.to_string()));
        let in_sch: std::collections::HashSet<&str> = ui.sch.as_ref().map(|sg| sg.n.iter().map(|c| c.name.as_str()).collect()).unwrap_or_default();
        let missing: Vec<String> = ui.sch_msel.iter().filter(|c| !in_sch.contains(c.as_str())).cloned().collect();
        (ui.fly_click, missing)
    };
    let braced = |v: &[String]| v.iter().map(|x| format!("{{{}}}", x)).collect::<Vec<_>>().join(" ");
    let mut cmds: Vec<String> = vec![];
    if fly {
        if cells.len() > 200 {
            cmds.push("gui_show_flylines -clear".into());
            w(g).status.set_text(&format!("{} instances selected: flylines are shown for up to 200 (Flylines panel: all cells)", cells.len()));
        } else if cells.is_empty() && pins.is_empty() && ports.is_empty() {
            cmds.push("gui_show_flylines -clear".into());
        } else {
            let mut c = "gui_show_flylines".to_string();
            if !cells.is_empty() { c.push_str(&format!(" -cells {{{}}}", braced(&cells))); }
            if !pins.is_empty() { c.push_str(&format!(" -pins {{{}}}", braced(&pins))); }
            if !ports.is_empty() { c.push_str(&format!(" -ports {{{}}}", braced(&ports))); }
            cmds.push(c);
        }
    }
    // schematic: show the selected instances (rebuilt around them when not all are drawn)
    let seeds: Vec<String> = cells.iter().chain(owners.iter()).cloned().collect();
    if !missing.is_empty() && !seeds.is_empty() && seeds.len() <= 40 {
        cmds.push(format!("gui_show_schematic -cells {{{}}} -depth 1", braced(&seeds)));
    }
    let n = sel.len();
    let txt = match n {
        0 => "Nothing selected.".to_string(),
        1 => format!("Selected {} {} — Q: properties", handle_kind(&sel[0]).map(|x| x.0).unwrap_or_default(), handle_kind(&sel[0]).map(|x| x.1).unwrap_or_default()),
        _ => format!("{} objects selected ({} instance(s), {} pin(s), {} port(s)) — Q: properties, PgUp / PgDn page through them", n, cells.len(), pins.len(), ports.len()),
    };
    if cmds.is_empty() {
        refresh(g);
    } else {
        for c in cmds { run_cmd(g, &c); }
    }
    w(g).info.set_text(&txt);
    if props {
        query_selection(g);
    } else {
        let mut ui = g.ui.borrow_mut();
        ui.qlist.clear();
    }
    w(g).lay.queue_draw();
    w(g).sch.queue_draw();
}
/// Q: properties of the selected objects, one object per page
fn query_selection(g: &Gr) {
    let sel: Vec<(String, String)> = g.sess.borrow().selection.iter().filter_map(|h| handle_kind(h)).collect();
    if sel.is_empty() {
        // a clicked non-netlist object, else the highlighted net
        let (lh, net) = { let ui = g.ui.borrow(); (ui.last_hit.clone(), ui.hl_net.clone()) };
        match (lh, net) {
            (Some((k, n, t)), _) => { g.ui.borrow_mut().qlist.clear(); show_tabs_or_object(g, &k, &n, t.as_ref()); update_qnav(g); }
            (None, Some(n)) => { g.ui.borrow_mut().qlist = vec![("net".into(), n)]; g.ui.borrow_mut().qpos = 0; show_qpage(g); }
            _ => { w(g).status.set_text("Query: select objects first (click, Shift+click or drag a box in the layout; click in the schematic)"); }
        }
        return;
    }
    {
        let mut ui = g.ui.borrow_mut();
        if ui.qlist != sel { ui.qpos = 0; }
        ui.qlist = sel;
        if ui.qpos >= ui.qlist.len() { ui.qpos = 0; }
    }
    show_qpage(g);
}
fn show_qpage(g: &Gr) {
    let it = { let ui = g.ui.borrow(); ui.qlist.get(ui.qpos).cloned() };
    if let Some((k, n)) = it {
        if !show_query(g, &k, &n) {
            show_query_tabs(g, &k, &n, &vec![("General".into(), vec![("Name".into(), n.clone()), ("Status".into(), "not found in the current design".into())])]);
        }
    }
    update_qnav(g);
}
fn update_qnav(g: &Gr) {
    let (pos, n, cur) = { let ui = g.ui.borrow(); (ui.qpos, ui.qlist.len(), ui.qlist.get(ui.qpos).cloned()) };
    let wd = w(g);
    if n == 0 {
        wd.qpage.set_text("");
    } else {
        wd.qpage.set_text(&format!("{} / {}", pos + 1, n));
        if let Some((k, nm)) = cur {
            wd.qtitle.set_markup(&format!("<b>{}</b>  {}   <span alpha=\"60%\">[{} / {}]</span>", glib::markup_escape_text(&nm), glib::markup_escape_text(&k), pos + 1, n));
        }
    }
    wd.qprev.set_sensitive(n > 1);
    wd.qnext.set_sensitive(n > 1);
}
/// next / previous page of the QUERY pane (wraps around)
fn qstep(g: &Gr, d: i64) {
    {
        let mut ui = g.ui.borrow_mut();
        let n = ui.qlist.len();
        if n == 0 { return; }
        ui.qpos = ((ui.qpos as i64 + d).rem_euclid(n as i64)) as usize;
    }
    show_qpage(g);
}
/// left click in the layout: select the instance / pin / port / net under the cursor (Shift toggles),
/// show its flylines and its schematic; Q lists the properties
fn layout_click(g2: &Gr, x0: f64, y0: f64, shift: bool, tool: usize) {
    let h = { let ui = g2.ui.borrow(); pick(&ui, x0, y0) };
    let (desc, hn, mk, cell) = { let ui = g2.ui.borrow(); (describe(&ui, &h), hit_net(&ui, &h), match &h { Hit::Marker(i) => Some(*i), _ => None }, match &h { Hit::Cell(i) => Some(ui.st.get("cells").at(*i).at(0).s().to_string()), _ => None }) };
    {
        let mut ui = g2.ui.borrow_mut();
        if mk.is_some() { ui.mk_i = mk; }
        if let Some(n) = &hn { if ui.tool >= T_WIRE { ui.opt.insert("wn", n.clone()); } }
    }
    if hn.is_some() && tool >= T_WIRE { rebuild_toolopts(g2); }
    // the netlist object under the cursor: a pin of the clicked instance, the instance, a port, a net
    let item: Option<String> = match &h {
        Hit::Cell(_) => {
            let c = cell.clone().unwrap();
            // pins are pickable once the instance is large enough on screen (zoom in); the click
            // must be on the pin shape (1 px tolerance)
            let (wx, wy, tol, big) = {
                let ui = g2.ui.borrow();
                let (x, y) = ui.s2w(x0, y0);
                let cw = match &h { Hit::Cell(i) => ui.st.get("cells").at(*i).at(8).f().min(ui.st.get("cells").at(*i).at(9).f()), _ => 0.0 };
                (x, y, 1.0 / ui.view.s, cw * ui.view.s >= 30.0)
            };
            let pin = if big { g2.sess.borrow().gui_pin_at(&c, wx, wy, tol) } else { None };
            match pin { Some(p) => Some(format!("pin::{}", p)), None => Some(format!("cell::{}", c)) }
        }
        Hit::Port(i) => Some(format!("port::{}", g2.ui.borrow().st.get("ports").at(*i).at(0).s())),
        Hit::Seg(_) => hn.clone().filter(|n| !n.is_empty()).map(|n| format!("net::{}", n)),
        _ => None,
    };
    if tool != 0 && item.is_none() { w(g2).info.set_markup(&desc); }
    match item {
        Some(it) => {
            g2.ui.borrow_mut().last_hit = None;
            apply_selection(g2, vec![it.clone()], if shift { 2 } else { 0 }, false);
            if let Some((k, n)) = handle_kind(&it) {
                let extra = if k == "pin" { "\nflylines of this pin's net" } else if k == "instance" { "\nflylines of all its pins (pin markers: click one)" } else if k == "port" { "\nflylines of this port's net" } else { "" };
                let nsel = g2.sess.borrow().selection.len();
                w(g2).info.set_markup(&format!("{}\n<b>{}</b> {} selected{}{}\nQ: properties{}", desc, glib::markup_escape_text(&n), k, extra, if nsel > 1 { format!(" · {} selected", nsel) } else { String::new() }, if nsel > 1 { " (PgUp / PgDn)" } else { "" }));
            }
        }
        None => {
            // non-netlist objects (blockage, guide, marker, power domain, empty area)
            let lh = hit_tabs(g2, &h);
            let pd = { let ui = g2.ui.borrow(); match &h { Hit::Pd(i) => Some(ui.st.get("pds").at(*i).get("n").s().to_string()), _ => None } };
            {
                let mut ui = g2.ui.borrow_mut();
                let hr = { let st = &ui.st; match &h {
                    Hit::Pblk(i) => st.get("pblk").at(*i).get("r").rect(), Hit::Rblk(i) => st.get("rblk").at(*i).get("r").rect(),
                    Hit::Guide(i) => st.get("guides").at(*i).get("r").rect(), Hit::Pd(i) => st.get("pds").at(*i).get("va").rect(),
                    Hit::Bound(i) => st.get("bounds").at(*i).get("r").rect(),
                    _ => None } };
                ui.sel_rect = hr;
                ui.hl_net = hn.clone();
                ui.last_hit = if matches!(h, Hit::Point(..)) { None } else { Some(lh) };
            }
            if matches!(h, Hit::Point(..)) && !shift {
                // click on empty space clears the selection
                if !g2.sess.borrow().selection.is_empty() { apply_selection(g2, vec![], 0, false); }
                w(g2).info.set_markup(&desc);
            } else {
                w(g2).info.set_markup(&format!("{}\nQ: properties", desc));
            }
            if let Some(n) = pd {
                let g3 = g2.clone();
                glib::idle_add_local_once(move || run_cmd(&g3, &format!("gui_highlight_power_domain {}{}", if shift { "-add " } else { "" }, n)));
            }
        }
    }
    w(g2).sch.queue_draw();
    w(g2).lay.queue_draw();
}
/// box selection in world coordinates: instances whose centre is inside, and top-level ports
fn select_box(g: &Gr, r: (f64, f64, f64, f64), mode: u8) {
    let items: Vec<String> = {
        let ui = g.ui.borrow();
        let st = &ui.st;
        let inside = |x: f64, y: f64| x >= r.0 && x <= r.2 && y >= r.1 && y <= r.3;
        let mut v: Vec<String> = vec![];
        for c in st.get("cells").arr() {
            let a = c.arr();
            if a.len() < 8 { continue; }
            let kind = match a[4].s() { "b" => "macros", "p" => "pads", "f" => "phys", _ => "cells" };
            if kind == "phys" || !ui.on(kind) { continue; }
            if inside(a[1].f(), a[2].f()) { v.push(format!("cell::{}", a[0].s())); }
        }
        if ui.on("pins") {
            for p in st.get("ports").arr() {
                if inside(p.at(1).f(), p.at(2).f()) { v.push(format!("port::{}", p.at(0).s())); }
            }
        }
        v
    };
    if items.is_empty() && mode == 0 {
        w(g).status.set_text("Box select: no instance or port inside the box");
        return;
    }
    apply_selection(g, items, mode, true);
}

fn complete_entry(g: &Gr, e: &gtk::Entry, list: bool) {
    let txt = e.text().to_string();
    let cur = e.position().max(0) as usize;
    let s = g.sess.borrow();
    let mut cmds: Vec<String> = crate::cmdreg::all().iter().flat_map(|c| std::iter::once(c.name).chain(c.aliases.iter().copied())).map(|n| n.to_string()).collect();
    cmds.extend(s.interp.procs.keys().cloned());
    let vars = s.interp.var_names();
    let opts_of = |c: &str| -> Vec<String> {
        let mut v: Vec<String> = vec![];
        if let Some(ci) = crate::cmdreg::find(c) {
            v.extend(ci.options.iter().chain(ci.flags.iter()).map(|o| o.to_string()));
            if let Some(sx) = s.curated_syntax(ci.name) {
                for wd in sx.split(|ch: char| ch.is_whitespace() || "[]{}()|,".contains(ch)) { if wd.len() > 1 && wd.starts_with('-') { v.push(wd.to_string()); } }
            }
        }
        v
    };
    let (start, mut cands) = crate::lineedit::complete(&txt, cur, &cmds, &opts_of, &vars);
    drop(s);
    cands.sort();
    cands.dedup();
    let chars: Vec<char> = txt.chars().collect();
    let word: String = chars[start.min(cur)..cur].iter().collect();
    let replace = |ins: &str, space: bool| {
        let mut n: String = chars[..start].iter().collect();
        n.push_str(ins);
        if space { n.push(' '); }
        let pos = n.chars().count();
        n.extend(chars[cur..].iter());
        e.set_text(&n);
        e.set_position(pos as i32);
    };
    if cands.len() == 1 {
        replace(&cands[0], !cands[0].ends_with('/'));
    } else if cands.len() > 1 {
        let cp = crate::lineedit::common_prefix(&cands);
        if cp.chars().count() > word.chars().count() { replace(&cp, false); }
        else if list { log_out(g, &cands.iter().take(300).cloned().collect::<Vec<_>>().join("  ")); }
    } else {
        e.error_bell();
    }
}

const CSS: &str = "
window, .bg { background: #1b1d21; color: #d6d6d6; }
.panel { background: #202328; padding: 6px; }
.hdr { color: #8c96a8; font-size: 11px; font-weight: bold; margin-top: 8px; }
.dim { color: #8a8f98; font-size: 11px; }
textview, textview text { background: #0b0c0e; color: #c8e6c8; font-family: monospace; font-size: 11px; }
entry.console { font-family: monospace; background: #0b0c0e; color: #e8e8e8; }
.status { font-family: monospace; color: #9fb4d0; font-size: 11px; padding: 2px 8px; }
notebook > header { background: #202328; }
notebook > header tab { padding: 4px 14px; color: #c8c8c8; }
notebook > header tab label { color: #c8c8c8; }
notebook > header tab:checked { box-shadow: inset 0 -2px #5a8cff; color: #ffffff; }
notebook > header tab:checked label { color: #ffffff; }
";

fn build(app: &gtk::Application, g: Gr) {
    if let Some(st) = gtk::Settings::default() { st.set_gtk_application_prefer_dark_theme(true); }
    let prov = gtk::CssProvider::new();
    prov.load_from_string(CSS);
    if let Some(d) = gdk::Display::default() { gtk::style_context_add_provider_for_display(&d, &prov, gtk::STYLE_PROVIDER_PRIORITY_APPLICATION); }
    let win = gtk::ApplicationWindow::builder().application(app).default_width(1500).default_height(940).title("RSynth").build();
    // ---- header bar
    let hb = gtk::HeaderBar::new();
    let title = gtk::Label::new(Some("RSynth"));
    title.add_css_class("dim");
    hb.set_title_widget(Some(&title));
    let bfit = gtk::Button::with_label("Fit");
    let bzi = gtk::Button::with_label("Zoom +");
    let bzo = gtk::Button::with_label("Zoom −");
    let bpng = gtk::Button::with_label("Save image");
    let bscr = gtk::Button::with_label("Save script");
    let bclose = gtk::Button::with_label("Close GUI");
    hb.pack_start(&bfit);
    hb.pack_start(&bzi);
    hb.pack_start(&bzo);
    // Route / Power menus: popovers of buttons
    let mk_menu = |label: &str| -> (gtk::MenuButton, gtk::Box, gtk::Popover) {
        let mb = gtk::MenuButton::new();
        mb.set_label(label);
        let bx = gtk::Box::new(gtk::Orientation::Vertical, 2);
        let pop = gtk::Popover::new();
        pop.set_child(Some(&bx));
        mb.set_popover(Some(&pop));
        (mb, bx, pop)
    };
    let (mroute, broute, proute) = mk_menu("Route");
    let (mpower, bpower, ppower) = mk_menu("Power");
    let (mlayout, blayout, playout) = mk_menu("Layout");
    hb.pack_start(&mlayout);
    hb.pack_start(&mroute);
    hb.pack_start(&mpower);
    hb.pack_end(&bclose);
    hb.pack_end(&bscr);
    hb.pack_end(&bpng);
    win.set_titlebar(Some(&hb));
    // ---- left panel
    let left = gtk::Box::new(gtk::Orientation::Vertical, 4);
    left.add_css_class("panel");
    let hdr = |t: &str| { let l = gtk::Label::new(Some(t)); l.add_css_class("hdr"); l.set_xalign(0.0); l };
    left.append(&hdr("TOOLS"));
    let mut first: Option<gtk::ToggleButton> = None;
    let tbs: Vec<gtk::ToggleButton> = TOOLS.iter().map(|t| { let b = gtk::ToggleButton::with_label(t); if let Some(f) = &first { b.set_group(Some(f)); } else { first = Some(b.clone()); } left.append(&b); b }).collect();
    tbs[0].set_active(true);
    let toolopts = gtk::Box::new(gtk::Orientation::Vertical, 3);
    left.append(&toolopts);
    left.append(&hdr("POWER DOMAINS"));
    let pdbox = gtk::Box::new(gtk::Orientation::Vertical, 3);
    left.append(&pdbox);
    left.append(&hdr("FLYLINES (SELECTED CELLS)"));
    let flylabel = gtk::Label::new(None);
    flylabel.add_css_class("dim");
    flylabel.set_wrap(true);
    flylabel.set_xalign(0.0);
    left.append(&flylabel);
    let flyclick = gtk::CheckButton::with_label("Flylines on click");
    flyclick.set_active(true);
    left.append(&flyclick);
    let frow = gtk::Box::new(gtk::Orientation::Horizontal, 4);
    let bfa = gtk::Button::with_label("All macros");
    let bfs = gtk::Button::with_label("All std cells");
    let bfc = gtk::Button::with_label("Clear");
    frow.append(&bfa);
    frow.append(&bfs);
    frow.append(&bfc);
    left.append(&frow);
    let fcol = gtk::DropDown::from_strings(&["Colour by net", "Colour by macro"]);
    left.append(&fcol);
    let fm2m = gtk::CheckButton::with_label("Macro-to-macro only");
    left.append(&fm2m);
    let fex = gtk::Entry::new();
    fex.set_placeholder_text(Some("exclude nets, e.g. clk* rst*"));
    left.append(&fex);
    let fmf = gtk::Entry::new();
    fmf.set_placeholder_text(Some("max fanout (0 = all)"));
    left.append(&fmf);
    left.append(&hdr("LEGEND"));
    let legend = gtk::Box::new(gtk::Orientation::Vertical, 2);
    left.append(&legend);
    let lscroll = gtk::ScrolledWindow::builder().child(&left).hscrollbar_policy(gtk::PolicyType::Never).min_content_width(250).build();
    // ---- right panel: layers + info
    let right = gtk::Box::new(gtk::Orientation::Vertical, 4);
    right.add_css_class("panel");
    // tabbed: floorplan object classes | LEF layers (colour + stipple, visibility)
    let layers = gtk::Box::new(gtk::Orientation::Vertical, 2);
    let lef = gtk::Box::new(gtk::Orientation::Vertical, 2);
    let lnb = gtk::Notebook::new();
    lnb.append_page(&layers, Some(&gtk::Label::new(Some("FPObjects"))));
    lnb.append_page(&lef, Some(&gtk::Label::new(Some("Layers"))));
    right.append(&lnb);
    right.append(&hdr("DRC / LVS MARKERS"));
    let mklabel = gtk::Label::new(Some("No markers"));
    mklabel.add_css_class("dim");
    mklabel.set_xalign(0.0);
    mklabel.set_wrap(true);
    right.append(&mklabel);
    let mkrow1 = gtk::Box::new(gtk::Orientation::Horizontal, 4);
    let bmprev = gtk::Button::with_label("◀ Prev");
    let bmnext = gtk::Button::with_label("Next ▶");
    let bmclr = gtk::Button::with_label("Clear");
    for b in [&bmprev, &bmnext, &bmclr] { mkrow1.append(b); }
    right.append(&mkrow1);
    let mkrow2 = gtk::Box::new(gtk::Orientation::Horizontal, 4);
    let bmdrc = gtk::Button::with_label("DRC");
    let bmlvs = gtk::Button::with_label("LVS");
    let bmvia = gtk::Button::with_label("Vias");
    let bmcal = gtk::Button::with_label("Calibre…");
    for b in [&bmdrc, &bmlvs, &bmvia, &bmcal] { mkrow2.append(b); }
    right.append(&mkrow2);
    right.append(&hdr("SELECTION"));
    let info = gtk::Label::new(Some("Click an object to inspect it."));
    info.set_wrap(true);
    info.set_xalign(0.0);
    info.set_selectable(true);
    right.append(&info);
    // query: its own pane under the panels, always visible
    let qbox = gtk::Box::new(gtk::Orientation::Vertical, 4);
    qbox.add_css_class("panel");
    qbox.append(&hdr("QUERY"));
    let qtitle = gtk::Label::new(Some("Select objects (click, Shift+click, drag a box), then Q to list their properties."));
    qtitle.add_css_class("dim");
    qtitle.set_wrap(true);
    qtitle.set_xalign(0.0);
    qbox.append(&qtitle);
    // pages: one selected object per page
    let qnav = gtk::Box::new(gtk::Orientation::Horizontal, 4);
    let qprev = gtk::Button::with_label("◀");
    let qnext = gtk::Button::with_label("▶");
    let qpage = gtk::Label::new(Some("no selection"));
    qpage.add_css_class("dim");
    qpage.set_hexpand(true);
    qprev.set_tooltip_text(Some("previous selected object (PgUp / [)"));
    qnext.set_tooltip_text(Some("next selected object (PgDn / ])"));
    qprev.set_sensitive(false);
    qnext.set_sensitive(false);
    qnav.append(&qprev);
    qnav.append(&qpage);
    qnav.append(&qnext);
    qbox.append(&qnav);
    let qbook = gtk::Notebook::new();
    qbook.set_scrollable(true);
    qbook.set_vexpand(true);
    qbox.append(&qbook);
    let rscroll0 = gtk::ScrolledWindow::builder().child(&right).hscrollbar_policy(gtk::PolicyType::Never).min_content_width(240).vexpand(true).build();
    let rscroll = gtk::Paned::new(gtk::Orientation::Vertical);
    rscroll.set_start_child(Some(&rscroll0));
    rscroll.set_end_child(Some(&qbox));
    rscroll.set_resize_start_child(true);
    rscroll.set_shrink_end_child(false);
    rscroll.set_position(560);
    // ---- centre: notebook (layout / schematic)
    let lay = gtk::DrawingArea::new();
    lay.set_hexpand(true);
    lay.set_vexpand(true);
    lay.set_focusable(true);
    let sch = gtk::DrawingArea::new();
    sch.set_hexpand(true);
    sch.set_vexpand(true);
    sch.set_focusable(true);
    let schpage = gtk::Box::new(gtk::Orientation::Vertical, 0);
    let schbar = gtk::Box::new(gtk::Orientation::Horizontal, 6);
    schbar.add_css_class("panel");
    let schcells = gtk::Entry::new();
    schcells.set_placeholder_text(Some("cells / ports (patterns)"));
    schcells.set_width_chars(18);
    schcells.set_hexpand(true);
    let schdepth = gtk::SpinButton::with_range(0.0, 8.0, 1.0);
    schdepth.set_value(2.0);
    let bshow = gtk::Button::with_label("Show");
    let bsel = gtk::Button::with_label("From layout selection");
    let ball = gtk::Button::with_label("Whole design");
    let bsfit = gtk::Button::with_label("Fit");
    let bsvg = gtk::Button::with_label("Save SVG");
    let schpins = gtk::CheckButton::with_label("Pin names");
    schpins.set_active(true);
    let trl = gtk::Label::new(Some("Trace levels"));
    trl.add_css_class("dim");
    let schtrace = gtk::SpinButton::with_range(1.0, 32.0, 1.0);
    schtrace.set_value(2.0);
    schtrace.set_tooltip_text(Some("levels of logic traced on a pin double-click"));
    let schend = gtk::CheckButton::with_label("To endpoint");
    schend.set_tooltip_text(Some("trace through combinational logic to the next flop / port"));
    let bsclr = gtk::Button::with_label("Clear trace");
    let schstat = gtk::Label::new(None);
    schstat.add_css_class("dim");
    for x in [schcells.upcast_ref::<gtk::Widget>(), schdepth.upcast_ref(), bshow.upcast_ref(), bsel.upcast_ref(), ball.upcast_ref(), bsfit.upcast_ref(), bsvg.upcast_ref()] { schbar.append(x); }
    schpage.append(&schbar);
    // second row: pin names and signal tracing
    let schbar2 = gtk::Box::new(gtk::Orientation::Horizontal, 6);
    schbar2.add_css_class("panel");
    let trh = gtk::Label::new(Some("double-click a pin: trace"));
    trh.add_css_class("dim");
    for x in [schpins.upcast_ref::<gtk::Widget>(), trl.upcast_ref(), schtrace.upcast_ref(), trh.upcast_ref(), schend.upcast_ref(), bsclr.upcast_ref()] { schbar2.append(x); }
    schpage.append(&schbar2);
    schstat.set_xalign(0.0);
    schstat.set_margin_start(8);
    schstat.set_ellipsize(gtk::pango::EllipsizeMode::End);
    schpage.append(&schstat);
    schpage.append(&sch);
    let nb = gtk::Notebook::new();
    nb.append_page(&lay, Some(&gtk::Label::new(Some("Layout"))));
    nb.append_page(&schpage, Some(&gtk::Label::new(Some("Schematic"))));
    let (ctpage, ctstore, ctview, ctclock, ctsinks, ctsum, ctrefresh, ctexpand, ctcollapse) = build_ctree_page();
    nb.append_page(&ctpage, Some(&gtk::Label::new(Some("Clock Tree"))));
    let hp1 = gtk::Paned::new(gtk::Orientation::Horizontal);
    hp1.set_start_child(Some(&lscroll));
    let hp2 = gtk::Paned::new(gtk::Orientation::Horizontal);
    hp2.set_start_child(Some(&nb));
    hp2.set_end_child(Some(&rscroll));
    hp2.set_resize_end_child(false);
    hp2.set_shrink_end_child(false);
    hp1.set_end_child(Some(&hp2));
    hp1.set_resize_start_child(false);
    hp1.set_shrink_start_child(false);
    // ---- bottom: interpreter
    let tv = gtk::TextView::new();
    tv.set_editable(false);
    tv.set_monospace(true);
    tv.set_wrap_mode(gtk::WrapMode::WordChar);
    let tscroll = gtk::ScrolledWindow::builder().child(&tv).vexpand(true).min_content_height(120).build();
    let crow = gtk::Box::new(gtk::Orientation::Horizontal, 6);
    crow.add_css_class("panel");
    let prompt = gtk::Label::new(Some("rsynth>"));
    prompt.add_css_class("status");
    let entry = gtk::Entry::new();
    entry.add_css_class("console");
    entry.set_hexpand(true);
    entry.set_placeholder_text(Some("Tcl command (Tab completes, Up/Down history)"));
    let brun = gtk::Button::with_label("Run");
    crow.append(&prompt);
    crow.append(&entry);
    crow.append(&brun);
    let console = gtk::Box::new(gtk::Orientation::Vertical, 0);
    console.append(&tscroll);
    console.append(&crow);
    let status = gtk::Label::new(Some(""));
    status.add_css_class("status");
    status.set_xalign(0.0);
    console.append(&status);
    let vp = gtk::Paned::new(gtk::Orientation::Vertical);
    vp.set_start_child(Some(&hp1));
    vp.set_end_child(Some(&console));
    vp.set_position(690);
    win.set_child(Some(&vp));

    let _ = g.w.set(W { win: win.clone(), nb: nb.clone(), lay: lay.clone(), sch: sch.clone(), tv, entry: entry.clone(), status, info, layers, lef, pdbox, flylabel, legend, toolopts, schcells: schcells.clone(), schdepth: schdepth.clone(), schstat, title, mklabel, schtrace: schtrace.clone(), schend: schend.clone(), qbook, qtitle, qprev: qprev.clone(), qnext: qnext.clone(), qpage, tools: tbs.clone(), ctstore, ctview, ctclock, ctsinks, ctsum });
    { let g2 = g.clone(); qprev.connect_clicked(move |_| qstep(&g2, -1)); }
    { let g2 = g.clone(); qnext.connect_clicked(move |_| qstep(&g2, 1)); }
    connect_ctree(&g, &ctrefresh, &ctexpand, &ctcollapse);

    // ---- drawing
    let g2 = g.clone();
    lay.set_draw_func(move |_, cr, w, h| {
        let mut ui = g2.ui.borrow_mut();
        ui.size = (w as f64, h as f64);
        if ui.need_fit { ui.fit(); ui.need_fit = false; }
        if let Some(r) = ui.pending_zoom.take() { ui.zoom_rect(r); }
        draw_layout(cr, &ui);
    });
    let g2 = g.clone();
    sch.set_draw_func(move |_, cr, w, h| {
        let mut ui = g2.ui.borrow_mut();
        ui.ssize = (w as f64, h as f64);
        if ui.sch_fit { sch_fit(&mut ui); ui.sch_fit = false; }
        draw_sch(cr, &ui, w as f64, h as f64, true);
    });
    // ---- layout interaction
    let motion = gtk::EventControllerMotion::new();
    let g2 = g.clone();
    motion.connect_motion(move |_, x, y| {
        let (wx, wy, desc) = { let mut ui = g2.ui.borrow_mut(); ui.mouse = (x, y); let (wx, wy) = ui.s2w(x, y); let h = pick(&ui, x, y); (wx, wy, match h { Hit::Point(..) => String::new(), h => describe(&ui, &h).lines().next().unwrap_or("").replace("<b>", "").replace("</b>", "") }) };
        w(&g2).status.set_text(&format!("x {:>10.3}  y {:>10.3} um   {}", wx, wy, desc));
        if g2.ui.borrow().tool == T_WIRE && !g2.ui.borrow().wpts.is_empty() { w(&g2).lay.queue_draw(); }
        if g2.ui.borrow().tool == T_RULER {
            let ui = g2.ui.borrow();
            let p = ui.ruler_pt(x, y, ui.rstart);
            let msg = match ui.rstart {
                Some(a) => { let (dx, dy) = (p.0 - a.0, p.1 - a.1); format!("ruler  d {:.3} um   dx {:.3}   dy {:.3}   ∠{:.1}°   (snap {:.3}, {})", (dx * dx + dy * dy).sqrt(), dx, dy, dy.atan2(dx).to_degrees(), ui.ruler_grid(), ui.opt.get("ra").cloned().unwrap_or_default()) }
                None => format!("x {:>10.3}  y {:>10.3} um   ruler snap {:.3}", p.0, p.1, ui.ruler_grid()),
            };
            drop(ui);
            w(&g2).status.set_text(&msg);
            w(&g2).lay.queue_draw();
        }
    });
    lay.add_controller(motion);
    let scroll = gtk::EventControllerScroll::new(gtk::EventControllerScrollFlags::VERTICAL);
    let g2 = g.clone();
    scroll.connect_scroll(move |_, _, dy| {
        { let mut ui = g2.ui.borrow_mut(); let (mx, my) = ui.mouse; ui.zoom(if dy < 0.0 { 1.2 } else { 1.0 / 1.2 }, mx, my); }
        w(&g2).lay.queue_draw();
        glib::Propagation::Stop
    });
    lay.add_controller(scroll);
    let drag = gtk::GestureDrag::new();
    drag.set_button(0);
    let g2 = g.clone();
    drag.connect_drag_begin(move |gd, x, y| {
        let b = gd.current_button();
        let ctrl = gd.current_event_state().contains(gdk::ModifierType::CONTROL_MASK);
        let mut ui = g2.ui.borrow_mut();
        let v = ui.view.clone();
        ui.drag = Some((x, y, x, y, b, v));
        // select tool: left drag draws a selection box, Ctrl+left / middle drag pans
        ui.drag_pan = b == 2 || (b == 1 && ctrl);
    });
    let g2 = g.clone();
    drag.connect_drag_update(move |_, dx, dy| {
        let mut ui = g2.ui.borrow_mut();
        let tool = ui.tool;
        let pan = ui.drag_pan;
        let mut nv = None;
        if let Some(d) = ui.drag.as_mut() {
            d.2 = d.0 + dx;
            d.3 = d.1 + dy;
            if (tool == 0 && d.4 == 1 && pan) || d.4 == 2 { nv = Some(d.5.clone()); }
        }
        if let Some(v) = nv { ui.view.ox = v.ox + dx; ui.view.oy = v.oy - dy; }
        drop(ui);
        w(&g2).lay.queue_draw();
    });
    let g2 = g.clone();
    drag.connect_drag_end(move |gd, dx, dy| {
        let shift = gd.current_event_state().contains(gdk::ModifierType::SHIFT_MASK);
        let d = g2.ui.borrow_mut().drag.take();
        let Some((x0, y0, _, _, b, _)) = d else { return };
        let tool = g2.ui.borrow().tool;
        w(&g2).lay.grab_focus();
        if b == 1 && tool == T_RULER {
            let done = {
                let mut ui = g2.ui.borrow_mut();
                if dx.abs() + dy.abs() > 3.0 {
                    let a = ui.ruler_pt(x0, y0, None);
                    let p = ui.ruler_pt(x0 + dx, y0 + dy, Some(a));
                    ui.rstart = None;
                    Some((a, p))
                } else if let Some(a) = ui.rstart.take() {
                    Some((a, ui.ruler_pt(x0, y0, Some(a))))
                } else {
                    ui.rstart = Some(ui.ruler_pt(x0, y0, None));
                    None
                }
            };
            if let Some((a, p)) = done {
                if (a.0 - p.0).abs() + (a.1 - p.1).abs() > 0.0 {
                    let g3 = g2.clone();
                    glib::idle_add_local_once(move || run_cmd(&g3, &format!("gui_add_ruler -from {{{} {}}} -to {{{} {}}}", f3s(a.0), f3s(a.1), f3s(p.0), f3s(p.1))));
                }
            }
            w(&g2).lay.queue_draw();
            return;
        }
        if b == 3 && tool == T_RULER && dx.abs() < 3.0 && dy.abs() < 3.0 {
            g2.ui.borrow_mut().rstart = None;
            w(&g2).lay.queue_draw();
            return;
        }
        if b == 3 && tool == T_WIRE && dx.abs() < 3.0 && dy.abs() < 3.0 {
            finish_wire(&g2);
            return;
        }
        if b == 1 && tool == T_WIRE && dx.abs() < 3.0 && dy.abs() < 3.0 {
            { let mut ui = g2.ui.borrow_mut(); let p = ui.wire_pt(x0, y0); if ui.wpts.last() != Some(&p) { ui.wpts.push(p); } }
            w(&g2).lay.queue_draw();
            return;
        }
        if b == 1 && tool == T_VIA && dx.abs() < 3.0 && dy.abs() < 3.0 {
            let cmd = {
                let ui = g2.ui.borrow();
                let h = pick(&ui, x0, y0);
                let net = hit_net(&ui, &h).or_else(|| ui.opt.get("wn").cloned()).unwrap_or_default();
                let p = ui.wire_pt(x0, y0);
                (net.clone(), format!("add_via -net {} -at {{{} {}}} -from {} -to {}", net, f2(p.0), f2(p.1), ui.opt.get("wl").cloned().unwrap_or_else(|| "M1".into()), ui.opt.get("wl2").cloned().unwrap_or_else(|| "M2".into())))
            };
            if cmd.0.trim().is_empty() { log_out(&g2, "Via: set the net first (click one of its wires)."); return; }
            let g3 = g2.clone();
            glib::idle_add_local_once(move || run_cmd(&g3, &cmd.1));
            return;
        }
        if b == 1 && (tool == T_DEL || tool == T_PGW) && dx.abs() > 2.0 && dy.abs() > 2.0 {
            let cmd = { let ui = g2.ui.borrow(); let (wx0, wy0) = ui.s2w(x0, y0); let (wx1, wy1) = ui.s2w(x0 + dx, y0 + dy); mkcmd(&ui, (wx0.min(wx1), wy0.min(wy1), wx0.max(wx1), wy0.max(wy1))) };
            if cmd.contains("-net ?") { log_out(&g2, "Delete wires: set the net first (click one of its wires)."); return; }
            let g3 = g2.clone();
            glib::idle_add_local_once(move || run_cmd(&g3, &cmd));
            return;
        }
        if b == 3 {
            // right-button rubber band: zoom to the drawn box
            if dx.abs() > 4.0 && dy.abs() > 4.0 {
                let mut ui = g2.ui.borrow_mut();
                let (wx0, wy0) = ui.s2w(x0, y0);
                let (wx1, wy1) = ui.s2w(x0 + dx, y0 + dy);
                ui.zoom_rect((wx0.min(wx1), wy0.min(wy1), wx0.max(wx1), wy0.max(wy1)));
            }
            w(&g2).lay.queue_draw();
            return;
        }
        if tool > 0 && b == 1 && dx.abs() > 4.0 && dy.abs() > 4.0 {
            let cmd = { let ui = g2.ui.borrow(); let (wx0, wy0) = ui.s2w(x0, y0); let (wx1, wy1) = ui.s2w(x0 + dx, y0 + dy); mkcmd(&ui, (wx0.min(wx1), wy0.min(wy1), wx0.max(wx1), wy0.max(wy1))) };
            let e = &w(&g2).entry;
            e.set_text(&cmd);
            e.grab_focus();
            e.set_position(-1);
        } else if tool == 0 && b == 1 && !g2.ui.borrow().drag_pan && (dx.abs() > 4.0 || dy.abs() > 4.0) {
            // left drag: select the instances / ports inside the box (Shift adds)
            let r = { let ui = g2.ui.borrow(); let (wx0, wy0) = ui.s2w(x0, y0); let (wx1, wy1) = ui.s2w(x0 + dx, y0 + dy); (wx0.min(wx1), wy0.min(wy1), wx0.max(wx1), wy0.max(wy1)) };
            select_box(&g2, r, if shift { 1 } else { 0 });
        } else if dx.abs() < 3.0 && dy.abs() < 3.0 && b == 1 {
            layout_click(&g2, x0, y0, shift, tool);
        }
        w(&g2).lay.queue_draw();
    });
    lay.add_controller(drag);
    let key = gtk::EventControllerKey::new();
    let g2 = g.clone();
    key.connect_key_pressed(move |_, k, _, mods| {
        let ctrl = mods.contains(gdk::ModifierType::CONTROL_MASK);
        if ctrl && (k == gdk::Key::d || k == gdk::Key::D) {
            // ^D: deselect all (GUI pick, session selection, flyline cells)
            { let mut ui = g2.ui.borrow_mut(); ui.sel = None; ui.sel_rect = None; ui.sch_msel.clear(); ui.sel_ports.clear(); ui.sel_pins.clear(); ui.pin_marks.clear(); ui.qlist.clear(); ui.last_hit = None; }
            w(&g2).info.set_text("Nothing selected.");
            let g3 = g2.clone();
            glib::idle_add_local_once(move || run_cmd(&g3, "gui_deselect_all"));
            return glib::Propagation::Stop;
        }
        if ctrl && (k == gdk::Key::t || k == gdk::Key::T) {
            // ^T: zoom to the selection, centred
            let ok = g2.ui.borrow_mut().zoom_sel();
            if !ok { w(&g2).status.set_text("Zoom selection: nothing selected"); }
            w(&g2).lay.queue_draw();
            return glib::Propagation::Stop;
        }
        if ctrl { return glib::Propagation::Proceed; }
        if g2.ui.borrow().tool == T_WIRE {
            match k {
                gdk::Key::Return | gdk::Key::KP_Enter => { finish_wire(&g2); return glib::Propagation::Stop; }
                gdk::Key::BackSpace => { g2.ui.borrow_mut().wpts.pop(); w(&g2).lay.queue_draw(); return glib::Propagation::Stop; }
                gdk::Key::Escape => { g2.ui.borrow_mut().wpts.clear(); w(&g2).lay.queue_draw(); return glib::Propagation::Stop; }
                _ => {}
            }
        }
        if k == gdk::Key::k {
            // k: ruler tool
            if let Some(b) = w(&g2).tools.get(T_RULER) { b.set_active(true); }
            return glib::Propagation::Stop;
        }
        if k == gdk::Key::K {
            g2.ui.borrow_mut().rstart = None;
            let g3 = g2.clone();
            glib::idle_add_local_once(move || run_cmd(&g3, "gui_clear_rulers"));
            return glib::Propagation::Stop;
        }
        if k == gdk::Key::q || k == gdk::Key::Q {
            // Q: properties of the selected objects in the QUERY pane (paginated)
            query_selection(&g2);
            return glib::Propagation::Stop;
        }
        if matches!(k, gdk::Key::Page_Down | gdk::Key::bracketright) { qstep(&g2, 1); return glib::Propagation::Stop; }
        if matches!(k, gdk::Key::Page_Up | gdk::Key::bracketleft) { qstep(&g2, -1); return glib::Propagation::Stop; }
        if k == gdk::Key::Escape && g2.ui.borrow().rstart.is_some() {
            g2.ui.borrow_mut().rstart = None;
            w(&g2).lay.queue_draw();
            return glib::Propagation::Stop;
        }
        if k == gdk::Key::n || k == gdk::Key::N {
            // n / N: next / previous marker
            goto_marker(&g2, if k == gdk::Key::n { 1 } else { -1 });
            return glib::Propagation::Stop;
        }
        let mut ui = g2.ui.borrow_mut();
        let (cx, cy) = (ui.size.0 / 2.0, ui.size.1 / 2.0);
        match k {
            gdk::Key::z => ui.zoom(2.0, cx, cy),   // Z: zoom in one level
            gdk::Key::Z => ui.zoom(0.5, cx, cy),   // Shift+Z: zoom out one level
            gdk::Key::f | gdk::Key::F => ui.fit(),
            gdk::Key::plus | gdk::Key::equal | gdk::Key::KP_Add => ui.zoom(1.25, cx, cy),
            gdk::Key::minus | gdk::Key::KP_Subtract => ui.zoom(0.8, cx, cy),
            gdk::Key::Left => ui.view.ox += 60.0,
            gdk::Key::Right => ui.view.ox -= 60.0,
            gdk::Key::Up => ui.view.oy -= 60.0,
            gdk::Key::Down => ui.view.oy += 60.0,
            gdk::Key::Escape => {
                ui.drag = None; ui.mk_i = None;
                drop(ui);
                apply_selection(&g2, vec![], 0, false);
                return glib::Propagation::Stop;
            }
            _ => return glib::Propagation::Proceed,
        }
        drop(ui);
        w(&g2).lay.queue_draw();
        glib::Propagation::Stop
    });
    lay.add_controller(key);
    // ---- schematic interaction (same keys and mouse as the layout)
    let sdrag = gtk::GestureDrag::new();
    sdrag.set_button(0);
    let g2 = g.clone();
    sdrag.connect_drag_begin(move |gd, x, y| {
        let b = gd.current_button();
        let mut ui = g2.ui.borrow_mut();
        let v = ui.sview.clone();
        if b == 3 { ui.sband = Some((x, y, x, y)); } else { ui.sdrag = Some((x, y, v)); }
        drop(ui);
        w(&g2).sch.grab_focus();
    });
    let g2 = g.clone();
    sdrag.connect_drag_update(move |_, dx, dy| {
        let mut ui = g2.ui.borrow_mut();
        if let Some(b) = ui.sband.as_mut() { b.2 = b.0 + dx; b.3 = b.1 + dy; }
        else if let Some((_, _, v)) = ui.sdrag.clone() { ui.sview.ox = v.ox + dx; ui.sview.oy = v.oy + dy; }
        drop(ui);
        w(&g2).sch.queue_draw();
    });
    let g2 = g.clone();
    sdrag.connect_drag_end(move |_, dx, dy| {
        let band = g2.ui.borrow_mut().sband.take();
        if let Some((x0, y0, _, _)) = band {
            // right-button rubber band: zoom to the box
            if dx.abs() > 4.0 && dy.abs() > 4.0 {
                let mut ui = g2.ui.borrow_mut();
                let (s0, ox, oy) = (ui.sview.s, ui.sview.ox, ui.sview.oy);
                let r = (((x0.min(x0 + dx)) - ox) / s0, ((y0.min(y0 + dy)) - oy) / s0, ((x0.max(x0 + dx)) - ox) / s0, ((y0.max(y0 + dy)) - oy) / s0);
                sch_zoom_rect(&mut ui, r);
            }
            w(&g2).sch.queue_draw();
            return;
        }
        let d = g2.ui.borrow_mut().sdrag.take();
        if let Some((x, y, _)) = d {
            if dx.abs() < 3.0 && dy.abs() < 3.0 {
                let pin = sch_pick_pin(&g2.ui.borrow(), x, y);
                let n = if pin.is_some() { None } else { sch_pick(&g2.ui.borrow(), x, y) };
                if let Some((c, p, net)) = pin {
                    if p.is_empty() { show_query(&g2, "port", &c); } else { show_query(&g2, "pin", &format!("{}/{}", c, p)); }
                    {
                        let mut ui = g2.ui.borrow_mut();
                        ui.sch_hl_net = net.clone();
                        ui.hl_net = net.clone();
                        if !p.is_empty() { ui.sch_sel = Some(c.clone()); ui.sel = Some(c.clone()); }
                    }
                    w(&g2).info.set_markup(&format!("<b>{}{}{}</b>\nnet {}\ndouble-click: trace {} level(s){} (net highlighted in the layout)", glib::markup_escape_text(&c), if p.is_empty() { "" } else { "/" }, glib::markup_escape_text(&p),
                        glib::markup_escape_text(net.as_deref().unwrap_or("(unconnected)")), w(&g2).schtrace.value() as i64, if w(&g2).schend.is_active() { " / to the endpoints" } else { "" }));
                } else {
                    {
                        let mut ui = g2.ui.borrow_mut();
                        ui.sch_sel = n.clone();
                        ui.sch_hl_net = None;
                        // schematic selection selects the same instance in the layout
                        ui.sel = n.clone();
                        ui.sel_rect = None;
                    }
                    if let Some(n) = &n {
                        // the same selection as a layout click (flylines, Q pages), properties shown right away
                        apply_selection(&g2, vec![format!("cell::{}", n)], 0, true);
                    }
                    if let Some(n) = n {
                        let st = &g2.ui.borrow().st;
                        let placed = st.get("cells").arr().iter().any(|c| c.at(0).s() == n);
                        if let Some(c) = st.get("sch").get("cells").arr().iter().find(|c| c.at(0).s() == n) {
                            w(&g2).info.set_markup(&format!("<b>{}</b>\ncell {} ({}){}\ninputs {}\noutputs {}\n{}\ndouble-click: re-centre · double-click a pin: trace", glib::markup_escape_text(&n), c.at(2).s(), c.at(1).s(),
                                if c.at(5).i() != 0 { " · sequential" } else { "" }, c.at(3).arr().iter().map(|x| x.s()).collect::<Vec<_>>().join(" "), c.at(4).arr().iter().map(|x| x.s()).collect::<Vec<_>>().join(" "),
                                if placed { "selected in the layout (^T there zooms to it)" } else { "not placed: no layout object" }));
                        }
                    }
                }
                w(&g2).sch.queue_draw();
                w(&g2).lay.queue_draw();
            }
        }
    });
    sch.add_controller(sdrag);
    let sclick = gtk::GestureClick::new();
    let g2 = g.clone();
    sclick.connect_pressed(move |_, n, x, y| {
        if n == 2 {
            let pin = sch_pick_pin(&g2.ui.borrow(), x, y);
            if let Some((c, p, _)) = pin {
                let lv = w(&g2).schtrace.value() as i64;
                let end = w(&g2).schend.is_active();
                let pn = if p.is_empty() { c } else { format!("{}/{}", c, p) };
                let g3 = g2.clone();
                glib::idle_add_local_once(move || run_cmd(&g3, &format!("gui_trace_schematic -pin {{{}}} -levels {}{}", pn, lv, if end { " -to_endpoint" } else { "" })));
            } else if let Some(c) = sch_pick(&g2.ui.borrow(), x, y) {
                w(&g2).schcells.set_text(&c);
                let d = w(&g2).schdepth.value() as i64;
                let g3 = g2.clone();
                glib::idle_add_local_once(move || run_cmd(&g3, &format!("gui_show_schematic -cells {{{}}} -depth {}", c, d)));
            }
        }
    });
    sch.add_controller(sclick);
    let skey = gtk::EventControllerKey::new();
    let g2 = g.clone();
    skey.connect_key_pressed(move |_, k, _, mods| {
        let ctrl = mods.contains(gdk::ModifierType::CONTROL_MASK);
        let mut ui = g2.ui.borrow_mut();
        let (cx, cy) = (ui.ssize.0 / 2.0, ui.ssize.1 / 2.0);
        if ctrl && (k == gdk::Key::d || k == gdk::Key::D) {
            ui.sch_sel = None; ui.sch_hl_net = None; ui.sel = None; ui.hl_net = None;
            drop(ui);
            w(&g2).info.set_text("Nothing selected.");
            w(&g2).sch.queue_draw(); w(&g2).lay.queue_draw();
            return glib::Propagation::Stop;
        }
        if ctrl && (k == gdk::Key::t || k == gdk::Key::T) {
            let r = ui.sch.as_ref().and_then(|g| ui.sch_sel.as_ref().and_then(|s| g.n.iter().find(|c| &c.name == s)).map(|c| (c.x, c.y, c.x + c.w, c.y + c.h)));
            match r {
                Some(r) => { let (cx, cy) = ((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0); let z = ((r.2 - r.0).max(r.3 - r.1) * 4.0).max(160.0); sch_zoom_rect(&mut ui, (cx - z / 2.0, cy - z / 2.0, cx + z / 2.0, cy + z / 2.0)); }
                None => { drop(ui); w(&g2).status.set_text("Zoom selection: nothing selected in the schematic"); return glib::Propagation::Stop; }
            }
            drop(ui);
            w(&g2).sch.queue_draw();
            return glib::Propagation::Stop;
        }
        if ctrl { return glib::Propagation::Proceed; }
        match k {
            gdk::Key::z => sch_zoom(&mut ui, 2.0, cx, cy),
            gdk::Key::Z => sch_zoom(&mut ui, 0.5, cx, cy),
            gdk::Key::f | gdk::Key::F => sch_fit(&mut ui),
            gdk::Key::plus | gdk::Key::equal | gdk::Key::KP_Add => sch_zoom(&mut ui, 1.25, cx, cy),
            gdk::Key::minus | gdk::Key::KP_Subtract => sch_zoom(&mut ui, 0.8, cx, cy),
            gdk::Key::Left => ui.sview.ox += 60.0,
            gdk::Key::Right => ui.sview.ox -= 60.0,
            gdk::Key::Up => ui.sview.oy += 60.0,
            gdk::Key::Down => ui.sview.oy -= 60.0,
            gdk::Key::Escape => { ui.sch_sel = None; ui.sch_hl_net = None; ui.sband = None; }
            _ => return glib::Propagation::Proceed,
        }
        drop(ui);
        w(&g2).sch.queue_draw();
        glib::Propagation::Stop
    });
    sch.add_controller(skey);
    let g2 = g.clone();
    schpins.connect_toggled(move |c| { g2.ui.borrow_mut().sch_pins = c.is_active(); w(&g2).sch.queue_draw(); });
    let g2 = g.clone();
    bsclr.connect_clicked(move |_| { let c = w(&g2).schcells.text().to_string(); let d = w(&g2).schdepth.value() as i64; run_cmd(&g2, &format!("gui_show_schematic{} -depth {}", if c.trim().is_empty() { String::new() } else { format!(" -cells {{{}}}", c.trim()) }, d)); });
    // ---- markers panel
    let g2 = g.clone();
    bmprev.connect_clicked(move |_| goto_marker(&g2, -1));
    let g2 = g.clone();
    bmnext.connect_clicked(move |_| goto_marker(&g2, 1));
    let g2 = g.clone();
    bmclr.connect_clicked(move |_| { g2.ui.borrow_mut().mk_i = None; run_cmd(&g2, "delete_markers"); });
    let g2 = g.clone();
    bmdrc.connect_clicked(move |_| { g2.ui.borrow_mut().mk_i = None; run_cmd(&g2, "check_drc"); });
    let g2 = g.clone();
    bmlvs.connect_clicked(move |_| { g2.ui.borrow_mut().mk_i = None; run_cmd(&g2, "check_lvs -shorts -connectivity"); });
    let g2 = g.clone();
    bmvia.connect_clicked(move |_| { g2.ui.borrow_mut().mk_i = None; run_cmd(&g2, "check_missing_vias"); });
    let g2 = g.clone();
    let calib = Rc::new(move || {
        let design = g2.ui.borrow().st.get("design").s().to_string();
        save_dialog(&g2, &format!("{}_markers.rdb", design), move |g3, p| run_cmd(g3, &format!("write_markers -format calibre -output {{{}}}", p)));
    });
    let c2 = calib.clone();
    bmcal.connect_clicked(move |_| c2());
    // ---- Route menu
    let item = |bx: &gtk::Box, pop: &gtk::Popover, label: &str, f: Rc<dyn Fn()>| {
        let b = gtk::Button::with_label(label);
        b.set_has_frame(false);
        if let Some(l) = b.child().and_then(|c| c.downcast::<gtk::Label>().ok()) { l.set_xalign(0.0); }
        let p = pop.clone();
        b.connect_clicked(move |_| { p.popdown(); f(); });
        bx.append(&b);
    };
    let run = |cmd: &'static str| -> Rc<dyn Fn()> { let g2 = g.clone(); Rc::new(move || { g2.ui.borrow_mut().mk_i = None; run_cmd(&g2, cmd) }) };
    let tmpl = |cmd: &'static str| -> Rc<dyn Fn()> { let g2 = g.clone(); Rc::new(move || { let e = &w(&g2).entry; e.set_text(cmd); e.grab_focus(); e.set_position(-1); }) };
    let tool_sel = |t: usize| -> Rc<dyn Fn()> { let tb = tbs[t].clone(); Rc::new(move || tb.set_active(true)) };
    item(&broute, &proute, "Check DRC (width / spacing / shorts / NDR)", run("check_drc"));
    item(&broute, &proute, "Check LVS – shorts", run("check_lvs -shorts"));
    item(&broute, &proute, "Check LVS – opens (connectivity)", run("check_lvs -connectivity"));
    item(&broute, &proute, "Check missing PG vias", run("check_missing_vias"));
    item(&broute, &proute, "Next marker  (n)", { let g2 = g.clone(); Rc::new(move || goto_marker(&g2, 1)) });
    item(&broute, &proute, "Clear markers", run("delete_markers"));
    item(&broute, &proute, "Write markers (Calibre RDB)…", calib.clone());
    item(&broute, &proute, "Read markers (Calibre RDB)…", tmpl("read_markers -tool calibre "));
    broute.append(&gtk::Separator::new(gtk::Orientation::Horizontal));
    item(&broute, &proute, "Manual wire / NDR route tool", tool_sel(T_WIRE));
    item(&broute, &proute, "Via tool", tool_sel(T_VIA));
    item(&broute, &proute, "Delete wires tool", tool_sel(T_DEL));
    let g2 = g.clone();
    item(&broute, &proute, "Re-route highlighted net (with NDR)", Rc::new(move || {
        let (n, r) = { let ui = g2.ui.borrow(); (ui.hl_net.clone(), ui.opt.get("wr").cloned().unwrap_or_default()) };
        let Some(n) = n else { log_out(&g2, "Click a wire of the net first (it is highlighted)."); return };
        if !r.is_empty() && r != "(default)" { run_cmd(&g2, &format!("set_route_attributes -nets {{{}}} -route_rule {}", n, r)); }
        run_cmd(&g2, &format!("delete_wire -net {}", n));
        run_cmd(&g2, "route_eco");
    }));
    item(&broute, &proute, "ECO route (opens)", run("route_eco"));
    broute.append(&gtk::Separator::new(gtk::Orientation::Horizontal));
    item(&broute, &proute, "Create NDR rule…", tmpl("create_route_rule -name NDR_2W2S -preset 2w2s"));
    item(&broute, &proute, "Apply NDR to clock nets…", tmpl("set_route_attributes -clock_nets -route_rule NDR_2W2S"));
    let g2 = g.clone();
    item(&broute, &proute, "Apply NDR to highlighted net…", Rc::new(move || {
        let n = g2.ui.borrow().hl_net.clone().unwrap_or_else(|| "net".into());
        let e = &w(&g2).entry; e.set_text(&format!("set_route_attributes -nets {{{}}} -route_rule ", n)); e.grab_focus(); e.set_position(-1);
    }));
    item(&broute, &proute, "Report NDR rules", run("report_route_rules"));
    // ---- Layout menu: ruler / measure, query
    let g2 = g.clone();
    item(&blayout, &playout, "Clock Tree Browser", Rc::new(move || { fill_ctree(&g2); w(&g2).nb.set_current_page(Some(2)); }));
    item(&broute, &proute, "Clock Tree Browser", { let g2 = g.clone(); Rc::new(move || { fill_ctree(&g2); w(&g2).nb.set_current_page(Some(2)); }) });
    blayout.append(&gtk::Separator::new(gtk::Orientation::Horizontal));
    item(&blayout, &playout, "Ruler tool  (K)", tool_sel(T_RULER));
    let g2 = g.clone();
    item(&blayout, &playout, "Ruler: orthogonal, snap to routing grid", Rc::new(move || { { let mut ui = g2.ui.borrow_mut(); ui.opt.insert("ra", "orthogonal".into()); ui.opt.insert("rs", "routing grid".into()); } if let Some(b) = w(&g2).tools.get(T_RULER) { b.set_active(true); } rebuild_toolopts(&g2); }));
    let g2 = g.clone();
    item(&blayout, &playout, "Ruler: any angle / diagonal, manufacturing grid", Rc::new(move || { { let mut ui = g2.ui.borrow_mut(); ui.opt.insert("ra", "any angle".into()); ui.opt.insert("rs", "manufacturing grid (0.005)".into()); } if let Some(b) = w(&g2).tools.get(T_RULER) { b.set_active(true); } rebuild_toolopts(&g2); }));
    let g2 = g.clone();
    item(&blayout, &playout, "Ruler: 45-degree", Rc::new(move || { g2.ui.borrow_mut().opt.insert("ra", "45 degree".into()); if let Some(b) = w(&g2).tools.get(T_RULER) { b.set_active(true); } rebuild_toolopts(&g2); }));
    item(&blayout, &playout, "Measure distance…", tmpl("measure_distance -from {0 0} -to {10 10}"));
    item(&blayout, &playout, "Report rulers", run("report_rulers"));
    item(&blayout, &playout, "Clear rulers  (Shift+K)", run("gui_clear_rulers"));
    blayout.append(&gtk::Separator::new(gtk::Orientation::Horizontal));
    let g2 = g.clone();
    item(&blayout, &playout, "Query selected objects  (Q, PgUp / PgDn pages)", Rc::new(move || query_selection(&g2)));
    item(&blayout, &playout, "Query object by name…", tmpl("gui_query_object -name "));
    let g2 = g.clone();
    item(&blayout, &playout, "Query highlighted net", Rc::new(move || { let n = g2.ui.borrow().hl_net.clone(); match n { Some(n) => { show_query(&g2, "net", &n); } None => w(&g2).status.set_text("Click a wire first") } }));
    let g2 = g.clone();
    item(&blayout, &playout, "Clear query panel", Rc::new(move || { let wd = w(&g2); while wd.qbook.n_pages() > 0 { wd.qbook.remove_page(Some(0)); } wd.qtitle.set_text("Click any object to list its properties."); g2.ui.borrow_mut().queried = None; }));
    blayout.append(&gtk::Separator::new(gtk::Orientation::Horizontal));
    let g2 = g.clone();
    item(&blayout, &playout, "Zoom fit  (F)", Rc::new(move || { g2.ui.borrow_mut().fit(); w(&g2).lay.queue_draw(); }));
    let g2 = g.clone();
    item(&blayout, &playout, "Zoom to selection  (Ctrl+T)", Rc::new(move || { g2.ui.borrow_mut().zoom_sel(); w(&g2).lay.queue_draw(); }));
    // ---- Power menu (templates go to the interpreter line)
    item(&bpower, &ppower, "Global net connect…", tmpl("connect_global_net VDD -type pg_pin -pin_base_name VDD -inst_base_name *"));
    item(&bpower, &ppower, "Core rings…", tmpl("add_rings -nets {VDD VSS} -type core_rings -layer {top M5 bottom M5 left M6 right M6} -width 3 -spacing 1.5 -offset 1.5"));
    item(&bpower, &ppower, "Block rings (macros)…", tmpl("add_rings -nets {VDD VSS} -type block_rings -around each_block -layer {top M5 bottom M5 left M6 right M6} -width 1 -spacing 0.5 -offset 0.4"));
    item(&bpower, &ppower, "Stripes…", tmpl("add_stripes -nets {VDD VSS} -layer M6 -direction vertical -width 2 -spacing 1 -set_to_set_distance 40 -extend_to first_ring"));
    item(&bpower, &ppower, "Followpins (std-cell rails)…", tmpl("create_followpins -nets {VDD VSS} -layer M1 -width 0.24 -extend_to ring"));
    item(&bpower, &ppower, "Connect block pins (sroute)…", tmpl("sroute -connect block_pin -nets {VDD VSS}"));
    item(&bpower, &ppower, "Generate via arrays", run("generate_vias"));
    item(&bpower, &ppower, "PG wire tool", tool_sel(T_PGW));
    item(&bpower, &ppower, "Check missing vias", run("check_missing_vias"));
    item(&bpower, &ppower, "Report power routes", run("report_power_routes"));
    let sscroll = gtk::EventControllerScroll::new(gtk::EventControllerScrollFlags::VERTICAL);
    let smotion = gtk::EventControllerMotion::new();
    let spos = Rc::new(RefCell::new((0.0f64, 0.0f64)));
    let sp2 = spos.clone();
    smotion.connect_motion(move |_, x, y| { *sp2.borrow_mut() = (x, y); });
    sch.add_controller(smotion);
    let g2 = g.clone();
    sscroll.connect_scroll(move |_, _, dy| {
        let (mx, my) = *spos.borrow();
        let mut ui = g2.ui.borrow_mut();
        let f = if dy < 0.0 { 1.15 } else { 1.0 / 1.15 };
        let (wx, wy) = ((mx - ui.sview.ox) / ui.sview.s, (my - ui.sview.oy) / ui.sview.s);
        ui.sview.s *= f;
        ui.sview.ox = mx - wx * ui.sview.s;
        ui.sview.oy = my - wy * ui.sview.s;
        drop(ui);
        w(&g2).sch.queue_draw();
        glib::Propagation::Stop
    });
    sch.add_controller(sscroll);
    let g2 = g.clone();
    let show = move |all: bool, cells: String| {
        let d = w(&g2).schdepth.value() as i64;
        let c = format!("gui_show_schematic{}{} -depth {}", if all { " -all" } else { "" }, if cells.trim().is_empty() { String::new() } else { format!(" -cells {{{}}}", cells.trim()) }, d);
        run_cmd(&g2, &c);
    };
    let show = Rc::new(show);
    let (s1, e1) = (show.clone(), schcells.clone());
    bshow.connect_clicked(move |_| s1(false, e1.text().to_string()));
    let (s1, e1) = (show.clone(), schcells.clone());
    schcells.connect_activate(move |_| s1(false, e1.text().to_string()));
    let s1 = show.clone();
    ball.connect_clicked(move |_| s1(true, String::new()));
    let (s1, g2) = (show.clone(), g.clone());
    bsel.connect_clicked(move |_| {
        let v = { let ui = g2.ui.borrow(); ui.sel.clone().or_else(|| ui.st.get("sel").at(0).s().to_string().into()).filter(|s| !s.is_empty()).or_else(|| { let m: Vec<String> = ui.st.get("fly").get("macros").arr().iter().map(|x| x.s().to_string()).collect(); if m.is_empty() { None } else { Some(m.join(" ")) } }) };
        match v { Some(v) => { w(&g2).schcells.set_text(&v); s1(false, v) } None => log_out(&g2, "Click a cell in the layout first.") }
    });
    let g2 = g.clone();
    bsfit.connect_clicked(move |_| { sch_fit(&mut g2.ui.borrow_mut()); w(&g2).sch.queue_draw(); });
    // ---- flylines panel
    let opt = { let (fcol, fm2m, fex, fmf) = (fcol.clone(), fm2m.clone(), fex.clone(), fmf.clone()); Rc::new(move || format!(" -color_by {} {} -exclude_nets {{{}}} -max_fanout {}", if fcol.selected() == 1 { "macro" } else { "net" }, if fm2m.is_active() { "-macro_to_macro" } else { "-all_connections" }, fex.text().trim(), { let t = fmf.text(); if t.trim().is_empty() { "0".to_string() } else { t.trim().to_string() } })) };
    let (g2, o) = (g.clone(), opt.clone());
    bfa.connect_clicked(move |_| run_cmd(&g2, &format!("gui_show_flylines -all_macros{}", o())));
    let (g2, o) = (g.clone(), opt.clone());
    bfs.connect_clicked(move |_| run_cmd(&g2, &format!("gui_show_flylines -all_std_cells{}", o())));
    let g2 = g.clone();
    bfc.connect_clicked(move |_| run_cmd(&g2, "gui_show_flylines -clear"));
    let g2 = g.clone();
    flyclick.connect_toggled(move |c| g2.ui.borrow_mut().fly_click = c.is_active());
    let (g2, o) = (g.clone(), opt.clone());
    fcol.connect_selected_notify(move |_| { if !g2.ui.borrow().st.get("fly").is_null() { let g3 = g2.clone(); let o3 = o.clone(); glib::idle_add_local_once(move || run_cmd(&g3, &format!("gui_show_flylines{}", o3()))); } });
    let (g2, o) = (g.clone(), opt.clone());
    fm2m.connect_toggled(move |_| { if !g2.ui.borrow().st.get("fly").is_null() { run_cmd(&g2, &format!("gui_show_flylines{}", o())); } });
    for e in [&fex, &fmf] { let (g2, o) = (g.clone(), opt.clone()); e.connect_activate(move |_| run_cmd(&g2, &format!("gui_show_flylines{}", o()))); }
    // ---- tools
    for (i, b) in tbs.iter().enumerate() {
        let g2 = g.clone();
        b.connect_toggled(move |b| { if b.is_active() { g2.ui.borrow_mut().tool = i; rebuild_toolopts(&g2); } });
    }
    // ---- header buttons
    let g2 = g.clone();
    bfit.connect_clicked(move |_| { if w(&g2).nb.current_page() == Some(1) { sch_fit(&mut g2.ui.borrow_mut()); w(&g2).sch.queue_draw(); } else { g2.ui.borrow_mut().fit(); w(&g2).lay.queue_draw(); } });
    let g2 = g.clone();
    bzi.connect_clicked(move |_| { { let mut ui = g2.ui.borrow_mut(); let (cx, cy) = (ui.size.0 / 2.0, ui.size.1 / 2.0); ui.zoom(1.25, cx, cy); } w(&g2).lay.queue_draw(); });
    let g2 = g.clone();
    bzo.connect_clicked(move |_| { { let mut ui = g2.ui.borrow_mut(); let (cx, cy) = (ui.size.0 / 2.0, ui.size.1 / 2.0); ui.zoom(0.8, cx, cy); } w(&g2).lay.queue_draw(); });
    let g2 = g.clone();
    bclose.connect_clicked(move |_| w(&g2).win.close());
    let g2 = g.clone();
    bpng.connect_clicked(move |_| {
        let sch_tab = w(&g2).nb.current_page() == Some(1);
        let design = g2.ui.borrow().st.get("design").s().to_string();
        save_dialog(&g2, &format!("{}_{}.png", design, if sch_tab { "schematic" } else { "layout" }), move |g3, p| {
            let r = if sch_tab { write_sch_image(&g3.ui.borrow(), &p) } else { write_layout_png(&g3.ui.borrow(), &p) };
            log_out(g3, &match r { Ok(_) => format!("Saved {}", p), Err(e) => format!("Error: {}", e) });
        });
    });
    let g2 = g.clone();
    bscr.connect_clicked(move |_| {
        save_dialog(&g2, "gui_edits.tcl", move |g3, p| {
            let t = g3.ui.borrow().script.join("\n") + "\n";
            log_out(g3, &match std::fs::write(&p, t) { Ok(_) => format!("Saved {}", p), Err(e) => format!("Error: {}", e) });
        });
    });
    let g2 = g.clone();
    bsvg.connect_clicked(move |_| {
        let design = g2.ui.borrow().st.get("design").s().to_string();
        save_dialog(&g2, &format!("{}_schematic.svg", design), move |g3, p| {
            log_out(g3, &match write_sch_image(&g3.ui.borrow(), &p) { Ok(_) => format!("Saved {}", p), Err(e) => format!("Error: {}", e) });
        });
    });
    // ---- interpreter
    let g2 = g.clone();
    entry.connect_activate(move |e| { let t = e.text().to_string(); e.set_text(""); run_cmd(&g2, &t); });
    let (g2, e2) = (g.clone(), entry.clone());
    brun.connect_clicked(move |_| { let t = e2.text().to_string(); e2.set_text(""); run_cmd(&g2, &t); });
    let ek = gtk::EventControllerKey::new();
    ek.set_propagation_phase(gtk::PropagationPhase::Capture);
    let (g2, e2) = (g.clone(), entry.clone());
    let last_tab = Rc::new(RefCell::new(false));
    let kill2: Rc<RefCell<String>> = Rc::new(RefCell::new(String::new()));
    ek.connect_key_pressed(move |_, k, _, st| {
        let was = std::mem::replace(&mut *last_tab.borrow_mut(), k == gdk::Key::Tab);
        match k {
            gdk::Key::Tab => { complete_entry(&g2, &e2, was); glib::Propagation::Stop }
            gdk::Key::Up | gdk::Key::Down => {
                let mut ui = g2.ui.borrow_mut();
                if k == gdk::Key::Up && ui.hpos > 0 { ui.hpos -= 1; } else if k == gdk::Key::Down && ui.hpos < ui.hist.len() { ui.hpos += 1; }
                let t = ui.hist.get(ui.hpos).cloned().unwrap_or_default();
                drop(ui);
                e2.set_text(&t);
                e2.set_position(-1);
                glib::Propagation::Stop
            }
            // Emacs line keys, as in the terminal shell
            gdk::Key::a if st.contains(gdk::ModifierType::CONTROL_MASK) => { e2.set_position(0); glib::Propagation::Stop }
            gdk::Key::e if st.contains(gdk::ModifierType::CONTROL_MASK) => { e2.set_position(-1); glib::Propagation::Stop }
            gdk::Key::k if st.contains(gdk::ModifierType::CONTROL_MASK) => { let p = e2.position(); *kill2.borrow_mut() = e2.text().chars().skip(p.max(0) as usize).collect(); e2.delete_text(p, -1); glib::Propagation::Stop }
            gdk::Key::u if st.contains(gdk::ModifierType::CONTROL_MASK) => { let p = e2.position(); *kill2.borrow_mut() = e2.text().chars().take(p.max(0) as usize).collect(); e2.delete_text(0, p); e2.set_position(0); glib::Propagation::Stop }
            gdk::Key::l if st.contains(gdk::ModifierType::CONTROL_MASK) => { w(&g2).tv.buffer().set_text(""); glib::Propagation::Stop }
            gdk::Key::d if st.contains(gdk::ModifierType::CONTROL_MASK) => { let p = e2.position(); if p < e2.text_length() as i32 { e2.delete_text(p, p + 1); } glib::Propagation::Stop }
            gdk::Key::b if st.contains(gdk::ModifierType::CONTROL_MASK) => { let p = e2.position(); e2.set_position((p - 1).max(0)); glib::Propagation::Stop }
            gdk::Key::f if st.contains(gdk::ModifierType::CONTROL_MASK) => { let p = e2.position(); e2.set_position((p + 1).min(e2.text_length() as i32)); glib::Propagation::Stop }
            gdk::Key::h if st.contains(gdk::ModifierType::CONTROL_MASK) => { let p = e2.position(); if p > 0 { e2.delete_text(p - 1, p); } glib::Propagation::Stop }
            gdk::Key::w if st.contains(gdk::ModifierType::CONTROL_MASK) => {
                let t: Vec<char> = e2.text().chars().collect();
                let p = (e2.position().max(0) as usize).min(t.len());
                let mut s0 = p;
                while s0 > 0 && t[s0 - 1] == ' ' { s0 -= 1; }
                while s0 > 0 && t[s0 - 1] != ' ' { s0 -= 1; }
                *kill2.borrow_mut() = t[s0..p].iter().collect();
                e2.delete_text(s0 as i32, p as i32);
                glib::Propagation::Stop
            }
            gdk::Key::y if st.contains(gdk::ModifierType::CONTROL_MASK) => { let k = kill2.borrow().clone(); let mut p = e2.position(); e2.insert_text(&k, &mut p); e2.set_position(p); glib::Propagation::Stop }
            gdk::Key::t if st.contains(gdk::ModifierType::CONTROL_MASK) => {
                let mut t: Vec<char> = e2.text().chars().collect();
                let p = e2.position().max(0) as usize;
                if t.len() >= 2 && p > 0 { let c = if p >= t.len() { t.len() - 1 } else { p }; t.swap(c - 1, c); e2.set_text(&t.iter().collect::<String>()); e2.set_position((c + 1).min(t.len()) as i32); }
                glib::Propagation::Stop
            }
            _ => glib::Propagation::Proceed,
        }
    });
    entry.add_controller(ek);
    let g2 = g.clone();
    win.connect_close_request(move |_| { g2.app.quit(); glib::Propagation::Proceed });

    rebuild_toolopts(&g);
    refresh(&g);
    win.present();
    entry.grab_focus();

    // automated screenshots (testing / documentation): RSYNTH_GTK_SCREENSHOT=prefix
    if let Ok(prefix) = std::env::var("RSYNTH_GTK_SCREENSHOT") {
        let g2 = g.clone();
        glib::timeout_add_local_once(std::time::Duration::from_millis(1200), move || {
            snap_window(&g2, &format!("{}_layout.png", prefix));
            let _ = write_layout_png(&g2.ui.borrow(), &format!("{}_layout_view.png", prefix));
            w(&g2).nb.set_current_page(Some(1));
            let g3 = g2.clone();
            glib::timeout_add_local_once(std::time::Duration::from_millis(900), move || {
                snap_window(&g3, &format!("{}_schematic.png", prefix));
                if std::env::var("RSYNTH_GTK_CLOCKTREE").is_ok() {
                    fill_ctree(&g3);
                    w(&g3).nb.set_current_page(Some(2));
                    let g6 = g3.clone();
                    let pf = prefix.clone();
                    glib::timeout_add_local_once(std::time::Duration::from_millis(500), move || snap_window(&g6, &format!("{}_clocktree.png", pf)));
                }
                if let Ok(cmds) = std::env::var("RSYNTH_GTK_CMDS") { for c in cmds.split(';') { run_cmd(&g3, c); } }
                // scripted interaction in world coordinates (testing): click / shiftclick / box / key
                if let Ok(acts) = std::env::var("RSYNTH_GTK_ACTIONS") {
                    for a in acts.split(';') {
                        let (k, v) = a.split_once(':').unwrap_or((a, ""));
                        let n: Vec<f64> = v.split(',').filter_map(|x| x.trim().parse().ok()).collect();
                        match k {
                            "click" | "shiftclick" if n.len() >= 2 => { let (sx, sy) = g3.ui.borrow().w2s(n[0], n[1]); layout_click(&g3, sx, sy, k == "shiftclick", 0); }
                            "box" if n.len() >= 4 => select_box(&g3, (n[0].min(n[2]), n[1].min(n[3]), n[0].max(n[2]), n[1].max(n[3])), 0),
                            "key" => match v { "q" => query_selection(&g3), "next" => qstep(&g3, 1), "prev" => qstep(&g3, -1), _ => {} },
                            "zoom" if n.len() >= 4 => { g3.ui.borrow_mut().zoom_rect((n[0], n[1], n[2], n[3])); }
                            "zoomcell" => {
                                let r = { let ui = g3.ui.borrow(); ui.st.get("cells").arr().iter().find(|c| c.at(0).s() == v).map(|c| { let (x, y, w) = (c.at(1).f(), c.at(2).f(), c.at(8).f().max(c.at(9).f()) * 2.0); (x - w, y - w, x + w, y + w) }) };
                                if let Some(r) = r { g3.ui.borrow_mut().zoom_rect(r); }
                            }
                            "cell" | "shiftcell" | "port" | "shiftport" | "pin" | "shiftpin" => {
                                // click on a named object: its centre (cell / port) or its pin shape
                                let xy = {
                                    let ui = g3.ui.borrow();
                                    match k.trim_start_matches("shift") {
                                        "port" => ui.st.get("ports").arr().iter().find(|p| p.at(0).s() == v).map(|p| (p.at(1).f(), p.at(2).f())),
                                        "pin" => g3.sess.borrow().gui_pin_marks(&[v.rsplit_once('/').map(|x| x.0.to_string()).unwrap_or_default()]).into_iter().find(|m| m.2 == v).map(|m| (m.0, m.1)),
                                        _ => ui.st.get("cells").arr().iter().find(|c| c.at(0).s() == v).map(|c| (c.at(1).f(), c.at(2).f())),
                                    }
                                };
                                match xy {
                                    Some((x, y)) => { let (sx, sy) = g3.ui.borrow().w2s(x, y); layout_click(&g3, sx, sy, k.starts_with("shift"), 0); }
                                    None => println!("GUI_ACTIONS: no object {} {}", k, v),
                                }
                            }
                            _ => {}
                        }
                        if std::env::var("RSYNTH_GTK_ACTIONS_TRACE").is_ok() { println!("GUI_ACTION {} -> selection {:?}", a, g3.sess.borrow().selection); }
                    }
                    let (ql, qp) = { let ui = g3.ui.borrow(); (ui.qlist.len(), ui.qpos) };
                    let fly = g3.ui.borrow().st.get("fly").get("l").arr().len();
                    let schsel = g3.ui.borrow().sch_msel.len();
                    let nsel = g3.sess.borrow().selection.len();
                    println!("GUI_ACTIONS selected {} flylines {} schematic_highlighted {} query_pages {} page {}", nsel, fly, schsel, ql, qp + 1);
                }
                let g4 = g3.clone();
                glib::timeout_add_local_once(std::time::Duration::from_millis(900), move || {
                    w(&g4).nb.set_current_page(Some(0));
                    if std::env::var("RSYNTH_GTK_NEXT_MARKER").is_ok() { goto_marker(&g4, 1); }
                    let g5 = g4.clone();
                    glib::timeout_add_local_once(std::time::Duration::from_millis(700), move || { snap_window(&g5, &format!("{}_after.png", prefix)); w(&g5).win.close(); });
                });
            });
        });
    }
}

// ----------------------------------------------------------------------------------- clock tree browser
const CT_COLS: [&str; 10] = ["Object", "Type", "Cell", "Level", "Latency max", "Latency min", "Transition", "Fanout", "Sinks", "Skew below"];

#[allow(deprecated)]
fn build_ctree_page() -> (gtk::Box, gtk::TreeStore, gtk::TreeView, gtk::DropDown, gtk::CheckButton, gtk::Label, gtk::Button, gtk::Button, gtk::Button) {
    let page = gtk::Box::new(gtk::Orientation::Vertical, 4);
    let bar = gtk::Box::new(gtk::Orientation::Horizontal, 6);
    bar.add_css_class("panel");
    let l = gtk::Label::new(Some("Clock"));
    l.add_css_class("dim");
    let clock = gtk::DropDown::from_strings(&["(all clocks)"]);
    let sinks = gtk::CheckButton::with_label("Show sinks");
    let refresh = gtk::Button::with_label("Refresh");
    let expand = gtk::Button::with_label("Expand all");
    let collapse = gtk::Button::with_label("Collapse");
    let hint = gtk::Label::new(Some("select: highlight in layout / schematic · double-click: zoom to it"));
    hint.add_css_class("dim");
    for x in [l.upcast_ref::<gtk::Widget>(), clock.upcast_ref(), sinks.upcast_ref(), refresh.upcast_ref(), expand.upcast_ref(), collapse.upcast_ref(), hint.upcast_ref()] { bar.append(x); }
    page.append(&bar);
    let sum = gtk::Label::new(Some("Press Refresh to trace the clock trees (latency needs a timed design)."));
    sum.set_xalign(0.0);
    sum.set_wrap(true);
    sum.add_css_class("dim");
    sum.set_margin_start(6);
    page.append(&sum);
    let types = vec![glib::Type::STRING; 12];
    let store = gtk::TreeStore::new(&types);
    let view = gtk::TreeView::with_model(&store);
    view.set_enable_tree_lines(true);
    for (i, t) in CT_COLS.iter().enumerate() {
        let cell = gtk::CellRendererText::new();
        if i >= 3 { cell.set_xalign(1.0); }
        let col = gtk::TreeViewColumn::new();
        col.set_title(t);
        col.pack_start(&cell, true);
        col.add_attribute(&cell, "text", i as i32);
        if i <= 1 { col.add_attribute(&cell, "foreground", 11); }
        col.set_resizable(true);
        col.set_sort_column_id(i as i32);
        view.append_column(&col);
    }
    let sc = gtk::ScrolledWindow::builder().child(&view).vexpand(true).hexpand(true).build();
    page.append(&sc);
    (page, store, view, clock, sinks, sum, refresh, expand, collapse)
}

fn kind_color(k: crate::ctree::Kind) -> &'static str {
    use crate::ctree::Kind as K;
    match k { K::Root => "#ffd700", K::Buf => "#6fa8ff", K::Inv => "#c58cff", K::Delay => "#a0a0a0", K::Icg => "#ff9f40", K::Ls | K::Iso => "#40d0d0", K::Logic => "#ff6060", K::Sink => "#6fd46f", K::Macro => "#e0e060" }
}

/// (re)fill the clock tree browser from the session
#[allow(deprecated)]
fn fill_ctree(g: &Gr) {
    let r = g.sess.borrow().gui_clock_trees();
    let wd = w(g);
    let store = wd.ctstore.clone();
    store.clear();
    let (scen, trees) = match r {
        Ok(v) => v,
        Err(e) => { wd.ctsum.set_text(&format!("Clock trees not available: {}", match e { crate::tcl::Flow::Err(s) => s, _ => String::new() })); return; }
    };
    // clock list for the filter
    let names: Vec<String> = std::iter::once("(all clocks)".to_string()).chain(trees.iter().map(|t| t.clock.clone())).collect();
    let cur = wd.ctclock.selected_item().and_then(|o| o.downcast::<gtk::StringObject>().ok()).map(|s| s.string().to_string()).unwrap_or_default();
    // replace the clock list only when it changed (setting the model re-fires the filter)
    let old: Vec<String> = wd.ctclock.model().and_then(|m| m.downcast::<gtk::StringList>().ok()).map(|m| (0..m.n_items()).filter_map(|i| m.string(i).map(|s| s.to_string())).collect()).unwrap_or_default();
    if old != names {
        let refs: Vec<&str> = names.iter().map(|s| s.as_str()).collect();
        let model = gtk::StringList::new(&refs);
        wd.ctclock.set_model(Some(&model));
        if let Some(i) = names.iter().position(|n| n == &cur) { wd.ctclock.set_selected(i as u32); }
    }
    let pick = names.get(wd.ctclock.selected() as usize).cloned().unwrap_or_default();
    let show_sinks = wd.ctsinks.is_active();
    let f = |v: f64| if v.is_finite() { format!("{:.4}", v) } else { "-".into() };
    let mut sum = vec![format!("Scenario {}", scen)];
    let mut nrows = 0usize;
    for t in trees.iter().filter(|t| pick.is_empty() || pick == "(all clocks)" || pick == t.clock) {
        let (mx, mn, sk) = t.latency();
        let ns = t.sinks().count();
        let ng = t.nodes.iter().filter(|n| n.kind == crate::ctree::Kind::Icg).count();
        let nb = t.cells().count();
        sum.push(format!("{}: {} sinks, {} clock cells ({} ICG), levels {}..{}, latency {:.4}..{:.4}ns, skew {:.4}ns", t.clock, ns, nb, ng, t.min_level(), t.max_level(), mn, mx, sk));
        let top = store.insert_with_values(None, None, &[(0, &t.clock), (1, &format!("clock {:.3}ns", t.period)), (2, &""), (3, &format!("{}..{}", t.min_level(), t.max_level())), (4, &f(mx)), (5, &f(mn)), (6, &""), (7, &""), (8, &ns.to_string()), (9, &f(sk)), (10, &""), (11, &"#ffffff")]);
        nrows += 1;
        // depth-first: children of a node, sinks optionally folded into one row
        let mut stack: Vec<(usize, gtk::TreeIter)> = t.roots.iter().rev().map(|r| (*r, top.clone())).collect();
        while let Some((i, parent)) = stack.pop() {
            if nrows > 60000 { break; }
            let n = &t.nodes[i];
            let inst = if n.kind == crate::ctree::Kind::Root { String::new() } else { n.name.clone() };
            let label = if n.kind.is_leaf() { n.pin.clone() } else { n.name.clone() };
            let it = store.insert_with_values(Some(&parent), None, &[(0, &label), (1, &n.kind.name().to_string()), (2, &n.lib), (3, &n.level.to_string()), (4, &f(n.lat_in[0])), (5, &f(n.lat_in[1])), (6, &f(n.tr_in)), (7, &if n.kind.is_leaf() { String::new() } else { n.fanout.to_string() }),
                (8, &if n.kind.is_leaf() { String::new() } else { n.sinks.to_string() }), (9, &if n.kind.is_leaf() || !n.smax.is_finite() || !n.smin.is_finite() { String::new() } else { f(n.smax - n.smin) }), (10, &inst), (11, &kind_color(n.kind).to_string())]);
            nrows += 1;
            let (leaf, inner): (Vec<usize>, Vec<usize>) = n.children.iter().partition(|c| t.nodes[**c].kind.is_leaf());
            if !leaf.is_empty() && !show_sinks {
                let l: Vec<f64> = leaf.iter().map(|c| t.nodes[*c].lat_in[0]).filter(|x| x.is_finite()).collect();
                let (a, b) = (l.iter().cloned().fold(f64::MAX, f64::min), l.iter().cloned().fold(f64::MIN, f64::max));
                store.insert_with_values(Some(&it), None, &[(0, &format!("{} sink(s)", leaf.len())), (1, &"sinks".to_string()), (2, &""), (3, &""), (4, &if l.is_empty() { "-".into() } else { f(b) }), (5, &if l.is_empty() { "-".into() } else { f(a) }), (6, &""), (7, &""), (8, &leaf.len().to_string()), (9, &if l.is_empty() { String::new() } else { f(b - a) }), (10, &""), (11, &kind_color(crate::ctree::Kind::Sink).to_string())]);
                nrows += 1;
            }
            let shown: Vec<usize> = if show_sinks { n.children.clone() } else { inner };
            for c in shown.into_iter().rev() { stack.push((c, it.clone())); }
        }
    }
    wd.ctsum.set_text(&sum.join("\n"));
    // clocks and their first level expanded
    let view = wd.ctview.clone();
    // clocks, their roots and the first clock cells expanded (three levels)
    fn expand_levels(store: &gtk::TreeStore, view: &gtk::TreeView, parent: Option<&gtk::TreeIter>, depth: usize) {
        if depth == 0 { return; }
        if let Some(it) = store.iter_children(parent) {
            loop {
                view.expand_row(&store.path(&it), false);
                expand_levels(store, view, Some(&it), depth - 1);
                if !store.iter_next(&it) { break; }
            }
        }
    }
    expand_levels(&store, &view, None, 3);
}

#[allow(deprecated)]
fn connect_ctree(g: &Gr, refresh: &gtk::Button, expand: &gtk::Button, collapse: &gtk::Button) {
    let g2 = g.clone();
    refresh.connect_clicked(move |_| fill_ctree(&g2));
    let g2 = g.clone();
    expand.connect_clicked(move |_| w(&g2).ctview.expand_all());
    let g2 = g.clone();
    collapse.connect_clicked(move |_| w(&g2).ctview.collapse_all());
    let g2 = g.clone();
    w(g).ctsinks.connect_toggled(move |_| fill_ctree(&g2));
    let g2 = g.clone();
    w(g).ctclock.connect_selected_notify(move |_| {
        // avoid re-entry while the model is being replaced
        let g3 = g2.clone();
        glib::idle_add_local_once(move || refill_ctree_tree_only(&g3));
    });
    let g2 = g.clone();
    w(g).ctview.selection().connect_changed(move |sel| {
        let Some((model, it)) = sel.selected() else { return };
        let inst: String = model.get_value(&it, 10).get().unwrap_or_default();
        if inst.is_empty() { return; }
        {
            let mut ui = g2.ui.borrow_mut();
            ui.sel = Some(inst.clone());
            ui.sch_sel = Some(inst.clone());
        }
        show_query(&g2, "instance", &inst);
        w(&g2).lay.queue_draw();
        w(&g2).sch.queue_draw();
    });
    let g2 = g.clone();
    w(g).ctview.connect_row_activated(move |tv, path, _| {
        let Some(m) = tv.model() else { return };
        let Some(it) = m.iter(path) else { return };
        let inst: String = m.get_value(&it, 10).get().unwrap_or_default();
        if inst.is_empty() { return; }
        g2.ui.borrow_mut().sel = Some(inst);
        g2.ui.borrow_mut().zoom_sel();
        w(&g2).nb.set_current_page(Some(0));
        w(&g2).lay.queue_draw();
    });
}

/// clock filter changed: rebuild the rows (the clock list stays)
fn refill_ctree_tree_only(g: &Gr) {
    fill_ctree(g);
}

fn save_dialog(g: &Gr, name: &str, f: impl Fn(&Gr, String) + 'static) {
    let d = gtk::FileDialog::builder().title("Save").initial_name(name).build();
    let g2 = g.clone();
    d.save(Some(&w(g).win), None::<&gio::Cancellable>, move |r| {
        if let Ok(file) = r { if let Some(p) = file.path() { f(&g2, p.to_string_lossy().to_string()); } }
    });
}

fn write_layout_png(ui: &Ui, path: &str) -> Result<(), String> {
    let (w, h) = (ui.size.0.max(200.0) as i32, ui.size.1.max(200.0) as i32);
    let surf = cairo::ImageSurface::create(cairo::Format::ARgb32, w, h).map_err(|e| e.to_string())?;
    { let cr = cairo::Context::new(&surf).map_err(|e| e.to_string())?; draw_layout(&cr, ui); }
    let mut f = std::fs::File::create(path).map_err(|e| e.to_string())?;
    surf.write_to_png(&mut f).map_err(|e| e.to_string())
}

/// schematic to SVG (path ends with .svg) or PNG, whole drawing at a readable scale
fn write_sch_image(ui: &Ui, path: &str) -> Result<(), String> {
    let Some(g) = ui.sch.as_ref() else { return Err("no schematic".into()) };
    let (w, h) = (g.width + 60.0, g.max_y + 320.0);
    let mut u2 = Ui::new();
    u2.st = J::Null;
    u2.sch = None;
    let ui2 = Ui { sview: View { s: 1.0, ox: 20.0, oy: 20.0 }, sch_sel: ui.sch_sel.clone(), ..u2 };
    let ui2 = Ui { sch: Some(SchG { n: g.n.clone(), nc: g.nc, nets: g.nets.clone(), col_x: g.col_x.clone(), col_w: g.col_w.clone(), chan: g.chan.clone(), width: g.width, max_y: g.max_y, back_n: g.back_n }), ..ui2 };
    if path.ends_with(".svg") {
        let surf = cairo::SvgSurface::new(w, h, Some(path)).map_err(|e| e.to_string())?;
        let cr = cairo::Context::new(&surf).map_err(|e| e.to_string())?;
        draw_sch(&cr, &ui2, w, h, true);
        surf.finish();
        Ok(())
    } else {
        let sc = (8000.0 / w.max(h)).min(1.5);
        let surf = cairo::ImageSurface::create(cairo::Format::ARgb32, (w * sc) as i32, (h * sc) as i32).map_err(|e| e.to_string())?;
        { let cr = cairo::Context::new(&surf).map_err(|e| e.to_string())?; cr.scale(sc, sc); draw_sch(&cr, &ui2, w, h, true); }
        let mut f = std::fs::File::create(path).map_err(|e| e.to_string())?;
        surf.write_to_png(&mut f).map_err(|e| e.to_string())
    }
}

/// layout image of a GUI state document without opening a window (gui_write_image)
pub fn export_layout(state: &str, path: &str, size: (f64, f64), rect: Option<(f64, f64, f64, f64)>, show: &[String], hide: &[String]) -> Result<(), String> {
    let mut ui = Ui::new();
    for v in ui.vis.iter_mut() { if show.iter().any(|x| x == v.0) { v.2 = true; } if hide.iter().any(|x| x == v.0) { v.2 = false; } }
    ui.st = J::parse(state)?;
    for l in ui.st.get("routes").get("layers").arr() { ui.rvis.insert(l.s().to_string(), true); }
    ui.size = (size.0.clamp(200.0, 16000.0), size.1.clamp(200.0, 16000.0));
    match rect { Some(r) => ui.zoom_rect(r), None => ui.fit() }
    if path.ends_with(".svg") {
        let surf = cairo::SvgSurface::new(ui.size.0, ui.size.1, Some(path)).map_err(|e| e.to_string())?;
        { let cr = cairo::Context::new(&surf).map_err(|e| e.to_string())?; draw_layout(&cr, &ui); }
        surf.finish();
        Ok(())
    } else {
        write_layout_png(&ui, path)
    }
}

/// schematic image (SVG or PNG) of a GUI state document without opening a window (write_schematic)
pub fn export_schematic(state: &str, path: &str) -> Result<(), String> {
    let mut ui = Ui::new();
    ui.st = J::parse(state)?;
    ui.sch = sch_layout(ui.st.get("sch"));
    if ui.sch.is_none() { return Err("empty schematic (no design, or no cells match -cells)".into()); }
    write_sch_image(&ui, path)
}

/// whole-window screenshot through GSK
fn snap_window(g: &Gr, path: &str) {
    let win = &w(g).win;
    let (ww, hh) = (win.width() as f64, win.height() as f64);
    let paintable = gtk::WidgetPaintable::new(Some(win));
    let snap = gtk::Snapshot::new();
    paintable.snapshot(&snap, ww, hh);
    let Some(node) = snap.to_node() else { return };
    let Some(native) = win.native() else { return };
    let Some(renderer) = native.renderer() else { return };
    let tex = renderer.render_texture(&node, None);
    let _ = tex.save_to_png(path);
}

/// run the GTK GUI on the session until the window closes; returns the session
pub fn run(s: Session) -> Session {
    if gtk::init().is_err() {
        crate::error!("GUI-101", "Cannot initialise GTK (no display?); staying in the shell");
        return s;
    }
    let app = gtk::Application::builder().application_id("org.rsynth.gui").flags(gio::ApplicationFlags::NON_UNIQUE).build();
    let g: Gr = Rc::new(G { sess: RefCell::new(s), ui: RefCell::new(Ui::new()), w: OnceCell::new(), app: app.clone() });
    let g2 = g.clone();
    app.connect_activate(move |app| build(app, g2.clone()));
    crate::info!("GUI-102", "GTK GUI opened (close the window or run gui_stop to return)");
    app.run_with_args::<&str>(&[]);
    crate::info!("GUI-103", "GTK GUI closed");
    drop(app);
    let sess = std::mem::take(&mut *g.sess.borrow_mut());
    sess
}

impl Session {
    /// `gtk_gui` / `gui_start -gtk` from the shell
    pub fn gtk_gui_cmd(&mut self) -> crate::tcl::R {
        let me = std::mem::take(self);
        *self = run(me);
        Ok(String::new())
    }
}
