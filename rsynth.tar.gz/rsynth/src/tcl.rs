//! Embedded Tcl-subset interpreter (the tool shell language).
//! Supports: substitution ($var, ${var}, [cmd], backslashes, {*}), braces/quotes,
//! procs with default args/args, global, control flow, expr with functions,
//! lists, strings, format, catch, source, redirect via host commands.

use std::collections::HashMap;

pub enum Flow {
    Err(String),
    Break,
    Continue,
    Return(String),
}
pub type R = Result<String, Flow>;
pub fn err<T>(s: impl Into<String>) -> Result<T, Flow> {
    Err(Flow::Err(s.into()))
}

#[derive(Default)]
pub struct Frame {
    vars: HashMap<String, String>,
    globals: Vec<String>,
}

impl Interp {
    /// variable names visible at the current level (locals + globals), for completion
    pub fn var_names(&self) -> Vec<String> {
        let mut v: Vec<String> = self.frames.last().map(|f| f.vars.keys().cloned().collect()).unwrap_or_default();
        if let Some(g) = self.frames.first() { v.extend(g.vars.keys().cloned()); }
        v.sort();
        v.dedup();
        v
    }
}

pub struct Interp {
    pub frames: Vec<Frame>,
    pub procs: HashMap<String, (Vec<(String, Option<String>)>, String)>,
    pub cmd_depth: usize,
    /// open file channels (open / puts / gets / read / eof / close)
    pub chans: HashMap<String, Chan>,
    pub next_chan: usize,
}

#[derive(Default)]
pub struct Chan {
    pub path: String,
    pub write: bool,
    pub out: String,
    pub data: String,
    pub pos: usize,
}

impl Default for Interp {
    fn default() -> Self {
        Interp { frames: vec![Frame::default()], procs: HashMap::new(), cmd_depth: 0, chans: HashMap::new(), next_chan: 1 }
    }
}

impl Interp {
    pub fn get(&self, n: &str) -> Option<String> {
        let f = self.frames.last().unwrap();
        if self.frames.len() > 1 && !f.globals.iter().any(|g| g == n) {
            return f.vars.get(n).cloned();
        }
        if self.frames.len() > 1 {
            return self.frames[0].vars.get(n).cloned();
        }
        f.vars.get(n).cloned()
    }
    pub fn set(&mut self, n: &str, v: &str) {
        let nf = self.frames.len();
        let is_g = nf > 1 && self.frames[nf - 1].globals.iter().any(|g| g == n);
        let f = if is_g { &mut self.frames[0] } else { self.frames.last_mut().unwrap() };
        f.vars.insert(n.to_string(), v.to_string());
    }
    pub fn unset(&mut self, n: &str) {
        self.frames.last_mut().unwrap().vars.remove(n);
    }
}

pub trait Host {
    fn interp(&mut self) -> &mut Interp;
    /// Return None if the command is unknown.
    fn command(&mut self, name: &str, args: &[String]) -> Option<R>;
}

// ---------------------------------------------------------------- lists
pub fn split_list(s: &str) -> Vec<String> {
    let c: Vec<char> = s.chars().collect();
    let mut i = 0;
    let mut out = vec![];
    loop {
        while i < c.len() && c[i].is_whitespace() {
            i += 1
        }
        if i >= c.len() {
            break;
        }
        if c[i] == '{' {
            let mut d = 1;
            let st = i + 1;
            i += 1;
            while i < c.len() && d > 0 {
                if c[i] == '\\' {
                    i += 1;
                } else if c[i] == '{' {
                    d += 1
                } else if c[i] == '}' {
                    d -= 1
                }
                i += 1;
            }
            out.push(c[st..i.saturating_sub(1).max(st)].iter().collect());
        } else if c[i] == '"' {
            i += 1;
            let mut w = String::new();
            while i < c.len() && c[i] != '"' {
                if c[i] == '\\' && i + 1 < c.len() {
                    i += 1;
                }
                w.push(c[i]);
                i += 1;
            }
            i += 1;
            out.push(w);
        } else {
            let mut w = String::new();
            while i < c.len() && !c[i].is_whitespace() {
                if c[i] == '\\' && i + 1 < c.len() {
                    i += 1;
                }
                w.push(c[i]);
                i += 1;
            }
            out.push(w);
        }
    }
    out
}
pub fn quote(s: &str) -> String {
    if s.is_empty() {
        return "{}".into();
    }
    if s.chars().any(|c| c.is_whitespace() || "{}\"$[];\\".contains(c)) {
        if s.chars().filter(|&c| c == '{').count() == s.chars().filter(|&c| c == '}').count() {
            return format!("{{{}}}", s);
        }
        return s.chars().map(|c| if "{}\"$[] ;\\".contains(c) { format!("\\{}", c) } else { c.to_string() }).collect();
    }
    s.to_string()
}
pub fn to_list<S: AsRef<str>>(v: &[S]) -> String {
    v.iter().map(|s| quote(s.as_ref())).collect::<Vec<_>>().join(" ")
}

// ---------------------------------------------------------------- parser / evaluator
fn match_brace(c: &[char], mut i: usize, open: char, close: char) -> usize {
    // c[i] == open; returns index of matching close
    let mut d = 0;
    while i < c.len() {
        if c[i] == '\\' {
            i += 2;
            continue;
        }
        if c[i] == open {
            d += 1
        } else if c[i] == close {
            d -= 1;
            if d == 0 {
                return i;
            }
        }
        i += 1;
    }
    c.len()
}
fn match_bracket(c: &[char], mut i: usize) -> usize {
    let mut d = 0;
    while i < c.len() {
        match c[i] {
            '\\' => {
                i += 2;
                continue;
            }
            '[' => d += 1,
            ']' => {
                d -= 1;
                if d == 0 {
                    return i;
                }
            }
            '{' => {
                i = match_brace(c, i, '{', '}');
            }
            _ => {}
        }
        i += 1;
    }
    c.len()
}

fn backslash(c: &[char], i: &mut usize, out: &mut String) {
    *i += 1;
    if *i >= c.len() {
        out.push('\\');
        return;
    }
    match c[*i] {
        'n' => out.push('\n'),
        't' => out.push('\t'),
        '\n' => {
            out.push(' ');
            while *i + 1 < c.len() && (c[*i + 1] == ' ' || c[*i + 1] == '\t') {
                *i += 1
            }
        }
        x => out.push(x),
    }
    *i += 1;
}

fn subst_var<H: Host>(h: &mut H, c: &[char], i: &mut usize, out: &mut String) -> Result<(), Flow> {
    *i += 1; // skip $
    let name: String;
    if *i < c.len() && c[*i] == '{' {
        let e = match_brace(c, *i, '{', '}');
        name = c[*i + 1..e].iter().collect();
        *i = e + 1;
    } else {
        let mut n = String::new();
        while *i < c.len() && (c[*i].is_alphanumeric() || c[*i] == '_' || (c[*i] == ':' && *i + 1 < c.len() && c[*i + 1] == ':')) {
            if c[*i] == ':' {
                n.push_str("::");
                *i += 2;
                continue;
            }
            n.push(c[*i]);
            *i += 1;
        }
        if n.is_empty() {
            out.push('$');
            return Ok(());
        }
        if *i < c.len() && c[*i] == '(' {
            let e = match_brace(c, *i, '(', ')');
            let idx_raw: String = c[*i + 1..e].iter().collect();
            let idx = subst(h, &idx_raw)?;
            *i = e + 1;
            n = format!("{}({})", n, idx);
        }
        name = n;
    }
    match h.interp().get(&name) {
        Some(v) => out.push_str(&v),
        None => return err(format!("can't read \"{}\": no such variable", name)),
    }
    Ok(())
}

/// Perform $, [] and backslash substitution on a string.
pub fn subst<H: Host>(h: &mut H, s: &str) -> R {
    let c: Vec<char> = s.chars().collect();
    let mut i = 0;
    let mut out = String::new();
    while i < c.len() {
        match c[i] {
            '\\' => backslash(&c, &mut i, &mut out),
            '$' => subst_var(h, &c, &mut i, &mut out)?,
            '[' => {
                let e = match_bracket(&c, i);
                let inner: String = c[i + 1..e.min(c.len())].iter().collect();
                out.push_str(&eval(h, &inner)?);
                i = e + 1;
            }
            x => {
                out.push(x);
                i += 1
            }
        }
    }
    Ok(out)
}

fn parse_words<H: Host>(h: &mut H, c: &[char], i: &mut usize) -> Result<Vec<String>, Flow> {
    let mut words = vec![];
    loop {
        while *i < c.len() && (c[*i] == ' ' || c[*i] == '\t' || c[*i] == '\r') {
            *i += 1
        }
        if *i < c.len() && c[*i] == '\\' && *i + 1 < c.len() && c[*i + 1] == '\n' {
            *i += 2;
            continue;
        }
        if *i >= c.len() || c[*i] == '\n' || c[*i] == ';' {
            if *i < c.len() {
                *i += 1
            }
            return Ok(words);
        }
        let mut expand = false;
        if c[*i] == '{' && *i + 2 < c.len() && c[*i + 1] == '*' && c[*i + 2] == '}' && *i + 3 < c.len() && !c[*i + 3].is_whitespace() {
            expand = true;
            *i += 3;
        }
        let w: String;
        if c[*i] == '{' {
            let e = match_brace(c, *i, '{', '}');
            w = c[*i + 1..e.min(c.len())].iter().collect();
            *i = e + 1;
        } else if c[*i] == '"' {
            *i += 1;
            let mut out = String::new();
            while *i < c.len() && c[*i] != '"' {
                match c[*i] {
                    '\\' => backslash(c, i, &mut out),
                    '$' => subst_var(h, c, i, &mut out)?,
                    '[' => {
                        let e = match_bracket(c, *i);
                        let inner: String = c[*i + 1..e.min(c.len())].iter().collect();
                        out.push_str(&eval(h, &inner)?);
                        *i = e + 1;
                    }
                    x => {
                        out.push(x);
                        *i += 1
                    }
                }
            }
            *i += 1;
            w = out;
        } else {
            let mut out = String::new();
            while *i < c.len() && !c[*i].is_whitespace() && c[*i] != ';' {
                match c[*i] {
                    '\\' => {
                        if *i + 1 < c.len() && c[*i + 1] == '\n' {
                            break;
                        }
                        backslash(c, i, &mut out)
                    }
                    '$' => subst_var(h, c, i, &mut out)?,
                    '[' => {
                        let e = match_bracket(c, *i);
                        let inner: String = c[*i + 1..e.min(c.len())].iter().collect();
                        out.push_str(&eval(h, &inner)?);
                        *i = e + 1;
                    }
                    x => {
                        out.push(x);
                        *i += 1
                    }
                }
            }
            w = out;
        }
        if expand {
            words.extend(split_list(&w));
        } else {
            words.push(w);
        }
    }
}

pub fn eval<H: Host>(h: &mut H, script: &str) -> R {
    let c: Vec<char> = script.chars().collect();
    let mut i = 0;
    let mut result = String::new();
    while i < c.len() {
        while i < c.len() && (c[i].is_whitespace() || c[i] == ';') {
            i += 1
        }
        if i >= c.len() {
            break;
        }
        if c[i] == '#' {
            while i < c.len() && c[i] != '\n' {
                if c[i] == '\\' {
                    i += 1
                }
                i += 1;
            }
            continue;
        }
        let words = parse_words(h, &c, &mut i)?;
        if words.is_empty() {
            continue;
        }
        result = invoke(h, &words)?;
    }
    Ok(result)
}

pub fn invoke<H: Host>(h: &mut H, w: &[String]) -> R {
    h.interp().cmd_depth += 1;
    if h.interp().cmd_depth > 1000 {
        h.interp().cmd_depth = 0;
        return err("too many nested evaluations (infinite loop?)");
    }
    let r = invoke_inner(h, w);
    h.interp().cmd_depth -= 1;
    r
}

fn truthy(s: &str) -> Result<bool, Flow> {
    let t = s.trim();
    match t {
        "1" | "true" | "yes" | "on" => return Ok(true),
        "0" | "false" | "no" | "off" | "" => return Ok(false),
        _ => {}
    }
    if let Ok(f) = t.parse::<f64>() {
        return Ok(f != 0.0);
    }
    err(format!("expected boolean value but got \"{}\"", t))
}

fn invoke_inner<H: Host>(h: &mut H, w: &[String]) -> R {
    let a = &w[1..];
    let name = w[0].as_str();
    macro_rules! need {
        ($n:expr) => {
            if a.len() < $n {
                return err(format!("wrong # args: {} needs {} argument(s)", name, $n));
            }
        };
    }
    match name {
        "set" => {
            need!(1);
            if a.len() >= 2 {
                h.interp().set(&a[0], &a[1]);
                return Ok(a[1].clone());
            }
            return h.interp().get(&a[0]).ok_or_else(|| Flow::Err(format!("can't read \"{}\": no such variable", a[0])));
        }
        "unset" => {
            for v in a {
                if v != "-nocomplain" {
                    h.interp().unset(v)
                }
            }
            return Ok(String::new());
        }
        "global" => {
            for v in a {
                h.interp().frames.last_mut().unwrap().globals.push(v.clone());
            }
            return Ok(String::new());
        }
        "open" => {
            need!(1);
            let mode = a.get(1).map(|s| s.as_str()).unwrap_or("r");
            let path = a[0].clone();
            let mut ch = Chan { path: path.clone(), ..Default::default() };
            match mode {
                "r" => ch.data = std::fs::read_to_string(&path).map_err(|e| Flow::Err(format!("couldn't open \"{}\": {}", path, e)))?,
                "w" | "a" => {
                    ch.write = true;
                    if mode == "a" {
                        ch.out = std::fs::read_to_string(&path).unwrap_or_default();
                    } else {
                        std::fs::write(&path, "").map_err(|e| Flow::Err(format!("couldn't open \"{}\": {}", path, e)))?;
                    }
                }
                _ => return err(format!("open: access mode '{}' not supported (r, w, a)", mode)),
            }
            let id = format!("file{}", h.interp().next_chan);
            h.interp().next_chan += 1;
            h.interp().chans.insert(id.clone(), ch);
            return Ok(id);
        }
        "close" | "flush" => {
            need!(1);
            let id = a[0].clone();
            let flush_only = name == "flush";
            let Some(ch) = (if flush_only { h.interp().chans.get(&id).map(|c| Chan { path: c.path.clone(), write: c.write, out: c.out.clone(), ..Default::default() }) } else { h.interp().chans.remove(&id) }) else { return err(format!("can not find channel named \"{}\"", id)) };
            if ch.write {
                std::fs::write(&ch.path, &ch.out).map_err(|e| Flow::Err(format!("error writing \"{}\": {}", ch.path, e)))?;
            }
            return Ok(String::new());
        }
        "gets" | "read" | "eof" => {
            need!(1);
            let id = a.iter().find(|x| !x.starts_with('-')).cloned().unwrap_or_default();
            let Some(ch) = h.interp().chans.get_mut(&id) else { return err(format!("can not find channel named \"{}\"", id)) };
            match name {
                "eof" => return Ok(if ch.pos >= ch.data.len() { "1".into() } else { "0".into() }),
                "read" => {
                    let r = ch.data[ch.pos..].to_string();
                    ch.pos = ch.data.len();
                    return Ok(r);
                }
                _ => {
                    let rest = &ch.data[ch.pos..];
                    let (line, adv, got) = match rest.find('\n') {
                        Some(i) => (rest[..i].trim_end_matches('\r').to_string(), i + 1, true),
                        None => (rest.to_string(), rest.len(), !rest.is_empty()),
                    };
                    ch.pos += adv;
                    if let Some(var) = a.get(1) {
                        let var = var.clone();
                        h.interp().set(&var, &line);
                        return Ok(if got { line.len().to_string() } else { "-1".into() });
                    }
                    return Ok(line);
                }
            }
        }
        "puts" | "echo" => {
            // puts ?-nonewline? channel string : write to an open file channel
            {
                let pos: Vec<&String> = a.iter().filter(|x| *x != "-nonewline").collect();
                if pos.len() == 2 && (h.interp().chans.contains_key(pos[0].as_str()) || pos[0] == "stderr") {
                    let nl = !a.iter().any(|x| x == "-nonewline");
                    let (id, text) = (pos[0].clone(), pos[1].clone());
                    if id == "stderr" {
                        eprintln!("{}", text);
                        return Ok(String::new());
                    }
                    let ch = h.interp().chans.get_mut(&id).unwrap();
                    if !ch.write {
                        return err(format!("channel \"{}\" wasn't opened for writing", id));
                    }
                    ch.out.push_str(&text);
                    if nl {
                        ch.out.push('\n');
                    }
                    return Ok(String::new());
                }
            }
            let mut nonl = false;
            let mut parts = vec![];
            for x in a {
                if x == "-nonewline" {
                    nonl = true
                } else if x != "stdout" {
                    // collections print as object names
                    match crate::cons::collection_names(x) {
                        Some(v) => parts.push(v.join(" ")),
                        None if x.contains("::") && split_list(x).iter().any(|t| crate::cons::Obj::parse(t).is_some()) => {
                            parts.push(split_list(x).iter().map(|t| crate::cons::Obj::parse(t).map(|o| o.name().to_string()).unwrap_or(t.clone())).collect::<Vec<_>>().join(" "))
                        }
                        None => parts.push(x.clone()),
                    }
                }
            }
            let _ = nonl;
            crate::log::out(&parts.join(" "));
            return Ok(String::new());
        }
        "expr" => return expr(h, &a.join(" ")),
        "switch" => {
            // switch ?-exact|-glob|-regexp? ?--? string {pattern body ...} | pattern body ...
            let mut i = 0;
            let mut mode = "exact";
            while i < a.len() && a[i].starts_with('-') {
                match a[i].as_str() {
                    "-exact" => mode = "exact",
                    "-glob" => mode = "glob",
                    "-regexp" => mode = "regexp",
                    "--" => {
                        i += 1;
                        break;
                    }
                    o => return err(format!("bad option \"{}\": must be -exact, -glob, -regexp or --", o)),
                }
                i += 1;
            }
            if i >= a.len() {
                return err("wrong # args: should be \"switch ?options? string pattern body ...\"");
            }
            let val = a[i].clone();
            let pairs: Vec<String> = if a.len() == i + 2 { split_list(&a[i + 1]) } else { a[i + 1..].to_vec() };
            if pairs.len() % 2 != 0 {
                return err("extra switch pattern with no body");
            }
            let mut k = 0;
            while k < pairs.len() {
                let pat = &pairs[k];
                let hit = pat == "default" && k + 2 == pairs.len()
                    || match mode {
                        "glob" => crate::netlist::glob(pat, &val),
                        "regexp" => crate::regex::Regex::new(pat).map(|r| r.is_match(&val)).unwrap_or(false),
                        _ => *pat == val,
                    };
                if hit {
                    // fall-through bodies ("-")
                    let mut b = k + 1;
                    while b < pairs.len() && pairs[b] == "-" {
                        b += 2;
                    }
                    if b >= pairs.len() {
                        return err("no body specified for pattern");
                    }
                    return eval(h, &pairs[b]);
                }
                k += 2;
            }
            return Ok(String::new());
        }
        "if" => {
            let mut k = 0;
            loop {
                if k >= a.len() {
                    return Ok(String::new());
                }
                let cond = expr(h, &a[k])?;
                let mut body = k + 1;
                if body < a.len() && a[body] == "then" {
                    body += 1;
                }
                if body >= a.len() {
                    return err("if: missing body");
                }
                if truthy(&cond)? {
                    return eval(h, &a[body]);
                }
                k = body + 1;
                if k >= a.len() {
                    return Ok(String::new());
                }
                if a[k] == "elseif" {
                    k += 1;
                    continue;
                }
                if a[k] == "else" {
                    return eval(h, a.get(k + 1).map(|s| s.as_str()).unwrap_or(""));
                }
                return eval(h, &a[k]);
            }
        }
        "while" => {
            need!(2);
            let mut n = 0;
            while truthy(&expr(h, &a[0])?)? {
                n += 1;
                if n > 10_000_000 {
                    return err("while: iteration limit");
                }
                match eval(h, &a[1]) {
                    Err(Flow::Break) => break,
                    Err(Flow::Continue) => continue,
                    Err(e) => return Err(e),
                    Ok(_) => {}
                }
            }
            return Ok(String::new());
        }
        "for" => {
            need!(4);
            eval(h, &a[0])?;
            while truthy(&expr(h, &a[1])?)? {
                match eval(h, &a[3]) {
                    Err(Flow::Break) => break,
                    Err(Flow::Continue) => {}
                    Err(e) => return Err(e),
                    Ok(_) => {}
                }
                eval(h, &a[2])?;
            }
            return Ok(String::new());
        }
        "foreach" => {
            need!(3);
            let vars = split_list(&a[0]);
            let items = split_list(&a[1]);
            let mut k = 0;
            while k < items.len() {
                for v in &vars {
                    let val = items.get(k).cloned().unwrap_or_default();
                    h.interp().set(v, &val);
                    k += 1;
                }
                match eval(h, &a[2]) {
                    Err(Flow::Break) => break,
                    Err(Flow::Continue) => {}
                    Err(e) => return Err(e),
                    Ok(_) => {}
                }
            }
            return Ok(String::new());
        }
        "break" => return Err(Flow::Break),
        "continue" => return Err(Flow::Continue),
        "return" => return Err(Flow::Return(a.last().cloned().unwrap_or_default())),
        "error" => return err(a.first().cloned().unwrap_or_default()),
        "clock" => {
            let now = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default();
            return Ok(match a.first().map(|s| s.as_str()).unwrap_or("seconds") {
                "milliseconds" => now.as_millis().to_string(),
                "microseconds" | "clicks" => now.as_micros().to_string(),
                _ => now.as_secs().to_string(),
            });
        }
        "incr" => {
            need!(1);
            let v: i64 = h.interp().get(&a[0]).unwrap_or("0".into()).trim().parse().unwrap_or(0);
            let d: i64 = a.get(1).map(|s| s.trim().parse().unwrap_or(1)).unwrap_or(1);
            let r = (v + d).to_string();
            h.interp().set(&a[0], &r);
            return Ok(r);
        }
        "append" => {
            need!(1);
            let mut v = h.interp().get(&a[0]).unwrap_or_default();
            for x in &a[1..] {
                v.push_str(x)
            }
            h.interp().set(&a[0], &v);
            return Ok(v);
        }
        "lappend" => {
            need!(1);
            let mut l = split_list(&h.interp().get(&a[0]).unwrap_or_default());
            l.extend(a[1..].iter().cloned());
            let r = to_list(&l);
            h.interp().set(&a[0], &r);
            return Ok(r);
        }
        "list" => return Ok(to_list(a)),
        "llength" => {
            need!(1);
            return Ok(split_list(&a[0]).len().to_string());
        }
        "lindex" => {
            need!(2);
            let l = split_list(&a[0]);
            let idx = if a[1] == "end" { l.len() as i64 - 1 } else { a[1].parse().unwrap_or(-1) };
            return Ok(if idx >= 0 { l.get(idx as usize).cloned().unwrap_or_default() } else { String::new() });
        }
        "lrange" => {
            need!(3);
            let l = split_list(&a[0]);
            let p = |s: &str| if s == "end" { l.len().saturating_sub(1) } else { s.parse().unwrap_or(0) };
            let (s, e) = (p(&a[1]), p(&a[2]));
            return Ok(if s <= e && s < l.len() { to_list(&l[s..=e.min(l.len() - 1)]) } else { String::new() });
        }
        "lsort" => {
            need!(1);
            let mut l = split_list(a.last().unwrap());
            if a.iter().any(|x| x == "-real" || x == "-integer") {
                l.sort_by(|x, y| x.parse::<f64>().unwrap_or(0.0).partial_cmp(&y.parse::<f64>().unwrap_or(0.0)).unwrap());
            } else {
                l.sort();
            }
            if a.iter().any(|x| x == "-decreasing") {
                l.reverse()
            }
            if a.iter().any(|x| x == "-unique") {
                l.dedup()
            }
            return Ok(to_list(&l));
        }
        "lsearch" => {
            need!(2);
            let l = split_list(&a[a.len() - 2]);
            let pat = &a[a.len() - 1];
            let opt = |o: &str| a[..a.len() - 2].iter().any(|x| x == o);
            let nocase = opt("-nocase");
            let rx = if opt("-regexp") { crate::regex::Regex::new(&if nocase { pat.to_lowercase() } else { pat.clone() }).ok() } else { None };
            let hit = |x: &String| -> bool {
                let (x, p) = if nocase { (x.to_lowercase(), pat.to_lowercase()) } else { (x.clone(), pat.clone()) };
                let r = if opt("-exact") { x == p } else if let Some(r) = &rx { r.is_match(&x) } else { crate::netlist::glob(&p, &x) };
                r != opt("-not")
            };
            if opt("-all") {
                let v: Vec<String> = l.iter().enumerate().filter(|(_, x)| hit(x)).map(|(i, x)| if opt("-inline") { x.clone() } else { i.to_string() }).collect();
                return Ok(to_list(&v));
            }
            return Ok(match l.iter().position(|x| hit(x)) {
                Some(p) if opt("-inline") => l[p].clone(),
                Some(p) => p.to_string(),
                None if opt("-inline") => String::new(),
                None => "-1".into(),
            });
        }
        "lreverse" => {
            need!(1);
            let mut l = split_list(&a[0]);
            l.reverse();
            return Ok(to_list(&l));
        }
        "lassign" => {
            need!(1);
            let l = split_list(&a[0]);
            for (i, v) in a[1..].iter().enumerate() {
                h.interp().set(v, l.get(i).map(|s| s.as_str()).unwrap_or(""));
            }
            return Ok(to_list(&l.iter().skip(a.len() - 1).cloned().collect::<Vec<_>>()));
        }
        "regexp" | "regsub" => {
            // regexp ?-nocase? ?-all? ?-inline? ?--? exp string ?matchVar subVar ...?
            // regsub ?-nocase? ?-all? ?--? exp string subSpec ?varName?
            let mut i = 0;
            let (mut nocase, mut all, mut inline) = (false, false, false);
            while i < a.len() && a[i].starts_with('-') {
                match a[i].as_str() {
                    "-nocase" => nocase = true,
                    "-all" => all = true,
                    "-inline" => inline = true,
                    "--" => {
                        i += 1;
                        break;
                    }
                    _ => {}
                }
                i += 1;
            }
            let rest = &a[i..];
            if rest.len() < 2 || (name == "regsub" && rest.len() < 3) {
                return err(format!("wrong # args: should be \"{} ?-switch ...? exp string{}\"", name, if name == "regsub" { " subSpec ?varName?" } else { " ?matchVar ...?" }));
            }
            let pat = if nocase { rest[0].to_lowercase() } else { rest[0].clone() };
            let re = crate::regex::Regex::new(&pat).map_err(|e| Flow::Err(format!("couldn't compile regular expression pattern: {}", e)))?;
            let text: Vec<char> = rest[1].chars().collect();
            let lowered: Vec<char> = if nocase { rest[1].to_lowercase().chars().collect() } else { text.clone() };
            let sub = |c: &[Option<(usize, usize)>], k: usize| -> String { c.get(k).copied().flatten().map(|(x, y)| text[x..y].iter().collect()).unwrap_or_default() };
            if name == "regexp" {
                let mut pos = 0;
                let mut found = vec![];
                while pos <= lowered.len() {
                    let Some(c) = re.find_at(&lowered, pos) else { break };
                    let (st, en) = c[0].unwrap();
                    found.push(c);
                    if !all {
                        break;
                    }
                    pos = if en > st { en } else { en + 1 };
                }
                if inline {
                    let v: Vec<String> = found.iter().flat_map(|c| (0..=re.groups()).map(move |k| (c, k))).map(|(c, k)| sub(c, k)).collect();
                    return Ok(to_list(&v));
                }
                if let Some(c) = found.first() {
                    for (k, var) in rest[2..].iter().enumerate() {
                        h.interp().set(var, &sub(c, k));
                    }
                } else {
                    for var in &rest[2..] {
                        h.interp().set(var, "");
                    }
                }
                return Ok(if all { found.len().to_string() } else if found.is_empty() { "0".into() } else { "1".into() });
            }
            // regsub
            let spec: Vec<char> = rest[2].chars().collect();
            let mut out = String::new();
            let mut pos = 0;
            let mut n = 0;
            while pos <= lowered.len() {
                let Some(c) = re.find_at(&lowered, pos) else { break };
                let (st, en) = c[0].unwrap();
                out.extend(&text[pos..st]);
                let mut j = 0;
                while j < spec.len() {
                    match spec[j] {
                        '&' => out.push_str(&sub(&c, 0)),
                        '\\' if j + 1 < spec.len() && spec[j + 1].is_ascii_digit() => {
                            out.push_str(&sub(&c, spec[j + 1].to_digit(10).unwrap() as usize));
                            j += 1;
                        }
                        '\\' if j + 1 < spec.len() && (spec[j + 1] == '&' || spec[j + 1] == '\\') => {
                            out.push(spec[j + 1]);
                            j += 1;
                        }
                        ch => out.push(ch),
                    }
                    j += 1;
                }
                n += 1;
                if en == st {
                    if st < text.len() {
                        out.push(text[st]);
                    }
                    pos = st + 1;
                } else {
                    pos = en;
                }
                if !all {
                    break;
                }
            }
            if pos <= text.len() {
                out.extend(&text[pos.min(text.len())..]);
            }
            if let Some(var) = rest.get(3) {
                h.interp().set(var, &out);
                return Ok(n.to_string());
            }
            return Ok(out);
        }
        "concat" => return Ok(a.iter().map(|s| s.trim()).filter(|s| !s.is_empty()).collect::<Vec<_>>().join(" ")),
        "join" => {
            need!(1);
            let sep = a.get(1).map(|s| s.as_str()).unwrap_or(" ");
            return Ok(split_list(&a[0]).join(sep));
        }
        "split" => {
            need!(1);
            let seps = a.get(1).cloned().unwrap_or(" \t\n".into());
            let parts: Vec<String> = a[0].split(|c| seps.contains(c)).map(|s| s.to_string()).collect();
            return Ok(to_list(&parts));
        }
        "string" => {
            need!(2);
            let s = &a[a.len() - 1];
            return Ok(match a[0].as_str() {
                "length" => s.chars().count().to_string(),
                "tolower" => s.to_lowercase(),
                "toupper" => s.to_uppercase(),
                "trim" => s.trim().to_string(),
                "equal" => (a.len() >= 3 && a[a.len() - 2] == *s).then(|| "1").unwrap_or("0").to_string(),
                "compare" => (a[1].cmp(&a[2]) as i32).to_string(),
                "match" => {
                    need!(3);
                    if crate::netlist::glob(&a[a.len() - 2], s) { "1" } else { "0" }.to_string()
                }
                "first" => {
                    need!(3);
                    a[2].find(a[1].as_str()).map(|x| x as i64).unwrap_or(-1).to_string()
                }
                "range" => {
                    need!(4);
                    let ch: Vec<char> = a[1].chars().collect();
                    let p = |x: &str| if x == "end" { ch.len().saturating_sub(1) } else { x.parse().unwrap_or(0) };
                    let (st, en) = (p(&a[2]), p(&a[3]));
                    if st <= en && st < ch.len() { ch[st..=en.min(ch.len() - 1)].iter().collect() } else { String::new() }
                }
                "map" => {
                    need!(3);
                    let m = split_list(&a[1]);
                    let mut r = a[2].clone();
                    for p in m.chunks(2) {
                        if p.len() == 2 {
                            r = r.replace(&p[0], &p[1])
                        }
                    }
                    r
                }
                "repeat" => {
                    need!(3);
                    a[1].repeat(a[2].parse().unwrap_or(0))
                }
                "index" => {
                    need!(3);
                    let ch: Vec<char> = a[1].chars().collect();
                    let i = if a[2] == "end" { ch.len().saturating_sub(1) } else if let Some(o) = a[2].strip_prefix("end-") { ch.len().saturating_sub(1 + o.parse::<usize>().unwrap_or(0)) } else { a[2].parse().unwrap_or(usize::MAX) };
                    ch.get(i).map(|c| c.to_string()).unwrap_or_default()
                }
                "last" => {
                    need!(3);
                    a[2].rfind(a[1].as_str()).map(|x| x as i64).unwrap_or(-1).to_string()
                }
                "trimleft" => s.trim_start().to_string(),
                "trimright" => s.trim_end().to_string(),
                "is" => {
                    need!(3);
                    let v = s.trim();
                    let ok = match a[1].as_str() {
                        "integer" | "wideinteger" | "entier" => v.parse::<i64>().is_ok(),
                        "double" => v.parse::<f64>().is_ok(),
                        "alpha" => !v.is_empty() && v.chars().all(|c| c.is_alphabetic()),
                        "digit" => !v.is_empty() && v.chars().all(|c| c.is_ascii_digit()),
                        "alnum" => !v.is_empty() && v.chars().all(|c| c.is_alphanumeric()),
                        "space" => v.is_empty() || s.chars().all(|c| c.is_whitespace()),
                        "boolean" => ["0", "1", "true", "false", "yes", "no", "on", "off"].contains(&v.to_lowercase().as_str()),
                        _ => false,
                    };
                    if ok { "1" } else { "0" }.to_string()
                }
                o => return err(format!("string: unsupported subcommand {}", o)),
            });
        }
        "format" => {
            need!(1);
            return Ok(format_tcl(&a[0], &a[1..]));
        }
        "proc" => {
            need!(3);
            let params = split_list(&a[1])
                .into_iter()
                .map(|p| {
                    let pp = split_list(&p);
                    (pp[0].clone(), pp.get(1).cloned())
                })
                .collect();
            h.interp().procs.insert(a[0].clone(), (params, a[2].clone()));
            return Ok(String::new());
        }
        "catch" => {
            need!(1);
            let (code, res) = match eval(h, &a[0]) {
                Ok(s) => (0, s),
                Err(Flow::Err(e)) => (1, e),
                Err(Flow::Return(s)) => (2, s),
                Err(Flow::Break) => (3, String::new()),
                Err(Flow::Continue) => (4, String::new()),
            };
            if let Some(v) = a.get(1) {
                h.interp().set(v, &res);
            }
            return Ok(code.to_string());
        }
        "eval" => return eval(h, &a.join(" ")),
        "info" => {
            need!(1);
            if a[0] == "exists" {
                need!(2);
                return Ok(if h.interp().get(&a[1]).is_some() { "1" } else { "0" }.into());
            }
            if a[0] == "procs" {
                return Ok(to_list(&h.interp().procs.keys().cloned().collect::<Vec<_>>()));
            }
            return err("info: unsupported subcommand");
        }
        "file" => {
            need!(2);
            let p = std::path::Path::new(&a[1]);
            return Ok(match a[0].as_str() {
                "exists" => if p.exists() { "1" } else { "0" }.into(),
                "dirname" => p.parent().map(|x| x.to_string_lossy().to_string()).filter(|x| !x.is_empty()).unwrap_or(".".into()),
                "tail" => p.file_name().map(|x| x.to_string_lossy().to_string()).unwrap_or_default(),
                "rootname" => a[1].rfind('.').filter(|&i| !a[1][i..].contains('/')).map(|i| a[1][..i].to_string()).unwrap_or(a[1].clone()),
                "extension" => a[1].rfind('.').filter(|&i| !a[1][i..].contains('/')).map(|i| a[1][i..].to_string()).unwrap_or_default(),
                "join" => a[1..].join("/"),
                "split" => to_list(&a[1].split('/').filter(|x| !x.is_empty()).map(|x| x.to_string()).collect::<Vec<_>>()),
                "mkdir" => {
                    let _ = std::fs::create_dir_all(p);
                    String::new()
                }
                "copy" | "rename" | "delete" => {
                    // file copy|rename ?-force? src dst ; file delete ?-force? path...
                    let ops: Vec<&String> = a[1..].iter().filter(|x| !x.starts_with('-')).collect();
                    let force = a.iter().any(|x| x == "-force");
                    if a[0] == "delete" {
                        for f in ops {
                            let q = std::path::Path::new(f.as_str());
                            let r = if q.is_dir() { std::fs::remove_dir_all(q) } else { std::fs::remove_file(q) };
                            if let Err(e) = r {
                                if q.exists() || !force {
                                    if q.exists() {
                                        return err(&format!("error deleting \"{}\": {}", f, e));
                                    }
                                }
                            }
                        }
                        return Ok(String::new());
                    }
                    if ops.len() != 2 {
                        return err(&format!("wrong # args: should be \"file {} ?-force? source target\"", a[0]));
                    }
                    let (src, dst) = (ops[0].as_str(), ops[1].as_str());
                    let dst = if std::path::Path::new(dst).is_dir() { format!("{}/{}", dst, std::path::Path::new(src).file_name().map(|x| x.to_string_lossy().to_string()).unwrap_or_default()) } else { dst.to_string() };
                    if std::path::Path::new(&dst).exists() && !force {
                        return err(&format!("error {} \"{}\": target \"{}\" already exists", if a[0] == "copy" { "copying" } else { "renaming" }, src, dst));
                    }
                    let r = if a[0] == "copy" { std::fs::copy(src, &dst).map(|_| ()) } else { std::fs::rename(src, &dst) };
                    r.map_err(|e| Flow::Err(format!("error {} \"{}\": {}", if a[0] == "copy" { "copying" } else { "renaming" }, src, e)))?;
                    String::new()
                }
                _ => return err("file: unsupported subcommand"),
            });
        }
        "source" => {
            let f = a.iter().find(|x| !x.starts_with('-')).ok_or_else(|| Flow::Err("source: missing file".into()))?;
            let s = std::fs::read_to_string(f).map_err(|e| Flow::Err(format!("couldn't read file \"{}\": {}", f, e)))?;
            if a.iter().any(|x| x == "-echo") {
                crate::log::out(&s);
            }
            return eval(h, &s);
        }
        _ => {}
    }
    // user procs
    if let Some((params, body)) = h.interp().procs.get(name).cloned() {
        let mut f = Frame::default();
        for (k, (p, def)) in params.iter().enumerate() {
            if p == "args" && k == params.len() - 1 {
                f.vars.insert("args".into(), to_list(&a[k.min(a.len())..]));
                break;
            }
            let v = a.get(k).cloned().or(def.clone()).ok_or_else(|| Flow::Err(format!("wrong # args for proc {}", name)))?;
            f.vars.insert(p.clone(), v);
        }
        h.interp().frames.push(f);
        let r = eval(h, &body);
        h.interp().frames.pop();
        return match r {
            Ok(s) | Err(Flow::Return(s)) => Ok(s),
            Err(e) => Err(e),
        };
    }
    match h.command(name, a) {
        Some(r) => r,
        None => err(format!("invalid command name \"{}\" (CMD-005)", name)),
    }
}

fn format_tcl(f: &str, args: &[String]) -> String {
    let c: Vec<char> = f.chars().collect();
    let mut out = String::new();
    let mut i = 0;
    let mut ai = 0;
    while i < c.len() {
        if c[i] == '%' && i + 1 < c.len() {
            if c[i + 1] == '%' {
                out.push('%');
                i += 2;
                continue;
            }
            let mut spec = String::new();
            i += 1;
            while i < c.len() && !c[i].is_alphabetic() {
                spec.push(c[i]);
                i += 1;
            }
            let conv = c.get(i).copied().unwrap_or('s');
            i += 1;
            let arg = args.get(ai).cloned().unwrap_or_default();
            ai += 1;
            let left = spec.starts_with('-');
            let spec = spec.trim_start_matches('-');
            let (w, p) = match spec.split_once('.') {
                Some((w, p)) => (w.parse::<usize>().unwrap_or(0), Some(p.parse::<usize>().unwrap_or(6))),
                None => (spec.parse::<usize>().unwrap_or(0), None),
            };
            let s = match conv {
                'd' | 'i' => format!("{}", arg.trim().parse::<f64>().unwrap_or(0.0) as i64),
                'f' => format!("{:.*}", p.unwrap_or(6), arg.trim().parse::<f64>().unwrap_or(0.0)),
                'g' | 'e' => format!("{}", arg.trim().parse::<f64>().unwrap_or(0.0)),
                'x' => format!("{:x}", arg.trim().parse::<i64>().unwrap_or(0)),
                _ => match p {
                    Some(p) => arg.chars().take(p).collect(),
                    None => arg,
                },
            };
            if s.len() < w {
                if left {
                    out.push_str(&format!("{:<w$}", s, w = w))
                } else {
                    out.push_str(&format!("{:>w$}", s, w = w))
                }
            } else {
                out.push_str(&s)
            }
        } else {
            out.push(c[i]);
            i += 1;
        }
    }
    out
}

// ---------------------------------------------------------------- expr
#[derive(Clone, Debug)]
enum V {
    I(i64),
    F(f64),
    S(String),
}
impl V {
    fn f(&self) -> Result<f64, Flow> {
        match self {
            V::I(i) => Ok(*i as f64),
            V::F(f) => Ok(*f),
            V::S(s) => s.trim().parse().map_err(|_| Flow::Err(format!("expected number but got \"{}\"", s))),
        }
    }
    fn s(&self) -> String {
        match self {
            V::I(i) => i.to_string(),
            V::F(f) => {
                if f.fract() == 0.0 && f.abs() < 1e15 {
                    format!("{:.1}", f)
                } else {
                    format!("{}", f)
                }
            }
            V::S(s) => s.clone(),
        }
    }
    fn num(s: &str) -> V {
        let t = s.trim();
        if let Ok(i) = t.parse::<i64>() {
            return V::I(i);
        }
        if let Some(h) = t.strip_prefix("0x") {
            if let Ok(i) = i64::from_str_radix(h, 16) {
                return V::I(i);
            }
        }
        if let Ok(f) = t.parse::<f64>() {
            return V::F(f);
        }
        V::S(s.to_string())
    }
    fn isnum(&self) -> bool {
        !matches!(self, V::S(_)) || matches!(V::num(&self.s()), V::I(_) | V::F(_))
    }
}

struct EP<'a, H: Host> {
    h: &'a mut H,
    c: Vec<char>,
    i: usize,
}

impl<'a, H: Host> EP<'a, H> {
    fn ws(&mut self) {
        while self.i < self.c.len() && self.c[self.i].is_whitespace() {
            self.i += 1
        }
    }
    fn eat(&mut self, s: &str) -> bool {
        self.ws();
        let sc: Vec<char> = s.chars().collect();
        if self.c.len() >= self.i + sc.len() && self.c[self.i..self.i + sc.len()] == sc[..] {
            // avoid eating "eq" from "equal" etc.
            if s.chars().all(|c| c.is_alphabetic()) && self.c.get(self.i + sc.len()).map(|c| c.is_alphanumeric()).unwrap_or(false) {
                return false;
            }
            self.i += sc.len();
            return true;
        }
        false
    }
    fn peek_is(&mut self, s: &str) -> bool {
        let save = self.i;
        let r = self.eat(s);
        self.i = save;
        r
    }
    fn tern(&mut self) -> Result<V, Flow> {
        let c = self.lor()?;
        if self.eat("?") {
            let a = self.tern()?;
            if !self.eat(":") {
                return err("expr: missing ':'");
            }
            let b = self.tern()?;
            return Ok(if c.f()? != 0.0 { a } else { b });
        }
        Ok(c)
    }
    fn lor(&mut self) -> Result<V, Flow> {
        let mut l = self.land()?;
        while self.eat("||") {
            let r = self.land()?;
            l = V::I((l.f()? != 0.0 || r.f()? != 0.0) as i64);
        }
        Ok(l)
    }
    fn land(&mut self) -> Result<V, Flow> {
        let mut l = self.cmp()?;
        while self.eat("&&") {
            let r = self.cmp()?;
            l = V::I((l.f()? != 0.0 && r.f()? != 0.0) as i64);
        }
        Ok(l)
    }
    fn cmp(&mut self) -> Result<V, Flow> {
        let mut l = self.add()?;
        loop {
            let op = ["==", "!=", "<=", ">=", "<", ">", "eq", "ne"].iter().find(|o| self.peek_is(o)).copied();
            let Some(op) = op else { return Ok(l) };
            self.eat(op);
            let r = self.add()?;
            let res = if op == "eq" || op == "ne" || !l.isnum() || !r.isnum() {
                let (a, b) = (l.s(), r.s());
                match op {
                    "==" | "eq" => a == b,
                    "!=" | "ne" => a != b,
                    "<" => a < b,
                    ">" => a > b,
                    "<=" => a <= b,
                    _ => a >= b,
                }
            } else {
                let (a, b) = (V::num(&l.s()).f()?, V::num(&r.s()).f()?);
                match op {
                    "==" => a == b,
                    "!=" => a != b,
                    "<" => a < b,
                    ">" => a > b,
                    "<=" => a <= b,
                    _ => a >= b,
                }
            };
            l = V::I(res as i64);
        }
    }
    fn add(&mut self) -> Result<V, Flow> {
        let mut l = self.mul()?;
        loop {
            if self.eat("+") {
                let r = self.mul()?;
                l = arith(&l, &r, '+')?;
            } else if self.peek_is("-") {
                self.eat("-");
                let r = self.mul()?;
                l = arith(&l, &r, '-')?;
            } else {
                return Ok(l);
            }
        }
    }
    fn mul(&mut self) -> Result<V, Flow> {
        let mut l = self.pow()?;
        loop {
            if self.peek_is("**") {
                return Ok(l);
            }
            if self.eat("*") {
                let r = self.pow()?;
                l = arith(&l, &r, '*')?;
            } else if self.eat("/") {
                let r = self.pow()?;
                l = arith(&l, &r, '/')?;
            } else if self.eat("%") {
                let r = self.pow()?;
                l = arith(&l, &r, '%')?;
            } else {
                return Ok(l);
            }
        }
    }
    fn pow(&mut self) -> Result<V, Flow> {
        let b = self.un()?;
        if self.eat("**") {
            let e = self.pow()?;
            return Ok(V::F(b.f()?.powf(e.f()?)));
        }
        Ok(b)
    }
    fn un(&mut self) -> Result<V, Flow> {
        if self.eat("!") {
            let v = self.un()?;
            return Ok(V::I((v.f()? == 0.0) as i64));
        }
        if self.eat("-") {
            let v = self.un()?;
            return Ok(match V::num(&v.s()) {
                V::I(i) => V::I(-i),
                x => V::F(-x.f()?),
            });
        }
        if self.eat("+") {
            return self.un();
        }
        self.prim()
    }
    fn prim(&mut self) -> Result<V, Flow> {
        self.ws();
        if self.i >= self.c.len() {
            return err("expr: unexpected end");
        }
        let ch = self.c[self.i];
        if ch == '(' {
            self.i += 1;
            let v = self.tern()?;
            self.eat(")");
            return Ok(v);
        }
        if ch == '$' {
            let mut o = String::new();
            let c = self.c.clone();
            subst_var(self.h, &c, &mut self.i, &mut o)?;
            return Ok(V::num(&o));
        }
        if ch == '[' {
            let e = match_bracket(&self.c, self.i);
            let inner: String = self.c[self.i + 1..e].iter().collect();
            self.i = e + 1;
            let r = eval(self.h, &inner)?;
            return Ok(V::num(&r));
        }
        if ch == '"' {
            self.i += 1;
            let st = self.i;
            while self.i < self.c.len() && self.c[self.i] != '"' {
                self.i += 1
            }
            let raw: String = self.c[st..self.i].iter().collect();
            self.i += 1;
            return Ok(V::S(subst(self.h, &raw)?));
        }
        if ch == '{' {
            let e = match_brace(&self.c, self.i, '{', '}');
            let raw: String = self.c[self.i + 1..e].iter().collect();
            self.i = e + 1;
            return Ok(V::S(raw));
        }
        if ch.is_ascii_digit() || ch == '.' {
            let st = self.i;
            while self.i < self.c.len()
                && (self.c[self.i].is_ascii_alphanumeric() || self.c[self.i] == '.' || ((self.c[self.i] == '-' || self.c[self.i] == '+') && (self.c[self.i - 1] == 'e' || self.c[self.i - 1] == 'E')))
            {
                self.i += 1
            }
            let s: String = self.c[st..self.i].iter().collect();
            return Ok(V::num(&s));
        }
        if ch.is_alphabetic() {
            let st = self.i;
            while self.i < self.c.len() && (self.c[self.i].is_alphanumeric() || self.c[self.i] == '_') {
                self.i += 1
            }
            let f: String = self.c[st..self.i].iter().collect();
            match f.as_str() {
                "true" | "yes" | "on" => return Ok(V::I(1)),
                "false" | "no" | "off" => return Ok(V::I(0)),
                _ => {}
            }
            if !self.eat("(") {
                return Ok(V::S(f));
            }
            let mut args = vec![];
            if !self.eat(")") {
                loop {
                    args.push(self.tern()?);
                    if self.eat(")") {
                        break;
                    }
                    if !self.eat(",") {
                        return err("expr: expected ','");
                    }
                }
            }
            let x = args.first().map(|v| v.f()).transpose()?.unwrap_or(0.0);
            return Ok(match f.as_str() {
                "abs" => match V::num(&args[0].s()) {
                    V::I(i) => V::I(i.abs()),
                    _ => V::F(x.abs()),
                },
                "int" => V::I(x as i64),
                "double" => V::F(x),
                "round" => V::I(x.round() as i64),
                "floor" => V::F(x.floor()),
                "ceil" => V::F(x.ceil()),
                "sqrt" => V::F(x.sqrt()),
                "log" => V::F(x.ln()),
                "log10" => V::F(x.log10()),
                "pow" => V::F(x.powf(args[1].f()?)),
                "min" => V::F(args.iter().map(|v| v.f().unwrap_or(f64::MAX)).fold(f64::MAX, f64::min)),
                "max" => V::F(args.iter().map(|v| v.f().unwrap_or(f64::MIN)).fold(f64::MIN, f64::max)),
                _ => return err(format!("expr: unknown function {}", f)),
            });
        }
        err(format!("expr: syntax error at '{}'", ch))
    }
}

fn arith(a: &V, b: &V, op: char) -> Result<V, Flow> {
    let (a, b) = (V::num(&a.s()), V::num(&b.s()));
    if let (V::I(x), V::I(y)) = (&a, &b) {
        let (x, y) = (*x, *y);
        return Ok(V::I(match op {
            '+' => x.wrapping_add(y),
            '-' => x.wrapping_sub(y),
            '*' => x.wrapping_mul(y),
            '/' => {
                if y == 0 {
                    return err("divide by zero");
                }
                x.div_euclid(y)
            }
            _ => {
                if y == 0 {
                    return err("divide by zero");
                }
                x.rem_euclid(y)
            }
        }));
    }
    let (x, y) = (a.f()?, b.f()?);
    Ok(V::F(match op {
        '+' => x + y,
        '-' => x - y,
        '*' => x * y,
        '/' => x / y,
        _ => x % y,
    }))
}

pub fn expr<H: Host>(h: &mut H, s: &str) -> R {
    let mut p = EP { h, c: s.chars().collect(), i: 0 };
    let v = p.tern()?;
    p.ws();
    if p.i < p.c.len() {
        return err(format!("expr: syntax error in \"{}\"", s));
    }
    Ok(v.s())
}

#[cfg(test)]
mod tests {
    use super::*;
    struct H(Interp);
    impl Host for H {
        fn interp(&mut self) -> &mut Interp { &mut self.0 }
        fn command(&mut self, _n: &str, _a: &[String]) -> Option<R> { None }
    }
    fn ev(s: &str) -> String {
        let mut h = H(Interp::default());
        match eval(&mut h, s) { Ok(x) => x, Err(Flow::Err(e)) => panic!("{}", e), Err(_) => String::new() }
    }
    #[test]
    fn substitution_procs_and_expr() {
        assert_eq!(ev("set a 3; expr {$a * 2 + 1}"), "7");
        assert_eq!(ev("proc f {x {y 10}} { return [expr $x + $y] }; f 5"), "15");
        assert_eq!(ev("set l {}; foreach i {1 2 3} { lappend l [expr $i*$i] }; join $l ,"), "1,4,9");
        assert_eq!(ev("if {[string match u_* u_core]} { set r yes } else { set r no }"), "yes");
        assert_eq!(ev("llength [list a {b c} d]"), "3");
        assert_eq!(ev("format %5.2f 3.14159"), " 3.14");
    }
}
