//! SDC constraint database and MMMC (mode / corner / scenario) objects.
//! Objects are stored by name so constraints survive netlist transformations
//! (mapping, sizing, buffering); they are resolved to pins at timing time.

#[derive(Clone, Debug, PartialEq)]
pub enum Obj {
    Port(String),
    Pin(String),
    Cell(String),
    Net(String),
    Clock(String),
    LibCell(String),
}
impl Obj {
    pub fn name(&self) -> &str {
        match self {
            Obj::Port(s) | Obj::Pin(s) | Obj::Cell(s) | Obj::Net(s) | Obj::Clock(s) | Obj::LibCell(s) => s,
        }
    }
    pub fn handle(&self) -> String {
        let (k, n) = match self {
            Obj::Port(s) => ("port", s),
            Obj::Pin(s) => ("pin", s),
            Obj::Cell(s) => ("cell", s),
            Obj::Net(s) => ("net", s),
            Obj::Clock(s) => ("clock", s),
            Obj::LibCell(s) => ("lib_cell", s),
        };
        format!("{}::{}", k, n)
    }
    pub fn parse(h: &str) -> Option<Obj> {
        let (k, n) = h.split_once("::")?;
        Some(match k {
            "port" => Obj::Port(n.into()),
            "pin" => Obj::Pin(n.into()),
            "cell" => Obj::Cell(n.into()),
            "net" => Obj::Net(n.into()),
            "clock" => Obj::Clock(n.into()),
            "lib_cell" => Obj::LibCell(n.into()),
            _ => return None,
        })
    }
}

#[derive(Clone, Debug)]
pub struct GenClock {
    pub master: String,
    pub source: Obj,
    pub divide: f64,
    pub multiply: f64,
    pub invert: bool,
    pub edges: Option<Vec<i32>>,
}

#[derive(Clone, Debug)]
pub struct Clock {
    pub name: String,
    pub period: f64,
    pub rise: f64,
    pub fall: f64,
    pub sources: Vec<Obj>,
    pub gen: Option<GenClock>,
    pub propagated: bool,
    pub src_lat: (f64, f64),
    pub net_lat: (f64, f64),
    pub unc_setup: f64,
    pub unc_hold: f64,
    pub transition: f64,
    pub max_tran: Option<f64>,
}
impl Clock {
    pub fn is_virtual(&self) -> bool {
        self.sources.is_empty()
    }
}

#[derive(Clone, Debug)]
pub struct IoDelay {
    pub obj: Obj,
    pub clock: Option<String>,
    pub clock_fall: bool,
    pub max: Option<f64>,
    pub min: Option<f64>,
    pub is_input: bool,
}

#[derive(Clone, Debug, PartialEq)]
pub enum ExKind {
    False,
    Multicycle(f64, bool), // multiplier, -start
    MaxDelay(f64),
    MinDelay(f64),
}

#[derive(Clone, Debug)]
pub struct Exception {
    pub kind: ExKind,
    pub from: Vec<Obj>,
    pub through: Vec<Obj>,
    pub to: Vec<Obj>,
    pub setup: bool,
    pub hold: bool,
    pub rise_from: Option<bool>,
}

/// group_path / create_path_groups
#[derive(Clone, Debug)]
pub struct PathGroup {
    pub name: String,
    pub from: Vec<Obj>,
    pub to: Vec<Obj>,
    pub weight: f64,
    pub critical_range: Option<f64>,
}

/// set_path_margin: extra required-time margin (positive = tighter) on matching paths
#[derive(Clone, Debug)]
pub struct PathMargin {
    pub from: Vec<Obj>,
    pub to: Vec<Obj>,
    pub setup: bool,
    pub hold: bool,
    pub value: f64,
}

#[derive(Clone, Debug, Default)]
pub struct Constraints {
    pub path_groups: Vec<PathGroup>,
    /// set_path_group_options / group_path -weight -critical_range, by group name (user or clock group)
    pub group_opts: std::collections::BTreeMap<String, (Option<f64>, Option<f64>)>,
    pub path_margins: Vec<PathMargin>,
    /// set_critical_range: critical range for every path group without its own value
    pub critical_range_all: Option<f64>,
    pub clocks: Vec<Clock>,
    pub io: Vec<IoDelay>,
    pub exceptions: Vec<Exception>,
    pub disabled: Vec<(Obj, Option<String>, Option<String>)>,
    pub case: Vec<(Obj, bool)>,
    pub max_tran: Option<f64>,
    pub max_fanout: Option<f64>,
    pub max_cap: Option<f64>,
    pub obj_max_tran: Vec<(Obj, f64)>,
    pub obj_max_fanout: Vec<(Obj, f64)>,
    pub obj_max_cap: Vec<(Obj, f64)>,
    pub input_tran: Vec<(Obj, f64)>,
    pub driving_cell: Vec<(Obj, String)>,
    pub loads: Vec<(Obj, f64)>,
    pub clock_groups: Vec<(String, Vec<Vec<String>>)>, // (async|exclusive|physically_exclusive, groups)
    /// set_clock_sense / set_sense -type clock: (pin, 0=stop_propagation 1=positive 2=negative, clocks (empty = all))
    pub clock_sense: Vec<(Obj, u8, Vec<String>)>,
    pub data_checks: Vec<(Obj, Obj, f64)>,
    pub ideal_nets: Vec<Obj>,
    pub wire_load_model: Option<String>,
    pub max_area: Option<f64>,
    pub cg_setup: f64,
    pub cg_hold: f64,
    pub min_pulse_width: Vec<(Option<Obj>, f64)>,
    pub raw: Vec<String>,
    pub max_dynamic_power: Option<f64>,
    pub max_leakage_power: Option<f64>,
}

impl Constraints {
    pub fn clock(&self, n: &str) -> Option<usize> {
        self.clocks.iter().position(|c| c.name == n)
    }
}

#[derive(Clone, Debug)]
pub struct Corner {
    pub name: String,
    pub libs: Vec<usize>,
    pub late_cell: f64,
    pub early_cell: f64,
    pub late_net: f64,
    pub early_net: f64,
    pub r_scale: f64,
    pub c_scale: f64,
    /// clock-path derates (None = same as data)
    pub late_cell_clk: Option<f64>,
    pub early_cell_clk: Option<f64>,
    pub late_net_clk: Option<f64>,
    pub early_net_clk: Option<f64>,
    pub temperature: Option<f64>,
    pub voltage: Option<f64>,
    pub process_label: String,
    pub spef: Option<String>,
    /// object-specific derates (cells, library cells, hierarchical instances, nets), applied in order
    pub obj_derates: Vec<ObjDerate>,
}
impl Corner {
    /// OCV derate for a cell or net delay, early or late, on a clock or data path
    pub fn derate(&self, cell: bool, early: bool, clock: bool) -> f64 {
        match (cell, early, clock) {
            (true, false, true) => self.late_cell_clk.unwrap_or(self.late_cell),
            (true, true, true) => self.early_cell_clk.unwrap_or(self.early_cell),
            (false, false, true) => self.late_net_clk.unwrap_or(self.late_net),
            (false, true, true) => self.early_net_clk.unwrap_or(self.early_net),
            (true, false, false) => self.late_cell,
            (true, true, false) => self.early_cell,
            (false, false, false) => self.late_net,
            (false, true, false) => self.early_net,
        }
    }
    pub fn new(n: &str) -> Corner {
        Corner { name: n.into(), libs: vec![], late_cell: 1.0, early_cell: 1.0, late_net: 1.0, early_net: 1.0, r_scale: 1.0, c_scale: 1.0, late_cell_clk: None, early_cell_clk: None, late_net_clk: None, early_net_clk: None, temperature: None, voltage: None, process_label: String::new(), spef: None, obj_derates: vec![] }
    }
}

#[derive(Clone, Debug)]
pub struct ObjDerate {
    pub obj: Obj,
    pub late: bool,
    pub early: bool,
    pub cell: bool,
    pub net: bool,
    pub clock: bool,
    pub data: bool,
    pub value: f64,
}

#[derive(Clone, Debug)]
pub struct Mode {
    pub name: String,
    pub sdc: Constraints,
}

#[derive(Clone, Debug)]
pub struct Scenario {
    pub name: String,
    pub mode: String,
    pub corner: String,
    pub active: bool,
    pub setup: bool,
    pub hold: bool,
    pub leakage: bool,
    pub dynamic: bool,
    pub max_tran: bool,
    pub max_cap: bool,
}

impl Constraints {
    /// (weight, critical range) of a path group. Weight defaults to 1.0. Critical range: the group's
    /// own value (group_path / set_path_group_options), else set_critical_range, else None = no window
    /// (all violating paths of the group are optimized, the default behaviour).
    pub fn group_weight_cr(&self, g: &str) -> (f64, Option<f64>) {
        let (mut w, mut cr) = (1.0, None);
        if let Some(pg) = self.path_groups.iter().find(|p| p.name == g) {
            w = pg.weight;
            cr = pg.critical_range;
        }
        if let Some((ow, ocr)) = self.group_opts.get(g) {
            if let Some(x) = ow {
                w = *x;
            }
            if ocr.is_some() {
                cr = *ocr;
            }
        }
        (w, cr.or(self.critical_range_all))
    }
    /// true when path groups influence optimization cost
    pub fn group_aware(&self) -> bool {
        // only non-default settings switch the optimizer to path-group cost (weight 1 / no range = default)
        !self.path_groups.is_empty()
            || self.critical_range_all.is_some()
            || self.group_opts.values().any(|(w, cr)| w.map(|w| (w - 1.0).abs() > 1e-12).unwrap_or(false) || cr.is_some())
    }
}

/// If every element of a Tcl list is an object handle, return the object names (for display).
pub fn collection_names(s: &str) -> Option<Vec<String>> {
    let items = crate::tcl::split_list(s);
    if items.is_empty() {
        return None;
    }
    let mut v = Vec::with_capacity(items.len());
    for it in &items {
        v.push(Obj::parse(it)?.name().to_string());
    }
    Some(v)
}
