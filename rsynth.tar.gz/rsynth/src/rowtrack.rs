//! Core rows and routing tracks, Innovus style (both the legacy camelCase names and the
//! Stylus snake_case names are accepted):
//!
//!  create_row / createRow   [-site name] [-area {x1 y1 x2 y2}] [-spacing s] [-no_abut|-noAbut]
//!                           [-no_flip|-noFlip] [-flip_first_row|-flip1st] [-num_rows n]
//!  cut_row / cutRow         [-area {x1 y1 x2 y2}] [-selected] [-objects pats] [-halo h]
//!                           [-left_gap|-leftGap l] [-right_gap r] [-top_gap t] [-bottom_gap b]
//!                           [-site name] [-min_row_width w]          (default: around every placed
//!                           block macro and hard placement blockage)
//!  delete_row / deleteRow   [-all] [-area {..}] [-site name] [row name patterns]
//!  report_rows [-verbose]
//!  create_track / createTrack  -layer {layers} [-dir X|Y | -direction vertical|horizontal]
//!                           [-start s] [-step p] [-num n] [-mask m] [-same_mask] [-add]
//!  add_tracks               [-honor_pitch] [-offsets {layer dir offset ...}] [-pitches {layer dir pitch ...}]
//!                           [-mask_pattern {layer {m ...} ...}] [-non_preferred] [-layers {..}]
//!  delete_tracks / deleteTracks [-layer {..}] [-dir X|Y] [-all]
//!  report_tracks
//!
//! Rows are explicit once any of the row commands ran: the legalizer then only uses sites that
//! lie on a row, and `write_def` writes the rows as they are (names RSROW_*). Tracks are written
//! as DEF TRACKS; the preferred-direction step of a layer becomes its routing pitch.

use crate::cons::Obj;
use crate::netlist::*;
use crate::phys::{RowRec, TrackRec};
use crate::session::{args, Session};
use crate::tcl::{err, split_list, Flow, R};

type Rect = (f64, f64, f64, f64);
const EPS: f64 = 1e-6;

fn parse_rect(s: &str) -> Option<Rect> {
    let v: Vec<f64> = s.replace(['{', '}'], " ").split_whitespace().filter_map(|x| x.parse().ok()).collect();
    if v.len() < 4 { return None; }
    Some((v[0].min(v[2]), v[1].min(v[3]), v[0].max(v[2]), v[1].max(v[3])))
}
/// option value under any of its spellings
fn opt<'a>(x: &'a crate::session::A, names: &[&str]) -> Option<&'a String> { names.iter().find_map(|n| x.get(n)) }
fn has(x: &crate::session::A, names: &[&str]) -> bool { names.iter().any(|n| x.has(n)) }

impl Session {
    pub fn rowtrack_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "create_row" | "createRow" | "create_rows" => self.c_create_row(a),
            "cut_row" | "cutRow" | "cut_rows" => self.c_cut_row(a),
            "delete_row" | "deleteRow" | "delete_rows" => self.c_delete_row(a),
            "report_rows" | "report_row" => self.c_report_rows(a),
            "create_track" | "createTrack" | "create_tracks" => self.c_create_track(a),
            "add_tracks" | "addTracks" | "generate_tracks" | "generateTracks" => self.c_add_tracks(a),
            "delete_tracks" | "deleteTracks" | "delete_track" | "deleteTrack" => self.c_delete_tracks(a),
            "report_tracks" | "report_track" => self.c_report_tracks(),
            _ => return None,
        })
    }

    /// row grid origin and pitches: (x0, y0, site width, row height, placement region)
    fn row_grid(&self) -> Result<(f64, f64, f64, f64, Rect), Flow> {
        let fp = self.fp.as_ref().ok_or_else(|| Flow::Err("No floorplan: initialize_floorplan or read_def first (FP-001)".into()))?;
        let rh = self.row_h();
        // same grid as the legalizer: the core, or the die less one row of margin
        let reg = match fp.core { Some(c) => c, None => (fp.die.0 + rh, fp.die.1 + rh, fp.die.2 - rh, fp.die.3 - rh) };
        Ok((reg.0, reg.1, self.site_w(), rh, reg))
    }

    /// turn the implicit rows (tiling the core) into explicit row records
    fn ensure_rows(&mut self) -> Result<(), Flow> {
        let (x0, y0, sw, rh, reg) = self.row_grid()?;
        let site_name = self.core_site_name();
        let fp = self.fp.as_mut().unwrap();
        if fp.rows_explicit { return Ok(()); }
        // DEF rows that sit on the grid are kept; otherwise tile the core
        let on_grid = !fp.row_list.is_empty() && fp.row_list.iter().all(|r| ((r.y - y0) / rh - ((r.y - y0) / rh).round()).abs() < 0.01 && (r.step - sw).abs() < 1e-6);
        if !on_grid {
            fp.row_list.clear();
            let n = ((reg.2 - reg.0) / sw + EPS).floor() as usize;
            let mut y = y0;
            let mut k = 0;
            while y + rh <= reg.3 + EPS {
                fp.row_list.push(RowRec { name: format!("RSROW_{}", k), site: site_name.clone(), x: x0, y, orient: if k % 2 == 0 { "N".into() } else { "FS".into() }, nsites: n, step: sw, height: rh });
                y += rh;
                k += 1;
            }
        } else {
            for r in &mut fp.row_list { r.height = rh; if !r.name.starts_with("RSROW_") { r.name = format!("RSROW_{}", r.name); } }
        }
        fp.rows_explicit = true;
        Ok(())
    }

    fn next_row_name(&mut self) -> String {
        let fp = self.fp.as_mut().unwrap();
        let mut k = fp.row_list.len();
        loop {
            let n = format!("RSROW_{}", k);
            if !fp.row_list.iter().any(|r| r.name == n) { return n; }
            k += 1;
        }
    }

    /// remove the parts of rows inside `r` (x snapped outward to the site grid); returns cut count
    fn cut_rows_in(&mut self, r: Rect, site: Option<&str>, min_w: f64) -> usize {
        let fp = self.fp.as_mut().unwrap();
        let mut out: Vec<RowRec> = vec![];
        let mut cuts = 0;
        let old = std::mem::take(&mut fp.row_list);
        for row in old {
            let hit = row.y < r.3 - EPS && row.y + row.height > r.1 + EPS && row.x < r.2 - EPS && row.x1() > r.0 + EPS && site.map(|s| s == row.site).unwrap_or(true);
            if !hit { out.push(row); continue; }
            cuts += 1;
            let sl = ((r.0 - row.x) / row.step + EPS).floor().max(0.0) as usize; // sites kept on the left
            let sr = ((r.2 - row.x) / row.step - EPS).ceil().max(0.0) as usize; // first site kept on the right
            if sl > 0 && sl as f64 * row.step >= min_w - EPS {
                out.push(RowRec { nsites: sl, ..row.clone() });
            }
            if sr < row.nsites && (row.nsites - sr) as f64 * row.step >= min_w - EPS {
                out.push(RowRec { name: format!("{}_r{}", row.name, cuts), x: row.x + sr as f64 * row.step, nsites: row.nsites - sr, ..row.clone() });
            }
        }
        // unique names
        let mut seen = std::collections::HashSet::new();
        for (k, r) in out.iter_mut().enumerate() { if !seen.insert(r.name.clone()) { r.name = format!("{}_{}", r.name, k); seen.insert(r.name.clone()); } }
        fp.row_list = out;
        cuts
    }

    fn rows_summary(&self) -> String {
        let fp = self.fp.as_ref().unwrap();
        let sites: usize = fp.row_list.iter().map(|r| r.nsites).sum();
        let area: f64 = fp.row_list.iter().map(|r| r.nsites as f64 * r.step * r.height).sum();
        format!("{} row(s), {} site(s), {:.1} um2 of row area", fp.row_list.len(), sites, area)
    }

    fn c_create_row(&mut self, a: &[String]) -> R {
        let x = args(a, &["-site", "-area", "-spacing", "-num_rows", "-numRows"]);
        self.ensure_rows()?;
        let (x0g, y0g, sw, rh, reg) = self.row_grid()?;
        let site = opt(&x, &["-site"]).cloned().unwrap_or_else(|| self.core_site_name());
        let area = match opt(&x, &["-area"]) { Some(s) => parse_rect(s).ok_or_else(|| Flow::Err("create_row: -area {x1 y1 x2 y2} (FP-410)".into()))?, None => reg };
        // snap inward to the site / row grid of the core
        let ax0 = x0g + ((area.0 - x0g) / sw - EPS).ceil() * sw;
        let ax1 = x0g + ((area.2 - x0g) / sw + EPS).floor() * sw;
        let ay0 = y0g + ((area.1 - y0g) / rh - EPS).ceil() * rh;
        if ax1 - ax0 < sw - EPS || area.3 - ay0 < rh - EPS { return err("create_row: the area holds no complete site (FP-411)"); }
        let mut sp = x.num("-spacing").unwrap_or(0.0).max(0.0);
        if sp > EPS {
            let snapped = (sp / rh - EPS).ceil() * rh;
            if (snapped - sp).abs() > EPS { crate::warn!("FP-412", "create_row: -spacing {} rounded up to {} (a multiple of the row height {})", sp, snapped, rh); }
            sp = snapped;
        }
        let no_abut = has(&x, &["-no_abut", "-noAbut"]);
        let no_flip = has(&x, &["-no_flip", "-noFlip"]);
        let flip1 = has(&x, &["-flip_first_row", "-flip1st", "-flipFirstRow"]);
        let maxn = opt(&x, &["-num_rows", "-numRows"]).and_then(|v| v.parse::<usize>().ok()).unwrap_or(usize::MAX);
        let n = ((ax1 - ax0) / sw + EPS).floor() as usize;
        let mut ys = vec![];
        let mut y = ay0;
        let mut k = 0usize;
        while y + rh <= area.3 + EPS && ys.len() < maxn {
            ys.push(y);
            k += 1;
            // abutted pairs with the spacing between pairs (or after every row with -no_abut)
            y += rh + if sp > 0.0 && (no_abut || k % 2 == 0) { sp } else { 0.0 };
        }
        let span = (ax0, ys.first().copied().unwrap_or(ay0), ax1, ys.last().map(|v| v + rh).unwrap_or(ay0));
        let replaced = self.cut_rows_in(span, None, 0.0);
        for (i, y) in ys.iter().enumerate() {
            let parity = (((y - y0g) / rh).round() as usize) % 2;
            let flip = if no_flip { false } else if flip1 { i % 2 == 0 } else if sp > 0.0 { i % 2 == 1 } else { parity == 1 };
            let nm = self.next_row_name();
            self.fp.as_mut().unwrap().row_list.push(RowRec { name: nm, site: site.clone(), x: ax0, y: *y, orient: if flip { "FS".into() } else { "N".into() }, nsites: n, step: sw, height: rh });
        }
        let fp = self.fp.as_mut().unwrap();
        fp.row_list.sort_by(|a, b| (a.y, a.x).partial_cmp(&(b.y, b.x)).unwrap());
        fp.rows = fp.row_list.len();
        crate::info!("FP-413", "create_row: {} row(s) of site '{}' ({} sites each) in ({:.3} {:.3}) ({:.3} {:.3}){}{}; {}", ys.len(), site, n, span.0, span.1, span.2, span.3,
            if replaced > 0 { format!(", replacing {} overlapping row segment(s)", replaced) } else { String::new() }, if sp > 0.0 { format!(", spacing {}{}", sp, if no_abut { "" } else { " between row pairs" }) } else { String::new() }, self.rows_summary());
        Ok(ys.len().to_string())
    }

    fn c_cut_row(&mut self, a: &[String]) -> R {
        let x = args(a, &["-area", "-halo", "-left_gap", "-leftGap", "-right_gap", "-rightGap", "-top_gap", "-topGap", "-bottom_gap", "-bottomGap", "-site", "-objects", "-object", "-min_row_width", "-minRowWidth"]);
        self.ensure_rows()?;
        let halo = x.num("-halo").unwrap_or(0.0);
        let g = |n: &[&str]| opt(&x, n).and_then(|v| v.parse::<f64>().ok()).unwrap_or(halo);
        let (gl, gr, gt, gb) = (g(&["-left_gap", "-leftGap"]), g(&["-right_gap", "-rightGap"]), g(&["-top_gap", "-topGap"]), g(&["-bottom_gap", "-bottomGap"]));
        let site = opt(&x, &["-site"]).cloned();
        let min_w = opt(&x, &["-min_row_width", "-minRowWidth"]).and_then(|v| v.parse::<f64>().ok()).unwrap_or(0.0);
        let mut rects: Vec<(String, Rect)> = vec![];
        let nl = self.nl.as_ref();
        let cell_rect = |c: CellId| -> Option<Rect> { let nl = nl?; crate::lef::cell_rect(&self.lef, nl.cell(c)) };
        if let Some(s) = opt(&x, &["-area"]) {
            rects.push(("area".into(), parse_rect(s).ok_or_else(|| Flow::Err("cut_row: -area {x1 y1 x2 y2} (FP-420)".into()))?));
        } else if x.has("-selected") || opt(&x, &["-objects", "-object"]).is_some() {
            let mut names: Vec<String> = vec![];
            if x.has("-selected") { names.extend(self.selection.iter().filter_map(|h| Obj::parse(h).map(|o| o.name().to_string()))); }
            let pats: Vec<String> = opt(&x, &["-objects", "-object"]).map(|s| split_list(s)).unwrap_or_default();
            let fp = self.fp.as_ref().unwrap();
            if let Some(nl) = nl {
                for c in nl.cell_ids() {
                    let n = &nl.cell(c).name;
                    if names.contains(n) || pats.iter().any(|p| glob(p, n)) { if let Some(r) = cell_rect(c) { rects.push((n.clone(), r)); } }
                }
            }
            for b in &fp.pblk { if names.contains(&b.name) || pats.iter().any(|p| glob(p, &b.name)) { rects.push((b.name.clone(), b.rect)); } }
            if rects.is_empty() { return err("cut_row: no selected / matching object with a placed outline (FP-421)"); }
        } else {
            // default: every placed block macro and every hard placement blockage
            if let Some(nl) = nl {
                for c in nl.cell_ids() {
                    let cl = nl.cell(c);
                    let blk = crate::lef::phys(&self.lef, cl).map(|m| m.is_block()).unwrap_or(false);
                    if blk { if let Some(r) = cell_rect(c) { rects.push((cl.name.clone(), r)); } }
                }
            }
            for b in &self.fp.as_ref().unwrap().pblk {
                if matches!(b.kind, crate::fplan::PbKind::Hard | crate::fplan::PbKind::HardMacro) && !b.name.contains("__guard_") { rects.push((b.name.clone(), b.rect)); }
            }
            if rects.is_empty() { crate::warn!("FP-422", "cut_row: no placed block macro or hard placement blockage to cut around (use -area / -selected)"); }
        }
        let before = self.fp.as_ref().unwrap().row_list.iter().map(|r| r.nsites).sum::<usize>();
        let mut segs = 0;
        for (_, r) in &rects {
            segs += self.cut_rows_in((r.0 - gl, r.1 - gb, r.2 + gr, r.3 + gt), site.as_deref(), min_w);
        }
        if min_w > 0.0 { self.fp.as_mut().unwrap().row_list.retain(|r| r.nsites as f64 * r.step >= min_w - EPS); }
        let fp = self.fp.as_mut().unwrap();
        fp.rows = fp.row_list.len();
        let after = fp.row_list.iter().map(|r| r.nsites).sum::<usize>();
        crate::info!("FP-423", "cut_row: {} object(s){}, {} row segment(s) cut, {} site(s) removed; {}", rects.len(),
            if gl + gr + gt + gb > 0.0 { format!(" (gaps l {} r {} t {} b {})", gl, gr, gt, gb) } else { String::new() }, segs, before - after, self.rows_summary());
        Ok(segs.to_string())
    }

    fn c_delete_row(&mut self, a: &[String]) -> R {
        let x = args(a, &["-area", "-site"]);
        self.ensure_rows()?;
        let site = x.get("-site").cloned();
        let fp = self.fp.as_mut().unwrap();
        let n0 = fp.row_list.len();
        if x.has("-all") {
            fp.row_list.retain(|r| site.as_ref().map(|s| s != &r.site).unwrap_or(false));
        } else if let Some(s) = x.get("-area") {
            let r = parse_rect(s).ok_or_else(|| Flow::Err("delete_row: -area {x1 y1 x2 y2} (FP-430)".into()))?;
            // rows lying inside the area (Innovus semantics: overlapping rows are not split)
            fp.row_list.retain(|w| { let q = w.rect(); !(q.0 >= r.0 - EPS && q.1 >= r.1 - EPS && q.2 <= r.2 + EPS && q.3 <= r.3 + EPS && site.as_ref().map(|s| s == &w.site).unwrap_or(true)) });
        } else if !x.pos.is_empty() {
            let pats: Vec<String> = x.pos.iter().flat_map(|p| split_list(p)).collect();
            fp.row_list.retain(|w| !pats.iter().any(|p| glob(p, &w.name)));
        } else if let Some(s) = &site {
            fp.row_list.retain(|w| &w.site != s);
        } else {
            return err("delete_row: give -all, -area {..}, -site name or row names (FP-431)");
        }
        let d = n0 - fp.row_list.len();
        fp.rows = fp.row_list.len();
        crate::info!("FP-432", "delete_row: {} row(s) deleted; {}", d, self.rows_summary());
        Ok(d.to_string())
    }

    fn c_report_rows(&mut self, a: &[String]) -> R {
        let verbose = a.iter().any(|x| x == "-verbose");
        let fp = self.fp.as_ref().ok_or_else(|| Flow::Err("No floorplan (FP-001)".into()))?;
        if !fp.rows_explicit {
            let (_, _, sw, rh, reg) = self.row_grid()?;
            let n = ((reg.3 - reg.1) / rh + EPS).floor().max(0.0);
            crate::out!("Rows: implicit, tiling the core ({:.3} {:.3}) ({:.3} {:.3}): row height {}, site width {}, ~{} rows", reg.0, reg.1, reg.2, reg.3, rh, sw, n);
            return Ok("0".into());
        }
        crate::out!("****************************************\nReport : rows\n****************************************\n  {}", self.rows_summary());
        let mut sites: Vec<String> = fp.row_list.iter().map(|r| r.site.clone()).collect();
        sites.sort();
        sites.dedup();
        for s in sites {
            let v: Vec<&RowRec> = fp.row_list.iter().filter(|r| r.site == s).collect();
            crate::out!("  site {:<12} {:>5} row(s) {:>8} site(s)  N {}  FS {}", s, v.len(), v.iter().map(|r| r.nsites).sum::<usize>(), v.iter().filter(|r| r.orient == "N").count(), v.iter().filter(|r| r.orient == "FS").count());
        }
        if verbose {
            for r in &fp.row_list { crate::out!("  {:<16} {:<10} ({:>9.3} {:>9.3}) - ({:>9.3} {:>9.3}) {:<3} {} sites", r.name, r.site, r.x, r.y, r.x1(), r.y + r.height, r.orient, r.nsites); }
        }
        Ok(fp.row_list.len().to_string())
    }

    // ------------------------------------------------------------------ tracks
    /// routing layers: (name, preferred horizontal, pitch)
    fn track_layers(&self) -> Vec<(String, bool, f64)> {
        let mut v: Vec<(String, bool, f64)> = self.lef_layers.iter().filter(|l| l.kind.eq_ignore_ascii_case("ROUTING") && l.pitch > 0.0)
            .map(|l| (l.name.clone(), l.dir.to_uppercase().starts_with('H'), l.pitch)).collect();
        if let Some(fp) = &self.fp {
            for l in &fp.layers { if !v.iter().any(|x| x.0 == l.name) { v.push((l.name.clone(), l.horiz, l.pitch)); } }
            // keep the routing-model order
            v.sort_by_key(|x| fp.layers.iter().position(|l| l.name == x.0).unwrap_or(usize::MAX));
        }
        v
    }

    fn put_tracks(&mut self, t: TrackRec, add: bool) {
        let fp = self.fp.as_mut().unwrap();
        if !add { fp.track_list.retain(|x| !(x.layer == t.layer && x.dir == t.dir)); }
        // the preferred-direction step is the routing pitch of the layer
        if let Some(l) = fp.layers.iter_mut().find(|l| l.name == t.layer) {
            if (l.horiz && t.dir == 'Y') || (!l.horiz && t.dir == 'X') { l.pitch = t.step; }
        }
        fp.track_list.push(t);
    }

    fn c_create_track(&mut self, a: &[String]) -> R {
        let x = args(a, &["-layer", "-layers", "-dir", "-direction", "-start", "-step", "-num", "-mask"]);
        if self.fp.is_none() { return err("create_track: no floorplan (FP-001)"); }
        let die = self.fp.as_ref().unwrap().die;
        let layers: Vec<String> = opt(&x, &["-layer", "-layers"]).map(|s| split_list(s)).ok_or_else(|| Flow::Err("create_track: -layer {layers} required (FP-440)".into()))?;
        let known = self.track_layers();
        let mut made = 0;
        for ln in &layers {
            let Some((_, horiz, pitch)) = known.iter().find(|k| &k.0 == ln).cloned() else { return err(&format!("create_track: unknown routing layer '{}' (FP-441)", ln)) };
            let dir = match opt(&x, &["-dir", "-direction"]).map(|s| s.to_lowercase()) {
                Some(d) if d == "x" || d.starts_with('v') => 'X',
                Some(d) if d == "y" || d.starts_with('h') => 'Y',
                Some(d) => return err(&format!("create_track: -dir '{}': X | Y (or vertical | horizontal) (FP-442)", d)),
                None => if horiz { 'Y' } else { 'X' },
            };
            let step = x.num("-step").unwrap_or(pitch);
            if step <= 0.0 { return err("create_track: -step must be > 0 (FP-443)"); }
            let (lo, hi) = if dir == 'X' { (die.0, die.2) } else { (die.1, die.3) };
            let start = x.num("-start").unwrap_or(lo + step);
            let num = x.num("-num").map(|v| v as usize).unwrap_or(((hi - start) / step + EPS).floor().max(0.0) as usize + 1);
            let num = num.min((((hi - start) / step) + EPS).floor().max(0.0) as usize + 1);
            if num == 0 { return err("create_track: no track fits in the die (FP-444)"); }
            self.put_tracks(TrackRec { layer: ln.clone(), dir, start, num, step, mask: x.num("-mask").map(|v| v as u32), same_mask: x.has("-same_mask") }, x.has("-add"));
            crate::info!("FP-445", "create_track: layer {} {} tracks: start {} step {} num {}{}", ln, if dir == 'X' { "X (vertical)" } else { "Y (horizontal)" }, start, step, num, x.num("-mask").map(|m| format!(" mask {}", m)).unwrap_or_default());
            made += 1;
        }
        Ok(made.to_string())
    }

    fn c_add_tracks(&mut self, a: &[String]) -> R {
        let x = args(a, &["-offsets", "-pitches", "-mask_pattern", "-layers"]);
        if self.fp.is_none() { return err("add_tracks: no floorplan (FP-001)"); }
        let die = self.fp.as_ref().unwrap().die;
        let lv = |o: &str| -> Vec<(String, char, f64)> {
            let t: Vec<String> = x.get(o).map(|s| split_list(s)).unwrap_or_default();
            t.chunks(3).filter(|c| c.len() == 3).filter_map(|c| { let d = c[1].to_lowercase(); let dir = if d.starts_with('v') || d == "x" { 'X' } else { 'Y' }; c[2].parse::<f64>().ok().map(|v| (c[0].clone(), dir, v)) }).collect()
        };
        let (offs, pits) = (lv("-offsets"), lv("-pitches"));
        let masks: Vec<String> = x.get("-mask_pattern").map(|s| split_list(s)).unwrap_or_default();
        let only: Vec<String> = x.get("-layers").map(|s| split_list(s)).unwrap_or_default();
        let layers = self.track_layers();
        if layers.is_empty() { return err("add_tracks: no routing layers (read a technology LEF) (FP-450)"); }
        self.fp.as_mut().unwrap().track_list.retain(|t| !only.is_empty() && !only.contains(&t.layer));
        let mut n = 0;
        for (ln, horiz, pitch) in layers {
            if !only.is_empty() && !only.contains(&ln) { continue; }
            let dirs: Vec<char> = if x.has("-non_preferred") { vec!['X', 'Y'] } else if horiz { vec!['Y'] } else { vec!['X'] };
            for dir in dirs {
                let step = pits.iter().find(|p| p.0 == ln && p.1 == dir).map(|p| p.2).unwrap_or(pitch);
                let (lo, hi) = if dir == 'X' { (die.0, die.2) } else { (die.1, die.3) };
                // default offset: half a pitch (tracks centred between the die edges' pitch grid)
                let off = offs.iter().find(|p| p.0 == ln && p.1 == dir).map(|p| p.2).unwrap_or(if x.has("-honor_pitch") { step } else { step / 2.0 });
                let start = lo + off;
                let num = (((hi - start) / step) + EPS).floor().max(0.0) as usize + 1;
                let mask = masks.iter().position(|m| m == &ln).and_then(|i| masks.get(i + 1)).and_then(|m| split_list(m).first().and_then(|v| v.parse::<u32>().ok()));
                self.put_tracks(TrackRec { layer: ln.clone(), dir, start, num, step, mask, same_mask: false }, true);
                n += 1;
            }
        }
        crate::info!("FP-451", "add_tracks: {} track pattern(s) on {} layer(s)", n, self.fp.as_ref().unwrap().track_list.iter().map(|t| t.layer.clone()).collect::<std::collections::BTreeSet<_>>().len());
        self.c_report_tracks()?;
        Ok(n.to_string())
    }

    fn c_delete_tracks(&mut self, a: &[String]) -> R {
        let x = args(a, &["-layer", "-layers", "-dir"]);
        let fp = self.fp.as_mut().ok_or_else(|| Flow::Err("No floorplan (FP-001)".into()))?;
        let ls: Vec<String> = opt(&x, &["-layer", "-layers"]).map(|s| split_list(s)).unwrap_or_default();
        let dir = x.get("-dir").and_then(|d| d.to_uppercase().chars().next());
        let n0 = fp.track_list.len();
        if x.has("-all") || (ls.is_empty() && dir.is_none()) { fp.track_list.clear(); } else {
            fp.track_list.retain(|t| !((ls.is_empty() || ls.contains(&t.layer)) && dir.map(|d| d == t.dir).unwrap_or(true)));
        }
        let d = n0 - fp.track_list.len();
        crate::info!("FP-452", "delete_tracks: {} track pattern(s) deleted ({} left; with none, write_def derives tracks from the layer pitches)", d, fp.track_list.len());
        Ok(d.to_string())
    }

    fn c_report_tracks(&mut self) -> R {
        let fp = self.fp.as_ref().ok_or_else(|| Flow::Err("No floorplan (FP-001)".into()))?;
        crate::out!("****************************************\nReport : tracks\n****************************************");
        if fp.track_list.is_empty() {
            crate::out!("  no explicit tracks: write_def derives one pattern per layer from the routing pitches");
            for l in &fp.layers { crate::out!("  {:<6} {} pitch {}", l.name, if l.horiz { "Y (horizontal)" } else { "X (vertical)" }, l.pitch); }
            return Ok("0".into());
        }
        crate::out!("  {:<8} {:<3} {:>10} {:>8} {:>8} {:>10} {}", "layer", "dir", "start", "step", "num", "end", "mask");
        for t in &fp.track_list {
            crate::out!("  {:<8} {:<3} {:>10.4} {:>8.4} {:>8} {:>10.4} {}", t.layer, t.dir, t.start, t.step, t.num, t.start + (t.num.max(1) - 1) as f64 * t.step, t.mask.map(|m| format!("{}{}", m, if t.same_mask { " samemask" } else { "" })).unwrap_or("-".into()));
        }
        Ok(fp.track_list.len().to_string())
    }
}
