//! Spare cells, gate-array base cells, post-mask (metal-only) ECO and netlist-diff ECO.
//!
//! Pre-mask:
//!  insert_spare_cells -cells {INV_X1_SVT 2 NAND2_X1_SVT 2 ...} [-modules pats] [-groups_per_module n]
//!                     [-tie_cell TIELO_X1_SVT] [-prefix spare] [-placement distributed|clustered]
//!  report_spare_cells
//!  insert_gate_array_fillers -cells {GFILL4 GFILL2 GFILL1} [-prefix ga_fill] [-area {..}]
//!  eco_netlist -by_verilog_file f [-apply] [-keep_physical]   (netlist diff by connectivity)
//!  eco_place [-max_displacement um]                            (new cells at their connection centroid)
//! Post-mask:
//!  set_eco_mode -post_mask true|false [-metal_layers {M2 ..}] [-allow_base_changes true|false]
//!  eco_remap_post_mask -use spare|gate_array|both [-max_distance um] [-allow_function_mapping]
//!  check_eco_mask
//!
//! Cell families come from the master name: NAND2_X1_SVT -> NAND2, GNAND2_X1 -> NAND2.

use crate::netlist::*;
use crate::session::{args, Session};
use crate::tcl::{err, split_list, Flow, R};
use std::collections::{BTreeMap, HashMap, HashSet};

#[derive(Clone, Debug, Default)]
pub struct EcoBase {
    /// physical instances: (master, x, y, orient) keyed by a location string
    pub cells: Vec<(String, String, (f64, f64), String)>, // name, master, loc, orient
    pub names: HashSet<String>,
    /// routed edges per layer key ("M2", "VIA23")
    pub edges: HashMap<String, HashSet<(u32, u32)>>,
    pub metal_layers: Vec<String>,
    pub allow_base: bool,
}

/// family of a master: strip a leading G of gate-array cells, drive / Vt suffixes
pub fn family(m: &str) -> String {
    let b = m.split('_').next().unwrap_or(m).to_uppercase();
    if b.starts_with('G') && b.len() > 2 && !b.starts_with("GFILL") && ["GINV", "GBUF", "GCLKBUF", "GNAND", "GNOR", "GAND", "GOR", "GXOR", "GXNOR", "GDFF", "GSDFF", "GMUX", "GAOI", "GOAI", "GDLH", "GTIE"].iter().any(|p| b.starts_with(p)) {
        b[1..].to_string()
    } else {
        b
    }
}
fn is_ga_fill(m: &str) -> bool {
    m.to_uppercase().starts_with("GFILL")
}

/// a parsed structural Verilog netlist
#[derive(Default, Debug)]
struct VNet {
    name: String,
    ports: Vec<String>,
    /// inst -> (master, [(pin, net)])
    insts: BTreeMap<String, (String, Vec<(String, String)>)>,
    assigns: Vec<(String, String)>,
}

fn vtoks(src: &str) -> Vec<String> {
    let b: Vec<char> = src.chars().collect();
    let mut t = vec![];
    let mut i = 0;
    while i < b.len() {
        let c = b[i];
        if c.is_whitespace() { i += 1; continue; }
        if c == '/' && b.get(i + 1) == Some(&'/') { while i < b.len() && b[i] != '\n' { i += 1; } continue; }
        if c == '/' && b.get(i + 1) == Some(&'*') { i += 2; while i + 1 < b.len() && !(b[i] == '*' && b[i + 1] == '/') { i += 1; } i += 2; continue; }
        if c == '\\' {
            let s = i + 1;
            while i < b.len() && !b[i].is_whitespace() { i += 1; }
            t.push(b[s..i].iter().collect());
            continue;
        }
        if "(),;.=[]{}:#".contains(c) { t.push(c.to_string()); i += 1; continue; }
        let s = i;
        while i < b.len() && !b[i].is_whitespace() && !"(),;.=[]{}:#".contains(b[i]) && !(b[i] == '\\') { i += 1; }
        if i == s { i += 1; continue; }
        t.push(b[s..i].iter().collect());
    }
    t
}

fn parse_vnet(src: &str) -> Result<VNet, String> {
    let t = vtoks(src);
    let mut v = VNet::default();
    let mut i = 0;
    // net expression: name | name [ idx ] | 1'b0
    let expr = |t: &[String], i: &mut usize| -> Result<String, String> {
        let mut s = t.get(*i).cloned().ok_or("unexpected end")?;
        if s == "{" { return Err("concatenations are not supported in ECO netlists".into()); }
        *i += 1;
        if t.get(*i).map(|x| x == "[").unwrap_or(false) {
            let idx = t.get(*i + 1).cloned().unwrap_or_default();
            if t.get(*i + 2).map(|x| x == ":").unwrap_or(false) { return Err(format!("part-select {}[..:..] is not supported", s)); }
            s = format!("{}[{}]", s, idx);
            *i += 3;
        }
        Ok(s)
    };
    while i < t.len() {
        match t[i].as_str() {
            "module" => {
                v.name = t.get(i + 1).cloned().unwrap_or_default();
                while i < t.len() && t[i] != ";" { i += 1; }
                i += 1;
            }
            "input" | "output" | "inout" => {
                i += 1;
                let mut range: Option<(i64, i64)> = None;
                if t.get(i).map(|x| x == "[").unwrap_or(false) {
                    let h: i64 = t[i + 1].parse().unwrap_or(0);
                    let l: i64 = t[i + 3].parse().unwrap_or(0);
                    range = Some((h, l));
                    i += 5;
                }
                while i < t.len() && t[i] != ";" {
                    if t[i] != "," {
                        match range {
                            Some((h, l)) => for k in h.min(l)..=h.max(l) { v.ports.push(format!("{}[{}]", t[i], k)); },
                            None => v.ports.push(t[i].clone()),
                        }
                    }
                    i += 1;
                }
                i += 1;
            }
            "wire" | "supply0" | "supply1" | "reg" => { while i < t.len() && t[i] != ";" { i += 1; } i += 1; }
            "assign" => {
                i += 1;
                let l = expr(&t, &mut i)?;
                if t.get(i).map(|x| x != "=").unwrap_or(true) { return Err("assign: '=' expected".into()); }
                i += 1;
                let r = expr(&t, &mut i)?;
                v.assigns.push((l, r));
                while i < t.len() && t[i] != ";" { i += 1; }
                i += 1;
            }
            "endmodule" => { i += 1; }
            _ => {
                // instance: MASTER [#(..)] NAME ( .P(n), ... ) ;
                let master = t[i].clone();
                i += 1;
                if t.get(i).map(|x| x == "#").unwrap_or(false) {
                    let mut d = 0;
                    i += 1;
                    loop {
                        match t.get(i).map(|s| s.as_str()) { Some("(") => d += 1, Some(")") => { d -= 1; if d == 0 { i += 1; break; } } None => break, _ => {} }
                        i += 1;
                    }
                }
                let inst = t.get(i).cloned().ok_or("instance name expected")?;
                i += 1;
                if t.get(i).map(|x| x != "(").unwrap_or(true) { return Err(format!("'(' expected after instance {}", inst)); }
                i += 1;
                let mut pins = vec![];
                while i < t.len() && t[i] != ")" {
                    if t[i] == "." {
                        let pn = t[i + 1].clone();
                        i += 3; // . name (
                        if t.get(i).map(|x| x == ")").unwrap_or(false) { i += 1; continue; }
                        let n = expr(&t, &mut i)?;
                        pins.push((pn, n));
                        if t.get(i).map(|x| x == ")").unwrap_or(false) { i += 1; }
                    } else {
                        if t[i] != "," { return Err(format!("instance {}: only named port connections are supported", inst)); }
                        i += 1;
                    }
                }
                i += 1;
                if t.get(i).map(|x| x == ";").unwrap_or(false) { i += 1; }
                v.insts.insert(inst, (master, pins));
            }
        }
    }
    Ok(v)
}

/// union-find over strings
struct Uf(HashMap<String, String>);
impl Uf {
    fn find(&mut self, a: &str) -> String {
        let p = self.0.get(a).cloned().unwrap_or(a.to_string());
        if p == a { return p; }
        let r = self.find(&p);
        self.0.insert(a.to_string(), r.clone());
        r
    }
    fn union(&mut self, a: &str, b: &str) {
        let (x, y) = (self.find(a), self.find(b));
        if x != y {
            // constants and ports win as group representatives
            let (k, r) = if y.starts_with("1'b") { (x, y) } else { (y, x) };
            self.0.insert(k, r);
        }
    }
}

impl Session {
    pub fn ecomask_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "insert_spare_cells" | "add_spare_cells" => self.c_spares(a),
            "report_spare_cells" => self.c_report_spares(a),
            "insert_gate_array_fillers" | "add_gate_array_cells" => self.c_ga_fill(a),
            "set_eco_mode" => self.c_eco_mode(a),
            "eco_remap_post_mask" | "map_eco_to_spares" | "eco_map_spare_cells" => self.c_remap(a),
            "check_eco_mask" | "report_eco_mask" => self.c_check_mask(a),
            "eco_netlist" | "eco_update_netlist" => self.c_eco_netlist(a),
            "eco_place" | "place_eco_cells" => self.c_eco_place(a),
            _ => return None,
        })
    }

    pub(crate) fn gr_cache_clear(&self) {
        *self.gr_cache.borrow_mut() = None;
    }

    fn lib_cell(&self, m: &str) -> Option<&crate::liberty::LibCell> {
        self.libs.iter().find_map(|l| l.cells.get(m))
    }
    fn cell_w(&self, m: &str) -> f64 {
        let rh = self.row_h();
        let sw = self.site_w();
        let a = self.lib_cell(m).map(|c| c.area).unwrap_or(rh * sw);
        ((a / rh / sw).ceil().max(1.0)) * sw
    }
    /// connection centroid of a cell (placed neighbours only)
    fn conn_centroid(&self, c: CellId) -> Option<(f64, f64)> {
        let nl = self.nl.as_ref()?;
        let mut s = (0.0, 0.0, 0usize);
        for p in &nl.cell(c).pins {
            let Some(n) = p.net else { continue };
            for q in Session::leaf_conns(nl, n) {
                match q {
                    PinRef::Cell(o, _) if o != c && !nl.cell(o).is_hport() => if let Some(l) = nl.cell(o).loc { s.0 += l.0; s.1 += l.1; s.2 += 1; },
                    PinRef::Port(pt) => if let Some(l) = nl.ports[pt].loc { s.0 += l.0; s.1 += l.1; s.2 += 1; },
                    _ => {}
                }
            }
        }
        if s.2 == 0 { None } else { Some((s.0 / s.2 as f64, s.1 / s.2 as f64)) }
    }
    /// free row space test against fixed rectangles and planned cells
    fn occupied_rects(&self) -> Vec<(f64, f64, f64, f64)> {
        let nl = self.nl.as_ref().unwrap();
        let rh = self.row_h();
        let mut v = vec![];
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.is_hport() || matches!(cl.kind, Kind::Gen(_)) { continue; }
            if let Some(r) = crate::lef::cell_rect(&self.lef, cl) { v.push(r); continue; }
            let Some(l) = cl.loc else { continue };
            if matches!(cl.kind, Kind::BlackBox(_)) {
                let s = { let m = self.appf("place.macro_default_size"); if m > 0.0 { m } else { 16.0 } };
                v.push((l.0 - s / 2.0, l.1 - s / 2.0, l.0 + s / 2.0, l.1 + s / 2.0));
            } else if cl.fixed {
                let w = cl.lib().map(|m| self.cell_w(m)).unwrap_or(0.2);
                v.push((l.0 - w / 2.0, l.1 - rh / 2.0, l.0 + w / 2.0, l.1 + rh / 2.0));
            }
        }
        if let Some(fp) = self.fp.as_ref() {
            for b in &fp.pblk {
                if matches!(b.kind, crate::fplan::PbKind::Hard | crate::fplan::PbKind::HardMacro) { v.push(b.rect); }
            }
        }
        v
    }

    /// legal spot for a `w`-wide single-row cell near `p`: (centre)
    fn find_site(&self, p: (f64, f64), w: f64, occ: &[(f64, f64, f64, f64)]) -> Option<(f64, f64)> {
        let fp = self.fp.as_ref()?;
        let reg = fp.place_region();
        let (rh, sw) = (self.row_h(), self.site_w());
        // legal rows: the legalizer builds rows over the region minus one row at each edge
        let core = (reg.0 + if fp.core.is_some() { 0.0 } else { rh }, reg.1 + if fp.core.is_some() { 0.0 } else { rh }, reg.2 - if fp.core.is_some() { 0.0 } else { rh }, reg.3 - if fp.core.is_some() { 0.0 } else { rh });
        let nrows = ((core.3 - core.1) / rh).floor() as i64;
        let nsites = ((core.2 - core.0) / sw).floor() as i64;
        let ws = (w / sw).round() as i64;
        let r0 = (((p.1 - core.1) / rh).floor() as i64).clamp(0, nrows - 1);
        let s0 = (((p.0 - w / 2.0 - core.0) / sw).round() as i64).clamp(0, (nsites - ws).max(0));
        let free = |r: i64, s: i64| -> bool {
            if s < 0 || s + ws > nsites || r < 0 || r >= nrows { return false; }
            let x0 = core.0 + s as f64 * sw;
            let y0 = core.1 + r as f64 * rh;
            let rr = (x0 + 1e-3, y0 + 1e-3, x0 + w - 1e-3, y0 + rh - 1e-3);
            !occ.iter().any(|o| rr.0 < o.2 && o.0 < rr.2 && rr.1 < o.3 && o.1 < rr.3)
        };
        for d in 0..(nrows.max(nsites)) {
            for dr in -d.min(nrows)..=d.min(nrows) {
                let rem = d - dr.abs();
                for ds in [-rem * 1, rem] {
                    let (r, s) = (r0 + dr, s0 + ds * 1);
                    if free(r, s) {
                        return Some((core.0 + s as f64 * sw + w / 2.0, core.1 + r as f64 * rh + rh / 2.0));
                    }
                }
            }
            if d > 4000 { break; }
        }
        None
    }

    // ------------------------------------------------------------------ spare cells
    fn c_spares(&mut self, a: &[String]) -> R {
        let x = args(a, &["-cells", "-modules", "-groups_per_module", "-tie_cell", "-prefix", "-placement", "-level"]);
        let spec = split_list(x.get("-cells").map(|s| s.as_str()).ok_or_else(|| Flow::Err("insert_spare_cells: -cells {cell count ...} required (CMD-001)".into()))?);
        let mut cells: Vec<(String, usize)> = vec![];
        let mut k = 0;
        while k < spec.len() {
            let m = spec[k].clone();
            let n = spec.get(k + 1).and_then(|s| s.parse::<usize>().ok());
            k += if n.is_some() { 2 } else { 1 };
            if self.lib_cell(&m).is_none() {
                return err(&format!("insert_spare_cells: lib cell '{}' not found (ECO-501)", m));
            }
            cells.push((m, n.unwrap_or(1)));
        }
        let tie = x.get("-tie_cell").cloned().or_else(|| {
            let mut v: Vec<&String> = self.libs.iter().flat_map(|l| l.cells.keys()).filter(|n| n.to_uppercase().starts_with("TIELO") || n.to_uppercase().starts_with("LOGIC0")).collect();
            v.sort();
            v.first().map(|s| s.to_string())
        });
        let prefix = x.get("-prefix").cloned().unwrap_or("spare".into());
        let gpm = x.get("-groups_per_module").and_then(|s| s.parse::<usize>().ok()).unwrap_or(1).max(1);
        let clustered = x.get("-placement").map(|s| s == "clustered").unwrap_or(false);
        let nl = self.nl()?;
        // modules: first hierarchy level of the cell names
        let mut mods: Vec<String> = match x.get("-modules") {
            Some(m) => split_list(m),
            None => {
                let mut s: Vec<String> = nl.cell_ids().into_iter().filter_map(|c| nl.cell(c).name.split_once('/').map(|p| p.0.to_string())).collect::<HashSet<_>>().into_iter().collect();
                s.retain(|m| !m.starts_with(&prefix));
                s.sort();
                if s.is_empty() { s.push(String::new()); }
                s
            }
        };
        mods.dedup();
        let placed = self.fp.is_some();
        // region per module: resolved bound, else bbox of its placed cells, else the core
        let region_of = |m: &str| -> Option<(f64, f64, f64, f64)> {
            let fp = self.fp.as_ref()?;
            if let Some(b) = fp.bounds.iter().find(|b| b.resolved.is_some() && b.members.iter().any(|q| q == m || glob(q, &format!("{}/x", m)))) { return b.resolved; }
            let pts: Vec<(f64, f64)> = nl.cell_ids().into_iter().filter(|c| m.is_empty() || nl.cell(*c).name.starts_with(&format!("{}/", m))).filter_map(|c| nl.cell(c).loc).collect();
            if pts.len() >= 3 {
                return Some((pts.iter().map(|p| p.0).fold(f64::MAX, f64::min), pts.iter().map(|p| p.1).fold(f64::MAX, f64::min), pts.iter().map(|p| p.0).fold(f64::MIN, f64::max), pts.iter().map(|p| p.1).fold(f64::MIN, f64::max)));
            }
            Some(fp.place_region())
        };
        let mut plan: Vec<(String, String, Vec<(String, String)>, Option<(f64, f64)>)> = vec![]; // group, module, [(inst, master)], anchor
        for (mi, m) in mods.iter().enumerate() {
            let reg = region_of(m);
            for g in 0..gpm {
                let grp = if m.is_empty() { format!("{}_{}", prefix, g) } else { format!("{}/{}_{}", m, prefix, g) };
                let mut insts = vec![];
                for (master, n) in &cells {
                    for i in 0..*n {
                        insts.push((format!("{}/{}_{}", grp, family(master).to_lowercase(), i), master.clone()));
                    }
                }
                if let Some(t) = &tie { insts.push((format!("{}/tielo", grp), t.clone())); }
                // anchor: lattice point g of the region (distributed) or its centre (clustered)
                let anchor = reg.map(|r| {
                    if clustered || gpm == 1 {
                        // spread modules' single groups a little so they do not collide at a shared centre
                        let f = (mi as f64 * 0.618).fract() * 0.2 - 0.1;
                        ((r.0 + r.2) / 2.0 + f * (r.2 - r.0), (r.1 + r.3) / 2.0)
                    } else {
                        let k = (gpm as f64).sqrt().ceil() as usize;
                        let (gx, gy) = (g % k, g / k);
                        (r.0 + (gx as f64 + 0.5) / k as f64 * (r.2 - r.0), r.1 + (gy as f64 + 0.5) / ((gpm + k - 1) / k) as f64 * (r.3 - r.1))
                    }
                });
                plan.push((grp, m.clone(), insts, anchor));
            }
        }
        // ---- create, connect and place
        let mut total = 0;
        let mut occ = if placed { self.occupied_rects() } else { vec![] };
        let rh = self.row_h();
        let mut unplaced = 0;
        for (grp, _m, insts, anchor) in &plan {
            let tie_net = tie.as_ref().map(|_| { let nl = self.nl.as_mut().unwrap(); nl.add_net(&format!("{}/tie_lo", grp)) });
            for (inst, master) in insts {
                if self.nl.as_ref().unwrap().cell_by_name(inst).is_some() {
                    return err(&format!("insert_spare_cells: '{}' exists (ECO-502)", inst));
                }
                let c = self.make_inst(inst, master)?;
                let is_tie = Some(master) == tie.as_ref() && inst.ends_with("/tielo");
                let w = self.cell_w(master);
                let loc = anchor.and_then(|p| self.find_site(p, w, &occ));
                let nl = self.nl.as_mut().unwrap();
                let pins: Vec<(usize, Dir)> = nl.cell(c).pins.iter().enumerate().map(|(i, p)| (i, p.dir)).collect();
                for (i, d) in pins {
                    match (d, tie_net) {
                        (Dir::In, Some(tn)) if !is_tie => nl.connect(c, i, tn),
                        (Dir::Out, Some(tn)) if is_tie => nl.connect(c, i, tn),
                        _ => {}
                    }
                }
                let cl = nl.cell_mut(c);
                cl.dont_touch = true;
                cl.attrs.push("spare".into());
                cl.attrs.push(format!("spare_group:{}", grp));
                if let Some(l) = loc {
                    cl.loc = Some(l);
                    cl.fixed = true;
                    occ.push((l.0 - w / 2.0, l.1 - rh / 2.0, l.0 + w / 2.0, l.1 + rh / 2.0));
                } else if placed {
                    unplaced += 1;
                }
                total += 1;
            }
        }
        if let Some(tn) = plan.first().map(|p| p.0.clone()) { let _ = tn; }
        self.eco_changes.push(format!("insert_spare_cells -cells {{{}}} -groups_per_module {}", spec.join(" "), gpm));
        crate::info!("ECO-500", "Inserted {} spare cell(s) in {} spare group(s) over {} module(s){}; inputs tied low{}, outputs open, dont_touch{}",
            total, plan.len(), mods.len(), if clustered { " (clustered)" } else { "" }, tie.map(|t| format!(" via {}", t)).unwrap_or_else(|| " (no tie cell)".into()),
            if placed { format!(", pre-placed and fixed{}", if unplaced > 0 { format!(" ({} without a free site)", unplaced) } else { String::new() }) } else { String::new() });
        Ok(total.to_string())
    }

    fn spare_used(nl: &Netlist, c: CellId) -> bool {
        nl.cell(c).pins.iter().any(|p| p.dir == Dir::Out && p.net.map(|n| !nl.loads(n).is_empty()).unwrap_or(false))
            && !nl.cell(c).name.ends_with("/tielo")
    }

    fn c_report_spares(&mut self, _a: &[String]) -> R {
        let nl = self.nl()?;
        let mut by: BTreeMap<(String, String), (usize, usize)> = BTreeMap::new();
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            let Some(g) = cl.attrs.iter().find_map(|a| a.strip_prefix("spare_group:")) else { continue };
            if cl.name.ends_with("/tielo") { continue; }
            let m = g.rsplit_once('/').map(|x| x.0).unwrap_or("(top)").to_string();
            let e = by.entry((m, family(cl.lib().unwrap_or("?")))).or_default();
            e.0 += 1;
            if Session::spare_used(nl, c) || cl.attrs.iter().any(|a| a == "spare_used") { e.1 += 1; }
        }
        crate::out!("****************************************\nReport : spare_cells\n****************************************");
        crate::out!("{:<24} {:<8} {:>6} {:>6} {:>6}", "Module", "Family", "Total", "Used", "Free");
        let (mut t, mut u) = (0, 0);
        for ((m, f), (n, k)) in &by {
            crate::out!("{:<24} {:<8} {:>6} {:>6} {:>6}", m, f, n, k, n - k);
            t += n; u += k;
        }
        crate::out!("{:<24} {:<8} {:>6} {:>6} {:>6}", "total", "", t, u, t - u);
        Ok(format!("{} {}", t, u))
    }

    // ------------------------------------------------------------------ gate-array base fill
    fn c_ga_fill(&mut self, a: &[String]) -> R {
        let x = args(a, &["-cells", "-prefix", "-area"]);
        let mut fc: Vec<(String, f64)> = x.get("-cells").map(|s| split_list(s)).unwrap_or_else(|| vec!["GFILL4".into(), "GFILL2".into(), "GFILL1".into()])
            .into_iter().map(|m| { let w = self.cell_w(&m); (m, w) }).collect();
        for (m, _) in &fc {
            if self.lib_cell(m).is_none() { return err(&format!("insert_gate_array_fillers: '{}' not in any library (ECO-510)", m)); }
        }
        fc.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
        let unit = fc.last().map(|f| f.1).unwrap_or(0.8);
        let prefix = x.get("-prefix").cloned().unwrap_or("ga_fill".into());
        let fp = self.fp.clone().ok_or_else(|| Flow::Err("insert_gate_array_fillers: no floorplan (FP-001)".into()))?;
        let reg = fp.place_region();
        let rh = self.row_h();
        let core = if fp.core.is_some() { reg } else { (reg.0 + rh, reg.1 + rh, reg.2 - rh, reg.3 - rh) };
        let area = x.get("-area").and_then(|s| crate::fpcmd::parse_rect(s)).unwrap_or(core);
        let occ = self.occupied_rects();
        // + every placed standard cell
        let nl = self.nl.as_ref().unwrap();
        let mut blk: Vec<(f64, f64, f64, f64)> = occ;
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.fixed || cl.is_hport() || !matches!(cl.kind, Kind::Lib(_)) || crate::lef::cell_rect(&self.lef, cl).is_some() { continue; }
            if let Some(l) = cl.loc { let w = self.cell_w(cl.lib().unwrap()); blk.push((l.0 - w / 2.0, l.1 - rh / 2.0, l.0 + w / 2.0, l.1 + rh / 2.0)); }
        }
        let nrows = ((core.3 - core.1) / rh + 1e-6).floor() as usize;
        let mut n = 0;
        let mut fa = 0.0;
        let mut k = 0usize;
        let mut adds: Vec<(String, String, (f64, f64))> = vec![];
        for r in 0..nrows {
            let y0 = core.1 + r as f64 * rh;
            if y0 < area.1 - 1e-6 || y0 + rh > area.3 + 1e-6 { continue; }
            let mut iv: Vec<(f64, f64)> = blk.iter().filter(|b| b.1 < y0 + rh - 1e-3 && b.3 > y0 + 1e-3).map(|b| (b.0, b.2)).collect();
            iv.sort_by(|a, b| a.partial_cmp(b).unwrap());
            let mut cur = area.0.max(core.0);
            let end = area.2.min(core.2);
            let mut gaps = vec![];
            for (a0, a1) in iv {
                if a0 > cur { gaps.push((cur, a0.min(end))); }
                cur = cur.max(a1);
            }
            if cur < end { gaps.push((cur, end)); }
            for (g0, g1) in gaps {
                // align to the gate-array grid (from the core origin)
                let mut p = core.0 + ((g0 - core.0) / unit - 1e-6).ceil() * unit;
                for (m, w) in &fc {
                    while p + w <= g1 + 1e-6 {
                        k += 1;
                        adds.push((format!("{}_{}", prefix, k), m.clone(), (p + w / 2.0, y0 + rh / 2.0)));
                        p += w;
                        fa += w * rh;
                        n += 1;
                    }
                }
            }
        }
        for (nm, m, l) in adds {
            let c = self.make_inst(&nm, &m)?;
            let cl = self.nl.as_mut().unwrap().cell_mut(c);
            cl.loc = Some(l);
            cl.fixed = true;
            cl.dont_touch = true;
            cl.attrs.push("ga_base".into());
        }
        crate::info!("ECO-511", "Inserted {} gate-array base filler(s) ({:.1} um^2, unit {:.2} um) for post-mask metal-only ECO", n, fa, unit);
        Ok(n.to_string())
    }

    // ------------------------------------------------------------------ post-mask mode
    fn route_edges(&self) -> HashMap<String, HashSet<(u32, u32)>> {
        let mut m: HashMap<String, HashSet<(u32, u32)>> = HashMap::new();
        if let Some(db) = self.routes.as_ref() {
            for r in db.nets.values() {
                for (c, p) in &r.tree {
                    if *p == crate::droute::NONE { continue; }
                    let (_, _, l1) = db.xyl(*c);
                    let (_, _, l2) = db.xyl(*p);
                    let key = if l1 == l2 { db.layers[l1].name.clone() } else { format!("VIA{}{}", l1.min(l2) + 1, l1.max(l2) + 1) };
                    m.entry(key).or_default().insert((*c.min(p), *c.max(p)));
                }
            }
        }
        m
    }

    fn c_eco_mode(&mut self, a: &[String]) -> R {
        let x = args(a, &["-post_mask", "-metal_layers", "-allow_base_changes"]);
        let on = x.get("-post_mask").map(|s| matches!(s.as_str(), "true" | "1" | "on")).unwrap_or(true);
        if !on {
            self.eco_base = None;
            crate::info!("ECO-520", "Post-mask ECO mode off (pre-mask: all layers may change)");
            return Ok("0".into());
        }
        let nl = self.nl()?;
        let mut cells = vec![];
        let mut names = HashSet::new();
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.is_hport() || matches!(cl.kind, Kind::Gen(_)) { continue; }
            names.insert(cl.name.clone());
            if let (Some(l), Some(m)) = (cl.loc, crate::lef::master(cl)) {
                cells.push((cl.name.clone(), m.to_string(), l, crate::lef::orient_of(cl).to_string()));
            }
        }
        let all: Vec<String> = self.route_layers().iter().map(|l| l.name.clone()).collect();
        let ml: Vec<String> = x.get("-metal_layers").map(|s| split_list(s)).unwrap_or_else(|| all.clone());
        let allow = x.get("-allow_base_changes").map(|s| matches!(s.as_str(), "true" | "1")).unwrap_or(false);
        let edges = self.route_edges();
        let ne: usize = edges.values().map(|s| s.len()).sum();
        crate::info!("ECO-521", "Post-mask ECO mode: base frozen ({} placed instance(s), {} routed edge(s)); changeable masks: {}{}",
            cells.len(), ne, ml.join(" "), if allow { "; base-layer (FEOL) changes allowed (BEOL+FEOL ECO)" } else { "; metal-only (BEOL) ECO" });
        self.eco_base = Some(EcoBase { cells, names, edges, metal_layers: ml, allow_base: allow });
        Ok("1".into())
    }

    /// family -> spare masters that can implement it (with input mapping)
    fn spare_options(fam: &str, allow_fn: bool) -> Vec<(String, bool)> {
        let mut v = vec![(fam.to_string(), false)];
        if allow_fn {
            match fam {
                "INV" => { v.push(("NAND2".into(), true)); v.push(("NOR2".into(), true)); }
                "BUF" => { v.push(("AND2".into(), true)); v.push(("OR2".into(), true)); }
                "DFF" => v.push(("SDFF".into(), false)),
                _ => {}
            }
        }
        v
    }

    /// move every connection of `from` onto `to` (pins by name; `tie_all` connects all inputs
    /// of `to` to the single input net of `from`)
    fn rewire(&mut self, from: CellId, to: CellId, tie_all: bool) -> Result<(), String> {
        let nl = self.nl.as_mut().unwrap();
        let fcl = nl.cell(from).clone();
        let tcl = nl.cell(to).clone();
        for (i, p) in tcl.pins.iter().enumerate() {
            if p.net.is_some() { nl.disconnect(to, i); }
        }
        let fin: Vec<&Pin> = fcl.pins.iter().filter(|p| p.dir == Dir::In).collect();
        let tin: Vec<(usize, &Pin)> = tcl.pins.iter().enumerate().filter(|(_, p)| p.dir == Dir::In).collect();
        let tout: Vec<(usize, &Pin)> = tcl.pins.iter().enumerate().filter(|(_, p)| p.dir == Dir::Out).collect();
        // outputs
        for p in fcl.pins.iter().filter(|p| p.dir == Dir::Out) {
            let Some(n) = p.net else { continue };
            let j = tout.iter().find(|(_, q)| q.name == p.name).or(tout.first()).map(|x| x.0).ok_or("no output pin")?;
            let fi = fcl.pins.iter().position(|q| q.name == p.name).unwrap();
            nl.disconnect(from, fi);
            nl.connect(to, j, n);
        }
        if tie_all {
            let n = fin.first().and_then(|p| p.net).ok_or("no input net")?;
            for p in fcl.pins.iter().enumerate().filter(|(_, p)| p.dir == Dir::In) { if p.1.net.is_some() { nl.disconnect(from, p.0); } }
            for (j, _) in &tin { nl.connect(to, *j, n); }
        } else {
            for (k, p) in fin.iter().enumerate() {
                let Some(n) = p.net else { continue };
                let j = tin.iter().find(|(_, q)| q.name == p.name).or(tin.get(k)).map(|x| x.0).ok_or(format!("no input pin for {}", p.name))?;
                let fi = fcl.pins.iter().position(|q| q.name == p.name).unwrap();
                nl.disconnect(from, fi);
                nl.connect(to, j, n);
            }
        }
        Ok(())
    }

    fn c_remap(&mut self, a: &[String]) -> R {
        let x = args(a, &["-use", "-max_distance"]);
        let use_ = x.get("-use").cloned().unwrap_or("both".into());
        if !["spare", "gate_array", "both"].contains(&use_.as_str()) {
            return err("eco_remap_post_mask: -use spare|gate_array|both (CMD-001)");
        }
        let maxd = x.num("-max_distance").unwrap_or(f64::MAX);
        let allow_fn = x.has("-allow_function_mapping");
        let base = self.eco_base.clone().ok_or_else(|| Flow::Err("eco_remap_post_mask: not in post-mask mode (set_eco_mode -post_mask true) (ECO-530)".into()))?;
        let nl = self.nl()?;
        // ECO cells: lib cells not in the frozen base
        let mut new: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| {
            let cl = nl.cell(*c);
            !base.names.contains(&cl.name) && matches!(cl.kind, Kind::Lib(_)) && !cl.attrs.iter().any(|a| a == "spare" || a == "ga_base" || a == "ga_cell")
        }).collect();
        new.sort_by_key(|c| nl.cell(*c).name.clone());
        let rh = self.row_h();
        let (mut n_sp, mut n_ga, mut fail) = (0, 0, vec![]);
        let mut used_spares: HashSet<CellId> = HashSet::new();
        let mut log = vec![];
        for c in new {
            let nl = self.nl.as_ref().unwrap();
            let cl = nl.cell(c).clone();
            let fam = family(cl.lib().unwrap());
            let at = self.conn_centroid(c).or(cl.loc).unwrap_or((0.0, 0.0));
            // ---- spare cell
            let mut done = false;
            if use_ != "gate_array" {
                let opts = Session::spare_options(&fam, allow_fn);
                let best = nl.cell_ids().into_iter().filter(|s| {
                    let sc = nl.cell(*s);
                    sc.attrs.iter().any(|a| a == "spare") && !sc.name.ends_with("/tielo") && !used_spares.contains(s) && !Session::spare_used(nl, *s) && !sc.attrs.iter().any(|a| a == "spare_used") && sc.loc.is_some()
                        && opts.iter().any(|(f, _)| family(sc.lib().unwrap_or("")) == *f)
                }).map(|s| {
                    let l = nl.cell(s).loc.unwrap();
                    let exact = family(nl.cell(s).lib().unwrap_or("")) == fam;
                    let d = (l.0 - at.0).abs() + (l.1 - at.1).abs();
                    // an exact spare is preferred over a function-mapped one up to 50 um farther
                    (s, d, d + if exact { 0.0 } else { 50.0 })
                })
                    .filter(|(_, d, _)| *d <= maxd).min_by(|a, b| a.2.partial_cmp(&b.2).unwrap()).map(|(s, d, _)| (s, d));
                if let Some((s, d)) = best {
                    let sf = family(nl.cell(s).lib().unwrap());
                    let tie_all = opts.iter().find(|o| o.0 == sf).map(|o| o.1).unwrap_or(false);
                    let sname = nl.cell(s).name.clone();
                    self.rewire(c, s, tie_all).map_err(|e| Flow::Err(format!("eco_remap_post_mask: {}: {} (ECO-531)", cl.name, e)))?;
                    let nlm = self.nl.as_mut().unwrap();
                    nlm.cell_mut(s).attrs.push("spare_used".into());
                    nlm.remove_cell(c);
                    used_spares.insert(s);
                    log.push(format!("{} ({}) -> spare {} ({:.1} um){}", cl.name, cl.lib().unwrap(), sname, d, if tie_all { " [function-mapped]" } else { "" }));
                    n_sp += 1;
                    done = true;
                }
            }
            // ---- gate-array base cell
            if !done && use_ != "spare" {
                let ga = self.libs.iter().flat_map(|l| l.cells.keys()).filter(|m| m.to_uppercase().starts_with('G') && !is_ga_fill(m) && family(m) == fam).min_by(|a, b| self.cell_w(a).partial_cmp(&self.cell_w(b)).unwrap()).cloned();
                if let Some(gm) = ga {
                    let need = self.cell_w(&gm);
                    // GFILL runs: rows of abutting base fillers
                    let nl = self.nl.as_ref().unwrap();
                    let mut fills: Vec<(f64, f64, f64, CellId)> = nl.cell_ids().into_iter().filter(|f| nl.cell(*f).attrs.iter().any(|a| a == "ga_base") && nl.cell(*f).lib().map(is_ga_fill).unwrap_or(false))
                        .filter_map(|f| { let l = nl.cell(f).loc?; let w = self.cell_w(nl.cell(f).lib()?); Some((l.1, l.0 - w / 2.0, l.0 + w / 2.0, f)) }).collect();
                    fills.sort_by(|a, b| (a.0, a.1).partial_cmp(&(b.0, b.1)).unwrap());
                    let mut best: Option<(f64, Vec<CellId>, f64, f64)> = None; // dist, cells, x0, y
                    let mut i = 0;
                    while i < fills.len() {
                        // grow a window [i..j) of abutting fillers until it is wide enough
                        let mut j = i;
                        let mut w = 0.0;
                        while j < fills.len() && fills[j].0 == fills[i].0 && (j == i || (fills[j].1 - fills[j - 1].2).abs() < 1e-6) && w < need - 1e-6 {
                            w += fills[j].2 - fills[j].1;
                            j += 1;
                        }
                        if w >= need - 1e-6 {
                            let cx = fills[i].1 + need / 2.0;
                            let d = (cx - at.0).abs() + (fills[i].0 - at.1).abs();
                            if d <= maxd && best.as_ref().map(|b| d < b.0).unwrap_or(true) {
                                best = Some((d, fills[i..j].iter().map(|f| f.3).collect(), fills[i].1, fills[i].0));
                            }
                        }
                        i += 1;
                    }
                    if let Some((d, used, x0, y)) = best {
                        let span: f64 = used.iter().map(|f| self.cell_w(self.nl.as_ref().unwrap().cell(*f).lib().unwrap())).sum();
                        let fill_masters: Vec<(String, f64)> = { let mut v: Vec<(String, f64)> = self.libs.iter().flat_map(|l| l.cells.keys()).filter(|m| is_ga_fill(m)).map(|m| (m.clone(), self.cell_w(m))).collect(); v.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap()); v.dedup(); v };
                        let nm = format!("{}_ga", cl.name);
                        let g = self.make_inst(&nm, &gm)?;
                        self.rewire(c, g, false).map_err(|e| Flow::Err(format!("eco_remap_post_mask: {}: {} (ECO-531)", cl.name, e)))?;
                        let nlm = self.nl.as_mut().unwrap();
                        for f in &used { nlm.remove_cell(*f); }
                        nlm.remove_cell(c);
                        let gc = nlm.cell_mut(g);
                        gc.loc = Some((x0 + need / 2.0, y));
                        gc.fixed = true;
                        gc.dont_touch = true;
                        gc.attrs.push("ga_cell".into());
                        // refill the rest of the consumed span
                        let mut p = x0 + need;
                        let end = x0 + span;
                        let mut k = 0;
                        for (fm, fw) in &fill_masters {
                            while p + fw <= end + 1e-6 {
                                k += 1;
                                let fname = format!("{}_refill{}", nm, k);
                                let f = self.make_inst(&fname, fm)?;
                                let fc = self.nl.as_mut().unwrap().cell_mut(f);
                                fc.loc = Some((p + fw / 2.0, y));
                                fc.fixed = true;
                                fc.dont_touch = true;
                                fc.attrs.push("ga_base".into());
                                p += fw;
                            }
                        }
                        log.push(format!("{} ({}) -> gate array {} {} ({:.1} um, {} base filler(s) used)", cl.name, cl.lib().unwrap(), gm, nm, d, used.len()));
                        n_ga += 1;
                        done = true;
                    }
                }
            }
            if !done {
                fail.push(format!("{} ({})", cl.name, cl.lib().unwrap()));
            }
            let _ = rh;
        }
        for l in &log { crate::out!("  {}", l); }
        for f in &fail { crate::out!("  UNMAPPED {}", f); }
        self.eco_changes.push(format!("eco_remap_post_mask -use {}", use_));
        crate::info!("ECO-532", "Post-mask remap: {} ECO cell(s) -> {} spare cell(s), {} gate-array cell(s); {} unmapped", n_sp + n_ga + fail.len(), n_sp, n_ga, fail.len());
        if !fail.is_empty() {
            crate::warn!("ECO-533", "{} ECO cell(s) have no free spare / base cell: {}", fail.len(), fail.join(", "));
        }
        Ok(format!("{} {} {}", n_sp, n_ga, fail.len()))
    }

    fn c_check_mask(&mut self, a: &[String]) -> R {
        let x = args(a, &["-metal_layers"]);
        let mut base = self.eco_base.clone().ok_or_else(|| Flow::Err("check_eco_mask: not in post-mask mode (set_eco_mode -post_mask true) (ECO-530)".into()))?;
        if let Some(m) = x.get("-metal_layers") { base.metal_layers = split_list(m); }
        let nl = self.nl()?;
        let key = |m: &str, l: (f64, f64), o: &str| format!("{}@{:.3},{:.3},{}", m, l.0, l.1, o);
        let bset: HashMap<String, (String, String, (f64, f64))> = base.cells.iter().map(|(n, m, l, o)| (key(m, *l, o), (n.clone(), m.clone(), *l))).collect();
        let mut cur: HashMap<String, (String, String, (f64, f64), bool)> = HashMap::new();
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.is_hport() || matches!(cl.kind, Kind::Gen(_)) { continue; }
            if let (Some(l), Some(m)) = (cl.loc, crate::lef::master(cl)) {
                cur.insert(key(m, l, crate::lef::orient_of(cl)), (cl.name.clone(), m.to_string(), l, cl.attrs.iter().any(|a| a == "ga_cell" || a == "ga_base")));
            }
        }
        let removed: Vec<&(String, String, (f64, f64))> = bset.iter().filter(|(k, _)| !cur.contains_key(*k)).map(|(_, v)| v).collect();
        let added: Vec<&(String, String, (f64, f64), bool)> = cur.iter().filter(|(k, _)| !bset.contains_key(*k)).map(|(_, v)| v).collect();
        // gate-array conversions: base fillers removed, G* / refill cells added inside their span
        let rh = self.row_h();
        let ga_spans: Vec<(f64, f64, f64)> = removed.iter().filter(|r| is_ga_fill(&r.1)).map(|r| { let w = self.cell_w(&r.1); (r.2 .1, r.2 .0 - w / 2.0, r.2 .0 + w / 2.0) }).collect();
        let in_span = |m: &str, l: (f64, f64)| -> bool {
            let w = self.cell_w(m);
            let (x0, x1) = (l.0 - w / 2.0, l.0 + w / 2.0);
            // covered by the union of removed base fillers in that row
            let mut iv: Vec<(f64, f64)> = ga_spans.iter().filter(|s| (s.0 - l.1).abs() < 1e-6).map(|s| (s.1, s.2)).collect();
            iv.sort_by(|a, b| a.partial_cmp(b).unwrap());
            let mut cur = x0;
            for (a, b) in iv { if a <= cur + 1e-6 && b > cur { cur = b; } }
            cur >= x1 - 1e-6
        };
        let mut viol: Vec<String> = vec![];
        let mut ga_ok = 0;
        for a in &added {
            if a.3 && in_span(&a.1, a.2) { ga_ok += 1; continue; }
            viol.push(format!("ECO-MASK-001 base change: instance {} ({}) added at ({:.2}, {:.2})", a.0, a.1, a.2 .0, a.2 .1));
        }
        for r in &removed {
            if is_ga_fill(&r.1) { continue; }
            viol.push(format!("ECO-MASK-002 base change: instance {} ({}) removed / moved / changed from ({:.2}, {:.2})", r.0, r.1, r.2 .0, r.2 .1));
        }
        // routing masks
        let now = self.route_edges();
        let mut keys: Vec<String> = base.edges.keys().chain(now.keys()).cloned().collect::<HashSet<_>>().into_iter().collect();
        keys.sort();
        let mut changed_masks: Vec<(String, usize, bool)> = vec![];
        let empty = HashSet::new();
        for k in &keys {
            let b = base.edges.get(k).unwrap_or(&empty);
            let c = now.get(k).unwrap_or(&empty);
            let d = b.symmetric_difference(c).count();
            if d == 0 { continue; }
            // a via layer may change when the metal above it may
            let allowed = if let Some(v) = k.strip_prefix("VIA") {
                let up = v.chars().nth(1).and_then(|c| c.to_digit(10)).map(|u| format!("M{}", u)).unwrap_or_default();
                base.metal_layers.iter().any(|m| m == k || *m == up)
            } else { base.metal_layers.iter().any(|m| m == k) };
            if !allowed {
                viol.push(format!("ECO-MASK-010 {} edge(s) changed on frozen mask {}", d, k));
            }
            changed_masks.push((k.clone(), d, allowed));
        }
        let feol = viol.iter().filter(|v| v.starts_with("ECO-MASK-00")).count();
        let beol = viol.len() - feol;
        crate::out!("****************************************\nReport : check_eco_mask ({} ECO)\n****************************************", if base.allow_base { "BEOL+FEOL" } else { "metal-only" });
        crate::out!("  changeable masks : {}", base.metal_layers.join(" "));
        crate::out!("  base instances   : {} frozen, {} added, {} removed ({} gate-array conversion(s) inside base filler)", base.cells.len(), added.len(), removed.len(), ga_ok);
        for (k, d, ok) in &changed_masks {
            crate::out!("  mask {:<7} {:>6} edge(s) changed{}", k, d, if *ok { "" } else { "  <-- FROZEN" });
        }
        for v in viol.iter().take(30) { crate::out!("  {}", v); }
        let fail = beol + if base.allow_base { 0 } else { feol };
        let respin: Vec<String> = changed_masks.iter().map(|m| m.0.clone()).collect();
        crate::info!("ECO-540", "ECO mask check: {} ({} base-layer change(s){}, {} frozen-mask change(s)); masks to re-spin: {}",
            if fail == 0 { "PASS" } else { "FAIL" }, feol, if base.allow_base && feol > 0 { " allowed" } else { "" }, beol,
            if respin.is_empty() && feol == 0 { "none".to_string() } else { format!("{}{}", if feol > 0 { "FEOL " } else { "" }, respin.join(" ")) });
        let _ = rh;
        Ok(fail.to_string())
    }

    // ------------------------------------------------------------------ netlist-diff ECO
    fn c_eco_netlist(&mut self, a: &[String]) -> R {
        let x = args(a, &["-by_verilog_file"]);
        let f = x.get("-by_verilog_file").cloned().or(x.pos.first().cloned()).ok_or_else(|| Flow::Err("eco_netlist: -by_verilog_file required (CMD-001)".into()))?;
        let src = std::fs::read_to_string(&f).map_err(|e| Flow::Err(format!("eco_netlist: {}: {} (ECO-550)", f, e)))?;
        let v = parse_vnet(&src).map_err(|e| Flow::Err(format!("eco_netlist: {}: {} (ECO-551)", f, e)))?;
        let apply = x.has("-apply");
        let post = self.eco_base.is_some();
        let nl = self.nl()?;
        // ---- new connectivity groups
        let mut uf = Uf(HashMap::new());
        for (l, r) in &v.assigns { uf.union(l, r); }
        let mut groups: HashMap<String, Vec<(String, String)>> = HashMap::new(); // rep -> [(inst, pin)] ("" inst = port)
        for p in &v.ports { let r = uf.find(p); groups.entry(r).or_default().push((String::new(), p.clone())); }
        for (inst, (_, pins)) in &v.insts {
            for (pn, n) in pins { let r = uf.find(n); groups.entry(r).or_default().push((inst.clone(), pn.clone())); }
        }
        // ---- old: logical net of every pin (through hierarchy boundary cells)
        let mut ouf: HashMap<NetId, NetId> = HashMap::new();
        fn root(m: &mut HashMap<NetId, NetId>, a: NetId) -> NetId { let p = *m.get(&a).unwrap_or(&a); if p == a { a } else { let r = root(m, p); m.insert(a, r); r } }
        for c in nl.cell_ids() {
            if nl.cell(c).is_hport() {
                if let (Some(a1), Some(y1)) = (nl.cell(c).pin_net("A"), nl.cell(c).pin_net("Y")) { let (ra, ry) = (root(&mut ouf, a1), root(&mut ouf, y1)); if ra != ry { ouf.insert(ry, ra); } }
            }
        }
        let konst = |n: NetId| -> Option<&'static str> {
            match nl.driver(n) { Some(PinRef::Cell(d, _)) => match nl.cell(d).kind { Kind::Gen(GOp::C0) => Some("1'b0"), Kind::Gen(GOp::C1) => Some("1'b1"), _ => None }, _ => None }
        };
        let phys_only = |cl: &Cell| cl.attrs.iter().any(|a| a == "spare" || a == "ga_base" || a == "ga_cell" || a == "io_pad") || cl.dont_touch && cl.fixed;
        let new_names: HashSet<&String> = v.insts.keys().collect();
        let mut add_cells: Vec<(String, String)> = vec![];
        let mut del_cells: Vec<CellId> = vec![];
        let mut chg: Vec<(CellId, String)> = vec![];
        for (inst, (m, _)) in &v.insts {
            match nl.cell_by_name(inst) {
                None => add_cells.push((inst.clone(), m.clone())),
                Some(c) => if nl.cell(c).lib().map(|l| l != m).unwrap_or(false) { chg.push((c, m.clone())); },
            }
        }
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.is_hport() || matches!(cl.kind, Kind::Gen(_)) || phys_only(cl) { continue; }
            if !new_names.contains(&cl.name) { del_cells.push(c); }
        }
        // per group: target old logical net by majority (ports weigh 100); every old net goes
        // to one group only (greedy by votes), the others get new nets
        let mut reconnect: Vec<(String, String, Option<NetId>, String)> = vec![]; // inst, pin, target net (None = create), group rep
        let mut new_nets = 0;
        let mut cands: Vec<(usize, String, NetId, NetId)> = vec![]; // votes, group, logical, concrete
        let mut reps: Vec<&String> = groups.keys().collect();
        reps.sort();
        for rep in &reps {
            if rep.starts_with("1'b") { continue; }
            let mut votes: HashMap<NetId, (usize, NetId)> = HashMap::new();
            for (inst, pin) in &groups[*rep] {
                let n = if inst.is_empty() { nl.port_by_name(pin).and_then(|p| nl.ports[p].net) } else { nl.cell_by_name(inst).and_then(|c| nl.cell(c).pin_net(pin)) };
                if let Some(n) = n {
                    if konst(n).is_some() { continue; }
                    let r = root(&mut ouf, n);
                    let e = votes.entry(r).or_insert((0, n));
                    e.0 += if inst.is_empty() { 100 } else { 1 };
                }
            }
            for (l, (v, c)) in votes { cands.push((v, (*rep).clone(), l, c)); }
        }
        cands.sort_by(|a, b| b.0.cmp(&a.0).then(a.1.cmp(&b.1)).then(a.2.cmp(&b.2)));
        let mut assigned: HashMap<String, (NetId, NetId)> = HashMap::new();
        let mut claimed: HashSet<NetId> = HashSet::new();
        for (_, g, l, c) in &cands {
            if assigned.contains_key(g) || claimed.contains(l) { continue; }
            assigned.insert(g.clone(), (*l, *c));
            claimed.insert(*l);
        }
        for rep in &reps {
            let mem = &groups[*rep];
            if rep.starts_with("1'b") {
                for (inst, pin) in mem {
                    if inst.is_empty() { continue; }
                    let cur = nl.cell_by_name(inst).and_then(|c| nl.cell(c).pin_net(pin));
                    if cur.and_then(konst) != Some(rep.as_str()) { reconnect.push((inst.clone(), pin.clone(), None, (*rep).clone())); }
                }
                continue;
            }
            let target = assigned.get(*rep).copied();
            if target.is_none() { new_nets += 1; }
            for (inst, pin) in mem {
                if inst.is_empty() { continue; }
                let cur = nl.cell_by_name(inst).and_then(|c| nl.cell(c).pin_net(pin)).map(|n| root(&mut ouf, n));
                if cur.is_none() || cur != target.map(|t| t.0) {
                    reconnect.push((inst.clone(), pin.clone(), target.map(|t| t.1), (*rep).clone()));
                }
            }
        }
        // pins connected now but open in the new netlist
        let mut opens: Vec<(CellId, usize)> = vec![];
        for (inst, (_, pins)) in &v.insts {
            let Some(c) = nl.cell_by_name(inst) else { continue };
            let have: HashSet<&String> = pins.iter().map(|p| &p.0).collect();
            for (i, p) in nl.cell(c).pins.iter().enumerate() {
                if p.net.is_some() && !have.contains(&p.name) { opens.push((c, i)); }
            }
        }
        reconnect.sort();
        crate::out!("ECO netlist diff vs '{}': {} instance(s) added, {} deleted, {} master change(s), {} pin reconnection(s), {} pin(s) opened, {} new net(s)",
            f, add_cells.len(), del_cells.len(), chg.len(), reconnect.len(), opens.len(), new_nets);
        for (i, m) in add_cells.iter().take(20) { crate::out!("  + {} ({})", i, m); }
        for c in del_cells.iter().take(20) { crate::out!("  - {} ({})", nl.cell(*c).name, nl.cell(*c).lib().unwrap_or("?")); }
        for (c, m) in chg.iter().take(20) { crate::out!("  ~ {} {} -> {}", nl.cell(*c).name, nl.cell(*c).lib().unwrap_or("?"), m); }
        for r in reconnect.iter().take(20) { crate::out!("  > {}/{} -> {}", r.0, r.1, r.3); }
        let total = add_cells.len() + del_cells.len() + chg.len() + reconnect.len() + opens.len();
        if !apply {
            crate::info!("ECO-552", "eco_netlist: {} change(s) found (use -apply to implement)", total);
            return Ok(total.to_string());
        }
        // ---- apply
        let del_names: Vec<String> = del_cells.iter().map(|c| nl.cell(*c).name.clone()).collect();
        let chg_names: Vec<(String, String)> = chg.iter().map(|(c, m)| (nl.cell(*c).name.clone(), m.clone())).collect();
        let opens_n: Vec<(String, String)> = opens.iter().map(|(c, i)| (nl.cell(*c).name.clone(), nl.cell(*c).pins[*i].name.clone())).collect();
        let mut freed = 0;
        // master changes: pre-mask in place; post-mask the old instance stays in the base
        for (n, m) in &chg_names {
            if post {
                let nlm = self.nl.as_mut().unwrap();
                let c = nlm.cell_by_name(n).unwrap();
                let old = format!("{}_eco_freed", n);
                nlm.rename_cell(c, &old);
                add_cells.push((n.clone(), m.clone()));
                self.free_cell(&old);
                freed += 1;
            } else {
                let r = self.cmd("eco_change_cell", &[n.clone(), "-cell".into(), m.clone()]).unwrap_or(Ok(String::new()));
                if let Err(e) = r { return Err(e); }
            }
        }
        for (i, m) in &add_cells {
            self.make_inst(i, m)?;
        }
        for (c, p) in &opens_n {
            let nlm = self.nl.as_mut().unwrap();
            if let Some(c) = nlm.cell_by_name(c) { if let Some(i) = nlm.cell(c).pin(p) { nlm.disconnect(c, i); } }
        }
        let mut made: HashMap<String, NetId> = HashMap::new();
        let mut ties: HashMap<String, NetId> = HashMap::new();
        for (inst, pin, tgt, rep) in &reconnect {
            let nlm = self.nl.as_mut().unwrap();
            let Some(c) = nlm.cell_by_name(inst) else { continue };
            let Some(i) = nlm.cell(c).pin(pin) else { crate::warn!("ECO-553", "{}: no pin {}", inst, pin); continue };
            let n = match (tgt, rep.starts_with("1'b")) {
                (_, true) => *ties.entry(rep.clone()).or_insert_with(|| {
                    let n = nlm.add_net(&format!("eco_tie_{}", &rep[3..]));
                    let t = nlm.add_cell(&format!("eco_const_{}", &rep[3..]), Kind::Gen(if rep == "1'b0" { GOp::C0 } else { GOp::C1 }), &[("Y", Dir::Out)]);
                    nlm.connect(t, 0, n);
                    n
                }),
                (Some(t), _) => *t,
                (None, _) => *made.entry(rep.clone()).or_insert_with(|| { let nm = if nlm.net_by_name(rep).is_some() { format!("{}_eco", rep) } else { rep.clone() }; nlm.add_net(&nm) }),
            };
            if nlm.cell(c).pins[i].net.is_some() { nlm.disconnect(c, i); }
            nlm.connect(c, i, n);
        }
        for n in &del_names {
            if post { self.free_cell(n); freed += 1; } else {
                let nlm = self.nl.as_mut().unwrap();
                if let Some(c) = nlm.cell_by_name(n) { nlm.remove_cell(c); }
            }
        }
        self.eco_changes.push(format!("eco_netlist -by_verilog_file {} -apply", f));
        self.gr_cache_clear();
        crate::info!("ECO-554", "eco_netlist: applied {} change(s){}", total,
            if post { format!(" (post-mask: {} base instance(s) freed as spares, {} new cell(s) to remap with eco_remap_post_mask)", freed, add_cells.len()) } else { format!("; {} new cell(s) unplaced (eco_place)", add_cells.len()) });
        Ok(total.to_string())
    }

    /// post-mask deletion: the instance stays in silicon; disconnect it, tie its inputs low and
    /// make it a spare
    fn free_cell(&mut self, name: &str) {
        let nlm = self.nl.as_mut().unwrap();
        let Some(c) = nlm.cell_by_name(name) else { return };
        let n = nlm.add_net(&format!("{}_tie_lo", name));
        let t = nlm.add_cell(&format!("{}_tie_c0", name), Kind::Gen(GOp::C0), &[("Y", Dir::Out)]);
        nlm.connect(t, 0, n);
        let pins: Vec<(usize, Dir, bool)> = nlm.cell(c).pins.iter().enumerate().map(|(i, p)| (i, p.dir, p.net.is_some())).collect();
        for (i, d, con) in pins {
            if con { nlm.disconnect(c, i); }
            if d == Dir::In { nlm.connect(c, i, n); }
        }
        let cl = nlm.cell_mut(c);
        cl.dont_touch = true;
        cl.attrs.push("spare".into());
        cl.attrs.push(format!("spare_group:{}_freed", name.rsplit_once('/').map(|x| x.0).unwrap_or("eco")));
    }

    fn c_eco_place(&mut self, a: &[String]) -> R {
        let _x = args(a, &["-max_displacement"]);
        if self.fp.is_none() { return err("eco_place: no floorplan (FP-001)"); }
        let nl = self.nl()?;
        let cands: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| { let cl = nl.cell(*c); cl.loc.is_none() && matches!(cl.kind, Kind::Lib(_)) && !cl.is_hport() }).collect();
        let mut occ = self.occupied_rects();
        let rh = self.row_h();
        // placed movable cells also occupy sites
        {
            let nl = self.nl.as_ref().unwrap();
            for c in nl.cell_ids() {
                let cl = nl.cell(c);
                if cl.fixed || cl.is_hport() || !matches!(cl.kind, Kind::Lib(_)) { continue; }
                if let Some(l) = cl.loc { let w = self.cell_w(cl.lib().unwrap()); occ.push((l.0 - w / 2.0, l.1 - rh / 2.0, l.0 + w / 2.0, l.1 + rh / 2.0)); }
            }
        }
        let mut n = 0;
        let mut disp = 0.0f64;
        for c in cands {
            let at = self.conn_centroid(c).unwrap_or_else(|| { let r = self.fp.as_ref().unwrap().place_region(); ((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0) });
            let m = self.nl.as_ref().unwrap().cell(c).lib().unwrap().to_string();
            let w = self.cell_w(&m);
            if let Some(l) = self.find_site(at, w, &occ) {
                disp = disp.max((l.0 - at.0).abs() + (l.1 - at.1).abs());
                self.nl.as_mut().unwrap().cell_mut(c).loc = Some(l);
                occ.push((l.0 - w / 2.0, l.1 - rh / 2.0, l.0 + w / 2.0, l.1 + rh / 2.0));
                n += 1;
            }
        }
        self.gr_cache_clear();
        crate::info!("ECO-560", "eco_place: placed {} new cell(s) at their connection centroids on free legal sites (max displacement {:.2} um)", n, disp);
        Ok(n.to_string())
    }
}
