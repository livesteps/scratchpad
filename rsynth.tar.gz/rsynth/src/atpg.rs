//! ATPG: stuck-at and transition (launch-on-capture, at-speed through the OCCs) test
//! generation on the full-scan view of the mapped netlist, with compression-aware encoding,
//! 3-valued bit-parallel fault simulation, PODEM with dynamic compaction, and pattern output
//! for ATE (STIL 1.0: structured and cycle-expanded) and for simulation (Verilog testbench with
//! load / shift / capture / unload and compare), plus Verilog simulation models of the
//! library cells and memories.
//!
//!  create_test_patterns [-fault_model stuck_at|transition] [-capture slow|atspeed]
//!                       [-random_patterns n] [-abort_limit n] [-max_patterns n] [-seed n] [-no_compression]
//!  report_atpg [-faults untested|all]       (report_test_coverage)
//!  write_test_patterns -format stil|stil_flat|verilog -output f [-period ns] [-fast_period ns]
//!  write_simulation_models file.v

use crate::liberty::{parse_func, BExpr, LibCell};
use crate::netlist::*;
use crate::session::{args, Session};
use crate::tcl::{err, Flow, R};
use std::collections::{BinaryHeap, HashMap, HashSet};
use std::cmp::Reverse;

// --------------------------------------------------------------------------- 3-valued words
#[derive(Clone, Copy, PartialEq, Debug)]
pub struct V { pub one: u64, pub zero: u64 }
const VX: V = V { one: !0, zero: !0 };
const V0: V = V { one: 0, zero: !0 };
const V1: V = V { one: !0, zero: 0 };
impl V {
    fn not(self) -> V { V { one: self.zero, zero: self.one } }
    fn and(self, b: V) -> V { V { one: self.one & b.one, zero: self.zero | b.zero } }
    fn or(self, b: V) -> V { V { one: self.one | b.one, zero: self.zero & b.zero } }
    fn xor(self, b: V) -> V { V { one: (self.one & b.zero) | (self.zero & b.one), zero: (self.one & b.one) | (self.zero & b.zero) } }
    fn k1(self) -> u64 { self.one & !self.zero }
    fn k0(self) -> u64 { self.zero & !self.one }
    fn bit(self) -> u8 { if self.k1() & 1 != 0 { 1 } else if self.k0() & 1 != 0 { 0 } else { 2 } }
    fn of(v: u8) -> V { match v { 0 => V0, 1 => V1, _ => VX } }
}

#[derive(Clone, Debug)]
enum Ins { In(u8), C0, C1, Not, And, Or, Xor }

fn compile(e: &BExpr, pin_idx: &dyn Fn(&str) -> Option<u8>, out: &mut Vec<Ins>) -> bool {
    match e {
        BExpr::Var(v) => match pin_idx(v) { Some(i) => out.push(Ins::In(i)), None => return false },
        BExpr::Const(b) => out.push(if *b { Ins::C1 } else { Ins::C0 }),
        BExpr::Not(a) => { if !compile(a, pin_idx, out) { return false; } out.push(Ins::Not); }
        BExpr::And(a, b) => { if !compile(a, pin_idx, out) || !compile(b, pin_idx, out) { return false; } out.push(Ins::And); }
        BExpr::Or(a, b) => { if !compile(a, pin_idx, out) || !compile(b, pin_idx, out) { return false; } out.push(Ins::Or); }
        BExpr::Xor(a, b) => { if !compile(a, pin_idx, out) || !compile(b, pin_idx, out) { return false; } out.push(Ins::Xor); }
    }
    true
}

#[derive(Clone, Debug)]
struct Gate { out: usize, ins: Vec<usize>, prog: Vec<Ins> }

fn run(prog: &[Ins], get: &dyn Fn(usize) -> V) -> V {
    let mut st: [V; 32] = [VX; 32];
    let mut sp = 0;
    for i in prog {
        match i {
            Ins::In(k) => { st[sp] = get(*k as usize); sp += 1; }
            Ins::C0 => { st[sp] = V0; sp += 1; }
            Ins::C1 => { st[sp] = V1; sp += 1; }
            Ins::Not => { st[sp - 1] = st[sp - 1].not(); }
            Ins::And => { sp -= 1; st[sp - 1] = st[sp - 1].and(st[sp]); }
            Ins::Or => { sp -= 1; st[sp - 1] = st[sp - 1].or(st[sp]); }
            Ins::Xor => { sp -= 1; st[sp - 1] = st[sp - 1].xor(st[sp]); }
        }
        if sp >= 31 { return VX; }
    }
    if sp == 0 { VX } else { st[sp - 1] }
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum Src { None, Pi(usize), Ppi(usize, bool), Const(u8), X, Gate(usize) }

/// combinational test view (one or two time frames)
#[derive(Clone)]
struct Circ {
    n: usize,
    gates: Vec<Gate>,       // topological order
    src: Vec<Src>,
    fanout: Vec<Vec<usize>>, // gate indices reading the net
    obs: Vec<usize>,        // observed nets: POs then PPOs
    n_po: usize,
    pi_nets: Vec<usize>,
    ppi_nets: Vec<Vec<(usize, bool)>>, // per scan cell: Q / QN nets
}

impl Circ {
    fn sim(&self, pi: &[V], ppi: &[V], vals: &mut Vec<V>) {
        for k in 0..self.n {
            vals[k] = match self.src[k] {
                Src::Pi(i) => pi[i],
                Src::Ppi(i, inv) => if inv { ppi[i].not() } else { ppi[i] },
                Src::Const(v) => V::of(v),
                _ => VX,
            };
        }
        for g in &self.gates {
            let v = run(&g.prog, &|i| vals[g.ins[i]]);
            vals[g.out] = v;
        }
    }
}

#[derive(Clone, Debug)]
struct Fault { net: usize, sa: u8, branch: Option<(usize, usize)>, init: Option<(usize, u8)>, status: u8 }
// status: 0 undetected, 1 detected, 2 redundant (proven untestable), 3 aborted, 4 untestable (not controllable / observable)

#[derive(Clone, Debug, Default)]
pub struct Pat { pub pi: Vec<u8>, pub load: Vec<u8>, pub po: Vec<u8>, pub cap: Vec<u8>, pub chan: Vec<Vec<u8>> }

#[derive(Clone, Debug, Default)]
pub struct PatternSet {
    pub model: String,
    pub capture: String,
    pub compressed: bool,
    pub cells: Vec<String>,
    /// (name, cell indices SI -> SO, scan in, scan out)
    pub chains: Vec<(String, Vec<usize>, String, String)>,
    pub pis: Vec<String>,
    pub pos: Vec<String>,
    pub pats: Vec<Pat>,
    pub constraints: Vec<(String, u8)>,
    pub stats: (usize, usize, usize, usize, usize, usize, usize), // total, detected, redundant, aborted, untestable (structural), random-detected, ATPG-untestable
    pub untested: Vec<String>,
    pub shift_len: usize,
    pub scan_clocks: Vec<String>,
    pub fast_clocks: Vec<String>,
}

struct Ctx<'a> { lib: Vec<&'a crate::liberty::Library> }
impl<'a> Ctx<'a> {
    fn cell(&self, n: &str) -> Option<&'a LibCell> { self.lib.iter().find_map(|l| l.cells.get(n)) }
}

/// data pin of a scan flop (the functional D)
fn data_pin(lc: &LibCell) -> Option<String> {
    let s = lc.seq.as_ref()?;
    let ns = s.next_state.replace(['(', ')', '!', '&', '|', '^', '\''], " ");
    ns.split_whitespace().find(|v| *v != "SI" && *v != "SE" && lc.pin(v).is_some()).map(|s| s.to_string())
}

impl Session {
    fn test_constraints(&self) -> Vec<(String, u8)> {
        let d = &self.dftx;
        let mut v: Vec<(String, u8)> = vec![];
        let tm = d.test_mode.clone().or(self.dft.test_mode.clone());
        if let Some(t) = tm { v.push((t, 1)); }
        if let Some(e) = &d.edt { v.push((e.enable.clone(), 1)); v.push((e.clear.clone(), 1)); }
        if let Some(t) = &d.tap { v.push((t.ports[3].clone(), 0)); v.push((t.ports[0].clone(), 0)); v.push((t.ports[1].clone(), 1)); v.push((t.ports[2].clone(), 0)); }
        for m in &d.mbist {
            if m.control == "pins" { v.push((m.en.clone(), 0)); v.push((m.start.clone(), 0)); }
            if !v.iter().any(|x| x.0 == m.reset) { v.push((m.reset.clone(), 0)); }
        }
        v
    }

    /// build the combinational test view; returns circuit, scan cells (chain order), PI names, PO names
    fn build_circ(&self, model: &str) -> Result<(Circ, Vec<String>, Vec<String>, Vec<String>, Vec<(String, u8)>), String> {
        let nl = self.nl.as_ref().ok_or("no design")?;
        let ctx = Ctx { lib: self.libs.iter().collect() };
        let chains = { let mut me_chains = self.dftx.chains.clone(); if me_chains.is_empty() { me_chains = self.dft.chains.iter().map(|(n, _, r)| { let (a, b) = n.split_once(':').unwrap_or((n, n)); (n.clone(), r.clone(), a.to_string(), b.to_string()) }).collect(); } me_chains };
        if chains.is_empty() { return Err("no scan chains (insert_dft)".into()); }
        let cells: Vec<String> = chains.iter().flat_map(|c| c.1.iter().cloned()).collect();
        let cidx: HashMap<&str, usize> = cells.iter().enumerate().map(|(i, c)| (c.as_str(), i)).collect();
        let n = nl.nets.len();
        let mut src = vec![Src::None; n];
        let mut gates: Vec<Gate> = vec![];
        let mut ppi_nets: Vec<Vec<(usize, bool)>> = vec![vec![]; cells.len()];
        let mut ppo: Vec<usize> = vec![usize::MAX; cells.len()];
        // constraints: test-mode values, clocks (data value 0), async resets inactive, scan enable 0
        let mut cons = self.test_constraints();
        let se = self.dftx.scan_en.clone().or(self.dft.scan_enable.clone()).unwrap_or("test_se".into());
        cons.push((se, 0));
        if let Some(a) = &self.dftx.atspeed { cons.push((a.clone(), if model == "transition" { 1 } else { 0 })); }
        if let Some(t) = &self.dftx.test_clk { cons.push((t.clone(), 0)); }
        let mut clock_ports: Vec<String> = self.dftx.occ.iter().map(|o| o.0.clone()).collect();
        for (_, d, _) in &self.dft.chains { if d != "all" && !clock_ports.contains(d) { clock_ports.push(d.clone()); } }
        for (c, _) in self.func_clock_periods_pub() { if !clock_ports.contains(&c) { clock_ports.push(c); } }
        for c in &clock_ports { if !cons.iter().any(|x| &x.0 == c) { cons.push((c.clone(), 0)); } }
        // ports driving async clear / preset of scan cells: held inactive
        for c in &cells {
            let Some(id) = nl.cell_by_name(c) else { continue };
            let Some(lc) = nl.cell(id).lib().and_then(|l| ctx.cell(l)) else { continue };
            let Some(sq) = &lc.seq else { continue };
            for (p, inactive_low) in [(sq.clear.clone(), true), (sq.preset.clone(), true)] {
                let Some(p) = p else { continue };
                let low = p.contains('!') || p.ends_with('\'');
                let pn = p.trim_start_matches('!').trim_end_matches('\'');
                let Some(mut net) = nl.cell(id).pin_net(pn) else { continue };
                let mut inv = false;
                for _ in 0..16 {
                    match nl.driver(net) {
                        Some(PinRef::Port(pt)) => { let nm = nl.ports[pt].name.clone(); let v = if low { 1 } else { 0 } ^ inv as u8; if !cons.iter().any(|x| x.0 == nm) { cons.push((nm, v)); } break; }
                        Some(PinRef::Cell(d, _)) => {
                            let dc = nl.cell(d);
                            let l = dc.lib().and_then(|l| ctx.cell(l));
                            let buf = dc.is_hport() || l.map(|x| x.is_buf).unwrap_or(false) || matches!(dc.kind, Kind::Gen(GOp::Buf));
                            let iv = l.map(|x| x.is_inv).unwrap_or(false) || matches!(dc.kind, Kind::Gen(GOp::Not));
                            if !(buf || iv) { break; }
                            if iv { inv = !inv; }
                            match dc.pins.iter().find(|q| q.dir == Dir::In).and_then(|q| q.net) { Some(x) => net = x, None => break }
                        }
                        None => break,
                    }
                }
                let _ = inactive_low;
            }
        }
        let mut pis: Vec<String> = vec![];
        let mut pi_nets: Vec<usize> = vec![];
        let mut pos: Vec<String> = vec![];
        let mut po_nets: Vec<usize> = vec![];
        let mut scan_ports: HashSet<String> = HashSet::new();
        for (_, _, si, so) in &chains { scan_ports.insert(si.clone()); scan_ports.insert(so.clone()); }
        if let Some(e) = &self.dftx.edt { for p in e.ci.iter().chain(e.co.iter()) { scan_ports.insert(p.clone()); } }
        if let Some(t) = &self.dftx.tap { scan_ports.insert(t.ports[4].clone()); }
        for m in &self.dftx.mbist { scan_ports.insert(m.done.clone()); scan_ports.insert(m.fail.clone()); }
        let mut ids = nl.port_ids();
        ids.sort_by_key(|p| nl.ports[*p].name.clone());
        for p in ids {
            let pt = &nl.ports[p];
            let Some(net) = pt.net else { continue };
            if !pt.alive { continue; }
            match pt.dir {
                Dir::In => {
                    if let Some(c) = cons.iter().find(|c| c.0 == pt.name) { src[net] = Src::Const(c.1); }
                    else if scan_ports.contains(&pt.name) { src[net] = Src::Const(0); }
                    else { src[net] = Src::Pi(pis.len()); pis.push(pt.name.clone()); pi_nets.push(net); }
                }
                Dir::Out => if !scan_ports.contains(&pt.name) { pos.push(pt.name.clone()); po_nets.push(net); },
                _ => {}
            }
        }
        // cells
        let mut nonscan: Vec<(CellId, &LibCell)> = vec![];
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            match &cl.kind {
                Kind::Lib(l) => {
                    let Some(lc) = ctx.cell(l) else { continue };
                    if let Some(sq) = &lc.seq {
                        if let Some(&ci) = cidx.get(cl.name.as_str()) {
                            for o in lc.outputs() {
                                let Some(net) = cl.pin_net(&o.name) else { continue };
                                let inv = o.function.as_deref().map(|f| f.contains('N') || f.starts_with('!')).unwrap_or(false);
                                src[net] = Src::Ppi(ci, inv);
                                ppi_nets[ci].push((net, inv));
                            }
                            let dp = data_pin(lc).unwrap_or("D".into());
                            ppo[ci] = cl.pin_net(&dp).unwrap_or(usize::MAX);
                        } else if lc.icg.is_some() {
                            for o in lc.outputs() { if let Some(net) = cl.pin_net(&o.name) { src[net] = Src::X; } }
                        } else {
                            let _ = sq;
                            nonscan.push((c, lc));
                            for o in lc.outputs() { if let Some(net) = cl.pin_net(&o.name) { src[net] = Src::X; } }
                        }
                        continue;
                    }
                    if let Some(t) = lc.tie { for o in lc.outputs() { if let Some(net) = cl.pin_net(&o.name) { src[net] = Src::Const(t as u8); } } continue; }
                    let ins: Vec<&crate::netlist::Pin> = cl.pins.iter().filter(|p| p.dir != Dir::Out).collect();
                    for o in lc.outputs() {
                        let Some(out) = cl.pin_net(&o.name) else { continue };
                        let Some(f) = o.function.as_deref().and_then(parse_func) else { src[out] = Src::X; continue };
                        let mut prog = vec![];
                        let inets: Vec<usize> = ins.iter().map(|p| p.net.unwrap_or(usize::MAX)).collect();
                        let ok = compile(&f, &|v| ins.iter().position(|p| p.name == v).map(|i| i as u8), &mut prog);
                        if !ok || inets.contains(&usize::MAX) { src[out] = Src::X; continue; }
                        src[out] = Src::Gate(gates.len());
                        gates.push(Gate { out, ins: inets, prog });
                    }
                }
                Kind::Gen(op) => {
                    let ins: Vec<usize> = cl.pins.iter().filter(|p| p.dir != Dir::Out).map(|p| p.net.unwrap_or(usize::MAX)).collect();
                    let Some(out) = cl.pins.iter().find(|p| p.dir == Dir::Out).and_then(|p| p.net) else { continue };
                    let prog = match op {
                        GOp::C0 => { src[out] = Src::Const(0); continue }
                        GOp::C1 => { src[out] = Src::Const(1); continue }
                        GOp::Buf => vec![Ins::In(0)],
                        GOp::Not => vec![Ins::In(0), Ins::Not],
                        GOp::And => vec![Ins::In(0), Ins::In(1), Ins::And],
                        GOp::Or => vec![Ins::In(0), Ins::In(1), Ins::Or],
                        GOp::Xor => vec![Ins::In(0), Ins::In(1), Ins::Xor],
                        GOp::Nand => vec![Ins::In(0), Ins::In(1), Ins::And, Ins::Not],
                        GOp::Nor => vec![Ins::In(0), Ins::In(1), Ins::Or, Ins::Not],
                        GOp::Xnor => vec![Ins::In(0), Ins::In(1), Ins::Xor, Ins::Not],
                        GOp::Mux => vec![Ins::In(0), Ins::In(2), Ins::And, Ins::In(0), Ins::Not, Ins::In(1), Ins::And, Ins::Or],
                        _ => { src[out] = Src::X; continue }
                    };
                    if ins.contains(&usize::MAX) { src[out] = Src::X; continue; }
                    src[out] = Src::Gate(gates.len());
                    gates.push(Gate { out, ins, prog });
                }
                Kind::BlackBox(_) => { for p in cl.pins.iter().filter(|p| p.dir == Dir::Out) { if let Some(net) = p.net { src[net] = Src::X; } } }
            }
        }
        // hierarchy port cells are buffers
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if !cl.is_hport() || matches!(cl.kind, Kind::Gen(_)) { continue; }
        }
        // topological order (gates whose inputs are in a loop become X)
        let mut drv_gate: Vec<Option<usize>> = vec![None; n];
        for (i, g) in gates.iter().enumerate() { drv_gate[g.out] = Some(i); }
        let mut indeg: Vec<usize> = gates.iter().map(|g| g.ins.iter().filter(|i| drv_gate[**i].is_some()).count()).collect();
        let mut users: Vec<Vec<usize>> = vec![vec![]; n];
        for (i, g) in gates.iter().enumerate() { for &x in &g.ins { users[x].push(i); } }
        let mut order = vec![];
        let mut q: Vec<usize> = (0..gates.len()).filter(|i| indeg[*i] == 0).collect();
        while let Some(g) = q.pop() {
            order.push(g);
            for &u in &users[gates[g].out] { indeg[u] -= 1; if indeg[u] == 0 { q.push(u); } }
        }
        let loops = gates.len() - order.len();
        let inorder: HashSet<usize> = order.iter().copied().collect();
        for (i, g) in gates.iter().enumerate() { if !inorder.contains(&i) { src[g.out] = Src::X; } }
        let gates: Vec<Gate> = order.iter().map(|i| gates[*i].clone()).collect();
        for (i, g) in gates.iter().enumerate() { src[g.out] = Src::Gate(i); }
        let _ = loops;
        let mut fanout: Vec<Vec<usize>> = vec![vec![]; n];
        for (i, g) in gates.iter().enumerate() { for &x in &g.ins { if !fanout[x].contains(&i) { fanout[x].push(i); } } }
        let mut obs = po_nets.clone();
        let n_po = obs.len();
        obs.extend(ppo.iter().map(|p| if *p == usize::MAX { 0 } else { *p }));
        let mut circ = Circ { n, gates, src, fanout, obs, n_po, pi_nets, ppi_nets };
        // non-scan flops: Q known when their async clear / preset is held active by the constraints
        for _ in 0..6 {
            let mut vals = vec![VX; n];
            circ.sim(&vec![VX; pis.len()], &vec![VX; cells.len()], &mut vals);
            let mut changed = false;
            for (c, lc) in &nonscan {
                let cl = nl.cell(*c);
                let sq = lc.seq.as_ref().unwrap();
                let act = |p: &Option<String>| -> bool {
                    let Some(p) = p else { return false };
                    let low = p.contains('!') || p.ends_with('\'');
                    let pn = p.trim_start_matches('!').trim_end_matches('\'');
                    cl.pin_net(pn).map(|n| { let b = vals[n].bit(); b == if low { 0 } else { 1 } }).unwrap_or(false)
                };
                let q = if act(&sq.clear) { Some(0u8) } else if act(&sq.preset) { Some(1u8) } else { None };
                if let Some(q) = q {
                    for o in lc.outputs() {
                        let Some(net) = cl.pin_net(&o.name) else { continue };
                        let inv = o.function.as_deref().map(|f| f.contains('N') || f.starts_with('!')).unwrap_or(false);
                        let v = q ^ inv as u8;
                        if circ.src[net] != Src::Const(v) { circ.src[net] = Src::Const(v); changed = true; }
                    }
                }
            }
            if !changed { break; }
        }
        if std::env::var("RSYNTH_ATPG_DEBUG").is_ok() {
            let mut vals = vec![VX; n];
            circ.sim(&vec![VX; pis.len()], &vec![VX; cells.len()], &mut vals);
            for (c, lc) in &nonscan {
                let cl = nl.cell(*c);
                let q = lc.outputs().iter().filter_map(|o| cl.pin_net(&o.name)).map(|n| format!("{:?}", circ.src[n])).collect::<Vec<_>>().join(",");
                let pins = cl.pins.iter().map(|p| format!("{}={}", p.name, p.net.map(|n| vals[n].bit()).unwrap_or(9))).collect::<Vec<_>>().join(" ");
                eprintln!("nonscan {} {} [{}] {:?} {:?} {}", cl.name, lc.name, pins, lc.seq.as_ref().unwrap().clear, lc.seq.as_ref().unwrap().preset, q);
            }
        }
        Ok((circ, cells, pis, pos, cons))
    }
}

/// two-frame (launch-on-capture) unrolling: frame-2 nets are offset by n
fn unroll(c: &Circ) -> Circ {
    let n = c.n;
    let mut src = vec![Src::None; 2 * n];
    let mut gates: Vec<Gate> = c.gates.clone();
    for k in 0..n { src[k] = c.src[k]; }
    // frame 2 sources: PIs held (buffer from frame 1), scan cells take the frame-1 captured value
    let mut extra: Vec<Gate> = vec![];
    for k in 0..n {
        src[n + k] = match c.src[k] {
            Src::Pi(_) => { extra.push(Gate { out: n + k, ins: vec![k], prog: vec![Ins::In(0)] }); Src::None }
            Src::Ppi(i, inv) => {
                let d = c.obs[c.n_po + i];
                extra.push(Gate { out: n + k, ins: vec![d], prog: if inv { vec![Ins::In(0), Ins::Not] } else { vec![Ins::In(0)] } });
                Src::None
            }
            Src::Const(v) => Src::Const(v),
            Src::X => Src::X,
            _ => Src::None,
        };
    }
    gates.extend(extra);
    for g in &c.gates { gates.push(Gate { out: g.out + n, ins: g.ins.iter().map(|i| i + n).collect(), prog: g.prog.clone() }); }
    for (i, g) in gates.iter().enumerate() { src[g.out] = Src::Gate(i); }
    let mut fanout: Vec<Vec<usize>> = vec![vec![]; 2 * n];
    for (i, g) in gates.iter().enumerate() { for &x in &g.ins { if !fanout[x].contains(&i) { fanout[x].push(i); } } }
    // only the frame-2 captures are observed (no PO strobe at speed)
    let obs: Vec<usize> = c.obs[c.n_po..].iter().map(|o| o + n).collect();
    Circ { n: 2 * n, gates, src, fanout, obs, n_po: 0, pi_nets: c.pi_nets.clone(), ppi_nets: c.ppi_nets.clone() }
}

// --------------------------------------------------------------------------- fault simulation
struct Fsim<'a> { c: &'a Circ, scratch: Vec<V>, touched: Vec<usize>, inq: Vec<bool>, heap: BinaryHeap<Reverse<usize>>, obs_set: Vec<Vec<usize>> }

impl<'a> Fsim<'a> {
    fn new(c: &'a Circ) -> Fsim<'a> {
        let mut obs_set = vec![vec![]; c.n];
        for (k, o) in c.obs.iter().enumerate() { obs_set[*o].push(k); }
        Fsim { c, scratch: vec![VX; c.n], touched: vec![], inq: vec![false; c.gates.len()], heap: BinaryHeap::new(), obs_set }
    }
    fn reset(&mut self, good: &[V]) { self.scratch.clear(); self.scratch.extend_from_slice(good); self.touched.clear(); }
    /// bits of the block that detect `f` (good values `good`, observation masks per observation point)
    fn detect(&mut self, f: &Fault, good: &[V], obsmask: &[u64], valid: u64) -> u64 {
        let c = self.c;
        // activation / initialisation conditions
        let stuck = if f.sa == 0 { V0 } else { V1 };
        let gv = good[f.net];
        let mut act = if f.sa == 0 { gv.k1() } else { gv.k0() };
        if let Some((n1, iv)) = f.init { act &= if iv == 0 { good[n1].k0() } else { good[n1].k1() }; }
        act &= valid;
        if act == 0 { return 0; }
        for &t in &self.touched { self.scratch[t] = good[t]; }
        self.touched.clear();
        let set = |me: &mut Fsim, net: usize, v: V| { if !me.touched.contains(&net) { me.touched.push(net); } me.scratch[net] = v; };
        let mut det = 0u64;
        match f.branch {
            None => {
                set(self, f.net, stuck);
                for &g in &c.fanout[f.net] { if !self.inq[g] { self.inq[g] = true; self.heap.push(Reverse(g)); } }
            }
            Some((g, k)) => {
                let gate = &c.gates[g];
                let scr = &self.scratch;
                let v = run(&gate.prog, &|i| if i == k { stuck } else { scr[gate.ins[i]] });
                if v != good[gate.out] {
                    set(self, gate.out, v);
                    for &h in &c.fanout[gate.out] { if !self.inq[h] { self.inq[h] = true; self.heap.push(Reverse(h)); } }
                }
            }
        }
        while let Some(Reverse(g)) = self.heap.pop() {
            self.inq[g] = false;
            let gate = &c.gates[g];
            if f.branch.is_none() && gate.out == f.net { continue; }
            let scr = &self.scratch;
            let v = run(&gate.prog, &|i| scr[gate.ins[i]]);
            if v != self.scratch[gate.out] {
                set(self, gate.out, v);
                for &h in &c.fanout[gate.out] { if !self.inq[h] { self.inq[h] = true; self.heap.push(Reverse(h)); } }
            }
        }
        for &t in &self.touched {
            for &k in &self.obs_set[t] {
                let (g, fv) = (good[t], self.scratch[t]);
                det |= ((g.k1() & fv.k0()) | (g.k0() & fv.k1())) & obsmask[k];
            }
        }
        for &t in &self.touched { self.scratch[t] = good[t]; }
        self.touched.clear();
        det & act
    }
}

// --------------------------------------------------------------------------- PODEM
struct Podem<'a> { c: &'a Circ, reach: &'a [bool], ctrl: &'a [bool], level: &'a [u32], g: Vec<V>, f: Vec<V>, fault: Fault, backtracks: usize }

impl<'a> Podem<'a> {
    fn new(c: &'a Circ, reach: &'a [bool], ctrl: &'a [bool], level: &'a [u32], fault: Fault) -> Podem<'a> {
        let mut p = Podem { c, reach, ctrl, level, g: vec![VX; c.n], f: vec![VX; c.n], fault, backtracks: 0 };
        for k in 0..c.n { if let Src::Const(v) = c.src[k] { p.g[k] = V::of(v); p.f[k] = V::of(v); } }
        // propagate constants
        for (i, _) in c.gates.iter().enumerate() { p.eval_gate(i); }
        p.inject_site();
        for (i, _) in c.gates.iter().enumerate() { p.eval_gate(i); }
        p
    }
    fn inject_site(&mut self) {
        if self.fault.branch.is_none() { self.f[self.fault.net] = if self.fault.sa == 0 { V0 } else { V1 }; }
    }
    fn eval_gate(&mut self, i: usize) -> bool {
        let gate = &self.c.gates[i];
        let gv = { let g = &self.g; run(&gate.prog, &|k| g[gate.ins[k]]) };
        let fv = {
            let f = &self.f;
            let st = if self.fault.sa == 0 { V0 } else { V1 };
            match self.fault.branch { Some((bg, bk)) if bg == i => run(&gate.prog, &|k| if k == bk { st } else { f[gate.ins[k]] }), _ => run(&gate.prog, &|k| f[gate.ins[k]]) }
        };
        let fv = if self.fault.branch.is_none() && gate.out == self.fault.net { if self.fault.sa == 0 { V0 } else { V1 } } else { fv };
        let ch = gv != self.g[gate.out] || fv != self.f[gate.out];
        self.g[gate.out] = gv;
        self.f[gate.out] = fv;
        ch
    }
    fn assign(&mut self, net: usize, v: u8) {
        self.g[net] = V::of(v);
        self.f[net] = V::of(v);
        self.inject_site();
        let mut heap: BinaryHeap<Reverse<usize>> = BinaryHeap::new();
        let mut inq = HashSet::new();
        for &h in &self.c.fanout[net] { if inq.insert(h) { heap.push(Reverse(h)); } }
        if let Some((bg, _)) = self.fault.branch { if inq.insert(bg) { heap.push(Reverse(bg)); } }
        while let Some(Reverse(g)) = heap.pop() {
            inq.remove(&g);
            if self.eval_gate(g) { for &h in &self.c.fanout[self.c.gates[g].out] { if inq.insert(h) { heap.push(Reverse(h)); } } }
        }
    }
    fn dval(&self, n: usize) -> bool { let (g, f) = (self.g[n].bit(), self.f[n].bit()); g != 2 && f != 2 && g != f }
    fn detected(&self) -> bool {
        if let Some((n1, iv)) = self.fault.init { if self.g[n1].bit() != iv { return false; } }
        self.c.obs.iter().any(|&o| self.dval(o))
    }
    fn activated(&self) -> Option<bool> {
        if let Some((n1, iv)) = self.fault.init { let b = self.g[n1].bit(); if b == 2 { return None; } if b != iv { return Some(false); } }
        let site = match self.fault.branch { Some((g, k)) => self.c.gates[g].ins[k], None => self.fault.net };
        match self.g[site].bit() { 2 => None, b => Some(b != self.fault.sa) }
    }
    fn dfrontier(&self) -> Vec<usize> {
        let mut v = vec![];
        for (i, gate) in self.c.gates.iter().enumerate() {
            let o = gate.out;
            if self.g[o].bit() != 2 && self.f[o].bit() != 2 { continue; }
            let has_d = gate.ins.iter().enumerate().any(|(k, &x)| self.dval(x) || (self.fault.branch == Some((i, k)) && self.g[x].bit() != 2 && self.g[x].bit() != self.fault.sa));
            if has_d { v.push(i); }
        }
        v
    }
    fn objective(&self) -> Option<(usize, u8)> {
        if let Some((n1, iv)) = self.fault.init { if self.g[n1].bit() == 2 { return Some((n1, iv)); } }
        let site = match self.fault.branch { Some((g, k)) => self.c.gates[g].ins[k], None => self.fault.net };
        if self.g[site].bit() == 2 { return Some((site, 1 - self.fault.sa)); }
        // D-frontier gates nearest the outputs first (only those with a path to a capture point)
        let mut df: Vec<usize> = self.dfrontier().into_iter().filter(|g| self.reach[self.c.gates[*g].out]).collect();
        df.sort_unstable_by(|a, b| b.cmp(a));
        for gi in df {
            let gate = &self.c.gates[gi];
            let mut best: Option<(usize, u8, i32)> = None;
            for (k, &x) in gate.ins.iter().enumerate() {
                if self.g[x].bit() != 2 || !self.ctrl[x] { continue; }
                for v in [0u8, 1] {
                    let gv = run(&gate.prog, &|j| if j == k { V::of(v) } else { self.g[gate.ins[j]] });
                    let st = if self.fault.sa == 0 { V0 } else { V1 };
                    let fv = run(&gate.prog, &|j| if j == k { V::of(v) } else if self.fault.branch == Some((gi, j)) { st } else { self.f[gate.ins[j]] });
                    let score = if gv.bit() != 2 && fv.bit() != 2 && gv.bit() != fv.bit() { 3 } else if gv.bit() == 2 || fv.bit() == 2 { 1 } else { -1 };
                    if best.map(|b| score > b.2).unwrap_or(true) { best = Some((x, v, score)); }
                }
            }
            if let Some(b) = best.filter(|b| b.2 >= 0) { if self.backtrace(b.0, b.1).is_some() { return Some((b.0, b.1)); } }
        }
        None
    }
    fn backtrace(&self, mut net: usize, mut val: u8) -> Option<(usize, u8)> {
        for _ in 0..10000 {
            match self.c.src[net] {
                Src::Pi(_) | Src::Ppi(_, _) => return Some((net, val)),
                Src::Gate(gi) => {
                    let gate = &self.c.gates[gi];
                    // SCOAP-like guidance: an input that alone sets the output -> the easiest (lowest level);
                    // otherwise all inputs are needed -> the hardest first
                    let mut pick: Option<(usize, u8, i64)> = None;
                    for (k, &x) in gate.ins.iter().enumerate() {
                        if self.g[x].bit() != 2 || !self.ctrl[x] { continue; }
                        for v in [0u8, 1] {
                            let r = run(&gate.prog, &|j| if j == k { V::of(v) } else { self.g[gate.ins[j]] }).bit();
                            let lv = self.level[x] as i64;
                            let score = if r == val { 2_000_000 - lv } else if r == 2 { 1_000_000 + lv } else { -1 };
                            if pick.map(|p| score > p.2).unwrap_or(true) { pick = Some((x, v, score)); }
                        }
                    }
                    let (x, v, sc) = pick?;
                    if sc < 0 { return None; }
                    net = x;
                    val = v;
                }
                _ => return None,
            }
        }
        None
    }
    /// returns Some(assignments) on success, Err(true) aborted, Err(false) untestable
    fn run(&mut self, fixed: &[(usize, u8)], limit: usize) -> Result<Vec<(usize, u8)>, bool> {
        for &(n, v) in fixed { self.assign(n, v); }
        let mut stack: Vec<(usize, u8, bool)> = vec![];
        loop {
            if self.detected() { return Ok(stack.iter().map(|s| (s.0, s.1)).chain(fixed.iter().copied()).collect()); }
            let act = self.activated();
            let mut fail = act == Some(false);
            let mut next: Option<(usize, u8)> = None;
            if !fail {
                match self.objective().and_then(|(n, v)| self.backtrace(n, v)) {
                    Some(d) => next = Some(d),
                    None => fail = true,
                }
            }
            if !fail {
                let (n, v) = next.unwrap();
                stack.push((n, v, false));
                self.assign(n, v);
                continue;
            }
            // backtrack
            loop {
                let Some((n, v, flipped)) = stack.pop() else { return Err(false) };
                self.g[n] = VX;
                self.f[n] = VX;
                self.assign_x(n);
                if !flipped {
                    self.backtracks += 1;
                    if self.backtracks > limit { return Err(true); }
                    stack.push((n, 1 - v, true));
                    self.assign(n, 1 - v);
                    break;
                }
            }
        }
    }
    fn assign_x(&mut self, net: usize) {
        self.g[net] = VX;
        self.f[net] = VX;
        let mut heap: BinaryHeap<Reverse<usize>> = BinaryHeap::new();
        let mut inq = HashSet::new();
        for &h in &self.c.fanout[net] { if inq.insert(h) { heap.push(Reverse(h)); } }
        while let Some(Reverse(g)) = heap.pop() {
            inq.remove(&g);
            if self.eval_gate(g) { for &h in &self.c.fanout[self.c.gates[g].out] { if inq.insert(h) { heap.push(Reverse(h)); } } }
        }
    }
}

// --------------------------------------------------------------------------- compression model
/// decompressor as linear equations: for every (chain, position) the GF(2) combination of the
/// channel variables (channel c at shift cycle t -> variable t * channels + c)
struct Decomp { words: usize, eq: Vec<Vec<Vec<u64>>>, vars: usize }

fn decomp_model(e: &crate::dftadv::EdtState, lens: &[usize], total: usize) -> Decomp {
    let vars = e.channels * total;
    let words = (vars + 63) / 64;
    let mut r: Vec<Vec<u64>> = vec![vec![0; words]; e.lfsr];
    let mut eq: Vec<Vec<Vec<u64>>> = lens.iter().map(|l| vec![vec![0; words]; *l]).collect();
    let xor = |a: &mut Vec<u64>, b: &Vec<u64>| { for (x, y) in a.iter_mut().zip(b) { *x ^= y; } };
    for t in 0..total {
        // chain inputs from the current state
        for (k, taps) in e.ps.iter().enumerate() {
            let mut v = vec![0u64; words];
            for b in taps { xor(&mut v, &r[*b]); }
            let pos = total as i64 - 1 - t as i64; // cell position that keeps this bit
            if pos >= 0 && (pos as usize) < lens[k] { eq[k][pos as usize] = v; }
        }
        // state update
        let mut nr: Vec<Vec<u64>> = vec![vec![0; words]; e.lfsr];
        for i in 0..e.lfsr {
            if i == 0 { for tp in &e.taps { let src = r[*tp].clone(); xor(&mut nr[0], &src); } } else { nr[i] = r[i - 1].clone(); }
            for (c, p) in e.inject.iter().enumerate() { if *p == i { let v = t * e.channels + c; nr[i][v / 64] ^= 1 << (v % 64); } }
        }
        r = nr;
    }
    Decomp { words, eq, vars }
}

/// solve care bits (chain, pos, value); returns channel variable values or None
fn solve(d: &Decomp, care: &[(usize, usize, u8)], rng: &mut u64) -> Option<Vec<u8>> {
    let mut rows: Vec<(Vec<u64>, u8)> = care.iter().map(|(k, p, v)| (d.eq[*k][*p].clone(), *v)).collect();
    let mut pivots: Vec<(usize, usize)> = vec![]; // (row, col)
    let mut r = 0;
    for col in 0..d.vars {
        let (w, b) = (col / 64, 1u64 << (col % 64));
        let Some(p) = (r..rows.len()).find(|i| rows[*i].0[w] & b != 0) else { continue };
        rows.swap(r, p);
        for i in 0..rows.len() {
            if i != r && rows[i].0[w] & b != 0 {
                let (a, bb) = if i < r { let (x, y) = rows.split_at_mut(r); (&mut x[i], &y[0]) } else { let (x, y) = rows.split_at_mut(i); (&mut y[0], &x[r]) };
                for (x, y) in a.0.iter_mut().zip(bb.0.iter()) { *x ^= y; }
                a.1 ^= bb.1;
            }
        }
        pivots.push((r, col));
        r += 1;
        if r == rows.len() { break; }
    }
    if rows[r..].iter().any(|row| row.1 == 1 && row.0.iter().all(|x| *x == 0)) { return None; }
    // free variables random, pivots solved
    let mut x: Vec<u8> = (0..d.vars).map(|_| (rnd(rng) & 1) as u8).collect();
    for &(ri, col) in pivots.iter().rev() {
        let mut v = rows[ri].1;
        for c2 in 0..d.vars { if c2 != col && rows[ri].0[c2 / 64] & (1 << (c2 % 64)) != 0 { v ^= x[c2]; } }
        x[col] = v;
    }
    let _ = d.words;
    Some(x)
}

fn rnd(s: &mut u64) -> u64 {
    *s ^= *s << 13;
    *s ^= *s >> 7;
    *s ^= *s << 17;
    *s
}

/// concrete decompressor run: channel bits per cycle -> loaded values per chain position
fn decomp_fill(e: &crate::dftadv::EdtState, lens: &[usize], total: usize, x: &[u8]) -> Vec<Vec<u8>> {
    let mut r = vec![0u8; e.lfsr];
    let mut out: Vec<Vec<u8>> = lens.iter().map(|l| vec![0; *l]).collect();
    for t in 0..total {
        for (k, taps) in e.ps.iter().enumerate() {
            let v = taps.iter().fold(0u8, |a, b| a ^ r[*b]);
            let pos = total as i64 - 1 - t as i64;
            if pos >= 0 && (pos as usize) < lens[k] { out[k][pos as usize] = v; }
        }
        let mut nr = vec![0u8; e.lfsr];
        for i in 0..e.lfsr {
            nr[i] = if i == 0 { e.taps.iter().fold(0, |a, t| a ^ r[*t]) } else { r[i - 1] };
            for (c, p) in e.inject.iter().enumerate() { if *p == i { nr[i] ^= x[t * e.channels + c]; } }
        }
        r = nr;
    }
    out
}

// --------------------------------------------------------------------------- commands
impl Session {
    pub fn atpg_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "create_test_patterns" | "run_atpg" | "atpg" => self.c_atpg(a),
            "report_atpg" | "report_test_coverage" | "report_faults" => self.c_report_atpg(a),
            "write_test_patterns" | "write_patterns" => self.c_write_patterns(a),
            "write_simulation_models" | "write_verilog_models" => self.c_write_models(a),
            _ => return None,
        })
    }

    fn c_atpg(&mut self, a: &[String]) -> R {
        let x = args(a, &["-fault_model", "-capture", "-random_patterns", "-abort_limit", "-max_patterns", "-seed"]);
        let model = x.get("-fault_model").cloned().unwrap_or("stuck_at".into());
        if !["stuck_at", "transition"].contains(&model.as_str()) { return err("create_test_patterns: -fault_model stuck_at|transition (ATPG-001)"); }
        let capture = x.get("-capture").cloned().unwrap_or(if model == "transition" { "atspeed".into() } else { "slow".into() });
        if model == "transition" && self.dftx.occ.is_empty() { crate::warn!("ATPG-002", "Transition patterns without OCC: launch / capture pulses come from the tester clock (no at-speed guarantee)"); }
        let compressed = self.dftx.edt.is_some() && !x.has("-no_compression");
        let limit = x.num("-abort_limit").unwrap_or(64.0) as usize;
        let maxp = x.num("-max_patterns").unwrap_or(100000.0) as usize;
        let mut seed: u64 = x.num("-seed").unwrap_or(12345.0) as u64 | 1;
        let t0 = std::time::Instant::now();
        let (c1, cells, pis, pos, cons) = self.build_circ(&model).map_err(|e| Flow::Err(format!("create_test_patterns: {} (ATPG-003)", e)))?;
        let chains = self.adv_chains();
        let cidx: HashMap<String, usize> = cells.iter().enumerate().map(|(i, c)| (c.clone(), i)).collect();
        let chs: Vec<(String, Vec<usize>, String, String)> = chains.iter().map(|(n, c, si, so)| (n.clone(), c.iter().map(|x| cidx[x]).collect(), si.clone(), so.clone())).collect();
        let lens: Vec<usize> = chs.iter().map(|c| c.1.len()).collect();
        let lmax = *lens.iter().max().unwrap_or(&0);
        let edt = if compressed { self.dftx.edt.clone() } else { None };
        let total_shift = lmax + edt.as_ref().map(|e| e.init_cycles).unwrap_or(0);
        let dm = edt.as_ref().map(|e| decomp_model(e, &lens, total_shift));
        let pos_of: Vec<(usize, usize)> = { let mut v = vec![(0, 0); cells.len()]; for (k, c) in chs.iter().enumerate() { for (i, ci) in c.1.iter().enumerate() { v[*ci] = (k, i); } } v };
        let circ = if model == "transition" { unroll(&c1) } else { c1.clone() };
        let base_n = c1.n;
        // ---- fault list (collapsed: stems + branches of multi-fanout nets), on the original nets
        let nl = self.nl.as_ref().unwrap();
        let mut faults: Vec<Fault> = vec![];
        let mut site_name: Vec<String> = vec![];
        let mut ip_sites = 0usize;
        for net in 0..base_n {
            if !nl.net_alive(net) { continue; }
            if let Some(PinRef::Cell(d, _)) = nl.driver(net) {
                if nl.cell(d).attrs.iter().any(|a| a.starts_with("dft_ip:")) { ip_sites += 1; continue; }
            }
            let interesting = matches!(c1.src[net], Src::Gate(_) | Src::Pi(_) | Src::Ppi(_, _)) && (!c1.fanout[net].is_empty() || c1.obs.contains(&net));
            if !interesting { continue; }
            let nm = nl.net(net).name.clone();
            for sa in [0u8, 1] {
                if model == "transition" {
                    faults.push(Fault { net: net + base_n, sa, branch: None, init: Some((net, sa)), status: 0 });
                } else {
                    faults.push(Fault { net, sa, branch: None, init: None, status: 0 });
                }
                site_name.push(format!("{} {}", nm, if model == "transition" { if sa == 0 { "slow-to-rise" } else { "slow-to-fall" } } else if sa == 0 { "sa0" } else { "sa1" }));
                if model == "stuck_at" && c1.fanout[net].len() > 1 {
                    for &g in &c1.fanout[net] {
                        let into_ip = matches!(nl.driver(c1.gates[g].out), Some(PinRef::Cell(d, _)) if nl.cell(d).attrs.iter().any(|a| a.starts_with("dft_ip:")));
                        if into_ip { continue; }
                        for (k, &i) in c1.gates[g].ins.iter().enumerate() {
                            if i == net {
                                faults.push(Fault { net, sa, branch: Some((g, k)), init: None, status: 0 });
                                site_name.push(format!("{} {} (branch {})", nm, if sa == 0 { "sa0" } else { "sa1" }, g));
                            }
                        }
                    }
                }
            }
        }
        let nf = faults.len();
        // ---- helpers: simulate patterns, fault-simulate, record expectations
        let npi = pis.len();
        let ncell = cells.len();
        let obsmask_all = vec![!0u64; circ.obs.len()];
        let mut pats: Vec<Pat> = vec![];
        let mut rand_det = 0;
        let mut fsim = Fsim::new(&circ);
        let simulate_block = |circ: &Circ, block: &[(Vec<u8>, Vec<u8>)]| -> Vec<V> {
            let mut piv = vec![V0; npi];
            let mut ppv = vec![V0; ncell];
            for (b, (pi, ld)) in block.iter().enumerate() {
                for (i, v) in pi.iter().enumerate() { let m = 1u64 << b; if *v == 1 { piv[i].one |= m; piv[i].zero &= !m; } else if *v == 2 { piv[i].one |= m; } }
                for (i, v) in ld.iter().enumerate() { let m = 1u64 << b; if *v == 1 { ppv[i].one |= m; ppv[i].zero &= !m; } else if *v == 2 { ppv[i].one |= m; } }
            }
            let mut vals = vec![VX; circ.n];
            circ.sim(&piv, &ppv, &mut vals);
            vals
        };
        let commit = |block: Vec<(Vec<u8>, Vec<u8>, Vec<Vec<u8>>)>, faults: &mut Vec<Fault>, pats: &mut Vec<Pat>, fsim: &mut Fsim| -> usize {
            if block.is_empty() { return 0; }
            let bb: Vec<(Vec<u8>, Vec<u8>)> = block.iter().map(|b| (b.0.clone(), b.1.clone())).collect();
            let vals = simulate_block(fsim.c, &bb);
            fsim.reset(&vals);
            let valid = if block.len() == 64 { !0 } else { (1u64 << block.len()) - 1 };
            let mut useful = vec![false; block.len()];
            let mut newly = 0;
            for f in faults.iter_mut().filter(|f| f.status == 0) {
                let d = fsim.detect(f, &vals, &obsmask_all, valid);
                if d != 0 { f.status = 1; newly += 1; useful[d.trailing_zeros() as usize] = true; }
            }
            for (b, (pi, ld, ch)) in block.into_iter().enumerate() {
                if !useful[b] { continue; }
                let bit = |v: V| -> u8 { let m = 1u64 << b; if v.k1() & m != 0 { 1 } else if v.k0() & m != 0 { 0 } else { 2 } };
                let po: Vec<u8> = if model == "transition" { vec![2; pos.len()] } else { (0..pos.len()).map(|i| bit(vals[fsim.c.obs[i]])).collect() };
                let cap: Vec<u8> = (0..ncell).map(|i| bit(vals[fsim.c.obs[fsim.c.n_po + i]])).collect();
                pats.push(Pat { pi, load: ld, po, cap, chan: ch });
            }
            newly
        };
        // fill a test cube into a concrete load (compressed: through the decompressor)
        let fill = |cube_pi: &[u8], cube_ld: &[u8], rng: &mut u64| -> Option<(Vec<u8>, Vec<u8>, Vec<Vec<u8>>)> {
            let pi: Vec<u8> = cube_pi.iter().map(|v| if *v == 2 { (rnd(rng) & 1) as u8 } else { *v }).collect();
            match (&edt, &dm) {
                (Some(e), Some(d)) => {
                    let care: Vec<(usize, usize, u8)> = cube_ld.iter().enumerate().filter(|(_, v)| **v != 2).map(|(i, v)| (pos_of[i].0, pos_of[i].1, *v)).collect();
                    let xs = solve(d, &care, rng)?;
                    let f = decomp_fill(e, &lens, total_shift, &xs);
                    let ld: Vec<u8> = (0..ncell).map(|i| f[pos_of[i].0][pos_of[i].1]).collect();
                    let ch: Vec<Vec<u8>> = (0..total_shift).map(|t| (0..e.channels).map(|c| xs[t * e.channels + c]).collect()).collect();
                    Some((pi, ld, ch))
                }
                _ => Some((pi, cube_ld.iter().map(|v| if *v == 2 { (rnd(rng) & 1) as u8 } else { *v }).collect(), vec![])),
            }
        };
        // ---- phase 1: random patterns (64 per block) while they keep detecting
        let nrand = x.num("-random_patterns").unwrap_or(256.0) as usize;
        let mut done_rand = 0;
        while done_rand < nrand && pats.len() < maxp {
            let mut block = vec![];
            for _ in 0..64 {
                let cube_pi = vec![2u8; npi];
                let cube_ld = vec![2u8; ncell];
                if let Some(b) = fill(&cube_pi, &cube_ld, &mut seed) { block.push(b); }
            }
            let nd = commit(block, &mut faults, &mut pats, &mut fsim);
            rand_det += nd;
            done_rand += 64;
            if nd * 1000 < nf { break; }
        }
        // ---- phase 2: deterministic PODEM with dynamic compaction
        let src_index = |net: usize| -> Option<(bool, usize, bool)> { match circ.src[net] { Src::Pi(i) => Some((true, i, false)), Src::Ppi(i, inv) => Some((false, i, inv)), _ => None } };
        // structural classification: observability (any path to a capture point) and X in the fan-in cone
        let mut reach = vec![false; circ.n];
        for &o in &circ.obs { reach[o] = true; }
        for g in circ.gates.iter().rev() { if reach[g.out] { for &i in &g.ins { reach[i] = true; } } }
        let mut xcone = vec![false; circ.n];
        for k in 0..circ.n { if matches!(circ.src[k], Src::X | Src::None) { xcone[k] = true; } }
        for g in &circ.gates { xcone[g.out] = g.ins.iter().any(|i| xcone[*i]); }
        let mut ctrl = vec![false; circ.n];
        for k in 0..circ.n { if matches!(circ.src[k], Src::Pi(_) | Src::Ppi(_, _)) { ctrl[k] = true; } }
        for g in &circ.gates { ctrl[g.out] = g.ins.iter().any(|i| ctrl[*i]); }
        let mut level = vec![0u32; circ.n];
        for g in &circ.gates { level[g.out] = g.ins.iter().map(|i| level[*i]).max().unwrap_or(0) + 1; }
        let mut dbg_ab = (0usize, 0usize, 0usize);
        let mut block: Vec<(Vec<u8>, Vec<u8>, Vec<Vec<u8>>)> = vec![];
        let order: Vec<usize> = (0..faults.len()).collect();
        for &fi in &order {
            if faults[fi].status != 0 || pats.len() + block.len() >= maxp { continue; }
            { let f = &faults[fi]; let out = match f.branch { Some((g, _)) => circ.gates[g].out, None => f.net }; if !reach[out] { faults[fi].status = 4; continue; } }
            let mut pd = Podem::new(&circ, &reach, &ctrl, &level, faults[fi].clone());
            let rr = pd.run(&[], limit);
            if std::env::var("RSYNTH_ATPG_DEBUG").is_ok() { eprintln!("fault {} {:?} -> {:?} bt {}", site_name[fi], faults[fi], rr.as_ref().map(|v| v.len()), pd.backtracks); }
            match rr {
                Err(true) => { faults[fi].status = 3; dbg_ab.0 += 1; continue; }
                Err(false) => {
                    let f = &faults[fi];
                    let site = match f.branch { Some((g, k)) => circ.gates[g].ins[k], None => f.net };
                    let out = match f.branch { Some((g, _)) => circ.gates[g].out, None => f.net };
                    let blocked = !reach[out] || !ctrl[site] || f.init.map(|(n1, _)| !ctrl[n1]).unwrap_or(false);
                    // proven redundant only when the search ran on X-free logic; else ATPG-untestable
                    faults[fi].status = if blocked { 4 } else if f.init.is_some() || xcone[site] { 5 } else { 2 };
                    continue;
                }
                Ok(asg) => {
                    let mut cube_pi = vec![2u8; npi];
                    let mut cube_ld = vec![2u8; ncell];
                    for (n, v) in &asg { if let Some((is_pi, i, inv)) = src_index(*n) { if is_pi { cube_pi[i] = *v; } else { cube_ld[i] = v ^ inv as u8; } } }
                    if compressed && fill(&cube_pi, &cube_ld, &mut seed.clone()).is_none() { faults[fi].status = 3; dbg_ab.1 += 1; continue; }
                    // dynamic compaction: merge more faults into this cube
                    let mut fixed: Vec<(usize, u8)> = asg.clone();
                    let mut tries = 0;
                    for &fj in &order {
                        if fj == fi || faults[fj].status != 0 { continue; }
                        tries += 1;
                        if tries > 24 { break; }
                        let mut p2 = Podem::new(&circ, &reach, &ctrl, &level, faults[fj].clone());
                        if let Ok(a2) = p2.run(&fixed, limit / 4 + 2) {
                            let (mut cp, mut cl) = (cube_pi.clone(), cube_ld.clone());
                            for (n, v) in &a2 { if let Some((is_pi, i, inv)) = src_index(*n) { if is_pi { cp[i] = *v; } else { cl[i] = v ^ inv as u8; } } }
                            if compressed && fill(&cp, &cl, &mut seed.clone()).is_none() { continue; }
                            cube_pi = cp;
                            cube_ld = cl;
                            fixed = a2;
                        }
                    }
                    if let Some(b) = fill(&cube_pi, &cube_ld, &mut seed) { block.push(b); }
                    if block.len() == 64 { commit(std::mem::take(&mut block), &mut faults, &mut pats, &mut fsim); }
                    // the target fault is detected by construction; make sure it is counted
                }
            }
        }
        commit(std::mem::take(&mut block), &mut faults, &mut pats, &mut fsim);
        // second pass: aborted faults again with a 16x larger backtrack limit (no compaction)
        for fi in 0..faults.len() {
            if faults[fi].status != 3 || pats.len() + block.len() >= maxp { continue; }
            let mut pd = Podem::new(&circ, &reach, &ctrl, &level, faults[fi].clone());
            if let Ok(asg) = pd.run(&[], limit * 16) {
                let mut cube_pi = vec![2u8; npi];
                let mut cube_ld = vec![2u8; ncell];
                for (n, v) in &asg { if let Some((is_pi, i, inv)) = src_index(*n) { if is_pi { cube_pi[i] = *v; } else { cube_ld[i] = v ^ inv as u8; } } }
                if let Some(b) = fill(&cube_pi, &cube_ld, &mut seed) { faults[fi].status = 0; block.push(b); dbg_ab.0 -= 1; }
                if block.len() == 64 { commit(std::mem::take(&mut block), &mut faults, &mut pats, &mut fsim); }
            }
        }
        commit(std::mem::take(&mut block), &mut faults, &mut pats, &mut fsim);
        // targeted faults the commit did not see as detected (X fill) go back to aborted
        for f in faults.iter_mut() { if f.status == 0 { f.status = 3; dbg_ab.2 += 1; } }
        if std::env::var("RSYNTH_ATPG_DEBUG").is_ok() { eprintln!("aborts: podem {} unencodable {} not-confirmed {}", dbg_ab.0, dbg_ab.1, dbg_ab.2); }
        let det = faults.iter().filter(|f| f.status == 1).count();
        let red = faults.iter().filter(|f| f.status == 2).count();
        let ab = faults.iter().filter(|f| f.status == 3).count();
        let ut = faults.iter().filter(|f| f.status == 4).count();
        let an = faults.iter().filter(|f| f.status == 5).count();
        let untested: Vec<String> = faults.iter().enumerate().filter(|(_, f)| f.status != 1).map(|(i, f)| format!("{:<4} {}", ["UD", "DT", "RE", "AB", "UT", "AU"][f.status as usize], site_name[i])).collect();
        let fc = 100.0 * det as f64 / nf.max(1) as f64;
        let tc = 100.0 * det as f64 / (nf - red - ut).max(1) as f64;
        let scan_clocks: Vec<String> = match &self.dftx.test_clk { Some(t) if !self.dftx.occ.is_empty() => vec![t.clone()], _ => {
            let mut v: Vec<String> = self.dft.chains.iter().map(|c| c.1.clone()).filter(|d| d != "all").collect();
            if v.is_empty() || self.dft.chains.iter().any(|c| c.1 == "all") { v.extend(self.func_clock_periods_pub().into_iter().map(|c| c.0)); }
            let nl = self.nl.as_ref().unwrap();
            v.retain(|c| nl.port_by_name(c).is_some());
            v.sort(); v.dedup(); v } };
        let fast_clocks: Vec<String> = self.dftx.occ.iter().map(|o| o.0.clone()).collect();
        if ip_sites > 0 { crate::info!("ATPG-099", "{} net(s) inside the DFT IP (TAP / OCC / compressor / MBIST) excluded from the scan fault list: they are covered by the JTAG, chain and MBIST tests", ip_sites); }
        crate::info!("ATPG-100", "{} ATPG ({} capture{}): {} fault(s), {} detected ({} by random patterns), {} redundant, {} unused/blocked, {} ATPG-untestable, {} aborted; fault coverage {:.2}%, test coverage {:.2}%; {} pattern(s), {} shift cycle(s) per load ({:.2}s)",
            model, capture, if compressed { ", compressed" } else { "" }, nf, det, rand_det, red, ut, an, ab, fc, tc, pats.len(), total_shift, t0.elapsed().as_secs_f64());
        self.atpg = Some(PatternSet { model, capture, compressed, cells, chains: chs, pis, pos, pats, constraints: cons, stats: (nf, det, red, ab, ut, rand_det, an), untested, shift_len: total_shift, scan_clocks, fast_clocks });
        Ok(format!("{:.2}", tc))
    }

    fn c_report_atpg(&mut self, a: &[String]) -> R {
        let p = self.atpg.as_ref().ok_or_else(|| Flow::Err("report_atpg: no patterns (create_test_patterns) (ATPG-010)".into()))?;
        let (nf, det, red, ab, ut, rd, an) = p.stats;
        crate::out!("****************************************\nReport : atpg ({} / {} capture{})\n****************************************", p.model, p.capture, if p.compressed { " / compressed" } else { "" });
        crate::out!("  fault classes        faults");
        crate::out!("  DT detected          {:>7}  ({} by random patterns)", det, rd);
        crate::out!("  RE redundant         {:>7}", red);
        crate::out!("  UT unused / blocked  {:>7}   (no structural path: black-box inputs, tied logic)", ut);
        crate::out!("  AU ATPG untestable   {:>7}   (X sources / test constraints)", an);
        crate::out!("  AB aborted           {:>7}", ab);
        crate::out!("  total                {:>7}", nf);
        crate::out!("  fault coverage       {:>7.2}%", 100.0 * det as f64 / nf.max(1) as f64);
        crate::out!("  test coverage        {:>7.2}%", 100.0 * det as f64 / (nf - red - ut).max(1) as f64);
        crate::out!("  patterns             {:>7}   scan cells {}  chains {}  shift cycles / load {}", p.pats.len(), p.cells.len(), p.chains.len(), p.shift_len);
        crate::out!("  tester cycles        {:>7}   (setup + patterns x (shift + capture) + final unload)", 2 + p.pats.len() * (p.shift_len + 1) + p.shift_len);
        if a.iter().any(|x| x == "-faults") {
            for u in p.untested.iter().take(100000) { crate::out!("    {}", u); }
        }
        Ok(format!("{:.2}", 100.0 * det as f64 / (nf - red - ut).max(1) as f64))
    }

    // ------------------------------------------------------------------ tester cycles
    /// cycle table: (inputs, expected outputs, scan clock pulse, at-speed capture, comment)
    fn tester_cycles(&self, p: &PatternSet) -> Result<(Vec<String>, Vec<String>, Vec<(Vec<u8>, Vec<u8>, bool, bool, String)>), String> {
        let nl = self.nl.as_ref().ok_or("no design")?;
        let mut ins: Vec<String> = vec![];
        let mut outs: Vec<String> = vec![];
        let mut ids = nl.port_ids();
        ids.sort_by_key(|q| nl.ports[*q].name.clone());
        for q in ids { let pt = &nl.ports[q]; if !pt.alive { continue; } match pt.dir { Dir::In => ins.push(pt.name.clone()), Dir::Out => outs.push(pt.name.clone()), _ => {} } }
        let ii: HashMap<&str, usize> = ins.iter().enumerate().map(|(i, n)| (n.as_str(), i)).collect();
        let oi: HashMap<&str, usize> = outs.iter().enumerate().map(|(i, n)| (n.as_str(), i)).collect();
        let se = self.dftx.scan_en.clone().or(self.dft.scan_enable.clone()).unwrap_or("test_se".into());
        let edt = if p.compressed { self.dftx.edt.clone() } else { None };
        let lens: Vec<usize> = p.chains.iter().map(|c| c.1.len()).collect();
        let t = p.shift_len;
        let mut base = vec![0u8; ins.len()];
        for (n, v) in &p.constraints { if let Some(i) = ii.get(n.as_str()) { base[*i] = *v; } }
        let clk_set: Vec<usize> = p.scan_clocks.iter().chain(p.fast_clocks.iter()).filter_map(|c| ii.get(c.as_str()).copied()).collect();
        for &c in &clk_set { base[c] = 0; }
        let mut cyc: Vec<(Vec<u8>, Vec<u8>, bool, bool, String)> = vec![];
        // structural scan state
        let mut contents: Vec<Vec<u8>> = lens.iter().map(|l| vec![2u8; *l]).collect();
        let mut lfsr: Vec<u8> = edt.as_ref().map(|e| vec![0; e.lfsr]).unwrap_or_default();
        let set_in = |v: &mut Vec<u8>, n: &str, b: u8| { if let Some(i) = ii.get(n) { v[*i] = b; } };
        // test setup: clear the decompressor with one slow capture-like cycle
        let mut v = base.clone();
        set_in(&mut v, &se, 0);
        cyc.push((v, vec![2; outs.len()], true, false, "test_setup".into()));
        let npat = p.pats.len();
        for k in 0..=npat {
            let pat = p.pats.get(k);
            // shift: load pattern k (or zeros for the final unload) and unload capture k-1
            for c in 0..t {
                let mut v = base.clone();
                set_in(&mut v, &se, 1);
                if let Some(e) = &edt { set_in(&mut v, &e.clear, 0); }
                if let Some(pt) = pat { for (i, n) in p.pis.iter().enumerate() { set_in(&mut v, n, pt.pi[i]); } }
                let mut exp = vec![2u8; outs.len()];
                let so: Vec<u8> = contents.iter().map(|ch| *ch.last().unwrap_or(&2)).collect();
                let si: Vec<u8> = match &edt {
                    Some(e) => {
                        let xs: Vec<u8> = pat.map(|pt| pt.chan[c].clone()).unwrap_or(vec![0; e.channels]);
                        for (j, n) in e.ci.iter().enumerate() { set_in(&mut v, n, xs[j]); }
                        for (j, g) in e.comp.iter().enumerate() {
                            let mut b = 0u8;
                            for kk in g { if so[*kk] == 2 { b = 2; break; } b ^= so[*kk]; }
                            if let Some(o) = oi.get(e.co[j].as_str()) { exp[*o] = b; }
                        }
                        let s: Vec<u8> = e.ps.iter().map(|tp| tp.iter().fold(0, |a, b| a ^ lfsr[*b])).collect();
                        let mut nr = vec![0u8; e.lfsr];
                        for i in 0..e.lfsr {
                            nr[i] = if i == 0 { e.taps.iter().fold(0, |a, tt| a ^ lfsr[*tt]) } else { lfsr[i - 1] };
                            for (cc, pp) in e.inject.iter().enumerate() { if *pp == i { nr[i] ^= xs[cc]; } }
                        }
                        lfsr = nr;
                        s
                    }
                    None => {
                        let mut s = vec![];
                        for (kk, (_, cl, si, so_p)) in p.chains.iter().enumerate() {
                            let pos = t as i64 - 1 - c as i64;
                            let b = match pat { Some(pt) if pos >= 0 && (pos as usize) < cl.len() => pt.load[cl[pos as usize]], _ => 0 };
                            set_in(&mut v, si, b);
                            if let Some(o) = oi.get(so_p.as_str()) { exp[*o] = so[kk]; }
                            s.push(b);
                        }
                        s
                    }
                };
                for (kk, ch) in contents.iter_mut().enumerate() { if ch.is_empty() { continue; } ch.pop(); ch.insert(0, si[kk]); }
                cyc.push((v, exp, true, false, if c == 0 { format!("pattern {} load{}", k, if k > 0 { format!(" / unload {}", k - 1) } else { String::new() }) } else { String::new() }));
            }
            let Some(pt) = pat else { break };
            // the loaded state must equal the pattern
            for (kk, (_, cl, _, _)) in p.chains.iter().enumerate() {
                for (i, ci) in cl.iter().enumerate() {
                    if contents[kk][i] != pt.load[*ci] { return Err(format!("internal: pattern {} chain {} position {}: shifted {} expected {}", k, kk, i, contents[kk][i], pt.load[*ci])); }
                }
            }
            // capture
            let mut v = base.clone();
            set_in(&mut v, &se, 0);
            if let Some(e) = &edt { set_in(&mut v, &e.clear, 1); lfsr = vec![0; e.lfsr]; }
            for (i, n) in p.pis.iter().enumerate() { set_in(&mut v, n, pt.pi[i]); }
            let mut exp = vec![2u8; outs.len()];
            for (i, n) in p.pos.iter().enumerate() { if let Some(o) = oi.get(n.as_str()) { exp[*o] = pt.po[i]; } }
            let atspeed = p.capture == "atspeed" && !p.fast_clocks.is_empty();
            if p.model == "transition" && !atspeed {
                // launch-on-capture with tester clocks: launch pulse (no strobe), then capture pulse
                cyc.push((v.clone(), vec![2; outs.len()], true, false, format!("pattern {} launch", k)));
            }
            cyc.push((v, exp, !atspeed, atspeed, format!("pattern {} capture", k)));
            for (kk, (_, cl, _, _)) in p.chains.iter().enumerate() { for (i, ci) in cl.iter().enumerate() { contents[kk][i] = pt.cap[*ci]; } }
        }
        Ok((ins, outs, cyc))
    }

    fn c_write_patterns(&mut self, a: &[String]) -> R {
        let x = args(a, &["-format", "-output", "-period", "-fast_period", "-netlist", "-models"]);
        let fmt = x.get("-format").cloned().unwrap_or("stil".into());
        let f = x.get("-output").cloned().or(x.pos.first().cloned()).ok_or_else(|| Flow::Err("write_test_patterns: -output required".into()))?;
        let p = self.atpg.clone().ok_or_else(|| Flow::Err("write_test_patterns: no patterns (create_test_patterns) (ATPG-010)".into()))?;
        let per = x.num("-period").unwrap_or(100.0);
        let fast = x.num("-fast_period").unwrap_or(4.0);
        let (ins, outs, cyc) = self.tester_cycles(&p).map_err(|e| Flow::Err(format!("write_test_patterns: {} (ATPG-020)", e)))?;
        let top = self.nl.as_ref().unwrap().name.clone();
        let clk_idx: Vec<usize> = p.scan_clocks.iter().filter_map(|c| ins.iter().position(|i| i == c)).collect();
        let ch = |b: u8, out: bool| -> char { match (b, out) { (0, false) => '0', (1, false) => '1', (0, true) => 'L', (1, true) => 'H', (_, true) => 'X', _ => 'N' } };
        let q = |s: &str| format!("\"{}\"", s);
        let s = match fmt.as_str() {
            "stil" | "stil_flat" => {
                let mut s = format!("STIL 1.0;\nHeader {{\n  Title \"{} {} patterns\";\n  Source \"rsynth create_test_patterns ({} capture{})\";\n  Ann {{* {} pattern(s), {} tester cycle(s), shift length {} *}}\n", top, p.model, p.capture, if p.compressed { ", compressed" } else { "" }, p.pats.len(), cyc.len(), p.shift_len);
                if !p.fast_clocks.is_empty() { s += &format!("  Ann {{* free-running at-speed reference clock(s) {} at {} ns during capture (OCC generates the launch / capture pulses) *}}\n", p.fast_clocks.join(" "), fast); }
                s += "}\nSignals {\n";
                for i in &ins { s += &format!("  {} In;\n", q(i)); }
                for o in &outs { s += &format!("  {} Out;\n", q(o)); }
                s += "}\nSignalGroups {\n";
                let data_in: Vec<&String> = ins.iter().enumerate().filter(|(k, _)| !clk_idx.contains(k)).map(|(_, n)| n).collect();
                s += &format!("  \"_pi\" = '{}';\n", data_in.iter().map(|n| q(n)).collect::<Vec<_>>().join(" + "));
                s += &format!("  \"_clk\" = '{}';\n", clk_idx.iter().map(|k| q(&ins[*k])).collect::<Vec<_>>().join(" + "));
                s += &format!("  \"_po\" = '{}';\n", outs.iter().map(|n| q(n)).collect::<Vec<_>>().join(" + "));
                s += "}\n";
                s += &format!("Timing {{\n  WaveformTable \"_default_WFT_\" {{\n    Period '{}ns';\n    Waveforms {{\n      \"_pi\" {{ 01 {{ '0ns' D/U; }} }}\n      \"_clk\" {{ 01 {{ '0ns' D; '{}ns' D/U; '{}ns' D; }} }}\n      \"_po\" {{ LHX {{ '0ns' X; '{}ns' L/H/X; }} }}\n    }}\n  }}\n}}\n",
                    per, per * 0.5, per * 0.8, per * 0.4);
                // scan structures
                s += "ScanStructures {\n";
                match &self.dftx.edt.as_ref().filter(|_| p.compressed) {
                    Some(e) => { for j in 0..e.channels { s += &format!("  ScanChain \"channel{}\" {{ ScanLength {}; ScanIn {}; ScanOut {}; }}\n", j, p.shift_len, q(&e.ci[j]), q(&e.co[j])); } }
                    None => { for (n, cl, si, so) in &p.chains { s += &format!("  ScanChain {} {{ ScanLength {}; ScanIn {}; ScanOut {}; }}\n", q(n), cl.len(), q(si), q(so)); } }
                }
                s += "}\nPatternBurst \"_burst_\" { PatList { \"_pattern_\" { } } }\nPatternExec { PatternBurst \"_burst_\"; }\n";
                let vec_str = |iv: &Vec<u8>, ev: &Vec<u8>, pulse: bool| -> String {
                    let pi: String = ins.iter().enumerate().filter(|(k, _)| !clk_idx.contains(k)).map(|(k, _)| ch(iv[k], false)).collect();
                    let ck: String = clk_idx.iter().map(|_| if pulse { '1' } else { '0' }).collect();
                    let po: String = ev.iter().map(|b| ch(*b, true)).collect();
                    format!("\"_pi\" = {}; \"_clk\" = {}; \"_po\" = {};", pi, ck, po)
                };
                if fmt == "stil" {
                    // structured: test_setup macro, load_unload / capture procedures with per-pattern data
                    let si_sig: Vec<String> = match self.dftx.edt.as_ref().filter(|_| p.compressed) { Some(e) => e.ci.clone(), None => p.chains.iter().map(|c| c.2.clone()).collect() };
                    let so_sig: Vec<String> = match self.dftx.edt.as_ref().filter(|_| p.compressed) { Some(e) => e.co.clone(), None => p.chains.iter().map(|c| c.3.clone()).collect() };
                    // shift condition: test constraints, scan enable on, other data inputs 0
                    let fixed: Vec<String> = p.constraints.iter().map(|c| c.0.clone()).chain([self.dftx.scan_en.clone().or(self.dft.scan_enable.clone()).unwrap_or("test_se".into())]).chain(self.dftx.edt.iter().map(|e| e.clear.clone())).collect();
                    let cond: Vec<String> = ins.iter().enumerate().filter(|(k, n)| !clk_idx.contains(k) && !si_sig.contains(n)).map(|(k, n)| format!("{} = {};", q(n), if fixed.contains(n) { ch(cyc.get(1).map(|c| c.0[k]).unwrap_or(0), false) } else { '0' })).collect();
                    s += &format!("Procedures {{\n  \"load_unload\" {{\n    W \"_default_WFT_\";\n    C {{ {} }}\n    Shift {{ V {{ {} \"_clk\" = {}; }} }}\n  }}\n  \"capture\" {{\n    W \"_default_WFT_\";\n    V {{ \"_pi\" = #; \"_po\" = #; \"_clk\" = {}; }}\n  }}\n}}\n",
                        cond.join(" "), si_sig.iter().chain(so_sig.iter()).map(|n| format!("{} = #;", q(n))).collect::<Vec<_>>().join(" "), "1".repeat(clk_idx.len()), if p.capture == "atspeed" && !p.fast_clocks.is_empty() { "0".repeat(clk_idx.len()) } else { "1".repeat(clk_idx.len()) });
                    s += &format!("MacroDefs {{\n  \"test_setup\" {{\n    W \"_default_WFT_\";\n    V {{ {} }}\n  }}\n}}\n", vec_str(&cyc[0].0, &cyc[0].1, true));
                    s += "Pattern \"_pattern_\" {\n  W \"_default_WFT_\";\n  Macro \"test_setup\";\n";
                    // group cycles: per pattern t shift cycles then a capture
                    let t = p.shift_len;
                    let mut i = 1;
                    let mut k = 0;
                    while i < cyc.len() {
                        let shift = &cyc[i..(i + t).min(cyc.len())];
                        let col = |name: &str, input: bool| -> String {
                            let (idx, inp) = if input { (ins.iter().position(|x| x == name), true) } else { (outs.iter().position(|x| x == name), false) };
                            // STIL scan data: first character is the bit shifted first
                            shift.iter().map(|c| idx.map(|j| if inp { ch(c.0[j], false) } else { ch(c.1[j], true) }).unwrap_or('X')).collect()
                        };
                        s += &format!("  \"pattern {}\": Call \"load_unload\" {{ {} }}\n", k, si_sig.iter().map(|n| format!("{} = {};", q(n), col(n, true))).chain(so_sig.iter().map(|n| format!("{} = {};", q(n), col(n, false)))).collect::<Vec<_>>().join(" "));
                        i += t;
                        if i < cyc.len() {
                            let c = &cyc[i];
                            let pi: String = ins.iter().enumerate().filter(|(kk, _)| !clk_idx.contains(kk)).map(|(kk, _)| ch(c.0[kk], false)).collect();
                            let po: String = c.1.iter().map(|b| ch(*b, true)).collect();
                            s += &format!("  Call \"capture\" {{ \"_pi\" = {}; \"_po\" = {}; }}\n", pi, po);
                            i += 1;
                            k += 1;
                        }
                    }
                    s += "}\n";
                } else {
                    s += "Pattern \"_pattern_\" {\n  W \"_default_WFT_\";\n";
                    for (iv, ev, pulse, _, cm) in &cyc {
                        if !cm.is_empty() { s += &format!("  Ann {{* {} *}}\n", cm); }
                        s += &format!("  V {{ {} }}\n", vec_str(iv, ev, *pulse));
                    }
                    s += "}\n";
                }
                s
            }
            "verilog" | "verilog_tb" | "testbench" => {
                let mut s = format!("`timescale 1ns/1ps\n// rsynth scan testbench for {}: {} {} patterns ({} capture{}), {} tester cycles\n// load / shift / capture / unload with compare at {} ns of every {} ns cycle\nmodule tb_scan;\n", top, p.pats.len(), p.model, p.capture, if p.compressed { ", compressed" } else { "" }, cyc.len(), per * 0.4, per);
                s += &crate::dftadv::tb_decls(&ins, "reg");
                s += &crate::dftadv::tb_decls(&outs, "wire");
                let all: Vec<String> = ins.iter().chain(outs.iter()).cloned().collect();
                s += &format!("  {} dut (\n{}\n  );\n", top, crate::dftadv::tb_conns(&all));
                let (ni, no) = (ins.len(), outs.len());
                s += &format!("  reg [{}:0] iv; reg [{}:0] ev, mv; integer errors = 0, cyc = 0, pat = -1;\n  reg fast_run = 0;\n", ni - 1, no.max(1) - 1);
                for fc in &p.fast_clocks { if let Some(_) = ins.iter().position(|x| x == fc) { s += &format!("  // free-running at-speed reference (PLL output); the OCC selects / gates it\n  always #({}) {} = ~{};\n", fast / 2.0, crate::dftadv::tb_ref(fc), crate::dftadv::tb_ref(fc)); } }
                s += "  task apply; begin\n";
                for (k, i) in ins.iter().enumerate() { if !clk_idx.contains(&k) && !p.fast_clocks.contains(i) { s += &format!("    {} = iv[{}];\n", crate::dftadv::tb_ref(i), k); } }
                s += "  end endtask\n  task check; begin\n";
                for (k, o) in outs.iter().enumerate() { s += &format!("    if (mv[{k}] && ({o} !== ev[{k}])) begin errors = errors + 1; if (errors < 20) $display(\"MISMATCH cycle %0d pattern %0d: {on} = %b expected %b\", cyc, pat, {o}, ev[{k}]); end\n", k = k, o = crate::dftadv::tb_ref(o), on = o); }
                s += "  end endtask\n";
                s += &format!("  task tcyc(input [{}:0] i, input [{}:0] e, input [{}:0] m, input pulse, input atspeed); begin\n    iv = i; ev = e; mv = m; apply;\n    fast_run = atspeed;\n    #({}); check;\n    #({});\n", ni - 1, no.max(1) - 1, no.max(1) - 1, per * 0.4, per * 0.1);
                for k in &clk_idx { s += &format!("    if (pulse) {} = 1;\n", crate::dftadv::tb_ref(&ins[*k])); }
                s += &format!("    #({});\n", per * 0.3);
                for k in &clk_idx { s += &format!("    {} = 0;\n", crate::dftadv::tb_ref(&ins[*k])); }
                s += &format!("    #({}); fast_run = 0; cyc = cyc + 1;\n  end endtask\n", per * 0.2);
                s += "  initial begin\n";
                for i in &ins { s += &format!("    {} = 0;\n", crate::dftadv::tb_ref(i)); }
                s += "    #1;\n";
                let bits = |v: &Vec<u8>, f: &dyn Fn(u8) -> char| -> String { v.iter().rev().map(|b| f(*b)).collect() };
                for (iv, ev, pulse, atspeed, cm) in &cyc {
                    if cm.starts_with("pattern") && cm.contains("load") { s += &format!("    pat = {};\n", cm.split_whitespace().nth(1).unwrap_or("0")); }
                    let ib = bits(iv, &|b| if b == 1 { '1' } else { '0' });
                    let eb = if no == 0 { "0".to_string() } else { bits(ev, &|b| if b == 1 { '1' } else { '0' }) };
                    let mb = if no == 0 { "0".to_string() } else { bits(ev, &|b| if b == 2 { '0' } else { '1' }) };
                    s += &format!("    tcyc({}'b{}, {}'b{}, {}'b{}, {}, {});\n", ni, ib, no.max(1), eb, no.max(1), mb, *pulse as u8, *atspeed as u8);
                }
                s += &format!("    if (errors == 0) $display(\"SCAN PATTERNS PASSED: %0d pattern(s), %0d cycle(s)\", {}, cyc);\n    else $display(\"SCAN PATTERNS FAILED: %0d mismatch(es)\", errors);\n    $finish;\n  end\nendmodule\n", p.pats.len());
                s
            }
            _ => return err("write_test_patterns: -format stil|stil_flat|verilog (ATPG-021)"),
        };
        std::fs::write(&f, s).map_err(|e| Flow::Err(e.to_string()))?;
        crate::info!("ATPG-030", "Wrote {} {} pattern(s) as {} to '{}' ({} tester cycles of {} ns)", p.pats.len(), p.model, fmt, f, cyc.len(), per);
        Ok(f)
    }

    // ------------------------------------------------------------------ simulation models
    fn c_write_models(&mut self, a: &[String]) -> R {
        let x = args(a, &["-output"]);
        let f = x.get("-output").cloned().or(x.pos.first().cloned()).ok_or_else(|| Flow::Err("write_simulation_models: file name required".into()))?;
        let nl = self.nl()?;
        let mut used: Vec<String> = nl.cell_ids().into_iter().filter_map(|c| nl.cell(c).lib().map(|s| s.to_string())).collect();
        used.sort();
        used.dedup();
        let mut s = String::from("`timescale 1ns/1ps\n// rsynth generated Verilog simulation models (from the Liberty functions); flops / latches have a 1 ns clock-to-q delay\n");
        let vexp = |e: &BExpr| -> String {
            fn go(e: &BExpr) -> String {
                match e { BExpr::Var(v) => v.clone(), BExpr::Const(b) => if *b { "1'b1".into() } else { "1'b0".into() }, BExpr::Not(a) => format!("~({})", go(a)), BExpr::And(a, b) => format!("({} & {})", go(a), go(b)), BExpr::Or(a, b) => format!("({} | {})", go(a), go(b)), BExpr::Xor(a, b) => format!("({} ^ {})", go(a), go(b)) }
            }
            go(e)
        };
        let mut n = 0;
        for m in &used {
            let Some(lc) = self.libs.iter().find_map(|l| l.cells.get(m)) else { continue };
            let pins: Vec<&crate::liberty::LibPin> = lc.pins.iter().collect();
            s += &format!("module {} ({});\n", m, pins.iter().map(|p| p.name.clone()).collect::<Vec<_>>().join(", "));
            for p in &pins { s += &format!("  {} {};\n", if p.dir == Some(Dir::Out) { "output" } else { "input" }, p.name); }
            if let Some(t) = lc.tie { for o in lc.outputs() { s += &format!("  assign {} = 1'b{};\n", o.name, t as u8); } }
            else if lc.icg.is_some() {
                let en: Vec<String> = pins.iter().filter(|p| p.dir != Some(Dir::Out) && !p.is_clock && p.name != "CK").map(|p| p.name.clone()).collect();
                let ck = pins.iter().find(|p| p.is_clock || p.name == "CK").map(|p| p.name.clone()).unwrap_or("CK".into());
                let o = lc.outputs().first().map(|o| o.name.clone()).unwrap_or("GCK".into());
                s += &format!("  reg IQ;\n  always @({} or {}) if (!{}) IQ = {};\n  assign {} = {} & IQ;\n", ck, en.join(" or "), ck, en.join(" | "), o, ck);
            } else if let Some(sq) = &lc.seq {
                s += "  reg IQ;\n  wire IQN = ~IQ;\n";
                let ns = parse_func(&sq.next_state).map(|e| vexp(&e)).unwrap_or("1'bx".into());
                if sq.is_latch {
                    let g = sq.clocked_on.clone();
                    let ge = parse_func(&g).map(|e| vexp(&e)).unwrap_or(g);
                    s += &format!("  always @* if ({}) IQ <= #1 {};\n", ge, ns);
                } else {
                    let neg = sq.clocked_on.starts_with('!') || sq.clocked_on.ends_with('\'');
                    let ck = sq.clocked_on.trim_start_matches('!').trim_end_matches('\'').to_string();
                    let mut sens = vec![format!("{} {}", if neg { "negedge" } else { "posedge" }, ck)];
                    let mut body = String::new();
                    for (p, v) in [(&sq.clear, "1'b0"), (&sq.preset, "1'b1")] {
                        if let Some(p) = p {
                            let low = p.contains('!') || p.ends_with('\'');
                            let pn = p.trim_start_matches('!').trim_end_matches('\'').to_string();
                            sens.push(format!("{} {}", if low { "negedge" } else { "posedge" }, pn));
                            body += &format!("if ({}{}) IQ <= #1 {};\n    else ", if low { "!" } else { "" }, pn, v);
                        }
                    }
                    s += &format!("  always @({})\n    {}IQ <= #1 {};\n", sens.join(" or "), body, ns);
                }
                for o in lc.outputs() {
                    let f = o.function.clone().unwrap_or("IQ".into());
                    let e = parse_func(&f).map(|e| vexp(&e)).unwrap_or("IQ".into());
                    s += &format!("  assign {} = {};\n", o.name, e);
                }
            } else {
                for o in lc.outputs() {
                    let e = o.function.as_deref().and_then(parse_func).map(|e| vexp(&e)).unwrap_or("1'bx".into());
                    s += &format!("  assign {} = {};\n", o.name, e);
                }
            }
            s += "endmodule\n";
            n += 1;
        }
        // memories / black boxes
        let mut bbs: Vec<(String, CellId)> = vec![];
        for c in nl.cell_ids() { if let Kind::BlackBox(b) = &nl.cell(c).kind { if !bbs.iter().any(|x| &x.0 == b) { bbs.push((b.clone(), c)); } } }
        for (b, c) in bbs {
            let mp = self.mem_port_pub(c);
            match mp {
                Some(m) => {
                    let model = crate::dftip::sram_model(&b, m.abits, m.dbits, m.words, &m);
                    s += &model;
                }
                None => {
                    let cl = nl.cell(c);
                    s += &format!("module {} ({});\n", b, cl.pins.iter().map(|p| crate::dftadv::vname(&p.name)).collect::<Vec<_>>().join(", "));
                    for p in &cl.pins { s += &format!("  {} {};\n", if p.dir == Dir::Out { "output" } else { "input" }, crate::dftadv::vname(&p.name)); }
                    for p in cl.pins.iter().filter(|p| p.dir == Dir::Out) { s += &format!("  assign {} = 1'bx;\n", crate::dftadv::vname(&p.name)); }
                    s += "endmodule\n";
                }
            }
            n += 1;
        }
        std::fs::write(&f, s).map_err(|e| Flow::Err(e.to_string()))?;
        crate::info!("ATPG-040", "Wrote {} simulation model(s) to '{}'", n, f);
        Ok(f)
    }
}
