//! ROW / SITE pre-check for placement: before `place_detail` / `legalize_placement` move
//! anything, the standard cells used are checked against the site definitions (LEF SITE),
//! the rows (DEF ROW / create_row) and the placement grid (row height, site width).
//! IO pads / corners / area IO / macros must not overlap or leave the die.
//! Any problem aborts the command with a report of what does not fit and how to fix it.

use crate::netlist::Kind;
use crate::session::{args, Session};
use crate::tcl::{err, Flow, R};
use std::collections::BTreeMap;

const TOL: f64 = 1e-3;

fn multiple(v: f64, unit: f64) -> bool {
    if unit <= 0.0 { return true; }
    let k = v / unit;
    (k - k.round()).abs() * unit < TOL && k.round() >= 1.0
}

#[derive(Default)]
pub struct SiteCheck {
    pub errors: Vec<(String, String)>,   // (id, message)
    pub warnings: Vec<(String, String)>,
    pub summary: Vec<String>,
}

impl Session {
    /// LEF site used by most standard-cell masters (CORE class), if the LEF defines sites
    pub(crate) fn core_site(&self) -> Option<String> {
        let mut n: BTreeMap<&str, usize> = BTreeMap::new();
        for m in self.lef.values() {
            if m.class.starts_with("CORE") && !m.site.is_empty() { *n.entry(m.site.as_str()).or_default() += 1; }
        }
        if let Some((s, _)) = n.iter().max_by_key(|x| *x.1) { return Some(s.to_string()); }
        self.lef_sites.iter().find(|s| s.class.eq_ignore_ascii_case("CORE")).map(|s| s.name.clone())
    }

    /// site name for rows created by the tool
    pub(crate) fn core_site_name(&self) -> String {
        self.core_site().unwrap_or_else(|| "coreSite".into())
    }

    pub(crate) fn row_site_check(&self) -> SiteCheck {
        let mut ck = SiteCheck::default();
        let (Some(nl), Some(fp)) = (self.nl.as_ref(), self.fp.as_ref()) else { return ck };
        let (sw, rh) = (self.site_w(), self.row_h());
        let explicit = fp.rows_explicit && !fp.row_list.is_empty();
        // ---- the rows the placer will use
        let rows_src = if explicit { "explicit rows (create_row / DEF RSROW_)" } else if !fp.row_list.is_empty() { "DEF rows (placement uses the implicit grid)" } else { "implicit rows tiling the core" };
        let mut row_sites: BTreeMap<String, (usize, Vec<f64>, Vec<f64>)> = BTreeMap::new();
        for r in &fp.row_list {
            let e = row_sites.entry(r.site.clone()).or_default();
            e.0 += 1;
            if !e.1.iter().any(|s| (s - r.step).abs() < TOL) { e.1.push(r.step); }
            let h = if r.height > 0.0 { r.height } else { rh };
            if !e.2.iter().any(|s| (s - h).abs() < TOL) { e.2.push(h); }
        }
        ck.summary.push(format!("Placement grid : row height {:.4}um, site width {:.4}um (place.site_width)", rh, sw));
        ck.summary.push(format!("Rows           : {} {}", fp.row_list.len().max(if explicit { 0 } else { fp.rows }), rows_src));
        for (s, (n, steps, hs)) in &row_sites {
            ck.summary.push(format!("  ROW site {:<28} {:>5} row(s), step {}, height {}", s, n, steps.iter().map(|v| format!("{:.4}", v)).collect::<Vec<_>>().join("/"), hs.iter().map(|v| format!("{:.4}", v)).collect::<Vec<_>>().join("/")));
        }
        for s in &self.lef_sites {
            ck.summary.push(format!("  LEF SITE {:<28} CLASS {:<6} {:.4} x {:.4}um", s.name, s.class, s.w, s.h));
        }
        let lsite = |n: &str| self.lef_sites.iter().find(|s| s.name == n);
        // ---- rows against the LEF sites and the placement grid
        for (s, (n, steps, hs)) in &row_sites {
            if !self.lef_sites.is_empty() {
                match lsite(s) {
                    None => ck.errors.push(("PLC-405".into(), format!("{} row(s) use site '{}', which no LEF SITE defines (LEF sites: {})", n, s, self.lef_sites.iter().map(|x| x.name.clone()).collect::<Vec<_>>().join(", ")))),
                    Some(ls) => {
                        for st in steps { if (st - ls.w).abs() > TOL { ck.errors.push(("PLC-406".into(), format!("rows of site '{}' have STEP {:.4}um but the LEF SITE is {:.4}um wide", s, st, ls.w))); } }
                        for h in hs { if (h - ls.h).abs() > TOL { ck.errors.push(("PLC-406".into(), format!("rows of site '{}' are {:.4}um apart (row height) but the LEF SITE is {:.4}um high", s, h, ls.h))); } }
                    }
                }
            }
            for st in steps { if (st - sw).abs() > TOL { ck.errors.push(("PLC-409".into(), format!("rows of site '{}' have STEP {:.4}um but placement uses site width {:.4}um (set_app_var place.site_width {:.4})", s, st, sw, st))); } }
            for h in hs { if (h - rh).abs() > TOL && explicit { ck.errors.push(("PLC-409".into(), format!("rows of site '{}' are {:.4}um high but the placement row height is {:.4}um", s, h, rh))); } }
            if steps.len() > 1 { ck.warnings.push(("PLC-407".into(), format!("rows of site '{}' use different STEPs: {}", s, steps.iter().map(|v| format!("{:.4}", v)).collect::<Vec<_>>().join(", ")))); }
        }
        // implicit grid against the LEF core site
        if fp.row_list.is_empty() {
            if let Some(ls) = self.core_site().and_then(|n| lsite(&n).cloned()) {
                if (ls.w - sw).abs() > TOL || (ls.h - rh).abs() > TOL {
                    ck.errors.push(("PLC-406".into(), format!("the placement grid ({:.4} x {:.4}um) does not match LEF SITE {} ({:.4} x {:.4}um)", sw, rh, ls.name, ls.w, ls.h)));
                }
            }
        }
        // ---- standard cells (movable, CORE class) against rows / sites / grid
        struct M { n: usize, site: String, w: f64, h: f64, first: String }
        let mut masters: BTreeMap<String, M> = BTreeMap::new();
        let mut no_lef = 0usize;
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            let Kind::Lib(l) = &cl.kind else { continue };
            if cl.fixed || cl.has_attr("io_pad") { continue; }
            let Some(m) = self.lef.get(l) else { no_lef += 1; continue };
            if !m.class.starts_with("CORE") { continue; }
            let e = masters.entry(l.clone()).or_insert(M { n: 0, site: m.site.clone(), w: m.w, h: m.h, first: cl.name.clone() });
            e.n += 1;
        }
        // IO pads / corners / area IO / macros must not overlap (the placer treats them as fixed blockages)
        let (ov, out) = self.io_overlaps();
        for o in &ov {
            ck.errors.push(("PLC-411".into(), format!("{} {} overlaps {} {}: ({:.3}, {:.3}) – ({:.3}, {:.3})", o.kind_a, o.a, o.kind_b, o.b, o.r.0, o.r.1, o.r.2, o.r.3)));
        }
        for (n, r) in &out {
            ck.errors.push(("PLC-412".into(), format!("{} extends outside the die: ({:.3}, {:.3}) – ({:.3}, {:.3})", n, r.0, r.1, r.2, r.3)));
        }
        ck.summary.push(format!("IO pads / macros: {} overlap(s), {} outside the die", ov.len(), out.len()));
        let inst: usize = masters.values().map(|m| m.n).sum();
        ck.summary.push(format!("Std-cell masters: {} ({} movable instance(s)){}", masters.len(), inst, if no_lef > 0 { format!("; {} instance(s) without LEF", no_lef) } else { String::new() }));
        let mut by_site: BTreeMap<String, usize> = BTreeMap::new();
        for m in masters.values() { *by_site.entry(if m.site.is_empty() { "(no SITE)".into() } else { m.site.clone() }).or_default() += m.n; }
        for (s, n) in &by_site { ck.summary.push(format!("  cells on SITE {:<26} {:>6} instance(s)", s, n)); }
        let row_has = |s: &str| row_sites.contains_key(s);
        for (name, m) in &masters {
            let what = format!("{} ({} instance(s), e.g. {})", name, m.n, m.first);
            if !m.site.is_empty() {
                if !row_sites.is_empty() && !row_has(&m.site) {
                    ck.errors.push(("PLC-401".into(), format!("{}: LEF SITE '{}' but no row uses it (rows: {})", what, m.site, row_sites.keys().cloned().collect::<Vec<_>>().join(", "))));
                }
                if !self.lef_sites.is_empty() {
                    match lsite(&m.site) {
                        None => ck.errors.push(("PLC-402".into(), format!("{}: SITE '{}' is not defined in the LEF", what, m.site))),
                        Some(ls) => {
                            if (ls.w - sw).abs() > TOL || (ls.h - rh).abs() > TOL {
                                ck.errors.push(("PLC-402".into(), format!("{}: SITE '{}' is {:.4} x {:.4}um but placement uses {:.4} x {:.4}um", what, m.site, ls.w, ls.h, sw, rh)));
                            }
                        }
                    }
                }
            } else if !self.lef_sites.is_empty() {
                ck.warnings.push(("PLC-408".into(), format!("{}: LEF MACRO has no SITE statement", what)));
            }
            if !multiple(m.h, rh) {
                ck.errors.push(("PLC-403".into(), format!("{}: height {:.4}um is not a multiple of the row height {:.4}um", what, m.h, rh)));
            }
            if !multiple(m.w, sw) {
                ck.errors.push(("PLC-404".into(), format!("{}: width {:.4}um is not a multiple of the site width {:.4}um", what, m.w, sw)));
            }
        }
        ck
    }

    /// print the check; Err (abort) when there are mismatches
    pub(crate) fn row_site_precheck(&self, cmd: &str, a: &[String]) -> Result<(), Flow> {
        if a.iter().any(|x| x == "-skip_site_check") {
            crate::warn!("PLC-410", "{}: ROW / SITE pre-check skipped (-skip_site_check)", cmd);
            return Ok(());
        }
        let ck = self.row_site_check();
        if ck.errors.is_empty() {
            for (id, m) in &ck.warnings { crate::warn!(id.as_str(), "{}", m); }
            crate::info!("PLC-400", "{}: ROW / SITE pre-check passed ({})", cmd, ck.summary.iter().find(|s| s.starts_with("Std-cell")).cloned().unwrap_or_default());
            return Ok(());
        }
        crate::out!("\n****************************************\nROW / SITE pre-check : {}\n****************************************", cmd);
        for s in &ck.summary { crate::out!("  {}", s); }
        crate::out!("  Mismatches     : {}", ck.errors.len());
        for (id, m) in ck.errors.iter().take(40) { crate::error!(id.as_str(), "{}", m); }
        if ck.errors.len() > 40 { crate::out!("    ... {} more (check_row_site -verbose)", ck.errors.len() - 40); }
        for (id, m) in ck.warnings.iter().take(20) { crate::warn!(id.as_str(), "{}", m); }
        if ck.errors.iter().any(|e| e.0 == "PLC-411" || e.0 == "PLC-412") {
            crate::out!("  Fix IO overlaps: move_objects / create_pad_ring again (check_io_overlaps lists them; markers in the GUI).");
        }
        crate::out!("  Fix: read the technology LEF with the SITE definitions before the cell LEFs, create the floorplan / rows on that site\n       (initialize_floorplan takes the site from the LEF; create_row -site), or set_app_var place.site_width to the row STEP.\n       -skip_site_check bypasses the check.");
        let io = ck.errors.iter().filter(|e| e.0 == "PLC-411" || e.0 == "PLC-412").count();
        let rs = ck.errors.len() - io;
        let mut what = vec![];
        if rs > 0 { what.push(format!("{} ROW / SITE mismatch(es) between the standard cells and the site / row definitions", rs)); }
        if io > 0 { what.push(format!("{} IO pad / macro overlap(s) or pad(s) outside the die", io)); }
        Err(Flow::Err(format!("{}: aborted, {}; nothing was moved (PLC-400)", cmd, what.join(" and "))))
    }

    pub(crate) fn sitecheck_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        match name {
            "check_row_site" | "check_placement_sites" | "check_site_rows" => {
                if self.fp.is_none() { return Some(err(&format!("{}: no floorplan (FP-001)", name))); }
                let x = args(a, &[]);
                let ck = self.row_site_check();
                crate::out!("\n****************************************\nReport : {}\n****************************************", name);
                for s in &ck.summary { crate::out!("  {}", s); }
                crate::out!("  Mismatches     : {}\n  Warnings       : {}", ck.errors.len(), ck.warnings.len());
                let lim = if x.has("-verbose") { usize::MAX } else { 40 };
                for (id, m) in ck.errors.iter().take(lim) { crate::out!("    {} {}", id, m); }
                for (id, m) in ck.warnings.iter().take(lim) { crate::out!("    {} (warning) {}", id, m); }
                Some(Ok(ck.errors.len().to_string()))
            }
            _ => None,
        }
    }
}
