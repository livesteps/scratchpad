//! Geometric overlap check for IO pads (signal / supply / corner / filler / breaker /
//! area-IO cells) and macros: every pair of placed instances whose boxes intersect with a
//! positive area (abutment is not an overlap), plus pads outside the die. Bond pads and
//! bumps (LEF CLASS COVER) sit on top of pads by design and are not checked.

use crate::lef::Rect;
use crate::pg::Marker;
use crate::session::{args, Session};
use crate::tcl::R;

const TOL: f64 = 1e-4;

#[derive(Clone, Debug)]
pub struct IoOverlap {
    pub a: String,
    pub b: String,
    pub kind_a: String,
    pub kind_b: String,
    pub r: Rect,
}

impl Session {
    /// placed pads / corners / fillers / breakers / area IO / macros: (name, kind, rect)
    fn io_objects(&self) -> Vec<(String, String, Rect)> {
        let Some(nl) = self.nl.as_ref() else { return vec![] };
        let mut v = vec![];
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.loc.is_none() { continue; }
            let Some(m) = crate::lef::master(cl).and_then(|m| self.lef.get(m)) else { continue };
            let cls = m.class.to_uppercase();
            if cls.starts_with("COVER") { continue; }
            let kind = if cl.has_attr("io_kind:area") { "area IO" }
                else if cls.starts_with("PAD") || cl.has_attr("io_pad") { "IO pad" }
                else if cls.starts_with("ENDCAP") && (cls.contains("TOP") || cls.contains("BOTTOM")) { "IO corner" }
                else if cls.starts_with("BLOCK") || cls.starts_with("RING") { "macro" }
                else { continue };
            if let Some(r) = crate::lef::cell_rect(&self.lef, cl) { v.push((cl.name.clone(), kind.to_string(), r)); }
        }
        v
    }

    /// all overlaps that involve at least one IO object (pad-pad, pad-macro, area IO), and
    /// macro-macro overlaps; second value: IO objects outside the die
    pub(crate) fn io_overlaps(&self) -> (Vec<IoOverlap>, Vec<(String, Rect)>) {
        let mut o = self.io_objects();
        o.sort_by(|a, b| a.2 .0.partial_cmp(&b.2 .0).unwrap());
        let mut ov = vec![];
        for i in 0..o.len() {
            for j in i + 1..o.len() {
                if o[j].2 .0 >= o[i].2 .2 - TOL { break; }
                let (a, b) = (&o[i].2, &o[j].2);
                let r = (a.0.max(b.0), a.1.max(b.1), a.2.min(b.2), a.3.min(b.3));
                if r.2 - r.0 > TOL && r.3 - r.1 > TOL {
                    ov.push(IoOverlap { a: o[i].0.clone(), b: o[j].0.clone(), kind_a: o[i].1.clone(), kind_b: o[j].1.clone(), r });
                }
            }
        }
        let mut out = vec![];
        if let Some(fp) = &self.fp {
            let d = fp.die;
            for (n, k, r) in &o {
                if k != "macro" && (r.0 < d.0 - TOL || r.1 < d.1 - TOL || r.2 > d.2 + TOL || r.3 > d.3 + TOL) { out.push((n.clone(), *r)); }
            }
        }
        (ov, out)
    }

    /// run the check, refresh the io markers, return the number of problems
    pub(crate) fn report_io_overlaps(&mut self, who: &str, verbose: bool, quiet_ok: bool) -> usize {
        let (ov, out) = self.io_overlaps();
        self.pgx.markers.retain(|m| !(m.tool == "drc" && (m.kind == "io_overlap" || m.kind == "io_outside_die")));
        for o in &ov {
            self.pgx.markers.push(Marker { tool: "drc".into(), kind: "io_overlap".into(), layer: String::new(), rect: o.r, nets: vec![],
                msg: format!("{} {} overlaps {} {} by {:.3} x {:.3} um", o.kind_a, o.a, o.kind_b, o.b, o.r.2 - o.r.0, o.r.3 - o.r.1) });
        }
        for (n, r) in &out {
            self.pgx.markers.push(Marker { tool: "drc".into(), kind: "io_outside_die".into(), layer: String::new(), rect: *r, nets: vec![], msg: format!("{} extends outside the die", n) });
        }
        let n = ov.len() + out.len();
        if n == 0 {
            if !quiet_ok { crate::info!("IO-230", "{}: no IO pad / macro overlaps", who); }
            return 0;
        }
        let lim = if verbose { usize::MAX } else { 25 };
        for o in ov.iter().take(lim) {
            crate::warn!("IO-231", "{}: {} {} overlaps {} {}: ({:.3}, {:.3}) – ({:.3}, {:.3}), {:.3} x {:.3} um", who, o.kind_a, o.a, o.kind_b, o.b, o.r.0, o.r.1, o.r.2, o.r.3, o.r.2 - o.r.0, o.r.3 - o.r.1);
        }
        if ov.len() > lim { crate::warn!("IO-231", "{}: ... {} more overlap(s) (check_io_overlaps -verbose)", who, ov.len() - lim); }
        for (nm, r) in out.iter().take(lim) {
            crate::warn!("IO-232", "{}: {} extends outside the die: ({:.3}, {:.3}) – ({:.3}, {:.3})", who, nm, r.0, r.1, r.2, r.3);
        }
        let pads = ov.iter().filter(|o| o.kind_a != "macro" && o.kind_b != "macro").count();
        crate::warn!("IO-233", "{}: {} overlap(s) ({} pad-pad, {} with macros), {} object(s) outside the die; markers added (report_markers -tool drc)", who, ov.len(), pads, ov.len() - pads, out.len());
        n
    }

    pub(crate) fn ioovl_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        match name {
            "check_io_overlaps" | "check_pad_overlaps" | "check_pad_overlap" | "check_io_overlap" => {
                if self.nl.is_none() { return Some(crate::tcl::err(&format!("{}: no design (FP-001)", name))); }
                let x = args(a, &[]);
                let n = self.report_io_overlaps(name, x.has("-verbose"), false);
                Some(Ok(n.to_string()))
            }
            _ => None,
        }
    }
}
