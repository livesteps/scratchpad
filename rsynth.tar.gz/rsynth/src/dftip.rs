//! DFT IP generation and insertion: each IP (TAP controller + boundary-scan register,
//! on-chip clock controller, scan decompressor / compactor, memory BIST controller + collars)
//! is written as synthesizable SystemVerilog, compiled with the design's target library in a
//! scratch session, and grafted into the mapped design under its own instance prefix.
//! The generated RTL is also written next to the design (write_dft_ip) for review and for
//! vendor simulation.

use crate::netlist::*;
use crate::session::Session;
use std::collections::HashMap;

impl Session {
    /// compile a generated RTL module with the target library (scratch session)
    pub(crate) fn compile_ip(&self, top: &str, rtl: &str) -> Result<Netlist, String> {
        let dir = std::env::temp_dir().join(format!("rsynth_ip_{}", std::process::id()));
        let _ = std::fs::create_dir_all(&dir);
        let f = dir.join(format!("{}.sv", top));
        std::fs::write(&f, rtl).map_err(|e| e.to_string())?;
        let mut t = Session::new();
        t.libs = self.libs.clone();
        t.corners = self.corners.clone();
        t.modes = self.modes.clone();
        t.scens = self.scens.clone();
        t.app = self.app.clone();
        let lib = self.libs.get(self.target_idx()).map(|l| l.name.clone()).unwrap_or_default();
        crate::log::push_redirect();
        let mut r = t.eval(&format!("set_app_options -name target_library -value {{{}}}\nanalyze -format sverilog {{{}}}\nelaborate {}", lib, f.display(), top));
        // instantiated library cells (ICGs) must not make the IP look pre-mapped
        if let Some(n) = t.nl.as_mut() { n.mapped = false; }
        if r.is_ok() { r = t.eval("compile_fusion -to logic_opto"); }
        let out = crate::log::pop_redirect();
        if let Err(crate::tcl::Flow::Err(e)) = r {
            return Err(format!("compiling generated {}: {}\n{}", top, e, out.lines().filter(|l| l.contains("Error")).collect::<Vec<_>>().join("\n")));
        }
        let nl = t.nl.take().ok_or("no netlist")?;
        if let Some(c) = nl.cell_ids().into_iter().find(|c| matches!(nl.cell(*c).kind, Kind::Gen(op) if !matches!(op, GOp::C0 | GOp::C1 | GOp::Buf)) && !nl.cell(*c).is_hport()) {
            return Err(format!("compiling generated {}: unmapped cell '{}' left after mapping", top, nl.cell(c).name));
        }
        if out.contains("Error:") {
            return Err(format!("compiling generated {}: {}", top, out.lines().filter(|l| l.contains("Error")).collect::<Vec<_>>().join("\n")));
        }
        Ok(nl)
    }

    /// copy `ip` into the design as instance `inst`: cells become `inst/<name>`; ports listed in
    /// `conn` attach to the given nets, the others get new nets `inst/<port>`. Returns port -> net.
    pub(crate) fn graft(&mut self, ip: &Netlist, inst: &str, conn: &HashMap<String, NetId>) -> Result<HashMap<String, NetId>, String> {
        let nl = self.nl.as_mut().ok_or("no design")?;
        // nets of the IP: ports first
        let mut nmap: HashMap<NetId, NetId> = HashMap::new();
        let mut pmap: HashMap<String, NetId> = HashMap::new();
        for p in ip.port_ids() {
            let pt = &ip.ports[p];
            let Some(n) = pt.net else { continue };
            let target = match conn.get(&pt.name) {
                Some(t) => *t,
                None => match nmap.get(&n) { Some(t) => *t, None => nl.add_net(&format!("{}/{}", inst, pt.name)) },
            };
            // two IP ports on one IP net (feed-through): merge into the first mapping
            match nmap.get(&n) {
                Some(prev) if *prev != target => { let keep = *prev; nl.merge_net(keep, target); pmap.insert(pt.name.clone(), keep); }
                _ => { nmap.insert(n, target); pmap.insert(pt.name.clone(), target); }
            }
        }
        for n in ip.net_ids() {
            if nmap.contains_key(&n) { continue; }
            let nn = nl.add_net(&format!("{}/{}", inst, ip.net(n).name));
            nmap.insert(n, nn);
        }
        for c in ip.cell_ids() {
            let cl = ip.cell(c);
            if cl.is_hport() { continue; }
            let pins: Vec<(&str, Dir)> = cl.pins.iter().map(|p| (p.name.as_str(), p.dir)).collect();
            let id = nl.add_cell(&format!("{}/{}", inst, cl.name), cl.kind.clone(), &pins);
            for (i, p) in cl.pins.iter().enumerate() {
                if let Some(n) = p.net { nl.connect(id, i, nmap[&n]); }
            }
            let ncl = nl.cell_mut(id);
            ncl.attrs = cl.attrs.clone();
            ncl.attrs.push(format!("dft_ip:{}", inst));
            ncl.dont_touch = true;
        }
        Ok(pmap)
    }
}

/// glitch-free clock gate from the library ICG (or a behavioural latch gate)
fn icg(inst: &str, ck: &str, en: &str, out: &str, has_icg: bool) -> String {
    if has_icg {
        format!("  ICG_X1_SVT {} (.CK({}), .E({}), .SE(1'b0), .GCK({}));\n", inst, ck, en, out)
    } else {
        format!("  logic {i}_l;\n  always_latch if (!{ck}) {i}_l = {en};\n  assign {out} = {ck} & {i}_l;\n", i = inst, ck = ck, en = en, out = out)
    }
}

/// IEEE 1149.1 TAP controller + instruction register + boundary-scan register.
/// cells: (port, kind) kind = "in" | "out" | "oe" (output enable control cell)
pub fn tap_bsr_rtl(cells: &[(String, String)], idcode: u32, ir_len: usize, user: &[(&str, u32)]) -> String {
    let n = cells.len().max(1);
    let mut s = String::new();
    let ir_max = (1u32 << ir_len) - 1;
    s += &format!("// rsynth generated: IEEE 1149.1 TAP controller, {}-bit IR, {}-cell boundary-scan register\n", ir_len, cells.len());
    s += "module rsdft_tap (\n  input  logic tck, tms, tdi, trst_n,\n  output logic tdo, tdo_en,\n";
    s += &format!("  input  logic [{}:0] bs_pi,      // from pads / functional inputs\n  output logic [{}:0] bs_po,      // to core / pads\n  input  logic [{}:0] bs_core,    // from core (output cells)\n", n - 1, n - 1, n - 1);
    s += "  output logic extest, intest, sample, bypass_sel, clamp, highz, user_scan, user_mbist, user_tdr_upd,\n  output logic [7:0] user_tdr,\n  input  logic [7:0] user_tdr_in\n);\n";
    s += "  typedef enum logic [3:0] {TLR, RTI, SEL_DR, CAP_DR, SH_DR, EX1_DR, PA_DR, EX2_DR, UPD_DR, SEL_IR, CAP_IR, SH_IR, EX1_IR, PA_IR, EX2_IR, UPD_IR} st_t;\n";
    s += "  st_t st;\n";
    s += "  always_ff @(posedge tck or negedge trst_n)\n    if (!trst_n) st <= TLR;\n    else case (st)\n";
    for (a, b, c) in [("TLR", "TLR", "RTI"), ("RTI", "SEL_DR", "RTI"), ("SEL_DR", "SEL_IR", "CAP_DR"), ("CAP_DR", "EX1_DR", "SH_DR"), ("SH_DR", "EX1_DR", "SH_DR"), ("EX1_DR", "UPD_DR", "PA_DR"), ("PA_DR", "EX2_DR", "PA_DR"), ("EX2_DR", "UPD_DR", "SH_DR"), ("UPD_DR", "SEL_DR", "RTI"),
        ("SEL_IR", "TLR", "CAP_IR"), ("CAP_IR", "EX1_IR", "SH_IR"), ("SH_IR", "EX1_IR", "SH_IR"), ("EX1_IR", "UPD_IR", "PA_IR"), ("PA_IR", "EX2_IR", "PA_IR"), ("EX2_IR", "UPD_IR", "SH_IR"), ("UPD_IR", "SEL_DR", "RTI")] {
        s += &format!("      {}: st <= tms ? {} : {};\n", a, b, c);
    }
    s += "    endcase\n";
    s += &format!("  logic [{m}:0] ir_sh, ir;\n", m = ir_len - 1);
    s += &format!("  always_ff @(posedge tck or negedge trst_n)\n    if (!trst_n) ir_sh <= '0;\n    else if (st == CAP_IR) ir_sh <= {}'b{};\n    else if (st == SH_IR) ir_sh <= {{tdi, ir_sh[{}:1]}};\n", ir_len, format!("{:0w$b}", 1, w = ir_len), ir_len - 1);
    // IDCODE is the reset instruction
    s += &format!("  always_ff @(negedge tck or negedge trst_n)\n    if (!trst_n) ir <= {}'d2;\n    else if (st == TLR) ir <= {}'d2;\n    else if (st == UPD_IR) ir <= ir_sh;\n", ir_len, ir_len);
    // instruction decode: 0 EXTEST, 1 SAMPLE/PRELOAD, 2 IDCODE, 3 INTEST, 4 CLAMP, 5 HIGHZ, user..., all-ones BYPASS
    s += &format!("  assign extest = (ir == {w}'d0);\n  assign sample = (ir == {w}'d1);\n  logic idcode_sel; assign idcode_sel = (ir == {w}'d2);\n  assign intest = (ir == {w}'d3);\n  assign clamp = (ir == {w}'d4);\n  assign highz = (ir == {w}'d5);\n", w = ir_len);
    for (nm, code) in user {
        s += &format!("  assign {} = (ir == {}'d{});\n", nm, ir_len, code);
    }
    let user_codes: Vec<u32> = user.iter().map(|u| u.1).collect();
    let decoded: Vec<String> = [0u32, 1, 2, 3, 4, 5].iter().chain(user_codes.iter()).map(|c| format!("ir != {}'d{}", ir_len, c)).collect();
    s += &format!("  assign bypass_sel = {};\n", decoded.join(" && "));
    let _ = ir_max;
    // data registers
    s += "  logic bypass_r;\n  always_ff @(posedge tck) if (st == CAP_DR) bypass_r <= 1'b0; else if (st == SH_DR) bypass_r <= tdi;\n";
    s += &format!("  logic [31:0] id_r;\n  always_ff @(posedge tck) if (st == CAP_DR) id_r <= 32'h{:08x}; else if (st == SH_DR && idcode_sel) id_r <= {{tdi, id_r[31:1]}};\n", idcode | 1);
    s += "  logic [7:0] tdr_sh;\n  always_ff @(posedge tck) if (st == CAP_DR && (user_scan || user_mbist)) tdr_sh <= user_tdr_in; else if (st == SH_DR && (user_scan || user_mbist)) tdr_sh <= {tdi, tdr_sh[7:1]};\n";
    s += "  always_ff @(negedge tck or negedge trst_n) if (!trst_n) user_tdr <= '0; else if (st == UPD_DR && (user_scan || user_mbist)) user_tdr <= tdr_sh;\n";
    s += "  assign user_tdr_upd = (st == UPD_DR) && (user_scan || user_mbist);\n";
    // boundary-scan register: capture / shift on tck, update on the falling edge
    s += &format!("  logic [{m}:0] bsr_sh, bsr_up;\n  wire bsr_sel = extest | sample | intest;   // CLAMP / HIGHZ select the bypass register (IEEE 1149.1)\n", m = n - 1);
    s += &format!("  always_ff @(posedge tck) if (st == CAP_DR && bsr_sel) bsr_sh <= bs_cap; else if (st == SH_DR && bsr_sel) bsr_sh <= {{tdi, bsr_sh[{}:1]}};\n", n - 1);
    s += "  always_ff @(negedge tck or negedge trst_n) if (!trst_n) bsr_up <= '0; else if (st == UPD_DR && (extest | sample | intest)) bsr_up <= bsr_sh;\n";
    // per cell: capture source and output mux
    s += &format!("  logic [{m}:0] bs_cap;\n", m = n - 1);
    for (k, (_, kind)) in cells.iter().enumerate() {
        match kind.as_str() {
            "in" => {
                s += &format!("  assign bs_cap[{k}] = bs_pi[{k}];\n  assign bs_po[{k}] = intest ? bsr_up[{k}] : bs_pi[{k}];\n", k = k);
            }
            _ => {
                // output / enable cell: capture the core value, drive the pad from the update latch in EXTEST / CLAMP
                s += &format!("  assign bs_cap[{k}] = bs_core[{k}];\n  assign bs_po[{k}] = (extest | clamp) ? bsr_up[{k}] : bs_core[{k}];\n", k = k);
            }
        }
    }
    if cells.is_empty() {
        s += "  assign bs_cap[0] = 1'b0;\n  assign bs_po[0] = bs_pi[0];\n";
    }
    s += &format!("  logic tdo_mux;\n  always_comb begin\n    if (st == SH_IR) tdo_mux = ir_sh[0];\n    else if (idcode_sel) tdo_mux = id_r[0];\n    else if (bsr_sel) tdo_mux = bsr_sh[0];\n    else if (user_scan | user_mbist) tdo_mux = tdr_sh[0];\n    else tdo_mux = bypass_r;\n  end\n");
    s += "  always_ff @(negedge tck or negedge trst_n) if (!trst_n) tdo <= 1'b0; else tdo <= tdo_mux;\n";
    s += "  always_ff @(negedge tck or negedge trst_n) if (!trst_n) tdo_en <= 1'b0; else tdo_en <= (st == SH_DR) || (st == SH_IR);\n";
    s += "endmodule\n";
    s
}

/// on-chip clock controller for one clock domain.
/// shift: test clock; slow capture: one test-clock pulse; at-speed: `pulses` fast-clock pulses
/// after scan_en falls (synchronised in the fast domain); functional: fast clock.
pub fn occ_rtl(name: &str, pulses: usize, has_icg: bool) -> String {
    let p = pulses.clamp(1, 4);
    let mut s = format!("// rsynth generated: on-chip clock controller ({} at-speed pulse(s))\nmodule {} (\n  input  logic fast_clk, test_clk, test_mode, scan_en, atspeed,\n  output logic clk_out, busy\n);\n", p, name);
    // scan_en synchroniser in the fast domain, pulse counter
    s += "  logic se_s1, se_s2, se_s3, armed;\n  logic [2:0] cnt;\n";
    s += "  always_ff @(posedge fast_clk) begin se_s1 <= scan_en; se_s2 <= se_s1; se_s3 <= se_s2; end\n";
    s += &format!("  always_ff @(posedge fast_clk)\n    if (!test_mode || !atspeed || se_s2) begin cnt <= 3'd0; armed <= 1'b0; end\n    else if (se_s3 && !se_s2) begin cnt <= 3'd0; armed <= 1'b1; end\n    else if (armed && cnt != 3'd{p}) cnt <= cnt + 3'd1;\n    else armed <= 1'b0;\n", p = p);
    s += "  wire fast_en = armed && (cnt != 3'd0 || 1'b1) && (cnt < 3'd";
    s += &format!("{});\n", p);
    s += "  logic fast_g;\n";
    s += &icg("u_cg_fast", "fast_clk", "fast_en", "fast_g", has_icg);
    s += "  logic slow_g;\n  wire slow_en = scan_en | ~atspeed;\n";
    s += &icg("u_cg_slow", "test_clk", "slow_en", "slow_g", has_icg);
    s += "  wire test_clk_mux = (atspeed & ~scan_en) ? fast_g : slow_g;\n";
    s += "  assign clk_out = test_mode ? test_clk_mux : fast_clk;\n";
    s += "  assign busy = armed;\nendmodule\n";
    s
}

/// sequential decompressor (ring-generator style LFSR with channel injection + XOR phase
/// shifter) and XOR space compactor
pub struct EdtCfg {
    pub channels: usize,
    pub chains: usize,
    pub lfsr: usize,
    /// LFSR feedback taps (bit indices xor-ed into bit 0)
    pub taps: Vec<usize>,
    /// injection positions per channel
    pub inject: Vec<usize>,
    /// phase shifter: LFSR bits xor-ed for each chain
    pub ps: Vec<Vec<usize>>,
    /// compactor: chains per output channel
    pub comp: Vec<Vec<usize>>,
    pub init_cycles: usize,
}

pub fn edt_cfg(channels: usize, chains: usize) -> EdtCfg {
    let lfsr = (2 * channels + 6).max(chains.min(32) / 2 + 8).min(64).max(channels + 4);
    // primitive-ish taps spread over the register
    let taps = vec![lfsr - 1, lfsr * 3 / 4, lfsr / 2, lfsr / 5].into_iter().filter(|t| *t > 0 && *t < lfsr).collect::<std::collections::BTreeSet<_>>().into_iter().collect();
    let inject: Vec<usize> = (0..channels).map(|c| (c * lfsr) / channels.max(1)).collect();
    let mut ps = vec![];
    for k in 0..chains {
        // three distinct taps per chain, deterministic spread
        let a = (k * 7 + 1) % lfsr;
        let mut b = (k * 13 + 5) % lfsr;
        let mut c = (k * 3 + lfsr / 2 + 2) % lfsr;
        if b == a { b = (b + 1) % lfsr; }
        while c == a || c == b { c = (c + 1) % lfsr; }
        ps.push(vec![a, b, c]);
    }
    let mut comp = vec![vec![]; channels];
    for k in 0..chains { comp[k % channels].push(k); }
    EdtCfg { channels, chains, lfsr, taps, inject, ps, comp, init_cycles: (lfsr + channels - 1) / channels.max(1) }
}

pub fn edt_rtl(name: &str, cfg: &EdtCfg) -> String {
    let mut s = format!("// rsynth generated: scan compression, {} channel(s) -> {} internal chain(s), {}-bit decompressor\n", cfg.channels, cfg.chains, cfg.lfsr);
    s += &format!("module {} (\n  input  logic clk, scan_en, edt_clear, comp_en,\n  input  logic [{}:0] chan_in,\n  output logic [{}:0] chain_si,\n  input  logic [{}:0] chain_so,\n  output logic [{}:0] chan_out\n);\n",
        name, cfg.channels - 1, cfg.chains - 1, cfg.chains - 1, cfg.channels - 1);
    s += &format!("  logic [{}:0] r;\n", cfg.lfsr - 1);
    // next state: shift up, feedback into bit 0, channel injection
    let mut nx = vec![String::new(); cfg.lfsr];
    for i in 0..cfg.lfsr {
        let mut terms: Vec<String> = vec![];
        if i == 0 { for t in &cfg.taps { terms.push(format!("r[{}]", t)); } } else { terms.push(format!("r[{}]", i - 1)); }
        for (c, p) in cfg.inject.iter().enumerate() { if *p == i { terms.push(format!("chan_in[{}]", c)); } }
        nx[i] = terms.join(" ^ ");
    }
    s += "  always_ff @(posedge clk)\n    if (edt_clear) r <= '0;\n    else if (scan_en) begin\n";
    for i in 0..cfg.lfsr { s += &format!("      r[{}] <= {};\n", i, nx[i]); }
    s += "    end\n";
    for (k, t) in cfg.ps.iter().enumerate() {
        s += &format!("  assign chain_si[{}] = comp_en ? ({}) : chan_in[{}];\n", k, t.iter().map(|b| format!("r[{}]", b)).collect::<Vec<_>>().join(" ^ "), k % cfg.channels);
    }
    for (j, g) in cfg.comp.iter().enumerate() {
        let x = if g.is_empty() { "1'b0".to_string() } else { g.iter().map(|k| format!("chain_so[{}]", k)).collect::<Vec<_>>().join(" ^ ") };
        s += &format!("  assign chan_out[{}] = comp_en ? ({}) : chain_so[{}];\n", j, x, j.min(cfg.chains - 1));
    }
    s += "endmodule\n";
    s
}

/// March algorithm: elements of (direction, ops); op: 'w0' 'w1' 'r0' 'r1'
pub fn march(alg: &str) -> Option<Vec<(char, Vec<&'static str>)>> {
    Some(match alg.to_lowercase().as_str() {
        "mats+" | "mats_plus" => vec![('b', vec!["w0"]), ('u', vec!["r0", "w1"]), ('d', vec!["r1", "w0"])],
        "march_c-" | "marchc-" | "march_c_minus" | "march_c" => vec![('b', vec!["w0"]), ('u', vec!["r0", "w1"]), ('u', vec!["r1", "w0"]), ('d', vec!["r0", "w1"]), ('d', vec!["r1", "w0"]), ('b', vec!["r0"])],
        "march_c+" | "marchc+" | "march_c_plus" => vec![('b', vec!["w0"]), ('u', vec!["r0", "w1", "r1"]), ('u', vec!["r1", "w0", "r0"]), ('d', vec!["r0", "w1", "r1"]), ('d', vec!["r1", "w0", "r0"]), ('b', vec!["r0"])],
        "march_x" => vec![('b', vec!["w0"]), ('u', vec!["r0", "w1"]), ('d', vec!["r1", "w0"]), ('b', vec!["r0"])],
        "march_y" => vec![('b', vec!["w0"]), ('u', vec!["r0", "w1", "r1"]), ('d', vec!["r1", "w0", "r0"]), ('b', vec!["r0"])],
        "march_b" => vec![('b', vec!["w0"]), ('u', vec!["r0", "w1", "r1", "w0", "r0", "w1"]), ('u', vec!["r1", "w0", "w1"]), ('d', vec!["r1", "w0", "w1", "w0"]), ('d', vec!["r0", "w1", "w0"])],
        "checkerboard" => vec![('u', vec!["wC"]), ('u', vec!["rC"]), ('u', vec!["wI"]), ('u', vec!["rI"])],
        _ => return None,
    })
}

pub struct MemPort { pub inst: String, pub abits: usize, pub dbits: usize, pub words: usize, pub clk: String, pub ce: String, pub we: String, pub addr: String, pub din: String, pub dout: String, pub ce_low: bool, pub we_low: bool }

/// memory BIST controller for a group of memories tested in parallel (shared address / data
/// generators, one comparator and fail flag per memory) + collars
pub fn mbist_rtl(name: &str, mems: &[MemPort], alg: &str) -> Result<String, String> {
    let el = march(alg).ok_or_else(|| format!("unknown MBIST algorithm '{}' (mats+, march_c-, march_c+, march_x, march_y, march_b, checkerboard)", alg))?;
    let ab = mems.iter().map(|m| m.abits).max().unwrap_or(1);
    let db = mems.iter().map(|m| m.dbits).max().unwrap_or(1);
    let nm = mems.len();
    // flatten the algorithm into a micro-program: per element: dir, op list
    let nops: usize = el.iter().map(|e| e.1.len()).sum();
    let mut s = format!("// rsynth generated: memory BIST controller, algorithm {} ({} element(s), {} op(s) per address), {} memory(ies)\n", alg, el.len(), nops, nm);
    let mut ports: Vec<String> = vec!["input  logic clk, rst_n, bist_en, start, test_mode".into(), "output logic done, fail".into(), format!("output logic [{}:0] fail_mem", nm.max(1) - 1)];
    for (k, m) in mems.iter().enumerate() {
        ports.push(format!("// memory {k}: {}\n  input  logic f{k}_ce, f{k}_we, input logic [{a}:0] f{k}_a, input logic [{d}:0] f{k}_d,\n  output logic m{k}_ce, m{k}_we, output logic [{a}:0] m{k}_a, output logic [{d}:0] m{k}_d, input logic [{d}:0] m{k}_q, output logic [{d}:0] f{k}_q",
            m.inst, k = k, a = m.abits - 1, d = m.dbits - 1));
    }
    s += &format!("module {} (\n  {}\n);\n", name, ports.join(",\n  "));
    // element / op tables
    let mut op_rom: Vec<(usize, char, &str, bool)> = vec![]; // (element, dir, op, last op of element)
    for (i, (d, ops)) in el.iter().enumerate() {
        for (j, o) in ops.iter().enumerate() { op_rom.push((i, *d, o, j + 1 == ops.len())); }
    }
    let nb = (op_rom.len() as f64).log2().ceil().max(1.0) as usize;
    s += &format!("  logic [{}:0] pc;\n  logic [{}:0] addr;\n  logic run;\n", nb - 1, ab - 1);
    s += &format!("  wire chk = {};\n", if alg.to_lowercase() == "checkerboard" { "addr[0]" } else { "1'b0" });
    s += "  logic is_wr, is_rd, wval, down, last_op, last_el;\n  always_comb begin\n    is_wr = 1'b0; is_rd = 1'b0; wval = 1'b0; down = 1'b0; last_op = 1'b0; last_el = 1'b0;\n    case (pc)\n";
    let checker = alg.to_lowercase() == "checkerboard";
    for (k, (e, d, o, lo)) in op_rom.iter().enumerate() {
        let wr = o.starts_with('w');
        let v = match &o[1..] { "1" => "1'b1", "C" => "chk", "I" => "~chk", _ => "1'b0" };
        s += &format!("      {}'d{}: begin is_wr = {}; is_rd = {}; wval = {}; down = {}; last_op = {}; last_el = {}; end\n", nb, k, if wr { "1'b1" } else { "1'b0" }, if wr { "1'b0" } else { "1'b1" }, v,
            if *d == 'd' { "1'b1" } else { "1'b0" }, if *lo { "1'b1" } else { "1'b0" }, if *e + 1 == el.len() { "1'b1" } else { "1'b0" });
    }
    s += "      default: begin end\n    endcase\n  end\n";
    let _ = checker;
    let amax = mems.iter().map(|m| m.words).max().unwrap_or(1) - 1;
    s += &format!("  wire at_end = down ? (addr == {ab}'d0) : (addr == {ab}'d{amax});\n", ab = ab, amax = amax);
    // first op of each element decides the start address
    s += &format!("  logic [{}:0] el_first;\n", nb - 1);
    s += "  // sequencing: each address runs all ops of the element, then the address steps\n";
    s += &format!("  logic [{nb1}:0] el_base;\n  always_ff @(posedge clk or negedge rst_n)\n    if (!rst_n) begin run <= 1'b0; pc <= '0; el_base <= '0; addr <= '0; done <= 1'b0; end\n    else if (!bist_en) begin run <= 1'b0; done <= 1'b0; end\n    else if (start && !run && !done) begin run <= 1'b1; pc <= '0; el_base <= '0; addr <= '0; end\n    else if (run) begin\n      if (!last_op) pc <= pc + 1'b1;\n      else if (!at_end) begin pc <= el_base; addr <= down ? addr - 1'b1 : addr + 1'b1; end\n      else if (last_el) begin run <= 1'b0; done <= 1'b1; end\n      else begin pc <= pc + 1'b1; el_base <= pc + 1'b1; addr <= next_down ? {ab}'d{amax} : '0; end\n    end\n",
        nb1 = nb - 1, ab = ab, amax = amax);
    // direction of the next element (to choose its start address)
    s += "  logic next_down;\n  always_comb begin\n    next_down = 1'b0;\n    case (pc)\n";
    for (k, (e, _, _, lo)) in op_rom.iter().enumerate() {
        if *lo && *e + 1 < el.len() {
            s += &format!("      {}'d{}: next_down = {};\n", nb, k, if el[*e + 1].0 == 'd' { "1'b1" } else { "1'b0" });
        }
    }
    s += "      default: begin end\n    endcase\n  end\n";
    // read compare one cycle later (synchronous memories)
    s += &format!("  logic rd_q, exp_q;\n  always_ff @(posedge clk or negedge rst_n) if (!rst_n) begin rd_q <= 1'b0; exp_q <= 1'b0; end else begin rd_q <= run & is_rd; exp_q <= wval; end\n");
    s += &format!("  logic [{}:0] failr;\n", nm.max(1) - 1);
    for (k, m) in mems.iter().enumerate() {
        let (ce_on, we_on, we_off) = (if m.ce_low { "1'b0" } else { "1'b1" }, if m.we_low { "1'b0" } else { "1'b1" }, if m.we_low { "1'b1" } else { "1'b0" });
        s += &format!("  assign m{k}_ce = bist_en ? (run ? {ce_on} : ~{ce_on}) : f{k}_ce;\n  assign m{k}_we = bist_en ? ((run & is_wr) ? {we_on} : {we_off}) : f{k}_we;\n  assign m{k}_a  = bist_en ? addr[{a}:0] : f{k}_a;\n  assign m{k}_d  = bist_en ? {{{d1}{{wval}}}} : f{k}_d;\n",
            k = k, ce_on = ce_on, we_on = we_on, we_off = we_off, a = m.abits - 1, d1 = m.dbits);
        // scan-mode memory bypass: Q observes D ^ folded address ^ CE ^ WE (memory shadow logic testable by ATPG)
        let mut byp: Vec<String> = (0..m.dbits).map(|i| format!("f{}_d[{}]", k, i)).collect();
        for j in 0..m.abits { byp[j % m.dbits] += &format!(" ^ f{}_a[{}]", k, j); }
        byp[0] += &format!(" ^ f{k}_ce ^ f{k}_we", k = k);
        for (i, b) in byp.iter().enumerate() { s += &format!("  assign f{k}_q[{i}] = (test_mode & ~bist_en) ? ({b}) : m{k}_q[{i}];\n", k = k, i = i, b = b); }
        s += &format!("  always_ff @(posedge clk or negedge rst_n) if (!rst_n) failr[{k}] <= 1'b0; else if (!bist_en) failr[{k}] <= 1'b0; else if (rd_q && (m{k}_q != {{{d}{{exp_q}}}})) failr[{k}] <= 1'b1;\n", k = k, d = m.dbits);
    }
    let _ = db;
    s += "  assign fail_mem = failr;\n  assign fail = |failr;\nendmodule\n";
    Ok(s)
}

/// behavioural single-port synchronous SRAM model (simulation of MBIST and functional mode)
pub fn sram_model(name: &str, abits: usize, dbits: usize, words: usize, pins: &MemPort) -> String {
    format!("// rsynth generated behavioural model of {name}\nmodule {name} ({clk}, {ce}, {we}, {a}, {d}, {q});\n  input {clk}, {ce}, {we};\n  input [{a1}:0] {a};\n  input [{d1}:0] {d};\n  output reg [{d1}:0] {q};\n  reg [{d1}:0] mem [0:{w1}];\n  always @(posedge {clk})\n    if ({ce}{cep}) begin\n      if ({we}{wep}) mem[{a}] <= {d};\n      else begin\n        {q} <= mem[{a}];\n`ifdef RSYNTH_INJECT_FAULT\n        if ({a} == 0) {q}[0] <= 1'b1;   // injected defect: word 0 bit 0 reads stuck-at-1\n`endif\n      end\n    end\nendmodule\n",
        name = name, clk = pins.clk, ce = pins.ce, we = pins.we, a = pins.addr, d = pins.din, q = pins.dout, a1 = abits - 1, d1 = dbits - 1, w1 = words - 1,
        cep = if pins.ce_low { " == 1'b0" } else { "" }, wep = if pins.we_low { " == 1'b0" } else { "" })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rtl_generators_are_consistent() {
        let t = tap_bsr_rtl(&[("a".into(), "in".into()), ("y".into(), "out".into())], 0x1234_5678, 4, &[("user_scan", 8), ("user_mbist", 9)]);
        assert!(t.contains("module rsdft_tap") && t.contains("UPD_IR: st <= tms ? SEL_DR : RTI;"));
        let e = edt_cfg(2, 8);
        assert_eq!(e.ps.len(), 8);
        assert!(e.ps.iter().all(|p| p.iter().all(|b| *b < e.lfsr)));
        assert_eq!(e.comp.iter().map(|g| g.len()).sum::<usize>(), 8);
        assert!(march("march_c-").unwrap().len() == 6 && march("bogus").is_none());
    }
}
