//! Global-route timing engine: per-net RC trees before detailed routing.
//!
//! For every net with placed pins:
//! * topology: rectilinear Steiner tree, nearest-point Prim with L-shaped connections that may
//!   tap the middle of existing segments (up to `MAX_PRIM` pins); larger nets use a trunk and
//!   branch comb along the median row
//! * detour: segment lengths are stretched so that the tree length matches the global-route
//!   length of the net when one exists (congestion detours)
//! * layers: the net length selects a horizontal/vertical layer pair (thresholds in um);
//!   horizontal segments use the H layer, vertical ones the V layer, each bend adds a via and
//!   each pin a via stack from M1
//! * electrical: segments are cut into sections of at most `seg_um` with per-layer R and C,
//!   loads add their pin capacitance; the result is an `RcTree` per net plus per-sink Elmore
//!   delays and wire caps in a `RoutedRc`, used by STA and the optimiser like extraction.

use crate::droute::{RLayer, RoutedRc};
use crate::netlist::*;
use crate::rcnet::{RcTree, ROOT};
use std::collections::HashMap;
use std::sync::Arc;

pub const MAX_PRIM: usize = 64;

#[derive(Clone, Debug)]
pub struct GrParams {
    pub layers: Vec<RLayer>,
    pub via_r: f64,
    pub via_c: f64,
    /// layer-pair thresholds on the net length (um)
    pub thresholds: Vec<f64>,
    pub seg_um: f64,
}

/// Steiner topology: points and undirected axis-aligned edges
#[derive(Clone, Debug, Default)]
pub struct Steiner {
    pub pts: Vec<(f64, f64)>,
    pub edges: Vec<(usize, usize)>,
    /// pin index -> point
    pub pin_pt: Vec<usize>,
}

impl Steiner {
    pub fn length(&self) -> f64 {
        self.edges.iter().map(|(a, b)| (self.pts[*a].0 - self.pts[*b].0).abs() + (self.pts[*a].1 - self.pts[*b].1).abs()).sum()
    }
}

fn dist(a: (f64, f64), b: (f64, f64)) -> f64 {
    (a.0 - b.0).abs() + (a.1 - b.1).abs()
}

/// nearest point to p on the axis-aligned segment a-b
fn nearest_on(a: (f64, f64), b: (f64, f64), p: (f64, f64)) -> (f64, f64) {
    let (x0, x1) = (a.0.min(b.0), a.0.max(b.0));
    let (y0, y1) = (a.1.min(b.1), a.1.max(b.1));
    (p.0.clamp(x0, x1), p.1.clamp(y0, y1))
}

/// Build the Steiner topology; pins[0] is the driver.
pub fn steiner(pins: &[(f64, f64)]) -> Steiner {
    let mut st = Steiner { pts: vec![pins[0]], edges: vec![], pin_pt: vec![0; pins.len()] };
    if pins.len() <= MAX_PRIM {
        let mut done = vec![false; pins.len()];
        done[0] = true;
        for _ in 1..pins.len() {
            // the closest remaining pin to the tree (points and edges)
            let mut best: Option<(f64, usize, (f64, f64), Option<usize>)> = None;
            for (k, p) in pins.iter().enumerate() {
                if done[k] {
                    continue;
                }
                for (ei, (a, b)) in st.edges.iter().enumerate() {
                    let q = nearest_on(st.pts[*a], st.pts[*b], *p);
                    let d = dist(q, *p);
                    if best.as_ref().map(|x| d < x.0 - 1e-12).unwrap_or(true) {
                        best = Some((d, k, q, Some(ei)));
                    }
                }
                for (pi, q) in st.pts.iter().enumerate() {
                    let d = dist(*q, *p);
                    if best.as_ref().map(|x| d < x.0 - 1e-12).unwrap_or(true) {
                        best = Some((d, k, *q, None));
                        let _ = pi;
                    }
                }
            }
            let (_, k, q, edge) = best.unwrap();
            done[k] = true;
            // tap point: existing point or split of an edge
            let tap = match st.pts.iter().position(|x| dist(*x, q) < 1e-9) {
                Some(i) => i,
                None => {
                    st.pts.push(q);
                    let t = st.pts.len() - 1;
                    if let Some(ei) = edge {
                        let (a, b) = st.edges[ei];
                        st.edges[ei] = (a, t);
                        st.edges.push((t, b));
                    }
                    t
                }
            };
            let p = pins[k];
            let pp = match st.pts.iter().position(|x| dist(*x, p) < 1e-9) {
                Some(i) => i,
                None => {
                    st.pts.push(p);
                    st.pts.len() - 1
                }
            };
            st.pin_pt[k] = pp;
            if pp != tap {
                let t = st.pts[tap];
                if (t.0 - p.0).abs() > 1e-9 && (t.1 - p.1).abs() > 1e-9 {
                    // L: horizontal from the tap, then vertical to the pin
                    st.pts.push((p.0, t.1));
                    let c = st.pts.len() - 1;
                    st.edges.push((tap, c));
                    st.edges.push((c, pp));
                } else {
                    st.edges.push((tap, pp));
                }
            }
        }
    } else {
        // comb: horizontal trunk on the median row, vertical branches
        let mut ys: Vec<f64> = pins.iter().map(|p| p.1).collect();
        ys.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let ym = ys[ys.len() / 2];
        let mut taps: Vec<(f64, usize)> = vec![];
        for (k, p) in pins.iter().enumerate() {
            let pp = if k == 0 { 0 } else {
                st.pts.push(*p);
                st.pts.len() - 1
            };
            st.pin_pt[k] = pp;
            if (p.1 - ym).abs() > 1e-9 {
                st.pts.push((p.0, ym));
                let t = st.pts.len() - 1;
                st.edges.push((pp, t));
                taps.push((p.0, t));
            } else {
                taps.push((p.0, pp));
            }
        }
        taps.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
        for w in taps.windows(2) {
            if w[0].1 != w[1].1 {
                st.edges.push((w[0].1, w[1].1));
            }
        }
    }
    st
}

/// (horizontal layer, vertical layer) for a net length
pub fn layer_pair(p: &GrParams, len: f64) -> (usize, usize) {
    let n = p.layers.len();
    let mut pairs: Vec<(usize, usize)> = vec![];
    let mut i = 1;
    while i < n {
        let a = i;
        let b = if i + 1 < n { i + 1 } else { i };
        let (h, v) = if p.layers[a].horiz { (a, b) } else { (b, a) };
        pairs.push((h, v));
        i += 2;
    }
    if pairs.is_empty() {
        return (0, 0);
    }
    let k = p.thresholds.iter().filter(|t| len >= **t).count().min(pairs.len() - 1);
    pairs[k]
}

/// RC tree of one net. `pins[0]` is the driver; `gr_len` the global-route length if known.
pub fn rc_tree(p: &GrParams, pins: &[(PinRef, (f64, f64), f64)], gr_len: Option<f64>) -> (RcTree, Steiner, f64) {
    let locs: Vec<(f64, f64)> = pins.iter().map(|x| x.1).collect();
    let st = steiner(&locs);
    let tl = st.length();
    let scale = match gr_len {
        Some(g) if tl > 1e-9 && g > tl => g / tl,
        _ => 1.0,
    };
    let (lh, lv) = layer_pair(p, tl * scale);
    let mut t = RcTree { src: "groute", ..Default::default() };
    // driver access: via stack down to the driver pin (lumped at the root)
    t.add_node(ROOT, 0.0, 0.0);
    let np = st.pts.len();
    let mut adj: Vec<Vec<usize>> = vec![vec![]; np];
    for (a, b) in &st.edges {
        adj[*a].push(*b);
        adj[*b].push(*a);
    }
    let stack_r = |l: usize| p.via_r * l as f64;
    // tree node of every Steiner point (on the wire layer), BFS from the driver point
    let root_pt = st.pin_pt[0];
    let mut node_of = vec![u32::MAX; np];
    // the driver pin -> wire layer via stack
    let first_layer = adj[root_pt].first().map(|q| if (st.pts[*q].1 - st.pts[root_pt].1).abs() < 1e-9 { lh } else { lv }).unwrap_or(lh);
    node_of[root_pt] = t.add_node(0, stack_r(first_layer).max(1e-6), p.via_c * first_layer as f64);
    // incoming direction per point (0 = H, 1 = V) for bend vias
    let mut dir_in = vec![usize::MAX; np];
    let mut q = std::collections::VecDeque::from([root_pt]);
    let mut seen = vec![false; np];
    seen[root_pt] = true;
    while let Some(u) = q.pop_front() {
        for &v in &adj[u] {
            if seen[v] {
                continue;
            }
            seen[v] = true;
            let (a, b) = (st.pts[u], st.pts[v]);
            let horiz = (a.1 - b.1).abs() < 1e-9;
            let l = if horiz { lh } else { lv };
            let d = if horiz { 0 } else { 1 };
            let len = dist(a, b) * scale;
            let mut cur = node_of[u];
            // bend at u: a via between the layers
            if dir_in[u] != usize::MAX && dir_in[u] != d || (u == root_pt && l != first_layer) {
                cur = t.add_node(cur, p.via_r, p.via_c);
            }
            let k = ((len / p.seg_um).ceil() as usize).max(1);
            let (r, c) = (p.layers[l].r * len / k as f64, p.layers[l].c * len / k as f64);
            for _ in 0..k {
                t.c[cur as usize] += c / 2.0;
                cur = t.add_node(cur, r, c / 2.0);
            }
            node_of[v] = cur;
            dir_in[v] = d;
            q.push_back(v);
        }
    }
    // pins: via stack from the wire layer down to M1, then the pin capacitance
    for (k, (pr, _, cap)) in pins.iter().enumerate() {
        if k == 0 {
            t.pins.push((*pr, 0));
            continue;
        }
        let pt = st.pin_pt[k];
        let at = if node_of[pt] == u32::MAX { node_of[root_pt] } else { node_of[pt] };
        let l = if dir_in[pt] == 1 { lv } else { lh };
        let nd = t.add_node(at, stack_r(l).max(1e-6), p.via_c * l as f64 + cap);
        t.cpin[nd as usize] = *cap;
        t.pins.push((*pr, nd));
    }
    (t, st, tl * scale)
}

/// RC trees for all nets with placed pins (driver nets of leaf drivers; hierarchy joined)
pub fn build(nl: &Netlist, p: &GrParams, gr: Option<&HashMap<NetId, f64>>, pin_cap: &dyn Fn(PinRef) -> f64,
             skip: &dyn Fn(NetId) -> bool) -> (RoutedRc, GrStats) {
    let mut rc = RoutedRc::default();
    let mut stats = GrStats::default();
    for n in nl.net_ids() {
        let Some(drv) = nl.driver(n) else { continue };
        if let PinRef::Cell(c, _) = drv {
            if nl.cell(c).is_hport() || matches!(nl.cell(c).kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) {
                continue;
            }
        }
        if skip(n) {
            continue;
        }
        let leaf: Vec<PinRef> = crate::session::Session::leaf_conns(nl, n).into_iter()
            .filter(|q| !matches!(q, PinRef::Cell(c, _) if nl.cell(*c).is_hport())).collect();
        let Some(dloc) = nl.pin_loc(drv) else { continue };
        let mut pins: Vec<(PinRef, (f64, f64), f64)> = vec![(drv, dloc, 0.0)];
        let mut ok = true;
        for q in leaf {
            if q == drv {
                continue;
            }
            match nl.pin_loc(q) {
                Some(l) => pins.push((q, l, pin_cap(q))),
                None => { ok = false; break; }
            }
        }
        if !ok || pins.len() < 2 {
            continue;
        }
        let gl = gr.and_then(|m| m.get(&n).copied());
        let (t, st, len) = rc_tree(p, &pins, gl);
        stats.nets += 1;
        stats.nodes += t.len();
        stats.wl += len;
        stats.steiner_pts += st.pts.len().saturating_sub(pins.len());
        if gl.map(|g| g > st.length() + 1e-6).unwrap_or(false) {
            stats.detoured += 1;
        }
        // per-sink Elmore and wire cap (legacy consumers)
        let m = t.moments(1.0);
        for (pr, nd) in &t.pins {
            if *nd != 0 {
                rc.elmore.insert(*pr, crate::rcnet::elmore(&m[*nd as usize]));
            }
        }
        rc.wire_c.insert(n, t.wire_cap());
        rc.trees.insert(n, Arc::new(t));
    }
    (rc, stats)
}

#[derive(Clone, Debug, Default)]
pub struct GrStats {
    pub nets: usize,
    pub nodes: usize,
    pub wl: f64,
    pub steiner_pts: usize,
    pub detoured: usize,
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn steiner_shares_trunk() {
        // driver at left, three loads on a column: the tree reuses the vertical trunk
        let pins = [(0.0, 0.0), (10.0, 0.0), (10.0, 10.0), (10.0, 20.0)];
        let st = steiner(&pins);
        assert!((st.length() - 30.0).abs() < 1e-9, "{}", st.length());
        // L-shape with a shared Steiner point
        let pins = [(0.0, 0.0), (10.0, 5.0), (10.0, -5.0)];
        let st = steiner(&pins);
        assert!(st.length() <= 20.0 + 1e-9, "{}", st.length());
        let big: Vec<(f64, f64)> = (0..200).map(|i| ((i % 20) as f64 * 3.0, (i / 20) as f64 * 2.0)).collect();
        let st = steiner(&big);
        assert_eq!(st.pin_pt.len(), 200);
        assert!(st.length() > 0.0);
    }
}
