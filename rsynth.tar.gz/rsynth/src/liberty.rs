//! Liberty (.lib) reader.  Generic group/attribute parser + semantic model:
//! NLDM delay/transition/constraint tables, CCS (output_current_*, receiver_capacitance),
//! ECSM (ecsm_waveform*), CCS-noise (ccsn_*), leakage/internal power, ff/latch/
//! clock-gating/isolation/level-shifter/retention/always-on/tie cell detection,
//! wire-load models, Vt classes and equivalent-cell families for sizing/Vt swapping.

use std::collections::HashMap;

#[derive(Debug, Clone, Default)]
pub struct Group {
    pub gtype: String,
    pub args: Vec<String>,
    pub attrs: Vec<(String, Vec<String>)>,
    pub groups: Vec<Group>,
}

impl Group {
    pub fn attr(&self, n: &str) -> Option<&str> {
        self.attrs.iter().find(|(k, _)| k == n).and_then(|(_, v)| v.first().map(|s| s.as_str()))
    }
    pub fn attr_all(&self, n: &str) -> Option<&Vec<String>> {
        self.attrs.iter().find(|(k, _)| k == n).map(|(_, v)| v)
    }
    pub fn num(&self, n: &str) -> Option<f64> {
        self.attr(n).and_then(|s| s.trim().parse().ok())
    }
    pub fn sub(&self, t: &str) -> impl Iterator<Item = &Group> {
        let t = t.to_string();
        self.groups.iter().filter(move |g| g.gtype == t)
    }
    pub fn has_sub(&self, t: &str) -> bool {
        self.groups.iter().any(|g| g.gtype == t || g.has_sub(t))
    }
}

// ---------------------------------------------------------------- raw parser
#[derive(Debug, Clone, PartialEq)]
enum Tok {
    W(String),
    S(String),
    P(char),
}

fn lex(src: &str) -> Vec<Tok> {
    let b: Vec<char> = src.chars().collect();
    let mut i = 0;
    let mut t = vec![];
    while i < b.len() {
        let c = b[i];
        if c == '\\' && i + 1 < b.len() && (b[i + 1] == '\n' || b[i + 1] == '\r') {
            i += 2;
            continue;
        }
        if c.is_whitespace() {
            i += 1;
            continue;
        }
        if c == '/' && i + 1 < b.len() && b[i + 1] == '*' {
            i += 2;
            while i + 1 < b.len() && !(b[i] == '*' && b[i + 1] == '/') {
                i += 1;
            }
            i += 2;
            continue;
        }
        if c == '/' && i + 1 < b.len() && b[i + 1] == '/' {
            while i < b.len() && b[i] != '\n' {
                i += 1;
            }
            continue;
        }
        if c == '"' {
            let mut s = String::new();
            i += 1;
            while i < b.len() && b[i] != '"' {
                if b[i] == '\\' && i + 1 < b.len() && (b[i + 1] == '\n' || b[i + 1] == '\r') {
                    i += 2;
                    continue;
                }
                s.push(b[i]);
                i += 1;
            }
            i += 1;
            t.push(Tok::S(s));
            continue;
        }
        if "(){}:;,".contains(c) {
            t.push(Tok::P(c));
            i += 1;
            continue;
        }
        let mut s = String::new();
        while i < b.len() && !b[i].is_whitespace() && !"(){}:;,\"".contains(b[i]) {
            s.push(b[i]);
            i += 1;
        }
        t.push(Tok::W(s));
    }
    t
}

struct P {
    t: Vec<Tok>,
    i: usize,
}
impl P {
    fn peek(&self) -> Option<&Tok> {
        self.t.get(self.i)
    }
    fn word(&mut self) -> Option<String> {
        match self.t.get(self.i).cloned() {
            Some(Tok::W(s)) | Some(Tok::S(s)) => {
                self.i += 1;
                Some(s)
            }
            _ => None,
        }
    }
    fn is(&self, c: char) -> bool {
        matches!(self.peek(), Some(Tok::P(x)) if *x==c)
    }
    fn body(&mut self, g: &mut Group) -> Result<(), String> {
        loop {
            if self.is('}') {
                self.i += 1;
                return Ok(());
            }
            if self.peek().is_none() {
                return Ok(());
            }
            if self.is(';') {
                self.i += 1;
                continue;
            }
            let name = self.word().ok_or_else(|| format!("liberty syntax error near token {}", self.i))?;
            if self.is(':') {
                self.i += 1;
                let mut v = vec![];
                while let Some(tk) = self.peek() {
                    match tk {
                        Tok::P(';') => {
                            self.i += 1;
                            break;
                        }
                        Tok::P('}') => break,
                        Tok::P(c) => {
                            v.push(c.to_string());
                            self.i += 1
                        }
                        Tok::W(s) | Tok::S(s) => {
                            // stop on newline-terminated attrs lacking ';' : heuristically when next token followed by ':' or '('
                            let s = s.clone();
                            if !v.is_empty() && matches!(self.t.get(self.i + 1), Some(Tok::P(':')) | Some(Tok::P('('))) {
                                break;
                            }
                            v.push(s);
                            self.i += 1;
                        }
                    }
                }
                g.attrs.push((name, vec![v.join(" ")]));
            } else if self.is('(') {
                self.i += 1;
                let mut args = vec![];
                let mut cur = String::new();
                let mut depth = 0;
                while let Some(tk) = self.peek().cloned() {
                    self.i += 1;
                    match tk {
                        Tok::P(')') if depth == 0 => break,
                        Tok::P(')') => {
                            depth -= 1;
                            cur.push(')')
                        }
                        Tok::P('(') => {
                            depth += 1;
                            cur.push('(')
                        }
                        Tok::P(',') if depth == 0 => {
                            args.push(cur.trim().to_string());
                            cur.clear();
                        }
                        Tok::P(c) => cur.push(c),
                        Tok::W(s) | Tok::S(s) => {
                            if !cur.is_empty() {
                                cur.push(' ');
                            }
                            cur.push_str(&s)
                        }
                    }
                }
                if !cur.trim().is_empty() || !args.is_empty() {
                    args.push(cur.trim().to_string());
                }
                if self.is('{') {
                    self.i += 1;
                    let mut sg = Group { gtype: name, args, ..Default::default() };
                    self.body(&mut sg)?;
                    g.groups.push(sg);
                } else {
                    if self.is(';') {
                        self.i += 1;
                    }
                    g.attrs.push((name, args));
                }
            } else {
                // stray word; skip
            }
        }
    }
}

pub fn parse_groups(src: &str) -> Result<Group, String> {
    let mut p = P { t: lex(src), i: 0 };
    let mut root = Group::default();
    p.body(&mut root)?;
    root.groups.into_iter().find(|g| g.gtype == "library").ok_or_else(|| "no library group found".into())
}

// ---------------------------------------------------------------- semantic model
#[derive(Debug, Clone, Default)]
pub struct Table {
    pub var1: String,
    pub var2: String,
    pub idx1: Vec<f64>,
    pub idx2: Vec<f64>,
    pub vals: Vec<Vec<f64>>, // vals[i1][i2]
}

fn interp1(idx: &[f64], x: f64) -> (usize, f64) {
    if idx.len() < 2 {
        return (0, 0.0);
    }
    let mut i = 0;
    while i + 2 < idx.len() && x > idx[i + 1] {
        i += 1;
    }
    let d = idx[i + 1] - idx[i];
    (i, if d.abs() < 1e-30 { 0.0 } else { (x - idx[i]) / d })
}

impl Table {
    /// Lookup with a variable resolver (maps liberty variable names to values).
    pub fn eval(&self, f: &dyn Fn(&str) -> f64) -> f64 {
        if self.vals.is_empty() {
            return 0.0;
        }
        let x = f(&self.var1);
        if self.idx2.len() < 2 || self.vals[0].len() < 2 {
            if self.idx1.len() < 2 || self.vals.len() < 2 {
                // 1-D along index_2 or scalar
                if self.vals[0].len() >= 2 && self.idx1.len() >= 2 && self.vals.len() == 1 {
                    let (i, t) = interp1(&self.idx1, x);
                    return self.vals[0][i] + t * (self.vals[0][i + 1] - self.vals[0][i]);
                }
                return self.vals[0][0];
            }
            let (i, t) = interp1(&self.idx1, x);
            return self.vals[i][0] + t * (self.vals[i + 1][0] - self.vals[i][0]);
        }
        let y = f(&self.var2);
        let (i, tx) = interp1(&self.idx1, x);
        let (j, ty) = interp1(&self.idx2, y);
        let v00 = self.vals[i][j];
        let v01 = self.vals[i][j + 1];
        let v10 = self.vals[i + 1][j];
        let v11 = self.vals[i + 1][j + 1];
        let a = v00 + ty * (v01 - v00);
        let b = v10 + ty * (v11 - v10);
        a + tx * (b - a)
    }
    /// Delay-style lookup: (input transition, output load cap)
    pub fn delay(&self, tran: f64, cap: f64) -> f64 {
        self.eval(&|v: &str| if v.contains("capacitance") { cap } else { tran })
    }
    /// Constraint lookup: (related/clock transition, constrained/data transition)
    pub fn constraint(&self, clk: f64, data: f64) -> f64 {
        self.eval(&|v: &str| if v.starts_with("related") { clk } else { data })
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TType {
    Comb,
    RisingEdge,
    FallingEdge,
    SetupRising,
    SetupFalling,
    HoldRising,
    HoldFalling,
    RecoveryRising,
    RemovalRising,
    Clear,
    Preset,
    NonSeqSetup,
    NonSeqHold,
    Other,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Sense {
    Pos,
    Neg,
    Non,
}

#[derive(Debug, Clone)]
pub struct TArc {
    pub related: String,
    pub ttype: TType,
    pub sense: Sense,
    pub cell_rise: Option<Table>,
    pub cell_fall: Option<Table>,
    pub rise_tran: Option<Table>,
    pub fall_tran: Option<Table>,
    pub rise_con: Option<Table>,
    pub fall_con: Option<Table>,
    pub ccs: bool,
    pub ecsm: bool,
}

#[derive(Debug, Clone, Default)]
pub struct LibPin {
    pub name: String,
    pub dir: Option<crate::netlist::Dir>,
    pub cap: f64,
    pub max_tran: Option<f64>,
    pub max_cap: Option<f64>,
    pub function: Option<String>,
    pub is_clock: bool,
    pub arcs: Vec<TArc>,
    pub rise_power: Option<Table>,
    pub fall_power: Option<Table>,
    pub min_pw_high: Option<f64>,
    pub min_pw_low: Option<f64>,
    pub min_period: Option<f64>,
    pub cg_role: Option<String>, // clock/enable/test/out
    pub iso_enable: bool,
    pub ls_enable: bool,
    pub nextstate_type: Option<String>, // scan_in / scan_enable / data ...
    pub retention_pin: Option<String>,
    pub ccs_receiver: bool,
    pub ccsn: bool,
}

#[derive(Debug, Clone, Default)]
pub struct SeqInfo {
    pub is_latch: bool,
    pub clocked_on: String, // e.g. "CK" or "!CK"
    pub next_state: String,
    pub clear: Option<String>,
    pub preset: Option<String>,
}

#[derive(Debug, Clone, Default)]
pub struct LibCell {
    pub name: String,
    pub area: f64,
    pub leakage: f64,
    pub pins: Vec<LibPin>,
    pub seq: Option<SeqInfo>,
    pub dont_use: bool,
    pub dont_touch: bool,
    pub icg: Option<String>,
    pub is_iso: bool,
    pub is_ls: bool,
    pub ls_type: Option<String>,
    pub always_on: bool,
    pub retention: bool,
    pub tie: Option<bool>,
    pub scan: bool,
    pub vt: String,
    pub drive: f64,
    pub family: String,
    pub footprint: String,
    pub is_buf: bool,
    pub is_inv: bool,
    pub is_delay: bool,
    pub is_switch: bool,
}

impl LibCell {
    pub fn pin(&self, n: &str) -> Option<&LibPin> {
        self.pins.iter().find(|p| p.name == n)
    }
    pub fn inputs(&self) -> Vec<&LibPin> {
        self.pins.iter().filter(|p| p.dir == Some(crate::netlist::Dir::In)).collect()
    }
    pub fn outputs(&self) -> Vec<&LibPin> {
        self.pins.iter().filter(|p| p.dir == Some(crate::netlist::Dir::Out)).collect()
    }
    pub fn is_seq(&self) -> bool {
        self.seq.is_some() || self.icg.is_some()
    }
    pub fn is_comb(&self) -> bool {
        !self.is_seq() && self.outputs().len() == 1 && self.outputs()[0].function.is_some()
    }
}

#[derive(Debug, Clone, Default)]
pub struct WireLoad {
    pub name: String,
    pub cap: f64,
    pub res: f64,
    pub slope: f64,
    pub fanout_len: Vec<(usize, f64)>,
}
impl WireLoad {
    pub fn length(&self, fo: usize) -> f64 {
        if let Some(&(_, l)) = self.fanout_len.iter().find(|(f, _)| *f == fo) {
            return l;
        }
        let (mf, ml) = self.fanout_len.iter().max_by_key(|x| x.0).copied().unwrap_or((1, 0.0));
        if fo > mf {
            ml + (fo - mf) as f64 * self.slope
        } else {
            // interpolate
            let lo = self.fanout_len.iter().filter(|x| x.0 < fo).max_by_key(|x| x.0).copied().unwrap_or((0, 0.0));
            let hi = self.fanout_len.iter().filter(|x| x.0 > fo).min_by_key(|x| x.0).copied().unwrap_or((mf, ml));
            lo.1 + (hi.1 - lo.1) * (fo - lo.0) as f64 / ((hi.0 - lo.0).max(1)) as f64
        }
    }
}

#[derive(Debug, Clone, Default)]
pub struct Library {
    pub name: String,
    pub file: String,
    pub time_scale: f64, // multiply lib time by this -> ns
    pub cap_scale: f64,  // -> pF
    pub leak_scale: f64, // -> nW
    pub nom_voltage: f64,
    pub nom_temp: f64,
    pub nom_process: f64,
    pub cells: HashMap<String, LibCell>,
    pub cell_order: Vec<String>,
    pub wire_loads: HashMap<String, WireLoad>,
    pub default_wire_load: Option<String>,
    pub default_max_tran: Option<f64>,
    pub default_max_fanout: Option<f64>,
    pub default_max_cap: Option<f64>,
    pub default_fanout_load: f64,
    pub n_ccs: usize,
    pub n_ecsm: usize,
    pub n_ccsn: usize,
    pub n_nldm: usize,
}

fn parse_nums(s: &str) -> Vec<f64> {
    s.split(|c: char| c == ',' || c.is_whitespace() || c == '"' || c == '\\')
        .filter(|x| !x.is_empty())
        .filter_map(|x| x.parse().ok())
        .collect()
}

fn unit_scale(s: &str, base: &[(&str, f64)]) -> f64 {
    let s = s.trim().trim_matches('"').to_lowercase();
    let num: String = s.chars().take_while(|c| c.is_ascii_digit() || *c == '.').collect();
    let n: f64 = num.parse().unwrap_or(1.0);
    for (u, f) in base {
        if s.ends_with(u) {
            return n * f;
        }
    }
    n
}

/// scale table axes to ns / pF (the library's time and capacitance units)
fn scale_axes(t: &mut Table, ts: f64, cs: f64) {
    for (var, idx) in [(&t.var1, &mut t.idx1), (&t.var2, &mut t.idx2)] {
        let k = if var.contains("capacitance") { cs } else if var.contains("transition") { ts } else { 1.0 };
        if (k - 1.0).abs() > 1e-12 { for v in idx.iter_mut() { *v *= k; } }
    }
}
fn mk_table(g: &Group, templates: &HashMap<String, Group>) -> Table {
    let tmpl = g.args.first().and_then(|t| templates.get(t));
    let mut t = Table::default();
    if let Some(tp) = tmpl {
        t.var1 = tp.attr("variable_1").unwrap_or("").to_string();
        t.var2 = tp.attr("variable_2").unwrap_or("").to_string();
        if let Some(v) = tp.attr_all("index_1") {
            t.idx1 = parse_nums(&v.join(","));
        }
        if let Some(v) = tp.attr_all("index_2") {
            t.idx2 = parse_nums(&v.join(","));
        }
    }
    if let Some(v) = g.attr_all("index_1") {
        t.idx1 = parse_nums(&v.join(","));
    }
    if let Some(v) = g.attr_all("index_2") {
        t.idx2 = parse_nums(&v.join(","));
    }
    if let Some(v) = g.attr_all("values") {
        let rows: Vec<Vec<f64>> = v.iter().map(|r| parse_nums(r)).filter(|r| !r.is_empty()).collect();
        if rows.len() == 1 && t.idx2.len() > 1 && t.idx1.len() > 1 && rows[0].len() == t.idx1.len() * t.idx2.len() {
            t.vals = rows[0].chunks(t.idx2.len()).map(|c| c.to_vec()).collect();
        } else if rows.len() == 1 && t.idx2.is_empty() && t.idx1.len() > 1 {
            // 1-D table indexed by var1
            t.vals = rows[0].iter().map(|v| vec![*v]).collect();
        } else {
            t.vals = rows;
        }
    }
    if t.var1.is_empty() {
        t.var1 = "input_net_transition".into();
        t.var2 = "total_output_net_capacitance".into();
    }
    t
}

fn detect_vt(name: &str, g: &Group) -> String {
    if let Some(v) = g.attr("threshold_voltage_group") {
        return v.to_uppercase();
    }
    let u = name.to_uppercase();
    for v in ["ULVT", "LVT", "HVT", "SVT", "RVT", "UHVT"] {
        if u.contains(v) {
            return if v == "RVT" { "SVT".into() } else { v.into() };
        }
    }
    "SVT".into()
}

fn detect_drive(name: &str) -> Option<f64> {
    let u = name.to_uppercase();
    let b = u.as_bytes();
    // find last 'X' or 'D' followed by digits
    let mut best = None;
    for i in 0..b.len() {
        if (b[i] == b'X' || b[i] == b'D') && i + 1 < b.len() && b[i + 1].is_ascii_digit() && (i == 0 || !b[i - 1].is_ascii_alphabetic() || b[i - 1] == b'_') {
            let d: String = u[i + 1..].chars().take_while(|c| c.is_ascii_digit() || *c == 'P').collect();
            let d = d.replace('P', ".");
            if let Ok(v) = d.parse::<f64>() {
                best = Some(v);
            }
        }
    }
    best
}

impl Library {
    pub fn load(path: &str) -> Result<Library, String> {
        let src = std::fs::read_to_string(path).map_err(|e| format!("cannot read {}: {}", path, e))?;
        let g = parse_groups(&src)?;
        let mut l = Library::from_group(&g);
        l.file = path.to_string();
        Ok(l)
    }
    pub fn from_group(g: &Group) -> Library {
        let mut l = Library {
            name: g.args.first().cloned().unwrap_or_default(),
            time_scale: unit_scale(g.attr("time_unit").unwrap_or("1ns"), &[("ps", 1e-3), ("ns", 1.0), ("us", 1e3)]),
            leak_scale: unit_scale(
                g.attr("leakage_power_unit").unwrap_or("1nW"),
                &[("pw", 1e-3), ("nw", 1.0), ("uw", 1e3), ("mw", 1e6)],
            ),
            cap_scale: 1.0,
            nom_voltage: g.num("nom_voltage").unwrap_or(1.0),
            nom_temp: g.num("nom_temperature").unwrap_or(25.0),
            nom_process: g.num("nom_process").unwrap_or(1.0),
            default_max_tran: g.num("default_max_transition"),
            default_max_fanout: g.num("default_max_fanout"),
            default_max_cap: g.num("default_max_capacitance"),
            default_fanout_load: g.num("default_fanout_load").unwrap_or(1.0),
            default_wire_load: g.attr("default_wire_load").map(|s| s.to_string()),
            ..Default::default()
        };
        if let Some(v) = g.attr_all("capacitive_load_unit") {
            let n: f64 = v.first().and_then(|s| s.trim().parse().ok()).unwrap_or(1.0);
            let u = v.get(1).map(|s| s.trim().to_lowercase()).unwrap_or("pf".into());
            l.cap_scale = n * if u == "ff" { 1e-3 } else { 1.0 };
        }
        let mut templates: HashMap<String, Group> = HashMap::new();
        for t in g.groups.iter().filter(|x| x.gtype.ends_with("_template")) {
            if let Some(n) = t.args.first() {
                templates.insert(n.clone(), t.clone());
            }
        }
        for w in g.sub("wire_load") {
            let mut wl = WireLoad {
                name: w.args.first().cloned().unwrap_or_default(),
                cap: w.num("capacitance").unwrap_or(0.0),
                res: w.num("resistance").unwrap_or(0.0),
                slope: w.num("slope").unwrap_or(0.0),
                fanout_len: vec![],
            };
            for (k, v) in &w.attrs {
                if k == "fanout_length" && v.len() >= 2 {
                    if let (Ok(f), Ok(len)) = (v[0].trim().parse::<usize>(), v[1].trim().parse::<f64>()) {
                        wl.fanout_len.push((f, len));
                    }
                }
            }
            l.wire_loads.insert(wl.name.clone(), wl);
        }
        for cg in g.sub("cell") {
            let c = l.mk_cell(cg, &templates);
            l.cell_order.push(c.name.clone());
            l.cells.insert(c.name.clone(), c);
        }
        l.build_families();
        l
    }

    fn mk_cell(&mut self, cg: &Group, templates: &HashMap<String, Group>) -> LibCell {
        use crate::netlist::Dir;
        let name = cg.args.first().cloned().unwrap_or_default();
        let mut c = LibCell {
            name: name.clone(),
            area: cg.num("area").unwrap_or(0.0),
            leakage: cg.num("cell_leakage_power").unwrap_or(0.0) * self.leak_scale,
            dont_use: cg.attr("dont_use").map(|v| v == "true").unwrap_or(false),
            dont_touch: cg.attr("dont_touch").map(|v| v == "true").unwrap_or(false),
            icg: cg.attr("clock_gating_integrated_cell").map(|s| s.to_string()),
            is_iso: cg.attr("is_isolation_cell").map(|v| v == "true").unwrap_or(false),
            is_ls: cg.attr("is_level_shifter").map(|v| v == "true").unwrap_or(false),
            ls_type: cg.attr("level_shifter_type").map(|s| s.to_string()),
            always_on: cg.attr("always_on").map(|v| v == "true").unwrap_or(false),
            retention: cg.attr("retention_cell").is_some(),
            is_switch: cg.attr("switch_cell_type").is_some(),
            vt: detect_vt(&name, cg),
            footprint: cg.attr("cell_footprint").unwrap_or("").to_string(),
            ..Default::default()
        };
        if c.leakage == 0.0 {
            let lp: Vec<f64> = cg.sub("leakage_power").filter_map(|g| g.num("value")).collect();
            if !lp.is_empty() {
                c.leakage = lp.iter().sum::<f64>() / lp.len() as f64 * self.leak_scale;
            }
        }
        c.scan = cg.sub("test_cell").next().is_some();
        for sg in cg.groups.iter().filter(|x| x.gtype == "ff" || x.gtype == "latch") {
            let is_latch = sg.gtype == "latch";
            c.seq = Some(SeqInfo {
                is_latch,
                clocked_on: sg.attr(if is_latch { "enable" } else { "clocked_on" }).unwrap_or("").to_string(),
                next_state: sg.attr(if is_latch { "data_in" } else { "next_state" }).unwrap_or("").to_string(),
                clear: sg.attr("clear").map(|s| s.to_string()),
                preset: sg.attr("preset").map(|s| s.to_string()),
            });
        }
        let mut pin_groups: Vec<&Group> = vec![];
        for pg in cg.groups.iter() {
            if pg.gtype == "pin" {
                pin_groups.push(pg);
            } else if pg.gtype == "bus" || pg.gtype == "bundle" {
                for sp in pg.sub("pin") {
                    pin_groups.push(sp);
                }
            }
        }
        for pg in pin_groups {
            for pname in &pg.args {
                let mut p = LibPin {
                    name: pname.clone(),
                    dir: match pg.attr("direction") {
                        Some("input") => Some(Dir::In),
                        Some("output") => Some(Dir::Out),
                        Some("inout") => Some(Dir::InOut),
                        _ => None,
                    },
                    cap: pg.num("capacitance").unwrap_or(0.0) * self.cap_scale,
                    max_tran: pg.num("max_transition").map(|v| v * self.time_scale),
                    max_cap: pg.num("max_capacitance").map(|v| v * self.cap_scale),
                    function: pg.attr("function").map(|s| s.to_string()),
                    is_clock: pg.attr("clock").map(|v| v == "true").unwrap_or(false),
                    min_pw_high: pg.num("min_pulse_width_high").map(|v| v * self.time_scale),
                    min_pw_low: pg.num("min_pulse_width_low").map(|v| v * self.time_scale),
                    min_period: pg.num("min_period").map(|v| v * self.time_scale),
                    iso_enable: pg.attr("isolation_cell_enable_pin").map(|v| v == "true").unwrap_or(false),
                    ls_enable: pg.attr("level_shifter_enable_pin").map(|v| v == "true").unwrap_or(false),
                    nextstate_type: pg.attr("nextstate_type").map(|s| s.to_string()),
                    retention_pin: pg.attr_all("retention_pin").map(|v| v.join(",")),
                    ..Default::default()
                };
                for k in ["clock_gate_clock_pin", "clock_gate_enable_pin", "clock_gate_test_pin", "clock_gate_out_pin"] {
                    if pg.attr(k) == Some("true") {
                        p.cg_role = Some(k.trim_start_matches("clock_gate_").trim_end_matches("_pin").to_string());
                    }
                }
                if pg.has_sub("receiver_capacitance") || pg.attr("receiver_capacitance1_rise").is_some() {
                    p.ccs_receiver = true;
                    if p.cap == 0.0 {
                        let rc: Vec<f64> = pg.groups.iter().filter(|g| g.gtype.starts_with("receiver_capacitance")).flat_map(|g| g.groups.iter()).filter_map(|t| t.attr_all("values").map(|v| parse_nums(&v.join(",")))).flatten().collect();
                        if !rc.is_empty() {
                            p.cap = rc.iter().sum::<f64>() / rc.len() as f64 * self.cap_scale;
                        }
                    }
                }
                if pg.has_sub("ccsn_first_stage") || pg.has_sub("ccsn_last_stage") {
                    p.ccsn = true;
                    self.n_ccsn += 1;
                }
                for tg in pg.sub("timing") {
                    let tt = match tg.attr("timing_type").unwrap_or("combinational") {
                        "combinational" | "combinational_rise" | "combinational_fall" | "three_state_enable" | "three_state_disable" => TType::Comb,
                        "rising_edge" => TType::RisingEdge,
                        "falling_edge" => TType::FallingEdge,
                        "setup_rising" => TType::SetupRising,
                        "setup_falling" => TType::SetupFalling,
                        "hold_rising" => TType::HoldRising,
                        "hold_falling" => TType::HoldFalling,
                        "recovery_rising" => TType::RecoveryRising,
                        "removal_rising" => TType::RemovalRising,
                        "clear" => TType::Clear,
                        "preset" => TType::Preset,
                        "non_seq_setup_rising" | "non_seq_setup_falling" => TType::NonSeqSetup,
                        "non_seq_hold_rising" | "non_seq_hold_falling" => TType::NonSeqHold,
                        _ => TType::Other,
                    };
                    let sense = match tg.attr("timing_sense").unwrap_or("non_unate") {
                        "positive_unate" => Sense::Pos,
                        "negative_unate" => Sense::Neg,
                        _ => Sense::Non,
                    };
                    let tb = |n: &str| tg.sub(n).next().map(|g| {
                        let mut t = mk_table(g, templates);
                        for r in t.vals.iter_mut() {
                            for v in r.iter_mut() {
                                *v *= self.time_scale;
                            }
                        }
                        scale_axes(&mut t, self.time_scale, self.cap_scale);
                        t
                    });
                    let ccs = tg.has_sub("output_current_rise") || tg.has_sub("output_current_fall");
                    let ecsm = tg.groups.iter().any(|g| g.gtype.starts_with("ecsm_waveform")) || tg.has_sub("ecsm_waveform_set");
                    if ccs {
                        self.n_ccs += 1
                    }
                    if ecsm {
                        self.n_ecsm += 1
                    }
                    let arc = TArc {
                        related: tg.attr("related_pin").unwrap_or("").to_string(),
                        ttype: tt,
                        sense,
                        cell_rise: tb("cell_rise"),
                        cell_fall: tb("cell_fall"),
                        rise_tran: tb("rise_transition"),
                        fall_tran: tb("fall_transition"),
                        rise_con: tb("rise_constraint"),
                        fall_con: tb("fall_constraint"),
                        ccs,
                        ecsm,
                    };
                    if arc.cell_rise.is_some() || arc.rise_con.is_some() {
                        self.n_nldm += 1;
                    }
                    for rp in arc.related.split_whitespace() {
                        let mut a = arc.clone();
                        a.related = rp.to_string();
                        p.arcs.push(a);
                    }
                }
                for ip in pg.sub("internal_power") {
                    // internal energy is in voltage x capacitance units: -> V * pF = pJ
                    let pw = |g: &Group| { let mut t = mk_table(g, templates); scale_axes(&mut t, self.time_scale, self.cap_scale); for r in t.vals.iter_mut() { for v in r.iter_mut() { *v *= self.cap_scale; } } t };
                    if let Some(r) = ip.sub("rise_power").next() {
                        p.rise_power = Some(pw(r));
                    }
                    if let Some(f) = ip.sub("fall_power").next() {
                        p.fall_power = Some(pw(f));
                    }
                }
                c.pins.push(p);
            }
        }
        // classification
        let outs: Vec<&LibPin> = c.pins.iter().filter(|p| p.dir == Some(Dir::Out)).collect();
        let ins: Vec<&LibPin> = c.pins.iter().filter(|p| p.dir == Some(Dir::In)).collect();
        if outs.len() == 1 && c.seq.is_none() {
            if let Some(f) = &outs[0].function {
                let f = f.trim().trim_matches('"').trim();
                if ins.is_empty() && (f == "0" || f == "1") {
                    c.tie = Some(f == "1");
                }
                if ins.len() == 1 {
                    let n = &ins[0].name;
                    let fz: String = f.chars().filter(|c| !c.is_whitespace()).collect();
                    if fz == *n || fz == format!("({})", n) {
                        c.is_buf = true;
                    } else if fz == format!("!{}", n) || fz == format!("{}'", n) || fz == format!("!({})", n) {
                        c.is_inv = true;
                    }
                }
            }
        }
        c.is_delay = c.is_buf && (name.to_uppercase().starts_with("DLY") || name.to_uppercase().contains("DEL"));
        if c.pins.iter().any(|p| p.nextstate_type.as_deref() == Some("scan_enable")) {
            c.scan = true;
        }
        c.drive = detect_drive(&name).unwrap_or(c.area.max(0.1));
        c
    }

    /// Group functionally equivalent cells (same pins, functions, seq type) into families.
    pub fn build_families(&mut self) {
        for c in self.cells.values_mut() {
            let mut sig = vec![];
            let mut pins: Vec<&LibPin> = c.pins.iter().collect();
            pins.sort_by(|a, b| a.name.cmp(&b.name));
            for p in pins {
                sig.push(format!("{}:{:?}:{}", p.name, p.dir, p.function.clone().unwrap_or_default().replace(' ', "")));
            }
            if let Some(s) = &c.seq {
                sig.push(format!("seq:{}:{}:{}:{:?}:{:?}", s.is_latch, s.clocked_on, s.next_state, s.clear, s.preset));
            }
            if let Some(i) = &c.icg {
                sig.push(format!("icg:{}", i));
            }
            sig.push(format!("iso{}ls{}aon{}ret{}dly{}", c.is_iso, c.is_ls, c.always_on, c.retention, c.is_delay));
            c.family = sig.join("|");
        }
    }
    /// Library cells in file order (deterministic iteration; never iterate `cells` directly
    /// when the result can influence optimization choices).
    pub fn cells_sorted(&self) -> Vec<&LibCell> {
        self.cell_order.iter().filter_map(|n| self.cells.get(n)).collect()
    }
    /// Cells in the same family as `cell` (any Vt / drive)
    pub fn family_of(&self, cell: &str) -> Vec<&LibCell> {
        let f = match self.cells.get(cell) {
            Some(c) => c.family.clone(),
            None => return vec![],
        };
        let mut v: Vec<&LibCell> = self.cells_sorted().into_iter().filter(|c| c.family == f).collect();
        v.sort_by(|a, b| a.drive.partial_cmp(&b.drive).unwrap().then(a.name.cmp(&b.name)));
        v
    }
    pub fn summary(&self) -> String {
        let vts: std::collections::BTreeSet<&str> = self.cells.values().map(|c| c.vt.as_str()).collect();
        format!(
            "Library '{}' ({}): {} cells, Vt classes {:?}, V={} T={} P={}; NLDM arcs={} CCS arcs={} ECSM arcs={} CCSN pins={} wire_loads={}",
            self.name,
            self.file,
            self.cells.len(),
            vts,
            self.nom_voltage,
            self.nom_temp,
            self.nom_process,
            self.n_nldm,
            self.n_ccs,
            self.n_ecsm,
            self.n_ccsn,
            self.wire_loads.len()
        )
    }
}

// ---------------------------------------------------------------- boolean functions
#[derive(Debug, Clone)]
pub enum BExpr {
    Var(String),
    Const(bool),
    Not(Box<BExpr>),
    And(Box<BExpr>, Box<BExpr>),
    Or(Box<BExpr>, Box<BExpr>),
    Xor(Box<BExpr>, Box<BExpr>),
}

pub fn parse_func(s: &str) -> Option<BExpr> {
    let t: Vec<char> = s.trim().trim_matches('"').chars().collect();
    let mut i = 0;
    let e = bor(&t, &mut i)?;
    Some(e)
}
fn skip(t: &[char], i: &mut usize) {
    while *i < t.len() && t[*i] == ' ' {
        *i += 1
    }
}
fn bor(t: &[char], i: &mut usize) -> Option<BExpr> {
    let mut l = bxor(t, i)?;
    loop {
        skip(t, i);
        if *i < t.len() && (t[*i] == '|' || t[*i] == '+') {
            *i += 1;
            let r = bxor(t, i)?;
            l = BExpr::Or(Box::new(l), Box::new(r));
        } else {
            return Some(l);
        }
    }
}
fn bxor(t: &[char], i: &mut usize) -> Option<BExpr> {
    let mut l = band(t, i)?;
    loop {
        skip(t, i);
        if *i < t.len() && t[*i] == '^' {
            *i += 1;
            let r = band(t, i)?;
            l = BExpr::Xor(Box::new(l), Box::new(r));
        } else {
            return Some(l);
        }
    }
}
fn band(t: &[char], i: &mut usize) -> Option<BExpr> {
    let mut l = bun(t, i)?;
    loop {
        skip(t, i);
        if *i < t.len() && (t[*i] == '&' || t[*i] == '*') {
            *i += 1;
            let r = bun(t, i)?;
            l = BExpr::And(Box::new(l), Box::new(r));
        } else if *i < t.len() && (t[*i].is_alphanumeric() || t[*i] == '(' || t[*i] == '!' || t[*i] == '_') {
            let r = bun(t, i)?; // juxtaposition = AND
            l = BExpr::And(Box::new(l), Box::new(r));
        } else {
            return Some(l);
        }
    }
}
fn bun(t: &[char], i: &mut usize) -> Option<BExpr> {
    skip(t, i);
    if *i >= t.len() {
        return None;
    }
    let mut e = if t[*i] == '!' {
        *i += 1;
        BExpr::Not(Box::new(bun(t, i)?))
    } else if t[*i] == '(' {
        *i += 1;
        let e = bor(t, i)?;
        skip(t, i);
        if *i < t.len() && t[*i] == ')' {
            *i += 1
        }
        e
    } else {
        let mut s = String::new();
        while *i < t.len() && (t[*i].is_alphanumeric() || t[*i] == '_' || t[*i] == '[' || t[*i] == ']' || t[*i] == '.') {
            s.push(t[*i]);
            *i += 1;
        }
        if s.is_empty() {
            return None;
        }
        if s == "0" {
            BExpr::Const(false)
        } else if s == "1" {
            BExpr::Const(true)
        } else {
            BExpr::Var(s)
        }
    };
    while *i < t.len() && t[*i] == '\'' {
        *i += 1;
        e = BExpr::Not(Box::new(e));
    }
    Some(e)
}
impl BExpr {
    pub fn eval(&self, f: &dyn Fn(&str) -> bool) -> bool {
        match self {
            BExpr::Var(v) => f(v),
            BExpr::Const(b) => *b,
            BExpr::Not(a) => !a.eval(f),
            BExpr::And(a, b) => a.eval(f) && b.eval(f),
            BExpr::Or(a, b) => a.eval(f) || b.eval(f),
            BExpr::Xor(a, b) => a.eval(f) ^ b.eval(f),
        }
    }
    /// truth table (bit i = value when var k has value (i>>k)&1)
    pub fn tt(&self, vars: &[String]) -> u64 {
        let mut r = 0u64;
        for m in 0..(1u64 << vars.len()) {
            if self.eval(&|v: &str| vars.iter().position(|x| x == v).map(|k| (m >> k) & 1 == 1).unwrap_or(false)) {
                r |= 1 << m;
            }
        }
        r
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn table_bilinear_and_extrapolation() {
        let t = Table { var1: "input_net_transition".into(), var2: "total_output_net_capacitance".into(), idx1: vec![0.0, 1.0], idx2: vec![0.0, 1.0], vals: vec![vec![0.0, 1.0], vec![1.0, 2.0]] };
        assert!((t.delay(0.5, 0.5) - 1.0).abs() < 1e-12);
        assert!((t.delay(2.0, 0.0) - 2.0).abs() < 1e-12); // linear extrapolation
    }
    #[test]
    fn boolean_functions() {
        let f = parse_func("!((A1&A2)|B)").unwrap();
        let v = ["A1".to_string(), "A2".to_string(), "B".to_string()];
        assert_eq!(f.tt(&v), 0b0000_0111);
        let g = parse_func("A B' + C").unwrap();
        assert!(g.eval(&|p| p == "A") && !g.eval(&|p| p == "B"));
    }
}
