//! Technology-independent optimization on the generic netlist:
//! constant propagation, buffer/assign sweeping, redundant logic removal,
//! structural hashing (logic sharing), constant/equal register removal,
//! unloaded register removal, clock-gating insertion (enable-flop detection).

use crate::liberty::Library;
use crate::netlist::*;
use std::collections::HashMap;

#[derive(Default, Debug, Clone)]
pub struct GenStats {
    pub consts: usize,
    pub buffers: usize,
    pub dead: usize,
    pub merged: usize,
    pub const_regs: usize,
    pub unloaded_regs: usize,
    pub equal_regs: usize,
}

pub fn const_of(nl: &Netlist, n: NetId) -> Option<bool> {
    match nl.driver(n) {
        Some(PinRef::Cell(c, _)) => match nl.cell(c).kind {
            Kind::Gen(GOp::C0) => Some(false),
            Kind::Gen(GOp::C1) => Some(true),
            _ => None,
        },
        _ => None,
    }
}
pub fn const_net(nl: &mut Netlist, v: bool) -> NetId {
    let name = if v { "1'b1" } else { "1'b0" };
    if let Some(n) = nl.net_by_name(name) {
        if nl.driver(n).is_some() {
            return n;
        }
        let c = nl.fresh(if v { "logic1_" } else { "logic0_" });
        nl.add_gen(&c, if v { GOp::C1 } else { GOp::C0 }, &[], n);
        return n;
    }
    let n = nl.add_net(name);
    let c = nl.fresh(if v { "logic1_" } else { "logic0_" });
    nl.add_gen(&c, if v { GOp::C1 } else { GOp::C0 }, &[], n);
    n
}

pub fn is_auto(name: &str) -> bool {
    let last = name.rsplit('/').next().unwrap_or(name);
    (last.starts_with('n') && last.len() > 1 && last[1..].chars().all(|c| c.is_ascii_digit())) || last.contains("_unconn") || last.starts_with("1'b")
}

/// Merge `gone` into `keep`, keeping the more meaningful name.
pub fn merge_named(nl: &mut Netlist, keep: NetId, gone: NetId) {
    if keep == gone {
        return;
    }
    let kn = nl.net(keep).name.clone();
    let gn = nl.net(gone).name.clone();
    nl.merge_net(keep, gone);
    if is_auto(&kn) && !is_auto(&gn) && !kn.starts_with("1'b") {
        nl.rename_net(keep, &gn);
    }
}

enum Res {
    Const(bool),
    Wire(NetId),
    Inv(NetId),
    Keep,
}

fn fold(nl: &Netlist, op: GOp, ins: &[NetId]) -> Res {
    let k: Vec<Option<bool>> = ins.iter().map(|n| const_of(nl, *n)).collect();
    let eqab = ins.len() >= 2 && ins[0] == ins[1];
    match op {
        GOp::Buf => match k[0] {
            Some(v) => Res::Const(v),
            None => Res::Wire(ins[0]),
        },
        GOp::Not => match k[0] {
            Some(v) => Res::Const(!v),
            None => {
                // double inversion
                if let Some(PinRef::Cell(d, _)) = nl.driver(ins[0]) {
                    if nl.cell(d).gop() == Some(GOp::Not) && !nl.cell(d).frozen() {
                        if let Some(x) = nl.cell(d).pin_net("A") {
                            return Res::Wire(x);
                        }
                    }
                }
                Res::Keep
            }
        },
        GOp::And | GOp::Nand | GOp::Or | GOp::Nor | GOp::Xor | GOp::Xnor => {
            let inv = matches!(op, GOp::Nand | GOp::Nor | GOp::Xnor);
            let base = match op {
                GOp::And | GOp::Nand => 0,
                GOp::Or | GOp::Nor => 1,
                _ => 2,
            };
            let r = match base {
                0 => match (k[0], k[1]) {
                    (Some(false), _) | (_, Some(false)) => Res::Const(false),
                    (Some(true), Some(true)) => Res::Const(true),
                    (Some(true), None) => Res::Wire(ins[1]),
                    (None, Some(true)) => Res::Wire(ins[0]),
                    _ if eqab => Res::Wire(ins[0]),
                    _ => Res::Keep,
                },
                1 => match (k[0], k[1]) {
                    (Some(true), _) | (_, Some(true)) => Res::Const(true),
                    (Some(false), Some(false)) => Res::Const(false),
                    (Some(false), None) => Res::Wire(ins[1]),
                    (None, Some(false)) => Res::Wire(ins[0]),
                    _ if eqab => Res::Wire(ins[0]),
                    _ => Res::Keep,
                },
                _ => match (k[0], k[1]) {
                    (Some(a), Some(b)) => Res::Const(a ^ b),
                    (Some(false), None) => Res::Wire(ins[1]),
                    (None, Some(false)) => Res::Wire(ins[0]),
                    (Some(true), None) => Res::Inv(ins[1]),
                    (None, Some(true)) => Res::Inv(ins[0]),
                    _ if eqab => Res::Const(false),
                    _ => Res::Keep,
                },
            };
            if !inv {
                return r;
            }
            match r {
                Res::Const(v) => Res::Const(!v),
                Res::Wire(n) => Res::Inv(n),
                Res::Inv(n) => Res::Wire(n),
                Res::Keep => Res::Keep,
            }
        }
        GOp::Mux => {
            let (s, a, b) = (ins[0], ins[1], ins[2]);
            match k[0] {
                Some(false) => return Res::Wire(a),
                Some(true) => return Res::Wire(b),
                None => {}
            }
            if a == b {
                return Res::Wire(a);
            }
            match (k[1], k[2]) {
                (Some(x), Some(y)) if x == y => Res::Const(x),
                (Some(false), Some(true)) => Res::Wire(s),
                (Some(true), Some(false)) => Res::Inv(s),
                _ => Res::Keep,
            }
        }
        _ => Res::Keep,
    }
}

pub fn sweep(nl: &mut Netlist, merge_regs: bool, remove_const_regs: bool) -> GenStats {
    let mut st = GenStats::default();
    let mut changed = true;
    let mut iter = 0;
    while changed && iter < 50 {
        changed = false;
        iter += 1;
        for c in nl.cell_ids() {
            if !nl.cell_alive(c) || nl.cell(c).frozen() {
                continue;
            }
            let Some(op) = nl.cell(c).gop() else { continue };
            if matches!(op, GOp::C0 | GOp::C1) {
                continue;
            }
            if op == GOp::Dff || op == GOp::Latch {
                if !remove_const_regs {
                    continue;
                }
                let cell = nl.cell(c).clone();
                let Some(q) = cell.pin_net("Q") else { continue };
                let d = cell.pin_net("D");
                let rn = cell.pin_net("RN");
                let sn = cell.pin_net("SN");
                // tie-off inactive async pins
                for (pn, net) in [("RN", rn), ("SN", sn)] {
                    if let Some(n) = net {
                        if const_of(nl, n) == Some(true) {
                            let i = nl.cell(c).pin(pn).unwrap();
                            nl.disconnect(c, i);
                            nl.cell_mut(c).pins.remove(i);
                            // fix pin indices of following pins in nets
                            reindex_cell(nl, c);
                            changed = true;
                        }
                    }
                }
                let cell = nl.cell(c).clone();
                let rn = cell.pin_net("RN");
                let sn = cell.pin_net("SN");
                let dv = d.and_then(|x| const_of(nl, x));
                let self_loop = d == Some(q);
                let mut cv: Option<bool> = None;
                if op == GOp::Dff {
                    if rn.map(|x| const_of(nl, x) == Some(false)).unwrap_or(false) {
                        cv = Some(false)
                    } else if let Some(v) = dv {
                        if (rn.is_none() || !v) && (sn.is_none() || v) {
                            cv = Some(v)
                        }
                    } else if self_loop {
                        if rn.is_some() && sn.is_none() {
                            cv = Some(false)
                        } else if sn.is_some() && rn.is_none() {
                            cv = Some(true)
                        }
                    }
                } else if let Some(g) = cell.pin_net("G") {
                    if const_of(nl, g) == Some(true) {
                        if let Some(dn) = d {
                            crate::info!("OPT-1210", "Latch '{}' is always transparent; replaced by wire", cell.name);
                            nl.remove_cell(c);
                            merge_named(nl, dn, q);
                            changed = true;
                            continue;
                        }
                    }
                    if dv.is_some() {
                        cv = dv
                    }
                }
                if let Some(v) = cv {
                    crate::info!("OPT-1206", "Register '{}' is a constant {} and will be removed", cell.name, v as u8);
                    nl.remove_cell(c);
                    let k = const_net(nl, v);
                    nl.merge_net(k, q);
                    st.const_regs += 1;
                    changed = true;
                }
                continue;
            }
            let cell = nl.cell(c);
            let ins: Vec<NetId> = cell.pins.iter().filter(|p| p.dir == Dir::In).map(|p| p.net.unwrap_or(usize::MAX)).collect();
            if ins.iter().any(|&n| n == usize::MAX) {
                continue;
            }
            let Some(y) = cell.pin_net("Y") else { continue };
            if nl.drivers(y).len() > 1 {
                continue; // never collapse a multi-driven net (would short its drivers)
            }
            match fold(nl, op, &ins) {
                Res::Keep => {}
                Res::Const(v) => {
                    nl.remove_cell(c);
                    let k = const_net(nl, v);
                    nl.merge_net(k, y);
                    st.consts += 1;
                    changed = true;
                }
                Res::Wire(n) => {
                    if n == y {
                        continue;
                    }
                    nl.remove_cell(c);
                    if const_of(nl, n).is_some() {
                        nl.merge_net(n, y);
                    } else {
                        merge_named(nl, n, y);
                    }
                    if op == GOp::Buf {
                        st.buffers += 1
                    } else {
                        st.consts += 1
                    }
                    changed = true;
                }
                Res::Inv(n) => {
                    let name = nl.cell(c).name.clone();
                    nl.remove_cell(c);
                    nl.add_gen(&name, GOp::Not, &[n], y);
                    st.consts += 1;
                    changed = true;
                }
            }
        }
        // structural hashing
        let mut h: HashMap<(GOp, Vec<NetId>), NetId> = HashMap::new();
        for c in nl.cell_ids() {
            if !nl.cell_alive(c) || nl.cell(c).frozen() {
                continue;
            }
            let Some(op) = nl.cell(c).gop() else { continue };
            if matches!(op, GOp::C0 | GOp::C1 | GOp::Latch) || (op == GOp::Dff && !merge_regs) {
                continue;
            }
            let cell = nl.cell(c);
            let mut ins: Vec<NetId> = cell.pins.iter().filter(|p| p.dir == Dir::In).map(|p| p.net.unwrap_or(usize::MAX)).collect();
            if matches!(op, GOp::And | GOp::Or | GOp::Xor | GOp::Nand | GOp::Nor | GOp::Xnor) {
                ins.sort();
            }
            let out = cell.pins.iter().find(|p| p.dir == Dir::Out).and_then(|p| p.net);
            let Some(out) = out else { continue };
            let key = if op == GOp::Dff {
                // include pin names (RN/SN presence)
                let mut k = ins.clone();
                k.push(cell.pins.len());
                (op, k)
            } else {
                (op, ins)
            };
            if let Some(&o) = h.get(&key) {
                if o != out {
                    if op == GOp::Dff {
                        crate::info!("OPT-1215", "Register '{}' is equivalent to driver of '{}' and is merged", nl.cell(c).name, nl.net(o).name);
                        st.equal_regs += 1;
                    }
                    nl.remove_cell(c);
                    merge_named(nl, o, out);
                    st.merged += 1;
                    changed = true;
                }
            } else {
                h.insert(key, out);
            }
        }
        // dead logic
        let d = remove_dead(nl, &mut st);
        if d > 0 {
            changed = true;
        }
    }
    nl.sweep_nets();
    st
}

pub fn reindex_cell(nl: &mut Netlist, c: CellId) {
    let pins = nl.cell(c).pins.clone();
    for (i, p) in pins.iter().enumerate() {
        if let Some(n) = p.net {
            let net = nl.net_mut(n);
            for pr in net.conns.iter_mut() {
                if let PinRef::Cell(cc, _) = pr {
                    if *cc == c {
                        // will be rebuilt below
                    }
                }
            }
            net.conns.retain(|pr| !matches!(pr, PinRef::Cell(cc, _) if *cc == c));
            let _ = i;
        }
    }
    for (i, p) in pins.iter().enumerate() {
        if let Some(n) = p.net {
            nl.net_mut(n).conns.push(PinRef::Cell(c, i));
        }
    }
}

pub fn remove_dead(nl: &mut Netlist, st: &mut GenStats) -> usize {
    let mut removed = 0;
    loop {
        let mut any = false;
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            if cell.frozen() || matches!(cell.kind, Kind::BlackBox(_)) {
                continue;
            }
            if matches!(cell.kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) {
                continue;
            }
            let outs: Vec<NetId> = cell.pins.iter().filter(|p| p.dir == Dir::Out).filter_map(|p| p.net).collect();
            let used = outs.iter().any(|&n| nl.net(n).conns.iter().any(|pr| nl.is_load(*pr)));
            if !used {
                let seq = matches!(cell.kind, Kind::Gen(GOp::Dff) | Kind::Gen(GOp::Latch));
                if seq {
                    crate::info!("OPT-1207", "Register '{}' has no fanout and is removed (unloaded register)", cell.name);
                    st.unloaded_regs += 1;
                }
                nl.remove_cell(c);
                removed += 1;
                any = true;
            }
        }
        if !any {
            break;
        }
    }
    st.dead += removed;
    removed
}

/// Clock-gating insertion: registers with D = mux(en, Q, d) sharing clock/enable
/// are gated with an integrated clock-gating cell from the library.
pub fn insert_clock_gating(nl: &mut Netlist, lib: &Library, min_bits: usize, max_fanout: usize, exclude: &[String]) -> usize {
    let Some(icg) = lib.cells_sorted().into_iter().filter(|c| c.icg.as_deref().map(|s| s.contains("latch_posedge")).unwrap_or(false) && !c.dont_use).min_by(|a, b| a.area.partial_cmp(&b.area).unwrap()) else {
        crate::warn!("PWR-880", "No integrated clock-gating cell (latch_posedge) available in target library; clock gating skipped");
        return 0;
    };
    let role = |r: &str| icg.pins.iter().find(|p| p.cg_role.as_deref() == Some(r)).map(|p| p.name.clone());
    let (Some(ckp), Some(enp), Some(gp)) = (role("clock"), role("enable"), role("out")) else {
        crate::warn!("PWR-881", "ICG cell {} lacks clock_gate_*_pin attributes; clock gating skipped", icg.name);
        return 0;
    };
    let tp = role("test");
    // groups: (clk, en, polarity) -> [(ff, d)]
    let mut groups: HashMap<(NetId, NetId, bool, String), Vec<(CellId, NetId, CellId)>> = HashMap::new();
    for c in nl.cell_ids() {
        let cell = nl.cell(c);
        if cell.gop() != Some(GOp::Dff) || cell.frozen() || exclude.iter().any(|e| glob(e, &cell.name)) {
            continue;
        }
        let (Some(d), Some(q), Some(ck)) = (cell.pin_net("D"), cell.pin_net("Q"), cell.pin_net("CK")) else { continue };
        let Some(PinRef::Cell(m, _)) = nl.driver(d) else { continue };
        let mc = nl.cell(m);
        if mc.gop() != Some(GOp::Mux) {
            continue;
        }
        let (s, a, b) = (mc.pin_net("S").unwrap(), mc.pin_net("A").unwrap(), mc.pin_net("B").unwrap());
        let h = cell.hier_prefix().to_string();
        if a == q {
            groups.entry((ck, s, true, h)).or_default().push((c, b, m));
        } else if b == q {
            groups.entry((ck, s, false, h)).or_default().push((c, a, m));
        }
    }
    let mut n_gated = 0;
    let mut keys: Vec<_> = groups.keys().cloned().collect();
    keys.sort();
    for key in keys {
        let regs = &groups[&key];
        if regs.len() < min_bits {
            continue;
        }
        for chunk in regs.chunks(max_fanout.max(1)) {
            let (ck, en, pol, ref hier) = key;
            let first = nl.cell(chunk[0].0).name.clone();
            let leaf = first.rsplit('/').next().unwrap_or(&first);
            let base = leaf.split('[').next().unwrap_or(leaf).trim_end_matches("_reg").replace('.', "_");
            let gname = if hier.is_empty() { format!("clk_gate_{}", base) } else { format!("{}/clk_gate_{}", hier, base) };
            let mut pins: Vec<(&str, Dir)> = vec![];
            for p in &icg.pins {
                pins.push((p.name.as_str(), p.dir.unwrap_or(Dir::In)));
            }
            let g = nl.add_cell(&gname, Kind::Lib(icg.name.clone()), &pins);
            let gnet = nl.add_net(&format!("{}/GCLK", nl.cell(g).name.clone()));
            nl.connect_name(g, &ckp, ck);
            let en_net = if pol {
                en
            } else {
                let o = nl.add_net(&format!("{}_en_n", gname));
                let cn = nl.fresh("cg_inv");
                nl.add_gen(&cn, GOp::Not, &[en], o);
                o
            };
            nl.connect_name(g, &enp, en_net);
            nl.connect_name(g, &gp, gnet);
            if let Some(t) = &tp {
                let z = const_net(nl, false);
                nl.connect_name(g, t, z);
            }
            nl.cell_mut(g).attrs.push("clock_gate".into());
            for (ff, d, _m) in chunk {
                let ckpin = nl.cell(*ff).pin("CK").unwrap();
                nl.connect(*ff, ckpin, gnet);
                let dpin = nl.cell(*ff).pin("D").unwrap();
                nl.connect(*ff, dpin, *d);
                n_gated += 1;
            }
            crate::info!("PWR-730", "Inserted clock gate '{}' ({}) gating {} register(s) on enable '{}'", nl.cell(g).name, icg.name, chunk.len(), nl.net(en).name);
        }
    }
    let mut st = GenStats::default();
    remove_dead(nl, &mut st);
    n_gated
}
