//! Flip-chip area-IO methodology: bump arrays, supply / signal bump assignment, assignment
//! re-optimization, RDL routing (orthogonal or 45-degree) and bump dumps (DEF / GDS / text).
//!
//!  create_bump_array -cell BUMP60 -pitch p [-pitch_y p] [-layer AP] [-pattern full|staggered|perimeter]
//!                    [-rings n] [-margin um] [-area {x0 y0 x1 y1}] [-prefix bump]
//!  assign_bumps -power_nets {VDD..} -ground_nets {VSS..} [-supply_pattern checker|rows|center]
//!               [-pad_cells pat] [-signals ports] [-signal_rings n]
//!  optimize_bump_assignment [-iterations n] [-crossing_weight um] [-swap_supplies]
//!  route_rdl [-layer AP] [-width w] [-spacing s] [-allow_45] [-nets pats]
//!  report_bumps
//!  write_bumps -format def|gds|text file [-gds_layer n]

use crate::chipfp::{fr, seg_cross, Rect};
use crate::netlist::*;
use crate::phys::{Bump, SpecialShape};
use crate::session::{args, Session};
use crate::tcl::{err, split_list, Flow, R};
use std::collections::{HashMap, HashSet};

fn dist(a: (f64, f64), b: (f64, f64)) -> f64 {
    (a.0 - b.0).abs() + (a.1 - b.1).abs()
}

/// octilinear route a -> b: (diagonal-first, straight-first) when 45-degree is allowed,
/// else the two L shapes
pub fn rdl_paths(a: (f64, f64), b: (f64, f64), allow_45: bool) -> [Vec<(f64, f64)>; 2] {
    let (dx, dy) = (b.0 - a.0, b.1 - a.1);
    if allow_45 {
        let d = dx.abs().min(dy.abs());
        let (sx, sy) = (dx.signum(), dy.signum());
        let m1 = (a.0 + sx * d, a.1 + sy * d);
        let m2 = (b.0 - sx * d, b.1 - sy * d);
        [vec![a, m1, b], vec![a, m2, b]]
    } else {
        [vec![a, (b.0, a.1), b], vec![a, (a.0, b.1), b]]
    }
}
fn path_len(p: &[(f64, f64)]) -> f64 {
    p.windows(2).map(|w| ((w[1].0 - w[0].0).powi(2) + (w[1].1 - w[0].1).powi(2)).sqrt()).sum()
}
/// distance from point p to segment ab
fn seg_pt(a: (f64, f64), b: (f64, f64), p: (f64, f64)) -> f64 {
    let (vx, vy) = (b.0 - a.0, b.1 - a.1);
    let l2 = vx * vx + vy * vy;
    let t = if l2 < 1e-12 { 0.0 } else { (((p.0 - a.0) * vx + (p.1 - a.1) * vy) / l2).clamp(0.0, 1.0) };
    ((a.0 + t * vx - p.0).powi(2) + (a.1 + t * vy - p.1).powi(2)).sqrt()
}
fn seg_seg(a: (f64, f64), b: (f64, f64), c: (f64, f64), d: (f64, f64)) -> f64 {
    if seg_cross(a, b, c, d) { return 0.0; }
    seg_pt(a, b, c).min(seg_pt(a, b, d)).min(seg_pt(c, d, a)).min(seg_pt(c, d, b))
}

impl Session {
    pub fn flipchip_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "create_bump_array" | "create_bumps" => self.c_bump_array(a),
            "assign_bumps" | "assign_pg_bumps" => self.c_assign_bumps(a),
            "optimize_bump_assignment" | "reassign_bumps" => self.c_opt_bumps(a),
            "route_rdl" | "route_flip_chip" => self.c_route_rdl(a),
            "report_bumps" => self.c_report_bumps(a),
            "create_area_io" | "place_area_io" => self.c_area_io(a),
            "delete_bumps" | "remove_bumps" => {
                let pats: Vec<String> = a.iter().flat_map(|p| split_list(p)).collect();
                match self.fp.as_mut() {
                    None => err("delete_bumps: no floorplan (FP-001)"),
                    Some(fp) => {
                        let n0 = fp.bumps.len();
                        fp.bumps.retain(|b| !(pats.is_empty() || pats.iter().any(|q| glob(q, &b.name))));
                        let names: HashSet<String> = fp.bumps.iter().map(|b| b.net.clone()).collect();
                        let _ = names;
                        crate::info!("BUMP-101", "Deleted {} bump(s)", n0 - fp.bumps.len());
                        Ok((n0 - fp.bumps.len()).to_string())
                    }
                }
            }
            "write_bumps" | "write_bump_def" | "write_bump_gds" => {
                let mut v = a.to_vec();
                if name == "write_bump_def" { v.extend(["-format".into(), "def".into()]); }
                if name == "write_bump_gds" { v.extend(["-format".into(), "gds".into()]); }
                self.c_write_bumps(&v)
            }
            _ => return self.routeedit_cmd(name, a),
        })
    }

    /// area-IO pads (flip-chip): one pad per signal port, placed on a ring just inside the
    /// core boundary in port order (counter-clockwise from the lower-left corner)
    fn c_area_io(&mut self, a: &[String]) -> R {
        let x = args(a, &["-input_cell", "-output_cell", "-ports", "-inset", "-prefix", "-placement"]);
        let ic = x.get("-input_cell").cloned().unwrap_or("AIO_IN".into());
        let oc = x.get("-output_cell").cloned().unwrap_or("AIO_OUT".into());
        let prefix = x.get("-prefix").cloned().unwrap_or("aio".into());
        let pats: Vec<String> = x.get("-ports").map(|s| split_list(s)).unwrap_or_else(|| vec!["*".into()]);
        let (iw, ih) = self.lef.get(&ic).map(|m| (m.w, m.h)).ok_or_else(|| Flow::Err(format!("create_area_io: no LEF for '{}' (BUMP-040)", ic)))?;
        let fp = self.fp.clone().ok_or_else(|| Flow::Err("create_area_io: no floorplan (FP-001)".into()))?;
        let core = fp.place_region();
        let inset = x.num("-inset").unwrap_or(2.0);
        let nl = self.nl()?;
        let mut ports: Vec<(String, Dir)> = nl.port_ids().into_iter().map(|p| (nl.ports[p].name.clone(), nl.ports[p].dir)).filter(|(n, _)| pats.iter().any(|q| glob(q, n))).collect();
        ports.sort_by(|a, b| crate::chipfp::bus_key_pub(&a.0).cmp(&crate::chipfp::bus_key_pub(&b.0)));
        let (w, h) = (core.2 - core.0 - 2.0 * inset - ih, core.3 - core.1 - 2.0 * inset - ih);
        let per = 2.0 * (w + h);
        let n = ports.len();
        if n as f64 * iw > per {
            return err(&format!("create_area_io: {} pads of {} um do not fit along the core ({:.0} um) (BUMP-041)", n, iw, per));
        }
        // with a bump array: pads go on the channel crossings between bumps (outer rings first,
        // counter-clockwise), so the RDL drop to the pad never sits under another bump
        let mut slots: Vec<(f64, f64)> = vec![];
        if !fp.bumps.is_empty() && x.get("-placement").map(|p| p != "ring").unwrap_or(true) {
            let mut xs: Vec<f64> = fp.bumps.iter().map(|b| b.x).collect();
            let mut ys: Vec<f64> = fp.bumps.iter().map(|b| b.y).collect();
            xs.sort_by(|a, b| a.partial_cmp(b).unwrap()); xs.dedup_by(|a, b| (*a - *b).abs() < 1e-3);
            ys.sort_by(|a, b| a.partial_cmp(b).unwrap()); ys.dedup_by(|a, b| (*a - *b).abs() < 1e-3);
            let cx: Vec<f64> = xs.windows(2).map(|w| (w[0] + w[1]) / 2.0).collect();
            let cy: Vec<f64> = ys.windows(2).map(|w| (w[0] + w[1]) / 2.0).collect();
            let (nx, ny) = (cx.len(), cy.len());
            let ctr = ((core.0 + core.2) / 2.0, (core.1 + core.3) / 2.0);
            let mut v: Vec<(usize, f64, (f64, f64))> = vec![];
            for (i, xx) in cx.iter().enumerate() {
                for (j, yy) in cy.iter().enumerate() {
                    let ring = i.min(j).min(nx - 1 - i).min(ny - 1 - j);
                    let p = (*xx, *yy);
                    if p.0 - iw / 2.0 < core.0 || p.0 + iw / 2.0 > core.2 || p.1 - ih / 2.0 < core.1 || p.1 + ih / 2.0 > core.3 { continue; }
                    let ang = (p.1 - ctr.1).atan2(p.0 - ctr.0).rem_euclid(std::f64::consts::TAU);
                    v.push((ring, ang, p));
                }
            }
            v.sort_by(|a, b| (a.0, a.1).partial_cmp(&(b.0, b.1)).unwrap());
            if v.len() >= n {
                // the slots of the used rings, in angular order, ports in order around them
                let mut take: Vec<(usize, f64, (f64, f64))> = v.into_iter().take(n).collect();
                take.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());
                slots = take.into_iter().map(|t| (t.2 .0 - iw / 2.0, t.2 .1 - ih / 2.0)).collect();
            }
        }
        let mut placed = 0;
        for (k, (pn, d)) in ports.iter().enumerate() {
            let cell = if *d == Dir::Out { &oc } else { &ic };
            let inst = format!("{}_{}", prefix, pn.replace(['[', ']'], "_").trim_end_matches('_'));
            let c = self.make_inst(&inst, cell)?;
            self.insert_pad(pn, c)?;
            // position along the inner ring
            let t = (k as f64 + 0.5) / n as f64 * per;
            let (x0, y0) = (core.0 + inset, core.1 + inset);
            let ll = if let Some(sl) = slots.get(k) { *sl } else if t < w { (x0 + t - iw / 2.0, y0) } else if t < w + h { (x0 + w, y0 + t - w - iw / 2.0) } else if t < 2.0 * w + h { (x0 + w - (t - w - h) - iw / 2.0, y0 + h) } else { (x0, y0 + h - (t - 2.0 * w - h) - iw / 2.0) };
            let cl = self.nl.as_mut().unwrap().cell_mut(c);
            cl.loc = Some(ll);
            cl.fixed = true;
            cl.attrs.retain(|a| !a.starts_with("orient:"));
            cl.attrs.push("orient:N".into());
            cl.attrs.push("io_pad".into());
            cl.attrs.push("io_kind:area".into());
            placed += 1;
        }
        let fpm = self.fp.as_mut().unwrap();
        fpm.io.style = "area".into();
        crate::info!("BUMP-140", "Inserted {} area-IO pad(s) ({} / {}) {}", placed, ic, oc, if slots.is_empty() { format!("on a ring {:.1} um inside the core", inset) } else { "on the bump-channel crossings".to_string() });
        self.report_io_overlaps("create_area_io", false, true);
        Ok(placed.to_string())
    }

    fn c_bump_array(&mut self, a: &[String]) -> R {
        let x = args(a, &["-cell", "-pitch", "-pitch_y", "-layer", "-pattern", "-rings", "-margin", "-area", "-prefix"]);
        let cell = x.get("-cell").cloned().ok_or_else(|| Flow::Err("create_bump_array: -cell required (CMD-001)".into()))?;
        let bsz = self.lef.get(&cell).map(|m| m.w.max(m.h)).ok_or_else(|| Flow::Err(format!("create_bump_array: no LEF for bump cell '{}' (BUMP-001)", cell)))?;
        let px = x.num("-pitch").ok_or_else(|| Flow::Err("create_bump_array: -pitch required (CMD-001)".into()))?;
        let py = x.num("-pitch_y").unwrap_or(px);
        if px < bsz || py < bsz {
            return err(&format!("create_bump_array: pitch {} x {} is below the bump size {} (BUMP-002)", px, py, bsz));
        }
        let pattern = x.get("-pattern").cloned().unwrap_or("full".into());
        if !["full", "staggered", "perimeter"].contains(&pattern.as_str()) {
            return err(&format!("create_bump_array: -pattern '{}': full, staggered or perimeter (BUMP-003)", pattern));
        }
        let layer = x.get("-layer").cloned().unwrap_or("AP".into());
        let prefix = x.get("-prefix").cloned().unwrap_or("bump".into());
        let fp = self.fp.as_mut().ok_or_else(|| Flow::Err("create_bump_array: no floorplan (FP-001)".into()))?;
        let seal = fp.special.iter().filter(|s| s.kind == "seal_ring").map(|s| { let b = s.bbox(); (b.2 - b.0).min(b.3 - b.1) }).fold(0.0f64, f64::max);
        let margin = x.num("-margin").unwrap_or(seal + px / 2.0);
        let area: Rect = x.get("-area").and_then(|s| crate::fpcmd::parse_rect(s)).unwrap_or((fp.die.0 + margin, fp.die.1 + margin, fp.die.2 - margin, fp.die.3 - margin));
        let nx = (((area.2 - area.0 - bsz) / px).floor() as i64 + 1).max(0);
        let ny = (((area.3 - area.1 - bsz) / py).floor() as i64 + 1).max(0);
        if nx < 1 || ny < 1 {
            return err("create_bump_array: the area holds no bump (BUMP-004)");
        }
        // centre the array in the area
        let ox = area.0 + bsz / 2.0 + (area.2 - area.0 - bsz - (nx - 1) as f64 * px) / 2.0;
        let oy = area.1 + bsz / 2.0 + (area.3 - area.1 - bsz - (ny - 1) as f64 * py) / 2.0;
        let rings = x.get("-rings").and_then(|s| s.parse::<i64>().ok()).unwrap_or(2);
        fp.bumps.retain(|b| !b.name.starts_with(&format!("{}_", prefix)));
        let mut n = 0;
        for r in 0..ny {
            for c in 0..nx {
                let ring = r.min(c).min(ny - 1 - r).min(nx - 1 - c);
                if pattern == "perimeter" && ring >= rings { continue; }
                let mut cx = ox + c as f64 * px;
                if pattern == "staggered" && r % 2 == 1 {
                    cx += px / 2.0;
                    if cx + bsz / 2.0 > area.2 + 1e-6 { continue; }
                }
                let cy = oy + r as f64 * py;
                fp.bumps.push(Bump { name: format!("{}_{}_{}", prefix, r, c), cell: cell.clone(), x: cx, y: cy, layer: layer.clone(), kind: "unassigned".into(), fixed: true, ..Default::default() });
                n += 1;
            }
        }
        fp.io.style = "area".into();
        // overlap with bumps of other arrays
        let mine: Vec<&Bump> = fp.bumps.iter().filter(|b| b.name.starts_with(&format!("{}_", prefix))).collect();
        let ov = fp.bumps.iter().filter(|o| !o.name.starts_with(&format!("{}_", prefix))).filter(|o| mine.iter().any(|b| (b.x - o.x).abs() < bsz && (b.y - o.y).abs() < bsz)).count();
        if ov > 0 {
            crate::warn!("BUMP-005", "{} existing bump(s) overlap the new '{}' array (delete_bumps)", ov, prefix);
        }
        crate::info!("BUMP-100", "Created {} {} bump(s) ({} pattern, {} x {} grid, pitch {} x {} um, layer {}) in {}", n, cell, pattern, nx, ny, px, py, layer, fr(&area));
        Ok(n.to_string())
    }

    /// signal targets for bump assignment: (name, net, location)
    fn bump_targets(&self, pad_pat: Option<&String>, sig_pat: Option<&String>, supplies: &HashSet<String>) -> Vec<(String, String, (f64, f64))> {
        let nl = self.nl.as_ref().unwrap();
        let mut v = vec![];
        if let Some(pp) = pad_pat {
            let pats = split_list(pp);
            for c in nl.cell_ids() {
                let cl = nl.cell(c);
                if !pats.iter().any(|q| glob(q, &cl.name) || crate::lef::master(cl).map(|m| glob(q, m)).unwrap_or(false)) { continue; }
                let Some(pi) = cl.pins.iter().position(|p| p.name == "PAD") else { continue };
                let Some(n) = cl.pins[pi].net else { continue };
                let loc = crate::lef::pin_shapes(&self.lef, cl, "PAD").first().map(|(_, r)| ((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0))
                    .or_else(|| crate::lef::cell_rect(&self.lef, cl).map(|r| ((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0))).or(cl.loc);
                if let Some(l) = loc { v.push((cl.name.clone(), nl.net(n).name.clone(), l)); }
            }
        } else {
            let pats: Vec<String> = sig_pat.map(|s| split_list(s)).unwrap_or_else(|| vec!["*".into()]);
            for p in nl.port_ids() {
                let pt = &nl.ports[p];
                if supplies.contains(&pt.name) || !pats.iter().any(|q| glob(q, &pt.name)) { continue; }
                let loc = pt.loc.or_else(|| {
                    let n = pt.net?;
                    let ls: Vec<(f64, f64)> = Session::leaf_conns(nl, n).into_iter().filter_map(|q| match q { PinRef::Cell(c, _) if !nl.cell(c).is_hport() => nl.cell(c).loc, _ => None }).collect();
                    if ls.is_empty() { None } else { Some((ls.iter().map(|q| q.0).sum::<f64>() / ls.len() as f64, ls.iter().map(|q| q.1).sum::<f64>() / ls.len() as f64)) }
                });
                if let Some(l) = loc { v.push((pt.name.clone(), pt.net.map(|n| nl.net(n).name.clone()).unwrap_or(pt.name.clone()), l)); }
            }
        }
        v
    }

    fn c_assign_bumps(&mut self, a: &[String]) -> R {
        let x = args(a, &["-power_nets", "-ground_nets", "-supply_pattern", "-pad_cells", "-signals", "-signal_rings"]);
        let pw: Vec<String> = x.get("-power_nets").map(|s| split_list(s)).unwrap_or_else(|| vec!["VDD".into()]);
        let gn: Vec<String> = x.get("-ground_nets").map(|s| split_list(s)).unwrap_or_else(|| vec!["VSS".into()]);
        let sup: HashSet<String> = pw.iter().chain(gn.iter()).cloned().collect();
        let pattern = x.get("-supply_pattern").cloned().unwrap_or("checker".into());
        let targets = self.bump_targets(x.get("-pad_cells"), x.get("-signals"), &sup);
        let fp = self.fp.as_mut().ok_or_else(|| Flow::Err("assign_bumps: no floorplan (FP-001)".into()))?;
        if fp.bumps.is_empty() {
            return err("assign_bumps: no bumps (create_bump_array) (BUMP-010)");
        }
        if targets.len() > fp.bumps.len() {
            return err(&format!("assign_bumps: {} signal(s) for {} bump(s) (BUMP-011)", targets.len(), fp.bumps.len()));
        }
        // ring index of every bump (0 = outermost) from its grid position
        let xs: Vec<f64> = { let mut v: Vec<f64> = fp.bumps.iter().map(|b| b.x).collect(); v.sort_by(|a, b| a.partial_cmp(b).unwrap()); v };
        let ys: Vec<f64> = { let mut v: Vec<f64> = fp.bumps.iter().map(|b| b.y).collect(); v.sort_by(|a, b| a.partial_cmp(b).unwrap()); v };
        let (x0, x1, y0, y1) = (xs[0], *xs.last().unwrap(), ys[0], *ys.last().unwrap());
        let pitch = { let mut d: Vec<f64> = ys.windows(2).map(|w| w[1] - w[0]).filter(|d| *d > 1e-6).collect(); d.sort_by(|a, b| a.partial_cmp(b).unwrap()); d.first().copied().unwrap_or(1.0) };
        let ring = |b: &Bump| -> usize { (((b.x - x0).min(x1 - b.x).min(b.y - y0).min(y1 - b.y)) / pitch + 0.5).floor() as usize };
        let maxring = fp.bumps.iter().map(|b| ring(b)).max().unwrap_or(0);
        // signal rings: enough outer rings for the signals plus a supply share (1 in 4 of those
        // bumps stays supply, for signal return paths)
        let mut srings = x.get("-signal_rings").and_then(|s| s.parse::<usize>().ok()).unwrap_or(0);
        if srings == 0 {
            srings = 1;
            while srings <= maxring {
                let cap = fp.bumps.iter().filter(|b| ring(b) < srings).count();
                if cap * 3 / 4 >= targets.len() { break; }
                srings += 1;
            }
        }
        for b in fp.bumps.iter_mut() {
            b.net.clear(); b.pad.clear(); b.kind = "unassigned".into();
        }
        // ---- signals: greedy nearest, farthest-from-centre targets first
        let ctr = ((fp.die.0 + fp.die.2) / 2.0, (fp.die.1 + fp.die.3) / 2.0);
        let mut order: Vec<usize> = (0..targets.len()).collect();
        order.sort_by(|a, b| dist(targets[*b].2, ctr).partial_cmp(&dist(targets[*a].2, ctr)).unwrap());
        // every 4th signal-ring bump (in a checker sense) is reserved for supply
        let reserved: HashSet<usize> = fp.bumps.iter().enumerate().filter(|(_, b)| {
            let (r, c) = { let p: Vec<&str> = b.name.rsplitn(3, '_').collect(); (p.get(1).and_then(|v| v.parse::<i64>().ok()).unwrap_or(0), p.first().and_then(|v| v.parse::<i64>().ok()).unwrap_or(0)) };
            ring(b) < srings && (r % 2 == 0 && c % 2 == 0)
        }).map(|(i, _)| i).collect();
        let avail_sig = |i: usize, b: &Bump| ring(b) < srings && !reserved.contains(&i);
        let mut nsig = 0;
        let mut unplaced = 0;
        for t in order {
            let (nm, net, loc) = &targets[t];
            let best = fp.bumps.iter().enumerate().filter(|(i, b)| b.kind == "unassigned" && avail_sig(*i, b))
                .min_by(|a, b| dist((a.1.x, a.1.y), *loc).partial_cmp(&dist((b.1.x, b.1.y), *loc)).unwrap()).map(|(i, _)| i)
                .or_else(|| fp.bumps.iter().enumerate().filter(|(_, b)| b.kind == "unassigned").min_by(|a, b| dist((a.1.x, a.1.y), *loc).partial_cmp(&dist((b.1.x, b.1.y), *loc)).unwrap()).map(|(i, _)| i));
            match best {
                Some(i) => { let b = &mut fp.bumps[i]; b.kind = "signal".into(); b.net = net.clone(); b.pad = nm.clone(); nsig += 1; }
                None => unplaced += 1,
            }
        }
        // ---- supplies on every remaining bump
        let (mut np, mut ng) = (0, 0);
        let mut k = 0usize;
        for b in fp.bumps.iter_mut().filter(|b| b.kind == "unassigned") {
            let (r, c) = { let p: Vec<&str> = b.name.rsplitn(3, '_').collect(); (p.get(1).and_then(|v| v.parse::<i64>().ok()).unwrap_or(0), p.first().and_then(|v| v.parse::<i64>().ok()).unwrap_or(0)) };
            let in_sig_ring = ring(b) < srings;
            let power = if in_sig_ring { np <= ng } else { match pattern.as_str() {
                "rows" => r % 2 == 0,
                "center" => ((b.x - ctr.0).abs() + (b.y - ctr.1).abs()) / pitch % 2.0 < 1.0,
                _ => (r + c) % 2 == 0,
            } };
            if power {
                b.kind = "power".into(); b.net = pw[np % pw.len()].clone(); np += 1;
            } else {
                b.kind = "ground".into(); b.net = gn[ng % gn.len()].clone(); ng += 1;
            }
            k += 1;
        }
        let _ = k;
        let wl: f64 = fp.bumps.iter().filter(|b| b.kind == "signal").filter_map(|b| targets.iter().find(|t| t.0 == b.pad).map(|t| dist((b.x, b.y), t.2))).sum();
        crate::info!("BUMP-110", "Assigned {} signal bump(s) (outer {} ring(s)), {} power ({}) and {} ground ({}) bump(s), {} pattern; bump-to-pad distance {:.1} um{}",
            nsig, srings, np, pw.join(" "), ng, gn.join(" "), pattern, wl, if unplaced > 0 { format!(", {} unplaced", unplaced) } else { String::new() });
        if unplaced > 0 { crate::warn!("BUMP-112", "{} signal(s) found no free bump", unplaced); }
        Ok(nsig.to_string())
    }

    /// assignment cost: Manhattan bump-to-target length + weight * flyline crossings
    fn bump_cost(&self, tloc: &HashMap<String, (f64, f64)>, w: f64) -> (f64, usize) {
        let fp = self.fp.as_ref().unwrap();
        let fl: Vec<((f64, f64), (f64, f64))> = fp.bumps.iter().filter(|b| b.kind == "signal").filter_map(|b| tloc.get(&b.pad).map(|t| ((b.x, b.y), *t))).collect();
        let len: f64 = fl.iter().map(|(a, b)| dist(*a, *b)).sum();
        let mut cr = 0;
        for i in 0..fl.len() {
            for j in i + 1..fl.len() {
                if seg_cross(fl[i].0, fl[i].1, fl[j].0, fl[j].1) { cr += 1; }
            }
        }
        (len + w * cr as f64, cr)
    }

    fn target_locs(&self) -> HashMap<String, (f64, f64)> {
        let nl = self.nl.as_ref().unwrap();
        let fp = self.fp.as_ref().unwrap();
        let mut m = HashMap::new();
        for b in fp.bumps.iter().filter(|b| b.kind == "signal") {
            if let Some(c) = nl.cell_by_name(&b.pad) {
                let cl = nl.cell(c);
                let l = crate::lef::pin_shapes(&self.lef, cl, "PAD").first().map(|(_, r)| ((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0)).or(cl.loc);
                if let Some(l) = l { m.insert(b.pad.clone(), l); }
            } else if let Some(p) = nl.port_by_name(&b.pad) {
                let t = self.bump_targets(None, Some(&nl.ports[p].name), &HashSet::new());
                if let Some(t) = t.first() { m.insert(b.pad.clone(), t.2); }
            }
        }
        m
    }

    fn c_opt_bumps(&mut self, a: &[String]) -> R {
        let x = args(a, &["-iterations", "-crossing_weight"]);
        let iters = x.get("-iterations").and_then(|s| s.parse::<usize>().ok()).unwrap_or(10);
        if self.fp.as_ref().map(|f| !f.bumps.iter().any(|b| b.kind == "signal")).unwrap_or(true) {
            return err("optimize_bump_assignment: no signal bumps (assign_bumps) (BUMP-020)");
        }
        let tloc = self.target_locs();
        let pitch = {
            let fp = self.fp.as_ref().unwrap();
            let mut d: Vec<f64> = fp.bumps.windows(2).map(|w| (w[1].x - w[0].x).abs()).filter(|d| *d > 1e-6).collect();
            d.sort_by(|a, b| a.partial_cmp(b).unwrap());
            d.first().copied().unwrap_or(100.0)
        };
        let w = x.num("-crossing_weight").unwrap_or(pitch);
        let (c0, cr0) = self.bump_cost(&tloc, w);
        let swap_sup = x.has("-swap_supplies");
        let mut swaps = 0;
        let mut it = 0;
        for _ in 0..iters {
            it += 1;
            let mut improved = false;
            let n = self.fp.as_ref().unwrap().bumps.len();
            for i in 0..n {
                for j in i + 1..n {
                    let (ki, kj) = { let b = &self.fp.as_ref().unwrap().bumps; (b[i].kind.clone(), b[j].kind.clone()) };
                    let ok = (ki == "signal" && kj == "signal") || (swap_sup && ((ki == "signal") != (kj == "signal")) && ki != "unassigned" && kj != "unassigned");
                    if !ok { continue; }
                    // local delta: only flylines of i and j and their crossings change
                    let before = self.bump_cost(&tloc, w).0;
                    self.swap_bump_assign(i, j);
                    let after = self.bump_cost(&tloc, w).0;
                    if after < before - 1e-6 {
                        swaps += 1;
                        improved = true;
                    } else {
                        self.swap_bump_assign(i, j);
                    }
                }
            }
            if !improved { break; }
        }
        let (c1, cr1) = self.bump_cost(&tloc, w);
        crate::info!("BUMP-120", "Bump re-optimization: {} swap(s) in {} pass(es); flyline crossings {} -> {}, cost {:.1} -> {:.1} (length + {:.0} um/crossing)",
            swaps, it, cr0, cr1, c0, c1, w);
        Ok(swaps.to_string())
    }

    fn swap_bump_assign(&mut self, i: usize, j: usize) {
        let b = &mut self.fp.as_mut().unwrap().bumps;
        let (n, k, p) = (b[i].net.clone(), b[i].kind.clone(), b[i].pad.clone());
        b[i].net = b[j].net.clone(); b[i].kind = b[j].kind.clone(); b[i].pad = b[j].pad.clone();
        b[j].net = n; b[j].kind = k; b[j].pad = p;
    }

    fn c_route_rdl(&mut self, a: &[String]) -> R {
        let x = args(a, &["-layer", "-width", "-spacing", "-nets"]);
        let layer = x.get("-layer").cloned().unwrap_or("AP".into());
        let wd = x.num("-width").unwrap_or(5.0);
        let sp = x.num("-spacing").unwrap_or(5.0);
        let allow45 = x.has("-allow_45") || x.has("-allow_45degree_routing");
        let nets: Vec<String> = x.get("-nets").map(|s| split_list(s)).unwrap_or_default();
        let tloc = self.target_locs();
        let fp = self.fp.as_mut().ok_or_else(|| Flow::Err("route_rdl: no floorplan (FP-001)".into()))?;
        let sig: Vec<Bump> = fp.bumps.iter().filter(|b| b.kind == "signal" && (nets.is_empty() || nets.iter().any(|q| glob(q, &b.net)))).cloned().collect();
        if sig.is_empty() {
            return err("route_rdl: no assigned signal bumps (BUMP-030)");
        }
        let bsz = self.lef.get(&sig[0].cell).map(|m| m.w).unwrap_or(40.0);
        fp.special.retain(|s| !(s.kind == "rdl" && sig.iter().any(|b| b.net == s.net)));
        let mut routes: Vec<(String, Vec<(f64, f64)>)> = fp.special.iter().filter(|s| s.kind == "rdl").map(|s| (s.net.clone(), s.pts.clone())).collect();
        // short nets first: they have the fewest alternatives
        let mut order: Vec<&Bump> = sig.iter().filter(|b| tloc.contains_key(&b.pad)).collect();
        order.sort_by(|a, b| dist((a.x, a.y), tloc[&a.pad]).partial_cmp(&dist((b.x, b.y), tloc[&b.pad])).unwrap());
        let clear = wd + sp;
        // bump grid (pitch, origin) for channel routing
        let grid = {
            let mut xs: Vec<f64> = fp.bumps.iter().map(|b| b.x).collect();
            let mut ys: Vec<f64> = fp.bumps.iter().map(|b| b.y).collect();
            xs.sort_by(|a, b| a.partial_cmp(b).unwrap());
            ys.sort_by(|a, b| a.partial_cmp(b).unwrap());
            let step = |v: &Vec<f64>| v.windows(2).map(|w| w[1] - w[0]).filter(|d| *d > 1e-3).fold(f64::MAX, f64::min);
            let (px, py) = (step(&xs), step(&ys));
            if px < f64::MAX && py < f64::MAX { Some((px, py, xs[0], ys[0])) } else { None }
        };
        let (mut total, mut manh, mut viol, mut n) = (0.0, 0.0, 0usize, 0usize);
        let mut diag = 0usize;
        for b in order {
            let s = (b.x, b.y);
            let t = tloc[&b.pad];
            let mut cand: Vec<Vec<(f64, f64)>> = rdl_paths(s, t, allow45).to_vec();
            // channel routes: leave the bump towards a channel corner, run along the channels
            // between bump rows / columns (at a few track offsets), then drop to the target
            if let Some((px, py, ox, oy)) = grid {
                let chx = |v: f64| ox + px / 2.0 + ((v - ox - px / 2.0) / px).round() * px;
                let chy = |v: f64| oy + py / 2.0 + ((v - oy - py / 2.0) / py).round() * py;
                let room = ((px.min(py) - bsz) / 2.0 - wd / 2.0 - sp).max(0.0);
                let offs: Vec<f64> = [0.0, -0.5, 0.5, -1.0, 1.0].iter().map(|k| k * (wd + sp)).filter(|o| o.abs() <= room + 1e-9).collect();
                for sx in [-1.0, 1.0] {
                    for sy in [-1.0, 1.0] {
                        for o in &offs {
                            let c = (s.0 + sx * (px / 2.0 + o), s.1 + sy * (py / 2.0 + o));
                            let lead: Vec<(f64, f64)> = if allow45 { vec![s, c] } else { vec![s, (c.0, s.1), c] };
                            let (tx, ty) = (chx(t.0) + o, chy(t.1) + o);
                            let mut a = lead.clone();
                            a.extend([(tx, c.1), (tx, t.1), t]);
                            let mut b2 = lead.clone();
                            b2.extend([(c.0, ty), (t.0, ty), t]);
                            cand.push(a);
                            cand.push(b2);
                        }
                    }
                }
            }
            for c in cand.iter_mut() {
                c.dedup_by(|a, b| (a.0 - b.0).abs() < 1e-9 && (a.1 - b.1).abs() < 1e-9);
            }
            // conflicts: other bumps the path passes over, existing RDL wires closer than width+spacing
            let conflicts = |p: &Vec<(f64, f64)>| -> usize {
                let mut k = 0;
                for o in fp.bumps.iter().filter(|o| o.name != b.name) {
                    if p.windows(2).any(|w| seg_pt(w[0], w[1], (o.x, o.y)) < bsz / 2.0 + wd / 2.0 + sp - 1e-6) { k += 1; }
                }
                for (nn, q) in &routes {
                    if *nn == b.net { continue; }
                    if p.windows(2).any(|w| q.windows(2).any(|v| seg_seg(w[0], w[1], v[0], v[1]) < clear - 1e-6)) { k += 1; }
                }
                k
            };
            let (pick, cmin) = cand.iter().enumerate().map(|(i, p)| (i, conflicts(p), path_len(p)))
                .min_by(|a, b| (a.1, a.2).partial_cmp(&(b.1, b.2)).unwrap()).map(|(i, c, _)| (i, c)).unwrap();
            let p = cand[pick].clone();
            viol += cmin;
            total += path_len(&p);
            manh += dist(s, t);
            if allow45 && p.windows(2).any(|w| (w[1].0 - w[0].0).abs() > 1e-6 && (w[1].1 - w[0].1).abs() > 1e-6) { diag += 1; }
            let mut pp = p.clone();
            pp.dedup_by(|a, b| (a.0 - b.0).abs() < 1e-9 && (a.1 - b.1).abs() < 1e-9);
            fp.special.push(SpecialShape { name: format!("rdl_{}", b.name), net: b.net.clone(), layer: layer.clone(), kind: "rdl".into(), width: wd, pts: pp.clone(), rect: None, ..Default::default() });
            routes.push((b.net.clone(), pp));
            n += 1;
        }
        crate::info!("RDL-100", "Routed {} RDL net(s) on {} ({} um wide, {} um spacing{}): length {:.1} um (Manhattan {:.1} um, {:.1}% saved), {} with 45-degree segments, {} conflict(s)",
            n, layer, wd, sp, if allow45 { ", 45-degree allowed" } else { ", orthogonal" }, total, manh, if manh > 0.0 { 100.0 * (1.0 - total / manh) } else { 0.0 }, diag, viol);
        if viol > 0 {
            crate::warn!("RDL-101", "{} RDL conflict(s) (wires over other bumps or closer than {} um); re-run optimize_bump_assignment or widen the bump pitch", viol, clear);
        }
        Ok(format!("{} {}", n, viol))
    }

    fn c_report_bumps(&mut self, _a: &[String]) -> R {
        let fp = self.fp.as_ref().ok_or_else(|| Flow::Err("no floorplan (FP-001)".into()))?;
        let mut by: HashMap<String, (usize, HashSet<String>)> = HashMap::new();
        for b in &fp.bumps {
            let e = by.entry(b.kind.clone()).or_default();
            e.0 += 1;
            if !b.net.is_empty() { e.1.insert(b.net.clone()); }
        }
        crate::out!("****************************************\nReport : bumps ({} total)\n****************************************", fp.bumps.len());
        let mut ks: Vec<&String> = by.keys().collect();
        ks.sort();
        for k in ks {
            crate::out!("  {:<11} {:>5} bump(s) {:>4} net(s)", k, by[k].0, by[k].1.len());
        }
        // nearest ground bump from every signal bump (current return path)
        let gr: Vec<&Bump> = fp.bumps.iter().filter(|b| b.kind == "ground").collect();
        let worst = fp.bumps.iter().filter(|b| b.kind == "signal").map(|b| gr.iter().map(|g| ((g.x - b.x).powi(2) + (g.y - b.y).powi(2)).sqrt()).fold(f64::MAX, f64::min)).fold(0.0, f64::max);
        let rdl: f64 = fp.special.iter().filter(|s| s.kind == "rdl").map(|s| s.length()).sum();
        crate::out!("  worst signal-to-ground bump distance {:.1} um, RDL length {:.1} um", if worst < f64::MAX { worst } else { 0.0 }, rdl);
        Ok(fp.bumps.len().to_string())
    }

    fn c_write_bumps(&mut self, a: &[String]) -> R {
        let x = args(a, &["-format", "-gds_layer"]);
        let f = x.pos.first().cloned().ok_or_else(|| Flow::Err("write_bumps: file name required (CMD-001)".into()))?;
        let fmt = x.get("-format").cloned().unwrap_or("text".into());
        let fp = self.fp.as_ref().ok_or_else(|| Flow::Err("no floorplan (FP-001)".into()))?;
        let design = self.nl.as_ref().map(|n| n.name.clone()).unwrap_or("top".into());
        match fmt.as_str() {
            "def" => {
                use std::fmt::Write;
                let u = |v: f64| (v * fp.dbu).round() as i64;
                let mut s = format!("VERSION 5.8 ;\nDIVIDERCHAR \"/\" ;\nBUSBITCHARS \"[]\" ;\nDESIGN {} ;\nUNITS DISTANCE MICRONS {} ;\n\nDIEAREA ( {} {} ) ( {} {} ) ;\n\n", design, fp.dbu as i64, u(fp.die.0), u(fp.die.1), u(fp.die.2), u(fp.die.3));
                let _ = writeln!(s, "COMPONENTS {} ;", fp.bumps.len());
                for b in &fp.bumps {
                    let _ = writeln!(s, "  - {} {} + SOURCE DIST + COVER ( {} {} ) N ;", b.name, b.cell, u(b.x), u(b.y));
                }
                let _ = writeln!(s, "END COMPONENTS\n");
                let mut sub = fp.clone();
                sub.special.retain(|s| s.kind == "rdl");
                let sn = crate::phys::special_nets_def(&sub, &[]);
                let _ = writeln!(s, "SPECIALNETS {} ;", sn.len());
                for e in &sn { let _ = writeln!(s, "{}", e); }
                let _ = writeln!(s, "END SPECIALNETS\n\nEND DESIGN");
                std::fs::write(&f, s).map_err(|e| Flow::Err(e.to_string()))?;
            }
            "gds" => {
                let gl: i16 = x.get("-gds_layer").and_then(|s| s.parse().ok()).unwrap_or(74);
                let mut rects = vec![];
                let mut texts = vec![];
                for b in &fp.bumps {
                    let h = self.lef.get(&b.cell).map(|m| m.w / 2.0).unwrap_or(20.0);
                    rects.push((gl, 0i16, (b.x - h, b.y - h, b.x + h, b.y + h)));
                    if !b.net.is_empty() { texts.push((gl, 251i16, (b.x, b.y), b.net.clone())); }
                }
                let paths: Vec<(i16, i16, f64, Vec<(f64, f64)>)> = fp.special.iter().filter(|s| s.kind == "rdl").map(|s| (gl, 0i16, s.width, s.pts.clone())).collect();
                crate::gds::write_shapes(&f, &format!("{}_bumps", design), fp.dbu, fp.die, &rects, &paths, &texts).map_err(|e| Flow::Err(e.to_string()))?;
            }
            _ => {
                let mut s = String::from("# bump cell x y layer kind net pad\n");
                for b in &fp.bumps {
                    s += &format!("{} {} {:.3} {:.3} {} {} {} {}\n", b.name, b.cell, b.x, b.y, b.layer, b.kind, if b.net.is_empty() { "-" } else { &b.net }, if b.pad.is_empty() { "-" } else { &b.pad });
                }
                std::fs::write(&f, s).map_err(|e| Flow::Err(e.to_string()))?;
            }
        }
        crate::info!("BUMP-130", "Wrote {} bump(s) ({}) to '{}'", fp.bumps.len(), fmt, f);
        Ok(String::new())
    }
}
