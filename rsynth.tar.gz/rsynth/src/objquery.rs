//! Object query: properties of an instance, net, port or pin, grouped in tabs.
//! Used by the GUI query panel (layout / schematic clicks) and by `query_objects`.

use crate::netlist::{Dir, Kind, PinRef};
use crate::session::Session;
use crate::tcl::{err, split_list, R};

pub type Tabs = Vec<(String, Vec<(String, String)>)>;

fn f(v: f64) -> String {
    format!("{:.3}", v)
}
fn dir(d: Dir) -> &'static str {
    match d { Dir::In => "input", Dir::Out => "output", Dir::InOut => "inout" }
}

impl Session {
    /// object kind + properties by tab; `kind` "" auto-detects (instance, port, net, pin)
    pub fn query_object(&self, kind: &str, name: &str) -> Option<(String, String, Tabs)> {
        let nl = self.nl.as_ref()?;
        let k = kind.to_lowercase();
        let try_cell = k.is_empty() || k == "cell" || k == "inst" || k == "instance";
        let try_port = k.is_empty() || k == "port";
        let try_net = k.is_empty() || k == "net";
        let try_pin = k.is_empty() || k == "pin";
        if try_cell { if let Some(c) = nl.cell_by_name(name) { if !nl.cell(c).is_hport() { return Some(("instance".into(), name.into(), self.q_cell(c))); } } }
        if try_port { if let Some(p) = nl.port_by_name(name) { return Some(("port".into(), name.into(), self.q_port(p))); } }
        if try_net { if let Some(n) = nl.net_by_name(name) { return Some(("net".into(), name.into(), self.q_net(n))); } }
        if try_pin {
            if let Some((i, p)) = name.rsplit_once('/') {
                if let Some(c) = nl.cell_by_name(i) {
                    if let Some(pi) = nl.cell(c).pin(p) { return Some(("pin".into(), name.into(), self.q_pin(c, pi))); }
                    // LEF-only (PG) pin
                    if let Some(m) = crate::lef::master(nl.cell(c)).and_then(|m| self.lef.get(m)) {
                        if let Some(lp) = m.pins.iter().find(|x| x.name == p) {
                            let net = self.pgx.gconn.iter().rev().find(|g| crate::netlist::glob(&g.pin, p) && crate::netlist::glob(&g.inst, i)).map(|g| g.net.clone()).unwrap_or_else(|| "(unconnected)".into());
                            let mut geo = vec![];
                            for (ly, r) in crate::lef::pin_shapes(&self.lef, nl.cell(c), p) { geo.push((ly, format!("({}, {}) – ({}, {})", f(r.0), f(r.1), f(r.2), f(r.3)))); }
                            return Some(("pin".into(), name.into(), vec![
                                ("General".into(), vec![("Name".into(), name.into()), ("Instance".into(), i.into()), ("Use".into(), lp.usage.clone()), ("Direction".into(), lp.dir.clone()), ("Global net".into(), net)]),
                                ("Geometry".into(), geo),
                            ]));
                        }
                    }
                }
            }
        }
        None
    }

    fn q_cell(&self, c: crate::netlist::CellId) -> Tabs {
        let nl = self.nl.as_ref().unwrap();
        let cl = nl.cell(c);
        let master = crate::lef::master(cl).unwrap_or("").to_string();
        let lc = self.libs.iter().find_map(|l| l.cells.get(&master).map(|x| (l.name.clone(), x)));
        let lm = self.lef.get(&master);
        let kind = match &cl.kind {
            Kind::Gen(o) => format!("generic {:?}", o),
            Kind::BlackBox(_) => if lm.map(|m| m.class.starts_with("BLOCK")).unwrap_or(false) { "macro (block)".into() } else { "black box".into() },
            Kind::Lib(l) => {
                if let Some(pk) = self.phys_kind_of(l) { format!("physical cell ({})", pk) }
                else if lm.map(|m| m.is_pad()).unwrap_or(false) { "IO pad".into() }
                else if lm.map(|m| m.is_corner()).unwrap_or(false) { "IO corner".into() }
                else if lm.map(|m| m.class.starts_with("BLOCK")).unwrap_or(false) { "macro (block)".into() }
                else if lm.map(|m| m.class.starts_with("COVER")).unwrap_or(false) { "cover (bump / bond pad)".into() }
                else if lc.as_ref().map(|x| x.1.seq.is_some()).unwrap_or(false) { "standard cell (sequential)".into() }
                else if lc.as_ref().map(|x| x.1.icg.is_some()).unwrap_or(false) { "standard cell (clock gate)".into() }
                else { "standard cell (combinational)".into() }
            }
        };
        let parent = cl.name.rsplit_once('/').map(|x| x.0.to_string()).unwrap_or_else(|| "(top)".into());
        let mut gen = vec![("Name".into(), cl.name.clone()), ("Type".into(), kind), ("Master".into(), if master.is_empty() { "-".into() } else { master.clone() })];
        if let Some((ln, _)) = &lc { gen.push(("Library".into(), ln.clone())); }
        gen.push(("Hierarchy".into(), parent));
        let mut flags = vec![];
        if cl.dont_touch { flags.push("dont_touch".to_string()); }
        if cl.fixed { flags.push("fixed".into()); }
        for a in &cl.attrs { if !a.starts_with("orient:") { flags.push(a.clone()); } }
        gen.push(("Attributes".into(), if flags.is_empty() { "-".into() } else { flags.join(", ") }));
        // geometry
        let mut geo = vec![];
        let status = if cl.loc.is_none() { "unplaced" } else if cl.fixed { "FIXED" } else { "PLACED" };
        geo.push(("Status".into(), status.into()));
        if let Some((x, y)) = cl.loc {
            geo.push(("Location".into(), format!("({}, {})", f(x), f(y))));
            geo.push(("Orientation".into(), crate::lef::orient_of(cl).to_string()));
        }
        let bbox = crate::lef::cell_rect(&self.lef, cl).or_else(|| {
            let (x, y) = cl.loc?;
            let m = self.lef.get(&master)?;
            Some((x - m.w / 2.0, y - m.h / 2.0, x + m.w / 2.0, y + m.h / 2.0))
        });
        if let Some(r) = bbox {
            geo.push(("Bounding box".into(), format!("({}, {}) – ({}, {})", f(r.0), f(r.1), f(r.2), f(r.3))));
            geo.push(("Width × height".into(), format!("{} × {} um", f(r.2 - r.0), f(r.3 - r.1))));
        }
        if let Some(m) = lm {
            geo.push(("LEF class".into(), m.class.clone()));
            if !m.site.is_empty() { geo.push(("Site".into(), m.site.clone())); }
            geo.push(("LEF size".into(), format!("{} × {} um", f(m.w), f(m.h))));
        }
        if let Some((_, x)) = &lc { geo.push(("Area".into(), format!("{} um²", f(x.area)))); }
        // pins / connectivity
        let mut pins = vec![];
        for p in &cl.pins {
            let n = p.net.map(|n| nl.net(n).name.clone()).unwrap_or_else(|| "(unconnected)".into());
            pins.push((format!("{} ({})", p.name, dir(p.dir)), n));
        }
        if let Some(m) = lm {
            for lp in m.pins.iter().filter(|p| p.usage == "POWER" || p.usage == "GROUND") {
                let net = self.pgx.gconn.iter().rev().find(|g| crate::netlist::glob(&g.pin, &lp.name) && crate::netlist::glob(&g.inst, &cl.name)).map(|g| g.net.clone()).unwrap_or_else(|| "(no global connect)".into());
                pins.push((format!("{} ({})", lp.name, lp.usage.to_lowercase()), net));
            }
        }
        let mut tabs: Tabs = vec![("General".into(), gen), ("Geometry".into(), geo), ("Pins".into(), pins)];
        if let Some((_, x)) = &lc {
            let mut lib = vec![("Area".into(), format!("{} um²", f(x.area))), ("Leakage".into(), format!("{:.4} (lib units)", x.leakage))];
            if !x.vt.is_empty() { lib.push(("Vt class".into(), x.vt.clone())); }
            if x.drive > 0.0 { lib.push(("Drive".into(), format!("{}", x.drive))); }
            if !x.footprint.is_empty() { lib.push(("Footprint".into(), x.footprint.clone())); }
            lib.push(("dont_use".into(), x.dont_use.to_string()));
            for p in &x.pins {
                let mut v = vec![];
                if p.cap > 0.0 { v.push(format!("cap {:.4} pF", p.cap)); }
                if let Some(fu) = &p.function { v.push(format!("= {}", fu)); }
                if p.is_clock { v.push("clock".into()); }
                if !p.arcs.is_empty() { v.push(format!("{} arc(s)", p.arcs.len())); }
                lib.push((format!("pin {}", p.name), v.join(" · ")));
            }
            tabs.push(("Library".into(), lib));
        }
        tabs
    }

    fn q_net(&self, n: crate::netlist::NetId) -> Tabs {
        let nl = self.nl.as_ref().unwrap();
        let net = nl.net(n);
        let mut drv = vec![];
        let mut lds = vec![];
        for r in &net.conns {
            let (s, out) = match r {
                PinRef::Cell(c, i) => { let cl = nl.cell(*c); (format!("{}/{}", cl.name, cl.pins[*i].name), cl.pins[*i].dir == Dir::Out) }
                PinRef::Port(p) => (format!("port {}", nl.ports[*p].name), nl.ports[*p].dir != Dir::Out),
            };
            if out { drv.push(s) } else { lds.push(s) }
        }
        let rn = self.routes.as_ref().and_then(|db| db.nets.get(&n).map(|r| (db, r)));
        let clock = rn.map(|x| x.1.clock).unwrap_or(false) || net.name.to_lowercase().contains("clk");
        let ty = if self.pg_nets().contains(&net.name) { "power / ground" } else if clock { "clock" } else { "signal" };
        let ndr = self.ndr_of(&net.name, clock).map(|r| r.name.clone()).unwrap_or_else(|| "(default)".into());
        let gen = vec![("Name".into(), net.name.clone()), ("Type".into(), ty.into()), ("Driver".into(), if drv.is_empty() { "(none)".into() } else { drv.join(", ") }),
            ("Fanout".into(), lds.len().to_string()), ("Route rule (NDR)".into(), ndr), ("dont_touch".into(), net.dont_touch.to_string())];
        let mut rt = vec![];
        match rn {
            Some((db, r)) => {
                let (mut wl, mut vias) = (0.0, 0usize);
                let mut layers: std::collections::BTreeMap<String, f64> = Default::default();
                for (c, p) in &r.tree {
                    if *p == crate::droute::NONE { continue; }
                    let (x1, y1, l1) = db.pos(*c);
                    let (x2, y2, l2) = db.pos(*p);
                    if l1 != l2 { vias += 1; continue; }
                    let d = (x1 - x2).abs() + (y1 - y2).abs();
                    wl += d;
                    *layers.entry(db.layers[l1].name.clone()).or_default() += d;
                }
                rt.push(("Routed".into(), if r.open { "yes (open)".into() } else { "yes".into() }));
                rt.push(("Wirelength".into(), format!("{} um", f(wl))));
                rt.push(("Vias".into(), vias.to_string()));
                for (l, d) in layers { rt.push((format!("on {}", l), format!("{} um", f(d)))); }
            }
            None => rt.push(("Routed".into(), "no".into())),
        }
        let sp: Vec<_> = self.fp.as_ref().map(|fp| fp.special.iter().filter(|s| s.net == net.name).collect()).unwrap_or_default();
        if !sp.is_empty() {
            let mut by: std::collections::BTreeMap<String, usize> = Default::default();
            for s in &sp { *by.entry(s.kind.clone()).or_default() += 1; }
            rt.push(("Special shapes".into(), by.iter().map(|(k, v)| format!("{} {}", v, k)).collect::<Vec<_>>().join(", ")));
        }
        let mk = self.pgx.markers.iter().filter(|m| m.nets.contains(&net.name)).count();
        if mk > 0 { rt.push(("Markers".into(), mk.to_string())); }
        let mut con: Vec<(String, String)> = drv.iter().map(|d| ("driver".to_string(), d.clone())).collect();
        con.extend(lds.iter().take(500).map(|d| ("load".to_string(), d.clone())));
        vec![("General".into(), gen), ("Routing".into(), rt), ("Connections".into(), con)]
    }

    fn q_port(&self, p: usize) -> Tabs {
        let nl = self.nl.as_ref().unwrap();
        let pt = &nl.ports[p];
        let net = pt.net.map(|n| nl.net(n).name.clone()).unwrap_or_else(|| "(unconnected)".into());
        let mut gen = vec![("Name".into(), pt.name.clone()), ("Direction".into(), dir(pt.dir).into()), ("Net".into(), net)];
        if let Some(n) = pt.net {
            let pads: Vec<String> = nl.net(n).conns.iter().filter_map(|r| match r { PinRef::Cell(c, i) if nl.cell(*c).pins[*i].name == "PAD" => Some(nl.cell(*c).name.clone()), _ => None }).collect();
            if !pads.is_empty() { gen.push(("Pad".into(), pads.join(", "))); }
        }
        let mut geo = vec![];
        if let Some(fp) = &self.fp {
            if let Some((x, y)) = pt.loc { geo.push(("Location".into(), format!("({}, {})", f(x), f(y)))); }
            if let Some((sd, ly, src)) = fp.pin_info.get(&pt.name) {
                geo.push(("Side".into(), sd.clone()));
                geo.push(("Layer".into(), ly.clone()));
                geo.push(("Placed by".into(), src.clone()));
            }
        }
        if geo.is_empty() { geo.push(("Location".into(), "(not placed)".into())); }
        vec![("General".into(), gen), ("Geometry".into(), geo)]
    }

    fn q_pin(&self, c: crate::netlist::CellId, i: usize) -> Tabs {
        let nl = self.nl.as_ref().unwrap();
        let cl = nl.cell(c);
        let p = &cl.pins[i];
        let net = p.net.map(|n| nl.net(n).name.clone()).unwrap_or_else(|| "(unconnected)".into());
        let mut gen = vec![("Name".into(), format!("{}/{}", cl.name, p.name)), ("Direction".into(), dir(p.dir).into()), ("Net".into(), net)];
        let master = crate::lef::master(cl).unwrap_or("");
        if let Some(lp) = self.libs.iter().find_map(|l| l.cells.get(master)).and_then(|x| x.pins.iter().find(|q| q.name == p.name)) {
            if lp.cap > 0.0 { gen.push(("Capacitance".into(), format!("{:.4} pF", lp.cap))); }
            if let Some(fu) = &lp.function { gen.push(("Function".into(), fu.clone())); }
            if lp.is_clock { gen.push(("Clock pin".into(), "yes".into())); }
            if let Some(m) = lp.max_cap { gen.push(("max_capacitance".into(), format!("{:.4} pF", m))); }
        }
        let mut geo = vec![];
        for (ly, r) in crate::lef::pin_shapes(&self.lef, cl, &p.name) { geo.push((ly, format!("({}, {}) – ({}, {})", f(r.0), f(r.1), f(r.2), f(r.3)))); }
        if geo.is_empty() { geo.push(("Shapes".into(), "(no LEF geometry)".into())); }
        vec![("General".into(), gen), ("Geometry".into(), geo)]
    }

    pub fn objquery_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        match name {
            "query_objects" | "query_object" | "gui_query_object" | "dbQuery" => {
                let x = crate::session::args(a, &["-name", "-type"]);
                let names: Vec<String> = x.get("-name").map(|v| split_list(v)).unwrap_or_else(|| x.pos.clone());
                if names.is_empty() { return Some(err("query_objects: -name object(s) required (QRY-001)")); }
                let kind = x.get("-type").cloned().unwrap_or_default();
                let mut found = 0;
                for n0 in names {
                    let n = crate::cons::Obj::parse(&n0).map(|o| o.name().to_string()).unwrap_or(n0);
                    match self.query_object(&kind, &n) {
                        Some((k, nm, tabs)) => {
                            found += 1;
                            crate::out!("{} {}", k, nm);
                            for (t, rows) in &tabs {
                                crate::out!("  [{}]", t);
                                for (a, b) in rows { crate::out!("    {:<20} {}", a, b); }
                            }
                            if x.has("-gui") || name == "gui_query_object" { self.gui.query = Some((k, nm)); }
                        }
                        None => crate::warn!("QRY-002", "query_objects: no instance, port, net or pin named '{}'", n),
                    }
                }
                Some(Ok(found.to_string()))
            }
            "gui_add_ruler" | "add_ruler" | "measure_distance" => {
                let x = crate::session::args(a, &["-from", "-to", "-points"]);
                let pt = |k: &str| -> Option<(f64, f64)> { let v: Vec<f64> = x.get(k)?.split(|c: char| c.is_whitespace() || c == '{' || c == '}' || c == ',').filter_map(|s| s.parse().ok()).collect(); if v.len() >= 2 { Some((v[0], v[1])) } else { None } };
                let (Some(p0), Some(p1)) = (pt("-from"), pt("-to")) else { return Some(err(&format!("{}: -from {{x y}} -to {{x y}} required (QRY-010)", name))) };
                let (dx, dy) = (p1.0 - p0.0, p1.1 - p0.1);
                let d = (dx * dx + dy * dy).sqrt();
                let ang = dy.atan2(dx).to_degrees();
                crate::info!("QRY-011", "Distance ({}, {}) – ({}, {}): {:.4} um (dx {:.4}, dy {:.4}, Manhattan {:.4}, angle {:.2} deg)", f(p0.0), f(p0.1), f(p1.0), f(p1.1), d, dx, dy, dx.abs() + dy.abs(), ang);
                if name != "measure_distance" { self.gui.rulers.push((p0.0, p0.1, p1.0, p1.1)); }
                Some(Ok(format!("{:.4}", d)))
            }
            "gui_clear_rulers" | "clear_rulers" => {
                let n = self.gui.rulers.len();
                self.gui.rulers.clear();
                crate::info!("QRY-012", "Removed {} ruler(s)", n);
                Some(Ok(n.to_string()))
            }
            "report_rulers" => {
                for (i, r) in self.gui.rulers.iter().enumerate() {
                    let (dx, dy) = (r.2 - r.0, r.3 - r.1);
                    crate::out!("ruler {:>3}  ({}, {}) – ({}, {})  {:.4} um  dx {:.4}  dy {:.4}  {:.2} deg", i + 1, f(r.0), f(r.1), f(r.2), f(r.3), (dx * dx + dy * dy).sqrt(), dx, dy, dy.atan2(dx).to_degrees());
                }
                Some(Ok(self.gui.rulers.len().to_string()))
            }
            _ => None,
        }
    }
}
