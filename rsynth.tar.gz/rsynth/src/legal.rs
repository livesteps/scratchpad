//! Placement legalization (rows/sites) and detailed placement.
//!
//! * Sites: rows of height `row_h` over the core, site width `site_w`; hard / hard-macro placement
//!   blockages and fixed cells (macros) remove sites.
//! * Every movable standard cell gets width = ceil(area / row_h / site_w) sites.
//! * Hard and exclusive bounds confine their members; exclusive bounds also keep other cells out.
//! * Legalization: cells in order of x, each placed at the free site run with minimum displacement
//!   (searching neighbouring rows outward), honouring its region.
//! * Detailed placement: per cell, move toward the median of its connected pins if free sites
//!   exist there; swap with same-width cells when HPWL improves. Never breaks legality.

use crate::fplan::*;
use crate::netlist::*;
use std::collections::HashMap;

#[derive(Clone, Debug)]
pub struct Rows {
    pub x0: f64,
    pub y0: f64,
    pub site_w: f64,
    pub row_h: f64,
    pub nsites: usize,
    pub nrows: usize,
    /// owner per (row, site): u32::MAX = free, u32::MAX-1 = blocked, else cell id
    pub occ: Vec<u32>,
    /// region per (row, site): 0 = none, k+1 = hard/exclusive bound k
    pub region: Vec<u16>,
    /// site belongs to an exclusive bound (non-members may not use it)
    pub excl: Vec<bool>,
    /// site under a soft placement blockage (used only when nothing else fits)
    pub soft: Vec<bool>,
    /// allow soft-blockage sites (fallback pass)
    pub allow_soft: bool,
}

pub const FREE: u32 = u32::MAX;
pub const BLOCKED: u32 = u32::MAX - 1;

#[derive(Default, Debug, Clone)]
pub struct LegalStats {
    pub cells: usize,
    pub moved: usize,
    pub avg_disp: f64,
    pub max_disp: f64,
    pub failed: Vec<String>,
    pub hpwl_before: f64,
    pub hpwl_after: f64,
}

impl Rows {
    pub fn idx(&self, r: usize, s: usize) -> usize {
        r * self.nsites + s
    }
    pub fn site_x(&self, s: usize) -> f64 {
        self.x0 + s as f64 * self.site_w
    }
    pub fn row_y(&self, r: usize) -> f64 {
        self.y0 + r as f64 * self.row_h
    }
    fn mark_rect(&mut self, r: &Rect, v: u32) {
        let s0 = (((r.0 - self.x0) / self.site_w).floor().max(0.0)) as usize;
        let s1 = (((r.2 - self.x0) / self.site_w).ceil().max(0.0) as usize).min(self.nsites);
        let r0 = (((r.1 - self.y0) / self.row_h).floor().max(0.0)) as usize;
        let r1 = (((r.3 - self.y0) / self.row_h).ceil().max(0.0) as usize).min(self.nrows);
        for row in r0..r1 {
            for s in s0..s1 {
                let i = self.idx(row, s);
                self.occ[i] = v;
            }
        }
    }
}

pub struct LegalCtx<'a> {
    pub die: Rect,
    pub row_h: f64,
    pub site_w: f64,
    pub pblk: &'a [PBlockage],
    pub bounds: &'a [Bound],
    /// cell area (um^2) and whether it is a macro (fixed obstacle)
    pub area: &'a dyn Fn(&Cell) -> f64,
    pub macro_size: f64,
    /// placed footprint of cells with a LEF abstract (lower-left placement)
    pub rect_of: &'a dyn Fn(&Cell) -> Option<Rect>,
    /// explicit rows (create_row / cut_row): sites outside every row are blocked
    pub rows: Option<&'a [crate::phys::RowRec]>,
}

fn width_sites(area: f64, row_h: f64, site_w: f64) -> usize {
    // tolerance: 2.66 / 1.3999999999999773 / 0.19 must stay 10 sites, not 11
    ((area / row_h / site_w - 1e-6).ceil() as usize).max(1)
}

/// Build the site grid and mark obstacles. Returns rows plus the movable cell list with widths.
pub fn build_rows(nl: &Netlist, cx: &LegalCtx) -> (Rows, Vec<(CellId, usize, Option<usize>)>) {
    let core = (cx.die.0 + cx.row_h, cx.die.1 + cx.row_h, cx.die.2 - cx.row_h, cx.die.3 - cx.row_h);
    let nsites = ((core.2 - core.0) / cx.site_w).floor().max(1.0) as usize;
    let nrows = ((core.3 - core.1) / cx.row_h).floor().max(1.0) as usize;
    let mut rows = Rows { x0: core.0, y0: core.1, site_w: cx.site_w, row_h: cx.row_h, nsites, nrows, occ: vec![FREE; nsites * nrows], region: vec![0; nsites * nrows], excl: vec![false; nsites * nrows], soft: vec![false; nsites * nrows], allow_soft: false };
    if let Some(rl) = cx.rows {
        let mut cov = vec![false; nsites * nrows];
        let eps = 1e-6;
        for r in rl {
            let ri = ((r.y - rows.y0) / rows.row_h).round();
            if ri < 0.0 || ri as usize >= nrows || ((r.y - rows.y0) / rows.row_h - ri).abs() > 0.01 { continue; }
            let s0 = (((r.x - rows.x0) / rows.site_w) - eps).ceil().max(0.0) as usize;
            let s1 = ((((r.x1() - rows.x0) / rows.site_w) + eps).floor().max(0.0) as usize).min(nsites);
            for sx in s0..s1 { cov[ri as usize * nsites + sx] = true; }
        }
        for (i, c) in cov.iter().enumerate() { if !c { rows.occ[i] = BLOCKED; } }
    }
    for b in cx.pblk {
        if matches!(b.kind, PbKind::Hard | PbKind::HardMacro) {
            rows.mark_rect(&b.rect, BLOCKED);
        } else if matches!(b.kind, PbKind::Soft) {
            let r = b.rect;
            let s0 = (((r.0 - rows.x0) / rows.site_w).floor().max(0.0)) as usize;
            let s1 = (((r.2 - rows.x0) / rows.site_w).ceil().max(0.0) as usize).min(nsites);
            let r0 = (((r.1 - rows.y0) / rows.row_h).floor().max(0.0)) as usize;
            let r1 = (((r.3 - rows.y0) / rows.row_h).ceil().max(0.0) as usize).min(nrows);
            for row in r0..r1 {
                for s in s0..s1 {
                    let i = rows.idx(row, s);
                    rows.soft[i] = true;
                }
            }
        }
    }
    // regions: hard / exclusive bounds
    for (k, b) in cx.bounds.iter().enumerate() {
        if matches!(b.kind, BoundKind::Hard | BoundKind::Exclusive) {
            if let Some(r) = b.resolved.or(b.rect) {
                let s0 = (((r.0 - rows.x0) / rows.site_w).ceil().max(0.0)) as usize;
                let s1 = (((r.2 - rows.x0) / rows.site_w).floor().max(0.0) as usize).min(nsites);
                let r0 = (((r.1 - rows.y0) / rows.row_h).ceil().max(0.0)) as usize;
                let r1 = (((r.3 - rows.y0) / rows.row_h).floor().max(0.0) as usize).min(nrows);
                for row in r0..r1 {
                    for s in s0..s1 {
                        let i = rows.idx(row, s);
                        rows.region[i] = (k + 1) as u16;
                    }
                }
                // non-members keep out of every site whose origin lies in the exclusive region
                // (inclusive edges, the same rule check_placement applies to cell origins)
                if matches!(b.kind, BoundKind::Exclusive) {
                    let eps = 1e-9;
                    let e0 = (((r.0 - rows.x0) / rows.site_w - eps).ceil().max(0.0)) as usize;
                    let e1 = ((((r.2 - rows.x0) / rows.site_w + eps).floor().max(0.0)) as usize + 1).min(nsites);
                    let q0 = (((r.1 - rows.y0) / rows.row_h - eps).ceil().max(0.0)) as usize;
                    let q1 = ((((r.3 - rows.y0) / rows.row_h + eps).floor().max(0.0)) as usize + 1).min(nrows);
                    for row in q0..q1 {
                        for s in e0..e1 {
                            let i = rows.idx(row, s);
                            rows.excl[i] = true;
                        }
                    }
                }
            }
        }
    }
    let mut movable = vec![];
    for c in nl.cell_ids() {
        let cl = nl.cell(c);
        if cl.is_hport() || matches!(cl.kind, Kind::Gen(_)) {
            continue;
        }
        let a = (cx.area)(cl);
        if cl.fixed || matches!(cl.kind, Kind::BlackBox(_)) {
            // fixed obstacle (macro): square of its area, or the default macro size
            if let Some(r) = (cx.rect_of)(cl) {
                rows.mark_rect(&r, BLOCKED);
            } else if let (Some(l), true) = (cl.loc, matches!(cl.kind, Kind::Lib(_)) && a <= 8.0 * cx.row_h * cx.row_h) {
                // fixed standard cell (spare / gate-array cell): its own sites in its row
                let w = width_sites(a, cx.row_h, cx.site_w) as f64 * cx.site_w;
                let e = 1e-3;
                rows.mark_rect(&(l.0 - w / 2.0 + e, l.1 - cx.row_h / 2.0 + e, l.0 + w / 2.0 - e, l.1 + cx.row_h / 2.0 - e), BLOCKED);
            } else if let Some(l) = cl.loc {
                let side = if a > 4.0 { a.sqrt() } else { cx.macro_size };
                rows.mark_rect(&(l.0 - side / 2.0, l.1 - side / 2.0, l.0 + side / 2.0, l.1 + side / 2.0), BLOCKED);
            }
            continue;
        }
        let w = width_sites(a, cx.row_h, cx.site_w);
        movable.push((c, w, bound_of(cx.bounds, &cl.name).filter(|&b| matches!(cx.bounds[b].kind, BoundKind::Hard | BoundKind::Exclusive))));
    }
    (rows, movable)
}

/// can `w` sites starting at (r, s) take a cell of region `reg`?
fn fits(rows: &Rows, r: usize, s: usize, w: usize, reg: u16, me: u32) -> bool {
    if s + w > rows.nsites {
        return false;
    }
    for k in s..s + w {
        let i = rows.idx(r, k);
        let o = rows.occ[i];
        if o != FREE && o != me {
            return false;
        }
        if rows.soft[i] && !rows.allow_soft {
            return false;
        }
        let rg = rows.region[i];
        // members of a hard/exclusive bound must stay inside it; others stay out of exclusive ones
        if reg != 0 && rg != reg {
            return false;
        }
        if reg == 0 && rows.excl[i] {
            return false;
        }
    }
    true
}

fn occupy(rows: &mut Rows, r: usize, s: usize, w: usize, v: u32) {
    for k in s..s + w {
        let i = rows.idx(r, k);
        rows.occ[i] = v;
    }
}

/// nearest legal spot to (x, y) for a cell of width w and region reg (search outward by rows)
fn find_spot(rows: &Rows, x: f64, y: f64, w: usize, reg: u16, me: u32, max_rows: usize) -> Option<(usize, usize, f64)> {
    let tr = (((y - rows.y0) / rows.row_h - 0.5).round().max(0.0) as usize).min(rows.nrows - 1);
    let ts = (((x - rows.x0) / rows.site_w - w as f64 / 2.0).round().max(0.0) as usize).min(rows.nsites.saturating_sub(w));
    let mut best: Option<(usize, usize, f64)> = None;
    for dr in 0..=max_rows.min(rows.nrows) {
        let dy = dr as f64 * rows.row_h;
        if let Some(b) = best {
            if dy > b.2 {
                break;
            }
        }
        for r in [tr as i64 - dr as i64, tr as i64 + dr as i64] {
            if r < 0 || r as usize >= rows.nrows || (dr == 0 && r != tr as i64) {
                continue;
            }
            let r = r as usize;
            let cy = rows.row_y(r) + rows.row_h / 2.0;
            // scan outward from the target site
            let lim = rows.nsites;
            for ds in 0..lim {
                let dx = ds as f64 * rows.site_w;
                let cost = dx + (cy - y).abs();
                if let Some(b) = best {
                    if cost >= b.2 {
                        break;
                    }
                }
                let mut hit = None;
                for s in [ts as i64 - ds as i64, ts as i64 + ds as i64] {
                    if s < 0 || (ds == 0 && s != ts as i64) {
                        continue;
                    }
                    if fits(rows, r, s as usize, w, reg, me) {
                        hit = Some(s as usize);
                        break;
                    }
                }
                if let Some(s) = hit {
                    let sx = rows.site_x(s) + w as f64 * rows.site_w / 2.0;
                    let c = (sx - x).abs() + (cy - y).abs();
                    if best.map(|b| c < b.2).unwrap_or(true) {
                        best = Some((r, s, c));
                    }
                    break;
                }
            }
        }
    }
    best
}

pub fn hpwl(nl: &Netlist) -> f64 {
    let mut t = 0.0;
    for n in nl.net_ids() {
        let locs: Vec<(f64, f64)> = nl.net(n).conns.iter().filter_map(|p| nl.pin_loc(*p)).collect();
        if locs.len() < 2 {
            continue;
        }
        let (x0, x1) = locs.iter().fold((f64::MAX, f64::MIN), |a, p| (a.0.min(p.0), a.1.max(p.0)));
        let (y0, y1) = locs.iter().fold((f64::MAX, f64::MIN), |a, p| (a.0.min(p.1), a.1.max(p.1)));
        t += (x1 - x0) + (y1 - y0);
    }
    t
}

/// Legalize all movable cells (or only `only` when given: ECO mode keeps others in place).
pub fn legalize(nl: &mut Netlist, cx: &LegalCtx, only: Option<&[CellId]>) -> (LegalStats, Rows) {
    let (mut rows, movable) = build_rows(nl, cx);
    let mut st = LegalStats { hpwl_before: hpwl(nl), ..Default::default() };
    let widx: HashMap<CellId, (usize, Option<usize>)> = movable.iter().map(|(c, w, b)| (*c, (*w, *b))).collect();
    let eco: Option<std::collections::HashSet<CellId>> = only.map(|v| v.iter().copied().collect());
    // ECO mode: keep already-legal cells where they are
    let mut todo: Vec<CellId> = vec![];
    for (c, w, b) in &movable {
        let reg = b.map(|x| (x + 1) as u16).unwrap_or(0);
        let keep = match &eco {
            Some(set) if !set.contains(c) => {
                if let Some(l) = nl.cell(*c).loc {
                    let s = ((l.0 - rows.x0) / rows.site_w - *w as f64 / 2.0).round();
                    let r = ((l.1 - rows.y0) / rows.row_h - 0.5).round();
                    rows.allow_soft = true;
                    let ok = s >= 0.0 && r >= 0.0 && (r as usize) < rows.nrows && fits(&rows, r as usize, s as usize, *w, reg, FREE);
                    rows.allow_soft = false;
                    if ok {
                        occupy(&mut rows, r as usize, s as usize, *w, *c as u32);
                        true
                    } else {
                        false
                    }
                } else {
                    false
                }
            }
            _ => false,
        };
        if !keep {
            todo.push(*c);
        }
    }
    // larger cells first within similar x, then by x (Tetris order)
    todo.sort_by(|a, b| {
        let la = nl.cell(*a).loc.unwrap_or((0.0, 0.0));
        let lb = nl.cell(*b).loc.unwrap_or((0.0, 0.0));
        widx[b].0.cmp(&widx[a].0).then(la.0.partial_cmp(&lb.0).unwrap_or(std::cmp::Ordering::Equal))
    });
    let mut tot = 0.0;
    for c in todo {
        let (w, b) = widx[&c];
        let reg = b.map(|x| (x + 1) as u16).unwrap_or(0);
        let want = nl.cell(c).loc.unwrap_or(((cx.die.0 + cx.die.2) / 2.0, (cx.die.1 + cx.die.3) / 2.0));
        let mut spot = find_spot(&rows, want.0, want.1, w, reg, c as u32, 12).or_else(|| find_spot(&rows, want.0, want.1, w, reg, c as u32, rows.nrows));
        if spot.is_none() {
            // last resort: soft placement blockages
            rows.allow_soft = true;
            spot = find_spot(&rows, want.0, want.1, w, reg, c as u32, rows.nrows);
            rows.allow_soft = false;
        }
        match spot {
            Some((r, s, d)) => {
                occupy(&mut rows, r, s, w, c as u32);
                let nx = rows.site_x(s) + w as f64 * rows.site_w / 2.0;
                let ny = rows.row_y(r) + rows.row_h / 2.0;
                nl.cell_mut(c).loc = Some((nx, ny));
                st.cells += 1;
                if d > 1e-6 {
                    st.moved += 1;
                }
                tot += d;
                st.max_disp = st.max_disp.max(d);
            }
            None => st.failed.push(nl.cell(c).name.clone()),
        }
    }
    st.avg_disp = if st.cells > 0 { tot / st.cells as f64 } else { 0.0 };
    st.hpwl_after = hpwl(nl);
    (st, rows)
}

fn cell_nets_hpwl(nl: &Netlist, c: CellId) -> f64 {
    let mut t = 0.0;
    for p in &nl.cell(c).pins {
        let Some(n) = p.net else { continue };
        let locs: Vec<(f64, f64)> = nl.net(n).conns.iter().filter_map(|q| nl.pin_loc(*q)).collect();
        if locs.len() < 2 || locs.len() > 64 {
            continue;
        }
        let (x0, x1) = locs.iter().fold((f64::MAX, f64::MIN), |a, p| (a.0.min(p.0), a.1.max(p.0)));
        let (y0, y1) = locs.iter().fold((f64::MAX, f64::MIN), |a, p| (a.0.min(p.1), a.1.max(p.1)));
        t += (x1 - x0) + (y1 - y0);
    }
    t
}

/// Detailed placement on a legal placement: median moves into free sites and same-width swaps.
pub fn detail_place(nl: &mut Netlist, cx: &LegalCtx, rows: &mut Rows, passes: usize) -> (usize, usize, f64, f64) {
    let before = hpwl(nl);
    let (_, movable) = build_rows(nl, cx);
    let info: HashMap<CellId, (usize, u16)> = movable.iter().map(|(c, w, b)| (*c, (*w, b.map(|x| (x + 1) as u16).unwrap_or(0)))).collect();
    let site_of = |rows: &Rows, l: (f64, f64), w: usize| -> (usize, usize) {
        let s = ((l.0 - rows.x0) / rows.site_w - w as f64 / 2.0).round().max(0.0) as usize;
        let r = ((l.1 - rows.y0) / rows.row_h - 0.5).round().max(0.0) as usize;
        (r.min(rows.nrows - 1), s)
    };
    let (mut moves, mut swaps) = (0, 0);
    let cells: Vec<CellId> = movable.iter().map(|x| x.0).collect();
    for _ in 0..passes {
        let mut changed = 0;
        for &c in &cells {
            if !nl.cell_alive(c) || nl.cell(c).dont_touch {
                continue;
            }
            let Some(l) = nl.cell(c).loc else { continue };
            let (w, reg) = info[&c];
            // median of the other pins on this cell's nets
            let mut xs = vec![];
            let mut ys = vec![];
            for p in &nl.cell(c).pins {
                let Some(n) = p.net else { continue };
                if nl.net(n).conns.len() > 32 {
                    continue;
                }
                for q in &nl.net(n).conns {
                    if matches!(q, PinRef::Cell(d, _) if *d == c) {
                        continue;
                    }
                    if let Some(pl) = nl.pin_loc(*q) {
                        xs.push(pl.0);
                        ys.push(pl.1);
                    }
                }
            }
            if xs.is_empty() {
                continue;
            }
            xs.sort_by(|a, b| a.partial_cmp(b).unwrap());
            ys.sort_by(|a, b| a.partial_cmp(b).unwrap());
            let tgt = (xs[xs.len() / 2], ys[ys.len() / 2]);
            if (tgt.0 - l.0).abs() + (tgt.1 - l.1).abs() < rows.site_w * 2.0 {
                continue;
            }
            let old_cost = cell_nets_hpwl(nl, c);
            let (r0, s0) = site_of(rows, l, w);
            // try a free spot near the target
            occupy(rows, r0, s0, w, FREE);
            let mut done = false;
            if let Some((r, s, _)) = find_spot(rows, tgt.0, tgt.1, w, reg, c as u32, 3) {
                let nl_loc = (rows.site_x(s) + w as f64 * rows.site_w / 2.0, rows.row_y(r) + rows.row_h / 2.0);
                nl.cell_mut(c).loc = Some(nl_loc);
                if cell_nets_hpwl(nl, c) + 1e-9 < old_cost {
                    occupy(rows, r, s, w, c as u32);
                    moves += 1;
                    changed += 1;
                    done = true;
                } else {
                    nl.cell_mut(c).loc = Some(l);
                }
            }
            if !done {
                occupy(rows, r0, s0, w, c as u32);
                // swap with a same-width cell sitting near the target
                let (tr, ts) = site_of(rows, tgt, w);
                let i = rows.idx(tr, ts.min(rows.nsites - 1));
                let o = rows.occ[i];
                if o != FREE && o != BLOCKED && o != c as u32 {
                    let d = o as usize;
                    if let (Some(&(wd, rd)), Some(ld)) = (info.get(&d), nl.cell(d).loc) {
                        if wd == w && rd == reg && !nl.cell(d).dont_touch {
                            let before2 = old_cost + cell_nets_hpwl(nl, d);
                            nl.cell_mut(c).loc = Some(ld);
                            nl.cell_mut(d).loc = Some(l);
                            if cell_nets_hpwl(nl, c) + cell_nets_hpwl(nl, d) + 1e-9 < before2 {
                                let (rd0, sd0) = site_of(rows, ld, w);
                                occupy(rows, rd0, sd0, w, c as u32);
                                occupy(rows, r0, s0, w, d as u32);
                                swaps += 1;
                                changed += 1;
                            } else {
                                nl.cell_mut(c).loc = Some(l);
                                nl.cell_mut(d).loc = Some(ld);
                            }
                        }
                    }
                }
            }
        }
        if changed == 0 {
            break;
        }
    }
    (moves, swaps, before, hpwl(nl))
}

/// Legality check: overlaps, off-row/off-site, blocked sites, region violations.
pub fn check(nl: &Netlist, cx: &LegalCtx) -> (usize, Vec<String>) {
    let (mut rows, movable) = build_rows(nl, cx);
    rows.allow_soft = true;
    let mut viol = vec![];
    for (c, w, b) in &movable {
        let cl = nl.cell(*c);
        let Some(l) = cl.loc else {
            viol.push(format!("{}: unplaced", cl.name));
            continue;
        };
        let sf = (l.0 - rows.x0) / rows.site_w - *w as f64 / 2.0;
        let rf = (l.1 - rows.y0) / rows.row_h - 0.5;
        if (sf - sf.round()).abs() > 1e-3 || (rf - rf.round()).abs() > 1e-3 || sf < -1e-3 || rf < -1e-3 || rf.round() as usize >= rows.nrows || sf.round() as usize + w > rows.nsites {
            viol.push(format!("{}: not on a row/site grid ({:.3}, {:.3})", cl.name, l.0, l.1));
            continue;
        }
        let (r, s) = (rf.round() as usize, sf.round() as usize);
        let reg = b.map(|x| (x + 1) as u16).unwrap_or(0);
        for k in s..s + w {
            let i = rows.idx(r, k);
            match rows.occ[i] {
                FREE => rows.occ[i] = *c as u32,
                BLOCKED => {
                    viol.push(format!("{}: on a blocked site (blockage / macro)", cl.name));
                    break;
                }
                o => {
                    viol.push(format!("{}: overlaps {}", cl.name, nl.cell(o as usize).name));
                    break;
                }
            }
            if (reg != 0 && rows.region[i] != reg) || (reg == 0 && rows.excl[i]) {
                viol.push(format!("{}: {}", cl.name, if reg != 0 { "outside its bound" } else { "inside an exclusive/hard bound it is not a member of" }));
                break;
            }
        }
    }
    (movable.len(), viol)
}
