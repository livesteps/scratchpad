//! LEF-driven routing rules and routing post-processing.
//!
//! * Layer rules come from the technology LEF: PITCH / OFFSET (or DEF TRACKS), WIDTH, MINWIDTH,
//!   MAXWIDTH, SPACING / SPACING RANGE / SPACINGTABLE PARALLELRUNLENGTH, AREA, RPERSQ /
//!   CPERSQDIST / EDGECAPACITANCE, MINIMUMDENSITY / MAXIMUMDENSITY / DENSITYCHECKWINDOW /
//!   DENSITYCHECKSTEP / FILLACTIVESPACING. Without a tech LEF the built-in routing layers are used
//!   (width = spacing = pitch / 2).
//! * The detailed router wires only on the tracks of each layer (M2 and up; M1 is pin access),
//!   adds minimum-area patches, writes via types, and `check_route_rules` verifies the routed
//!   database against the rules (tracks, width, spacing, minimum area, cut spacing, fill spacing).
//! * Metal fill (`add_metal_fill`) fills each density window to the LEF / OPC target, keeps
//!   FILLACTIVESPACING from routing, PG, pins and obstructions, never exceeds the maximum
//!   density, and is trimmed when routing changes later. `report_metal_density` checks the
//!   stepped LEF windows.
//! * OPC / litho rules (`-opc file` on route_auto / route_detail / route_opt / add_metal_fill, `read_opc_rules`): fill shape sizes and spacing per layer,
//!   density targets, assist fill next to isolated lines, line-end extension, forbidden pitches
//!   and wrong-way restriction for litho-driven routing; `check_litho` reports them.
//! * Yield (`route_opt -yield`): wire spreading first (nets rerouted with a cost for wires on the
//!   neighbouring tracks, kept only if opens, shorts and spacing violations do not increase), then
//!   single-cut to double-cut via swapping where the second cut has room (no new spacing DRC).

use crate::droute::{RouteDb, NONE};
use crate::netlist::*;
use crate::session::{args, Session};
use crate::tcl::{err, split_list, R};
use std::collections::{BTreeMap, HashMap, HashSet};

pub type Rect = (f64, f64, f64, f64);

/// routing rule of one routing layer (router layer order)
#[derive(Clone, Debug, Default)]
pub struct LRule {
    pub name: String,
    pub horiz: bool,
    pub pitch: f64,
    /// first track position (absolute, along the cross direction)
    pub start: f64,
    pub width: f64,
    pub min_width: f64,
    pub max_width: f64,
    pub area: f64,
    pub lef: crate::lef::LefLayer,
    pub min_density: f64,
    pub max_density: f64,
    pub window: (f64, f64),
    pub step: f64,
    pub fill_active: f64,
    /// "LEF" or "built-in"
    pub source: &'static str,
    /// explicit DEF tracks
    pub tracks: bool,
}
impl LRule {
    pub fn spacing(&self, w1: f64, w2: f64, prl: f64) -> f64 {
        let s = self.lef.spacing_for(w1, w2, prl);
        if s > 0.0 { s } else { (self.pitch - self.width).max(self.width) }
    }
}

/// OPC / litho fill and routing rules of one layer
#[derive(Clone, Debug)]
pub struct OpcLayer {
    pub fill_width: f64,
    pub fill_length: f64,
    pub fill_spacing: f64,
    pub active_spacing: f64,
    pub min_density: f64,
    pub max_density: f64,
    pub target_density: f64,
    pub window: f64,
    pub step: f64,
    /// parallel wire pitches to avoid (centre distance ranges)
    pub forbidden_pitch: Vec<(f64, f64)>,
    pub line_end_extension: f64,
    /// a wire with no neighbour within this distance is isolated: assist fill next to it
    pub isolated_space: f64,
    /// allow wrong-way wiring on this layer in litho-driven routing
    pub wrong_way: bool,
}
impl Default for OpcLayer {
    fn default() -> Self {
        OpcLayer { fill_width: 0.0, fill_length: 0.0, fill_spacing: 0.0, active_spacing: 0.0, min_density: -1.0, max_density: -1.0, target_density: -1.0, window: 0.0, step: 0.0, forbidden_pitch: vec![], line_end_extension: 0.0, isolated_space: 0.0, wrong_way: true }
    }
}
#[derive(Clone, Debug, Default)]
pub struct OpcRules {
    pub file: String,
    pub default: OpcLayer,
    pub layers: BTreeMap<String, OpcLayer>,
}
impl OpcRules {
    pub fn layer(&self, n: &str) -> OpcLayer {
        self.layers.get(n).cloned().unwrap_or_else(|| self.default.clone())
    }
    /// `default|layer NAME key value key value ...` lines; # comments
    pub fn parse(text: &str, file: &str) -> Result<OpcRules, String> {
        let mut r = OpcRules { file: file.to_string(), ..Default::default() };
        for (ln, line) in text.lines().enumerate() {
            let line = line.split('#').next().unwrap_or("").trim();
            if line.is_empty() { continue; }
            let t: Vec<&str> = line.split_whitespace().collect();
            let (mut l, mut i) = match t[0] {
                "default" => (r.default.clone(), 1),
                "layer" if t.len() > 1 => (r.layers.get(t[1]).cloned().unwrap_or_else(|| r.default.clone()), 2),
                k => return Err(format!("{}:{}: expected 'default' or 'layer <name>', found '{}'", file, ln + 1, k)),
            };
            while i < t.len() {
                let k = t[i];
                let v = t.get(i + 1).copied().ok_or_else(|| format!("{}:{}: '{}' has no value", file, ln + 1, k))?;
                let f = || v.parse::<f64>().map_err(|_| format!("{}:{}: '{}' is not a number for '{}'", file, ln + 1, v, k));
                match k {
                    "fill_width" => l.fill_width = f()?,
                    "fill_length" => l.fill_length = f()?,
                    "fill_spacing" => l.fill_spacing = f()?,
                    "active_spacing" | "fill_active_spacing" => l.active_spacing = f()?,
                    "min_density" => l.min_density = pct(f()?),
                    "max_density" => l.max_density = pct(f()?),
                    "target_density" | "density" => l.target_density = pct(f()?),
                    "window" => l.window = f()?,
                    "step" => l.step = f()?,
                    "line_end_extension" | "line_end_ext" => l.line_end_extension = f()?,
                    "isolated_space" | "assist_space" => l.isolated_space = f()?,
                    "wrong_way" => l.wrong_way = matches!(v, "on" | "true" | "1" | "yes"),
                    "forbidden_pitch" => {
                        for rg in v.split(',') {
                            let (a, b) = rg.split_once(':').unwrap_or((rg, rg));
                            let a: f64 = a.parse().map_err(|_| format!("{}:{}: bad forbidden_pitch '{}'", file, ln + 1, rg))?;
                            let b: f64 = b.parse().map_err(|_| format!("{}:{}: bad forbidden_pitch '{}'", file, ln + 1, rg))?;
                            l.forbidden_pitch.push((a.min(b), a.max(b)));
                        }
                    }
                    _ => return Err(format!("{}:{}: unknown OPC rule '{}'", file, ln + 1, k)),
                }
                i += 2;
            }
            if t[0] == "default" { r.default = l; } else { r.layers.insert(t[1].to_string(), l); }
        }
        Ok(r)
    }
}
fn pct(v: f64) -> f64 { if v > 1.0 { v / 100.0 } else { v } }

/// rectangles bucketed for overlap queries
pub struct RGrid {
    b: f64,
    cells: HashMap<(i64, i64), Vec<usize>>,
    pub r: Vec<(Rect, u32)>,
}
impl RGrid {
    pub fn new(b: f64) -> Self { RGrid { b: b.max(0.5), cells: HashMap::new(), r: vec![] } }
    pub fn add(&mut self, r: Rect, tag: u32) {
        let k = self.r.len();
        self.r.push((r, tag));
        for i in (r.0 / self.b).floor() as i64..=(r.2 / self.b).floor() as i64 {
            for j in (r.1 / self.b).floor() as i64..=(r.3 / self.b).floor() as i64 {
                self.cells.entry((i, j)).or_default().push(k);
            }
        }
    }
    /// indices of rectangles overlapping `q` (strictly)
    pub fn query(&self, q: Rect) -> Vec<usize> {
        let mut out = vec![];
        let mut seen = HashSet::new();
        for i in (q.0 / self.b).floor() as i64..=(q.2 / self.b).floor() as i64 {
            for j in (q.1 / self.b).floor() as i64..=(q.3 / self.b).floor() as i64 {
                if let Some(v) = self.cells.get(&(i, j)) {
                    for &k in v {
                        let r = self.r[k].0;
                        if r.0 < q.2 - 1e-9 && r.2 > q.0 + 1e-9 && r.1 < q.3 - 1e-9 && r.3 > q.1 + 1e-9 && seen.insert(k) { out.push(k); }
                    }
                }
            }
        }
        out
    }
    pub fn hits(&self, q: Rect) -> bool { !self.query(q).is_empty() }
}

/// merge the per-grid-edge wire rectangles of each net into maximal straight segments
/// (via landings inside a segment are absorbed)
pub(crate) fn merge_wires(wr: Vec<Vec<(NetId, Rect)>>) -> Vec<Vec<(NetId, Rect)>> {
    let k = |v: f64| (v * 1e4).round() as i64;
    wr.into_iter().map(|rects| {
        let mut by: HashMap<NetId, Vec<Rect>> = HashMap::new();
        for (n, r) in rects { by.entry(n).or_default().push(r); }
        let mut ids: Vec<NetId> = by.keys().copied().collect();
        ids.sort();
        let mut out = vec![];
        for n in ids {
            let rs = &by[&n];
            let mut hg: BTreeMap<(i64, i64), Vec<Rect>> = BTreeMap::new();
            let mut vg: BTreeMap<(i64, i64), Vec<Rect>> = BTreeMap::new();
            for r in rs {
                if r.2 - r.0 + 1e-9 >= r.3 - r.1 { hg.entry((k(r.1), k(r.3))).or_default().push(*r); } else { vg.entry((k(r.0), k(r.2))).or_default().push(*r); }
            }
            let merge = |g: BTreeMap<(i64, i64), Vec<Rect>>, horiz: bool| -> Vec<Rect> {
                let mut res = vec![];
                for (_, mut v) in g {
                    if horiz { v.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap()); } else { v.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap()); }
                    let mut cur = v[0];
                    for r in v.into_iter().skip(1) {
                        let touch = if horiz { r.0 <= cur.2 + 1e-9 } else { r.1 <= cur.3 + 1e-9 };
                        if touch { cur = (cur.0.min(r.0), cur.1.min(r.1), cur.2.max(r.2), cur.3.max(r.3)); } else { res.push(cur); cur = r; }
                    }
                    res.push(cur);
                }
                res
            };
            let h = merge(hg, true);
            let v = merge(vg, false);
            let inside = |a: &Rect, b: &Rect| a.0 >= b.0 - 1e-9 && a.1 >= b.1 - 1e-9 && a.2 <= b.2 + 1e-9 && a.3 <= b.3 + 1e-9;
            for r in &h {
                let sq = ((r.2 - r.0) - (r.3 - r.1)).abs() < 1e-9;
                if sq && v.iter().any(|q| inside(r, q)) { continue; }
                out.push((n, *r));
            }
            for r in v { out.push((n, r)); }
        }
        out
    }).collect()
}

/// metal coverage raster of one layer (union area, no double counting of overlaps)
pub(crate) struct Cover { x0: f64, y0: f64, res: f64, nx: usize, ny: usize, bits: Vec<bool> }
impl Cover {
    pub fn new(die: Rect, res: f64) -> Self {
        let nx = ((die.2 - die.0) / res).ceil() as usize + 1;
        let ny = ((die.3 - die.1) / res).ceil() as usize + 1;
        Cover { x0: die.0, y0: die.1, res, nx, ny, bits: vec![false; nx * ny] }
    }
    fn span(&self, r: Rect) -> (usize, usize, usize, usize) {
        let c = |v: f64, o: f64, n: usize| (((v - o) / self.res).round().max(0.0) as usize).min(n);
        (c(r.0, self.x0, self.nx), c(r.1, self.y0, self.ny), c(r.2, self.x0, self.nx), c(r.3, self.y0, self.ny))
    }
    pub fn add(&mut self, r: Rect) {
        let (a, b, c, d) = self.span(r);
        for y in b..d { for x in a..c { self.bits[y * self.nx + x] = true; } }
    }
    pub fn area(&self, r: Rect) -> f64 {
        let (a, b, c, d) = self.span(r);
        let mut n = 0usize;
        for y in b..d { n += self.bits[y * self.nx + a..y * self.nx + c].iter().filter(|q| **q).count(); }
        n as f64 * self.res * self.res
    }
}

/// nets of `pick` left open by a reroute get their route from `save` back when its nodes are
/// still free (and clear of other nets by the LEF spacing); returns how many were restored
pub(crate) fn restore_open_nets(db: &mut RouteDb, save: &RouteDb, pick: &HashSet<NetId>) -> usize {
    let mut kept = 0;
    let mut owner = node_owner(db);
    let mut open_ids: Vec<NetId> = db.nets.iter().filter(|(n, r)| r.open && pick.contains(n)).map(|(n, _)| *n).collect();
    open_ids.sort();
    for n in open_ids {
        let Some(old) = save.nets.get(&n).cloned() else { continue };
        if old.open { continue; }
        let cur = db.nets[&n].clone();
        for (nd, _) in &cur.tree { let o = &mut db.occ[*nd as usize]; *o = o.saturating_sub(1); owner.remove(nd); }
        let free = old.tree.iter().all(|(nd, _)| db.occ[*nd as usize] == 0 && space_ok(db, &owner, *nd, n));
        if free {
            for (nd, _) in &old.tree { db.occ[*nd as usize] += 1; owner.insert(*nd, n); }
            for (nd, _) in &old.tree { if let Some(p) = save.patches.get(nd) { db.patches.insert(*nd, *p); } }
            db.nets.insert(n, old);
            kept += 1;
        } else {
            for (nd, _) in &cur.tree { db.occ[*nd as usize] += 1; owner.insert(*nd, n); }
        }
    }
    kept
}

/// owner of every routed node
pub(crate) fn node_owner(db: &RouteDb) -> HashMap<u32, NetId> {
    let mut m = HashMap::new();
    let mut ids: Vec<&NetId> = db.nets.keys().collect();
    ids.sort();
    for id in ids { for (nd, _) in &db.nets[id].tree { m.insert(*nd, *id); } }
    m
}
/// a node may take metal of `id` without coming within the layer's LEF spacing of another net
pub(crate) fn space_ok(db: &RouteDb, owner: &HashMap<u32, NetId>, nd: u32, id: NetId) -> bool {
    let (x, y, l) = db.xyl(nd);
    let k = db.space_k.get(l).copied().unwrap_or(0) as i64;
    for ex in -k..=k {
        for ey in -k..=k {
            let (ax, ay) = (x as i64 + ex, y as i64 + ey);
            if ax < 0 || ay < 0 || ax as usize >= db.nx || ay as usize >= db.ny { continue; }
            if let Some(o) = owner.get(&db.node(ax as usize, ay as usize, l)) { if *o != id { return false; } }
        }
    }
    true
}
fn grow(r: Rect, d: f64) -> Rect { (r.0 - d, r.1 - d, r.2 + d, r.3 + d) }
fn inter(a: Rect, b: Rect) -> f64 {
    let w = a.2.min(b.2) - a.0.max(b.0);
    let h = a.3.min(b.3) - a.1.max(b.1);
    if w > 1e-6 && h > 1e-6 { w * h } else { 0.0 }
}

#[derive(Clone, Debug, Default)]
pub struct RuleCheck {
    pub off_track: usize,
    pub spacing: usize,
    pub shorts: usize,
    pub min_area: usize,
    pub width: usize,
    pub cut_spacing: usize,
    pub fill: usize,
    pub wires: usize,
}
impl RuleCheck {
    pub fn total(&self) -> usize { self.off_track + self.spacing + self.shorts + self.min_area + self.width + self.cut_spacing + self.fill }
}

impl Session {
    /// routing rules per router layer (LEF when the tech LEF defines the layer)
    pub(crate) fn layer_rules(&self) -> Vec<LRule> {
        let ls = self.fp.as_ref().map(|f| f.layers.clone()).unwrap_or_else(crate::fplan::default_layers);
        let die = self.fp.as_ref().map(|f| f.die).unwrap_or((0.0, 0.0, 0.0, 0.0));
        ls.iter().map(|l| {
            let lef = self.lef_layers.iter().find(|q| q.name == l.name && q.kind.eq_ignore_ascii_case("ROUTING")).cloned();
            let src = if lef.is_some() { "LEF" } else { "built-in" };
            let lef = lef.unwrap_or_default();
            let pitch = if lef.pitch > 0.0 { lef.pitch } else { l.pitch };
            let width = if lef.width > 0.0 { lef.width } else { pitch / 2.0 };
            let tr = self.fp.as_ref().and_then(|f| f.track_list.iter().find(|t| t.layer == l.name && ((t.dir == 'Y') == l.horiz)).cloned());
            let start = match &tr {
                Some(t) => t.start,
                None => (if l.horiz { die.1 } else { die.0 }) + lef.offset.unwrap_or(pitch / 2.0),
            };
            let pitch = tr.as_ref().map(|t| t.step).filter(|s| *s > 0.0).unwrap_or(pitch);
            let win = if lef.density_window.0 > 0.0 { lef.density_window } else { (50.0, 50.0) };
            LRule {
                name: l.name.clone(), horiz: l.horiz, pitch, start, width,
                min_width: if lef.min_width > 0.0 { lef.min_width } else { width },
                max_width: lef.max_width, area: lef.area,
                min_density: lef.min_density, max_density: if lef.max_density > 0.0 { lef.max_density } else { 0.0 },
                window: win, step: if lef.density_step > 0.0 { lef.density_step } else { win.0 / 2.0 },
                fill_active: if lef.fill_active_spacing > 0.0 { lef.fill_active_spacing } else { 0.0 },
                lef, source: src, tracks: tr.is_some(),
            }
        }).collect()
    }

    /// LEF rule mode (route.detail.honor_tracks auto): the tech LEF defines routing rules beyond
    /// a plain layer stack (OFFSET, AREA, SPACINGTABLE / RANGE, MINWIDTH, density, fill or antenna
    /// rules), or the design has explicit tracks
    pub(crate) fn lef_rule_mode(&self) -> bool {
        let explicit = self.fp.as_ref().map(|f| !f.track_list.is_empty()).unwrap_or(false);
        explicit || self.lef_layers.iter().any(|l| l.kind.eq_ignore_ascii_case("ROUTING") && (l.offset.is_some() || l.area > 0.0 || !l.sp_table.is_empty() || !l.sp_range.is_empty() || l.min_width > 0.0 || l.min_density > 0.0 || l.max_density > 0.0 || l.fill_active_spacing > 0.0 || l.ant_ratio > 0.0))
    }

    /// wire R / C per um from the LEF (RPERSQ / width, CPERSQDIST * width + 2 EDGECAPACITANCE)
    pub(crate) fn lef_rc(&self, name: &str) -> Option<(f64, f64)> {
        let l = self.lef_layers.iter().find(|q| q.name == name)?;
        let w = if l.width > 0.0 { l.width } else { return None };
        let r = if l.rpersq > 0.0 { Some(l.rpersq / w / 1000.0) } else { None };
        let c = if l.cpersq > 0.0 || l.edgecap > 0.0 { Some(l.cpersq * w + 2.0 * l.edgecap) } else { None };
        match (r, c) {
            (None, None) => None,
            (r, c) => Some((r.unwrap_or(-1.0), c.unwrap_or(-1.0))),
        }
    }

    /// mark the grid lines between the tracks of each layer above M1 (no wiring along them)
    pub(crate) fn apply_tracks(&self, db: &mut RouteDb) {
        let rules = self.layer_rules();
        db.tstep = vec![1; db.layers.len()];
        let mode = self.app.get("route.detail.honor_tracks").cloned().unwrap_or_else(|| "auto".into());
        if mode == "false" || mode == "0" { return; }
        if mode == "auto" && !self.lef_rule_mode() {
            for (li, r) in rules.iter().enumerate() { if li < db.tstep.len() && r.pitch > 0.0 { db.tstep[li] = ((r.pitch / db.g).round() as usize).max(1); } }
            return;
        }
        let n = db.occ.len();
        let mut off = vec![false; n];
        let mut any = false;
        let plane = db.nx * db.ny;
        for (li, r) in rules.iter().enumerate().skip(1) {
            if li >= db.layers.len() || r.pitch <= 0.0 { continue; }
            let st = (r.pitch / db.g).round() as usize;
            db.tstep[li] = st.max(1);
            // only layers with tech-LEF rules (built-in layers keep the free routing grid)
            if st <= 1 || r.source != "LEF" { continue; }
            let (cnt, org) = if r.horiz { (db.ny, db.y0) } else { (db.nx, db.x0) };
            for k in 0..cnt {
                let pos = org + k as f64 * db.g;
                let t = ((pos - r.start) / r.pitch).round();
                let on = ((r.start + t * r.pitch) - pos).abs() <= db.g * 0.26;
                if on { continue; }
                any = true;
                if r.horiz {
                    for x in 0..db.nx { let nd = li * plane + k * db.nx + x; off[nd] = true; }
                } else {
                    for y in 0..db.ny { let nd = li * plane + y * db.nx + k; off[nd] = true; }
                }
            }
        }
        if any {
            db.offtrack = off;
        }
        // LEF spacing in grid steps (wires of other nets closer than this are negotiated away)
        let honor_sp = !self.app.get("route.detail.honor_spacing").map(|v| v == "false" || v == "0").unwrap_or(false);
        db.space_k = rules.iter().enumerate().map(|(li, r)| {
            if !honor_sp { return 0; }
            if li == 0 || li >= db.layers.len() || r.source != "LEF" { return 0; }
            let need = r.spacing(r.width, r.width, r.pitch * 4.0) + r.width;
            (((need / db.g) - 1e-6).ceil() as usize).saturating_sub(1).min(3)
        }).collect();
        let nl = rules.iter().enumerate().filter(|(i, r)| *i > 0 && r.source == "LEF").count();
        if nl > 0 { crate::info!("RT-110", "LEF rule routing: wiring on tracks and LEF spacing on {} layer(s){}", nl, if mode == "auto" { " (route.detail.honor_tracks auto: tech LEF rules / explicit tracks)" } else { "" }); }
    }

    /// minimum-area patches: same-layer metal pieces smaller than LEF AREA are extended along the
    /// preferred direction onto free grid nodes (stubs of the net's tree)
    pub(crate) fn fix_min_area(&self, db: &mut RouteDb) -> (usize, usize) {
        let (f, bad) = self.fix_min_area_nets(db);
        (f, bad.len())
    }
    /// minimum-area patches; returns (pieces fixed, (net, piece) pieces without room)
    pub(crate) fn fix_min_area_nets(&self, db: &mut RouteDb) -> (usize, Vec<(NetId, Vec<u32>)>) {
        self.fix_min_area_for(db, None)
    }
    /// minimum-area patches for all nets or one net
    pub(crate) fn fix_min_area_for(&self, db: &mut RouteDb, only: Option<NetId>) -> (usize, Vec<(NetId, Vec<u32>)>) {
        let rules = self.layer_rules();
        if rules.iter().all(|r| r.area <= 0.0) { return (0, vec![]); }
        let (mut fixed, mut failed) = (0, vec![]);
        let mut owner = node_owner(db);
        let ids: Vec<NetId> = match only { Some(n) => if db.nets.contains_key(&n) { vec![n] } else { vec![] }, None => { let mut v: Vec<NetId> = db.nets.keys().copied().collect(); v.sort(); v } };
        for id in ids {
            let rn = db.nets[&id].clone();
            let wm = rn.wmul.max(1.0) as f64;
            // components of same-layer edges
            let mut parent: HashMap<u32, u32> = HashMap::new();
            fn find(p: &mut HashMap<u32, u32>, x: u32) -> u32 {
                let mut r = x;
                while let Some(&q) = p.get(&r) { if q == r { break; } r = q; }
                let mut y = x;
                while let Some(&q) = p.get(&y) { if q == r { break; } p.insert(y, r); y = q; }
                r
            }
            for &(nd, _) in &rn.tree { parent.insert(nd, nd); }
            for &(nd, par) in &rn.tree {
                if par == NONE { continue; }
                if db.xyl(nd).2 == db.xyl(par).2 {
                    let (a, b) = (find(&mut parent, nd), find(&mut parent, par));
                    if a != b { parent.insert(a, b); }
                }
            }
            let mut comp: HashMap<u32, Vec<u32>> = HashMap::new();
            for &(nd, _) in &rn.tree { let r = find(&mut parent, nd); comp.entry(r).or_default().push(nd); }
            let mut add: Vec<(u32, u32)> = vec![];
            // pieces in a fixed order (deterministic patches)
            let mut comp: Vec<Vec<u32>> = comp.into_values().map(|mut v| { v.sort_unstable(); v }).collect();
            comp.sort();
            for nodes in comp {
                let l = db.xyl(nodes[0]).2;
                if l == 0 { continue; }
                let Some(r) = rules.get(l) else { continue };
                if r.area <= 0.0 { continue; }
                let w = r.width * wm;
                let len = (nodes.len().saturating_sub(1)) as f64 * db.g;
                let area = (len + w) * w;
                if area + 1e-9 >= r.area { continue; }
                let need = ((r.area / w - w - len) / db.g).ceil().max(1.0) as usize;
                // extend along the preferred direction: from one end, or from both ends of the piece
                let mut cands: Vec<Vec<(u32, u32)>> = vec![];
                for &end in &nodes {
                    let (x, y, _) = db.xyl(end);
                    for dirn in [1i64, -1] {
                        let mut chain = vec![];
                        let mut prev = end;
                        for k in 1..=(need + nodes.len()) as i64 {
                            let (nx, ny) = if r.horiz { (x as i64 + dirn * k, y as i64) } else { (x as i64, y as i64 + dirn * k) };
                            if nx < 0 || ny < 0 || nx as usize >= db.nx || ny as usize >= db.ny { break; }
                            let nd = db.node(nx as usize, ny as usize, l);
                            let i = nd as usize;
                            if nodes.contains(&nd) { if chain.is_empty() { prev = nd; continue; } else { break; } }
                            if db.blocked[i] || db.occ[i] > 0 || (db.pin_owner[i] != NONE && db.pin_owner[i] != id as u32) || !space_ok(db, &owner, nd, id) { break; }
                            if !db.offtrack.is_empty() && db.offtrack[i] != db.offtrack[end as usize] { break; }
                            chain.push((nd, prev));
                            prev = nd;
                            if chain.len() >= need { break; }
                        }
                        if !chain.is_empty() { cands.push(chain); }
                    }
                }
                cands.sort_by(|a, b| b.len().cmp(&a.len()));
                let mut ok = false;
                if let Some(c) = cands.iter().find(|c| c.len() >= need) {
                    add.extend(c.iter().copied());
                    ok = true;
                } else {
                    'pair: for i in 0..cands.len() {
                        for j in i + 1..cands.len() {
                            let si: HashSet<u32> = cands[i].iter().map(|q| q.0).collect();
                            if cands[j].iter().any(|q| si.contains(&q.0)) { continue; }
                            if cands[i].len() + cands[j].len() >= need {
                                let take_j = need - cands[i].len();
                                add.extend(cands[i].iter().copied());
                                add.extend(cands[j].iter().take(take_j).copied());
                                ok = true;
                                break 'pair;
                            }
                        }
                    }
                }
                if ok { fixed += 1; } else { failed.push((id, nodes.clone())); }
            }
            if !add.is_empty() {
                for (nd, _) in &add { owner.insert(*nd, id); }
                let rn = db.nets.get_mut(&id).unwrap();
                for (nd, par) in add {
                    rn.tree.push((nd, par));
                    db.occ[nd as usize] += 1;
                    db.patches.insert(nd, id);
                }
            }
        }
        (fixed, failed)
    }

    /// verify the routed database against the layer rules
    pub(crate) fn route_rule_check(&mut self, markers: bool, verbose: bool) -> Result<RuleCheck, crate::tcl::Flow> {
        let rules = self.layer_rules();
        let names: HashMap<NetId, String> = { let nl = self.nl()?; nl.net_ids().into_iter().map(|n| (n, nl.net(n).name.clone())).collect() };
        let db = self.routes.as_ref().ok_or_else(|| crate::tcl::Flow::Err("check_route_rules: the design is not routed (route_auto) (RT-400)".into()))?;
        let widths: Vec<f64> = rules.iter().map(|r| r.width).collect();
        let wr = merge_wires(db.wire_rects(&widths));
        let mut rc = RuleCheck::default();
        let mut mk: Vec<crate::pg::Marker> = vec![];
        let push = |kind: &str, layer: &str, r: Rect, nets: Vec<String>, msg: String, mk: &mut Vec<crate::pg::Marker>| {
            if markers && mk.len() < 5000 { mk.push(crate::pg::Marker { tool: "route_rules".into(), kind: kind.into(), layer: layer.into(), rect: r, nets, msg }); }
        };
        // off-track wiring (patches and via landings excluded)
        if !db.offtrack.is_empty() {
            for rn in db.nets.values() {
                for &(nd, par) in &rn.tree {
                    if par == NONE || db.patches.contains_key(&nd) { continue; }
                    if db.xyl(nd).2 == db.xyl(par).2 && db.offtrack[nd as usize] && db.offtrack[par as usize] { rc.off_track += 1; }
                }
            }
        }
        for (li, rects) in wr.iter().enumerate() {
            let Some(r) = rules.get(li) else { continue };
            rc.wires += rects.len();
            // width
            for (net, q) in rects {
                let w = (q.2 - q.0).min(q.3 - q.1);
                if w + 1e-9 < r.min_width || (r.max_width > 0.0 && w > r.max_width + 1e-9) {
                    rc.width += 1;
                    push("width", &r.name, *q, vec![names.get(net).cloned().unwrap_or_default()], format!("{} width {:.3} outside [{:.3}, {}]", r.name, w, r.min_width, if r.max_width > 0.0 { format!("{:.3}", r.max_width) } else { "-".into() }), &mut mk);
                }
            }
            if li == 0 { continue; }
            // spacing / shorts between different nets
            let smax = r.spacing(r.width * 3.0, r.width * 3.0, 1e9);
            let mut g = RGrid::new((r.pitch * 8.0).max(1.0));
            for (k, (_, q)) in rects.iter().enumerate() { g.add(*q, k as u32); }
            let mut seen: HashSet<(usize, usize)> = HashSet::new();
            for (k, (net, q)) in rects.iter().enumerate() {
                for j in g.query(grow(*q, smax)) {
                    if j == k { continue; }
                    let (n2, q2) = rects[j];
                    if n2 == *net { continue; }
                    let key = (k.min(j), k.max(j));
                    if !seen.insert(key) { continue; }
                    let ov = inter(*q, q2) > 0.0;
                    let dx = (q2.0 - q.2).max(q.0 - q2.2).max(0.0);
                    let dy = (q2.1 - q.3).max(q.1 - q2.3).max(0.0);
                    let d = dx.max(dy);
                    let prl = if r.horiz { q.2.min(q2.2) - q.0.max(q2.0) } else { q.3.min(q2.3) - q.1.max(q2.1) };
                    let need = r.spacing((q.2 - q.0).min(q.3 - q.1), (q2.2 - q2.0).min(q2.3 - q2.1), prl.max(0.0));
                    let nets = vec![names.get(net).cloned().unwrap_or_default(), names.get(&n2).cloned().unwrap_or_default()];
                    if ov {
                        rc.shorts += 1;
                        push("short", &r.name, (q.0.max(q2.0), q.1.max(q2.1), q.2.min(q2.2), q.3.min(q2.3)), nets, format!("{} short", r.name), &mut mk);
                    } else if d + 1e-6 < need && (dx == 0.0 || dy == 0.0) {
                        rc.spacing += 1;
                        push("spacing", &r.name, (q.0.min(q2.0), q.1.min(q2.1), q.2.max(q2.2), q.3.max(q2.3)), nets, format!("{} spacing {:.3} < {:.3}", r.name, d, need), &mut mk);
                    }
                }
            }
            // minimum area per connected piece
            if r.area > 0.0 {
                let mut by_net: HashMap<NetId, Vec<Rect>> = HashMap::new();
                for (n, q) in rects { by_net.entry(*n).or_default().push(*q); }
                for (n, rs) in by_net {
                    // union of touching rectangles of the net on this layer
                    let mut lab: Vec<usize> = (0..rs.len()).collect();
                    fn f(l: &mut Vec<usize>, x: usize) -> usize { let mut r = x; while l[r] != r { r = l[r]; } let mut y = x; while l[y] != r { let t = l[y]; l[y] = r; y = t; } r }
                    let mut gg = RGrid::new(2.0);
                    for (k, q) in rs.iter().enumerate() { gg.add(grow(*q, 1e-6), k as u32); }
                    for (k, q) in rs.iter().enumerate() { for j in gg.query(grow(*q, 1e-6)) { let (a, b) = (f(&mut lab, k), f(&mut lab, j)); if a != b { lab[a] = b; } } }
                    let mut area: HashMap<usize, (f64, Rect)> = HashMap::new();
                    for (k, q) in rs.iter().enumerate() {
                        let root = f(&mut lab, k);
                        let e = area.entry(root).or_insert((0.0, *q));
                        e.0 += (q.2 - q.0) * (q.3 - q.1);
                        e.1 = (e.1 .0.min(q.0), e.1 .1.min(q.1), e.1 .2.max(q.2), e.1 .3.max(q.3));
                    }
                    for (_, (a, bb)) in area {
                        // overlapping rectangles of one piece: the bounding box bounds the union for straight pieces
                        let a = a.min((bb.2 - bb.0) * (bb.3 - bb.1));
                        if a + 1e-9 < r.area {
                            rc.min_area += 1;
                            push("min_area", &r.name, bb, vec![names.get(&n).cloned().unwrap_or_default()], format!("{} area {:.4} < {:.4}", r.name, a, r.area), &mut mk);
                        }
                    }
                }
            }
        }
        // cut spacing: vias of different nets on the same cut layer too close
        {
            let mut cuts: Vec<HashMap<(usize, usize), NetId>> = vec![HashMap::new(); db.layers.len()];
            for (id, rn) in &db.nets {
                for &(nd, par) in &rn.tree {
                    if par == NONE { continue; }
                    let (x, y, l1) = db.xyl(nd);
                    let l2 = db.xyl(par).2;
                    if l1 == l2 { continue; }
                    cuts[l1.min(l2)].insert((x, y), *id);
                }
            }
            for (lo, m) in cuts.iter().enumerate() {
                // the CUT layer that follows this metal in the LEF stack
                let lower = rules.get(lo).map(|r| r.name.clone()).unwrap_or_default();
                let cut = self.lef_layers.iter().position(|q| q.name == lower).and_then(|i| self.lef_layers[i + 1..].iter().take_while(|q| !q.kind.eq_ignore_ascii_case("ROUTING")).find(|q| q.kind.eq_ignore_ascii_case("CUT")).cloned()).unwrap_or_default();
                let need = cut.spacing + cut.width;
                if need <= 0.0 { continue; }
                let k = (need / db.g).ceil() as i64 - 1;
                if k < 1 { continue; }
                for (&(x, y), n) in m {
                    for dx in -k..=k {
                        for dy in -k..=k {
                            if dx == 0 && dy == 0 { continue; }
                            let p = (x as i64 + dx, y as i64 + dy);
                            if p.0 < 0 || p.1 < 0 { continue; }
                            if let Some(n2) = m.get(&(p.0 as usize, p.1 as usize)) {
                                if n2 != n && ((dx, dy) > (0, 0)) && ((dx as f64 * db.g).hypot(dy as f64 * db.g) + 1e-6 < need) {
                                    rc.cut_spacing += 1;
                                }
                            }
                        }
                    }
                }
            }
        }
        // fill shapes: spacing to active metal of the layer
        if let Some(fp) = self.fp.as_ref() {
            for (li, r) in rules.iter().enumerate() {
                let fills: Vec<Rect> = fp.fills.iter().filter(|f| f.0 == r.name).map(|f| f.1).collect();
                if fills.is_empty() { continue; }
                let act = if r.fill_active > 0.0 { r.fill_active } else { r.spacing(r.width, r.width, 0.0) };
                let mut g = RGrid::new(4.0);
                for (_, q) in wr.get(li).into_iter().flatten() { g.add(*q, 0); }
                for f in fills {
                    if g.hits(grow(f, act - 1e-6)) {
                        rc.fill += 1;
                        push("fill_spacing", &r.name, f, vec![], format!("{} fill closer than {:.3} to routing", r.name, act), &mut mk);
                    }
                }
            }
        }
        if verbose {
            for m in mk.iter().take(30) { crate::out!("    {:<12} {:<4} {}", m.kind, m.layer, m.msg); }
        }
        if markers {
            self.pgx.markers.retain(|m| m.tool != "route_rules");
            self.pgx.markers.extend(mk);
        }
        Ok(rc)
    }

    /// metal shapes of a layer that are not fill: routing, PG, pins, obstructions, blockages
    fn active_shapes(&self, li: usize, r: &LRule, wr: &[Vec<(NetId, Rect)>]) -> Vec<Rect> {
        let mut v: Vec<Rect> = wr.get(li).map(|x| x.iter().map(|q| q.1).collect()).unwrap_or_default();
        let Some(fp) = self.fp.as_ref() else { return v };
        for sh in &fp.special {
            let Some(q) = sh.rect else { continue };
            let on = match &sh.via { Some(va) => va.lower == r.name || va.upper == r.name, None => sh.layer == r.name };
            if on { v.push(q); }
        }
        for b in &fp.rblk {
            if b.layers.is_empty() || b.layers.iter().any(|l| l == &r.name) { v.push(b.rect); }
        }
        if let Some(nl) = self.nl.as_ref() {
            for c in nl.cell_ids() {
                let cl = nl.cell(c);
                let Some(l) = cl.loc else { continue };
                if let (Some(m), Some(rr)) = (crate::lef::phys(&self.lef, cl), crate::lef::cell_rect(&self.lef, cl)) {
                    if m.obs.is_empty() && li < 4 { v.push(rr); }
                    for (ly, o) in &m.obs { if ly == &r.name { v.push(crate::lef::place_rect(*o, m.w, m.h, crate::lef::orient_of(cl), l)); } }
                    for p in &m.pins { for (ly, o) in &p.shapes { if ly == &r.name { v.push(crate::lef::place_rect(*o, m.w, m.h, crate::lef::orient_of(cl), l)); } } }
                } else if li == 0 {
                    // standard cells without an abstract: their M1 is internal
                    if let Some(b) = self.gui_cell_box(cl) { v.push(b); }
                }
            }
            for p in nl.port_ids() {
                if let (Some(l), Some(i)) = (nl.ports[p].loc, fp.pin_info.get(&nl.ports[p].name)) {
                    if i.1 == r.name {
                        let (w, d) = fp.pin_shapes.get(&nl.ports[p].name).copied().unwrap_or((r.width * 2.0, r.width * 2.0));
                        let h = w.max(d) / 2.0;
                        v.push((l.0 - h, l.1 - h, l.0 + h, l.1 + h));
                    }
                }
            }
        }
        v
    }

    /// add fill to every window below its target density; returns (shapes added, per-layer counts)
    pub(crate) fn add_metal_fill(&mut self, layers: &[String], area: Option<Rect>, opc: Option<&OpcRules>, ov: &FillOverrides) -> Result<(usize, Vec<(String, usize, f64, f64)>), crate::tcl::Flow> {
        let rules = self.layer_rules();
        let die = self.fp.as_ref().ok_or_else(|| crate::tcl::Flow::Err("add_metal_fill: no floorplan (FP-001)".into()))?.die;
        let reg = area.unwrap_or(die);
        let widths: Vec<f64> = rules.iter().map(|r| r.width).collect();
        let wr = self.routes.as_ref().map(|d| merge_wires(d.wire_rects(&widths))).unwrap_or_else(|| vec![vec![]; rules.len()]);
        let mut total = 0;
        let mut rep = vec![];
        let mut new_fills: Vec<(String, Rect)> = vec![];
        for (li, r) in rules.iter().enumerate() {
            if !layers.is_empty() && !layers.iter().any(|l| crate::netlist::glob(l, &r.name)) { continue; }
            if layers.is_empty() && li == 0 { continue; }
            let o = opc.map(|x| x.layer(&r.name)).unwrap_or_default();
            let pick = |a: f64, b: f64, d: f64| if a > 0.0 { a } else if b > 0.0 { b } else { d };
            let fw = pick(ov.width, o.fill_width, r.width * 2.0);
            let flen = pick(ov.length, o.fill_length, (r.pitch * 10.0).max(fw * 4.0));
            let fsp = pick(ov.spacing, o.fill_spacing, r.spacing(fw, fw, flen));
            let act = pick(ov.active_spacing, o.active_spacing, if r.fill_active > 0.0 { r.fill_active } else { 2.0 * r.spacing(r.width, fw, flen) });
            let dmin = if ov.min_density >= 0.0 { ov.min_density } else if o.min_density >= 0.0 { o.min_density } else { r.min_density };
            let dmax = if ov.max_density >= 0.0 { ov.max_density } else if o.max_density >= 0.0 { o.max_density } else if r.max_density > 0.0 { r.max_density } else { 0.8 };
            let target = if ov.target >= 0.0 { ov.target } else if o.target_density >= 0.0 { o.target_density } else { (dmin + 0.05).max(0.2).min(dmax) };
            let win = if ov.window > 0.0 { ov.window } else if o.window > 0.0 { o.window } else { r.window.0 };
            let act_shapes = self.active_shapes(li, r, &wr);
            let mut obs = RGrid::new(win.min(10.0).max(1.0));
            for q in &act_shapes { obs.add(grow(*q, act - 1e-9), 0); }
            let mut metal = RGrid::new(win.min(10.0).max(1.0));
            for q in &act_shapes { metal.add(*q, 0); }
            let existing: Vec<Rect> = self.fp.as_ref().unwrap().fills.iter().filter(|f| f.0 == r.name).map(|f| f.1).collect();
            let mut fills = RGrid::new(win.min(10.0).max(1.0));
            for q in &existing { fills.add(*q, 0); metal.add(*q, 1); }
            let mut cov = Cover::new(die, 0.05);
            for q in act_shapes.iter().chain(existing.iter()) { cov.add(*q); }
            // track-aligned fill lines: a fill occupies ceil((fw + fsp) / pitch) tracks
            let tstep = ((fw + fsp) / r.pitch).ceil().max(1.0) * r.pitch;
            let along = flen + fsp;
            let mut added = 0;
            let mut assist = 0;
            // 1) OPC assist fill: free track next to isolated wires
            if o.isolated_space > 0.0 {
                for (_, q) in wr.get(li).into_iter().flatten() {
                    let iso = !metal.query(grow(*q, o.isolated_space)).into_iter().any(|k| { let m = metal.r[k].0; !(m == *q) && inter(m, grow(*q, o.isolated_space)) > 0.0 && !(m.0 >= q.0 - 1e-9 && m.2 <= q.2 + 1e-9 && m.1 >= q.1 - 1e-9 && m.3 <= q.3 + 1e-9) });
                    if !iso { continue; }
                    for side in [-1.0, 1.0] {
                        let off = act + fw / 2.0 + if r.horiz { (q.3 - q.1) / 2.0 } else { (q.2 - q.0) / 2.0 };
                        let c = if r.horiz { (q.1 + q.3) / 2.0 + side * off } else { (q.0 + q.2) / 2.0 + side * off };
                        let f = if r.horiz { (q.0, c - fw / 2.0, q.2, c + fw / 2.0) } else { (c - fw / 2.0, q.1, c + fw / 2.0, q.3) };
                        if f.0 < reg.0 || f.1 < reg.1 || f.2 > reg.2 || f.3 > reg.3 { continue; }
                        if obs.hits(f) || fills.hits(grow(f, fsp - 1e-9)) { continue; }
                        fills.add(f, 0);
                        metal.add(f, 1);
                        cov.add(f);
                        new_fills.push((r.name.clone(), f));
                        added += 1;
                        assist += 1;
                    }
                }
            }
            // 2) density fill window by window
            let (mut lo_d, mut hi_d) = (1.0f64, 0.0f64);
            let mut wy = reg.1;
            while wy < reg.3 - 1e-9 {
                let mut wx = reg.0;
                while wx < reg.2 - 1e-9 {
                    let w = (wx, wy, (wx + win).min(reg.2), (wy + win).min(reg.3));
                    let warea = (w.2 - w.0) * (w.3 - w.1);
                    let mut m: f64 = cov.area(w);
                    if m / warea < target {
                        // candidate lattice inside the window
                        let (c0, c1, a0, a1) = if r.horiz { (w.1, w.3, w.0, w.2) } else { (w.0, w.2, w.1, w.3) };
                        let first = r.start + ((c0 - r.start) / tstep).ceil() * tstep;
                        let mut c = first;
                        'outer: while c + fw / 2.0 <= c1 + 1e-9 {
                            let mut a = a0 + fsp / 2.0;
                            while a + flen <= a1 + 1e-9 {
                                let f = if r.horiz { (a, c - fw / 2.0, a + flen, c + fw / 2.0) } else { (c - fw / 2.0, a, c + fw / 2.0, a + flen) };
                                if !obs.hits(f) && !fills.hits(grow(f, fsp - 1e-9)) {
                                    let fa = flen * fw;
                                    if (m + fa) / warea > dmax { break 'outer; }
                                    fills.add(f, 0);
                                    metal.add(f, 1);
                                    cov.add(f);
                                    new_fills.push((r.name.clone(), f));
                                    m += fa;
                                    added += 1;
                                    if m / warea >= target { break 'outer; }
                                }
                                a += along;
                            }
                            c += tstep;
                        }
                    }
                    lo_d = lo_d.min(m / warea);
                    hi_d = hi_d.max(m / warea);
                    wx += win;
                }
                wy += win;
            }
            if added > 0 || assist > 0 {
                crate::info!("FILL-101", "{}: {} fill shape(s) ({} assist), {:.3}x{:.3}um, spacing {:.3}, {:.3} to active metal; window density {:.1}% .. {:.1}% (target {:.0}%, LEF min {:.0}% / max {:.0}%)", r.name, added, assist, if r.horiz { flen } else { fw }, if r.horiz { fw } else { flen }, fsp, act, lo_d * 100.0, hi_d * 100.0, target * 100.0, dmin * 100.0, dmax * 100.0);
            }
            total += added;
            rep.push((r.name.clone(), added, lo_d, hi_d));
        }
        self.fp.as_mut().unwrap().fills.extend(new_fills);
        Ok((total, rep))
    }

    /// stepped-window density check (LEF DENSITYCHECKWINDOW / DENSITYCHECKSTEP): per layer
    /// (layer, windows, min, max, violations below min, violations above max)
    pub(crate) fn density_check(&self, layers: &[String], win: f64, step: f64, markers: &mut Vec<crate::pg::Marker>) -> Vec<(String, usize, f64, f64, usize, usize, f64, f64)> {
        let rules = self.layer_rules();
        let Some(fp) = self.fp.as_ref() else { return vec![] };
        let die = fp.die;
        let widths: Vec<f64> = rules.iter().map(|r| r.width).collect();
        let wr = self.routes.as_ref().map(|d| merge_wires(d.wire_rects(&widths))).unwrap_or_else(|| vec![vec![]; rules.len()]);
        let mut out = vec![];
        for (li, r) in rules.iter().enumerate() {
            if li == 0 || (!layers.is_empty() && !layers.iter().any(|l| crate::netlist::glob(l, &r.name))) { continue; }
            let (w, s) = (if win > 0.0 { win } else { r.window.0 }, if step > 0.0 { step } else { r.step });
            let dmin = r.min_density;
            let dmax = if r.max_density > 0.0 { r.max_density } else { 1.0 };
            let mut cov = Cover::new(die, 0.05);
            for q in self.active_shapes(li, r, &wr) { cov.add(q); }
            for f in fp.fills.iter().filter(|f| f.0 == r.name) { cov.add(f.1); }
            let (mut n, mut lo, mut hi, mut vlo, mut vhi) = (0, 1.0f64, 0.0f64, 0, 0);
            let mut y = die.1;
            while y + w <= die.3 + 1e-9 || (n == 0 && y < die.3) {
                let mut x = die.0;
                while x + w <= die.2 + 1e-9 || x == die.0 {
                    let q = (x, y, (x + w).min(die.2), (y + w).min(die.3));
                    let a: f64 = cov.area(q);
                    let d = a / ((q.2 - q.0) * (q.3 - q.1)).max(1e-9);
                    n += 1;
                    lo = lo.min(d);
                    hi = hi.max(d);
                    if d + 1e-9 < dmin { vlo += 1; if markers.len() < 2000 { markers.push(crate::pg::Marker { tool: "density".into(), kind: "min_density".into(), layer: r.name.clone(), rect: q, nets: vec![], msg: format!("{} density {:.1}% < {:.0}%", r.name, d * 100.0, dmin * 100.0) }); } }
                    if d > dmax + 1e-9 { vhi += 1; if markers.len() < 2000 { markers.push(crate::pg::Marker { tool: "density".into(), kind: "max_density".into(), layer: r.name.clone(), rect: q, nets: vec![], msg: format!("{} density {:.1}% > {:.0}%", r.name, d * 100.0, dmax * 100.0) }); } }
                    if x + w >= die.2 - 1e-9 { break; }
                    x += s;
                }
                if y + w >= die.3 - 1e-9 { break; }
                y += s;
            }
            out.push((r.name.clone(), n, lo, hi, vlo, vhi, dmin, dmax));
        }
        out
    }

    /// remove fill shapes that violate the active spacing to the current routing
    pub(crate) fn trim_fill(&mut self) -> usize {
        let has = self.fp.as_ref().map(|f| !f.fills.is_empty()).unwrap_or(false);
        if !has || self.routes.is_none() { return 0; }
        let rules = self.layer_rules();
        let widths: Vec<f64> = rules.iter().map(|r| r.width).collect();
        let wr = merge_wires(self.routes.as_ref().unwrap().wire_rects(&widths));
        let mut grids: HashMap<String, (RGrid, f64)> = HashMap::new();
        for (li, r) in rules.iter().enumerate() {
            let mut g = RGrid::new(4.0);
            for q in wr.get(li).into_iter().flatten() { g.add(q.1, 0); }
            let act = if r.fill_active > 0.0 { r.fill_active } else { r.spacing(r.width, r.width, 0.0) };
            grids.insert(r.name.clone(), (g, act));
        }
        let fp = self.fp.as_mut().unwrap();
        let before = fp.fills.len();
        fp.fills.retain(|f| match grids.get(&f.0) { Some((g, act)) => !g.hits(grow(f.1, act - 1e-6)), None => true });
        before - fp.fills.len()
    }

    /// share of routed wire length that has another net on a neighbouring track
    pub(crate) fn adjacency(db: &RouteDb) -> (f64, f64) {
        let (mut tot, mut adj) = (0.0, 0.0);
        let owner: HashMap<u32, NetId> = node_owner(db);
        for (n, rn) in &db.nets {
            for &(nd, par) in &rn.tree {
                if par == NONE { continue; }
                let (x, y, l) = db.xyl(nd);
                let (px, py, pl) = db.xyl(par);
                if l != pl { continue; }
                tot += db.g;
                let st = db.tstep.get(l).copied().unwrap_or(1).max(1) as i64;
                let horiz = py == y && px != x;
                let mut hit = false;
                for side in [-st, st] {
                    let (ax, ay) = if horiz { (x as i64, y as i64 + side) } else { (x as i64 + side, y as i64) };
                    if ax < 0 || ay < 0 || ax as usize >= db.nx || ay as usize >= db.ny { continue; }
                    let an = db.node(ax as usize, ay as usize, l);
                    if owner.get(&an).map(|o| o != n).unwrap_or(false) { hit = true; }
                }
                if hit { adj += db.g; }
            }
        }
        (tot, adj)
    }

    /// yield step 1: wire spreading (reroute crowded nets with a neighbour-track cost)
    pub(crate) fn wire_spreading(&mut self, frac: f64) -> Result<String, crate::tcl::Flow> {
        let Some(db0) = self.routes.as_ref() else { return Err(crate::tcl::Flow::Err("wire spreading: not routed (RT-400)".into())) };
        let (tot0, adj0) = Self::adjacency(db0);
        let save = db0.clone();
        let before = self.route_rule_check(false, false)?;
        let opens0 = save.nets.values().filter(|r| r.open).count();
        // nets with the most neighbour-track length
        let db = self.routes.as_ref().unwrap();
        let owner: HashMap<u32, NetId> = node_owner(db);
        let mut score: Vec<(f64, NetId)> = db.nets.iter().filter(|(_, r)| !r.clock).map(|(n, rn)| {
            let mut s = 0.0;
            for &(nd, _) in &rn.tree {
                let (x, y, l) = db.xyl(nd);
                if l == 0 { continue; }
                let st = db.tstep.get(l).copied().unwrap_or(1).max(1) as i64;
                for (dx, dy) in [(st, 0), (-st, 0), (0, st), (0, -st)] {
                    let (ax, ay) = (x as i64 + dx, y as i64 + dy);
                    if ax < 0 || ay < 0 || ax as usize >= db.nx || ay as usize >= db.ny { continue; }
                    if owner.get(&db.node(ax as usize, ay as usize, l)).map(|o| o != n).unwrap_or(false) { s += 1.0; }
                }
            }
            (s, *n)
        }).collect();
        score.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap().then(a.1.cmp(&b.1)));
        let k = ((score.len() as f64) * frac).ceil() as usize;
        let pick: HashSet<NetId> = score.iter().take(k).filter(|s| s.0 > 0.0).map(|s| s.1).collect();
        if pick.is_empty() { return Ok("wire spreading: no crowded nets".into()); }
        let todo: Vec<crate::droute::RNet> = { let db = self.routes.as_ref().unwrap(); pick.iter().filter_map(|n| db.nets.get(n).cloned()).filter(|r| r.halo == 0).collect() };
        let p = crate::droute::RouteParams { max_iter: 2, via_cost: self.appf("route.detail.via_cost") as f32, m1_cost: self.appf("route.detail.wrong_way_cost") as f32, adj_cost: self.appf("route_opt.yield.spread_cost").max(0.1) as f32, layer_cost: vec![], order: vec![], legal_only: true, fp_steps: vec![], fp_cost: 0.0 };
        let mut db = self.routes.take().unwrap();
        crate::droute::route(&mut db, todo, &p);
        // nets the legal-only reroute could not complete keep their previous route
        let kept = restore_open_nets(&mut db, &save, &pick);
        let still: Vec<crate::droute::RNet> = db.nets.iter().filter(|(n, r)| r.open && pick.contains(n)).map(|(_, r)| r.clone()).collect();
        if !still.is_empty() {
            let p2 = crate::droute::RouteParams { max_iter: 8, adj_cost: 0.0, legal_only: false, ..p.clone() };
            crate::droute::route(&mut db, still, &p2);
        }
        self.min_area_repair(&mut db, "wire spreading");
        let st = crate::droute::stats(&db);
        if kept > 0 { crate::info!("RT-512", "Wire spreading: {} net(s) without a legal spread route keep their previous route", kept); }
        let (tot1, adj1) = Self::adjacency(&db);
        self.routes = Some(db);
        let after = self.route_rule_check(false, false)?;
        let opens1 = self.routes.as_ref().unwrap().nets.values().filter(|r| r.open).count();
        let wl_ok = tot1 <= tot0 * (1.0 + self.appf("route_opt.yield.max_wirelength_increase").max(0.0) / 100.0) + 1e-9;
        if opens1 > opens0 || after.shorts > before.shorts || after.spacing > before.spacing || after.min_area > before.min_area || !wl_ok || adj1 >= adj0 {
            self.routes = Some(save);
            crate::info!("RT-511", "Wire spreading: {} net(s) tried, change rejected (opens {}->{}, shorts {}->{}, spacing {}->{}, min area {}->{}, wirelength {:.1}->{:.1}um, neighbour-track length {:.1}->{:.1}um); routing kept", pick.len(), opens0, opens1, before.shorts, after.shorts, before.spacing, after.spacing, before.min_area, after.min_area, tot0, tot1, adj0, adj1);
            return Ok(format!("0 {:.1}", adj0));
        }
        self.refresh_rc();
        crate::info!("RT-510", "Wire spreading: {} net(s) rerouted ({} open); wire with a neighbour on the adjacent track {:.1}% -> {:.1}% ({:.1} -> {:.1}um), wirelength {:.1} -> {:.1}um; no new opens / shorts / spacing violations", pick.len(), st.opens, 100.0 * adj0 / tot0.max(1e-9), 100.0 * adj1 / tot1.max(1e-9), adj0, adj1, tot0, tot1);
        Ok(format!("{} {:.1}", pick.len(), adj1))
    }

    /// yield step 2: single-cut vias -> double-cut where the second cut has room
    pub(crate) fn multicut_vias(&mut self) -> Result<(usize, usize), crate::tcl::Flow> {
        let before = self.route_rule_check(false, false)?;
        let db = self.routes.as_mut().ok_or_else(|| crate::tcl::Flow::Err("via swapping: not routed (RT-400)".into()))?;
        let mut ids: Vec<NetId> = db.nets.keys().copied().collect();
        ids.sort();
        let (mut total, mut done) = (0, 0);
        let owner: HashMap<u32, NetId> = node_owner(db);
        let mut claimed: HashSet<u32> = HashSet::new();
        for id in ids {
            let tree = db.nets[&id].tree.clone();
            let own: HashSet<u32> = tree.iter().map(|t| t.0).collect();
            let mut add: Vec<(u32, u32)> = vec![];
            for &(c, p) in &tree {
                if p == NONE { continue; }
                let (x, y, lc) = db.xyl(c);
                let lp = db.xyl(p).2;
                if lc == lp { continue; }
                let (lo, hi) = (lc.min(lp), lc.max(lp));
                if lo == 0 { continue; }
                total += 1;
                let lon = db.node(x, y, lo);
                if db.via_types.get(&lon).map(|v| v.0.contains("CUT")).unwrap_or(false) { done += 0; continue; }
                // the second cut beside the first, along the upper layer's preferred direction first
                let dirs: [(i64, i64); 4] = if db.layers[hi].horiz { [(1, 0), (-1, 0), (0, 1), (0, -1)] } else { [(0, 1), (0, -1), (1, 0), (-1, 0)] };
                for (dx, dy) in dirs {
                    let (nx, ny) = (x as i64 + dx, y as i64 + dy);
                    if nx < 1 || ny < 1 || nx as usize >= db.nx - 1 || ny as usize >= db.ny - 1 { continue; }
                    let (nx, ny) = (nx as usize, ny as usize);
                    let mut ok = true;
                    for l in [lo, hi] {
                        let nd = db.node(nx, ny, l);
                        let i = nd as usize;
                        if own.contains(&nd) { continue; }
                        if db.blocked[i] || db.occ[i] > 0 || claimed.contains(&nd) || (db.pin_owner[i] != NONE && db.pin_owner[i] != id as u32) { ok = false; break; }
                        // the second cut's enclosure keeps the LEF spacing to other nets
                        if !space_ok(db, &owner, nd, id) { ok = false; break; }
                        // one grid step of margin beyond the LEF spacing (the second cut's enclosure)
                        let k = db.space_k.get(l).copied().unwrap_or(1).max(1) as i64 + 1;
                        let (x0, y0) = (nx as i64, ny as i64);
                        for ex in -k..=k { for ey in -k..=k {
                            let (ax, ay) = (x0 + ex, y0 + ey);
                            if ax < 0 || ay < 0 || ax as usize >= db.nx || ay as usize >= db.ny { continue; }
                            if owner.get(&db.node(ax as usize, ay as usize, l)).map(|o| *o != id).unwrap_or(false) { ok = false; }
                        } }
                        for ex in -k..=k { for ey in -k..=k {
                            let (ax, ay) = (nx as i64 + ex, ny as i64 + ey);
                            if ax < 0 || ay < 0 || ax as usize >= db.nx || ay as usize >= db.ny { continue; }
                            if claimed.contains(&db.node(ax as usize, ay as usize, l)) && !own.contains(&db.node(ax as usize, ay as usize, l)) { ok = false; }
                        } }
                    }
                    if !ok { continue; }
                    for l in [lo, hi] {
                        let nd = db.node(nx, ny, l);
                        if !own.contains(&nd) { add.push((nd, db.node(x, y, l))); claimed.insert(nd); }
                    }
                    let name = format!("VIA{}{}_2CUT_{}", lo + 1, hi + 1, if dx != 0 { "H" } else { "V" });
                    db.via_types.insert(lon, (name, 0.5));
                    done += 1;
                    break;
                }
            }
            if !add.is_empty() {
                let rn = db.nets.get_mut(&id).unwrap();
                for (nd, par) in add {
                    rn.tree.push((nd, par));
                    db.occ[nd as usize] += 1;
                    db.patches.insert(nd, id);
                }
            }
        }
        let after = self.route_rule_check(false, false)?;
        self.refresh_rc();
        crate::info!("RT-520", "Via swapping: {} of {} single-cut via(s) -> double-cut ({:.1}%); spacing violations {} -> {}, shorts {} -> {}, cut spacing {} -> {}", done, total, 100.0 * done as f64 / total.max(1) as f64, before.spacing, after.spacing, before.shorts, after.shorts, before.cut_spacing, after.cut_spacing);
        Ok((done, total))
    }

    /// litho checks with the OPC rules: forbidden pitches between parallel wires, isolated lines
    pub(crate) fn litho_check(&mut self, opc: &OpcRules, markers: bool) -> Result<(usize, usize, usize), crate::tcl::Flow> {
        let rules = self.layer_rules();
        let db = self.routes.as_ref().ok_or_else(|| crate::tcl::Flow::Err("check_litho: not routed (RT-400)".into()))?;
        let widths: Vec<f64> = rules.iter().map(|r| r.width).collect();
        let wr = merge_wires(db.wire_rects(&widths));
        let (mut fpv, mut iso, mut ww) = (0, 0, 0);
        let mut mk = vec![];
        for (li, rects) in wr.iter().enumerate().skip(1) {
            let Some(r) = rules.get(li) else { continue };
            let o = opc.layer(&r.name);
            let reach = o.forbidden_pitch.iter().map(|x| x.1).fold(o.isolated_space, f64::max);
            if reach <= 0.0 { continue; }
            let mut g = RGrid::new(4.0);
            for (k, (_, q)) in rects.iter().enumerate() { g.add(*q, k as u32); }
            for (k, (n, q)) in rects.iter().enumerate() {
                let along = if r.horiz { q.2 - q.0 } else { q.3 - q.1 };
                if along < r.pitch { continue; }
                let mut near = false;
                for j in g.query(grow(*q, reach)) {
                    if j == k { continue; }
                    let (n2, q2) = rects[j];
                    let cd = if r.horiz { ((q.1 + q.3) - (q2.1 + q2.3)).abs() / 2.0 } else { ((q.0 + q.2) - (q2.0 + q2.2)).abs() / 2.0 };
                    let prl = if r.horiz { q.2.min(q2.2) - q.0.max(q2.0) } else { q.3.min(q2.3) - q.1.max(q2.1) };
                    if prl <= 0.0 || cd < 1e-9 { continue; }
                    if cd <= o.isolated_space { near = true; }
                    if n2 != *n && j > k && o.forbidden_pitch.iter().any(|(a, b)| cd >= *a - 1e-9 && cd <= *b + 1e-9) {
                        fpv += 1;
                        if markers { mk.push(crate::pg::Marker { tool: "litho".into(), kind: "forbidden_pitch".into(), layer: r.name.clone(), rect: (q.0.min(q2.0), q.1.min(q2.1), q.2.max(q2.2), q.3.max(q2.3)), nets: vec![], msg: format!("{} parallel wires at forbidden pitch {:.3}", r.name, cd) }); }
                    }
                }
                if o.isolated_space > 0.0 && !near { iso += 1; }
            }
            // wrong-way runs where the litho rules forbid them (routed edges; via enclosures and
            // patches are not wiring)
            if !o.wrong_way {
                let mut wwr: Vec<Vec<(NetId, Rect)>> = vec![vec![]; db.layers.len()];
                let w2 = r.width / 2.0;
                for (id, rn) in &db.nets {
                    for &(c, p) in &rn.tree {
                        if p == NONE || db.patches.contains_key(&c) { continue; }
                        let (a, b) = (db.pos(c), db.pos(p));
                        if a.2 != li || b.2 != li { continue; }
                        let wrong = if r.horiz { (a.0 - b.0).abs() < 1e-9 } else { (a.1 - b.1).abs() < 1e-9 };
                        if wrong { wwr[li].push((*id, (a.0.min(b.0) - w2, a.1.min(b.1) - w2, a.0.max(b.0) + w2, a.1.max(b.1) + w2))); }
                    }
                }
                for (_, q) in merge_wires(wwr).swap_remove(li) {
                    let len = (q.2 - q.0).max(q.3 - q.1);
                    if len > r.pitch + 1e-9 {
                        ww += 1;
                        if markers { mk.push(crate::pg::Marker { tool: "litho".into(), kind: "wrong_way".into(), layer: r.name.clone(), rect: q, nets: vec![], msg: format!("{} wrong-way run {:.3}um", r.name, len) }); }
                    }
                }
            }
        }
        if markers {
            self.pgx.markers.retain(|m| m.tool != "litho");
            self.pgx.markers.extend(mk);
        }
        Ok((fpv, iso, ww))
    }

    /// OPC line-end extension: each wire end (degree-1 node, not a pin) extended along its run
    pub(crate) fn line_end_extension(&self, db: &mut RouteDb, opc: &OpcRules) -> usize {
        let rules = self.layer_rules();
        let mut n = 0;
        let mut owner = node_owner(db);
        let ids: Vec<NetId> = { let mut v: Vec<NetId> = db.nets.keys().copied().collect(); v.sort(); v };
        for id in ids {
            let rn = db.nets[&id].clone();
            let pins: HashSet<u32> = rn.pins.iter().map(|p| p.1).collect();
            let mut deg: HashMap<u32, usize> = HashMap::new();
            for &(c, p) in &rn.tree { if p != NONE { *deg.entry(c).or_default() += 1; *deg.entry(p).or_default() += 1; } }
            let mut add = vec![];
            for &(c, p) in &rn.tree {
                for (end, other) in [(c, p), (p, c)] {
                    if other == NONE || end == NONE || deg.get(&end) != Some(&1) || pins.contains(&end) || db.patches.contains_key(&end) || db.patches.contains_key(&other) { continue; }
                    let (x, y, l) = db.xyl(end);
                    let (ox, oy, ol) = db.xyl(other);
                    if l != ol || l == 0 { continue; }
                    let ext = opc.layer(&rules[l].name).line_end_extension;
                    if ext <= 0.0 { continue; }
                    let k = (ext / db.g).ceil() as i64;
                    let (dx, dy) = ((x as i64 - ox as i64).signum(), (y as i64 - oy as i64).signum());
                    let mut prev = end;
                    for s in 1..=k {
                        let (nx, ny) = (x as i64 + dx * s, y as i64 + dy * s);
                        if nx < 0 || ny < 0 || nx as usize >= db.nx || ny as usize >= db.ny { break; }
                        let nd = db.node(nx as usize, ny as usize, l);
                        let i = nd as usize;
                        if db.blocked[i] || db.occ[i] > 0 || db.pin_owner[i] != NONE || !space_ok(db, &owner, nd, id) { break; }
                        owner.insert(nd, id);
                        add.push((nd, prev));
                        prev = nd;
                    }
                    if prev != end { n += 1; }
                }
            }
            let rn = db.nets.get_mut(&id).unwrap();
            for (nd, par) in add {
                if db.occ[nd as usize] > 0 { continue; }
                rn.tree.push((nd, par));
                db.occ[nd as usize] += 1;
                db.patches.insert(nd, id);
            }
        }
        n
    }

    pub(crate) fn rtrules_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "report_layer_rules" | "report_lef_rules" | "report_routing_layer_rules" => {
                let rules = self.layer_rules();
                crate::out!("\n****************************************\nReport : layer_rules\n****************************************");
                crate::out!("  {:<6} {:<4} {:>7} {:>7} {:>7} {:>7} {:>8} {:>7} {:>10} {:>10} {:<9} {}", "layer", "dir", "pitch", "width", "space", "minw", "area", "track0", "R kOhm/um", "C pF/um", "source", "density / spacing table");
                for r in &rules {
                    let rc = self.lef_rc(&r.name);
                    crate::out!("  {:<6} {:<4} {:>7.3} {:>7.3} {:>7.3} {:>7.3} {:>8.4} {:>7.3} {:>10} {:>10} {:<9} {}", r.name, if r.horiz { "H" } else { "V" }, r.pitch, r.width, r.spacing(r.width, r.width, 0.0), r.min_width, r.area, r.start,
                        rc.filter(|x| x.0 >= 0.0).map(|x| format!("{:.6}", x.0)).unwrap_or("app".into()), rc.filter(|x| x.1 >= 0.0).map(|x| format!("{:.6}", x.1)).unwrap_or("app".into()), format!("{}{}", r.source, if r.tracks { "+DEF" } else { "" }),
                        format!("{}{}{}", if r.min_density > 0.0 || r.max_density > 0.0 { format!("{:.0}%..{:.0}% win {:.0}x{:.0} step {:.0}", r.min_density * 100.0, r.max_density * 100.0, r.window.0, r.window.1, r.step) } else { "-".into() },
                            if r.fill_active > 0.0 { format!(" fillactive {:.3}", r.fill_active) } else { String::new() },
                            if r.lef.sp_table.is_empty() { String::new() } else { format!(" prl {:?} {:?}", r.lef.prl, r.lef.sp_table) }));
                }
                Ok(rules.len().to_string())
            }
            "check_route_rules" | "verify_route_rules" | "check_lef_rules" | "verifyRouteRules" => {
                let x = args(a, &[]);
                match self.route_rule_check(!x.has("-no_markers"), x.has("-verbose")) {
                    Ok(rc) => {
                        let rules = self.layer_rules();
                        crate::out!("\n****************************************\nReport : check_route_rules\n****************************************");
                        crate::out!("  Rules              : {} (tech LEF layers: {})", if rules.iter().any(|r| r.source == "LEF") { "LEF" } else { "built-in" }, rules.iter().filter(|r| r.source == "LEF").count());
                        let on = self.routes.as_ref().map(|d| !d.offtrack.is_empty() || d.space_k.iter().any(|k| *k > 0)).unwrap_or(false);
                        crate::out!("  Track / spacing    : {}", if on { "enforced by the router" } else { "not enforced (route.detail.honor_tracks auto: plain LEF layer stack; set it to true)" });
                        crate::out!("  Wire shapes        : {}", rc.wires);
                        crate::out!("  Off-track wiring   : {}", rc.off_track);
                        crate::out!("  Width              : {}", rc.width);
                        crate::out!("  Spacing            : {}", rc.spacing);
                        crate::out!("  Shorts             : {}", rc.shorts);
                        crate::out!("  Minimum area       : {}", rc.min_area);
                        crate::out!("  Cut spacing        : {}", rc.cut_spacing);
                        crate::out!("  Fill spacing       : {}", rc.fill);
                        crate::out!("  Total              : {}", rc.total());
                        if rc.total() == 0 { crate::info!("RT-401", "Routing honours the layer rules"); } else { crate::warn!("RT-402", "{} routing rule violation(s) (markers: report_markers -tool route_rules)", rc.total()); }
                        Ok(rc.total().to_string())
                    }
                    Err(e) => Err(e),
                }
            }
            "read_opc_rules" | "load_opc_rules" => {
                let Some(f) = a.iter().find(|x| !x.starts_with('-')) else { return Some(err("read_opc_rules <opc_fill.rules>")) };
                match self.load_opc(f) {
                    Ok(n) => Ok(n.to_string()),
                    Err(e) => Err(e),
                }
            }
            "report_opc_rules" => {
                let Some(o) = self.rt.opc.clone() else { return Some(err("report_opc_rules: no OPC rules (read_opc_rules / route_auto -opc file) (OPC-002)")) };
                crate::out!("\n****************************************\nReport : opc_rules ({})\n****************************************", o.file);
                let show = |n: &str, l: &OpcLayer| crate::out!("  {:<8} fill {}x{} space {} active {} density {}/{}/{} window {} step {} assist {} line-end {} forbidden {:?} wrong-way {}", n, l.fill_width, l.fill_length, l.fill_spacing, l.active_spacing, l.min_density, l.target_density, l.max_density, l.window, l.step, l.isolated_space, l.line_end_extension, l.forbidden_pitch, if l.wrong_way { "allowed" } else { "off" });
                show("default", &o.default);
                for (n, l) in &o.layers { show(n, l); }
                Ok(o.layers.len().to_string())
            }
            "add_metal_fill" | "addMetalFill" | "create_metal_fill" | "signoff_create_metal_fill" | "insert_metal_fill" => {
                let x = args(a, &["-layers", "-layer", "-area", "-opc", "-width", "-length", "-spacing", "-active_spacing", "-min_density", "-max_density", "-target_density", "-density", "-window"]);
                if let Some(f) = x.get("-opc") { if let Err(e) = self.load_opc(f) { return Some(Err(e)); } }
                let opc = if x.has("-no_opc") { None } else { self.rt.opc.clone() };
                let layers: Vec<String> = x.get("-layers").or(x.get("-layer")).map(|s| split_list(s)).unwrap_or_default();
                let area = x.get("-area").and_then(|s| { let v: Vec<f64> = s.replace(['{', '}'], " ").split_whitespace().filter_map(|t| t.parse().ok()).collect(); if v.len() >= 4 { Some((v[0].min(v[2]), v[1].min(v[3]), v[0].max(v[2]), v[1].max(v[3]))) } else { None } });
                let ov = FillOverrides {
                    width: x.num("-width").unwrap_or(0.0), length: x.num("-length").unwrap_or(0.0), spacing: x.num("-spacing").unwrap_or(0.0), active_spacing: x.num("-active_spacing").unwrap_or(0.0),
                    min_density: x.num("-min_density").map(pct).unwrap_or(-1.0), max_density: x.num("-max_density").map(pct).unwrap_or(-1.0), target: x.num("-target_density").or(x.num("-density")).map(pct).unwrap_or(-1.0), window: x.num("-window").unwrap_or(0.0),
                };
                if x.has("-replace") || x.has("-delete_existing") {
                    if let Some(fp) = self.fp.as_mut() { fp.fills.retain(|f| !layers.is_empty() && !layers.iter().any(|l| crate::netlist::glob(l, &f.0))); }
                }
                match self.add_metal_fill(&layers, area, opc.as_ref(), &ov) {
                    Ok((n, _)) => {
                        crate::info!("FILL-100", "add_metal_fill: {} fill shape(s) added{} ({} in the design)", n, opc.as_ref().map(|o| format!(" with OPC rules '{}'", o.file)).unwrap_or_default(), self.fp.as_ref().map(|f| f.fills.len()).unwrap_or(0));
                        Ok(n.to_string())
                    }
                    Err(e) => Err(e),
                }
            }
            "delete_metal_fill" | "deleteMetalFill" | "remove_metal_fill" | "trim_metal_fill" => {
                let x = args(a, &["-layers", "-layer", "-area"]);
                if name == "trim_metal_fill" {
                    let n = self.trim_fill();
                    crate::info!("FILL-110", "trim_metal_fill: {} fill shape(s) too close to routing removed", n);
                    return Some(Ok(n.to_string()));
                }
                let layers: Vec<String> = x.get("-layers").or(x.get("-layer")).map(|s| split_list(s)).unwrap_or_default();
                let area = x.get("-area").and_then(|s| { let v: Vec<f64> = s.replace(['{', '}'], " ").split_whitespace().filter_map(|t| t.parse().ok()).collect(); if v.len() >= 4 { Some((v[0].min(v[2]), v[1].min(v[3]), v[0].max(v[2]), v[1].max(v[3]))) } else { None } });
                let Some(fp) = self.fp.as_mut() else { return Some(err("delete_metal_fill: no floorplan (FP-001)")) };
                let b = fp.fills.len();
                fp.fills.retain(|f| !((layers.is_empty() || layers.iter().any(|l| crate::netlist::glob(l, &f.0))) && area.map(|r| inter(r, f.1) > 0.0).unwrap_or(true)));
                let n = b - fp.fills.len();
                crate::info!("FILL-111", "delete_metal_fill: {} fill shape(s) removed", n);
                Ok(n.to_string())
            }
            "report_metal_density" | "check_metal_density" | "verifyMetalDensity" | "verify_metal_density" => {
                let x = args(a, &["-layers", "-layer", "-window", "-step"]);
                let layers: Vec<String> = x.get("-layers").or(x.get("-layer")).map(|s| split_list(s)).unwrap_or_default();
                let mut mk = vec![];
                let r = self.density_check(&layers, x.num("-window").unwrap_or(0.0), x.num("-step").unwrap_or(0.0), &mut mk);
                crate::out!("\n****************************************\nReport : metal_density\n****************************************");
                crate::out!("  {:<6} {:>7} {:>8} {:>8} {:>8} {:>8} {:>7} {:>7} {:>7}", "layer", "windows", "min", "max", "LEF min", "LEF max", "<min", ">max", "fills");
                let mut v = 0;
                for (l, n, lo, hi, vlo, vhi, dmin, dmax) in &r {
                    let nf = self.fp.as_ref().map(|f| f.fills.iter().filter(|q| &q.0 == l).count()).unwrap_or(0);
                    crate::out!("  {:<6} {:>7} {:>7.1}% {:>7.1}% {:>7.0}% {:>7.0}% {:>7} {:>7} {:>7}", l, n, lo * 100.0, hi * 100.0, dmin * 100.0, dmax * 100.0, vlo, vhi, nf);
                    v += vlo + vhi;
                }
                if !x.has("-no_markers") {
                    self.pgx.markers.retain(|m| m.tool != "density");
                    self.pgx.markers.extend(mk);
                }
                if v == 0 { crate::info!("FILL-120", "Metal density within the LEF limits on all checked layers"); } else { crate::warn!("FILL-121", "{} density window violation(s)", v); }
                Ok(v.to_string())
            }
            "check_litho" | "check_litho_rules" | "verify_litho" => {
                let x = args(a, &["-opc"]);
                if let Some(f) = x.get("-opc") { if let Err(e) = self.load_opc(f) { return Some(Err(e)); } }
                let Some(o) = self.rt.opc.clone() else { return Some(err("check_litho: no OPC rules (read_opc_rules / -opc file) (OPC-002)")) };
                match self.litho_check(&o, true) {
                    Ok((fpv, iso, ww)) => {
                        crate::out!("\n****************************************\nReport : check_litho ({})\n****************************************", o.file);
                        crate::out!("  Forbidden-pitch wire pairs : {}\n  Isolated lines             : {}\n  Wrong-way runs             : {}", fpv, iso, ww);
                        Ok(format!("{} {} {}", fpv, iso, ww))
                    }
                    Err(e) => Err(e),
                }
            }
            "optimize_wire_spreading" | "spread_wires" | "route_spread_wires" => {
                let x = args(a, &["-fraction"]);
                self.wire_spreading(x.num("-fraction").unwrap_or(self.appf("route_opt.yield.spread_fraction").max(0.01)).clamp(0.01, 1.0))
            }
            "insert_redundant_vias" | "add_redundant_vias" | "swap_multicut_vias" | "via_swap_multicut" => match self.multicut_vias() {
                Ok((d, t)) => Ok(format!("{} {}", d, t)),
                Err(e) => Err(e),
            },
            _ => return self.rtopt_cmd(name, a),
        })
    }

    pub(crate) fn load_opc(&mut self, f: &str) -> Result<usize, crate::tcl::Flow> {
        let t = std::fs::read_to_string(f).map_err(|e| crate::tcl::Flow::Err(format!("OPC rules '{}': {} (OPC-001)", f, e)))?;
        let r = OpcRules::parse(&t, f).map_err(|e| crate::tcl::Flow::Err(format!("{} (OPC-003)", e)))?;
        crate::info!("OPC-010", "Read OPC / litho rules '{}': default + {} layer(s) ({})", f, r.layers.len(), r.layers.keys().cloned().collect::<Vec<_>>().join(" "));
        let n = r.layers.len();
        self.rt.opc = Some(r);
        Ok(n)
    }
}

/// add_metal_fill command overrides (0 / negative: from OPC rules or LEF)
#[derive(Clone, Debug, Default)]
pub struct FillOverrides {
    pub width: f64,
    pub length: f64,
    pub spacing: f64,
    pub active_spacing: f64,
    pub min_density: f64,
    pub max_density: f64,
    pub target: f64,
    pub window: f64,
}
