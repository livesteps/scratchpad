//! LEF reader (macro abstracts) and placed-cell geometry.
//!
//! `read_lef file...` loads MACRO CLASS / SIZE / SYMMETRY / SITE / PIN (DIRECTION, USE, PORT
//! LAYER RECT) / OBS and LAYER (TYPE, DIRECTION, PITCH, WIDTH) definitions. Cells whose
//! master has a LEF macro are placed by their lower-left corner (DEF semantics) and use the
//! LEF footprint, pin shapes and obstructions in legalization, routing and GDS; cells
//! without one keep the area-based model.
//!
//! Orientation convention (same as the GDS writer): reflect about X (F*), then rotate
//! counter-clockwise: N 0, W 90, S 180, E 270, FS = MX, FN = MX+180 (= MY), FE = MX+90,
//! FW = MX+270; the transformed bounding box is moved so that its lower-left is the
//! placement point.

use crate::netlist::*;
use std::collections::HashMap;

pub type Rect = (f64, f64, f64, f64);

#[derive(Clone, Debug, Default)]
pub struct LefPin {
    pub name: String,
    pub dir: String,
    pub usage: String,
    pub shapes: Vec<(String, Rect)>,
}

#[derive(Clone, Debug, Default)]
pub struct LefMacro {
    pub name: String,
    pub class: String,
    pub w: f64,
    pub h: f64,
    pub symmetry: String,
    pub site: String,
    pub pins: Vec<LefPin>,
    pub obs: Vec<(String, Rect)>,
    pub file: String,
}

#[derive(Clone, Debug, Default)]
pub struct LefLayer {
    pub name: String,
    pub kind: String,
    pub dir: String,
    pub pitch: f64,
    pub width: f64,
    /// minimum spacing (first SPACING statement)
    pub spacing: f64,
}

/// VIARULE ... GENERATE: cut array between two routing layers
#[derive(Clone, Debug, Default)]
pub struct ViaRule {
    pub name: String,
    pub lower: String,
    pub cut: String,
    pub upper: String,
    pub cut_w: f64,
    pub cut_h: f64,
    pub sp_x: f64,
    pub sp_y: f64,
    pub enc_lo: (f64, f64),
    pub enc_hi: (f64, f64),
}

/// VIARULE GENERATE statements of a LEF file
/// LEF `SITE name CLASS c ; SIZE w BY h ; END name`
#[derive(Clone, Debug, Default)]
pub struct LefSite {
    pub name: String,
    pub class: String,
    pub w: f64,
    pub h: f64,
}
pub fn parse_sites(text: &str) -> Vec<LefSite> {
    let clean = text.lines().map(|l| l.split('#').next().unwrap_or("")).collect::<Vec<_>>().join("\n");
    let t: Vec<&str> = clean.split_whitespace().collect();
    let mut v = vec![];
    let mut i = 0;
    let mut in_macro: Option<String> = None;
    while i + 1 < t.len() {
        match t[i] {
            "MACRO" => { in_macro = Some(t[i + 1].to_string()); i += 2; }
            "END" => { if in_macro.as_deref() == Some(t[i + 1]) { in_macro = None; } i += 2; }
            "SITE" if in_macro.is_none() => {
                let mut s = LefSite { name: t[i + 1].to_string(), ..Default::default() };
                let mut j = i + 2;
                while j + 1 < t.len() && !(t[j] == "END" && t[j + 1] == s.name) {
                    match t[j] {
                        "CLASS" => s.class = t[j + 1].trim_end_matches(';').to_string(),
                        "SIZE" if j + 3 < t.len() => { s.w = t[j + 1].parse().unwrap_or(0.0); s.h = t[j + 3].parse().unwrap_or(0.0); }
                        _ => {}
                    }
                    j += 1;
                }
                v.push(s);
                i = j + 2;
            }
            _ => i += 1,
        }
    }
    v
}

pub fn parse_via_rules(text: &str) -> Vec<ViaRule> {
    let t = toks(text);
    let mut out = vec![];
    let mut i = 0;
    let f = |k: usize| t.get(k).and_then(|x| x.parse::<f64>().ok()).unwrap_or(0.0);
    while i < t.len() {
        if t[i] == "VIARULE" && t.get(i + 2).map(|x| x == "GENERATE").unwrap_or(false) {
            let name = t[i + 1].clone();
            let mut r = ViaRule { name: name.clone(), ..Default::default() };
            let mut layers: Vec<String> = vec![];
            let mut encs: Vec<(f64, f64)> = vec![];
            i += 3;
            while i < t.len() && !(t[i] == "END" && t.get(i + 1) == Some(&name)) {
                match t[i].as_str() {
                    "LAYER" => { layers.push(t.get(i + 1).cloned().unwrap_or_default()); i += 2; }
                    "ENCLOSURE" => { encs.push((f(i + 1), f(i + 2))); i += 3; }
                    "RECT" => { r.cut_w = (f(i + 3) - f(i + 1)).abs(); r.cut_h = (f(i + 4) - f(i + 2)).abs(); i += 5; }
                    "SPACING" => { r.sp_x = f(i + 1); r.sp_y = if t.get(i + 2).map(|x| x == "BY").unwrap_or(false) { f(i + 3) } else { f(i + 1) }; i += 2; }
                    _ => i += 1,
                }
            }
            if layers.len() == 3 {
                r.lower = layers[0].clone();
                r.cut = layers[1].clone();
                r.upper = layers[2].clone();
                r.enc_lo = encs.first().copied().unwrap_or((0.0, 0.0));
                r.enc_hi = encs.get(1).copied().unwrap_or(r.enc_lo);
                out.push(r);
            }
        }
        i += 1;
    }
    out
}

impl LefMacro {
    pub fn pin(&self, n: &str) -> Option<&LefPin> {
        self.pins.iter().find(|p| p.name == n)
    }
    pub fn is_block(&self) -> bool {
        self.class.starts_with("BLOCK")
    }
    pub fn is_pad(&self) -> bool {
        self.class.starts_with("PAD")
    }
    pub fn is_corner(&self) -> bool {
        self.class.contains("CORNER") || self.class == "ENDCAP TOPLEFT" || self.class.starts_with("ENDCAP")
    }
    pub fn is_bump(&self) -> bool {
        self.class.contains("BUMP")
    }
}

fn toks(s: &str) -> Vec<String> {
    let mut v = vec![];
    for line in s.lines() {
        let l = line.split('#').next().unwrap_or("");
        for t in l.split_whitespace() {
            if t.ends_with(';') && t.len() > 1 {
                v.push(t[..t.len() - 1].to_string());
                v.push(";".into());
            } else {
                v.push(t.to_string());
            }
        }
    }
    v
}

/// Parse LEF text: (macros, layers)
pub fn parse(text: &str, file: &str) -> Result<(Vec<LefMacro>, Vec<LefLayer>), String> {
    let t = toks(text);
    let mut i = 0;
    let mut macros = vec![];
    let mut layers = vec![];
    let num = |t: &Vec<String>, i: usize| -> Result<f64, String> { t.get(i).and_then(|x| x.parse::<f64>().ok()).ok_or_else(|| format!("{}: number expected near token {}", file, i)) };
    let skip_stmt = |i: &mut usize| { while *i < t.len() && t[*i] != ";" { *i += 1; } *i += 1; };
    while i < t.len() {
        match t[i].as_str() {
            "LAYER" if i + 1 < t.len() => {
                let mut l = LefLayer { name: t[i + 1].clone(), ..Default::default() };
                i += 2;
                while i < t.len() && !(t[i] == "END" && t.get(i + 1) == Some(&l.name)) {
                    match t[i].as_str() {
                        "TYPE" => { l.kind = t.get(i + 1).cloned().unwrap_or_default(); skip_stmt(&mut i); }
                        "DIRECTION" => { l.dir = t.get(i + 1).cloned().unwrap_or_default(); skip_stmt(&mut i); }
                        "PITCH" => { l.pitch = num(&t, i + 1).unwrap_or(0.0); skip_stmt(&mut i); }
                        "WIDTH" => { l.width = num(&t, i + 1).unwrap_or(0.0); skip_stmt(&mut i); }
                        "SPACING" => { if l.spacing == 0.0 { l.spacing = num(&t, i + 1).unwrap_or(0.0); } skip_stmt(&mut i); }
                        _ => i += 1,
                    }
                }
                i += 2;
                layers.push(l);
            }
            // VIA / VIARULE blocks carry LAYER statements of their own: skip them here
            "VIA" | "VIARULE" if i + 1 < t.len() => {
                let name = t[i + 1].clone();
                i += 2;
                while i < t.len() && !(t[i] == "END" && t.get(i + 1) == Some(&name)) { i += 1; }
                i += 2;
            }
            "MACRO" if i + 1 < t.len() => {
                let mut m = LefMacro { name: t[i + 1].clone(), file: file.to_string(), ..Default::default() };
                i += 2;
                while i < t.len() && !(t[i] == "END" && t.get(i + 1) == Some(&m.name)) {
                    match t[i].as_str() {
                        "CLASS" => {
                            let mut c = vec![];
                            i += 1;
                            while i < t.len() && t[i] != ";" { c.push(t[i].clone()); i += 1; }
                            i += 1;
                            m.class = c.join(" ");
                        }
                        "SIZE" => {
                            m.w = num(&t, i + 1)?;
                            m.h = num(&t, i + 3)?;
                            skip_stmt(&mut i);
                        }
                        "SYMMETRY" => {
                            let mut c = vec![];
                            i += 1;
                            while i < t.len() && t[i] != ";" { c.push(t[i].clone()); i += 1; }
                            i += 1;
                            m.symmetry = c.join(" ");
                        }
                        "SITE" => { m.site = t.get(i + 1).cloned().unwrap_or_default(); skip_stmt(&mut i); }
                        "PIN" => {
                            let mut p = LefPin { name: t[i + 1].clone(), ..Default::default() };
                            i += 2;
                            let mut layer = String::new();
                            while i < t.len() && !(t[i] == "END" && t.get(i + 1) == Some(&p.name)) {
                                match t[i].as_str() {
                                    "DIRECTION" => { p.dir = t.get(i + 1).cloned().unwrap_or_default(); skip_stmt(&mut i); }
                                    "USE" => { p.usage = t.get(i + 1).cloned().unwrap_or_default(); skip_stmt(&mut i); }
                                    "LAYER" => { layer = t.get(i + 1).cloned().unwrap_or_default(); skip_stmt(&mut i); }
                                    "RECT" => {
                                        let r = (num(&t, i + 1)?, num(&t, i + 2)?, num(&t, i + 3)?, num(&t, i + 4)?);
                                        p.shapes.push((layer.clone(), (r.0.min(r.2), r.1.min(r.3), r.0.max(r.2), r.1.max(r.3))));
                                        skip_stmt(&mut i);
                                    }
                                    _ => i += 1,
                                }
                            }
                            i += 2;
                            m.pins.push(p);
                        }
                        "OBS" => {
                            i += 1;
                            let mut layer = String::new();
                            while i < t.len() && t[i] != "END" {
                                match t[i].as_str() {
                                    "LAYER" => { layer = t.get(i + 1).cloned().unwrap_or_default(); skip_stmt(&mut i); }
                                    "RECT" => {
                                        let r = (num(&t, i + 1)?, num(&t, i + 2)?, num(&t, i + 3)?, num(&t, i + 4)?);
                                        m.obs.push((layer.clone(), (r.0.min(r.2), r.1.min(r.3), r.0.max(r.2), r.1.max(r.3))));
                                        skip_stmt(&mut i);
                                    }
                                    _ => i += 1,
                                }
                            }
                            i += 1;
                        }
                        _ => i += 1,
                    }
                }
                i += 2;
                if m.w <= 0.0 || m.h <= 0.0 {
                    return Err(format!("{}: MACRO {} has no SIZE", file, m.name));
                }
                macros.push(m);
            }
            _ => i += 1,
        }
    }
    Ok((macros, layers))
}

/// footprint (w, h) after orientation
pub fn oriented_size(w: f64, h: f64, orient: &str) -> (f64, f64) {
    match orient {
        "W" | "E" | "FW" | "FE" => (h, w),
        _ => (w, h),
    }
}

/// transform a macro-local rectangle to design coordinates for placement `at` (lower-left)
pub fn place_rect(r: Rect, w: f64, h: f64, orient: &str, at: (f64, f64)) -> Rect {
    let (refl, ang) = crate::gds::orient_tf(orient);
    let tf = |x: f64, y: f64| -> (f64, f64) {
        let y = if refl { -y } else { y };
        match ang {
            90 => (-y, x),
            180 => (-x, -y),
            270 => (y, -x),
            _ => (x, y),
        }
    };
    // bounding box of the transformed macro outline gives the translation
    let cs = [tf(0.0, 0.0), tf(w, 0.0), tf(0.0, h), tf(w, h)];
    let mx = cs.iter().map(|p| p.0).fold(f64::MAX, f64::min);
    let my = cs.iter().map(|p| p.1).fold(f64::MAX, f64::min);
    let a = tf(r.0, r.1);
    let b = tf(r.2, r.3);
    (a.0.min(b.0) - mx + at.0, a.1.min(b.1) - my + at.1, a.0.max(b.0) - mx + at.0, a.1.max(b.1) - my + at.1)
}

pub fn orient_of(c: &Cell) -> &str {
    c.attrs.iter().find_map(|a| a.strip_prefix("orient:")).unwrap_or("N")
}

/// placed bounding box of a cell with a LEF master
pub fn cell_rect(lef: &HashMap<String, LefMacro>, c: &Cell) -> Option<Rect> {
    let m = phys(lef, c)?;
    let l = c.loc?;
    Some(place_rect((0.0, 0.0, m.w, m.h), m.w, m.h, orient_of(c), l))
}

/// LEF macro of a cell placed by its lower-left corner (blocks, pads, covers); standard cells
/// (CLASS CORE) keep the centre-placed area model
pub fn phys<'a>(lef: &'a HashMap<String, LefMacro>, c: &Cell) -> Option<&'a LefMacro> {
    lef.get(master(c)?).filter(|m| !m.class.starts_with("CORE"))
}

pub fn master(c: &Cell) -> Option<&str> {
    match &c.kind {
        Kind::Lib(l) => Some(l.as_str()),
        Kind::BlackBox(m) => Some(m.as_str()),
        _ => None,
    }
}

/// placed shapes of a pin (layer, rect) of a cell with a LEF master
pub fn pin_shapes(lef: &HashMap<String, LefMacro>, c: &Cell, pin: &str) -> Vec<(String, Rect)> {
    let Some(m) = phys(lef, c) else { return vec![] };
    let Some(l) = c.loc else { return vec![] };
    let o = orient_of(c);
    m.pin(pin).map(|p| p.shapes.iter().map(|(ly, r)| (ly.clone(), place_rect(*r, m.w, m.h, o, l))).collect()).unwrap_or_default()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn parse_and_orient() {
        let lef = "MACRO PADIN\n CLASS PAD INPUT ;\n SIZE 60 BY 120 ;\n SYMMETRY X Y R90 ;\n PIN C\n  DIRECTION OUTPUT ;\n  PORT\n   LAYER M2 ;\n    RECT 29 119 31 120 ;\n  END\n END C\n OBS\n  LAYER M1 ;\n   RECT 0 0 60 120 ;\n END\nEND PADIN\n";
        let (m, _) = parse(lef, "t").unwrap();
        assert_eq!(m.len(), 1);
        let p = &m[0];
        assert_eq!((p.w, p.h, p.class.as_str()), (60.0, 120.0, "PAD INPUT"));
        assert_eq!(p.pins[0].shapes[0].1, (29.0, 119.0, 31.0, 120.0));
        // S (180): the pin at the top moves to the bottom
        let r = place_rect(p.pins[0].shapes[0].1, 60.0, 120.0, "S", (100.0, 0.0));
        assert!((r.1 - 0.0).abs() < 1e-9 && (r.0 - 129.0).abs() < 1e-9, "{:?}", r);
        // W (90 ccw): footprint 120 x 60; top edge -> left edge
        let r = place_rect(p.pins[0].shapes[0].1, 60.0, 120.0, "W", (0.0, 0.0));
        assert!((r.0 - 0.0).abs() < 1e-9 && (r.2 - 1.0).abs() < 1e-9, "{:?}", r);
        assert_eq!(oriented_size(60.0, 120.0, "W"), (120.0, 60.0));
    }
}
