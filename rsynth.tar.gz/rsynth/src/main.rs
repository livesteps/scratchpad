//! RSynth — physically-aware MMMC logic synthesis with a Fusion-Compiler-style shell.
pub mod checks;
pub mod cons;
pub mod dft;
pub mod eco;
pub mod elab;
pub mod genopt;
pub mod hdl;
pub mod liberty;
pub mod log;
pub mod netlist;
pub mod opt;
pub mod out;
pub mod phys;
pub mod fplan;
pub mod legal;
pub mod cts;
pub mod ctree;
pub mod paths;
pub mod tpaths;
pub mod dbaccess;
pub mod pintime;
pub mod spef;
pub mod timcmd;
pub mod names;
pub mod models;
pub mod xout;
pub mod gds;
pub mod hflow;
pub mod mim;
pub mod optctl;
pub mod droute;
pub mod pnr;
pub mod fpcmd;
pub mod gui;
pub mod part;
pub mod query;
pub mod objquery;
pub mod sitecheck;
pub mod ioovl;
pub mod ctspec;
pub mod tupdate;
pub mod rtrules;
pub mod rtopt;
pub mod odb;
pub mod odb_gen;
pub mod metrics;
pub mod regex;
pub mod session;
pub mod sim;
pub mod sta;
pub mod tcl;
pub mod techmap;
pub mod upf;
pub mod va;
pub mod rcnet;
pub mod grtime;
pub mod dcalc;
pub mod lef;
pub mod chipfp;
pub mod padring;
pub mod flipchip;
pub mod routeedit;
pub mod ecomask;
pub mod cmdreg;
pub mod guisch;
pub mod lineedit;
pub mod dftip;
pub mod dftadv;
pub mod rowtrack;
pub mod physcells;
pub mod pg;
pub mod atpg;
#[cfg(feature = "gtk")]
pub mod gtkgui;
#[cfg(feature = "gtk")]
pub mod json;

use std::io::{BufRead, Write};

fn usage() {
    println!("Usage: rsynth [-f script.tcl] [-x \"cmds\"] [-nolog] [-no_gui] [-gui]\n  -f        Run a Tcl script\n  -x        Run commands\n  -nolog    No rsynth.run.log / rsynth.cmd.log (set_log_filename / set_cmd_filename name them)\n  -no_gui   Stay in the shell after the scripts\n  -gui      Open GUI\n  -version  Show the release version\n  -help     Show this help");
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    // -help / -version: no logs
    for a in &args[1..] {
        match a.as_str() {
            "-h" | "-help" | "--help" => { usage(); return; }
            "-v" | "-version" | "--version" => { println!("RSynth {}", env!("CARGO_PKG_VERSION")); return; }
            _ => {}
        }
    }
    metrics::init();
    // run and command logs (Innovus style): RSYNTH_LOG_FILE / RSYNTH_CMD_FILE if set, else
    // rsynth.run.log / rsynth.cmd.log (next free rsynth.run.logN / rsynth.cmd.logN)
    let nolog = args.iter().any(|a| a == "-nolog" || a == "-no_log" || a == "--nolog") || std::env::var("RSYNTH_NOLOG").map(|v| !v.is_empty() && v != "0").unwrap_or(false);
    if !nolog {
        let env_log = std::env::var("RSYNTH_LOG_FILE").ok().filter(|v| !v.is_empty());
        let env_cmd = std::env::var("RSYNTH_CMD_FILE").ok().filter(|v| !v.is_empty());
        let (dl, dc) = if env_log.is_some() && env_cmd.is_some() { (None, None) } else { log::open_default_logs("rsynth.run.log", "rsynth.cmd.log") };
        if let Some(f) = env_log { if let Err(e) = log::set_log_path(&f) { eprintln!("Error: {} (LOG-101)", e); } }
        if let Some(f) = env_cmd { if let Err(e) = log::set_cmd_path(&f) { eprintln!("Error: {} (LOG-103)", e); } }
        if dl.is_none() && dc.is_none() && log::log_path().is_none() { eprintln!("Warning: cannot create rsynth.run.log / rsynth.cmd.log in the current directory (LOG-104)"); }
    }
    metrics::header();
    let mut s = session::Session::new();
    let mut scripts = vec![];
    let mut cmds = vec![];
    let mut interactive = false;
    let mut gtk = false;
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "-f" | "-file" => {
                scripts.push(args.get(i + 1).cloned().unwrap_or_default());
                i += 1;
            }
            "-x" => {
                cmds.push(args.get(i + 1).cloned().unwrap_or_default());
                i += 1;
            }
            o @ ("-l" | "-log" | "-output_log_file") => {
                // removed: the run always logs to rsynth.run.log / rsynth.cmd.log
                warn!("CMD-006", "Option {} was removed: rsynth writes rsynth.run.log and rsynth.cmd.log by default; use set_log_filename <file.log> / set_cmd_filename <file.cmd> to name them", o);
                if args.get(i + 1).map(|v| !v.starts_with('-')).unwrap_or(false) { i += 1; }
            }
            "-nolog" | "-no_log" | "--nolog" => {}
            o @ ("-opc" | "--opc" | "-opc_rules") => {
                // moved to the routing commands
                warn!("CMD-007", "Option {} was removed from the rsynth command line: give the OPC / litho rules to the routing commands (route_auto / route_detail / route_opt -opc <opc_fill.rules>, or read_opc_rules)", o);
                if args.get(i + 1).map(|v| !v.starts_with('-')).unwrap_or(false) { i += 1; }
            }
            "-no_gui" | "--no_gui" => interactive = true,
            "-i" => {
                // former name of -no_gui
                warn!("CMD-002", "Option -i is now -no_gui");
                interactive = true;
            }
            "-gui" | "--gui" | "-g" | "-gtk_gui" | "--gtk_gui" | "-gtk" => gtk = true,
            o @ ("-html_gui" | "--html_gui" | "-no_browser" | "--no_browser") => {
                // the browser GUI was removed: the GTK GUI is the only GUI
                warn!("CMD-003", "Option {} was removed (the HTML GUI is no longer supported); use -gui", o);
            }
            o @ ("-gui_port" | "--gui_port") => {
                warn!("CMD-003", "Option {} was removed (the HTML GUI is no longer supported); use -gui", o);
                i += 1;
            }
            _ => {}
        }
        i += 1;
    }
    out!("\n                     RSynth  v{}  —  MMMC physical synthesis & timing\n          (RSynth command set; see 'help')\n", env!("CARGO_PKG_VERSION"));
    let mut rc = 0;
    for c in cmds {
        if let Err(e) = s.eval(&c) {
            report(e);
            rc = 1;
        }
    }
    for f in &scripts {
        match std::fs::read_to_string(f) {
            Ok(src) => {
                if let Err(e) = s.eval(&src) {
                    report(e);
                    rc = 1;
                }
            }
            Err(e) => {
                error!("CMD-001", "Cannot open script '{}': {}", f, e);
                rc = 1;
            }
        }
        if s.exit {
            break;
        }
    }
    if gtk && !s.exit {
        #[cfg(feature = "gtk")]
        {
            s = gtkgui::run(s);
        }
        #[cfg(not(feature = "gtk"))]
        {
            // no GUI in this build: stay in the shell
            error!("GUI-100", "This rsynth was built without the GUI (cargo build --release --features gtk); continuing in the shell");
            rc = 1;
            interactive = true;
        }
    }
    if ((scripts.is_empty() && !gtk) || interactive) && !s.exit {
        let stdin = std::io::stdin();
        let mut buf = String::new();
        use std::io::IsTerminal;
        let tty = stdin.is_terminal() && std::io::stdout().is_terminal() && std::env::var("RSYNTH_NO_LINEEDIT").is_err();
        let mut ed = lineedit::Editor::new();
        loop {
            let prompt = if buf.is_empty() { "rsynth> " } else { "...> " };
            let mut line = String::new();
            if tty {
                // command names: registry + aliases + Tcl procs; options: registry + curated syntax
                let mut cmds: Vec<String> = cmdreg::all().iter().flat_map(|c| std::iter::once(c.name).chain(c.aliases.iter().copied())).map(|n| n.to_string()).collect();
                cmds.extend(s.interp.procs.keys().cloned());
                let vars = s.interp.var_names();
                let ss = &s;
                let opts_of = |c: &str| -> Vec<String> {
                    let mut v: Vec<String> = vec![];
                    if let Some(ci) = cmdreg::find(c) {
                        v.extend(ci.options.iter().chain(ci.flags.iter()).map(|o| o.to_string()));
                        for n in std::iter::once(ci.name).chain(ci.aliases.iter().copied()) {
                            if let Some(sx) = ss.curated_syntax(n) {
                                for w in sx.split(|ch: char| ch.is_whitespace() || "[]{}()|,".contains(ch)) {
                                    if w.len() > 1 && w.starts_with('-') && w[1..].chars().next().map(|ch| ch.is_ascii_alphabetic()).unwrap_or(false) { v.push(w.to_string()); }
                                }
                            }
                        }
                    }
                    v
                };
                let mut comp = |l: &str, c: usize| lineedit::complete(l, c, &cmds, &opts_of, &vars);
                match ed.read_line(prompt, &mut comp) {
                    Some(l) => { line = l; line.push('\n'); }
                    None => break,
                }
                ed.add_history(line.trim_end());
            } else {
                print!("{}", prompt);
                let _ = std::io::stdout().flush();
                if stdin.lock().read_line(&mut line).unwrap_or(0) == 0 {
                    break;
                }
            }
            buf.push_str(&line);
            let opens = buf.matches('{').count() as i64 - buf.matches('}').count() as i64;
            if opens > 0 || buf.trim_end().ends_with('\\') {
                continue;
            }
            match s.eval(&buf) {
                Ok(r) => {
                    if !r.is_empty() {
                        match rsynth_display(&r) {
                            Some(d) => println!("{}", d),
                            None => println!("{}", r),
                        }
                    }
                }
                Err(e) => report(e),
            }
            buf.clear();
            if s.exit {
                break;
            }
        }
    }
    log::summary();
    metrics::finish(&mut s);
    std::process::exit(if log::count(log::Sev::Error) > 0 { rc.max(0) } else { rc });
}

fn report(e: tcl::Flow) {
    if let tcl::Flow::Err(m) = e {
        error!("CMD-013", "{}", m);
    }
}

/// Fusion Compiler style echo of a collection: {"a", "b", ...}
fn rsynth_display(r: &str) -> Option<String> {
    let v = cons::collection_names(r)?;
    Some(format!("{{{}}}", v.iter().map(|n| format!("\"{}\"", n)).collect::<Vec<_>>().join(", ")))
}
