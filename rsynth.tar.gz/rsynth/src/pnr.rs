//! Place-and-route commands: legalization / detailed placement, clock tree synthesis (clock_opt),
//! detailed routing (route_auto / route_detail), post-route optimization (route_opt).

use crate::netlist::*;
use crate::session::*;
use crate::tcl::{split_list, Flow};

type R = Result<String, Flow>;

fn err<T: Into<String>>(m: T) -> R {
    Err(Flow::Err(m.into()))
}

impl Session {
    pub(crate) fn site_w(&self) -> f64 {
        let v = self.appf("place.site_width");
        if v > 0.0 { v } else { 0.2 }
    }
    pub(crate) fn row_h(&self) -> f64 {
        let v = self.fp.as_ref().map(|f| f.row_h).unwrap_or(0.0);
        if v > 0.0 { v } else { 1.6 }
    }

    /// run `f` with a legalization context
    fn with_legal<T>(&mut self, f: impl FnOnce(&mut Netlist, &crate::legal::LegalCtx) -> T) -> Result<T, Flow> {
        let (row_h, site_w, msz) = (self.row_h(), self.site_w(), self.appf("place.macro_default_size"));
        let fp = self.fp.take().ok_or_else(|| Flow::Err("No floorplan (FP-001)".into()))?;
        let libs = &self.libs;
        let area = |c: &Cell| -> f64 {
            match &c.kind {
                Kind::Lib(l) => libs.iter().find_map(|x| x.cells.get(l)).map(|x| x.area).unwrap_or(1.0),
                _ => 0.0,
            }
        };
        let lef = &self.lef;
        let rect_of = |c: &Cell| -> Option<crate::lef::Rect> { crate::lef::cell_rect(lef, c) };
        // rows cover the core (the legalizer keeps one row of margin inside the given box)
        let region = fp.core.map(|c| (c.0 - row_h, c.1 - row_h, c.2 + row_h, c.3 + row_h)).unwrap_or(fp.die);
        let r = match self.nl.as_mut() {
            Some(nl) => {
                let cx = crate::legal::LegalCtx { die: region, row_h, site_w, pblk: &fp.pblk, bounds: &fp.bounds, area: &area, macro_size: if msz > 0.0 { msz } else { 16.0 }, rect_of: &rect_of, rows: if fp.rows_explicit && !fp.row_list.is_empty() { Some(&fp.row_list) } else { None } };
                Ok(f(nl, &cx))
            }
            None => Err(Flow::Err("no design".into())),
        };
        self.fp = Some(fp);
        r
    }

    /// Legalize (full or ECO) and optionally run detailed placement.
    pub(crate) fn fp_legalize(&mut self, eco: Option<Vec<CellId>>, detail: bool, quiet: bool) -> Result<crate::legal::LegalStats, Flow> {
        let passes = self.appu("place.detail.passes").max(1);
        let (st, dp) = self.with_legal(|nl, cx| {
            let (st, mut rows) = crate::legal::legalize(nl, cx, eco.as_deref());
            let dp = if detail { Some(crate::legal::detail_place(nl, cx, &mut rows, passes)) } else { None };
            (st, dp)
        })?;
        if !st.failed.is_empty() {
            crate::error!("PLC-310", "Legalization could not place {} cell(s) (no free legal sites in their region): {}", st.failed.len(), abbrev_list(&st.failed, 6));
        }
        if !quiet {
            crate::info!("PLC-300", "{}: {} cell(s) on rows/sites, {} moved, avg displacement {:.3}um, max {:.3}um, HPWL {:.1} -> {:.1}um", if eco.is_some() { "ECO legalization" } else { "Legalization" }, st.cells, st.moved, st.avg_disp, st.max_disp, st.hpwl_before, st.hpwl_after);
            if let Some((m, s, b, a)) = dp {
                crate::info!("PLC-301", "Detailed placement: {} move(s), {} swap(s), HPWL {:.1} -> {:.1}um ({:+.1}%)", m, s, b, a, if b > 0.0 { 100.0 * (a - b) / b } else { 0.0 });
            }
        }
        Ok(st)
    }

    /// cells that are not on legal sites (for ECO legalization after optimization)
    pub(crate) fn illegal_cells(&mut self) -> Result<Vec<CellId>, Flow> {
        let v = self.with_legal(|nl, cx| {
            let (_, viol) = crate::legal::check(nl, cx);
            let names: Vec<String> = viol.iter().filter_map(|v| v.split(':').next().map(|s| s.to_string())).collect();
            names.iter().filter_map(|n| nl.cell_by_name(n)).collect::<Vec<_>>()
        })?;
        Ok(v)
    }

    /// clock root nets of all modes (primary clock sources and generated-clock source pins)
    fn clock_roots(&self) -> Vec<NetId> {
        let Some(nl) = self.nl.as_ref() else { return vec![] };
        let mut v = vec![];
        for m in &self.modes {
            for c in &m.sdc.clocks {
                for s in &c.sources {
                    let n = match s {
                        crate::cons::Obj::Port(p) => nl.port_by_name(p).and_then(|q| nl.ports[q].net),
                        crate::cons::Obj::Pin(p) => nl.find_pin(p).and_then(|q| nl.pin_net(q)),
                        _ => None,
                    };
                    if let Some(n) = n {
                        if !v.contains(&n) {
                            v.push(n);
                        }
                    }
                }
            }
        }
        v
    }

    fn cts_lib(&self, key: &str) -> Vec<crate::liberty::LibCell> {
        let names = self.app.get(key).cloned().unwrap_or_default();
        let mut v: Vec<crate::liberty::LibCell> = split_list(&names).iter().filter_map(|n| self.libs.iter().find_map(|l| l.cells.get(n)).cloned()).collect();
        v.sort_by(|a, b| a.drive.partial_cmp(&b.drive).unwrap_or(std::cmp::Ordering::Equal));
        v
    }

    /// register / macro clock pins reachable from a clock net (through clock buffers, ICGs, logic)
    fn reg_sinks_below(&self, start: NetId) -> Vec<PinRef> {
        let nl = self.nl.as_ref().unwrap();
        let libs = &self.libs;
        let mut out = vec![];
        let mut st = vec![start];
        let mut vis = std::collections::HashSet::new();
        while let Some(n) = st.pop() {
            if !vis.insert(n) {
                continue;
            }
            for l in nl.loads(n) {
                let PinRef::Cell(c, p) = l else { continue };
                let cl = nl.cell(c);
                let lc = cl.lib().and_then(|x| libs.iter().find_map(|y| y.cells.get(x)));
                let is_ck = lc.and_then(|lc| lc.pin(&cl.pins[p].name)).map(|x| x.is_clock).unwrap_or(false);
                let seq = lc.map(|x| x.seq.is_some()).unwrap_or(false) || matches!(cl.kind, Kind::BlackBox(_));
                if seq {
                    if is_ck || matches!(cl.kind, Kind::BlackBox(_)) {
                        out.push(l);
                    }
                    continue;
                }
                for q in &cl.pins {
                    if q.dir == Dir::Out {
                        if let Some(o) = q.net {
                            st.push(o);
                        }
                    }
                }
            }
        }
        out
    }

    /// clock latency (max over clocks, late) at each pin, from the first active setup scenario
    fn sink_latency(&self, pins: &[PinRef]) -> Result<std::collections::HashMap<PinRef, (f64, f64)>, Flow> {
        let si = (0..self.scens.len()).find(|&i| self.scens[i].active && self.scens[i].setup).unwrap_or(0);
        self.with_timing(si, |t| {
            let mut m = std::collections::HashMap::new();
            for p in pins {
                if let Some(&u) = t.idx.get(p) {
                    let tg = &t.ctags[u as usize];
                    if !tg.is_empty() {
                        let mx = tg.iter().map(|c| c.lmax).fold(f64::MIN, f64::max);
                        let mn = tg.iter().map(|c| c.lmin).fold(f64::MAX, f64::min);
                        m.insert(*p, (mx, mn));
                    }
                }
            }
            m
        })
    }

    pub(crate) fn set_all_propagated(&mut self, v: bool) {
        for m in self.modes.iter_mut() {
            for c in m.sdc.clocks.iter_mut() {
                if !c.is_virtual() {
                    c.propagated = v;
                }
            }
        }
    }

    /// Clock tree synthesis + skew balancing. Returns (trees, buffers, delay cells, skew, latency).
    pub(crate) fn run_cts(&mut self) -> Result<(usize, usize, usize, f64, f64), Flow> {
        if self.fp.is_none() {
            return Err(Flow::Err("CTS requires a placed design with a floorplan (FP-001)".into()));
        }
        let bufs = self.cts_lib("cts.buffers");
        if bufs.is_empty() {
            return Err(Flow::Err("CTS: no usable clock buffers (set_clock_tree_options -buffers / set_lib_cell_purpose -include cts) (CTS-001)".into()));
        }
        let dcells = { let d = self.cts_lib("cts.delay_cells"); if d.is_empty() { vec![bufs[0].clone()] } else { d } };
        if self.nl.as_ref().map(|n| n.cell_ids().iter().any(|c| n.cell(*c).has_attr("cts"))).unwrap_or(false) {
            let n = crate::cts::remove_trees(self.nl.as_mut().unwrap());
            crate::info!("CTS-010", "Removed {} cell(s) of the previous clock trees", n);
        }
        let o = crate::cts::CtsOpts { max_fanout: self.appu("cts.max_fanout").max(2), max_cap: self.appf("cts.max_capacitance"), c_per_um: self.appf("time.wire_c_per_um"), bufs };
        let roots = self.clock_roots();
        let spec = self.effective_ctspec();
        let exc = spec.exc();
        let trees = crate::cts::trace_ex(self.nl.as_ref().unwrap(), &self.libs, &roots, &exc);
        if !exc.ignore.is_empty() || !exc.leaf.is_empty() || !exc.through.is_empty() {
            crate::info!("CTS-430", "Clock tree exceptions: {} ignore, {} leaf, {} through, {} float pin(s)", spec.ignore_pins.len(), spec.leaf_pins.len(), spec.through_pins.len(), spec.float_pins.len());
        }
        // clock of each root net (for balance groups and latency targets)
        let root_clocks: std::collections::HashMap<NetId, Vec<String>> = {
            let nl = self.nl.as_ref().unwrap();
            let mut m: std::collections::HashMap<NetId, Vec<String>> = Default::default();
            for md in &self.modes { for c in &md.sdc.clocks { for so in &c.sources {
                let n = match so { crate::cons::Obj::Port(p) => nl.port_by_name(p).and_then(|q| nl.ports[q].net), crate::cons::Obj::Pin(p) => nl.find_pin(p).and_then(|q| nl.pin_net(q)), _ => None };
                if let Some(n) = n { let e = m.entry(n).or_default(); if !e.contains(&c.name) { e.push(c.name.clone()); } }
            } } }
            m
        };
        let mut net_root: std::collections::HashMap<NetId, NetId> = Default::default();
        let mut leaves: Vec<(CellId, Vec<PinRef>)> = vec![];
        let mut nbuf = 0;
        let mut ntrees = 0;
        let mut cts_nets = vec![];
        let mut skipped_dt = 0;
        for (k, (net, sinks, root)) in trees.iter().enumerate() {
            let nl = self.nl.as_mut().unwrap();
            if !nl.net_alive(*net) {
                continue;
            }
            if nl.net(*net).dont_touch {
                if spec.honor_dont_touch {
                    skipped_dt += 1;
                    continue;
                }
                nl.net_mut(*net).dont_touch = false;
            }
            net_root.insert(*net, *root);
            let prefix = format!("cts{}", k);
            let (st, lv) = crate::cts::build(nl, &self.libs, &o, *net, sinks, &prefix);
            crate::info!("CTS-100", "Clock net '{}': {} sink(s), {} buffer(s), {} level(s)", st.net, st.sinks, st.buffers, st.levels);
            nbuf += st.buffers;
            ntrees += 1;
            cts_nets.push(st.net.clone());
            leaves.extend(lv);
        }
        if skipped_dt > 0 {
            crate::info!("CTS-431", "honor_dont_touch: {} dont_touch clock net(s) left as they are", skipped_dt);
        }
        self.cts_nets = cts_nets;
        self.set_all_propagated(true);
        let new: Vec<CellId> = self.nl.as_ref().unwrap().cell_ids().into_iter().filter(|c| self.nl.as_ref().unwrap().cell(*c).has_attr("cts")).collect();
        self.fp_legalize(Some(new), false, true)?;
        self.fp_route(true)?;
        // skew balancing on leaf clusters (register sinks below each leaf buffer)
        let target = self.appf("cts.target_skew");
        let iters = self.appu("cts.balance_iterations");
        // leaf clusters with their register sinks, plus leaf / float pins (exceptions)
        let leaf_net_of: std::collections::HashMap<CellId, NetId> = {
            let nl = self.nl.as_ref().unwrap();
            leaves.iter().filter_map(|(b, _)| {
                let inp = nl.cell(*b).pins.iter().find(|p| p.dir == Dir::In).and_then(|p| p.net)?;
                Some((*b, inp))
            }).collect()
        };
        let all_leaf_sinks: Vec<(CellId, Vec<PinRef>)> = leaves.iter().map(|(b, _)| {
            let nl = self.nl.as_ref().unwrap();
            let on = nl.cell(*b).pins.iter().find(|p| p.dir == Dir::Out).and_then(|p| p.net);
            let mut v = on.map(|n| self.reg_sinks_below(n)).unwrap_or_default();
            if let Some(n) = on { for l in nl.loads(n) { if exc.leaf.contains(&nl.pin_name(l)) && !v.contains(&l) { v.push(l); } } }
            (*b, v)
        }).filter(|(_, v)| !v.is_empty()).collect();
        // balance groups: clocks listed together share one skew target, other clocks are balanced
        // on their own; without groups every clock tree is balanced together
        let group_of = |me: &Self, b: CellId| -> String {
            if spec.balance_groups.is_empty() { return "all".into(); }
            let nl = me.nl.as_ref().unwrap();
            // the leaf's tree net -> its root -> clock(s)
            let mut n = leaf_net_of.get(&b).copied();
            let mut hops = 0;
            while let Some(x) = n {
                if let Some(r) = net_root.get(&x) {
                    let cks = root_clocks.get(r).cloned().unwrap_or_default();
                    for (g, l) in &spec.balance_groups { if cks.iter().any(|c| l.contains(c)) { return g.clone(); } }
                    return cks.first().cloned().unwrap_or_else(|| "other".into());
                }
                // walk up through inserted buffers
                n = nl.driver(x).and_then(|d| if let PinRef::Cell(c, _) = d { nl.cell(c).pins.iter().find(|p| p.dir == Dir::In).and_then(|p| p.net) } else { None });
                hops += 1;
                if hops > 64 { break; }
            }
            "other".into()
        };
        let mut groups: Vec<(String, Vec<(CellId, Vec<PinRef>)>)> = vec![];
        for ls in all_leaf_sinks {
            let g = group_of(self, ls.0);
            match groups.iter_mut().find(|x| x.0 == g) { Some(x) => x.1.push(ls), None => groups.push((g, vec![ls])) }
        }
        if groups.len() > 1 {
            crate::info!("CTS-432", "Balancing {} skew group(s): {}", groups.len(), groups.iter().map(|g| format!("{} ({} leaf)", g.0, g.1.len())).collect::<Vec<_>>().join(", "));
        }
        let mut ndel = 0;
        let (mut skew_all, mut lat_all) = (0.0f64, 0.0f64);
        for (gname, leaf_sinks) in groups {
        let all: Vec<PinRef> = leaf_sinks.iter().flat_map(|x| x.1.clone()).collect();
        let fdel: std::collections::HashMap<PinRef, f64> = {
            let nl = self.nl.as_ref().unwrap();
            all.iter().filter_map(|p| { let d = spec.float_delay(&nl.pin_name(*p)); if d != 0.0 { Some((*p, d)) } else { None } }).collect()
        };
        let skew_lat = |me: &Self| -> Result<(f64, f64, Vec<(CellId, f64)>), Flow> {
            let mut lat = me.sink_latency(&all)?;
            // float pins: add the insertion delay inside the macro / block
            for (p, d) in &fdel { if let Some(v) = lat.get_mut(p) { v.0 += d; v.1 += d; } }
            let mut gmax = f64::MIN;
            let mut gmin = f64::MAX;
            let mut per = vec![];
            for (b, v) in &leaf_sinks {
                let l: Vec<f64> = v.iter().filter_map(|p| lat.get(p).map(|x| x.0)).collect();
                if l.is_empty() {
                    continue;
                }
                let mx = l.iter().cloned().fold(f64::MIN, f64::max);
                let mn = l.iter().cloned().fold(f64::MAX, f64::min);
                gmax = gmax.max(mx);
                gmin = gmin.min(mn);
                per.push((*b, mx));
            }
            Ok((if gmax > gmin { gmax - gmin } else { 0.0 }, gmax.max(0.0), per))
        };
        let (mut skew, mut lat, mut per) = skew_lat(self)?;
        crate::info!("CTS-200", "Before balancing{}: global skew {:.4}ns, max latency {:.4}ns over {} sink(s)", if gname == "all" { String::new() } else { format!(" ({})", gname) }, skew, lat, all.len());
        let mut step = 0.0f64; // measured delay of one delay cell
        for it in 0..iters {
            if skew <= target {
                break;
            }
            let gmax = per.iter().map(|x| x.1).fold(f64::MIN, f64::max);
            let thr = if step > 0.0 { (step * 0.6).max(target / 2.0) } else { target / 2.0 };
            let early: Vec<(CellId, f64)> = per.iter().filter(|(_, l)| gmax - *l > thr).cloned().collect();
            if early.is_empty() {
                break;
            }
            let nl = self.nl.as_mut().unwrap();
            let mut batch: Vec<CellId> = vec![];
            let chain = |gap: f64| -> usize { if step > 1e-4 { ((gap - target / 2.0) / step * 0.8).floor().clamp(1.0, 12.0) as usize } else { 1 } };
            for (b, l) in &early {
                // chain length from the measured delay of one cell (damped; one cell until it is known)
                batch.extend(crate::cts::add_delay_chain(nl, *b, &dcells[0], &format!("cts_dly{}_", it), chain(gmax - *l)));
            }
            ndel += batch.len();
            let (s2, l2, p2) = skew_lat(self)?;
            // measured average delay added per inserted cell
            let mut inc = vec![];
            for (b, l0) in &early {
                if let Some(x) = p2.iter().find(|x| x.0 == *b) {
                    let k = if step > 1e-4 { ((gmax - *l0 - target / 2.0) / step * 0.8).floor().clamp(1.0, 12.0) } else { 1.0 };
                    inc.push((x.1 - l0) / k);
                }
            }
            if !inc.is_empty() {
                step = inc.iter().sum::<f64>() / inc.len() as f64;
            }
            if s2 > skew + 1e-4 {
                // revert this batch and stop
                crate::cts::remove_cells(self.nl.as_mut().unwrap(), &batch);
                ndel -= batch.len();
                crate::info!("CTS-211", "Balancing iteration {} would increase skew ({:.4} -> {:.4}ns); reverted and stopped", it + 1, skew, s2);
                break;
            }
            crate::info!("CTS-210", "Balancing iteration {}: {} delay cell(s), skew {:.4} -> {:.4}ns (step {:.4}ns)", it + 1, early.len(), skew, s2, step);
            skew = s2;
            lat = l2;
            per = p2;
        }
        // latency target of the group: lengthen every leaf of a group that is too fast
        let tgt = if gname == "all" { spec.target_latency } else {
            spec.balance_groups.iter().find(|g| g.0 == gname).map(|g| g.1.clone()).unwrap_or_else(|| vec![gname.clone()]).iter().filter_map(|c| spec.latency_of(c)).reduce(f64::max)
        };
        if let Some(t) = tgt {
            if t > 0.0 && lat + target.max(0.01) < t && !per.is_empty() {
                // measure one delay cell first (unless balancing did), then fill the rest of the gap
                let mut batch = vec![];
                let mut cur = lat;
                let mut st = step;
                if st <= 1e-4 {
                    let nl = self.nl.as_mut().unwrap();
                    for (b, _) in &per { batch.extend(crate::cts::add_delay_chain(nl, *b, &dcells[0], "cts_lat_", 1)); }
                    let (_, l1, _) = skew_lat(self)?;
                    st = (l1 - cur).max(1e-3);
                    cur = l1;
                }
                // a few measured rounds (the delay of a chain cell depends on its neighbours)
                let mut tot = batch.len() / per.len().max(1);
                for _round in 0..4 {
                    let k = ((t - cur) / st).floor().clamp(0.0, 24.0 - tot as f64) as usize;
                    if k == 0 { break; }
                    let nl = self.nl.as_mut().unwrap();
                    for (b, _) in &per { batch.extend(crate::cts::add_delay_chain(nl, *b, &dcells[0], "cts_lat_", k)); }
                    tot += k;
                    let (_, l1, _) = skew_lat(self)?;
                    st = ((l1 - cur) / k as f64).max(1e-3);
                    cur = l1;
                }
                ndel += batch.len();
                let (s2, l2, p2) = skew_lat(self)?;
                crate::info!("CTS-220", "Latency target {:.4}ns{}: {} delay cell(s) on {} leaf cluster(s), latency {:.4} -> {:.4}ns, skew {:.4}ns", t, if gname == "all" { String::new() } else { format!(" ({})", gname) }, batch.len(), per.len(), lat, l2, s2);
                skew = s2; lat = l2; per = p2;
            } else if t > 0.0 && lat > t + target.max(0.01) {
                crate::warn!("CTS-221", "Latency {:.4}ns{} exceeds the target {:.4}ns", lat, if gname == "all" { String::new() } else { format!(" ({})", gname) }, t);
            }
        }
        let _ = &per;
        skew_all = skew_all.max(skew);
        lat_all = lat_all.max(lat);
        }
        let (skew, lat) = (skew_all, lat_all);
        let new: Vec<CellId> = self.nl.as_ref().unwrap().cell_ids().into_iter().filter(|c| self.nl.as_ref().unwrap().cell(*c).has_attr("cts_delay")).collect();
        if !new.is_empty() {
            self.fp_legalize(Some(new), false, true)?;
        }
        Ok((ntrees, nbuf, ndel, skew, lat))
    }

    /// scenario for clock-tree analysis: -scenario/-scenarios, else the first active setup scenario
    fn ctree_scen(&self, x: &A) -> Result<usize, Flow> {
        if let Some(n) = x.get("-scenario").or(x.get("-scenarios")) {
            let n = split_list(n).into_iter().next().unwrap_or_default();
            return (0..self.scens.len()).find(|&i| self.scens[i].name == n).ok_or_else(|| Flow::Err(format!("Scenario '{}' does not exist (MV-SCN)", n)));
        }
        (0..self.scens.len()).find(|&i| self.scens[i].active && self.scens[i].setup).or(if self.scens.is_empty() { None } else { Some(0) }).ok_or_else(|| Flow::Err("no scenario for clock analysis (MV-SCN)".into()))
    }

    /// clock trees of the clock-analysis scenario, for the GUI clock tree browser
    #[cfg_attr(not(feature = "gtk"), allow(dead_code))]
    pub(crate) fn gui_clock_trees(&self) -> Result<(String, Vec<crate::ctree::Tree>), Flow> {
        let si = self.ctree_scen(&args(&[], &[]))?;
        Ok((self.scens[si].name.clone(), self.clock_trees(si, &[])?))
    }

    pub(crate) fn clock_trees(&self, si: usize, pats: &[String]) -> Result<Vec<crate::ctree::Tree>, Flow> {
        self.with_timing(si, |t| {
            (0..t.cons.clocks.len())
                .filter(|&ci| pats.is_empty() || pats.iter().any(|p| crate::netlist::glob(p, &t.cons.clocks[ci].name)))
                .filter_map(|ci| crate::ctree::build(t, ci))
                .filter(|tr| tr.sinks().count() > 0 || !pats.is_empty())
                .collect()
        })
    }

    fn ctree_args(a: &[String]) -> A {
        args(a, &["-type", "-clocks", "-clock", "-scenario", "-scenarios", "-max_level", "-nworst", "-bins", "-output", "-max_transition", "-max_capacitance", "-max_fanout"])
    }

    /// report_clock_qor [-type summary|structure|level|latency|histogram|drc_violators|all] [-clocks c] [-scenario s]
    ///                  [-max_level n] [-show_sinks] [-nworst n] [-verbose] [-bins n]
    fn report_clock_qor(&self, a: &[String]) -> R {
        let x = Self::ctree_args(a);
        let ty = x.get("-type").cloned().unwrap_or("summary".into());
        const TYPES: &[&str] = &["summary", "structure", "level", "latency", "histogram", "drc_violators", "all"];
        let ty = if ty == "levels" { "level".to_string() } else if ty == "drc" { "drc_violators".into() } else { ty };
        if !TYPES.contains(&ty.as_str()) {
            return Err(Flow::Err(format!("report_clock_qor: unknown -type '{}' (use {}) (CMD-010)", ty, TYPES.join("|"))));
        }
        let pats: Vec<String> = x.get("-clocks").or(x.get("-clock")).map(|s| split_list(s)).unwrap_or_default().into_iter().chain(x.pos.iter().flat_map(|p| split_list(p))).collect();
        let si = self.ctree_scen(&x)?;
        let trees = self.clock_trees(si, &pats)?;
        let scen = self.scens[si].name.clone();
        let nl = self.nl()?;
        crate::out!("\n****************************************\nReport : clock_qor -type {}\nDesign : {}\n****************************************", ty, nl.name);
        if trees.is_empty() {
            crate::warn!("CTS-400", "No clock trees to report (no clocks with sources{})", if pats.is_empty() { "" } else { " matching the -clocks pattern" });
            return Ok("0".into());
        }
        let all = ty == "all";
        let mut out = String::new();
        if ty == "summary" || all {
            let cts_cells: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| nl.cell(*c).has_attr("cts")).collect();
            out += &format!("  CTS-inserted cells: {} ({} balancing delay cells)\n", cts_cells.len(), cts_cells.iter().filter(|c| nl.cell(**c).has_attr("cts_delay")).count());
            out += &crate::ctree::report_summary(&trees, &scen);
        }
        let ml = x.num("-max_level").map(|v| v as usize).unwrap_or(usize::MAX);
        for t in &trees {
            if ty == "level" || all {
                out += &crate::ctree::report_levels(t);
            }
            if ty == "structure" || all {
                out += &crate::ctree::report_structure(t, ml, x.has("-show_sinks"));
            }
            if ty == "latency" || all {
                out += &crate::ctree::report_latency(t, x.num("-nworst").map(|v| v as usize).unwrap_or(10), x.has("-verbose"));
            }
            if ty == "histogram" || all {
                out += &crate::ctree::report_histogram(t, x.num("-bins").map(|v| v as usize).unwrap_or(10).max(1));
            }
        }
        let mut nv = 0;
        if ty == "drc_violators" || all {
            let cons = &self.modes[self.cur_mode].sdc;
            for t in &trees {
                let ck = cons.clocks.iter().find(|c| c.name == t.clock);
                let mtr = x.num("-max_transition").or(ck.and_then(|c| c.max_tran)).unwrap_or(self.appf("cts.max_transition"));
                let mcap = x.num("-max_capacitance").unwrap_or(self.appf("cts.max_capacitance"));
                let mfo = x.num("-max_fanout").map(|v| v as usize).unwrap_or(self.appf("cts.max_fanout") as usize);
                let (s, n) = crate::ctree::report_drc(t, mtr, mcap, mfo);
                out += &s;
                nv += n;
            }
        }
        for l in out.lines() {
            crate::out!("{}", l);
        }
        Ok(if ty == "drc_violators" { nv.to_string() } else { trees.len().to_string() })
    }

    /// clock-tree data (nodes, levels, latencies, placement) as JSON for scripts / external viewers
    fn write_clock_tree(&self, a: &[String]) -> R {
        let x = Self::ctree_args(a);
        let file = x.get("-output").cloned().or(x.pos.first().cloned()).ok_or_else(|| Flow::Err("write_clock_tree: -output <file.json> required (CMD-001)".into()))?;
        let pats: Vec<String> = x.get("-clocks").or(x.get("-clock")).map(|s| split_list(s)).unwrap_or_default();
        let si = self.ctree_scen(&x)?;
        let trees = self.clock_trees(si, &pats)?;
        let die = self.fp.as_ref().map(|f| f.die);
        let j = crate::ctree::to_json(&trees, die, &self.nl()?.name, &self.scens[si].name);
        std::fs::write(&file, j).map_err(|e| Flow::Err(format!("cannot write '{}': {} (FILE-002)", file, e)))?;
        crate::info!("CTS-120", "Wrote clock tree data '{}' ({} clock tree(s), {} node(s))", file, trees.len(), trees.iter().map(|t| t.nodes.len()).sum::<usize>());
        Ok(file)
    }

    /// routing layers with per-layer RC (lower layers thinner / more resistive)
    pub(crate) fn route_layers(&self) -> Vec<crate::droute::RLayer> {
        let r0 = self.appf("time.wire_r_per_um");
        let c0 = self.appf("time.wire_c_per_um");
        let ls = self.fp.as_ref().map(|f| f.layers.clone()).unwrap_or_else(crate::fplan::default_layers);
        let n = ls.len();
        ls.iter().enumerate().map(|(i, l)| {
            let (rm, cm) = if i == 0 { (2.0, 1.1) } else if i + 2 >= n { (0.35, 1.15) } else if i <= 2 { (1.3, 1.0) } else { (1.0, 1.0) };
            crate::droute::RLayer { name: l.name.clone(), horiz: l.horiz, r: r0 * rm, c: c0 * cm }
        }).collect()
    }

    fn new_route_db(&self) -> Result<crate::droute::RouteDb, Flow> {
        let fp = self.fp.as_ref().ok_or_else(|| Flow::Err("routing requires a floorplan (FP-001)".into()))?;
        let g = { let v = self.appf("route.detail.grid"); if v > 0.0 { v } else { self.site_w() / 2.0 } };
        let layers = self.route_layers();
        let nodes = ((fp.die.2 - fp.die.0) / g + 1.0) * ((fp.die.3 - fp.die.1) / g + 1.0) * layers.len() as f64;
        let maxn = self.appf("route.detail.max_grid_nodes");
        if nodes > maxn {
            return Err(Flow::Err(format!("detailed routing grid would have {:.1}M nodes (> route.detail.max_grid_nodes {:.0}M); increase route.detail.grid or the limit (RT-001)", nodes / 1e6, maxn / 1e6)));
        }
        let mut db = crate::droute::RouteDb::new(fp.die, g, layers);
        db.via_r = self.appf("route.via_resistance");
        let lidx = |n: &str| db.layers.iter().position(|l| l.name == n);
        let mut blk: Vec<((f64, f64, f64, f64), Vec<usize>)> = vec![];
        for b in &fp.rblk {
            let ls: Vec<usize> = if b.layers.is_empty() { (0..db.layers.len()).collect() } else { b.layers.iter().filter_map(|l| lidx(l)).collect() };
            blk.push((b.rect, ls));
        }
        // macros obstruct M1..M4 over their footprint
        let nl = self.nl()?;
        let msz = self.appf("place.macro_default_size");
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            // LEF abstract: its obstructions (or the footprint on M1..M4)
            if let (Some(m), Some(r)) = (crate::lef::phys(&self.lef, cl), crate::lef::cell_rect(&self.lef, cl)) {
                if m.obs.is_empty() {
                    blk.push((r, (0..4.min(db.layers.len())).collect()));
                } else {
                    let l = cl.loc.unwrap();
                    for (ly, o) in &m.obs {
                        if let Some(li) = lidx(ly) {
                            blk.push((crate::lef::place_rect(*o, m.w, m.h, crate::lef::orient_of(cl), l), vec![li]));
                        }
                    }
                }
                continue;
            }
            if matches!(cl.kind, Kind::BlackBox(_)) || (cl.fixed && cl.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|x| x.area > 50.0).unwrap_or(false)) {
                if let Some(l) = cl.loc {
                    let a = cl.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|x| x.area).unwrap_or(0.0);
                    let side = if a > 4.0 { a.sqrt() } else { msz };
                    blk.push(((l.0 - side / 2.0, l.1 - side / 2.0, l.0 + side / 2.0, l.1 + side / 2.0), (0..4.min(db.layers.len())).collect()));
                }
            }
        }
        // power / ground special wiring blocks its layer (with the layer spacing); via arrays
        // block both metal layers
        let order = self.metal_order();
        let _ = &order;
        for sh in &fp.special {
            if !crate::pg::is_pg_kind(&sh.kind) { continue; }
            let Some(r) = sh.rect else { continue };
            let ls: Vec<&str> = match &sh.via { Some(v) => vec![v.lower.as_str(), v.upper.as_str()], None => vec![sh.layer.as_str()] };
            for l in ls {
                if let Some(li) = lidx(l) {
                    // spacing of the widest-spaced route rule in use, plus half a grid step for the wire
                    let sm = self.pgx.ndrs.iter().filter(|q| self.pgx.net_ndr.values().any(|v| v == &q.name)).map(|q| q.smul).fold(1.0, f64::max);
                    let sp = self.min_space(l) * sm + g;
                    blk.push(((r.0 - sp, r.1 - sp, r.2 + sp, r.3 + sp), vec![li]));
                }
            }
        }
        for (r, ls) in blk {
            db.block_rect(r, &ls);
        }
        self.apply_tracks(&mut db);
        Ok(db)
    }

    /// routing nets: groups joined through boundary pins, constants skipped
    fn build_rnets(&self, db: &crate::droute::RouteDb, clock_only: bool) -> Result<Vec<crate::droute::RNet>, Flow> {
        let nl = self.nl()?;
        let rh = self.row_h();
        let libs = &self.libs;
        let width = |c: CellId| -> f64 { nl.cell(c).lib().and_then(|l| libs.iter().find_map(|x| x.cells.get(l))).map(|x| x.area / rh).unwrap_or(0.4) };
        let fp = self.fp.as_ref().unwrap();
        let port_layer = |p: &str| -> usize { fp.pin_info.get(p).and_then(|i| db.layers.iter().position(|l| l.name == i.1)).unwrap_or(2) };
        let is_hp = |p: &PinRef| matches!(p, PinRef::Cell(c, _) if nl.cell(*c).is_hport());
        let clock_nets: std::collections::HashSet<NetId> = {
            let mut s: std::collections::HashSet<NetId> = self.cts_nets.iter().filter_map(|n| nl.net_by_name(n)).collect();
            for c in nl.cell_ids() {
                if nl.cell(c).has_attr("cts") {
                    for p in &nl.cell(c).pins {
                        if let Some(n) = p.net {
                            s.insert(n);
                        }
                    }
                }
            }
            s.extend(self.clock_roots());
            s
        };
        let mut out = vec![];
        for n in nl.net_ids() {
            if nl.driver(n).map(|d| is_hp(&d)).unwrap_or(false) || crate::genopt::const_of(nl, n).is_some() {
                continue;
            }
            // group through boundary pins
            let mut grp = vec![n];
            let mut k = 0;
            while k < grp.len() {
                let m = grp[k];
                k += 1;
                for l in nl.loads(m) {
                    if let PinRef::Cell(c, _) = l {
                        if nl.cell(c).is_hport() {
                            if let Some(y) = nl.cell(c).pin_net("Y") {
                                if !grp.contains(&y) {
                                    grp.push(y);
                                }
                            }
                        }
                    }
                }
            }
            let clock = grp.iter().any(|g| clock_nets.contains(g));
            if clock_only && !clock {
                continue;
            }
            // driver first
            let mut pins: Vec<PinRef> = grp.iter().flat_map(|g| nl.net(*g).conns.clone()).filter(|p| !is_hp(p)).collect();
            if let Some(d) = nl.driver(n) {
                if let Some(i) = pins.iter().position(|p| *p == d) {
                    pins.swap(0, i);
                }
            }
            let msz = { let m = self.appf("place.macro_default_size"); if m > 0.0 { m } else { 16.0 } };
            let pn = crate::droute::pin_nodes(db, nl, &width, &port_layer, msz, &pins, &self.lef);
            if pn.len() < 2 {
                continue;
            }
            let sig = crate::droute::sig_of(nl, &pn);
            let ndr = self.ndr_of(&nl.net(n).name, clock);
            out.push(crate::droute::RNet { net: n, tree: vec![], pins: pn, sig, clock, open: false, halo: ndr.map(|r| r.halo()).unwrap_or(0), wmul: ndr.map(|r| r.wmul as f32).unwrap_or(1.0), lmin: self.rt.min_layer.map(|l| l as u8).unwrap_or(0), lmax: self.rt.max_layer.map(|l| l as u8).unwrap_or(0) });
        }
        Ok(out)
    }

    pub(crate) fn refresh_rc(&mut self) {
        let Some(db) = self.routes.as_ref() else { self.routed_rc = None; return };
        let Some(nl) = self.nl.as_ref() else { return };
        let libs = &self.libs;
        let cap = |p: PinRef| -> f64 {
            match p {
                PinRef::Cell(c, i) => nl.cell(c).lib().and_then(|l| libs.iter().find_map(|x| x.cells.get(l))).and_then(|lc| lc.pin(&nl.cell(c).pins[i].name)).map(|x| x.cap).unwrap_or(0.001),
                PinRef::Port(_) => 0.0,
            }
        };
        let name = |p: PinRef| nl.pin_name(p);
        let mode = self.extract_mode();
        self.routed_rc = Some(std::sync::Arc::new(crate::droute::extract_mode(db, &cap, &name, &|p: &PinRef| nl.is_driver(*p), mode)));
    }

    /// Detailed-route clock nets only, or all nets that are unrouted / changed (ECO).
    pub(crate) fn route_nets_kind(&mut self, clock_only: bool) -> Result<crate::droute::RouteStats, Flow> {
        self.route_incremental(clock_only, false)
    }

    pub(crate) fn c_route_opt(&mut self, a: &[String], incremental: bool) -> R {
        self.flow_body = Some(incremental);
        let r = self.pnr_cmd("route_opt", a).unwrap_or(Ok(String::new()));
        self.flow_body = None;
        r
    }
    pub(crate) fn route_incremental(&mut self, clock_only: bool, reroute_all: bool) -> Result<crate::droute::RouteStats, Flow> {
        let mut db = match self.routes.take() {
            Some(d) if !reroute_all => d,
            _ => self.new_route_db()?,
        };
        let all = self.build_rnets(&db, clock_only)?;
        // drop routes of nets that no longer exist
        let live: std::collections::HashSet<NetId> = all.iter().map(|r| r.net).collect();
        if !clock_only {
            let gone: Vec<NetId> = db.nets.keys().filter(|k| !live.contains(k)).copied().collect();
            for k in gone {
                if let Some(old) = db.nets.remove(&k) {
                    for (nd, _) in &old.tree {
                        let o = &mut db.occ[*nd as usize];
                        *o = o.saturating_sub(1);
                    }
                    for (_, nd) in &old.pins {
                        if db.pin_owner[*nd as usize] == k as u32 {
                            db.pin_owner[*nd as usize] = crate::droute::NONE;
                        }
                    }
                }
            }
        }
        let todo: Vec<crate::droute::RNet> = all.into_iter().filter(|r| match db.nets.get(&r.net) {
            Some(old) => old.sig != r.sig || old.open,
            None => true,
        }).collect();
        let nt = todo.len();
        let mut order: Vec<NetId> = vec![];
        if self.rt.timing_driven {
            // most critical nets first: they get the direct paths before congestion builds up
            let sl: std::collections::HashMap<NetId, f64> = self.net_slacks();
            let mut v: Vec<(f64, NetId)> = todo.iter().filter_map(|r| sl.get(&r.net).map(|s| (*s, r.net))).filter(|x| x.0 < f64::MAX / 2.0).collect();
            v.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal).then(a.1.cmp(&b.1)));
            order = v.into_iter().map(|x| x.1).collect();
            if let Some(n0) = order.first() { crate::info!("RT-130", "Timing-driven routing: {} net(s) ordered by slack (most critical '{}')", order.len(), self.nl.as_ref().map(|nl| nl.net(*n0).name.clone()).unwrap_or_default()); }
        }
        let base_it = self.appu("route.detail.max_iterations").max(1);
        let max_iter = match self.rt.effort { 1 => (base_it / 3).clamp(4, 10), 3 => base_it.max(12) * 3 / 2, _ => base_it };
        let layer_cost = self.rt.layer_cost.clone();
        // litho-driven routing (OPC rules): forbidden parallel pitches cost, wrong-way off
        let mut fp_steps: Vec<Vec<i64>> = vec![];
        let mut m1_cost = self.appf("route.detail.wrong_way_cost") as f32;
        if let Some(o) = self.rt.opc.as_ref() {
            for l in &db.layers {
                let ol = o.layer(&l.name);
                let mut v: Vec<i64> = vec![];
                for (a, b) in &ol.forbidden_pitch {
                    let (ka, kb) = ((a / db.g).ceil() as i64, (b / db.g).floor() as i64);
                    for k in ka.max(1)..=kb { v.push(k); }
                }
                fp_steps.push(v);
            }
            if db.layers.iter().skip(1).any(|l| !o.layer(&l.name).wrong_way) { m1_cost = m1_cost.max(20.0); }
        }
        let fp_cost = if fp_steps.iter().any(|v| !v.is_empty()) { self.appf("route.litho.forbidden_pitch_cost") as f32 } else { 0.0 };
        let p = crate::droute::RouteParams { max_iter, via_cost: self.appf("route.detail.via_cost") as f32, m1_cost, adj_cost: if self.rt.opc.is_some() { self.appf("route.litho.spread_cost") as f32 } else { 0.0 }, layer_cost, order, legal_only: false, fp_steps, fp_cost };
        let st = crate::droute::route(&mut db, todo, &p);
        let sc = crate::droute::spacing_conflicts(&db).len();
        crate::info!("RT-100", "Detailed routing{}: {} net(s) (re)routed; total {} routed, {} open, {} short(s){}; wirelength {:.1}um, {} via(s), {} iteration(s)", if clock_only { " (clock nets)" } else { "" }, nt, st.routed, st.opens, st.shorts, if db.space_k.iter().any(|k| *k > 0) { format!(", {} LEF spacing conflict(s)", sc) } else { String::new() }, st.wl, st.vias, st.iterations);
        self.routes = Some(db);
        self.refresh_rc();
        Ok(st)
    }

    pub(crate) fn pnr_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        let r = match name {
            "legalize_placement" => {
                if self.fp.is_none() {
                    return Some(err("legalize_placement: no floorplan (FP-001)"));
                }
                if let Err(e) = self.row_site_precheck("legalize_placement", a) { return Some(Err(e)); }
                let x = args(a, &["-cells"]);
                let eco: Option<Vec<CellId>> = x.get("-cells").map(|c| {
                    let nl = self.nl.as_ref().unwrap();
                    split_list(c).iter().filter_map(|h| crate::cons::Obj::parse(h).map(|o| o.name().to_string()).or(Some(h.clone()))).filter_map(|n| nl.cell_by_name(&n)).collect()
                });
                let eco = if x.has("-incremental") && eco.is_none() { Some(self.illegal_cells().ok()?) } else { eco };
                match self.fp_legalize(eco, !x.has("-no_detail"), false) {
                    Ok(st) => Ok(st.failed.len().to_string()),
                    Err(e) => Err(e),
                }
            }
            "refine_placement" | "place_detail" | "optimize_placement" => {
                if self.fp.is_none() {
                    return Some(err(format!("{}: no floorplan (FP-001)", name)));
                }
                if let Err(e) = self.row_site_precheck(name, a) { return Some(Err(e)); }
                let (sv, a2) = match self.place_options_begin(name, a) { Ok(v) => v, Err(e) => return Some(Err(e)) };
                let x = args(&a2, &["-passes"]);
                let passes = x.num("-passes").map(|v| v as usize).unwrap_or(self.appu("place.detail.passes").max(1));
                let r = self.with_legal(|nl, cx| {
                    let (st, mut rows) = crate::legal::legalize(nl, cx, Some(&[]));
                    let dp = crate::legal::detail_place(nl, cx, &mut rows, passes);
                    (st, dp)
                });
                let r = match r {
                    Ok((_, (m, s, b, a2))) => {
                        crate::info!("PLC-301", "Detailed placement: {} move(s), {} swap(s), HPWL {:.1} -> {:.1}um ({:+.1}%)", m, s, b, a2, if b > 0.0 { 100.0 * (a2 - b) / b } else { 0.0 });
                        Ok(format!("{:.3}", a2))
                    }
                    Err(e) => Err(e),
                };
                let e = self.place_options_end(name, sv);
                r.and_then(|v| e.map(|_| v))
            }
            "check_legality" => {
                if self.fp.is_none() {
                    return Some(err("check_legality: no floorplan (FP-001)"));
                }
                let x = args(a, &[]);
                let verbose = x.has("-verbose");
                match self.with_legal(|nl, cx| crate::legal::check(nl, cx)) {
                    Ok((n, viol)) => {
                        crate::out!("\n****************************************\nReport : check_legality\n****************************************");
                        crate::out!("  Standard cells checked : {}\n  Row height / site      : {:.3}um / {:.3}um\n  Violations             : {}", n, self.row_h(), self.site_w(), viol.len());
                        for v in viol.iter().take(if verbose { usize::MAX } else { 20 }) {
                            crate::out!("    {}", v);
                        }
                        if !verbose && viol.len() > 20 {
                            crate::out!("    ... {} more (-verbose)", viol.len() - 20);
                        }
                        // IO pads / corners / fillers / area IO / macros: geometric overlaps
                        let io = self.report_io_overlaps("check_legality", verbose, true);
                        crate::out!("  IO pad / macro overlaps: {}", io);
                        if viol.is_empty() && io == 0 {
                            crate::info!("PLC-320", "Placement is legal");
                        } else {
                            crate::warn!("PLC-321", "{} legality violation(s){}", viol.len() + io, if io > 0 { format!(" ({} IO pad / macro overlap(s))", io) } else { String::new() });
                        }
                        Ok((viol.len() + io).to_string())
                    }
                    Err(e) => Err(e),
                }
            }
            // ---------------------------------------------------------------- routing
            "route_auto" | "route_detail" | "route_eco" | "route_group" => {
                if let Err(e) = self.route_options(name, a) {
                    return Some(Err(e));
                }
                let x = args(a, &["-max_detail_route_iterations", "-max_iterations", "-effort_level", "-effort", "-min_layer", "-min_routing_layer", "-max_layer", "-max_routing_layer", "-antenna_diode", "-antenna_diode_cell", "-max_buffering_distance", "-opc", "-nets"]);
                if let Some(v) = x.get("-max_detail_route_iterations").or(x.get("-max_iterations")) {
                    self.app.insert("route.detail.max_iterations".into(), v.clone());
                }
                let clock_only = name == "route_group" && (x.has("-all_clock_nets") || x.pos.is_empty());
                let reroute = x.has("-reroute") || (name == "route_auto" && !x.has("-incremental"));
                if name == "route_auto" {
                    if let Err(e) = self.fp_route(true) {
                        return Some(Err(e));
                    }
                }
                if let Err(e) = self.route_incremental(clock_only, reroute) {
                    return Some(Err(e));
                }
                if let Err(e) = self.route_post(name) {
                    return Some(Err(e));
                }
                let st = crate::droute::stats(self.routes.as_ref().unwrap());
                Ok(format!("{} {}", st.opens, st.shorts))
            }
            "route_opt" if self.flow_body.is_some() => {
                let incremental = self.flow_body.take() == Some(true);
                let x = args(a, &["-iterations", "-max_net_length", "-max_buffering_distance", "-spread_fraction", "-opc"]);
                // OPC / litho rules for route_opt's reroutes (line ends, forbidden pitches) and fill
                if let Some(f) = x.get("-opc") {
                    if let Err(e) = self.load_opc(f) {
                        return Some(Err(e));
                    }
                }
                if incremental && self.routes.is_none() {
                    return Some(err("route_opt -incremental: the design is not routed (route_auto first) (OPT-932)"));
                }
                if self.routes.is_none() {
                    crate::info!("RT-300", "route_opt: design not routed yet; running route_auto first");
                    if let Err(e) = self.route_incremental(false, true) {
                        return Some(Err(e));
                    }
                }
                let loops = x.num("-iterations").map(|v| v as usize).unwrap_or(if incremental { 1 } else { self.appu("route_opt.iterations").max(1) });
                let q0 = self.with_env(|nl, env| { let a = env.analyze(nl, 0); (a.wns, a.tns, a.whs, a.ths, a.drv.len()) });
                if let Ok(q) = q0 {
                    crate::out!("  [{:<14}] WNS {:>8.4}  TNS {:>9.4}  WHS {:>8.4}  THS {:>9.4}  DRV {:>4}  (extracted RC)", "post-route", q.0, q.1, q.2, q.3, q.4);
                }
                for it in 0..loops {
                    crate::out!("\n==== route_opt : loop {} ====", it + 1);
                    if let Err(e) = self.stage("final_opto", true) {
                        return Some(Err(e));
                    }
                    let bad = self.illegal_cells().unwrap_or_default();
                    let nb = bad.len();
                    if nb > 0 {
                        if let Err(e) = self.fp_legalize(Some(bad), false, true) {
                            return Some(Err(e));
                        }
                    }
                    let st = match self.route_incremental(false, false) {
                        Ok(s) => s,
                        Err(e) => return Some(Err(e)),
                    };
                    if let Ok(q) = self.with_env(|nl, env| { let a = env.analyze(nl, 0); (a.wns, a.tns, a.whs, a.ths, a.drv.len(), nl.num_cells()) }) {
                        crate::out!("  [route_opt {:<4}] WNS {:>8.4}  TNS {:>9.4}  WHS {:>8.4}  THS {:>9.4}  DRV {:>4}  cells {:>6}  ECO-legalized {:>4}  opens {} shorts {}", it + 1, q.0, q.1, q.2, q.3, q.4, q.5, nb, st.opens, st.shorts);
                    }
                }
                // net-length based buffering on the routed trees
                let ml = x.num("-max_net_length").or(x.num("-max_buffering_distance")).unwrap_or(self.appf("route_opt.flow.max_net_length"));
                if ml > 0.0 {
                    crate::out!("\n==== route_opt : net-length buffering ====");
                    if let Err(e) = self.net_length_buffering(ml, None, "route_opt") {
                        return Some(Err(e));
                    }
                }
                // route_opt's own net-length limit replaces the persisted route -max_buffering_distance
                let keep = self.rt.max_buf_dist;
                if ml > 0.0 { self.rt.max_buf_dist = 0.0; }
                let r = self.route_post("route_opt");
                self.rt.max_buf_dist = keep;
                if let Err(e) = r {
                    return Some(Err(e));
                }
                // yield: 1) wire spreading, 2) single -> multi-cut vias; no new route DRCs
                if x.has("-yield") || self.app.get("route_opt.flow.enable_yield").map(|v| v == "true" || v == "1").unwrap_or(false) {
                    crate::out!("\n==== route_opt : yield (1/2) wire spreading ====");
                    let frac = x.num("-spread_fraction").unwrap_or(self.appf("route_opt.yield.spread_fraction")).clamp(0.01, 1.0);
                    if let Err(e) = self.wire_spreading(frac) {
                        return Some(Err(e));
                    }
                    crate::out!("\n==== route_opt : yield (2/2) via swapping to multi-cut ====");
                    let c0 = match self.route_rule_check(false, false) { Ok(c) => c, Err(e) => return Some(Err(e)) };
                    let save = self.routes.clone();
                    if let Err(e) = self.multicut_vias() {
                        return Some(Err(e));
                    }
                    let c1 = match self.route_rule_check(false, false) { Ok(c) => c, Err(e) => return Some(Err(e)) };
                    if c1.spacing + c1.shorts + c1.cut_spacing > c0.spacing + c0.shorts + c0.cut_spacing {
                        self.routes = save;
                        self.refresh_rc();
                        crate::warn!("RT-521", "route_opt -yield: via swapping would add route DRCs; vias restored");
                    }
                    let st = crate::droute::stats(self.routes.as_ref().unwrap());
                    crate::info!("RT-530", "route_opt -yield: done; route DRCs: shorts {} -> {}, spacing {} -> {}, opens {}", c0.shorts, c1.shorts.min(c0.shorts.max(c1.shorts)), c0.spacing, c1.spacing, st.opens);
                }
                Ok(String::new())
            }
            "route_opt" => return Some(self.with_opt_ctl("route_opt", a, |s, rest, ctl| s.c_route_opt(rest, ctl.map(|c| c.incremental).unwrap_or(false)))),
            "remove_routes" => {
                let n = self.routes.as_ref().map(|d| d.nets.len()).unwrap_or(0);
                self.routes = None;
                self.routed_rc = None;
                crate::info!("RT-110", "Removed detailed routes of {} net(s); timing uses estimated parasitics", n);
                Ok(n.to_string())
            }
            "check_routes" | "report_routing" | "report_route_summary" | "report_design_rule_violations" => {
                let Some(db) = self.routes.as_ref() else { return Some(err(format!("{}: design is not routed (route_auto)", name))) };
                let st = crate::droute::stats(db);
                let nl = match self.nl() { Ok(n) => n, Err(e) => return Some(Err(e)) };
                crate::out!("\n****************************************\nReport : {}\n****************************************", name);
                crate::out!("  Grid pitch {:.3}um, {} x {} x {} layers", db.g, db.nx, db.ny, db.layers.len());
                crate::out!("  Nets routed      : {} / {}", st.routed, st.nets);
                crate::out!("  Open nets        : {}", st.opens);
                crate::out!("  Shorts (overlaps): {}", st.shorts);
                crate::out!("  Wirelength       : {:.1}um   vias: {}", st.wl, st.vias);
                for (i, l) in db.layers.iter().enumerate() {
                    crate::out!("    {:<4} {:>10.1}um  ({})", l.name, st.wl_layer[i], if l.horiz { "H" } else { "V" });
                }
                if name == "check_routes" || name == "report_design_rule_violations" {
                    let opens: Vec<String> = db.nets.values().filter(|r| r.open).map(|r| nl.net(r.net).name.clone()).collect();
                    for o in opens.iter().take(20) {
                        crate::out!("    open: {}", o);
                    }
                    let shorts: Vec<u32> = (0..db.occ.len()).filter(|&k| db.occ[k] > 1).map(|k| k as u32).take(20).collect();
                    for sh in shorts {
                        let (x, y, l) = db.pos(sh);
                        crate::out!("    short: {} at ({:.2}, {:.2})", db.layers[l].name, x, y);
                    }
                    if st.opens + st.shorts == 0 {
                        crate::info!("RT-200", "check_routes: no opens, no shorts");
                    } else {
                        crate::warn!("RT-201", "check_routes: {} open net(s), {} short(s)", st.opens, st.shorts);
                    }
                }
                Ok((st.opens + st.shorts).to_string())
            }
            // ---------------------------------------------------------------- CTS
            "set_clock_tree_options" => {
                let x = args(a, &["-target_skew", "-target_latency", "-max_fanout", "-max_transition", "-max_capacitance", "-buffers", "-delay_cells", "-clocks", "-balance_iterations"]);
                for (o, k) in [("-target_skew", "cts.target_skew"), ("-target_latency", "cts.target_latency"), ("-max_fanout", "cts.max_fanout"), ("-max_transition", "cts.max_transition"), ("-max_capacitance", "cts.max_capacitance"), ("-balance_iterations", "cts.balance_iterations")] {
                    if let Some(v) = x.get(o) {
                        self.app.insert(k.into(), v.clone());
                    }
                }
                for (o, k) in [("-buffers", "cts.buffers"), ("-delay_cells", "cts.delay_cells")] {
                    if let Some(v) = x.get(o) {
                        let names: Vec<String> = split_list(v).iter().map(|h| crate::cons::Obj::parse(h).map(|o| o.name().rsplit('/').next().unwrap_or("").to_string()).unwrap_or(h.clone())).collect();
                        self.app.insert(k.into(), names.join(" "));
                    }
                }
                Ok(String::new())
            }
            "set_lib_cell_purpose" => {
                let x = args(a, &["-include", "-exclude"]);
                let cells: Vec<String> = x.pos.iter().flat_map(|p| split_list(p)).map(|h| crate::cons::Obj::parse(&h).map(|o| o.name().rsplit('/').next().unwrap_or("").to_string()).unwrap_or(h)).collect();
                let key = "cts.buffers";
                let mut cur: Vec<String> = split_list(&self.app.get(key).cloned().unwrap_or_default());
                if x.get("-include").map(|v| v.contains("cts")).unwrap_or(false) {
                    for c in cells {
                        if !cur.contains(&c) {
                            cur.push(c);
                        }
                    }
                } else if x.get("-exclude").map(|v| v.contains("cts")).unwrap_or(false) {
                    cur.retain(|c| !cells.contains(c));
                }
                self.app.insert(key.into(), cur.join(" "));
                Ok(cur.len().to_string())
            }
            "report_clock_qor" => self.report_clock_qor(a),
            "report_clock_tree" => {
                // ICC-style: report_clock_tree [-summary|-structure|-level|-latency|-histogram|-drc_violators] [-clock c] ...
                let x = Self::ctree_args(a);
                let ty = ["structure", "level", "latency", "histogram", "drc_violators", "summary"].iter().find(|t| x.has(&format!("-{}", t))).copied().unwrap_or("structure");
                let mut v: Vec<String> = vec!["-type".into(), ty.into()];
                v.extend(a.iter().filter(|s| *s != &format!("-{}", ty)).cloned());
                self.report_clock_qor(&v)
            }
            "write_clock_tree" => self.write_clock_tree(a),
            "clock_opt" if self.flow_body.is_none() => return Some(self.with_opt_ctl("clock_opt", a, |s, rest, ctl| {
                s.flow_body = Some(ctl.map(|c| c.incremental).unwrap_or(false));
                let r = s.pnr_cmd("clock_opt", rest).unwrap_or(Ok(String::new()));
                s.flow_body = None;
                r
            })),
            "synthesize_clock_trees" | "clock_opt" | "remove_clock_trees" | "report_clock_timing" => {
                let x = args(a, &["-from", "-to", "-type", "-nworst", "-spec", "-spec_file", "-write_spec", "-trace_file"]);
                // clock tree specification / tracing options of clock_opt and synthesize_clock_trees
                if name != "remove_clock_trees" && name != "report_clock_timing" {
                    if let Some(f) = x.get("-spec").or(x.get("-spec_file")).cloned() {
                        if let Some(Err(e)) = self.cmd("read_clock_tree_spec", &[f]) { return Some(Err(e)); }
                    }
                    if let Some(f) = x.get("-write_spec").cloned() {
                        if let Some(Err(e)) = self.cmd("write_clock_tree_spec", &["-file".into(), f]) { return Some(Err(e)); }
                        if x.has("-spec_only") { return Some(Ok(String::new())); }
                    }
                    if x.has("-trace") || x.has("-trace_only") || x.has("-trace_file") {
                        let mut v: Vec<String> = vec![];
                        if let Some(f) = x.get("-trace_file") { v.push("-file".into()); v.push(f.clone()); }
                        match self.cmd("trace_clock_tree", &v) { Some(Err(e)) => return Some(Err(e)), _ => {} }
                        if x.has("-trace_only") { return Some(Ok(String::new())); }
                    }
                }
                match name {
                    "remove_clock_trees" => {
                        let Some(nl) = self.nl.as_mut() else { return Some(err("no design")) };
                        let n = crate::cts::remove_trees(nl);
                        for nn in self.cts_nets.clone() {
                            if let Some(id) = nl.net_by_name(&nn) {
                                nl.net_mut(id).dont_touch = false;
                            }
                        }
                        self.cts_nets.clear();
                        self.set_all_propagated(false);
                        crate::info!("CTS-011", "Removed {} clock tree cell(s); clocks set back to ideal", n);
                        Ok(n.to_string())
                    }
                    "report_clock_timing" => {
                        let ty = x.get("-type").cloned().unwrap_or("latency".into());
                        let nw = x.num("-nworst").map(|v| v as usize).unwrap_or(10);
                        let si = (0..self.scens.len()).find(|&i| self.scens[i].active && self.scens[i].setup).unwrap_or(0);
                        let r = self.with_timing(si, |t| {
                            let is_icg = |u: u32| matches!(t.nodes[u as usize], PinRef::Cell(c, _) if t.nl.cell(c).lib().map(|l| l.starts_with("ICG") || l.contains("CLKGATE")).unwrap_or(false));
                            let mut v: Vec<(String, f64, f64)> = t.clk_pins.iter().collect::<std::collections::HashSet<_>>().into_iter().filter(|u| !is_icg(**u)).filter_map(|&u| t.ctags[u as usize].iter().map(|c| (c.lmax, c.lmin)).reduce(|a, b| (a.0.max(b.0), a.1.min(b.1))).map(|(mx, mn)| (t.nl.pin_name(t.nodes[u as usize]), mx, mn))).collect();
                            v.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
                            v
                        });
                        match r {
                            Ok(v) => {
                                crate::out!("\n****************************************\nReport : clock_timing -type {}\n****************************************", ty);
                                crate::out!("  {:<46} {:>10} {:>10}", "Clock pin", "Late lat", "Early lat");
                                let show: Vec<&(String, f64, f64)> = if ty == "skew" { v.iter().take(nw).chain(v.iter().rev().take(nw)).collect() } else { v.iter().take(nw).collect() };
                                for (p, mx, mn) in show {
                                    crate::out!("  {:<46} {:>10.4} {:>10.4}", p, mx, mn);
                                }
                                if let (Some(f), Some(l)) = (v.first(), v.last()) {
                                    crate::out!("\n  Global skew (late latency spread): {:.4}ns  [{} .. {}]", f.1 - l.1, l.0, f.0);
                                }
                                Ok(v.len().to_string())
                            }
                            Err(e) => Err(e),
                        }
                    }
                    _ => {
                        // synthesize_clock_trees = build_clock only; clock_opt = build_clock, route_clock, final_opto
                        const ST: &[&str] = &["build_clock", "route_clock", "final_opto"];
                        let incremental = self.flow_body.take().unwrap_or(false);
                        if incremental && self.cts_nets.is_empty() {
                            return Some(err("clock_opt -incremental: no clock trees yet (clock_opt first) (OPT-933)"));
                        }
                        let (fi, ti) = if name == "synthesize_clock_trees" { (0, 0) } else if incremental { (2, 2) } else {
                            (x.get("-from").and_then(|s| ST.iter().position(|t| t == s)).unwrap_or(0), x.get("-to").and_then(|s| ST.iter().position(|t| t == s)).unwrap_or(ST.len() - 1))
                        };
                        for st in &ST[fi..=ti] {
                            crate::out!("\n==== {} : {} ====", name, st);
                            let res: Result<(), Flow> = match *st {
                                "build_clock" => self.run_cts().map(|(t, b, d, sk, la)| {
                                    crate::info!("CTS-300", "build_clock: {} tree(s), {} buffer(s), {} balancing delay cell(s); global skew {:.4}ns, max latency {:.4}ns; clocks are now propagated", t, b, d, sk, la);
                                }),
                                "route_clock" => self.route_nets_kind(true).map(|_| ()),
                                _ => {
                                    let r = self.stage("final_opto", true);
                                    match r {
                                        Ok(()) => {
                                            let bad = self.illegal_cells().unwrap_or_default();
                                            if !bad.is_empty() {
                                                let _ = self.fp_legalize(Some(bad), false, false);
                                            }
                                            if self.routes.as_ref().map(|db| db.nets.values().any(|r| !r.clock)).unwrap_or(false) {
                                                // signal nets routed already: reroute only the nets the optimization changed
                                                self.route_incremental(false, false).map(|_| ())
                                            } else if self.opt_ctl.as_ref().map(|c| c.focus.is_some()).unwrap_or(false) {
                                                Ok(()) // -endpoints: keep the other nets' global routes
                                            } else {
                                                self.fp_route(true).map(|_| ())
                                            }
                                        }
                                        Err(e) => Err(e),
                                    }
                                }
                            };
                            if let Err(e) = res {
                                return Some(Err(e));
                            }
                            if let Ok(q) = self.with_env(|nl, env| { let a = env.analyze(nl, 0); (a.wns, a.tns, a.whs, a.ths, a.drv.len(), nl.num_cells()) }) {
                                crate::out!("  [{:<11}] WNS {:>8.4}  TNS {:>9.4}  WHS {:>8.4}  THS {:>9.4}  DRV {:>4}  cells {:>6}", st, q.0, q.1, q.2, q.3, q.4, q.5);
                            }
                        }
                        Ok(String::new())
                    }
                }
            }
            _ => return None,
        };
        Some(r)
    }
}
