//! Post-mapping, MMMC-concurrent optimization engine.
//! All timing-driven moves are evaluated against every active scenario
//! (worst slack across scenarios) and batches that degrade QoR are reverted.

use crate::cons::*;
use crate::liberty::{parse_func, LibCell, Library};
use crate::netlist::*;
use crate::sta::*;
use std::collections::{HashMap, HashSet};

pub struct Env<'a> {
    pub libs: &'a [Library],
    pub target: usize,
    pub setup: Vec<(&'a Constraints, &'a Corner, String)>,
    pub hold: Vec<(&'a Constraints, &'a Corner, String)>,
    pub opts: StaOpts,
    pub dont_use: Vec<String>,
    pub vt_order: Vec<String>,
    pub aon_nets: HashSet<String>,
    /// optimize only the paths to these endpoints (pin / port names); other endpoints must not get worse
    pub focus: Option<std::sync::Arc<HashSet<String>>>,
    /// critical paths taken per timing-optimization pass (effort)
    pub npaths: usize,
}

#[derive(Default, Clone)]
pub struct Analysis {
    pub slack: HashMap<PinRef, f64>,
    pub hslack: HashMap<PinRef, f64>,
    pub slew: HashMap<PinRef, f64>,
    pub net_c: Vec<f64>,
    pub wns: f64,
    pub tns: f64,
    pub whs: f64,
    pub ths: f64,
    pub drv: Vec<(String, NetId, f64, f64)>,
    pub crit: Vec<Vec<PinRef>>,
    pub hold_eps: Vec<(PinRef, f64)>,
    pub ep_setup: HashMap<PinRef, f64>,
    /// path-group-aware cost (only when user path groups / group options exist)
    pub group_aware: bool,
    /// sum over groups of weight * min(0, group WNS)
    pub gwns: f64,
    /// sum over groups of weight * TNS within the group's critical range
    pub gtns: f64,
    /// per group: (worst WNS, worst TNS) over setup scenarios
    pub groups: Vec<(String, f64, f64)>,
    /// focus (-endpoints): worst / total negative setup slack of the focus endpoints, worst hold
    /// slack of the focus endpoints, and worst setup / hold slack of every other endpoint
    pub focus: bool,
    pub fwns: f64,
    pub ftns: f64,
    pub fwhs: f64,
    pub owns: f64,
    pub owhs: f64,
    /// total negative setup slack of the other endpoints
    pub otns: f64,
}

impl Analysis {
    /// the worst setup slack the optimizer works on (the focus endpoints with -endpoints)
    pub fn opt_wns(&self) -> f64 {
        if self.focus {
            self.fwns
        } else {
            self.wns
        }
    }
    /// QoR comparison used to accept/reject optimization moves
    pub fn better_than(&self, a: &Analysis) -> bool {
        if self.focus {
            // the focus endpoints improve, and no other endpoint gets worse than it was (or than 0)
            let others_ok = (self.owns >= a.owns - 1e-6 || self.owns >= 0.0) && self.otns >= a.otns - 1e-6;
            return others_ok && (self.fwns > a.fwns + 1e-6 || (self.fwns >= a.fwns - 1e-6 && self.ftns > a.ftns + 1e-6));
        }
        if self.group_aware {
            // weighted WNS first; TNS within critical ranges second, but such a move may not make the
            // design's total TNS worse (paths outside a critical range are not optimized, not sacrificed)
            self.gwns > a.gwns + 1e-6 || (self.gwns >= a.gwns - 1e-6 && self.gtns > a.gtns + 1e-6 && self.tns >= a.tns - 1e-6)
        } else {
            self.wns > a.wns + 1e-6 || (self.wns >= a.wns - 1e-6 && self.tns > a.tns + 1e-6)
        }
    }
    /// no worse than `a` (within tolerance) on the active cost
    pub fn not_worse(&self, a: &Analysis) -> bool {
        if self.focus {
            return self.fwns >= a.fwns.min(0.0) - 1e-6 && self.ftns >= a.ftns - 1e-6 && (self.owns >= a.owns - 1e-6 || self.owns >= 0.0) && self.otns >= a.otns - 1e-6;
        }
        if self.group_aware {
            self.gwns >= a.gwns.min(0.0) - 1e-6 && self.gtns >= a.gtns - 1e-6
        } else {
            self.wns >= a.wns.min(0.0) - 1e-6 && self.tns >= a.tns - 1e-6
        }
    }
}

impl<'a> Env<'a> {
    pub fn lib(&self) -> &'a Library {
        &self.libs[self.target]
    }
    pub fn lc(&self, n: &str) -> Option<&'a LibCell> {
        self.libs.iter().find_map(|l| l.cells.get(n))
    }
    pub fn in_focus(&self, name: &str) -> bool {
        self.focus.as_ref().map(|f| f.contains(name)).unwrap_or(true)
    }
    /// nets in the fan-in cones of the focus endpoints (up to registers and ports)
    pub fn focus_nets(&self, nl: &Netlist) -> Option<HashSet<NetId>> {
        let f = self.focus.as_ref()?;
        let mut nets = HashSet::new();
        let mut st: Vec<NetId> = vec![];
        for name in f.iter() {
            if let Some(pr) = nl.find_pin(name).or_else(|| nl.port_by_name(name).map(PinRef::Port)) {
                if let Some(n) = nl.pin_net(pr) {
                    st.push(n);
                }
            }
        }
        while let Some(n) = st.pop() {
            if !nets.insert(n) {
                continue;
            }
            if let Some(PinRef::Cell(c, _)) = nl.driver(n) {
                let seq = nl.cell(c).lib().and_then(|l| self.lc(l)).map(|lc| lc.is_seq()).unwrap_or(false);
                if seq {
                    continue;
                }
                for p in &nl.cell(c).pins {
                    if p.dir == Dir::In {
                        if let Some(m) = p.net {
                            st.push(m);
                        }
                    }
                }
            }
        }
        Some(nets)
    }
    pub fn analyze(&self, nl: &Netlist, npaths: usize) -> Analysis {
        let mut a = Analysis { wns: 0.0, ..Default::default() };
        if self.focus.is_some() {
            a.focus = true;
            a.fwns = 0.0;
            a.fwhs = f64::INFINITY;
            a.owns = f64::INFINITY;
            a.owhs = f64::INFINITY;
        }
        for (k, (cons, corner, _)) in self.setup.iter().enumerate() {
            let ls = LibSet { libs: corner.libs.iter().map(|i| &self.libs[*i]).collect() };
            let ls = if ls.libs.is_empty() { LibSet { libs: vec![self.lib()] } } else { ls };
            let mut t = Timing::new(nl, &ls, cons, corner, self.opts.clone());
            t.run();
            if k == 0 {
                a.net_c = t.net_c.clone();
            } else {
                for (i, c) in t.net_c.iter().enumerate() {
                    if i < a.net_c.len() {
                        a.net_c[i] = a.net_c[i].max(*c);
                    }
                }
            }
            for (i, pr) in t.nodes.iter().enumerate() {
                let s = t.slack(i as u32);
                let e = a.slack.entry(*pr).or_insert(f64::INFINITY);
                *e = e.min(s);
                let sl = t.pin_slew(*pr);
                let e2 = a.slew.entry(*pr).or_insert(0.0);
                *e2 = e2.max(sl);
            }
            a.wns = a.wns.min(t.wns);
            a.tns = a.tns.min(t.tns);
            for d in &t.drv {
                if !a.drv.iter().any(|x| x.0 == d.kind && x.1 == d.net) {
                    a.drv.push((d.kind.to_string(), d.net, d.actual, d.limit));
                }
            }
            if cons.group_aware() && self.focus.is_none() {
                a.group_aware = true;
                for (g, gw, _gt, _, _, _) in t.group_summary() {
                    let (w, cr) = cons.group_weight_cr(&g);
                    // critical range: optimize (and count in TNS cost) the violating paths within `cr`
                    // of the group's WNS; 0 = worst path only; unset = every violating path
                    let lim = match cr { Some(c) => (gw + c.max(0.0)).min(0.0), None => 0.0 };
                    let all: Vec<(&EndPoint, f64)> = t.endpoints.iter().filter_map(|e| e.groups.iter().find(|x| x.0 == g).map(|x| (e, x.1))).filter(|(_, s)| *s < 0.0).collect();
                    // cost: TNS of the paths inside the critical range
                    let tcr: f64 = all.iter().filter(|(_, s)| *s <= lim + 1e-12).map(|x| x.1).sum();
                    // work set: the critical range, widened to 5% of the group WNS so a zero range still
                    // gives the optimizer the near-worst paths that share the critical logic
                    let wlim = match cr { Some(c) => (gw + c.max(0.0).max(0.05 * gw.abs())).min(0.0), None => 0.0 };
                    let mut geps: Vec<(&EndPoint, f64)> = all.into_iter().filter(|(_, s)| *s <= wlim + 1e-12).collect();
                    geps.sort_by(|x, y| x.1.partial_cmp(&y.1).unwrap());
                    if w > 0.0 {
                        for (e, _) in geps.iter().take(npaths) {
                            let p: Vec<PinRef> = t.path(e, false).iter().map(|(n, _, _)| t.nodes[*n as usize]).collect();
                            if !a.crit.contains(&p) {
                                a.crit.push(p);
                            }
                        }
                    }
                    if let Some(x) = a.groups.iter_mut().find(|x| x.0 == g) {
                        x.1 = x.1.min(gw);
                        x.2 = x.2.min(tcr);
                    } else {
                        a.groups.push((g.clone(), gw, tcr));
                    }
                }
            } else {
                let mut eps: Vec<&EndPoint> = t.endpoints.iter().filter(|e| e.setup_slack < 0.0 && self.in_focus(&e.name)).collect();
                eps.sort_by(|x, y| x.setup_slack.partial_cmp(&y.setup_slack).unwrap());
                for e in eps.iter().take(npaths) {
                    let p: Vec<PinRef> = t.path(e, false).iter().map(|(n, _, _)| t.nodes[*n as usize]).collect();
                    a.crit.push(p);
                }
            }
            for e in &t.endpoints {
                let pr = t.nodes[e.node as usize];
                let x = a.ep_setup.entry(pr).or_insert(f64::INFINITY);
                *x = x.min(e.setup_slack);
                if a.focus {
                    if self.in_focus(&e.name) {
                        a.fwns = a.fwns.min(e.setup_slack.min(0.0));
                    } else if e.setup_slack.is_finite() {
                        a.owns = a.owns.min(e.setup_slack);
                    }
                }
            }
            if a.focus {
                // TNS of the focus endpoints in this scenario
                let ft: f64 = t.endpoints.iter().filter(|e| self.in_focus(&e.name) && e.setup_slack < 0.0).map(|e| e.setup_slack).sum();
                a.ftns = a.ftns.min(ft);
                let ot: f64 = t.endpoints.iter().filter(|e| !self.in_focus(&e.name) && e.setup_slack < 0.0).map(|e| e.setup_slack).sum();
                a.otns = a.otns.min(ot);
            }
        }
        if a.group_aware {
            let c0 = &self.setup[0].0;
            a.gwns = a.groups.iter().map(|(g, w, _)| c0.group_weight_cr(g).0 * w.min(0.0)).sum();
            a.gtns = a.groups.iter().map(|(g, _, t)| c0.group_weight_cr(g).0 * t).sum();
        }
        for (cons, corner, _) in &self.hold {
            let ls = LibSet { libs: corner.libs.iter().map(|i| &self.libs[*i]).collect() };
            let ls = if ls.libs.is_empty() { LibSet { libs: vec![self.lib()] } } else { ls };
            let mut t = Timing::new(nl, &ls, cons, corner, self.opts.clone());
            t.run();
            a.whs = a.whs.min(t.whs);
            a.ths += t.ths;
            for e in &t.endpoints {
                if a.focus && e.hold_slack.is_finite() {
                    if self.in_focus(&e.name) {
                        a.fwhs = a.fwhs.min(e.hold_slack);
                    } else {
                        a.owhs = a.owhs.min(e.hold_slack);
                    }
                }
                if e.hold_slack < 0.0 && self.in_focus(&e.name) {
                    let pr = t.nodes[e.node as usize];
                    if let Some(x) = a.hold_eps.iter_mut().find(|x| x.0 == pr) {
                        x.1 = x.1.min(e.hold_slack);
                    } else {
                        a.hold_eps.push((pr, e.hold_slack));
                    }
                }
            }
        }
        // DRV work limited to the fan-in cones of the focus endpoints
        if let Some(fnets) = self.focus_nets(nl) {
            a.drv.retain(|d| fnets.contains(&d.1));
        }
        a
    }
    fn vt_rank(&self, vt: &str) -> usize {
        self.vt_order.iter().position(|v| v == vt).unwrap_or(self.vt_order.len() / 2)
    }
    fn allowed(&self, c: &LibCell) -> bool {
        !c.dont_use && !self.dont_use.iter().any(|d| glob(d, &c.name))
    }
    /// alternative cells: same family (function), filtered
    pub fn alts(&self, cell: &str) -> Vec<&'a LibCell> {
        self.lib().family_of(cell).into_iter().filter(|c| self.allowed(c)).collect()
    }
    pub fn bigger(&self, cell: &str) -> Option<&'a LibCell> {
        let cur = self.lc(cell)?;
        self.alts(cell).into_iter().filter(|c| c.vt == cur.vt && c.drive > cur.drive + 1e-9).min_by(|a, b| a.drive.partial_cmp(&b.drive).unwrap())
    }
    pub fn smaller(&self, cell: &str) -> Option<&'a LibCell> {
        let cur = self.lc(cell)?;
        self.alts(cell).into_iter().filter(|c| c.vt == cur.vt && c.drive < cur.drive - 1e-9).max_by(|a, b| a.drive.partial_cmp(&b.drive).unwrap())
    }
    pub fn faster_vt(&self, cell: &str) -> Option<&'a LibCell> {
        let cur = self.lc(cell)?;
        let r = self.vt_rank(&cur.vt);
        self.alts(cell).into_iter().filter(|c| (c.drive - cur.drive).abs() < 1e-9 && self.vt_rank(&c.vt) > r).min_by_key(|c| self.vt_rank(&c.vt))
    }
    pub fn slower_vt(&self, cell: &str) -> Option<&'a LibCell> {
        let cur = self.lc(cell)?;
        let r = self.vt_rank(&cur.vt);
        self.alts(cell).into_iter().filter(|c| (c.drive - cur.drive).abs() < 1e-9 && self.vt_rank(&c.vt) < r).max_by_key(|c| self.vt_rank(&c.vt))
    }
    pub fn buffers(&self, aon: bool) -> Vec<&'a LibCell> {
        let mut v: Vec<&LibCell> = self.lib().cells_sorted().into_iter().filter(|c| c.is_buf && !c.is_delay && self.allowed(c) && c.always_on == aon && !c.is_iso && !c.is_ls).collect();
        let pref = self.vt_order.get(self.vt_order.len().saturating_sub(1) / 2).cloned().unwrap_or("SVT".into());
        v.sort_by(|a, b| (a.vt != pref).cmp(&(b.vt != pref)).then(a.drive.partial_cmp(&b.drive).unwrap()));
        v
    }
}

pub fn lib_pins(c: &LibCell) -> Vec<(&str, Dir)> {
    c.pins.iter().map(|p| (p.name.as_str(), p.dir.unwrap_or(Dir::In))).collect()
}

/// swap a cell to another library cell with identical pin names
pub fn swap_cell(nl: &mut Netlist, c: CellId, to: &str) {
    nl.cell_mut(c).kind = Kind::Lib(to.to_string());
}

/// Insert a buffer driving `loads` (moved from net `n`). Returns buffer cell.
/// Hierarchy (and hence power domain) a new cell driving `loads` from net `n` should live in.
pub fn host_hier(nl: &Netlist, n: NetId, loads: &[PinRef]) -> String {
    let h = host_hier0(nl, n, loads);
    if nl.frozen_hier.is_empty() { h } else { nl.outside_frozen(&h) }
}

fn host_hier0(nl: &Netlist, n: NetId, loads: &[PinRef]) -> String {
    let hs: Vec<String> = loads.iter().map(|l| match l {
        PinRef::Cell(c, _) if !nl.cell(*c).has_attr("iso") && !nl.cell(*c).has_attr("ls") => nl.cell(*c).hier_prefix().to_string(),
        PinRef::Cell(c, _) => nl.cell(*c).hier_prefix().to_string(),
        PinRef::Port(_) => String::new(),
    }).collect();
    if let Some(f) = hs.first() {
        if hs.iter().all(|h| h == f) {
            return f.clone();
        }
        // common hierarchical prefix (path components)
        let mut common: Vec<&str> = f.split('/').collect();
        for h in &hs[1..] {
            let p: Vec<&str> = h.split('/').collect();
            let k = common.iter().zip(p.iter()).take_while(|(a, b)| a == b).count();
            common.truncate(k);
        }
        let c = common.join("/");
        if !c.is_empty() {
            return c;
        }
    }
    match nl.driver(n) {
        Some(PinRef::Cell(c, _)) if hs.is_empty() => nl.cell(c).hier_prefix().to_string(),
        _ => String::new(),
    }
}

pub fn insert_buffer(nl: &mut Netlist, n: NetId, loads: &[PinRef], buf: &LibCell, prefix: &str) -> CellId {
    let inp = buf.inputs()[0].name.clone();
    let out = buf.outputs()[0].name.clone();
    let h = host_hier(nl, n, loads);
    let base = nl.fresh(prefix);
    let name = if h.is_empty() { base } else { format!("{}/{}", h, base) };
    let b = nl.add_cell(&name, Kind::Lib(buf.name.clone()), &lib_pins(buf));
    let nn = nl.add_net(&format!("{}_net", name));
    nl.connect_name(b, &inp, n);
    nl.connect_name(b, &out, nn);
    let mut sx = 0.0;
    let mut sy = 0.0;
    let mut k = 0.0;
    for l in loads {
        match *l {
            PinRef::Cell(c, p) => nl.connect(c, p, nn),
            PinRef::Port(p) => nl.connect_port(p, nn),
        }
        if let Some((x, y)) = nl.pin_loc(*l) {
            sx += x;
            sy += y;
            k += 1.0;
        }
    }
    if k > 0.0 {
        nl.cell_mut(b).loc = Some((sx / k, sy / k));
    }
    nl.cell_mut(b).attrs.push("opt_buffer".into());
    b
}

// ------------------------------------------------------------------ tie cells
pub fn insert_ties(nl: &mut Netlist, lib: &Library, max_fanout: usize, dont_use: &[String]) -> usize {
    let pick = |v: bool| lib.cells_sorted().into_iter().filter(|c| c.tie == Some(v) && !dont_use.iter().any(|d| glob(d, &c.name))).min_by(|a, b| a.area.partial_cmp(&b.area).unwrap());
    let mut n = 0;
    for c in nl.cell_ids() {
        let v = match nl.cell(c).gop() {
            Some(GOp::C0) => false,
            Some(GOp::C1) => true,
            _ => continue,
        };
        let Some(net) = nl.cell(c).pin_net("Y") else { continue };
        let loads: Vec<PinRef> = nl.loads(net);
        if loads.is_empty() {
            continue;
        }
        let Some(tc) = pick(v) else {
            crate::warn!("OPT-1500", "No TIE{} cell in target library; constant {} kept as netlist assignment", if v { "HI" } else { "LO" }, v as u8);
            continue;
        };
        let out = tc.outputs()[0].name.clone();
        let mut by_h: std::collections::BTreeMap<String, Vec<PinRef>> = std::collections::BTreeMap::new();
        for l in &loads {
            let h = match l {
                PinRef::Cell(c, _) => nl.cell(*c).hier_prefix().to_string(),
                _ => String::new(),
            };
            by_h.entry(h).or_default().push(*l);
        }
        for (h, hl) in by_h {
        for chunk in hl.chunks(max_fanout.max(1)) {
            let base = nl.fresh(if v { "tie_hi_" } else { "tie_lo_" });
            let name = if h.is_empty() { base } else { format!("{}/{}", h, base) };
            let t = nl.add_cell(&name, Kind::Lib(tc.name.clone()), &lib_pins(tc));
            let tn = nl.add_net(&format!("{}_net", name));
            nl.connect_name(t, &out, tn);
            let mut loc = None;
            for l in chunk {
                match *l {
                    PinRef::Cell(cc, p) => {
                        nl.connect(cc, p, tn);
                        loc = loc.or(nl.cell(cc).loc);
                    }
                    PinRef::Port(p) => nl.connect_port(p, tn),
                }
            }
            nl.cell_mut(t).loc = loc;
            n += 1;
        }
        }
    }
    if n > 0 {
        crate::info!("OPT-1501", "Inserted {} tie cell(s) (max tie fanout {})", n, max_fanout);
    }
    nl.sweep_nets();
    n
}

// ------------------------------------------------------------------ buffer tree removal
pub fn remove_buffer_trees(nl: &mut Netlist, env: &Env) -> usize {
    let mut n = 0;
    for c in nl.cell_ids() {
        if !nl.cell_alive(c) || nl.cell(c).frozen() {
            continue;
        }
        let Some(lc) = nl.cell(c).lib().and_then(|l| env.lc(l)) else { continue };
        if lc.always_on || lc.is_iso || lc.is_ls || nl.cell(c).has_attr("keep") {
            continue;
        }
        if lc.is_buf {
            let a = nl.cell(c).pin_net(&lc.inputs()[0].name);
            let y = nl.cell(c).pin_net(&lc.outputs()[0].name);
            let (Some(a), Some(y)) = (a, y) else { continue };
            let a_port = nl.net(a).conns.iter().any(|p| matches!(p, PinRef::Port(_)));
            let y_port = nl.net(y).conns.iter().any(|p| matches!(p, PinRef::Port(_)));
            if a_port && y_port || nl.net(a).dont_touch || nl.net(y).dont_touch {
                continue;
            }
            nl.remove_cell(c);
            crate::genopt::merge_named(nl, a, y);
            n += 1;
        } else if lc.is_inv {
            // INV -> INV pair
            let y = nl.cell(c).pin_net(&lc.outputs()[0].name);
            let a = nl.cell(c).pin_net(&lc.inputs()[0].name);
            let (Some(y), Some(a)) = (y, a) else { continue };
            let loads = nl.loads(y);
            if loads.len() != 1 || nl.net(y).conns.iter().any(|p| matches!(p, PinRef::Port(_))) {
                continue;
            }
            let PinRef::Cell(c2, _) = loads[0] else { continue };
            if nl.cell(c2).frozen() {
                continue;
            }
            let Some(l2) = nl.cell(c2).lib().and_then(|l| env.lc(l)) else { continue };
            if !l2.is_inv {
                continue;
            }
            let Some(y2) = nl.cell(c2).pin_net(&l2.outputs()[0].name) else { continue };
            let a_port = nl.net(a).conns.iter().any(|p| matches!(p, PinRef::Port(_)));
            let y2_port = nl.net(y2).conns.iter().any(|p| matches!(p, PinRef::Port(_)));
            if a_port && y2_port {
                continue;
            }
            nl.remove_cell(c2);
            nl.remove_cell(c);
            crate::genopt::merge_named(nl, a, y2);
            n += 2;
        }
    }
    nl.sweep_nets();
    if n > 0 {
        crate::info!("OPT-1600", "Removed {} buffer/inverter-pair cell(s) from existing buffer trees", n);
    }
    n
}

// ------------------------------------------------------------------ high-fanout / DRV
pub fn buffer_net(nl: &mut Netlist, env: &Env, n: NetId, max_fo: usize, max_cap: Option<f64>, aon: bool, tag: &str) -> usize {
    let bufs = env.buffers(aon);
    if bufs.is_empty() {
        crate::warn!("OPT-1700", "No usable buffer cell{} for buffering net '{}'", if aon { " (always-on)" } else { "" }, nl.net(n).name);
        return 0;
    }
    let mut loads = nl.loads(n);
    if loads.len() <= max_fo && max_cap.is_none() {
        return 0;
    }
    // cluster loads by location (if placed) else by name
    loads.sort_by(|a, b| {
        let la = nl.pin_loc(*a).unwrap_or((0.0, 0.0));
        let lb = nl.pin_loc(*b).unwrap_or((0.0, 0.0));
        (la.0 + la.1 * 0.001).partial_cmp(&(lb.0 + lb.1 * 0.001)).unwrap().then(nl.pin_name(*a).cmp(&nl.pin_name(*b)))
    });
    let caps: Vec<f64> = loads.iter().map(|l| match l {
        PinRef::Cell(c, p) => nl.cell(*c).lib().and_then(|x| env.lc(x)).and_then(|x| x.pin(&nl.cell(*c).pins[*p].name)).map(|x| x.cap).unwrap_or(0.002),
        _ => 0.002,
    }).collect();
    let mut groups: Vec<Vec<PinRef>> = vec![];
    let mut cur = vec![];
    let mut cc = 0.0;
    for (l, c) in loads.iter().zip(caps.iter()) {
        let cap_hit = max_cap.map(|m| cc + c > m * 0.7).unwrap_or(false);
        if !cur.is_empty() && (cur.len() >= max_fo || cap_hit) {
            groups.push(std::mem::take(&mut cur));
            cc = 0.0;
        }
        cur.push(*l);
        cc += c;
    }
    if !cur.is_empty() {
        groups.push(cur);
    }
    if groups.len() <= 1 {
        return 0;
    }
    let mut added = 0;
    for g in &groups {
        let gcap: f64 = g.iter().map(|l| match l {
            PinRef::Cell(c, p) => nl.cell(*c).lib().and_then(|x| env.lc(x)).and_then(|x| x.pin(&nl.cell(*c).pins[*p].name)).map(|x| x.cap).unwrap_or(0.002),
            _ => 0.002,
        }).sum();
        let b = bufs.iter().find(|b| b.outputs()[0].max_cap.map(|m| m > gcap * 1.5).unwrap_or(true) && b.drive >= (g.len() as f64 / 8.0)).copied().unwrap_or(*bufs.last().unwrap());
        insert_buffer(nl, n, g, b, tag);
        added += 1;
    }
    // recurse if the root still exceeds fanout
    if nl.loads(n).len() > max_fo {
        added += buffer_net(nl, env, n, max_fo, max_cap, aon, tag);
    }
    added
}

pub fn is_clock_net(nl: &Netlist, env: &Env, n: NetId) -> bool {
    nl.loads(n).iter().any(|l| match l {
        PinRef::Cell(c, p) => nl.cell(*c).lib().and_then(|x| env.lc(x)).and_then(|x| x.pin(&nl.cell(*c).pins[*p].name)).map(|x| x.is_clock || x.cg_role.as_deref() == Some("clock")).unwrap_or(false),
        _ => false,
    })
}

pub fn high_fanout_synthesis(nl: &mut Netlist, env: &Env, threshold: usize, max_fo: usize, include_clocks: bool) -> usize {
    let mut tot = 0;
    for n in nl.net_ids() {
        if !nl.net_alive(n) || nl.net(n).dont_touch {
            continue;
        }
        let fo = nl.loads(n).len();
        if fo <= threshold {
            continue;
        }
        if is_pad_net(nl, n) {
            continue;
        }
        if !include_clocks && is_clock_net(nl, env, n) {
            crate::info!("OPT-1702", "Skipping high-fanout clock net '{}' ({} loads): left for clock tree synthesis", nl.net(n).name, fo);
            continue;
        }
        let aon = env.aon_nets.contains(&nl.net(n).name);
        let name = nl.net(n).name.clone();
        let k = buffer_net(nl, env, n, max_fo, None, aon, "HFSBUF_");
        if k > 0 {
            crate::info!("OPT-1701", "High-fanout net '{}' ({} loads) buffered with {} {}buffer(s)", name, fo, k, if aon { "always-on " } else { "" });
        }
        tot += k;
    }
    tot
}

/// pad-side nets (port <-> pad PAD pin): bond wire / package, never buffered or resized
pub fn is_pad_net(nl: &Netlist, n: NetId) -> bool {
    nl.net(n).conns.iter().any(|r| matches!(r, PinRef::Cell(c, i) if nl.cell(*c).pins[*i].name == "PAD" && (nl.cell(*c).has_attr("io_pad") || nl.cell(*c).has_attr("area_io") || nl.cell(*c).fixed)))
}

pub fn fix_drv(nl: &mut Netlist, env: &Env, max_iter: usize) -> (usize, usize) {
    let (mut sized, mut bufd) = (0, 0);
    for _ in 0..max_iter {
        let a = env.analyze(nl, 0);
        if a.drv.is_empty() {
            break;
        }
        let mut done_nets = HashSet::new();
        let mut progress = false;
        for (kind, n, _act, lim) in &a.drv {
            if !nl.net_alive(*n) || !done_nets.insert(*n) || nl.net(*n).dont_touch {
                continue;
            }
            if is_clock_net(nl, env, *n) || is_pad_net(nl, *n) {
                continue;
            }
            let drv = nl.driver_cell(*n);
            // try upsizing driver first for transition/cap
            if kind != "max_fanout" {
                if let Some(c) = drv {
                    if !nl.cell(c).dont_touch {
                        if let Some(l) = nl.cell(c).lib().map(|s| s.to_string()) {
                            if let Some(b) = env.bigger(&l) {
                                swap_cell(nl, c, &b.name.clone());
                                sized += 1;
                                progress = true;
                                continue;
                            }
                        }
                    }
                }
            }
            let fo = nl.loads(*n).len();
            if kind != "max_fanout" && fo <= 2 {
                // dont_touch / max-size driver with few loads: isolate the loads behind a strong buffer
                let aon = env.aon_nets.contains(&nl.net(*n).name);
                let bufs = env.buffers(aon);
                if let Some(b) = bufs.iter().rev().find(|b| b.drive <= 2.0).or(bufs.first()) {
                    let loads = nl.loads(*n);
                    let already = loads.iter().all(|l| matches!(l, PinRef::Cell(c, _) if nl.cell(*c).has_attr("opt_buffer")));
                    if !already {
                        let dloc = nl.driver(*n).and_then(|d| nl.pin_loc(d));
                        let bc = insert_buffer(nl, *n, &loads, b, "DRVBUF_");
                        if let Some(l) = dloc {
                            nl.cell_mut(bc).loc = Some(l); // keep the driver-side wire short
                        }
                        bufd += 1;
                        progress = true;
                    }
                }
                continue;
            }
            let mfo = if kind == "max_fanout" { (*lim as usize).max(2) } else { (fo / 2).max(2) };
            let cap = if kind == "max_capacitance" { Some(*lim) } else { None };
            let aon = env.aon_nets.contains(&nl.net(*n).name);
            let k = buffer_net(nl, env, *n, mfo, cap, aon, "DRVBUF_");
            if k > 0 {
                bufd += k;
                progress = true;
            }
        }
        if !progress {
            break;
        }
    }
    (sized, bufd)
}

// ------------------------------------------------------------------ timing optimization
fn snapshot(nl: &Netlist) -> Vec<(CellId, String)> {
    nl.cell_ids().into_iter().filter_map(|c| nl.cell(c).lib().map(|l| (c, l.to_string()))).collect()
}

/// symmetric (swappable) input pin pairs of a library cell
pub fn swappable_pairs(lc: &LibCell) -> Vec<(String, String)> {
    let Some(f) = lc.outputs().first().and_then(|o| o.function.clone()).and_then(|f| parse_func(&f)) else { return vec![] };
    let ins: Vec<String> = lc.inputs().iter().map(|p| p.name.clone()).collect();
    let tt = f.tt(&ins);
    let mut out = vec![];
    for i in 0..ins.len() {
        for j in i + 1..ins.len() {
            let mut sw = ins.clone();
            sw.swap(i, j);
            if f.tt(&sw) == tt {
                out.push((ins[i].clone(), ins[j].clone()));
            }
        }
    }
    out
}

fn pin_delay(lc: &LibCell, pin: &str, slew: f64, load: f64) -> f64 {
    let mut d: f64 = 0.0;
    for o in lc.outputs() {
        for a in o.arcs.iter().filter(|a| a.related == pin) {
            if let Some(t) = &a.cell_rise {
                d = d.max(t.delay(slew, load));
            }
            if let Some(t) = &a.cell_fall {
                d = d.max(t.delay(slew, load));
            }
        }
    }
    d
}

pub struct TimingOptStats {
    pub upsized: usize,
    pub vt_swapped: usize,
    pub pin_swaps: usize,
    pub clones: usize,
    pub iterations: usize,
}

/// endpoint-limited optimization: one move at a time on the cells of the focus paths, kept only
/// when the focus endpoints improve and no other endpoint gets worse
fn optimize_focus(nl: &mut Netlist, env: &Env, max_iter: usize, allow_vt: bool) -> TimingOptStats {
    let mut st = TimingOptStats { upsized: 0, vt_swapped: 0, pin_swaps: 0, clones: 0, iterations: 0 };
    let mut a = env.analyze(nl, env.npaths.max(1));
    let budget = 20 * max_iter.max(1);
    let mut trials = 0;
    for it in 0..max_iter {
        if a.opt_wns() >= 0.0 || trials >= budget {
            break;
        }
        st.iterations = it + 1;
        // candidate cells along the focus paths, worst path first, each once
        let mut cands: Vec<CellId> = vec![];
        for path in a.crit.iter() {
            for pr in path {
                if let PinRef::Cell(c, p) = *pr {
                    if nl.cell_alive(c) && nl.cell(c).pins[p].dir == Dir::Out && !nl.cell(c).dont_touch && !cands.contains(&c) {
                        cands.push(c);
                    }
                }
            }
        }
        let mut improved = false;
        for c in cands {
            if trials >= budget {
                break;
            }
            let Some(ln) = nl.cell(c).lib().map(|s| s.to_string()) else { continue };
            let mut options: Vec<(String, bool)> = vec![];
            if allow_vt {
                if let Some(f) = env.faster_vt(&ln) {
                    options.push((f.name.clone(), true));
                }
            }
            if let Some(b) = env.bigger(&ln) {
                options.push((b.name.clone(), false));
            }
            for (to, is_vt) in options {
                trials += 1;
                swap_cell(nl, c, &to);
                let b = env.analyze(nl, env.npaths.max(1));
                if b.better_than(&a) {
                    if is_vt {
                        st.vt_swapped += 1;
                    } else {
                        st.upsized += 1;
                    }
                    a = b;
                    improved = true;
                    break;
                }
                swap_cell(nl, c, &ln);
            }
        }
        if !improved {
            break;
        }
    }
    st
}

pub fn optimize_timing(nl: &mut Netlist, env: &Env, max_iter: usize, allow_vt: bool, allow_clone: bool) -> TimingOptStats {
    if env.focus.is_some() {
        return optimize_focus(nl, env, max_iter, allow_vt);
    }
    let mut st = TimingOptStats { upsized: 0, vt_swapped: 0, pin_swaps: 0, clones: 0, iterations: 0 };
    let mut npaths = env.npaths.max(1);
    let mut a = env.analyze(nl, npaths);
    let mut stall = 0;
    for it in 0..max_iter {
        if a.opt_wns() >= 0.0 {
            break;
        }
        st.iterations = it + 1;
        let snap = snapshot(nl);
        let mut moves = 0;
        let mut touched: HashSet<CellId> = HashSet::new();
        let mut swapped_pins: Vec<(CellId, usize, usize)> = vec![];
        let mut cloned: Vec<CellId> = vec![];
        let (mut up, mut vt, mut ps, mut cl) = (0, 0, 0, 0);
        for path in a.crit.iter().take(npaths) {
            for pr in path {
                let PinRef::Cell(c, p) = *pr else { continue };
                if !nl.cell_alive(c) || touched.contains(&c) || nl.cell(c).dont_touch {
                    continue;
                }
                let Some(ln) = nl.cell(c).lib().map(|s| s.to_string()) else { continue };
                let Some(lc) = env.lc(&ln) else { continue };
                if nl.cell(c).pins[p].dir != Dir::Out {
                    // pin swapping at the critical input pin
                    if nl.cell(c).pins[p].dir == Dir::In && lc.is_comb() && !nl.cell(c).has_attr("size_only") {
                        let pname = nl.cell(c).pins[p].name.clone();
                        let out = lc.outputs()[0].name.clone();
                        let load = nl.cell(c).pin_net(&out).map(|n| a.net_c.get(n).copied().unwrap_or(0.0)).unwrap_or(0.0);
                        let slew = a.slew.get(pr).copied().unwrap_or(0.05);
                        for (x, y) in swappable_pairs(lc) {
                            let other = if x == pname { y.clone() } else if y == pname { x.clone() } else { continue };
                            let (dc, do_) = (pin_delay(lc, &pname, slew, load), pin_delay(lc, &other, slew, load));
                            if do_ + 1e-4 < dc {
                                let oi = nl.cell(c).pin(&other).unwrap();
                                let (n1, n2) = (nl.cell(c).pins[p].net, nl.cell(c).pins[oi].net);
                                if let (Some(n1), Some(n2)) = (n1, n2) {
                                    nl.connect(c, p, n2);
                                    nl.connect(c, oi, n1);
                                    swapped_pins.push((c, p, oi));
                                    touched.insert(c);
                                    ps += 1;
                                    moves += 1;
                                }
                                break;
                            }
                        }
                    }
                    continue;
                }
                touched.insert(c);
                // cloning of high-fanout critical drivers
                if allow_clone && !nl.cell(c).has_attr("size_only") {
                    if let Some(on) = nl.cell(c).pins[p].net {
                        let loads = nl.loads(on);
                        if loads.len() >= 8 && !lc.is_seq() {
                            let mut crit: Vec<PinRef> = loads.iter().copied().filter(|l| a.slack.get(l).copied().unwrap_or(f64::INFINITY) < 0.0).collect();
                            if !crit.is_empty() && crit.len() * 2 <= loads.len() {
                                crit.truncate(loads.len() / 2);
                                let nm = nl.fresh(&format!("{}_clone", nl.cell(c).name));
                                let cell = nl.cell(c).clone();
                                let k = nl.add_cell(&nm, cell.kind.clone(), &cell.pins.iter().map(|x| (x.name.as_str(), x.dir)).collect::<Vec<_>>());
                                nl.cell_mut(k).loc = cell.loc;
                                nl.cell_mut(k).attrs.push("clone".into());
                                for (i, pin) in cell.pins.iter().enumerate() {
                                    if pin.dir == Dir::In {
                                        if let Some(n) = pin.net {
                                            nl.connect(k, i, n);
                                        }
                                    }
                                }
                                let nn = nl.add_net(&format!("{}_net", nm));
                                nl.connect(k, p, nn);
                                for l in crit {
                                    match l {
                                        PinRef::Cell(lc2, lp) => nl.connect(lc2, lp, nn),
                                        PinRef::Port(pp) => nl.connect_port(pp, nn),
                                    }
                                }
                                cloned.push(k);
                                cl += 1;
                                moves += 1;
                                continue;
                            }
                        }
                    }
                }
                if allow_vt {
                    if let Some(f) = env.faster_vt(&ln) {
                        swap_cell(nl, c, &f.name.clone());
                        vt += 1;
                        moves += 1;
                        continue;
                    }
                }
                if let Some(b) = env.bigger(&ln) {
                    swap_cell(nl, c, &b.name.clone());
                    up += 1;
                    moves += 1;
                }
            }
        }
        if moves == 0 {
            break;
        }
        let b = env.analyze(nl, npaths);
        let better = b.better_than(&a);
        if better {
            st.upsized += up;
            st.vt_swapped += vt;
            st.pin_swaps += ps;
            st.clones += cl;
            a = b;
            stall = 0;
        } else {
            // revert batch
            for (c, l) in &snap {
                if nl.cell_alive(*c) {
                    nl.cell_mut(*c).kind = Kind::Lib(l.clone());
                }
            }
            for (c, p, o) in swapped_pins.iter().rev() {
                let (n1, n2) = (nl.cell(*c).pins[*p].net.unwrap(), nl.cell(*c).pins[*o].net.unwrap());
                nl.connect(*c, *p, n2);
                nl.connect(*c, *o, n1);
            }
            for k in cloned {
                let out = nl.cell(k).pins.iter().position(|x| x.dir == Dir::Out).unwrap();
                let nn = nl.cell(k).pins[out].net.unwrap();
                // reconnect loads back to original driver net: find original via same input nets
                let orig = nl.cell_ids().into_iter().find(|&o| o != k && nl.cell(o).kind == nl.cell(k).kind && nl.cell(o).pins.iter().zip(nl.cell(k).pins.iter()).all(|(x, y)| x.dir == Dir::Out || x.net == y.net));
                if let Some(o) = orig {
                    let on = nl.cell(o).pins[out].net.unwrap();
                    nl.remove_cell(k);
                    nl.merge_net(on, nn);
                }
            }
            stall += 1;
            npaths = (npaths / 3).max(1);
            if stall >= 4 {
                break;
            }
            a = env.analyze(nl, npaths);
        }
    }
    st
}

pub fn fix_hold(nl: &mut Netlist, env: &Env, margin: f64, max_iter: usize) -> usize {
    let mut added = 0;
    let dly: Vec<&LibCell> = {
        let mut v: Vec<&LibCell> = env.lib().cells_sorted().into_iter().filter(|c| c.is_delay && !c.dont_use).collect();
        if v.is_empty() {
            v = env.buffers(false).into_iter().take(1).collect();
        }
        v.sort_by(|a, b| a.area.partial_cmp(&b.area).unwrap());
        v
    };
    let Some(d) = dly.first().copied() else { return 0 };
    let dd = crate::techmap::nominal_delay(d).max(0.01);
    for _ in 0..max_iter {
        let a = env.analyze(nl, 0);
        if a.hold_eps.is_empty() {
            break;
        }
        let mut any = false;
        for (ep, hs) in &a.hold_eps {
            let ss = a.ep_setup.get(ep).copied().unwrap_or(f64::INFINITY);
            let need = -hs + margin;
            if ss.is_finite() && ss < need + margin {
                crate::warn!("OPT-1800", "Hold violation at {} ({:.3}) not fixed: insufficient setup margin ({:.3})", nl.pin_name(*ep), hs, ss);
                continue;
            }
            let k = ((need / dd).ceil() as usize).clamp(1, 8);
            let Some(net) = nl.pin_net(*ep) else { continue };
            let mut cur_loads = vec![*ep];
            let mut n = net;
            let mut chain = vec![];
            for _ in 0..k {
                let b = insert_buffer(nl, n, &cur_loads, d, "HOLDBUF_");
                chain.push(b);
                n = nl.cell(b).pin_net(&d.outputs()[0].name).unwrap();
                cur_loads = nl.loads(n);
            }
            if env.focus.is_some() {
                // -endpoints: the other endpoints may not get worse (setup or hold)
                let b2 = env.analyze(nl, 0);
                let worse = (b2.owns < a.owns - 1e-6 && b2.owns < 0.0) || b2.otns < a.otns - 1e-6 || (b2.owhs < a.owhs - 1e-6 && b2.owhs < 0.0);
                if worse {
                    match *ep {
                        PinRef::Cell(c, p) => nl.connect(c, p, net),
                        PinRef::Port(q) => nl.connect_port(q, net),
                    }
                    for b in chain {
                        nl.remove_cell(b);
                    }
                    nl.sweep_nets();
                    crate::info!("OPT-1802", "Hold fix at {} undone: it would make other endpoints worse", nl.pin_name(*ep));
                    continue;
                }
            }
            added += chain.len();
            any = true;
        }
        if !any {
            break;
        }
    }
    if added > 0 {
        crate::info!("OPT-1801", "Inserted {} hold-fixing delay cell(s) ({})", added, d.name);
    }
    added
}

pub fn recover_power_area(nl: &mut Netlist, env: &Env, leakage: bool, area: bool, margin: f64) -> (usize, usize) {
    let (mut vtn, mut dn) = (0, 0);
    let mut base = env.analyze(nl, 0);
    // candidates sorted by slack (most slack first)
    let mut cands: Vec<(CellId, f64)> = vec![];
    for c in nl.cell_ids() {
        if nl.cell(c).dont_touch || nl.cell(c).lib().is_none() {
            continue;
        }
        let worst = (0..nl.cell(c).pins.len()).map(|i| base.slack.get(&PinRef::Cell(c, i)).copied().unwrap_or(f64::INFINITY)).fold(f64::INFINITY, f64::min);
        if worst >= margin {
            cands.push((c, worst));
        }
    }
    cands.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
    let chunk = (cands.len() / 10).max(8);
    for part in cands.chunks(chunk) {
        let mut changed: Vec<(CellId, String, bool)> = vec![];
        for (c, _) in part {
            let Some(ln) = nl.cell(*c).lib().map(|s| s.to_string()) else { continue };
            if leakage {
                if let Some(s) = env.slower_vt(&ln) {
                    if s.leakage < env.lc(&ln).map(|x| x.leakage).unwrap_or(0.0) {
                        swap_cell(nl, *c, &s.name.clone());
                        changed.push((*c, ln, true));
                        continue;
                    }
                }
            }
            if area {
                if let Some(s) = env.smaller(&ln) {
                    let out_load = nl.cell(*c).pins.iter().filter(|p| p.dir == Dir::Out).filter_map(|p| p.net).map(|n| base.net_c.get(n).copied().unwrap_or(0.0)).fold(0.0, f64::max);
                    if s.outputs().first().and_then(|o| o.max_cap).map(|m| out_load < m * 0.6).unwrap_or(true) {
                        swap_cell(nl, *c, &s.name.clone());
                        changed.push((*c, ln, false));
                    }
                }
            }
        }
        if changed.is_empty() {
            continue;
        }
        let after = env.analyze(nl, 0);
        let ok = after.not_worse(&base) && after.drv.len() <= base.drv.len() && after.whs >= base.whs.min(0.0) - 1e-6;
        if ok {
            for (_, _, v) in &changed {
                if *v { vtn += 1 } else { dn += 1 }
            }
            base = after;
        } else {
            for (c, l, _) in changed {
                nl.cell_mut(c).kind = Kind::Lib(l);
            }
        }
    }
    (vtn, dn)
}

/// Post-map logic sharing: merge identical cells driven by identical nets.
pub fn share_logic(nl: &mut Netlist, max_fanout: usize) -> usize {
    let mut h: HashMap<(String, Vec<Option<NetId>>), CellId> = HashMap::new();
    let mut n = 0;
    for c in nl.cell_ids() {
        let cell = nl.cell(c);
        let Some(l) = cell.lib() else { continue };
        // pads, fixed cells and cells with bidirectional pins are never merged
        if cell.fixed || cell.has_attr("io_pad") || cell.pins.iter().any(|p| p.dir == Dir::InOut) {
            continue;
        }
        if cell.frozen() || cell.has_attr("clone") || cell.has_attr("opt_buffer") || cell.has_attr("iso") || cell.has_attr("ls") || cell.pins.iter().filter(|p| p.dir == Dir::Out).count() != 1 {
            continue;
        }
        let up = l.to_uppercase();
        if up.starts_with("BUF") || up.starts_with("INV") || up.starts_with("TIE") || up.starts_with("DLY") || up.contains("AON") {
            continue;
        }
        let key = (l.to_string(), cell.pins.iter().map(|p| if p.dir != Dir::Out { p.net } else { None }).collect::<Vec<_>>());
        if key.1.iter().all(|x| x.is_none()) {
            continue;
        }
        if let Some(&o) = h.get(&key) {
            let oo = nl.cell(o).pins.iter().position(|p| p.dir == Dir::Out).unwrap();
            let co = nl.cell(c).pins.iter().position(|p| p.dir == Dir::Out).unwrap();
            let (Some(on), Some(cn)) = (nl.cell(o).pins[oo].net, nl.cell(c).pins[co].net) else { continue };
            if nl.loads(on).len() + nl.loads(cn).len() > max_fanout {
                continue;
            }
            if nl.net(cn).conns.iter().any(|p| matches!(p, PinRef::Port(_))) && nl.net(on).conns.iter().any(|p| matches!(p, PinRef::Port(_))) {
                continue;
            }
            nl.remove_cell(c);
            crate::genopt::merge_named(nl, on, cn);
            n += 1;
        } else {
            h.insert(key, c);
        }
    }
    n
}

/// Merge previously cloned cells back when not timing critical.
pub fn declone(nl: &mut Netlist, env: &Env, max_fanout: usize) -> usize {
    let a = env.analyze(nl, 0);
    let mut n = 0;
    for c in nl.cell_ids() {
        if !nl.cell_alive(c) || !nl.cell(c).has_attr("clone") {
            continue;
        }
        let out = nl.cell(c).pins.iter().position(|p| p.dir == Dir::Out).unwrap();
        if a.slack.get(&PinRef::Cell(c, out)).copied().unwrap_or(f64::INFINITY) < 0.05 {
            continue;
        }
        let k = nl.cell(c).clone();
        let orig = nl.cell_ids().into_iter().find(|&o| o != c && nl.cell(o).kind == k.kind && !nl.cell(o).has_attr("clone") && nl.cell(o).pins.iter().zip(k.pins.iter()).all(|(x, y)| x.dir == Dir::Out || x.net == y.net));
        if let Some(o) = orig {
            let on = nl.cell(o).pins[out].net.unwrap();
            let cn = k.pins[out].net.unwrap();
            if nl.loads(on).len() + nl.loads(cn).len() <= max_fanout {
                nl.remove_cell(c);
                nl.merge_net(on, cn);
                n += 1;
            }
        }
    }
    n
}

// ------------------------------------------------------------------ register retiming
fn seq_signature(nl: &Netlist, env: &Env, c: CellId) -> Option<(String, Option<NetId>, Vec<(String, Option<NetId>)>)> {
    let cell = nl.cell(c);
    let lc = env.lc(cell.lib()?)?;
    let s = crate::techmap::classify_seq(lc)?;
    if s.latch {
        return None;
    }
    let ck = cell.pin_net(&s.ck);
    let mut asyncs = vec![];
    for (p, _) in s.clr.iter().chain(s.pre.iter()) {
        asyncs.push((p.clone(), cell.pin_net(p)));
    }
    Some((lc.name.clone(), ck, asyncs))
}

/// Forward/backward register retiming across single combinational gates, guided by slack.
pub fn retime(nl: &mut Netlist, env: &Env, max_moves: usize) -> usize {
    let mut moves = 0;
    for _ in 0..max_moves {
        let a = env.analyze(nl, 10);
        if a.wns >= 0.0 {
            break;
        }
        let mut done = false;
        // forward: gate G whose inputs all come from single-fanout flops with identical clock/async
        let crit_cells: Vec<CellId> = a.crit.iter().flatten().filter_map(|p| if let PinRef::Cell(c, _) = p { Some(*c) } else { None }).collect();
        'outer: for &g in &crit_cells {
            if !nl.cell_alive(g) || nl.cell(g).frozen() {
                continue;
            }
            let Some(glc) = nl.cell(g).lib().and_then(|l| env.lc(l)) else { continue };
            if !glc.is_comb() {
                continue;
            }
            let ins: Vec<(String, NetId)> = nl.cell(g).pins.iter().filter(|p| p.dir == Dir::In).filter_map(|p| p.net.map(|n| (p.name.clone(), n))).collect();
            let mut ffs = vec![];
            let mut sig0 = None;
            for (_, n) in &ins {
                let Some(d) = nl.driver_cell(*n) else { continue 'outer };
                if nl.loads(*n).len() != 1 || nl.cell(d).frozen() {
                    continue 'outer;
                }
                let Some(sg) = seq_signature(nl, env, d) else { continue 'outer };
                if sig0.as_ref().map(|s: &(String, Option<NetId>, Vec<(String, Option<NetId>)>)| s.1 != sg.1 || s.2 != sg.2).unwrap_or(false) {
                    continue 'outer;
                }
                sig0 = Some(sg);
                ffs.push(d);
            }
            let Some(sig) = sig0 else { continue };
            // D-side slack must accommodate the gate delay
            let gd = crate::techmap::nominal_delay(glc);
            let dslack: f64 = ffs.iter().map(|f| {
                let lc = env.lc(nl.cell(*f).lib().unwrap()).unwrap();
                let s = crate::techmap::classify_seq(lc).unwrap();
                let dp = nl.cell(*f).pin(&s.d).unwrap();
                a.slack.get(&PinRef::Cell(*f, dp)).copied().unwrap_or(f64::INFINITY)
            }).fold(f64::INFINITY, f64::min);
            if dslack < gd * 1.5 {
                continue;
            }
            // reset value of the retimed register
            let ff_lc = env.lc(&sig.0).unwrap();
            let sq = crate::techmap::classify_seq(ff_lc).unwrap();
            if sq.qn.is_some() && sq.q.is_none() {
                continue;
            }
            let has_async = sig.2.iter().any(|(_, n)| n.map(|x| crate::genopt::const_of(nl, x).is_none()).unwrap_or(false));
            let mut new_cell = sig.0.clone();
            if has_async {
                // all retimed regs reset to 0 (clear) -> evaluate gate at all-zero inputs
                let f = parse_func(glc.outputs()[0].function.as_ref().unwrap()).unwrap();
                let v = f.eval(&|_| false);
                if v {
                    // need preset flop with same clear net polarity
                    let Some(alt) = crate::techmap::pick_seq(env.lib(), false, false, true, &crate::techmap::MapOpts::default()) else { continue };
                    if sq.clr.is_none() {
                        continue;
                    }
                    let _ = alt;
                    continue; // conservative: skip polarity-changing retiming
                }
                if sq.pre.is_some() {
                    continue;
                }
                new_cell = sig.0.clone();
            }
            // build: G' on D side, single flop on output
            let gout = glc.outputs()[0].name.clone();
            let Some(gy) = nl.cell(g).pin_net(&gout) else { continue };
            let gname = nl.cell(g).name.clone();
            let gk = nl.cell(g).kind.clone();
            let gpins: Vec<(String, Dir)> = nl.cell(g).pins.iter().map(|p| (p.name.clone(), p.dir)).collect();
            let mut dnets = vec![];
            for (pn, n) in &ins {
                let f = nl.driver_cell(*n).unwrap();
                let dn = nl.cell(f).pin_net(&sq.d).unwrap();
                dnets.push((pn.clone(), dn));
            }
            let ff0 = nl.cell(ffs[0]).clone();
            let ffname = format!("{}_retimed", ff0.name);
            for f in &ffs {
                nl.remove_cell(*f);
            }
            nl.remove_cell(g);
            let g2 = nl.add_cell(&format!("{}_rt", gname), gk, &gpins.iter().map(|(a, b)| (a.as_str(), *b)).collect::<Vec<_>>());
            let nd = nl.add_net(&format!("{}_rt_d", gname));
            for (pn, dn) in &dnets {
                nl.connect_name(g2, pn, *dn);
            }
            nl.connect_name(g2, &gout, nd);
            let f2 = nl.add_cell(&ffname, Kind::Lib(new_cell.clone()), &lib_pins(env.lc(&new_cell).unwrap()));
            nl.connect_name(f2, &sq.d, nd);
            if let Some(ck) = sig.1 {
                nl.connect_name(f2, &sq.ck, ck);
            }
            for (p, n) in &sig.2 {
                if let Some(n) = n {
                    nl.connect_name(f2, p, *n);
                }
            }
            nl.connect_name(f2, sq.q.as_ref().unwrap(), gy);
            nl.cell_mut(f2).loc = ff0.loc;
            crate::info!("OPT-1900", "Retimed {} register(s) forward across '{}' -> '{}'", ffs.len(), gname, ffname);
            moves += 1;
            done = true;
            nl.sweep_nets();
            break;
        }
        if !done {
            break;
        }
    }
    moves
}

// ------------------------------------------------------------------ physical
pub fn coarse_place(nl: &mut Netlist, die: (f64, f64, f64, f64), iters: usize) -> usize {
    let unplaced: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| nl.cell(*c).loc.is_none()).collect();
    if unplaced.is_empty() {
        return 0;
    }
    let cx = (die.0 + die.2) / 2.0;
    let cy = (die.1 + die.3) / 2.0;
    for (i, c) in unplaced.iter().enumerate() {
        let a = i as f64 * 2.399;
        let r = (i as f64).sqrt() * ((die.2 - die.0).min(die.3 - die.1) / 2.0 / (unplaced.len() as f64).sqrt().max(1.0));
        nl.cell_mut(*c).loc = Some((cx + r * a.cos(), cy + r * a.sin()));
    }
    for _ in 0..iters {
        for &c in &unplaced {
            let (mut sx, mut sy, mut k) = (0.0, 0.0, 0.0);
            for p in nl.cell(c).pins.clone() {
                let Some(n) = p.net else { continue };
                if nl.net(n).conns.len() > 50 {
                    continue;
                }
                for pr in &nl.net(n).conns {
                    if let PinRef::Cell(o, _) = pr {
                        if *o == c {
                            continue;
                        }
                    }
                    if let Some((x, y)) = nl.pin_loc(*pr) {
                        sx += x;
                        sy += y;
                        k += 1.0;
                    }
                }
            }
            if k > 0.0 {
                let (x, y) = (sx / k, sy / k);
                nl.cell_mut(c).loc = Some((x.clamp(die.0, die.2), y.clamp(die.1, die.3)));
            }
        }
    }
    unplaced.len()
}

/// Physically-aware register & clock-gate movement toward connectivity centroid.
pub fn move_registers(nl: &mut Netlist, env: &Env, die: (f64, f64, f64, f64)) -> (usize, usize) {
    let (mut r, mut g) = (0, 0);
    for c in nl.cell_ids() {
        let cell = nl.cell(c);
        if cell.fixed || cell.dont_touch {
            continue;
        }
        let Some(lc) = cell.lib().and_then(|l| env.lc(l)) else { continue };
        let is_icg = lc.icg.is_some();
        if lc.seq.is_none() && !is_icg {
            continue;
        }
        let (mut sx, mut sy, mut k) = (0.0, 0.0, 0.0);
        for p in &cell.pins {
            let Some(n) = p.net else { continue };
            let clockpin = lc.pin(&p.name).map(|x| x.is_clock || x.cg_role.as_deref() == Some("clock")).unwrap_or(false);
            if clockpin {
                continue;
            }
            let conns = &nl.net(n).conns;
            if conns.len() > 64 && !is_icg {
                continue;
            }
            for pr in conns {
                if *pr == PinRef::Cell(c, cell.pin(&p.name).unwrap()) {
                    continue;
                }
                if let Some((x, y)) = nl.pin_loc(*pr) {
                    sx += x;
                    sy += y;
                    k += 1.0;
                }
            }
        }
        if k == 0.0 {
            continue;
        }
        let nloc = ((sx / k).clamp(die.0, die.2), (sy / k).clamp(die.1, die.3));
        let old = nl.cell(c).loc;
        if old.map(|o| ((o.0 - nloc.0).abs() + (o.1 - nloc.1).abs()) > 1.0).unwrap_or(true) {
            nl.cell_mut(c).loc = Some(nloc);
            if is_icg {
                g += 1
            } else {
                r += 1
            }
        }
    }
    (r, g)
}
