//! Technology mapping: priority-cut (K=4) Boolean matching against the target
//! library (all pin permutations, output-inversion fallback), delay-oriented
//! selection followed by area-flow recovery under required times; sequential
//! mapping of generic DFF/latch with async set/reset to library flops/latches.

use crate::liberty::{parse_func, LibCell, Library};
use crate::netlist::*;
use std::collections::{HashMap, HashSet};

#[derive(Clone, Debug)]
pub struct Match {
    pub cell: String,
    pub pins: Vec<String>,
    pub area: f64,
    pub delay: f64,
    pub inv_out: bool,
}

#[derive(Clone, Debug)]
pub struct MapOpts {
    pub vt: Option<String>,
    pub area_recovery: bool,
    pub dont_use: Vec<String>,
    pub max_cuts: usize,
}
impl Default for MapOpts {
    fn default() -> Self {
        MapOpts { vt: None, area_recovery: true, dont_use: vec![], max_cuts: 10 }
    }
}

fn perms(n: usize) -> Vec<Vec<usize>> {
    if n == 0 {
        return vec![vec![]];
    }
    let mut out = vec![];
    for p in perms(n - 1) {
        for i in 0..=p.len() {
            let mut q = p.clone();
            q.insert(i, n - 1);
            out.push(q);
        }
    }
    out
}

pub fn nominal_delay(c: &LibCell) -> f64 {
    let out = c.outputs();
    let Some(o) = out.first() else { return 0.1 };
    let cap = c.inputs().iter().map(|p| p.cap).sum::<f64>() / c.inputs().len().max(1) as f64 * 4.0;
    let mut d: f64 = 0.0;
    for a in &o.arcs {
        if let Some(t) = &a.cell_rise {
            d = d.max(t.delay(0.05, cap.max(0.004)));
        }
        if let Some(t) = &a.cell_fall {
            d = d.max(t.delay(0.05, cap.max(0.004)));
        }
    }
    if d == 0.0 {
        0.05
    } else {
        d
    }
}

fn usable(c: &LibCell, o: &MapOpts) -> bool {
    !c.dont_use && !o.dont_use.iter().any(|d| glob(d, &c.name)) && !c.is_iso && !c.is_ls && !c.always_on && !c.is_delay && !c.retention && !c.is_switch && c.tie.is_none()
}

pub struct Dict {
    pub m: HashMap<(usize, u16), Match>,
    pub inv: Option<Match>,
}

pub fn build_dict(lib: &Library, o: &MapOpts) -> Dict {
    let mut m: HashMap<(usize, u16), Match> = HashMap::new();
    let vt_pref = o.vt.clone().unwrap_or_else(|| {
        let mut cnt: std::collections::BTreeMap<&str, usize> = std::collections::BTreeMap::new();
        for c in lib.cells_sorted().into_iter() {
            *cnt.entry(c.vt.as_str()).or_default() += 1;
        }
        if cnt.contains_key("SVT") { "SVT".into() } else { cnt.into_iter().max_by_key(|x| x.1).map(|x| x.0.to_string()).unwrap_or_default() }
    });
    for name in &lib.cell_order {
        let c = &lib.cells[name];
        if !c.is_comb() || !usable(c, o) || c.vt != vt_pref {
            continue;
        }
        let ins: Vec<String> = c.inputs().iter().map(|p| p.name.clone()).collect();
        let k = ins.len();
        if k == 0 || k > 4 {
            continue;
        }
        let Some(f) = c.outputs()[0].function.as_ref().and_then(|f| parse_func(f)) else { continue };
        let delay = nominal_delay(c);
        for p in perms(k) {
            // leaf i -> pin ins[p[i]]
            let mut tt: u16 = 0;
            for mt in 0..(1u32 << k) {
                let v = f.eval(&|pn: &str| {
                    let pi = ins.iter().position(|x| x == pn);
                    match pi {
                        Some(pi) => {
                            let leaf = p.iter().position(|&q| q == pi).unwrap();
                            (mt >> leaf) & 1 == 1
                        }
                        None => false,
                    }
                });
                if v {
                    tt |= 1 << mt;
                }
            }
            let pins: Vec<String> = (0..k).map(|i| ins[p[i]].clone()).collect();
            let cand = Match { cell: c.name.clone(), pins, area: c.area, delay, inv_out: false };
            let e = m.entry((k, tt)).or_insert(cand.clone());
            if cand.area < e.area - 1e-9 || ((cand.area - e.area).abs() < 1e-9 && cand.delay < e.delay) {
                *e = cand;
            }
        }
    }
    let inv = m.get(&(1, 0b01)).cloned();
    Dict { m, inv }
}

#[derive(Clone)]
struct Cut {
    leaves: Vec<NetId>,
    tt: u16,
}

fn expand(tt: u16, from: &[NetId], to: &[NetId]) -> u16 {
    let pos: Vec<usize> = from.iter().map(|l| to.iter().position(|x| x == l).unwrap()).collect();
    let q = to.len();
    let mut r = 0u16;
    for m in 0..(1u32 << q) {
        let mut mm = 0u32;
        for (i, &p) in pos.iter().enumerate() {
            if (m >> p) & 1 == 1 {
                mm |= 1 << i;
            }
        }
        if (tt >> mm) & 1 == 1 {
            r |= 1 << m;
        }
    }
    r
}
fn mask(k: usize) -> u16 {
    if k >= 4 {
        0xFFFF
    } else {
        ((1u32 << (1 << k)) - 1) as u16
    }
}
fn shrink(c: &mut Cut) {
    let mut i = 0;
    while i < c.leaves.len() {
        let k = c.leaves.len();
        let mut dep = false;
        for m in 0..(1u32 << k) {
            if (m >> i) & 1 == 0 {
                let a = (c.tt >> m) & 1;
                let b = (c.tt >> (m | (1 << i))) & 1;
                if a != b {
                    dep = true;
                    break;
                }
            }
        }
        if dep {
            i += 1;
            continue;
        }
        // remove var i
        let mut nt = 0u16;
        let mut idx = 0;
        for m in 0..(1u32 << k) {
            if (m >> i) & 1 == 0 {
                if (c.tt >> m) & 1 == 1 {
                    nt |= 1 << idx;
                }
                idx += 1;
            }
        }
        c.tt = nt;
        c.leaves.remove(i);
    }
}

#[derive(Default, Debug)]
pub struct MapStats {
    pub comb: usize,
    pub seq: usize,
    pub inv_added: usize,
    pub area: f64,
}

pub fn map(nl: &mut Netlist, lib: &Library, o: &MapOpts) -> Result<MapStats, String> {
    let dict = build_dict(lib, o);
    for (need, nm) in [((1usize, 0b01u16), "inverter"), ((2, 0b0111), "NAND2"), ((2, 0b1000), "AND2/NAND2")] {
        if !dict.m.contains_key(&need) && !dict.m.contains_key(&(need.0, !need.1 & mask(need.0))) {
            return Err(format!("Target library lacks a usable {} function (OPT-101)", nm));
        }
    }
    let mut st = MapStats::default();
    // ---- comb nodes
    let mut node_of: HashMap<NetId, CellId> = HashMap::new();
    for c in nl.cell_ids() {
        let cell = nl.cell(c);
        if let Some(op) = cell.gop() {
            if matches!(op, GOp::Buf | GOp::Not | GOp::And | GOp::Or | GOp::Xor | GOp::Nand | GOp::Nor | GOp::Xnor | GOp::Mux) && !cell.dont_touch {
                if let Some(y) = cell.pin_net("Y") {
                    node_of.insert(y, c);
                }
            }
        }
    }
    let fanins = |nl: &Netlist, c: CellId| -> Vec<NetId> { nl.cell(c).pins.iter().filter(|p| p.dir == Dir::In).filter_map(|p| p.net).collect() };
    // topo order
    let mut order: Vec<NetId> = vec![];
    let mut state: HashMap<NetId, u8> = HashMap::new();
    let mut roots: Vec<NetId> = node_of.keys().copied().collect();
    roots.sort();
    for r in roots {
        let mut stack = vec![(r, false)];
        while let Some((n, post)) = stack.pop() {
            if post {
                state.insert(n, 2);
                order.push(n);
                continue;
            }
            if state.get(&n).copied().unwrap_or(0) != 0 {
                continue;
            }
            state.insert(n, 1);
            stack.push((n, true));
            if let Some(&c) = node_of.get(&n) {
                for f in fanins(nl, c) {
                    if node_of.contains_key(&f) && state.get(&f).copied().unwrap_or(0) == 0 {
                        stack.push((f, false));
                    }
                }
            }
        }
    }
    let fo: HashMap<NetId, usize> = node_of.keys().map(|n| (*n, nl.loads(*n).len().max(1))).collect();
    let mut cuts: HashMap<NetId, Vec<Cut>> = HashMap::new();
    let triv = |n: NetId| Cut { leaves: vec![n], tt: 0b10 };
    let mut best: HashMap<NetId, (Cut, Match)> = HashMap::new();
    let mut arr: HashMap<NetId, f64> = HashMap::new();
    let mut af: HashMap<NetId, f64> = HashMap::new();
    let inv_d = dict.inv.as_ref().map(|m| m.delay).unwrap_or(0.03);
    let inv_a = dict.inv.as_ref().map(|m| m.area).unwrap_or(1.0);
    let lookup = |c: &Cut| -> Option<Match> {
        let k = c.leaves.len();
        if let Some(m) = dict.m.get(&(k, c.tt)) {
            return Some(m.clone());
        }
        let nt = !c.tt & mask(k);
        dict.m.get(&(k, nt)).map(|m| {
            let mut m = m.clone();
            m.inv_out = true;
            m.area += inv_a;
            m.delay += inv_d;
            m
        })
    };
    for &n in &order {
        let c = node_of[&n];
        let op = nl.cell(c).gop().unwrap();
        let fi = fanins(nl, c);
        let fsets: Vec<Vec<Cut>> = fi.iter().map(|f| cuts.get(f).cloned().unwrap_or_else(|| vec![triv(*f)])).collect();
        let mut cand: Vec<Cut> = vec![];
        let combine = |sets: &[&Cut]| -> Option<Cut> {
            let mut u: Vec<NetId> = vec![];
            for s in sets {
                for l in &s.leaves {
                    if !u.contains(l) {
                        u.push(*l)
                    }
                }
            }
            if u.len() > 4 {
                return None;
            }
            u.sort();
            let k = u.len();
            let t: Vec<u16> = sets.iter().map(|s| expand(s.tt, &s.leaves, &u)).collect();
            let mk = mask(k);
            let tt = match op {
                GOp::Buf => t[0],
                GOp::Not => !t[0] & mk,
                GOp::And => t[0] & t[1],
                GOp::Or => t[0] | t[1],
                GOp::Xor => t[0] ^ t[1],
                GOp::Nand => !(t[0] & t[1]) & mk,
                GOp::Nor => !(t[0] | t[1]) & mk,
                GOp::Xnor => !(t[0] ^ t[1]) & mk,
                GOp::Mux => (t[0] & t[2]) | (!t[0] & t[1] & mk),
                _ => return None,
            };
            let mut cu = Cut { leaves: u, tt };
            shrink(&mut cu);
            Some(cu)
        };
        match fsets.len() {
            1 => {
                for a in &fsets[0] {
                    if let Some(x) = combine(&[a]) {
                        cand.push(x)
                    }
                }
            }
            2 => {
                for a in &fsets[0] {
                    for b in &fsets[1] {
                        if let Some(x) = combine(&[a, b]) {
                            cand.push(x)
                        }
                    }
                }
            }
            3 => {
                for a in &fsets[0] {
                    for b in &fsets[1] {
                        for cc in &fsets[2] {
                            if let Some(x) = combine(&[a, b, cc]) {
                                cand.push(x)
                            }
                        }
                    }
                }
            }
            _ => {}
        }
        // dedupe
        let mut seen = HashSet::new();
        cand.retain(|c| !c.leaves.is_empty() && seen.insert((c.leaves.clone(), c.tt)));
        // evaluate
        let mut scored: Vec<(f64, f64, Cut, Match)> = vec![];
        for cu in cand {
            let Some(m) = lookup(&cu) else { continue };
            let a = cu.leaves.iter().map(|l| arr.get(l).copied().unwrap_or(0.0)).fold(0.0, f64::max) + m.delay;
            let f = m.area + cu.leaves.iter().map(|l| af.get(l).copied().unwrap_or(0.0) / *fo.get(l).unwrap_or(&1) as f64).sum::<f64>();
            scored.push((a, f, cu, m));
        }
        if scored.is_empty() {
            // no cut matched: fall back to the trivial-fanin cut decomposed by inverter pairs is impossible
            return Err(format!("No library match for generic {:?} gate driving '{}' (OPT-102)", op, nl.net(n).name));
        }
        scored.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap().then(a.1.partial_cmp(&b.1).unwrap()));
        let (a, f, cu, m) = scored[0].clone();
        arr.insert(n, a);
        af.insert(n, f);
        best.insert(n, (cu, m));
        let mut keep: Vec<Cut> = scored.iter().take(o.max_cuts).map(|s| s.2.clone()).collect();
        keep.push(triv(n));
        cuts.insert(n, keep);
    }
    // roots: nets driven by comb nodes with a non-node load
    let is_root = |nl: &Netlist, n: NetId| -> bool {
        nl.net(n).conns.iter().any(|pr| match pr {
            PinRef::Port(p) => nl.ports[*p].dir != Dir::In,
            PinRef::Cell(c, p) => nl.cell(*c).pins[*p].dir != Dir::Out && !(node_of.values().any(|x| x == c)),
        })
    };
    let node_cells: HashSet<CellId> = node_of.values().copied().collect();
    let is_root2 = |nl: &Netlist, n: NetId| -> bool {
        nl.net(n).conns.iter().any(|pr| match pr {
            PinRef::Port(p) => nl.ports[*p].dir != Dir::In,
            PinRef::Cell(c, p) => nl.cell(*c).pins[*p].dir != Dir::Out && !node_cells.contains(c),
        })
    };
    let _ = is_root;
    let roots: Vec<NetId> = order.iter().copied().filter(|n| is_root2(nl, *n)).collect();
    // area recovery under required times
    if o.area_recovery {
        let tmax = roots.iter().map(|r| arr[r]).fold(0.0, f64::max);
        let mut req: HashMap<NetId, f64> = HashMap::new();
        for r in &roots {
            req.insert(*r, tmax);
        }
        let mut cover: Vec<NetId> = vec![];
        let mut inc: HashSet<NetId> = HashSet::new();
        let mut stack = roots.clone();
        while let Some(n) = stack.pop() {
            if !inc.insert(n) {
                continue;
            }
            cover.push(n);
            for l in &best[&n].0.leaves {
                if node_of.contains_key(l) {
                    stack.push(*l)
                }
            }
        }
        for &n in order.iter().rev() {
            if !inc.contains(&n) {
                continue;
            }
            let r = *req.get(&n).unwrap_or(&f64::INFINITY);
            let d = best[&n].1.delay;
            for l in best[&n].0.leaves.clone() {
                let e = req.entry(l).or_insert(f64::INFINITY);
                *e = e.min(r - d);
            }
        }
        // re-select with area flow
        arr.clear();
        af.clear();
        for &n in &order {
            let r = *req.get(&n).unwrap_or(&f64::INFINITY);
            let mut bestc: Option<(f64, f64, Cut, Match)> = None;
            for cu in cuts[&n].iter().filter(|c| !(c.leaves.len() == 1 && c.leaves[0] == n)) {
                let Some(m) = lookup(cu) else { continue };
                let a = cu.leaves.iter().map(|l| arr.get(l).copied().unwrap_or(0.0)).fold(0.0, f64::max) + m.delay;
                let f = m.area + cu.leaves.iter().map(|l| af.get(l).copied().unwrap_or(0.0) / *fo.get(l).unwrap_or(&1) as f64).sum::<f64>();
                if a > r + 1e-9 {
                    continue;
                }
                if bestc.as_ref().map(|b| f < b.1 - 1e-9 || ((f - b.1).abs() < 1e-9 && a < b.0)).unwrap_or(true) {
                    bestc = Some((a, f, cu.clone(), m));
                }
            }
            if let Some((a, f, cu, m)) = bestc {
                arr.insert(n, a);
                af.insert(n, f);
                best.insert(n, (cu, m));
            } else {
                let (cu, m) = best[&n].clone();
                let a = cu.leaves.iter().map(|l| arr.get(l).copied().unwrap_or(0.0)).fold(0.0, f64::max) + m.delay;
                arr.insert(n, a);
                af.insert(n, 0.0);
            }
        }
    }
    // final cover
    let mut needed: Vec<NetId> = vec![];
    let mut inc: HashSet<NetId> = HashSet::new();
    let mut stack = roots.clone();
    while let Some(n) = stack.pop() {
        if !inc.insert(n) {
            continue;
        }
        needed.push(n);
        for l in &best[&n].0.leaves {
            if node_of.contains_key(l) {
                stack.push(*l)
            }
        }
    }
    // record names, remove generic comb cells
    let names: HashMap<NetId, String> = node_of.iter().map(|(n, c)| (*n, nl.cell(*c).name.clone())).collect();
    for c in node_cells {
        nl.remove_cell(c);
    }
    needed.sort();
    for n in needed {
        let (cu, m) = best[&n].clone();
        let lc = &lib.cells[&m.cell];
        let pins: Vec<(&str, Dir)> = lc.pins.iter().map(|p| (p.name.as_str(), p.dir.unwrap_or(Dir::In))).collect();
        let c = nl.add_cell(&names[&n], Kind::Lib(m.cell.clone()), &pins);
        for (i, l) in cu.leaves.iter().enumerate() {
            nl.connect_name(c, &m.pins[i], *l);
        }
        let opin = lc.outputs()[0].name.clone();
        if m.inv_out {
            let t = nl.add_net(&format!("{}_ninv", nl.net(n).name.clone()));
            nl.connect_name(c, &opin, t);
            let im = dict.inv.as_ref().unwrap();
            let ilc = &lib.cells[&im.cell];
            let ipins: Vec<(&str, Dir)> = ilc.pins.iter().map(|p| (p.name.as_str(), p.dir.unwrap_or(Dir::In))).collect();
            let nm = nl.fresh(&format!("{}_inv", names[&n]));
            let ic = nl.add_cell(&nm, Kind::Lib(im.cell.clone()), &ipins);
            nl.connect_name(ic, &im.pins[0], t);
            nl.connect_name(ic, &ilc.outputs()[0].name, n);
            st.inv_added += 1;
            st.area += ilc.area;
        } else {
            nl.connect_name(c, &opin, n);
        }
        st.comb += 1;
        st.area += lc.area;
    }
    // ---- sequential mapping
    st.seq = map_seq(nl, lib, o)?;
    nl.sweep_nets();
    nl.mapped = true;
    Ok(st)
}

#[derive(Clone, Debug)]
pub struct SeqLib {
    pub cell: String,
    pub latch: bool,
    pub d: String,
    pub ck: String,
    pub ck_inv: bool,
    pub q: Option<String>,
    pub qn: Option<String>,
    pub clr: Option<(String, bool)>,
    pub pre: Option<(String, bool)>,
    pub area: f64,
}

fn pin_of(expr: &str) -> (String, bool) {
    let s = expr.trim().trim_matches('"').trim();
    if let Some(x) = s.strip_prefix('!') {
        return (x.trim_matches(|c| c == '(' || c == ')').to_string(), true);
    }
    if let Some(x) = s.strip_suffix('\'') {
        return (x.to_string(), true);
    }
    (s.to_string(), false)
}

pub fn classify_seq(c: &LibCell) -> Option<SeqLib> {
    let s = c.seq.as_ref()?;
    if c.scan || c.retention || c.icg.is_some() {
        return None;
    }
    let (d, dinv) = pin_of(&s.next_state);
    if dinv || c.pin(&d).is_none() {
        return None;
    }
    let (ck, ck_inv) = pin_of(&s.clocked_on);
    c.pin(&ck)?;
    let mut q = None;
    let mut qn = None;
    for o in c.outputs() {
        let f = o.function.clone().unwrap_or_default();
        let f = f.trim().trim_matches('"').trim().to_string();
        if f.starts_with('!') || f.ends_with('\'') || f.ends_with('N') {
            qn = Some(o.name.clone())
        } else {
            q = Some(o.name.clone())
        }
    }
    Some(SeqLib {
        cell: c.name.clone(),
        latch: s.is_latch,
        d,
        ck,
        ck_inv,
        q,
        qn,
        clr: s.clear.as_ref().map(|x| {
            let (p, inv) = pin_of(x);
            (p, inv)
        }),
        pre: s.preset.as_ref().map(|x| {
            let (p, inv) = pin_of(x);
            (p, inv)
        }),
        area: c.area,
    })
}

pub fn pick_seq(lib: &Library, latch: bool, need_clr: bool, need_pre: bool, o: &MapOpts) -> Option<SeqLib> {
    let vt = o.vt.clone().unwrap_or("SVT".into());
    let mut cands: Vec<(i32, SeqLib)> = vec![];
    for c in lib.cells_sorted().into_iter() {
        if c.dont_use || o.dont_use.iter().any(|d| glob(d, &c.name)) {
            continue;
        }
        let Some(s) = classify_seq(c) else { continue };
        if s.latch != latch || s.ck_inv {
            continue;
        }
        if (need_clr && s.clr.is_none()) || (need_pre && s.pre.is_none()) {
            continue;
        }
        let extra = (s.clr.is_some() && !need_clr) as i32 + (s.pre.is_some() && !need_pre) as i32 + if c.vt != vt { 2 } else { 0 } + if s.q.is_none() { 1 } else { 0 };
        cands.push((extra, s));
    }
    cands.sort_by(|a, b| a.0.cmp(&b.0).then(a.1.area.partial_cmp(&b.1.area).unwrap()));
    cands.into_iter().next().map(|x| x.1)
}

fn map_seq(nl: &mut Netlist, lib: &Library, o: &MapOpts) -> Result<usize, String> {
    let dict = build_dict(lib, o);
    let inv = dict.inv.clone().ok_or("no inverter")?;
    let mut n = 0;
    for c in nl.cell_ids() {
        let cell = nl.cell(c).clone();
        let latch = match cell.gop() {
            Some(GOp::Dff) => false,
            Some(GOp::Latch) => true,
            _ => continue,
        };
        let has_clr = cell.pin_net("RN").is_some();
        let has_pre = cell.pin_net("SN").is_some();
        let s = pick_seq(lib, latch, has_clr, has_pre, o).ok_or_else(|| format!("No library {} with{}{} found for '{}' (OPT-103)", if latch { "latch" } else { "flip-flop" }, if has_clr { " clear" } else { "" }, if has_pre { " preset" } else { "" }, cell.name))?;
        let lc = &lib.cells[&s.cell];
        let pins: Vec<(&str, Dir)> = lc.pins.iter().map(|p| (p.name.as_str(), p.dir.unwrap_or(Dir::In))).collect();
        let d = cell.pin_net("D");
        let ck = cell.pin_net(if latch { "G" } else { "CK" });
        let q = cell.pin_net("Q");
        let rn = cell.pin_net("RN");
        let sn = cell.pin_net("SN");
        let name = cell.name.clone();
        nl.remove_cell(c);
        let nc = nl.add_cell(&name, Kind::Lib(s.cell.clone()), &pins);
        if let Some(d) = d {
            nl.connect_name(nc, &s.d, d);
        }
        if let Some(ck) = ck {
            nl.connect_name(nc, &s.ck, ck);
        }
        let add_inv = |nl: &mut Netlist, from: NetId, to: NetId| {
            let ilc = &lib.cells[&inv.cell];
            let ip: Vec<(&str, Dir)> = ilc.pins.iter().map(|p| (p.name.as_str(), p.dir.unwrap_or(Dir::In))).collect();
            let nm = nl.fresh(&format!("{}_inv", name));
            let ic = nl.add_cell(&nm, Kind::Lib(inv.cell.clone()), &ip);
            nl.connect_name(ic, &inv.pins[0], from);
            nl.connect_name(ic, &ilc.outputs()[0].name, to);
        };
        // async pins (generic RN/SN are active low)
        for (lp, gnet) in [(&s.clr, rn), (&s.pre, sn)] {
            if let Some((pn, active_low)) = lp {
                match gnet {
                    Some(g) => {
                        if *active_low {
                            nl.connect_name(nc, pn, g);
                        } else {
                            let t = nl.add_net(&format!("{}_{}_n", name, pn));
                            add_inv(nl, g, t);
                            nl.connect_name(nc, pn, t);
                        }
                    }
                    None => {
                        let k = crate::genopt::const_net(nl, *active_low);
                        nl.connect_name(nc, pn, k);
                    }
                }
            }
        }
        if let Some(q) = q {
            match (&s.q, &s.qn) {
                (Some(qp), _) => {
                    nl.connect_name(nc, qp, q);
                }
                (None, Some(qnp)) => {
                    let t = nl.add_net(&format!("{}_QN", name));
                    nl.connect_name(nc, qnp, t);
                    add_inv(nl, t, q);
                }
                _ => {}
            }
        }
        n += 1;
    }
    Ok(n)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn cut_truth_table_ops() {
        // f(a,b)=a&b over leaves [1,2] expanded to [1,2,3]
        let t = expand(0b1000, &[1, 2], &[1, 2, 3]);
        assert_eq!(t, 0b1000_1000);
        let mut c = Cut { leaves: vec![1, 2, 3], tt: t };
        shrink(&mut c); // var 3 is redundant
        assert_eq!(c.leaves, vec![1, 2]);
        assert_eq!(c.tt, 0b1000);
        assert_eq!(perms(3).len(), 6);
    }
}
