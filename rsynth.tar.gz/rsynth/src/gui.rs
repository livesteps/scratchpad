//! GUI state document: the JSON the GTK GUI renders (floorplan objects, cells, pins, power
//! domains, flylines, schematic, routed wires, LEF layers). `gui_write_state file.json` writes it.

use crate::fplan::*;
use crate::netlist::*;
use crate::session::Session;
use std::fmt::Write as _;

fn js(s: &str) -> String {
    let mut o = String::from("\"");
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            '\r' => {}
            '<' => o.push_str("\\u003c"),
            c if (c as u32) < 0x20 => {
                let _ = write!(o, "\\u{:04x}", c as u32);
            }
            c => o.push(c),
        }
    }
    o.push('"');
    o
}
fn r4(r: &Rect) -> String {
    format!("[{:.3},{:.3},{:.3},{:.3}]", r.0, r.1, r.2, r.3)
}
fn f3(v: f64) -> String {
    if v.is_finite() {
        format!("{:.3}", v)
    } else {
        "null".into()
    }
}

pub fn state_json(s: &Session) -> String {
    state_json_ext(s, true)
}

/// `full` adds the physical detail of the layout view (core, routed wires and vias, special
/// wiring, bumps, bond pads, macro / pad pin shapes)
pub fn state_json_ext(s: &Session, full: bool) -> String {
    let mut o = state_core(s);
    o.pop();
    if let Some(fp) = &s.fp {
        if fp.rows_explicit {
            let _ = write!(o, ",\"rowl\":[{}]", fp.row_list.iter().map(|r| format!("[{},{},{},{},{}]", f3(r.x), f3(r.y), f3(r.x1()), f3(r.y + r.height), js(&r.orient))).collect::<Vec<_>>().join(","));
        }
        let _ = write!(o, ",\"tracks\":[{}]", fp.track_list.iter().map(|t| format!("[{},\"{}\",{},{},{}]", js(&t.layer), t.dir, f3(t.start), t.num, f3(t.step))).collect::<Vec<_>>().join(","));
    }
    let _ = write!(o, ",\"markers\":[{}]", s.pgx.markers.iter().take(20000).map(|m| format!("[{},{},{},{},{},{},{},{},[{}]]", js(&m.tool), js(&m.kind), js(&m.layer), f3(m.rect.0), f3(m.rect.1), f3(m.rect.2), f3(m.rect.3), js(&m.msg), m.nets.iter().map(|n| js(n)).collect::<Vec<_>>().join(","))).collect::<Vec<_>>().join(","));
    let _ = write!(o, ",\"rulers\":[{}],\"query\":{}", s.gui.rulers.iter().map(|r| format!("[{},{},{},{}]", f3(r.0), f3(r.1), f3(r.2), f3(r.3))).collect::<Vec<_>>().join(","),
        s.gui.query.as_ref().map(|(k, n)| format!("[{},{}]", js(k), js(n))).unwrap_or("null".into()));
    let _ = write!(o, ",\"ndrs\":[{}],\"mlayers\":[{}]", s.pgx.ndrs.iter().map(|r| js(&r.name)).collect::<Vec<_>>().join(","), s.metal_order().iter().map(|l| js(l)).collect::<Vec<_>>().join(","));
    let _ = write!(o, ",\"lef_layers\":[{}]", s.lef_layers.iter().map(|l| format!("{{\"n\":{},\"k\":{},\"d\":{},\"p\":{},\"w\":{}}}", js(&l.name), js(&l.kind), js(&l.dir), f3(l.pitch), f3(l.width))).collect::<Vec<_>>().join(","));
    let _ = write!(o, ",\"sch\":{},\"fly\":{},\"zoom\":{}", s.sch_json(), s.fly_json(),
        s.gui.zoom.map(|(r, k)| format!("{{\"r\":{},\"k\":{}}}", r4(&r), k)).unwrap_or("null".into()));
    if full {
        if let Some(fp) = &s.fp {
            let _ = write!(o, ",\"core\":{}", fp.core.map(|c| r4(&c)).unwrap_or("null".into()));
            // routed wires: collinear unit edges merged per net
            if let Some(db) = s.routes.as_ref() {
                let mut segs: Vec<String> = vec![];
                let mut vias: Vec<String> = vec![];
                let mut nets: Vec<_> = db.nets.keys().copied().collect();
                nets.sort();
                let mut rnames: Vec<String> = vec![];
                'n: for n in nets {
                    let rn = &db.nets[&n];
                    let mut runs: Vec<(usize, (f64, f64), (f64, f64))> = vec![];
                    for (c, p) in &rn.tree {
                        if *p == crate::droute::NONE { continue; }
                        let (x1, y1, l1) = db.pos(*c);
                        let (x2, y2, l2) = db.pos(*p);
                        if l1 != l2 { vias.push(format!("[{},{},{}]", f3(x1), f3(y1), l1.min(l2))); continue; }
                        if let Some(r) = runs.iter_mut().find(|r| r.0 == l1 && r.2 == (x2, y2) && ((r.1 .0 == r.2 .0 && x1 == x2) || (r.1 .1 == r.2 .1 && y1 == y2))) { r.2 = (x1, y1); continue; }
                        runs.push((l1, (x2, y2), (x1, y1)));
                    }
                    let ni = rnames.len();
                    rnames.push(js(&s.nl.as_ref().map(|nl| nl.net(n).name.clone()).unwrap_or_default()));
                    for r in runs {
                        segs.push(format!("[{},{},{},{},{},{}]", r.0, f3(r.1 .0), f3(r.1 .1), f3(r.2 .0), f3(r.2 .1), ni));
                        if segs.len() > 400000 { break 'n; }
                    }
                }
                let _ = write!(o, ",\"routes\":{{\"layers\":[{}],\"segs\":[{}],\"vias\":[{}],\"w\":{},\"nets\":[{}]}}",
                    db.layers.iter().map(|l| js(&l.name)).collect::<Vec<_>>().join(","), segs.join(","), vias.join(","), f3(db.g), rnames.join(","));
            }
            let _ = write!(o, ",\"special\":[{}]", fp.special.iter().map(|sh| format!("[{},{},{},[{}],{},{},{}]", js(&sh.layer), js(&sh.kind), f3(sh.width),
                sh.pts.iter().map(|p| format!("{},{}", f3(p.0), f3(p.1))).collect::<Vec<_>>().join(","), sh.rect.map(|r| r4(&r)).unwrap_or("null".into()), js(&sh.net),
                sh.via.as_ref().map(|v| format!("[{},{},{},{},{},{},{},{}]", v.cols, v.rows, f3(v.cut_w), f3(v.cut_h), f3(v.sp_x), f3(v.sp_y), js(&v.lower), js(&v.upper))).unwrap_or("null".into()))).collect::<Vec<_>>().join(","));
            let _ = write!(o, ",\"bumps\":[{}]", fp.bumps.iter().map(|b| format!("[{},{},{},{},{},{}]", js(&b.name), f3(b.x), f3(b.y),
                f3(s.lef.get(&b.cell).map(|m| m.w).unwrap_or(40.0)), js(&b.kind), js(&b.net))).collect::<Vec<_>>().join(","));
            let _ = write!(o, ",\"bonds\":[{}]", fp.io.bond_pads.iter().map(|b| r4(&b.rect)).collect::<Vec<_>>().join(","));
            let mut mp = vec![];
            if let Some(nl) = s.nl.as_ref() {
                for c in nl.cell_ids() {
                    let cl = nl.cell(c);
                    let Some(m) = crate::lef::phys(&s.lef, cl) else { continue };
                    if cl.loc.is_none() { continue; }
                    for p in &m.pins {
                        for (ly, r) in crate::lef::pin_shapes(&s.lef, cl, &p.name) {
                            mp.push(format!("[{},{},{}]", r4(&r), js(&ly), js(&p.name)));
                        }
                    }
                    if mp.len() > 50000 { break; }
                }
            }
            let _ = write!(o, ",\"mpins\":[{}]", mp.join(","));
        }
    }
    o.push('}');
    o
}

fn state_core(s: &Session) -> String {
    let mut o = String::from("{");
    let nl = s.nl.as_ref();
    let _ = write!(o, "\"design\":{},", js(&nl.map(|n| n.name.clone()).unwrap_or_default()));
    let Some(fp) = &s.fp else {
        o.push_str("\"die\":null}");
        return o;
    };
    let _ = write!(o, "\"die\":{},\"row_h\":{},", r4(&fp.die), f3(fp.row_h));
    let _ = write!(o, "\"layers\":[{}],", fp.layers.iter().map(|l| format!("{{\"n\":{},\"h\":{}}}", js(&l.name), l.horiz)).collect::<Vec<_>>().join(","));
    let _ = write!(o, "\"pblk\":[{}],", fp.pblk.iter().map(|b| format!("{{\"n\":{},\"r\":{},\"k\":{},\"src\":{}}}", js(&b.name), r4(&b.rect), js(&match b.kind {
        PbKind::Hard => "hard".to_string(),
        PbKind::HardMacro => "hard_macro".into(),
        PbKind::Soft => "soft".into(),
        PbKind::Partial(p) => format!("partial {}%", p),
    }), js(&b.source))).collect::<Vec<_>>().join(","));
    let _ = write!(o, "\"rblk\":[{}],", fp.rblk.iter().map(|b| format!("{{\"n\":{},\"r\":{},\"l\":{}}}", js(&b.name), r4(&b.rect), js(&if b.layers.is_empty() { "all".into() } else { b.layers.join(",") }))).collect::<Vec<_>>().join(","));
    let _ = write!(o, "\"guides\":[{}],", fp.guides.iter().map(|g| format!("{{\"n\":{},\"r\":{},\"nets\":{},\"tu\":{}}}", js(&g.name), r4(&g.rect), js(&g.nets.join(" ")), g.track_util.map(f3).unwrap_or("null".into()))).collect::<Vec<_>>().join(","));
    let mut bnames: Vec<String> = vec![];
    let _ = write!(o, "\"bounds\":[{}],", fp.bounds.iter().filter_map(|b| {
        let r = b.resolved.or(b.rect)?;
        bnames.push(b.name.clone());
        Some(format!("{{\"n\":{},\"r\":{},\"k\":{},\"m\":{}}}", js(&b.name), r4(&r), js(&format!("{:?}", b.kind).to_lowercase()), js(&b.members.join(" "))))
    }).collect::<Vec<_>>().join(","));
    let _ = write!(o, "\"feeds\":[{}],", fp.feeds.iter().map(|f| format!("{{\"n\":{},\"reg\":{},\"nets\":{}}}", js(&f.name), js(&f.region), js(&f.nets.join(" ")))).collect::<Vec<_>>().join(","));
    // power domains (UPF) + voltage areas
    let top = s.upf.top_domain();
    let pdl: Vec<String> = s.upf.domains.iter().map(|d| {
        let st = s.pd_stats(&d.name);
        let va = fp.vas.iter().find(|v| v.pds.contains(&d.name));
        let sws: Vec<String> = s.upf.switches.iter().filter(|w| w.domain == d.name).map(|w| w.name.clone()).collect();
        let ns = |v: &Vec<String>| v.iter().map(|x| js(x)).collect::<Vec<_>>().join(",");
        let strat = |k: &str| -> Vec<String> {
            match k {
                "iso" => s.upf.iso.iter().filter(|x| x.domain == d.name).map(|x| x.name.clone()).collect(),
                "ls" => s.upf.ls.iter().filter(|x| x.domain == d.name).map(|x| x.name.clone()).collect(),
                _ => s.upf.ret.iter().filter(|x| x.domain == d.name).map(|x| x.name.clone()).collect(),
            }
        };
        format!("{{\"n\":{},\"top\":{},\"el\":[{}],\"v\":{},\"sw\":{},\"pwr\":{},\"gnd\":{},\"ss\":{},\"va\":{},\"vin\":{},\"van\":{},\"c\":{},\"pl\":{},\"out\":{},\"iso\":{},\"ls\":{},\"ret\":{},\"area\":{},\"siso\":[{}],\"sls\":[{}],\"sret\":[{}],\"swi\":[{}]}}",
            js(&d.name), top.as_deref() == Some(d.name.as_str()), ns(&d.elements),
            s.upf.domain_voltage(&d.name).map(f3).unwrap_or("null".into()), s.upf.switchable(&d.name),
            js(&s.upf.domain_power(d).unwrap_or_default()), js(&d.ground.clone().or_else(|| d.supply_set.as_ref().and_then(|x| s.upf.supply_sets.get(x)).and_then(|x| x.1.clone())).unwrap_or_default()), js(d.supply_set.as_deref().unwrap_or("")),
            va.map(|v| r4(&v.rect)).unwrap_or("null".into()), va.map(|v| r4(&v.inner())).unwrap_or("null".into()), js(va.map(|v| v.name.as_str()).unwrap_or("")),
            st.cells, st.placed, st.outside, st.iso, st.ls, st.ret, f3(st.area), ns(&strat("iso")), ns(&strat("ls")), ns(&strat("ret")), ns(&sws))
    }).collect();
    let _ = write!(o, "\"pds\":[{}],\"pdhl\":[{}],\"colorby\":{},", pdl.join(","), s.pd_hl.iter().map(|x| js(x)).collect::<Vec<_>>().join(","), js(&s.gui_color_by));
    let pd_index = |name: &str| -> i64 { s.cell_domain(name).and_then(|d| s.upf.domains.iter().position(|x| x.name == d)).map(|i| i as i64).unwrap_or(-1) };
    let _ = write!(o, "\"parts\":[{}],", s.partitions.iter().map(|p| format!("{{\"n\":{},\"inst\":{},\"b\":{}}}", js(&p.name), js(&p.inst), js(p.bound.as_deref().unwrap_or("")))).collect::<Vec<_>>().join(","));
    if let Some(nl) = nl {
        let mut ps = vec![];
        for p in nl.port_ids() {
            let pt = &nl.ports[p];
            let Some((x, y)) = pt.loc else { continue };
            let (sd, ly, src) = fp.pin_info.get(&pt.name).cloned().unwrap_or_default();
            ps.push(format!("[{},{},{},{},{},{},{}]", js(&pt.name), f3(x), f3(y), js(&sd), js(&ly), js(&src), js(match pt.dir {
                Dir::In => "in",
                Dir::Out => "out",
                Dir::InOut => "inout",
            })));
        }
        let _ = write!(o, "\"ports\":[{}],", ps.join(","));
        let mut groups: Vec<String> = vec![];
        let mut cs = vec![];
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            let Some((mut x, mut y)) = cell.loc else { continue };
            // LEF-placed blocks / pads (lower-left placement): draw at the footprint centre
            if let Some(r) = crate::lef::cell_rect(&s.lef, cell) {
                x = (r.0 + r.2) / 2.0;
                y = (r.1 + r.3) / 2.0;
                let a = (r.2 - r.0) * (r.3 - r.1);
                let top = cell.name.split('/').next().filter(|_| cell.name.contains('/')).unwrap_or("(top)").to_string();
                let gi = match groups.iter().position(|g| *g == top) { Some(i) => i, None => { groups.push(top); groups.len() - 1 } };
                let ty = if cell.lib().or(match &cell.kind { Kind::BlackBox(b) => Some(b.as_str()), _ => None }).map(|m| s.phys_kind_of(m).is_some()).unwrap_or(false) { "f" } else if crate::lef::phys(&s.lef, cell).map(|m| m.is_pad() || m.is_corner()).unwrap_or(false) { "p" } else { "b" };
                cs.push(format!("[{},{},{},{:.2},{},{},{},{},{},{}]", js(&cell.name), f3(x), f3(y), a.sqrt(), js(ty), gi, if cell.fixed { 1 } else { 0 }, pd_index(&cell.name), f3(r.2 - r.0), f3(r.3 - r.1)));
                continue;
            }
            let (ty, area) = match &cell.kind {
                Kind::Lib(l) => {
                    let lc = s.libs.iter().find_map(|x| x.cells.get(l));
                    let a = lc.map(|x| x.area).unwrap_or(1.0);
                    let t = if s.phys_kind_of(l).is_some() {
                        "f"
                    } else if cell.has_attr("iso") || cell.has_attr("ls") {
                        "u"
                    } else if lc.map(|x| x.icg.is_some()).unwrap_or(false) {
                        "i"
                    } else if lc.map(|x| x.seq.is_some()).unwrap_or(false) {
                        "s"
                    } else if cell.has_attr("opt_buffer") {
                        "o"
                    } else {
                        "c"
                    };
                    (t, a)
                }
                Kind::BlackBox(_) => ("b", 64.0),
                Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1) => continue,
                Kind::Gen(_) => ("c", 1.0),
            };
            let top = cell.name.split('/').next().filter(|_| cell.name.contains('/')).unwrap_or("(top)").to_string();
            let gi = match groups.iter().position(|g| *g == top) {
                Some(i) => i,
                None => {
                    groups.push(top);
                    groups.len() - 1
                }
            };
            // footprint: standard cells are one row high, black boxes square
            let (w, h) = if ty != "b" && fp.row_h > 0.0 && area <= 8.0 * fp.row_h * fp.row_h { (area / fp.row_h, fp.row_h) } else { (area.sqrt(), area.sqrt()) };
            cs.push(format!("[{},{},{},{:.2},{},{},{},{},{},{}]", js(&cell.name), f3(x), f3(y), area.sqrt(), js(ty), gi, if cell.fixed { 1 } else { 0 }, pd_index(&cell.name), f3(w), f3(h)));
        }
        let _ = write!(o, "\"groups\":[{}],\"cells\":[{}],", groups.iter().map(|g| js(g)).collect::<Vec<_>>().join(","), cs.join(","));
        // selection (select_obj / add_to_selection): cell names, plus the cells of selected pins and nets
        let mut sel: Vec<String> = vec![];
        for h in &s.selection {
            match crate::cons::Obj::parse(h) {
                Some(crate::cons::Obj::Cell(c)) => sel.push(c),
                Some(crate::cons::Obj::Pin(p)) => sel.extend(p.rsplit_once('/').map(|x| x.0.to_string())),
                Some(crate::cons::Obj::Net(n)) => {
                    if let Some(id) = nl.net_by_name(&n) {
                        for pr in &nl.net(id).conns {
                            if let PinRef::Cell(c, _) = pr {
                                sel.push(nl.cell(*c).name.clone());
                            }
                        }
                    }
                }
                _ => {}
            }
        }
        let _ = write!(o, "\"sel\":[{}],", sel.iter().map(|x| js(x)).collect::<Vec<_>>().join(","));
    }
    match &fp.groute {
        Some(g) => {
            let u: Vec<String> = (0..g.nx * g.ny).map(|k| format!("{:.2}", (g.dem[k][0] / g.cap[k][0].max(1e-9)).max(g.dem[k][1] / g.cap[k][1].max(1e-9)).min(9.99))).collect();
            let _ = write!(o, "\"cong\":{{\"nx\":{},\"ny\":{},\"g\":{},\"u\":[{}],\"ov\":{},\"wl\":{}}}", g.nx, g.ny, f3(g.gcell), u.join(","), f3(g.overflow), f3(g.wirelength));
        }
        None => o.push_str("\"cong\":null"),
    }
    o.push('}');
    o
}

