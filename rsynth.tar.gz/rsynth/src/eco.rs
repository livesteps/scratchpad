//! Netlist ECO commands: ports, instances, connections, repeaters, sizing and cell changes.
//! Every successful change is recorded in the session ECO log (`report_eco_changes`, `write_eco_changes`).

use crate::cons::Obj;
use crate::liberty::LibCell;
use crate::netlist::*;
use crate::session::*;
use crate::tcl::{split_list, to_list, Flow};
use std::collections::HashSet;

type R = Result<String, Flow>;

fn err<T: Into<String>>(m: T) -> R {
    Err(Flow::Err(m.into()))
}

/// names from a mix of collections, plain names and wildcard patterns
fn names(s: &str) -> Vec<String> {
    split_list(s).into_iter().map(|x| Obj::parse(&x).map(|o| o.name().to_string()).unwrap_or(x)).collect()
}

/// expand `bus[7:0]` (and `bus[*]` with a width) into bit names
fn expand_bits(n: &str, width: Option<usize>) -> Result<Vec<String>, String> {
    if let (Some(o), true) = (n.rfind('['), n.ends_with(']')) {
        let base = &n[..o];
        let inner = &n[o + 1..n.len() - 1];
        if inner == "*" {
            let w = width.ok_or_else(|| format!("'{}': a [*] pattern needs -bus_width", n))?;
            return Ok((0..w).rev().map(|i| format!("{}[{}]", base, i)).collect());
        }
        if let Some((h, l)) = inner.split_once(':') {
            let (h, l): (i64, i64) = (h.trim().parse().map_err(|_| format!("bad range in '{}'", n))?, l.trim().parse().map_err(|_| format!("bad range in '{}'", n))?);
            let v: Vec<i64> = if h >= l { (l..=h).rev().collect() } else { (h..=l).collect() };
            return Ok(v.into_iter().map(|i| format!("{}[{}]", base, i)).collect());
        }
    }
    if n.contains('*') || n.contains('?') {
        return Err(format!("'{}': wildcards are only allowed as a bus range 'name[*]' with -bus_width N, or 'name[msb:lsb]'", n));
    }
    Ok(vec![n.to_string()])
}

impl Session {
    fn eco_log(&mut self, name: &str, a: &[String]) {
        if self.in_eco_diff {
            return; // the enclosing command records the exact netlist diff
        }
        // brace any argument Tcl would otherwise substitute or split, so the log replays with `source`
        let q = |x: &String| -> String {
            let x = crate::cons::collection_names(x).map(|v| v.join(" ")).unwrap_or_else(|| {
                let it = split_list(x);
                if it.len() == 1 { it[0].clone() } else { x.clone() }
            });
            if x.is_empty() || x.chars().any(|c| " \t[]$\\;\"{}".contains(c)) { format!("{{{}}}", x) } else { x }
        };
        let line = std::iter::once(name.to_string()).chain(a.iter().map(q)).collect::<Vec<_>>().join(" ");
        self.eco_changes.push(line);
    }

    fn find_lib_cell(&self, n: &str) -> Option<LibCell> {
        let n = Obj::parse(n).map(|o| o.name().to_string()).unwrap_or(n.to_string());
        let n = n.rsplit('/').next().unwrap_or(&n).to_string();
        self.libs.iter().find_map(|l| l.cells.get(&n)).cloned()
    }

    /// owner (kept hierarchy instance) of a hierarchical name
    fn owner_hier(&self, name: &str) -> String {
        let Some(nl) = self.nl.as_ref() else { return String::new() };
        let kept: HashSet<&str> = nl.hier.iter().filter(|(i, _)| !nl.ungrouped.contains(i)).map(|(i, _)| i.as_str()).collect();
        let mut best = String::new();
        let mut end = 0;
        while let Some(i) = name[end..].find('/') {
            end += i;
            if kept.contains(&name[..end]) {
                best = name[..end].to_string();
            }
            end += 1;
        }
        best
    }

    /// hierarchy a pin lives in (boundary pins: the outer side belongs to the parent)
    fn pin_owner(&self, pr: PinRef) -> String {
        let Some(nl) = self.nl.as_ref() else { return String::new() };
        match pr {
            PinRef::Port(_) => String::new(),
            PinRef::Cell(c, p) => {
                let cl = nl.cell(c);
                if let Some((inst, _, is_in)) = cl.hport() {
                    let outside = (is_in && cl.pins[p].name == "A") || (!is_in && cl.pins[p].name == "Y");
                    return if outside { self.owner_hier(&inst) } else { inst };
                }
                self.owner_hier(&cl.name)
            }
        }
    }

    /// hierarchies a connection between owners `a` and `b` must punch ports through
    fn punch_path(&self, a: &str, b: &str) -> Vec<String> {
        let anc = |x: &str, y: &str| x.is_empty() || y == x || y.starts_with(&format!("{}/", x));
        let mut l = a.to_string();
        while !anc(&l, b) {
            l = self.owner_hier(&l);
        }
        let mut out = vec![];
        for s in [a, b] {
            let mut h = s.to_string();
            while h != l {
                out.push(h.clone());
                h = self.owner_hier(&h);
            }
        }
        out
    }

    fn cells_of(&self, s: &str) -> Vec<String> {
        let nl = match self.nl.as_ref() {
            Some(n) => n,
            None => return vec![],
        };
        let mut out = vec![];
        for n in names(s) {
            if nl.cell_by_name(&n).is_some() {
                out.push(n);
            } else if n.contains('*') || n.contains('?') {
                let mut m: Vec<String> = nl.cell_ids().into_iter().map(|c| nl.cell(c).name.clone()).filter(|c| glob(&n, c)).collect();
                m.sort();
                out.extend(m);
            } else {
                out.push(n); // reported as missing by the caller
            }
        }
        out
    }

    pub(crate) fn eco_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        let r = match name {
            // ------------------------------------------------------------- ports
            "eco_create_ports" | "create_port" | "create_ports" => {
                let x = args(a, &["-direction", "-bus_width", "-port_type"]);
                let dir = match x.get("-direction").map(|s| s.as_str()).unwrap_or("in") {
                    "in" | "input" => Dir::In,
                    "out" | "output" => Dir::Out,
                    "inout" => Dir::InOut,
                    d => return Some(err(format!("{}: bad -direction '{}' (in|out|inout)", name, d))),
                };
                let w = x.num("-bus_width").map(|v| v as usize);
                let mut bits = vec![];
                for p in x.pos.iter().flat_map(|p| split_list(p)) {
                    match expand_bits(&p, w) {
                        Ok(v) => bits.extend(v),
                        Err(e) => return Some(err(format!("{}: {}", name, e))),
                    }
                }
                if bits.is_empty() {
                    return Some(err(format!("{}: no port names given", name)));
                }
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                if let Some(b) = bits.iter().find(|b| nl.port_by_name(b).is_some()) {
                    return Some(err(format!("{}: port '{}' already exists (ECO-201)", name, b)));
                }
                for b in &bits {
                    let p = nl.add_port(b, dir);
                    let _ = p;
                }
                crate::info!("ECO-200", "Created {} {} port(s): {}", bits.len(), match dir { Dir::In => "input", Dir::Out => "output", Dir::InOut => "inout" }, abbrev_list(&bits, 8));
                self.eco_log(name, a);
                Ok(to_list(&bits.iter().map(|b| Obj::Port(b.clone()).handle()).collect::<Vec<_>>()))
            }
            "eco_delete_ports" | "remove_port" | "remove_ports" => {
                let x = args(a, &[]);
                let pats: Vec<String> = x.pos.iter().flat_map(|p| names(p)).collect();
                let Some(nl) = self.nl.as_ref() else { return Some(err("no design")) };
                let mut ids: Vec<PortId> = vec![];
                for p in &pats {
                    let m: Vec<PortId> = nl.port_ids().into_iter().filter(|q| glob(p, &nl.ports[*q].name)).collect();
                    if m.is_empty() {
                        crate::warn!("ECO-203", "{}: no port matches '{}'", name, p);
                    }
                    ids.extend(m);
                }
                ids.sort();
                ids.dedup();
                let clk_src: HashSet<String> = self.modes.iter().flat_map(|m| m.sdc.clocks.iter().flat_map(|c| c.sources.iter().map(|s| s.name().to_string()))).collect();
                let nl = self.nl.as_mut().unwrap();
                let mut dangling = 0;
                let mut del = vec![];
                for p in ids {
                    let pn = nl.ports[p].name.clone();
                    if clk_src.contains(&pn) {
                        crate::warn!("ECO-204", "Deleting port '{}', which is a clock source", pn);
                    }
                    if let Some(n) = nl.ports[p].net {
                        dangling += nl.net(n).conns.iter().filter(|c| matches!(c, PinRef::Cell(..))).count();
                    }
                    nl.remove_port(p);
                    del.push(pn);
                }
                crate::info!("ECO-202", "Deleted {} port(s){}{}", del.len(), if del.is_empty() { String::new() } else { format!(": {}", abbrev_list(&del, 8)) }, if dangling > 0 { format!("; {} pin(s) left on now port-less nets", dangling) } else { String::new() });
                if !del.is_empty() {
                    self.eco_log(name, a);
                }
                Ok(del.len().to_string())
            }
            // ------------------------------------------------------------- nets
            "create_net" | "eco_create_net" => {
                let x = args(a, &[]);
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let mut made = vec![];
                for n in x.pos.iter().flat_map(|p| split_list(p)) {
                    if nl.net_by_name(&n).is_some() {
                        return Some(err(format!("{}: net '{}' already exists", name, n)));
                    }
                    nl.add_net(&n);
                    made.push(Obj::Net(n).handle());
                }
                self.eco_log(name, a);
                Ok(to_list(&made))
            }
            "remove_net" | "remove_nets" | "eco_delete_net" => {
                let x = args(a, &[]);
                let force = x.has("-force");
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let mut k = 0;
                for n in x.pos.iter().flat_map(|p| names(p)) {
                    let Some(id) = nl.net_by_name(&n) else {
                        crate::warn!("ECO-205", "net '{}' not found", n);
                        continue;
                    };
                    if !nl.net(id).conns.is_empty() && !force {
                        return Some(err(format!("{}: net '{}' still has {} connection(s); disconnect them or use -force", name, n, nl.net(id).conns.len())));
                    }
                    for c in nl.net(id).conns.clone() {
                        match c {
                            PinRef::Cell(c, p) => nl.disconnect(c, p),
                            PinRef::Port(p) => nl.ports[p].net = None,
                        }
                    }
                    nl.remove_net(id);
                    k += 1;
                }
                self.eco_log(name, a);
                Ok(k.to_string())
            }
            // ------------------------------------------------------------- instances
            "add_instance" | "create_cell" | "eco_add_instance" => {
                let x = args(a, &["-name", "-cell", "-lib_cell", "-location", "-orientation"]);
                let mut inames: Vec<String> = x.get("-name").map(|s| split_list(s)).unwrap_or_default();
                let mut lc = x.get("-cell").or(x.get("-lib_cell")).cloned();
                if name == "create_cell" && inames.is_empty() && x.pos.len() >= 2 {
                    inames = split_list(&x.pos[0]);
                    lc = Some(x.pos[1].clone());
                }
                let Some(lc) = lc else { return Some(err(format!("{}: -cell <library_cell> is required", name))) };
                if inames.is_empty() {
                    return Some(err(format!("{}: -name <instance_name> is required", name)));
                }
                let Some(cell) = self.find_lib_cell(&lc) else { return Some(err(format!("{}: library cell '{}' not found (ECO-002)", name, lc))) };
                let loc = x.get("-location").map(|l| split_list(&l.replace(['{', '}'], " "))).and_then(|v| if v.len() >= 2 { Some((v[0].parse::<f64>().ok()?, v[1].parse::<f64>().ok()?)) } else { None });
                let pins: Vec<(String, Dir)> = crate::opt::lib_pins(&cell).into_iter().map(|(p, d)| (p.to_string(), d)).collect();
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let mut made = vec![];
                for n in &inames {
                    if nl.cell_by_name(n).is_some() || nl.hier.iter().any(|(h, _)| h == n) {
                        return Some(err(format!("{}: instance '{}' already exists (ECO-211)", name, n)));
                    }
                    let pr: Vec<(&str, Dir)> = pins.iter().map(|(p, d)| (p.as_str(), *d)).collect();
                    let c = nl.add_cell(n, Kind::Lib(cell.name.clone()), &pr);
                    nl.cell_mut(c).loc = loc;
                    nl.cell_mut(c).attrs.push("eco".into());
                    made.push(Obj::Cell(n.clone()).handle());
                }
                crate::info!("ECO-210", "Added {} instance(s) of {} (pins unconnected): {}", made.len(), cell.name, abbrev_list(&inames, 6));
                self.eco_log(name, a);
                Ok(to_list(&made))
            }
            "delete_instance" | "remove_cell" | "remove_cells" | "eco_delete_instance" => {
                // delete_instance {names} | -inst {patterns} [-physical_only] [-force]
                let x = args(a, &["-inst", "-insts"]);
                let force = x.has("-force");
                let mut targets: Vec<String> = x.pos.iter().flat_map(|p| self.cells_of(p)).collect();
                if let Some(p) = x.get("-inst").or(x.get("-insts")) {
                    for q in split_list(p) { targets.extend(self.cells_of(&q)); }
                }
                if x.has("-physical_only") {
                    let n0 = targets.len();
                    targets.retain(|t| self.nl.as_ref().and_then(|nl| nl.cell_by_name(t)).and_then(|c| self.nl.as_ref().unwrap().cell(c).lib().map(|m| m.to_string())).map(|m| self.phys_kind_of(&m).is_some()).unwrap_or(false));
                    if n0 > targets.len() { crate::info!("ECO-215", "{}: {} matching logical instance(s) kept (-physical_only)", name, n0 - targets.len()); }
                }
                // physical-only cells (fillers, decaps, taps, end caps) are fixed / dont_touch by construction
                let phys: Vec<bool> = targets.iter().map(|t| self.nl.as_ref().and_then(|nl| nl.cell_by_name(t)).and_then(|c| self.nl.as_ref().unwrap().cell(c).lib().map(|m| m.to_string())).map(|m| self.phys_kind_of(&m).is_some()).unwrap_or(false)).collect();
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let mut del = 0;
                let mut hier_del = 0;
                for (ti, t) in targets.iter().enumerate() {
                    if let Some(c) = nl.cell_by_name(t) {
                        if nl.cell(c).frozen() && !force && !phys[ti] {
                            crate::error!("ECO-213", "'{}' is dont_touch/size_only; use -force", t);
                            continue;
                        }
                        nl.remove_cell(c);
                        del += 1;
                    } else if nl.hier.iter().any(|(h, _)| h == t) {
                        // hierarchical instance: delete everything below it
                        let pre = format!("{}/", t);
                        let inside: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| nl.cell(*c).name.starts_with(&pre)).collect();
                        if !force && inside.iter().any(|c| nl.cell(*c).dont_touch && !nl.cell(*c).is_hport()) {
                            crate::error!("ECO-213", "hierarchy '{}' contains dont_touch cells; use -force", t);
                            continue;
                        }
                        for c in &inside {
                            nl.remove_cell(*c);
                        }
                        nl.hier.retain(|(h, _)| h != t && !h.starts_with(&pre));
                        del += inside.iter().filter(|c| !nl.cell_alive(**c)).count();
                        hier_del += 1;
                    } else {
                        crate::warn!("ECO-212", "{}: instance '{}' not found", name, t);
                    }
                }
                crate::info!("ECO-214", "Deleted {} cell(s){}; nets left in place", del, if hier_del > 0 { format!(" ({} hierarchical instance(s))", hier_del) } else { String::new() });
                if del > 0 {
                    self.eco_log(name, a);
                }
                Ok(del.to_string())
            }
            // ------------------------------------------------------------- connections
            "disconnect_pin" | "disconnect_net" | "disconnect_pins" => {
                let x = args(a, &["-net", "-pin", "-pins"]);
                let net = x.get("-net").map(|n| names(n).into_iter().next().unwrap_or_default());
                let pins: Vec<String> = x.get("-pin").or(x.get("-pins")).into_iter().chain(x.pos.iter()).flat_map(|p| names(p)).collect();
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let netid = match &net {
                    Some(n) => match nl.net_by_name(n) {
                        Some(i) => Some(i),
                        None => return Some(err(format!("{}: net '{}' not found", name, n))),
                    },
                    None => None,
                };
                // disconnect_net -net n -all : everything on the net
                let pins: Vec<String> = if pins.is_empty() && x.has("-all") {
                    netid.map(|i| nl.net(i).conns.iter().map(|p| nl.pin_name(*p)).collect()).unwrap_or_default()
                } else {
                    pins
                };
                if pins.is_empty() {
                    return Some(err(format!("{}: give the pin(s) to disconnect", name)));
                }
                let mut k = 0;
                for p in &pins {
                    let Some(pr) = nl.find_pin(p) else { return Some(err(format!("{}: pin '{}' not found", name, p))) };
                    let cur = nl.pin_net(pr);
                    if cur.is_none() {
                        crate::warn!("ECO-221", "pin '{}' is not connected", p);
                        continue;
                    }
                    if let Some(want) = netid {
                        if cur != Some(want) {
                            return Some(err(format!("{}: pin '{}' is on net '{}', not '{}'", name, p, nl.net(cur.unwrap()).name, net.clone().unwrap())));
                        }
                    }
                    match pr {
                        PinRef::Cell(c, i) => {
                            if nl.cell(c).frozen() && !x.has("-force") {
                                return Some(err(format!("{}: '{}' is on a dont_touch/size_only cell; use -force", name, p)));
                            }
                            nl.disconnect(c, i)
                        }
                        PinRef::Port(q) => {
                            let n = nl.ports[q].net.take().unwrap();
                            nl.net_mut(n).conns.retain(|c| *c != PinRef::Port(q));
                        }
                    }
                    k += 1;
                }
                crate::info!("ECO-220", "Disconnected {} pin(s)", k);
                self.eco_log(name, a);
                Ok(k.to_string())
            }
            "connect" | "connect_net" | "connect_pin" | "connect_pins" | "eco_connect" => {
                let x = args(a, &["-net", "-pin", "-pins", "-driver", "-loads"]);
                let auto_disc = a.iter().any(|s| s.starts_with("-auto_disconnect"));
                let no_punch = x.has("-no_punch_ports");
                if let Some(n) = x.get("-net") {
                    if names(n).len() > 1 {
                        return Some(err(format!("{}: -net must name exactly one net (got {})", name, names(n).len())));
                    }
                }
                let Some(netn) = x.get("-net").map(|n| names(n).into_iter().next().unwrap_or_default()).or_else(|| if name == "connect_pins" { None } else { x.pos.first().cloned().filter(|_| x.get("-pin").is_some()) }) else {
                    // connect_pins -driver d -loads {..}: connect loads to the driver's net
                    if let (Some(d), Some(l)) = (x.get("-driver"), x.get("-loads")) {
                        let dn = names(d).into_iter().next().unwrap_or_default();
                        let nl = match self.nl.as_ref() { Some(n) => n, None => return Some(err("no design")) };
                        let Some(net) = nl.find_pin(&dn).and_then(|p| nl.pin_net(p)) else { return Some(err(format!("connect_pins: driver '{}' has no net", dn))) };
                        let nn = nl.net(net).name.clone();
                        let mut args2 = vec!["-net".to_string(), nn, "-pin".into(), l.clone()];
                        if auto_disc {
                            args2.push("-auto_disconnect_existing".into());
                        }
                        if no_punch {
                            args2.push("-no_punch_ports".into());
                        }
                        return self.eco_cmd("connect", &args2);
                    }
                    return Some(err(format!("{}: -net <net> is required", name)));
                };
                let pins: Vec<String> = x.get("-pin").or(x.get("-pins")).into_iter().chain(x.pos.iter().filter(|p| x.get("-net").is_some() || **p != netn)).flat_map(|p| names(p)).collect();
                if pins.is_empty() {
                    return Some(err(format!("{}: -pin <pin(s)> is required", name)));
                }
                // hierarchy bookkeeping for port punching
                let net_owners: Vec<String> = {
                    let Some(nl) = self.nl.as_ref() else { return Some(err("no design")) };
                    if nl.net_by_name(&netn).is_none() && !x.has("-create") {
                        return Some(err(format!("{}: net '{}' not found (use create_net, or -create)", name, netn)));
                    }
                    match nl.net_by_name(&netn) {
                        Some(id) => nl.net(id).conns.iter().map(|p| self.pin_owner(*p)).collect(),
                        None => vec![],
                    }
                };
                let pin_owners: Vec<String> = pins.iter().filter_map(|p| self.nl.as_ref().unwrap().find_pin(p)).map(|pr| self.pin_owner(pr)).collect();
                let mut punched: Vec<String> = vec![];
                for po in &pin_owners {
                    for no in &net_owners {
                        for h in self.punch_path(po, no) {
                            if !punched.contains(&h) {
                                punched.push(h);
                            }
                        }
                    }
                }
                if !punched.is_empty() && no_punch {
                    return Some(err(format!("{}: net '{}' and the pin(s) are in different hierarchies; ports would have to be punched through {} (-no_punch_ports given)", name, netn, abbrev_list(&punched, 4))));
                }
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let id = match nl.net_by_name(&netn) {
                    Some(i) => i,
                    None => nl.add_net(&netn),
                };
                let mut k = 0;
                for p in &pins {
                    let Some(pr) = nl.find_pin(p) else { return Some(err(format!("{}: pin '{}' not found", name, p))) };
                    if let Some(cur) = nl.pin_net(pr) {
                        if cur == id {
                            continue;
                        }
                        // a port alone on its own net (e.g. just created) moves without -auto_disconnect_existing
                        let lone_port = matches!(pr, PinRef::Port(_)) && nl.net(cur).conns.len() == 1;
                        if !auto_disc && !lone_port {
                            return Some(err(format!("{}: pin '{}' is already connected to net '{}' (use -auto_disconnect_existing)", name, p, nl.net(cur).name)));
                        }
                    }
                    let drives = nl.is_driver(pr) || matches!(pr, PinRef::Port(q) if nl.ports[q].dir == Dir::In);
                    if drives && nl.driver(id).map(|d| d != pr).unwrap_or(false) && !x.has("-force") {
                        return Some(err(format!("{}: net '{}' already has a driver ({}); connecting '{}' would create a multi-driven net (use -force)", name, netn, nl.pin_name(nl.driver(id).unwrap()), p)));
                    }
                    match pr {
                        PinRef::Cell(c, i) => {
                            if nl.cell(c).frozen() && !x.has("-force") {
                                return Some(err(format!("{}: '{}' is on a dont_touch/size_only cell; use -force", name, p)));
                            }
                            nl.connect(c, i, id)
                        }
                        PinRef::Port(q) => nl.connect_port(q, id),
                    }
                    k += 1;
                }
                if !punched.is_empty() {
                    crate::info!("ECO-232", "Connection crosses hierarchy: port(s) punched through {} (created as hierarchical ports by write_verilog)", abbrev_list(&punched, 6));
                }
                crate::info!("ECO-230", "Connected {} pin(s) to net '{}'", k, netn);
                if k > 0 {
                    self.eco_log(name, a);
                }
                Ok(k.to_string())
            }
            // ------------------------------------------------------------- repeaters
            "eco_add_repeater" | "add_repeater" | "eco_add_buffer" => {
                let x = args(a, &["-cell", "-lib_cell", "-pin", "-pins", "-net", "-stage_count", "-name", "-location"]);
                let Some(lc) = x.get("-cell").or(x.get("-lib_cell")).cloned() else { return Some(err(format!("{}: -cell <buffer/inverter> is required", name))) };
                let Some(buf) = self.find_lib_cell(&lc) else { return Some(err(format!("{}: library cell '{}' not found", name, lc))) };
                if !(buf.is_buf || buf.is_inv) {
                    return Some(err(format!("{}: '{}' is not a buffer or inverter", name, buf.name)));
                }
                let stages = x.num("-stage_count").map(|v| v as usize).unwrap_or(1).max(1);
                if buf.is_inv && stages % 2 == 1 {
                    return Some(err(format!("{}: inverter '{}' with -stage_count {} would invert the signal; use an even stage count", name, buf.name, stages)));
                }
                let prefix = x.get("-name").cloned().unwrap_or_else(|| "eco_rpt".into());
                let pins: Vec<String> = x.get("-pin").or(x.get("-pins")).map(|p| names(p)).unwrap_or_default();
                let netn = x.get("-net").map(|n| names(n).into_iter().next().unwrap_or_default());
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let (net, loads): (NetId, Vec<PinRef>) = if !pins.is_empty() {
                    let prs: Vec<PinRef> = match pins.iter().map(|p| nl.find_pin(p).ok_or(p.clone())).collect::<Result<Vec<_>, _>>() {
                        Ok(v) => v,
                        Err(p) => return Some(err(format!("{}: pin '{}' not found", name, p))),
                    };
                    let nets: HashSet<NetId> = prs.iter().filter_map(|p| nl.pin_net(*p)).collect();
                    if nets.len() != 1 {
                        return Some(err(format!("{}: the -pin loads must all be on one net (found {})", name, nets.len())));
                    }
                    let n = *nets.iter().next().unwrap();
                    if let Some(want) = &netn {
                        if &nl.net(n).name != want {
                            return Some(err(format!("{}: pins are on net '{}', not '{}'", name, nl.net(n).name, want)));
                        }
                    }
                    if prs.iter().any(|p| nl.is_driver(*p)) {
                        return Some(err(format!("{}: -pin must list load pins (the repeater drives them)", name)));
                    }
                    (n, prs)
                } else if let Some(nn) = &netn {
                    let Some(n) = nl.net_by_name(nn) else { return Some(err(format!("{}: net '{}' not found", name, nn))) };
                    (n, nl.loads(n))
                } else {
                    return Some(err(format!("{}: give -net <net> or -pin <load pins>", name)));
                };
                if loads.is_empty() {
                    return Some(err(format!("{}: net '{}' has no loads", name, nl.net(net).name)));
                }
                if nl.net(net).dont_touch && !x.has("-force") {
                    return Some(err(format!("{}: net '{}' is dont_touch", name, nl.net(net).name)));
                }
                let drv_loc = nl.driver(net).and_then(|d| nl.pin_loc(d));
                let (sx, sy, k) = loads.iter().filter_map(|l| nl.pin_loc(*l)).fold((0.0, 0.0, 0.0), |s, p| (s.0 + p.0, s.1 + p.1, s.2 + 1.0));
                let sink = if k > 0.0 { Some((sx / k, sy / k)) } else { None };
                let inp = buf.inputs()[0].name.clone();
                let mut cur_loads = loads.clone();
                let mut made = vec![];
                for s in 0..stages {
                    let b = crate::opt::insert_buffer(nl, net, &cur_loads, &buf, &format!("{}_", prefix));
                    nl.cell_mut(b).attrs.retain(|x| x != "opt_buffer");
                    nl.cell_mut(b).attrs.push("eco".into());
                    // place stages evenly from the sink back toward the driver
                    if let (Some(d), Some(t)) = (drv_loc, sink) {
                        let f = (s as f64 + 1.0) / (stages as f64 + 1.0);
                        nl.cell_mut(b).loc = Some((t.0 + (d.0 - t.0) * f, t.1 + (d.1 - t.1) * f));
                    }
                    let bi = nl.cell(b).pin(&inp).unwrap();
                    cur_loads = vec![PinRef::Cell(b, bi)];
                    made.push(nl.cell(b).name.clone());
                }
                made.reverse();
                crate::info!("ECO-240", "Added {} {} repeater stage(s) on net '{}' driving {} load(s): {}", stages, buf.name, nl.net(net).name, loads.len(), made.join(" -> "));
                self.eco_log(name, a);
                Ok(to_list(&made.iter().map(|m| Obj::Cell(m.clone()).handle()).collect::<Vec<_>>()))
            }
            "eco_delete_repeater" | "remove_buffers" | "eco_remove_repeater" | "remove_repeaters" => {
                let x = args(a, &["-net", "-nets", "-cells", "-inst"]);
                let mut want_buf = x.has("-buff") || x.has("-buffers") || x.has("-buf");
                let want_inv = x.has("-inv_pairs") || x.has("-inverter_pairs");
                if !want_buf && !want_inv {
                    want_buf = true;
                }
                let insts: Vec<String> = x.get("-cells").or(x.get("-inst")).into_iter().chain(x.pos.iter()).flat_map(|p| self.cells_of(p)).collect();
                let nets: Vec<String> = x.get("-net").or(x.get("-nets")).map(|n| names(n)).unwrap_or_default();
                let all = x.has("-all") || (insts.is_empty() && nets.is_empty() && name == "remove_buffers");
                if insts.is_empty() && nets.is_empty() && !all {
                    return Some(err(format!("{}: give repeater instances, -net <nets>, or -all", name)));
                }
                let libs = self.libs.clone();
                let lc_of = |nl: &Netlist, c: CellId| nl.cell(c).lib().and_then(|l| libs.iter().find_map(|x| x.cells.get(l)).cloned());
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                // candidate cells
                let mut cand: Vec<CellId> = vec![];
                if all {
                    cand = nl.cell_ids();
                }
                for i in &insts {
                    match nl.cell_by_name(i) {
                        Some(c) => cand.push(c),
                        None => crate::warn!("ECO-252", "{}: instance '{}' not found", name, i),
                    }
                }
                for n in &nets {
                    // the repeater chain driving the net, and repeaters it drives
                    let Some(id) = nl.net_by_name(n) else {
                        crate::warn!("ECO-252", "{}: net '{}' not found", name, n);
                        continue;
                    };
                    let mut cur = id;
                    for _ in 0..64 {
                        let Some(d) = nl.driver_cell(cur) else { break };
                        let Some(l) = lc_of(nl, d) else { break };
                        if !(l.is_buf || l.is_inv) {
                            break;
                        }
                        cand.push(d);
                        let Some(inn) = nl.cell(d).pins.iter().find(|p| p.dir == Dir::In).and_then(|p| p.net) else { break };
                        cur = inn;
                    }
                    for l in nl.loads(id) {
                        if let PinRef::Cell(c, _) = l {
                            cand.push(c);
                        }
                    }
                }
                let mut seen = HashSet::new();
                cand.retain(|c| seen.insert(*c));
                let (mut nb, mut ni, mut skipped) = (0, 0, 0);
                let io = |nl: &Netlist, c: CellId| -> Option<(NetId, NetId)> {
                    let i = nl.cell(c).pins.iter().find(|p| p.dir == Dir::In)?.net?;
                    let o = nl.cell(c).pins.iter().find(|p| p.dir == Dir::Out)?.net?;
                    Some((i, o))
                };
                let has_port = |nl: &Netlist, n: NetId| nl.net(n).conns.iter().any(|p| matches!(p, PinRef::Port(_)));
                for c in cand {
                    if !nl.cell_alive(c) {
                        continue;
                    }
                    let Some(l) = lc_of(nl, c) else { continue };
                    if nl.cell(c).frozen() || nl.cell(c).is_hport() {
                        if !all {
                            skipped += 1;
                        }
                        continue;
                    }
                    let Some((i, o)) = io(nl, c) else { continue };
                    if want_buf && l.is_buf && !l.is_seq() && !l.is_delay || (want_buf && l.is_delay && !all) {
                        if has_port(nl, i) && has_port(nl, o) || nl.net(o).dont_touch || nl.net(i).dont_touch {
                            skipped += 1;
                            continue;
                        }
                        nl.remove_cell(c);
                        if has_port(nl, o) && !has_port(nl, i) {
                            nl.merge_net(o, i);
                        } else {
                            nl.merge_net(i, o);
                        }
                        nb += 1;
                    } else if want_inv && l.is_inv {
                        // c drives exactly one load, an inverter: remove the pair
                        let ld = nl.loads(o);
                        if ld.len() != 1 || has_port(nl, o) {
                            continue;
                        }
                        let PinRef::Cell(c2, _) = ld[0] else { continue };
                        let Some(l2) = lc_of(nl, c2) else { continue };
                        if !l2.is_inv || nl.cell(c2).frozen() {
                            continue;
                        }
                        let Some((_, o2)) = io(nl, c2) else { continue };
                        if has_port(nl, i) && has_port(nl, o2) {
                            skipped += 1;
                            continue;
                        }
                        nl.remove_cell(c);
                        nl.remove_cell(c2);
                        if has_port(nl, o2) && !has_port(nl, i) {
                            nl.merge_net(o2, i);
                        } else {
                            nl.merge_net(i, o2);
                        }
                        nl.remove_net(o);
                        ni += 1;
                    }
                }
                nl.sweep_nets();
                crate::info!("ECO-250", "Removed {} buffer(s) and {} inverter pair(s){}", nb, ni, if skipped > 0 { format!("; {} skipped (dont_touch, port-to-port, or boundary)", skipped) } else { String::new() });
                if nb + ni > 0 {
                    self.eco_log(name, a);
                }
                Ok((nb + ni).to_string())
            }
            // ------------------------------------------------------------- sizing / cell change
            "eco_sizecell" | "eco_size_cell" => {
                let x = args(a, &["-cell", "-lib_cell", "-inst", "-cells"]);
                let insts: Vec<String> = x.get("-inst").or(x.get("-cells")).into_iter().chain(x.pos.iter()).flat_map(|p| self.cells_of(p)).collect();
                let up = x.has("-autoup") || x.has("-auto_up") || x.has("-upsize");
                let down = x.has("-autodown") || x.has("-auto_down") || x.has("-downsize");
                let to = x.get("-cell").or(x.get("-lib_cell")).cloned();
                if insts.is_empty() {
                    return Some(err(format!("{}: -inst <instances> is required", name)));
                }
                if [to.is_some(), up, down].iter().filter(|b| **b).count() != 1 {
                    return Some(err(format!("{}: give exactly one of -cell <lib_cell>, -autoup, -autodown", name)));
                }
                let target = match &to {
                    Some(t) => match self.find_lib_cell(t) {
                        Some(c) => Some(c),
                        None => return Some(err(format!("{}: library cell '{}' not found", name, t))),
                    },
                    None => None,
                };
                let libs = self.libs.clone();
                let errs0 = crate::log::count(crate::log::Sev::Error);
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let mut done = vec![];
                for i in &insts {
                    let Some(c) = nl.cell_by_name(i) else {
                        crate::warn!("ECO-262", "{}: instance '{}' not found", name, i);
                        continue;
                    };
                    if nl.cell(c).dont_touch {
                        crate::error!("ECO-263", "{}: '{}' is dont_touch", name, i);
                        continue;
                    }
                    let Some(cur) = nl.cell(c).lib().and_then(|l| libs.iter().find_map(|x| x.cells.get(l))).cloned() else {
                        crate::warn!("ECO-264", "{}: '{}' is not a library cell", name, i);
                        continue;
                    };
                    let lib = libs.iter().find(|l| l.cells.contains_key(&cur.name)).unwrap();
                    let fam: Vec<&LibCell> = lib.family_of(&cur.name).into_iter().filter(|f| f.vt == cur.vt && !f.dont_use).collect();
                    let new = if let Some(t) = &target {
                        if !fam.iter().any(|f| f.name == t.name) && t.name != cur.name {
                            crate::error!("ECO-265", "{}: '{}' is not a size variant of {} (same function and Vt); use eco_change_cell", name, t.name, cur.name);
                            continue;
                        }
                        Some(t.name.clone())
                    } else {
                        let mut v = fam.clone();
                        v.sort_by(|a, b| a.drive.partial_cmp(&b.drive).unwrap().then(a.area.partial_cmp(&b.area).unwrap()));
                        let k = v.iter().position(|f| f.name == cur.name).unwrap_or(0);
                        if up { v.get(k + 1).map(|f| f.name.clone()) } else if k > 0 { v.get(k - 1).map(|f| f.name.clone()) } else { None }
                    };
                    match new {
                        Some(n) if n != cur.name => {
                            crate::opt::swap_cell(nl, c, &n);
                            done.push(format!("{}: {} -> {}", i, cur.name, n));
                        }
                        _ => crate::warn!("ECO-266", "{}: '{}' ({}) is already the {} size", name, i, cur.name, if up { "largest" } else if down { "smallest" } else { "requested" }),
                    }
                }
                for d in &done {
                    crate::info!("ECO-260", "Sized {}", d);
                }
                if done.is_empty() && crate::log::count(crate::log::Sev::Error) > errs0 {
                    return Some(err(format!("{}: no instance was sized", name)));
                }
                if !done.is_empty() {
                    self.eco_log(name, a);
                }
                Ok(done.len().to_string())
            }
            "eco_change_cell" | "change_cell" => {
                let x = args(a, &["-cell", "-lib_cell", "-inst", "-cells"]);
                let insts: Vec<String> = x.get("-inst").or(x.get("-cells")).into_iter().chain(x.pos.iter()).flat_map(|p| self.cells_of(p)).collect();
                let Some(t) = x.get("-cell").or(x.get("-lib_cell")).cloned() else { return Some(err(format!("{}: -cell <lib_cell> is required", name))) };
                let Some(target) = self.find_lib_cell(&t) else { return Some(err(format!("{}: library cell '{}' not found", name, t))) };
                let force = x.has("-force");
                let errs0 = crate::log::count(crate::log::Sev::Error);
                let Ok(nl) = self.nlm() else { return Some(err("no design")) };
                let mut done = 0;
                for i in &insts {
                    let Some(c) = nl.cell_by_name(i) else {
                        crate::warn!("ECO-272", "{}: instance '{}' not found", name, i);
                        continue;
                    };
                    if nl.cell(c).frozen() && !force {
                        crate::error!("ECO-273", "{}: '{}' is dont_touch/size_only; use -force", name, i);
                        continue;
                    }
                    // pin mapping by name
                    let old: Vec<(String, Option<NetId>)> = nl.cell(c).pins.iter().map(|p| (p.name.clone(), p.net)).collect();
                    let lost: Vec<&String> = old.iter().filter(|(p, n)| n.is_some() && target.pin(p).is_none()).map(|(p, _)| p).collect();
                    if !lost.is_empty() && !force {
                        crate::error!("ECO-274", "{}: '{}' -> {}: connected pin(s) {} do not exist on the new cell (use -force to drop them)", name, i, target.name, lost.iter().map(|s| s.as_str()).collect::<Vec<_>>().join(", "));
                        continue;
                    }
                    let oldref = nl.cell(c).lib().unwrap_or("?").to_string();
                    for k in 0..nl.cell(c).pins.len() {
                        nl.disconnect(c, k);
                    }
                    let newpins: Vec<Pin> = target.pins.iter().map(|p| Pin { name: p.name.clone(), dir: p.dir.unwrap_or(Dir::In), net: None }).collect();
                    {
                        let cm = nl.cell_mut(c);
                        cm.kind = Kind::Lib(target.name.clone());
                        cm.pins = newpins;
                    }
                    let mut unconnected = vec![];
                    for (p, n) in &old {
                        if let Some(n) = n {
                            if !nl.connect_name(c, p, *n) {
                                unconnected.push(p.clone());
                            }
                        }
                    }
                    let fresh: Vec<String> = target.pins.iter().filter(|p| !old.iter().any(|(o, _)| *o == p.name)).map(|p| p.name.clone()).collect();
                    if !fresh.is_empty() {
                        crate::warn!("ECO-275", "{}: '{}' new pin(s) {} left unconnected", name, i, fresh.join(", "));
                    }
                    crate::info!("ECO-270", "Changed {}: {} -> {}{}", i, oldref, target.name, if unconnected.is_empty() { String::new() } else { format!(" (dropped: {})", unconnected.join(", ")) });
                    done += 1;
                }
                if done == 0 && crate::log::count(crate::log::Sev::Error) > errs0 {
                    return Some(err(format!("{}: no instance was changed", name)));
                }
                if done > 0 {
                    self.eco_log(name, a);
                }
                Ok(done.to_string())
            }
            "report_eco_changes" | "report_eco" => {
                crate::out!("\nECO changes in this session: {}", self.eco_changes.len());
                for (i, l) in self.eco_changes.iter().enumerate() {
                    crate::out!("  {:>4}  {}", i + 1, l);
                }
                Ok(self.eco_changes.len().to_string())
            }
            "write_eco_changes" | "write_eco_script" => {
                let Some(f) = a.iter().find(|x| !x.starts_with('-')).cloned() else { return Some(err(format!("{}: file name required", name))) };
                let body = format!("# RSynth ECO script ({} change(s)) - replay with: source {}\n{}\n", self.eco_changes.len(), f, self.eco_changes.join("\n"));
                if let Err(e) = std::fs::write(&f, body) {
                    return Some(err(format!("{}: {}", name, e)));
                }
                crate::info!("ECO-280", "Wrote {} ECO change(s) to '{}'", self.eco_changes.len(), f);
                Ok(f)
            }
            _ => return None,
        };
        Some(r)
    }
}
