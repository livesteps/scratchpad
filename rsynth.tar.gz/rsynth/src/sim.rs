//! Cycle-based 2-state logic simulator and sequential equivalence checker
//! (random-vector co-simulation of a golden netlist vs. a revised netlist).
//! Handles generic gates, library cells (Liberty functions), flops with async
//! clear/preset, latches, integrated clock gates (enable sampling), black boxes
//! (identical pseudo-random outputs in both netlists), and scan/test inputs.

use crate::liberty::{parse_func, BExpr, Library};
use crate::netlist::*;
use std::collections::HashMap;

enum Ev {
    Gen(GOp, Vec<NetId>, NetId),
    Func(BExpr, Vec<(String, NetId)>, NetId),
    Latch(NetId, NetId, Option<NetId>, NetId), // D G RN Q
}
struct Seq {
    d: NetId,
    q: Option<NetId>,
    qn: Option<NetId>,
    clr: Option<(NetId, bool)>, // net, active_low
    pre: Option<(NetId, bool)>,
    en: Option<NetId>, // clock enable derived from ICGs on the clock path
    inv_d: bool,
}

pub struct Model {
    vals: Vec<bool>,
    evs: Vec<Ev>,
    seqs: Vec<Seq>,
    pub inputs: HashMap<String, NetId>,
    pub outputs: HashMap<String, NetId>,
    bb: Vec<(String, NetId)>,
    icg_en: HashMap<NetId, (NetId, Option<NetId>)>, // gated clock net -> (E, SE)
    order_ok: bool,
}

fn rnd(seed: u64) -> bool {
    let mut x = seed.wrapping_mul(0x9E3779B97F4A7C15).wrapping_add(0x632BE59BD9B4E019);
    x ^= x >> 31;
    x = x.wrapping_mul(0xBF58476D1CE4E5B9);
    x ^= x >> 29;
    x & 1 == 1
}
fn h(s: &str) -> u64 {
    s.bytes().fold(1469598103934665603u64, |a, b| (a ^ b as u64).wrapping_mul(1099511628211))
}

impl Model {
    pub fn build(nl: &Netlist, libs: &[Library]) -> Result<Model, String> {
        let lc = |n: &str| libs.iter().find_map(|l| l.cells.get(n));
        let mut m = Model { vals: vec![false; nl.nets.len()], evs: vec![], seqs: vec![], inputs: HashMap::new(), outputs: HashMap::new(), bb: vec![], icg_en: HashMap::new(), order_ok: true };
        for p in nl.port_ids() {
            if let Some(n) = nl.ports[p].net {
                match nl.ports[p].dir {
                    Dir::In => {
                        m.inputs.insert(nl.ports[p].name.clone(), n);
                    }
                    _ => {
                        m.outputs.insert(nl.ports[p].name.clone(), n);
                    }
                }
            }
        }
        let mut seq_cells = vec![];
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            match &cell.kind {
                Kind::Gen(op) => match op {
                    GOp::Dff => seq_cells.push(c),
                    GOp::Latch => {
                        if let (Some(d), Some(g), Some(q)) = (cell.pin_net("D"), cell.pin_net("G"), cell.pin_net("Q")) {
                            m.evs.push(Ev::Latch(d, g, cell.pin_net("RN"), q));
                        }
                    }
                    _ => {
                        let ins: Vec<NetId> = cell.pins.iter().filter(|p| p.dir == Dir::In).filter_map(|p| p.net).collect();
                        if let Some(y) = cell.pin_net("Y") {
                            m.evs.push(Ev::Gen(*op, ins, y));
                        }
                    }
                },
                Kind::Lib(l) => {
                    let Some(lc) = lc(l) else { return Err(format!("unknown library cell {}", l)) };
                    if lc.icg.is_some() {
                        let role = |r: &str| lc.pins.iter().find(|p| p.cg_role.as_deref() == Some(r)).and_then(|p| cell.pin_net(&p.name));
                        if let (Some(ck), Some(e), Some(g)) = (role("clock"), role("enable"), role("out")) {
                            m.icg_en.insert(g, (e, role("test")));
                            // gated clock net follows the clock value combinationally (for clock-as-data)
                            m.evs.push(Ev::Gen(GOp::Buf, vec![ck], g));
                        }
                        continue;
                    }
                    if let Some(s) = &lc.seq {
                        if s.is_latch {
                            let dp = s.next_state.trim().to_string();
                            let gp = s.clocked_on.trim().to_string();
                            let q = lc.outputs().iter().find(|o| !o.function.clone().unwrap_or_default().contains('N')).and_then(|o| cell.pin_net(&o.name));
                            if let (Some(d), Some(g), Some(q)) = (cell.pin_net(&dp), cell.pin_net(&gp), q) {
                                m.evs.push(Ev::Latch(d, g, None, q));
                            }
                        } else {
                            seq_cells.push(c);
                        }
                        continue;
                    }
                    for o in lc.outputs() {
                        let Some(y) = cell.pin_net(&o.name) else { continue };
                        let Some(f) = o.function.as_ref().and_then(|f| parse_func(f)) else { continue };
                        let ins: Vec<(String, NetId)> = cell.pins.iter().filter(|p| p.dir == Dir::In).filter_map(|p| p.net.map(|n| (p.name.clone(), n))).collect();
                        m.evs.push(Ev::Func(f, ins, y));
                    }
                }
                Kind::BlackBox(_) => {
                    for p in &cell.pins {
                        if p.dir == Dir::Out {
                            if let Some(n) = p.net {
                                m.bb.push((format!("{}/{}", cell.name, p.name), n));
                            }
                        }
                    }
                }
            }
        }
        // sequential elements
        for c in seq_cells {
            let cell = nl.cell(c);
            let (d, ck, q, qn, clr, pre, inv_d) = match &cell.kind {
                Kind::Gen(_) => (cell.pin_net("D"), cell.pin_net("CK"), cell.pin_net("Q"), None, cell.pin_net("RN").map(|n| (n, true)), cell.pin_net("SN").map(|n| (n, true)), false),
                Kind::Lib(l) => {
                    let lc = lc(l).unwrap();
                    let s = lc.seq.as_ref().unwrap();
                    // scan flops: next_state "(D&!SE)|(SI&SE)" -> evaluate as function into a virtual D net
                    let pin = |e: &str| -> (String, bool) {
                        let t = e.trim().trim_matches('"');
                        if let Some(x) = t.strip_prefix('!') { (x.to_string(), true) } else { (t.trim_end_matches('\'').to_string(), t.ends_with('\'')) }
                    };
                    let (ckp, _) = pin(&s.clocked_on);
                    let mut q = None;
                    let mut qn = None;
                    for o in lc.outputs() {
                        let f = o.function.clone().unwrap_or_default();
                        if f.contains('!') || f.trim().ends_with('N') {
                            qn = cell.pin_net(&o.name)
                        } else {
                            q = cell.pin_net(&o.name)
                        }
                    }
                    let d = if lc.pin(s.next_state.trim()).is_some() {
                        cell.pin_net(s.next_state.trim())
                    } else {
                        // functional next state
                        let f = parse_func(&s.next_state).ok_or("bad next_state")?;
                        let ins: Vec<(String, NetId)> = cell.pins.iter().filter(|p| p.dir == Dir::In).filter_map(|p| p.net.map(|n| (p.name.clone(), n))).collect();
                        let vn = m.vals.len();
                        m.vals.push(false);
                        m.evs.push(Ev::Func(f, ins, vn));
                        Some(vn)
                    };
                    let clr = s.clear.as_ref().map(|x| pin(x)).and_then(|(p, al)| cell.pin_net(&p).map(|n| (n, al)));
                    let pre = s.preset.as_ref().map(|x| pin(x)).and_then(|(p, al)| cell.pin_net(&p).map(|n| (n, al)));
                    (d, cell.pin_net(&ckp), q, qn, clr, pre, false)
                }
                _ => continue,
            };
            let Some(d) = d else { continue };
            // trace clock path to an ICG output
            let mut en = None;
            if let Some(mut n) = ck {
                for _ in 0..32 {
                    if m.icg_en.contains_key(&n) {
                        en = Some(n);
                        break;
                    }
                    match nl.driver(n) {
                        Some(PinRef::Cell(dc, _)) => {
                            let dcell = nl.cell(dc);
                            let pass = match &dcell.kind {
                                Kind::Gen(GOp::Buf) | Kind::Gen(GOp::Not) => dcell.pin_net("A"),
                                Kind::Lib(l) => lc(l).filter(|x| x.is_buf || x.is_inv || x.is_ls).and_then(|x| dcell.pin_net(&x.inputs()[0].name)),
                                _ => None,
                            };
                            match pass {
                                Some(p) => n = p,
                                None => break,
                            }
                        }
                        _ => break,
                    }
                }
            }
            m.seqs.push(Seq { d, q, qn, clr, pre, en, inv_d });
        }
        Ok(m)
    }

    fn eval_comb(&mut self, cyc: u64, nl_hash: &HashMap<NetId, u64>) {
        for (name, n) in &self.bb {
            let _ = nl_hash;
            self.vals[*n] = rnd(h(name) ^ cyc.wrapping_mul(7919));
        }
        let mut changed = true;
        let mut it = 0;
        while changed && it < 200 {
            changed = false;
            it += 1;
            for e in &self.evs {
                let (out, v) = match e {
                    Ev::Gen(op, ins, y) => {
                        let a = |k: usize| ins.get(k).map(|n| self.vals[*n]).unwrap_or(false);
                        let v = match op {
                            GOp::Buf => a(0),
                            GOp::Not => !a(0),
                            GOp::And => a(0) & a(1),
                            GOp::Or => a(0) | a(1),
                            GOp::Xor => a(0) ^ a(1),
                            GOp::Nand => !(a(0) & a(1)),
                            GOp::Nor => !(a(0) | a(1)),
                            GOp::Xnor => !(a(0) ^ a(1)),
                            GOp::Mux => {
                                if a(0) { a(2) } else { a(1) }
                            }
                            GOp::C0 => false,
                            GOp::C1 => true,
                            _ => continue,
                        };
                        (*y, v)
                    }
                    Ev::Func(f, ins, y) => {
                        let v = f.eval(&|p: &str| ins.iter().find(|(n, _)| n == p).map(|(_, net)| self.vals[*net]).unwrap_or(false));
                        (*y, v)
                    }
                    Ev::Latch(d, g, rn, q) => {
                        if rn.map(|r| !self.vals[r]).unwrap_or(false) {
                            (*q, false)
                        } else if self.vals[*g] {
                            (*q, self.vals[*d])
                        } else {
                            continue;
                        }
                    }
                };
                if self.vals[out] != v {
                    self.vals[out] = v;
                    changed = true;
                }
            }
        }
        if changed {
            self.order_ok = false;
        }
    }
    fn clock(&mut self) {
        let mut nxt = vec![];
        for s in &self.seqs {
            let enabled = match s.en {
                Some(g) => {
                    let (e, se) = self.icg_en[&g];
                    self.vals[e] || se.map(|x| self.vals[x]).unwrap_or(false)
                }
                None => true,
            };
            let cur = s.q.map(|q| self.vals[q]).or(s.qn.map(|q| !self.vals[q])).unwrap_or(false);
            let v = if enabled { self.vals[s.d] ^ s.inv_d } else { cur };
            nxt.push(v);
        }
        for (s, v) in self.seqs.iter().zip(nxt) {
            if let Some(q) = s.q {
                self.vals[q] = v;
            }
            if let Some(q) = s.qn {
                self.vals[q] = !v;
            }
        }
    }
    fn async_apply(&mut self) -> bool {
        let mut any = false;
        for s in &self.seqs {
            let clr = s.clr.map(|(n, al)| self.vals[n] != al).unwrap_or(false);
            let pre = s.pre.map(|(n, al)| self.vals[n] != al).unwrap_or(false);
            if clr || pre {
                let v = !clr;
                if let Some(q) = s.q {
                    any |= self.vals[q] != v;
                    self.vals[q] = v;
                }
                if let Some(q) = s.qn {
                    self.vals[q] = !v;
                }
            }
        }
        any
    }
    fn step(&mut self, cyc: u64, ins: &HashMap<String, bool>, empty: &HashMap<NetId, u64>) {
        for (n, net) in &self.inputs {
            if let Some(v) = ins.get(n) {
                self.vals[*net] = *v;
            }
        }
        self.eval_comb(cyc, empty);
        for _ in 0..3 {
            if !self.async_apply() {
                break;
            }
            self.eval_comb(cyc, empty);
        }
    }
}

impl Model {
    /// nets in the forward cone of the given seed nets
    pub fn cone(&self, seeds: &[NetId]) -> std::collections::HashSet<NetId> {
        let mut fwd: HashMap<NetId, Vec<NetId>> = HashMap::new();
        for e in &self.evs {
            let (ins, out): (Vec<NetId>, NetId) = match e {
                Ev::Gen(_, i, y) => (i.clone(), *y),
                Ev::Func(_, i, y) => (i.iter().map(|x| x.1).collect(), *y),
                Ev::Latch(d, g, r, q) => (vec![*d, *g].into_iter().chain(r.iter().copied()).collect(), *q),
            };
            for i in ins {
                fwd.entry(i).or_default().push(out);
            }
        }
        for s in &self.seqs {
            for q in s.q.iter().chain(s.qn.iter()) {
                fwd.entry(s.d).or_default().push(*q);
            }
        }
        let mut seen: std::collections::HashSet<NetId> = seeds.iter().copied().collect();
        let mut st: Vec<NetId> = seeds.to_vec();
        while let Some(n) = st.pop() {
            for m in fwd.get(&n).cloned().unwrap_or_default() {
                if seen.insert(m) {
                    st.push(m);
                }
            }
        }
        seen
    }
}

pub struct EqResult {
    pub unverifiable: Vec<String>,
    pub cycles: usize,
    pub compared_outputs: usize,
    pub mismatches: Vec<(usize, String, bool, bool)>,
}

/// `consts`: inputs forced to a value (e.g. scan_en=0, iso_en=0); `resets`: active-low inputs held 0 for first cycles
pub fn equivalence(gold: &Netlist, rev: &Netlist, libs: &[Library], cycles: usize, consts: &HashMap<String, bool>, resets: &[String], seed: u64) -> Result<EqResult, String> {
    let mut g = Model::build(gold, libs)?;
    let mut r = Model::build(rev, libs)?;
    let mut outs: Vec<String> = g.outputs.keys().filter(|k| r.outputs.contains_key(*k)).cloned().collect();
    outs.sort();
    // outputs depending on multi-driven reference nets are unverifiable
    let md: Vec<NetId> = gold.net_ids().into_iter().filter(|n| gold.drivers(*n).len() > 1).collect();
    let mut unverifiable = vec![];
    if !md.is_empty() {
        let cone = g.cone(&md);
        outs.retain(|o| {
            let bad = cone.contains(&g.outputs[o]);
            if bad {
                unverifiable.push(o.clone());
            }
            !bad
        });
    }
    let mut ins: Vec<String> = g.inputs.keys().chain(r.inputs.keys()).cloned().collect();
    ins.sort();
    ins.dedup();
    let empty = HashMap::new();
    let mut mism = vec![];
    for cyc in 0..cycles as u64 {
        let mut iv: HashMap<String, bool> = HashMap::new();
        for (k, n) in ins.iter().enumerate() {
            let v = if let Some(c) = consts.get(n) {
                *c
            } else if resets.contains(n) {
                cyc >= 2
            } else {
                rnd(seed ^ (cyc << 20) ^ k as u64 ^ h(n))
            };
            iv.insert(n.clone(), v);
        }
        g.step(cyc, &iv, &empty);
        r.step(cyc, &iv, &empty);
        for o in &outs {
            let (a, b) = (g.vals[g.outputs[o]], r.vals[r.outputs[o]]);
            if a != b && mism.len() < 50 {
                mism.push((cyc as usize, o.clone(), a, b));
            }
        }
        g.clock();
        r.clock();
    }
    Ok(EqResult { unverifiable, cycles, compared_outputs: outs.len(), mismatches: mism })
}
