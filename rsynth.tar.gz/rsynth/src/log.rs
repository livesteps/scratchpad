//! Message/diagnostic subsystem.  Every message carries a stable ID
//! (e.g. `ELAB-366`, `TIM-104`) so scripts can grep logs, suppress or
//! limit messages, and the end-of-run diagnostics summary is meaningful.

use std::collections::BTreeMap;
use std::io::Write;
use std::sync::Mutex;

#[derive(Clone, Copy, PartialEq, Eq, Debug, PartialOrd, Ord)]
pub enum Sev {
    Info,
    Warn,
    Error,
}

#[derive(Default)]
struct LogState {
    counts: BTreeMap<String, (Sev, usize)>,
    limits: BTreeMap<String, usize>,
    suppressed: BTreeMap<String, bool>,
    redirect: Vec<String>,
    logfile: Option<std::fs::File>,
}

static LOG: Mutex<Option<LogState>> = Mutex::new(None);

fn with<R>(f: impl FnOnce(&mut LogState) -> R) -> R {
    let mut g = LOG.lock().unwrap_or_else(|e| e.into_inner());
    if g.is_none() {
        *g = Some(LogState::default());
    }
    f(g.as_mut().unwrap())
}

/// Plain report output (goes to redirect buffer if active, stdout otherwise, and to the log file).
pub fn out(s: &str) {
    with(|l| {
        if let Some(b) = l.redirect.last_mut() {
            b.push_str(s);
            b.push('\n');
        } else {
            println!("{}", s);
        }
        if let Some(f) = &mut l.logfile {
            let _ = writeln!(f, "{}", s);
        }
    })
}

pub fn msg(sev: Sev, id: &str, text: &str) {
    let emit = with(|l| {
        let e = l.counts.entry(id.to_string()).or_insert((sev, 0));
        e.1 += 1;
        let n = e.1;
        if *l.suppressed.get(id).unwrap_or(&false) {
            return None;
        }
        let lim = *l.limits.get(id).unwrap_or(&usize::MAX);
        if n > lim {
            if n == lim + 1 {
                return Some(format!("Information: Message {} limit ({}) reached; further messages suppressed. (MSG-1)", id, lim));
            }
            return None;
        }
        let tag = match sev {
            Sev::Info => "Information",
            Sev::Warn => "Warning",
            Sev::Error => "Error",
        };
        Some(format!("{}: {} ({})", tag, text, id))
    });
    if let Some(s) = emit {
        out(&s);
    }
}

pub fn set_limit(id: &str, n: usize) {
    with(|l| {
        l.limits.insert(id.to_string(), n);
    })
}
pub fn suppress(id: &str, on: bool) {
    with(|l| {
        l.suppressed.insert(id.to_string(), on);
    })
}
pub fn open_logfile(path: &str) -> std::io::Result<()> {
    let f = std::fs::File::create(path)?;
    with(|l| l.logfile = Some(f));
    Ok(())
}
pub fn push_redirect() {
    with(|l| l.redirect.push(String::new()))
}
pub fn pop_redirect() -> String {
    with(|l| l.redirect.pop().unwrap_or_default())
}
pub fn count(sev: Sev) -> usize {
    with(|l| l.counts.values().filter(|(s, _)| *s == sev).map(|(_, n)| *n).sum())
}

pub fn summary() {
    let rows: Vec<(String, Sev, usize)> = with(|l| l.counts.iter().map(|(k, (s, n))| (k.clone(), *s, *n)).collect());
    out("");
    out("Diagnostics summary:");
    out(&format!("  {:<14} {:<12} {:>8}", "ID", "Severity", "Count"));
    for (id, s, n) in &rows {
        if *s == Sev::Info {
            continue;
        }
        out(&format!("  {:<14} {:<12} {:>8}", id, format!("{:?}", s), n));
    }
    out(&format!(
        "  Total: {} error(s), {} warning(s), {} information message(s)",
        count(Sev::Error),
        count(Sev::Warn),
        count(Sev::Info)
    ));
}

#[macro_export]
macro_rules! info { ($id:expr, $($a:tt)*) => { $crate::log::msg($crate::log::Sev::Info, $id, &format!($($a)*)) } }
#[macro_export]
macro_rules! warn { ($id:expr, $($a:tt)*) => { $crate::log::msg($crate::log::Sev::Warn, $id, &format!($($a)*)) } }
#[macro_export]
macro_rules! error { ($id:expr, $($a:tt)*) => { $crate::log::msg($crate::log::Sev::Error, $id, &format!($($a)*)) } }
#[macro_export]
macro_rules! out { ($($a:tt)*) => { $crate::log::out(&format!($($a)*)) } }
