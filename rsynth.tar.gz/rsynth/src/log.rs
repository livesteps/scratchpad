//! Message/diagnostic subsystem.  Every message carries a stable ID
//! (e.g. `ELAB-366`, `TIM-104`) so scripts can grep logs, suppress or
//! limit messages, and the end-of-run diagnostics summary is meaningful.

use std::collections::BTreeMap;
use std::io::Write;
use std::sync::Mutex;

#[derive(Clone, Copy, PartialEq, Eq, Debug, PartialOrd, Ord)]
pub enum Sev {
    Info,
    Warn,
    Error,
}

#[derive(Default)]
struct LogState {
    counts: BTreeMap<String, (Sev, usize)>,
    limits: BTreeMap<String, usize>,
    suppressed: BTreeMap<String, bool>,
    redirect: Vec<String>,
    logfile: Option<std::fs::File>,
    log_path: Option<String>,
    cmdfile: Option<std::fs::File>,
    cmd_path: Option<String>,
}

static LOG: Mutex<Option<LogState>> = Mutex::new(None);

fn with<R>(f: impl FnOnce(&mut LogState) -> R) -> R {
    let mut g = LOG.lock().unwrap_or_else(|e| e.into_inner());
    if g.is_none() {
        *g = Some(LogState::default());
    }
    f(g.as_mut().unwrap())
}

/// Plain report output (goes to redirect buffer if active, stdout otherwise, and to the log file).
pub fn out(s: &str) {
    with(|l| {
        if let Some(b) = l.redirect.last_mut() {
            b.push_str(s);
            b.push('\n');
        } else {
            println!("{}", s);
        }
        if let Some(f) = &mut l.logfile {
            let _ = writeln!(f, "{}", s);
        }
    })
}

pub fn msg(sev: Sev, id: &str, text: &str) {
    let emit = with(|l| {
        let e = l.counts.entry(id.to_string()).or_insert((sev, 0));
        e.1 += 1;
        let n = e.1;
        if *l.suppressed.get(id).unwrap_or(&false) {
            return None;
        }
        let lim = *l.limits.get(id).unwrap_or(&usize::MAX);
        if n > lim {
            if n == lim + 1 {
                return Some(format!("Information: Message {} limit ({}) reached; further messages suppressed. (MSG-1)", id, lim));
            }
            return None;
        }
        let tag = match sev {
            Sev::Info => "Information",
            Sev::Warn => "Warning",
            Sev::Error => "Error",
        };
        Some(format!("{}: {} ({})", tag, text, id))
    });
    if let Some(s) = emit {
        out(&s);
    }
}

pub fn set_limit(id: &str, n: usize) {
    with(|l| {
        l.limits.insert(id.to_string(), n);
    })
}
pub fn suppress(id: &str, on: bool) {
    with(|l| {
        l.suppressed.insert(id.to_string(), on);
    })
}
pub fn open_logfile(path: &str) -> std::io::Result<()> {
    let f = std::fs::File::create(path)?;
    with(|l| { l.logfile = Some(f); l.log_path = Some(path.to_string()); });
    Ok(())
}

/// default run and command logs: `rsynth.run.log` / `rsynth.cmd.log` in the current directory;
/// when those exist (an earlier run) the next free pair `rsynth.run.logN` / `rsynth.cmd.logN` is
/// taken, so no log is ever overwritten (as Innovus does with innovus.log / innovus.logN)
pub fn open_default_logs(log_base: &str, cmd_base: &str) -> (Option<String>, Option<String>) {
    for n in 0..10000 {
        let sfx = if n == 0 { String::new() } else { n.to_string() };
        let (lp, cp) = (format!("{}{}", log_base, sfx), format!("{}{}", cmd_base, sfx));
        if std::path::Path::new(&lp).exists() || std::path::Path::new(&cp).exists() { continue; }
        let lf = std::fs::OpenOptions::new().write(true).create_new(true).open(&lp);
        let Ok(lf) = lf else { continue };
        let cf = std::fs::OpenOptions::new().write(true).create_new(true).open(&cp).ok();
        let got_c = cf.is_some();
        with(|l| { l.logfile = Some(lf); l.log_path = Some(lp.clone()); l.cmdfile = cf; l.cmd_path = if got_c { Some(cp.clone()) } else { None }; });
        return (Some(lp), if got_c { Some(cp) } else { None });
    }
    (None, None)
}

fn move_file(old: &str, new: &str) -> std::io::Result<()> {
    if let Some(d) = std::path::Path::new(new).parent() { if !d.as_os_str().is_empty() { std::fs::create_dir_all(d)?; } }
    if std::fs::rename(old, new).is_ok() { return Ok(()); }
    // other file system: copy, then remove
    std::fs::copy(old, new)?;
    std::fs::remove_file(old)
}

/// set_log_filename: the run log moves to `path` (everything logged so far is kept) and goes on there
pub fn set_log_path(path: &str) -> Result<Option<String>, String> {
    let cur = with(|l| l.log_path.clone());
    if cur.as_deref() == Some(path) { return Ok(cur); }
    with(|l| { if let Some(f) = &mut l.logfile { let _ = f.flush(); } l.logfile = None; });
    if let Some(c) = &cur { if std::path::Path::new(c).exists() { move_file(c, path).map_err(|e| format!("cannot move the log '{}' to '{}': {}", c, path, e))?; } }
    let f = std::fs::OpenOptions::new().create(true).append(true).open(path).map_err(|e| format!("cannot open log '{}': {}", path, e))?;
    with(|l| { l.logfile = Some(f); l.log_path = Some(path.to_string()); });
    Ok(cur)
}
/// set_cmd_filename: the command log moves to `path` and goes on there
pub fn set_cmd_path(path: &str) -> Result<Option<String>, String> {
    let cur = with(|l| l.cmd_path.clone());
    if cur.as_deref() == Some(path) { return Ok(cur); }
    with(|l| { if let Some(f) = &mut l.cmdfile { let _ = f.flush(); } l.cmdfile = None; });
    if let Some(c) = &cur { if std::path::Path::new(c).exists() { move_file(c, path).map_err(|e| format!("cannot move the command log '{}' to '{}': {}", c, path, e))?; } }
    let f = std::fs::OpenOptions::new().create(true).append(true).open(path).map_err(|e| format!("cannot open command log '{}': {}", path, e))?;
    with(|l| { l.cmdfile = Some(f); l.cmd_path = Some(path.to_string()); });
    Ok(cur)
}
pub fn log_path() -> Option<String> { with(|l| l.log_path.clone()) }
pub fn cmd_path() -> Option<String> { with(|l| l.cmd_path.clone()) }

/// a command typed or run from a script: `rsynth.cmd.log` gets it as is, the run log gets `<CMD> ...`
pub fn command(line: &str) {
    with(|l| {
        if let Some(f) = &mut l.cmdfile { let _ = writeln!(f, "{}", line); let _ = f.flush(); }
        if let Some(f) = &mut l.logfile { let _ = writeln!(f, "<CMD> {}", line); }
    })
}
/// run-metrics lines: terminal and log, but never into a redirect buffer
pub fn metric(s: &str) {
    with(|l| {
        if l.redirect.is_empty() { println!("{}", s); }
        if let Some(f) = &mut l.logfile { let _ = writeln!(f, "{}", s); }
    })
}
/// text for the run log only (not the terminal)
pub fn log_only(s: &str) {
    with(|l| { if let Some(f) = &mut l.logfile { let _ = writeln!(f, "{}", s); } })
}
pub fn flush() {
    with(|l| { if let Some(f) = &mut l.logfile { let _ = f.flush(); } if let Some(f) = &mut l.cmdfile { let _ = f.flush(); } })
}
pub fn push_redirect() {
    with(|l| l.redirect.push(String::new()))
}
pub fn pop_redirect() -> String {
    with(|l| l.redirect.pop().unwrap_or_default())
}
pub fn count(sev: Sev) -> usize {
    with(|l| l.counts.values().filter(|(s, _)| *s == sev).map(|(_, n)| *n).sum())
}

pub fn summary() {
    let rows: Vec<(String, Sev, usize)> = with(|l| l.counts.iter().map(|(k, (s, n))| (k.clone(), *s, *n)).collect());
    out("");
    out("Diagnostics summary:");
    out(&format!("  {:<14} {:<12} {:>8}", "ID", "Severity", "Count"));
    for (id, s, n) in &rows {
        if *s == Sev::Info {
            continue;
        }
        out(&format!("  {:<14} {:<12} {:>8}", id, format!("{:?}", s), n));
    }
    out(&format!(
        "  Total: {} error(s), {} warning(s), {} information message(s)",
        count(Sev::Error),
        count(Sev::Warn),
        count(Sev::Info)
    ));
}

#[macro_export]
macro_rules! info { ($id:expr, $($a:tt)*) => { $crate::log::msg($crate::log::Sev::Info, $id, &format!($($a)*)) } }
#[macro_export]
macro_rules! warn { ($id:expr, $($a:tt)*) => { $crate::log::msg($crate::log::Sev::Warn, $id, &format!($($a)*)) } }
#[macro_export]
macro_rules! error { ($id:expr, $($a:tt)*) => { $crate::log::msg($crate::log::Sev::Error, $id, &format!($($a)*)) } }
#[macro_export]
macro_rules! out { ($($a:tt)*) => { $crate::log::out(&format!($($a)*)) } }
