//! Hierarchical implementation flow on top of the partitioning commands:
//!   * implement_partitions : every partition written by write_partitions is implemented on its
//!     own (block netlist + budgeted SDC + block DEF or an initialized floorplan): place_opt,
//!     clock_opt, route_auto, route_opt; it writes the routed netlist / DEF / SPEF per corner,
//!     an ETM per scenario (cell named after the block module), a LEF abstract and an ILM.
//!     Blocks run as separate RSynth processes (in parallel with -jobs).
//!   * verify_block_abstracts : top-level timing with the blocks replaced by their ETMs is
//!     compared with flat timing of the assembled implemented netlist (block parasitics from the
//!     block SPEFs annotated under each instance): per top-level endpoint and per block input pin
//!     (worst path through the pin into the block), setup and hold, per scenario.
//!   * report_boundary_slacks : the per-key slacks used by that comparison (works on either view)
//!   * top-level nets are ideal (zero wire) in both views, so the comparison measures the block
//!     abstraction itself
use crate::netlist::{Dir, PinRef};
use crate::paths::PathQuery;
use crate::session::*;
use crate::sta::Timing;
use crate::tcl::{split_list, Flow};
use std::collections::{BTreeMap, HashMap, HashSet};
use std::fmt::Write;
type R = Result<String, Flow>;

fn err(m: impl Into<String>) -> R {
    Err(Flow::Err(m.into()))
}
fn abs(p: &str) -> String {
    std::fs::canonicalize(p).map(|x| x.to_string_lossy().to_string()).unwrap_or_else(|_| {
        let cwd = std::env::current_dir().unwrap_or_default();
        cwd.join(p).to_string_lossy().to_string()
    })
}
fn tq(s: &str) -> String {
    format!("{{{}}}", s)
}

#[derive(Clone, Debug, Default)]
pub struct BlockImpl {
    pub name: String,
    pub inst: String,
    /// every instance using this block (several for a MIM partition)
    pub instances: Vec<String>,
    pub netlist: String,
    pub def: String,
    /// corner -> SPEF
    pub spef: BTreeMap<String, String>,
    /// scenario -> ETM .lib
    pub etm: BTreeMap<String, String>,
    pub lef: String,
    pub ilm: String,
    pub log: String,
    pub qor: String,
    pub ok: bool,
}

#[derive(Clone, Debug, Default)]
pub struct HierImpl {
    pub parts_dir: String,
    pub out_dir: String,
    pub top: String,
    pub blocks: Vec<BlockImpl>,
}

impl Session {
    pub(crate) fn hflow_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "implement_partitions" | "implement_blocks" => self.c_implement_partitions(a),
            "verify_block_abstracts" | "check_block_abstracts" => self.c_verify_abstracts(a),
            "report_boundary_slacks" => self.c_boundary_slacks(a),
            "report_hierarchical_implementation" => self.c_report_himpl(),
            "assemble_hier_gds" | "export_hier_gds" => self.c_assemble_gds(a),
            _ => return None,
        })
    }

    /// library / corner / mode / scenario setup lines replaying this session's MMMC set-up
    fn mmmc_script(&self) -> String {
        let mut s = String::new();
        let mut in_corner: HashSet<usize> = HashSet::new();
        for m in &self.modes {
            let _ = writeln!(s, "create_mode {}", m.name);
        }
        for c in &self.corners {
            let _ = writeln!(s, "create_corner {}", c.name);
            for &i in &c.libs {
                if let Some(l) = self.libs.get(i) {
                    let _ = writeln!(s, "read_lib -corner {} {}", c.name, tq(&abs(&l.file)));
                    in_corner.insert(i);
                }
            }
        }
        for (i, l) in self.libs.iter().enumerate() {
            if !in_corner.contains(&i) && !l.file.is_empty() {
                let _ = writeln!(s, "read_lib {}", tq(&abs(&l.file)));
            }
        }
        for sc in &self.scens {
            let _ = writeln!(s, "create_scenario -name {} -mode {} -corner {}", sc.name, sc.mode, sc.corner);
            let _ = writeln!(s, "set_scenario_status {} -active {} -setup {} -hold {}", sc.name, sc.active, sc.setup, sc.hold);
        }
        s
    }

    fn c_implement_partitions(&mut self, a: &[String]) -> R {
        let x = args(a, &["-partitions", "-input_dir", "-output_dir", "-flow", "-utilization", "-route_opt_iterations", "-jobs", "-extra_script", "-transitions", "-loads", "-gds_map_file"]);
        let gmap = x.get("-gds_map_file").map(|f| format!(" -gds_map_file {}", tq(&abs(f)))).unwrap_or_default();
        let parts_dir = x.get("-input_dir").cloned().unwrap_or("out/parts".into());
        let out_dir = x.get("-output_dir").cloned().unwrap_or("out/impl".into());
        if !std::path::Path::new(&parts_dir).is_dir() {
            return err(format!("implement_partitions: '{}' not found: run write_partitions first (HIER-001)", parts_dir));
        }
        std::fs::create_dir_all(&out_dir).map_err(|e| Flow::Err(format!("implement_partitions: {}: {}", out_dir, e)))?;
        let flow: Vec<String> = x.get("-flow").map(|s| split_list(s)).unwrap_or(vec!["place".into(), "cts".into(), "route".into(), "route_opt".into()]);
        for f in &flow {
            if !["place", "cts", "route", "route_opt"].contains(&f.as_str()) {
                return err(format!("implement_partitions: -flow step '{}' (place cts route route_opt) (HIER-002)", f));
            }
        }
        // partitions: the session's, else every block netlist in the directory
        let mut parts: Vec<(String, String)> = self.partitions.iter().map(|p| (p.name.clone(), p.inst.clone())).collect();
        let inst_list: HashMap<String, Vec<String>> = self.partitions.iter().map(|p| (p.name.clone(), p.insts())).collect();
        if parts.is_empty() {
            for e in std::fs::read_dir(&parts_dir).map_err(|e| Flow::Err(e.to_string()))? {
                let p = e.map_err(|e| Flow::Err(e.to_string()))?.path();
                let n = p.file_name().unwrap().to_string_lossy().to_string();
                if n.ends_with(".v") && !n.ends_with(".top.v") {
                    parts.push((n.trim_end_matches(".v").to_string(), String::new()));
                }
            }
            parts.sort();
        }
        if let Some(sel) = x.get("-partitions") {
            let sel = split_list(sel);
            for s in &sel {
                if !parts.iter().any(|p| &p.0 == s) {
                    return err(format!("implement_partitions: no partition '{}' (HIER-003)", s));
                }
            }
            parts.retain(|p| sel.contains(&p.0));
        }
        if parts.is_empty() {
            return err("implement_partitions: no partitions (HIER-004)");
        }
        let top = self.nl.as_ref().map(|n| n.name.clone()).unwrap_or_default();
        let util = x.num("-utilization").unwrap_or(0.5);
        let util = (util * 1000.0).round() / 1000.0;
        let roi = x.num("-route_opt_iterations").unwrap_or(1.0) as usize;
        let jobs = x.num("-jobs").map(|v| v as usize).unwrap_or(2).max(1);
        let mmmc = self.mmmc_script();
        let scen_names: Vec<String> = self.scens.iter().map(|s| s.name.clone()).collect();
        let corner_names: Vec<String> = self.corners.iter().map(|c| c.name.clone()).collect();
        let setup_scen = self.active("setup").first().and_then(|i| self.scens.get(*i)).map(|s| s.name.clone()).unwrap_or_default();
        let hold_scen = self.active("hold").first().and_then(|i| self.scens.get(*i)).map(|s| s.name.clone()).unwrap_or(setup_scen.clone());
        let extra = x.get("-extra_script").map(|f| abs(f));
        let sweeps = format!("{}{}", x.get("-transitions").map(|t| format!(" -transitions {}", tq(t))).unwrap_or_default(), x.get("-loads").map(|t| format!(" -loads {}", tq(t))).unwrap_or_default());
        let od = abs(&out_dir);
        let pd = abs(&parts_dir);
        let mut blocks: Vec<BlockImpl> = vec![];
        let mut scripts: Vec<(usize, String)> = vec![];
        for (name, inst) in &parts {
            let v = format!("{}/{}.v", pd, name);
            let sdc = format!("{}/{}.sdc", pd, name);
            let def = format!("{}/{}.def", pd, name);
            if !std::path::Path::new(&v).exists() || !std::path::Path::new(&sdc).exists() {
                return err(format!("implement_partitions: {}.v / {}.sdc missing in {} (HIER-005)", name, name, parts_dir));
            }
            let mut b = BlockImpl { name: name.clone(), inst: inst.clone(), instances: inst_list.get(name).cloned().unwrap_or_else(|| if inst.is_empty() { vec![] } else { vec![inst.clone()] }), netlist: format!("{}/{}.v", od, name), def: format!("{}/{}.def", od, name), lef: format!("{}/{}.lef", od, name), ilm: format!("{}/{}_ilm.v", od, name), log: format!("{}/{}.log", od, name), ..Default::default() };
            let mut s = String::new();
            let _ = writeln!(s, "# Block implementation of partition '{}' ({}) - generated by implement_partitions", name, if inst.is_empty() { "-" } else { inst });
            s.push_str(&mmmc);
            let _ = writeln!(s, "read_verilog {}\nlink_block {}\ncurrent_design {}", tq(&v), name, name);
            for m in &self.modes {
                let _ = writeln!(s, "current_mode {}\nread_sdc {}", m.name, tq(&sdc));
            }
            if std::path::Path::new(&def).exists() {
                let _ = writeln!(s, "read_def {}", tq(&def));
            } else {
                let _ = writeln!(s, "initialize_floorplan -core_utilization {}\nplace_pins", util);
            }
            if flow.iter().any(|f| f == "place") {
                let _ = writeln!(s, "place_opt\nlegalize_placement");
            }
            if flow.iter().any(|f| f == "cts") {
                let _ = writeln!(s, "if {{[sizeof_collection [all_clocks]] > 0}} {{ clock_opt -from build_clock -to route_clock }}");
            }
            if flow.iter().any(|f| f == "route") {
                let _ = writeln!(s, "route_auto");
            }
            if flow.iter().any(|f| f == "route_opt") {
                let _ = writeln!(s, "route_opt -iterations {}", roi);
            }
            if let Some(e) = &extra {
                let _ = writeln!(s, "source {}", tq(e));
            }
            let _ = writeln!(s, "check_legality");
            let _ = writeln!(
                s,
                "proc __s {{sc h}} {{ if {{$h}} {{ set p [get_timing_paths -scenarios $sc -delay_type min] }} else {{ set p [get_timing_paths -scenarios $sc] }} ; if {{[sizeof_collection $p] == 0}} {{ return inf }} ; return [get_attribute $p slack] }}"
            );
            let _ = writeln!(s, "puts \"BLOCK_QOR {} wns [__s {} 0] whs [__s {} 1] cells [sizeof_collection [get_cells -hier *]]\"", name, setup_scen, hold_scen);
            let _ = writeln!(s, "write_verilog {}\nwrite_def {}", tq(&b.netlist), tq(&b.def));
            let _ = writeln!(s, "write_spef -output {} -extraction_corners {}", tq(&format!("{}/{}.%c.spef", od, name)), tq(&corner_names.join(" ")));
            for c in &corner_names {
                b.spef.insert(c.clone(), format!("{}/{}.{}.spef", od, name, c));
            }
            for sc in &scen_names {
                let f = format!("{}/{}_{}.lib", od, name, sc);
                let _ = writeln!(s, "extract_model -scenario {} -output {} -cell_name {} -library_name {}_{}_etm{}", sc, tq(&f), name, name, sc, sweeps);
                b.etm.insert(sc.clone(), f);
            }
            let _ = writeln!(s, "write_lef_abstract {}\nwrite_ilm -output {}", tq(&b.lef), tq(&b.ilm));
            // block layout: one GDS structure named after the block (library cells referenced)
            let _ = writeln!(s, "export_gds -output {} -top_cell_name {}{}", tq(&format!("{}/{}.gds", od, name)), name, gmap);
            let _ = writeln!(s, "puts \"BLOCK_DONE {}\"", name);
            let sf = format!("{}/impl_{}.tcl", od, name);
            std::fs::write(&sf, s).map_err(|e| Flow::Err(e.to_string()))?;
            scripts.push((blocks.len(), sf));
            blocks.push(b);
        }
        if x.has("-script_only") {
            crate::info!("HIER-100", "Wrote {} block implementation script(s) to '{}' (not run)", scripts.len(), out_dir);
            self.himpl = Some(HierImpl { parts_dir: pd, out_dir: od, top, blocks });
            return Ok(scripts.iter().map(|s| s.1.clone()).collect::<Vec<_>>().join(" "));
        }
        let exe = std::env::current_exe().map_err(|e| Flow::Err(format!("implement_partitions: {}", e)))?;
        let t0 = std::time::Instant::now();
        crate::info!("HIER-101", "Implementing {} block(s) with {} parallel job(s): flow {}", blocks.len(), jobs, flow.join(" -> "));
        // run in parallel batches
        let results: std::sync::Mutex<HashMap<usize, (String, f64)>> = Default::default();
        let queue: std::sync::Mutex<Vec<(usize, String)>> = std::sync::Mutex::new(scripts.into_iter().rev().collect());
        std::thread::scope(|sc| {
            for _ in 0..jobs {
                sc.spawn(|| loop {
                    let Some((i, f)) = queue.lock().unwrap().pop() else { break };
                    let t = std::time::Instant::now();
                    let run1 = |f: &str| match std::process::Command::new(&exe).current_dir(&od).args(["-f", f]).output() {
                        Ok(o) => String::from_utf8_lossy(&o.stdout).to_string() + &String::from_utf8_lossy(&o.stderr),
                        Err(e) => format!("Error: could not run {}: {}", exe.display(), e),
                    };
                    let mut log = run1(&f);
                    // a block on an initialized floorplan that runs out of legal sites (the block
                    // grows during optimization) is retried on a larger die
                    let mut u = util;
                    for _ in 0..2 {
                        if !log.contains("PLC-310") {
                            break;
                        }
                        let Ok(txt) = std::fs::read_to_string(&f) else { break };
                        let key = format!("initialize_floorplan -core_utilization {}", u);
                        if !txt.contains(&key) {
                            break;
                        }
                        u = (u * 0.75 * 1000.0).round() / 1000.0;
                        let _ = std::fs::write(&f, txt.replace(&key, &format!("initialize_floorplan -core_utilization {}", u)));
                        log = format!("{}\nInformation: no legal sites left at the initial utilization; retrying at {} (HIER-103)\n{}", "", u, run1(&f));
                    }
                    results.lock().unwrap().insert(i, (log, t.elapsed().as_secs_f64()));
                });
            }
        });
        let results = results.into_inner().unwrap();
        crate::out!("\n  Block implementation ({} blocks, {:.1}s)", blocks.len(), t0.elapsed().as_secs_f64());
        crate::out!("  {:<16} {:>9} {:>9} {:>7} {:>7} {:>6}  status", "block", "WNS", "WHS", "cells", "errors", "time");
        let mut bad = 0;
        for (i, b) in blocks.iter_mut().enumerate() {
            let (log, secs) = results.get(&i).cloned().unwrap_or_default();
            let _ = std::fs::write(&b.log, &log);
            let errors = log.lines().find(|l| l.trim_start().starts_with("Total:") && l.contains("error(s)")).and_then(|l| l.split_whitespace().nth(1)).and_then(|v| v.parse::<usize>().ok()).unwrap_or(if log.contains("Error") { 1 } else { 0 });
            let q = log.lines().find(|l| l.starts_with("BLOCK_QOR")).unwrap_or("").to_string();
            let f = |k: &str| q.split(&format!(" {} ", k)).nth(1).and_then(|r| r.split_whitespace().next()).unwrap_or("-").to_string();
            b.ok = errors == 0 && log.contains(&format!("BLOCK_DONE {}", b.name));
            b.qor = q.clone();
            if !b.ok {
                bad += 1;
            }
            let retry = log.lines().filter(|l| l.contains("HIER-103")).last().and_then(|l| l.split("retrying at ").nth(1)).and_then(|r| r.split_whitespace().next()).map(|u| format!(" (die enlarged: utilization {})", u)).unwrap_or_default();
            crate::out!("  {:<16} {:>9} {:>9} {:>7} {:>7} {:>5.1}s  {}{}", b.name, f("wns"), f("whs"), f("cells"), errors, secs, if b.ok { "ok" } else { "FAILED (see log)" }, retry);
        }
        let manifest: String = blocks
            .iter()
            .map(|b| format!("block {} inst {} netlist {} def {} lef {} ilm {} {} {}\n", b.name, if b.inst.is_empty() { "-" } else { &b.inst }, b.netlist, b.def, b.lef, b.ilm, b.etm.iter().map(|(s, f)| format!("etm:{}={}", s, f)).collect::<Vec<_>>().join(" "), b.spef.iter().map(|(c, f)| format!("spef:{}={}", c, f)).collect::<Vec<_>>().join(" ")))
            .collect();
        let _ = std::fs::write(format!("{}/blocks.txt", od), manifest);
        self.himpl = Some(HierImpl { parts_dir: pd, out_dir: od.clone(), top, blocks });
        if bad > 0 {
            crate::warn!("HIER-110", "{} block(s) failed; see the logs in '{}'", bad, out_dir);
        }
        crate::info!("HIER-102", "Implemented {} block(s), {} failed: netlist, DEF, SPEF per corner, ETM per scenario, LEF abstract and ILM in '{}' (blocks.txt)", parts.len(), bad, out_dir);
        Ok(od)
    }

    /// top-level GDS of the hierarchical design: the top netlist on the block abstracts, placed
    /// by the top DEF (block instances fixed with their orientations), merged with every block's
    /// GDS (one structure per block, referenced by each of its instances) and the given library
    /// / IP layouts
    fn c_assemble_gds(&mut self, a: &[String]) -> R {
        let x = args(a, &["-output", "-merge", "-gds_map_file", "-top_cell_name"]);
        let h = self.himpl.clone().ok_or_else(|| Flow::Err("assemble_hier_gds: run implement_partitions first (HIER-006)".into()))?;
        let out = abs(&x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or(format!("{}/{}.gds", h.out_dir, h.top)));
        let top_v = format!("{}/{}.top.v", h.parts_dir, h.top);
        let top_def = format!("{}/{}.top.def", h.parts_dir, h.top);
        if !std::path::Path::new(&top_def).exists() {
            return err("assemble_hier_gds: no top-level DEF (write_partitions with a floorplan) (HIER-020)");
        }
        let mut merge: Vec<String> = h.blocks.iter().map(|b| format!("{}/{}.gds", h.out_dir, b.name)).collect();
        for m in x.get("-merge").map(|s| split_list(s)).unwrap_or_default() {
            merge.push(abs(&m));
        }
        for m in &merge {
            if !std::path::Path::new(m).exists() {
                return err(format!("assemble_hier_gds: '{}' not found (HIER-021)", m));
            }
        }
        let sc = self.active("setup").first().and_then(|i| self.scens.get(*i)).cloned().ok_or_else(|| Flow::Err("assemble_hier_gds: no setup scenario".into()))?;
        let mut s = String::new();
        let _ = writeln!(s, "# Hierarchical GDS assembly - generated by assemble_hier_gds");
        s.push_str(&self.mmmc_script());
        for b in &h.blocks {
            if let Some(f) = b.etm.get(&sc.name) {
                let _ = writeln!(s, "read_lib -corner {} {}", sc.corner, tq(f));
            }
        }
        let _ = writeln!(s, "read_verilog {}\nlink_block {}\ncurrent_design {}\nread_def {}", tq(&top_v), h.top, h.top, tq(&top_def));
        let _ = writeln!(
            s,
            "export_gds -output {} -merge {} -top_cell_name {} -prune_unused{}\nreport_gds -verbose -max_structures 400 {}",
            tq(&out),
            tq(&merge.iter().map(|m| tq(m)).collect::<Vec<_>>().join(" ")),
            x.get("-top_cell_name").cloned().unwrap_or(h.top.clone()),
            x.get("-gds_map_file").map(|f| format!(" -gds_map_file {}", tq(&abs(f)))).unwrap_or_default(),
            tq(&out)
        );
        let sf = format!("{}/assemble_gds.tcl", h.out_dir);
        std::fs::write(&sf, s).map_err(|e| Flow::Err(e.to_string()))?;
        let exe = std::env::current_exe().map_err(|e| Flow::Err(e.to_string()))?;
        let log = match std::process::Command::new(&exe).current_dir(&h.out_dir).args(["-f", &sf]).output() {
            Ok(o) => String::from_utf8_lossy(&o.stdout).to_string() + &String::from_utf8_lossy(&o.stderr),
            Err(e) => format!("Error: {}", e),
        };
        let _ = std::fs::write(format!("{}/assemble_gds.log", h.out_dir), &log);
        for l in log.lines().filter(|l| l.contains("GDS-1") || l.contains("GDS-2") || l.starts_with("  ") && (l.contains("structures") || l.contains("top cell") || l.contains("unresolved") || l.contains("references"))) {
            crate::out!("{}", l);
        }
        if !std::path::Path::new(&out).exists() || log.lines().any(|l| l.starts_with("Error")) {
            return err(format!("assemble_hier_gds: failed; see {}/assemble_gds.log (HIER-022)", h.out_dir));
        }
        crate::info!("HIER-300", "Assembled hierarchical GDS '{}' from the top DEF, {} block layout(s) and {} other layout file(s)", out, h.blocks.len(), merge.len() - h.blocks.len());
        Ok(out)
    }

    fn c_report_himpl(&mut self) -> R {
        let Some(h) = &self.himpl else { return err("report_hierarchical_implementation: run implement_partitions first (HIER-006)") };
        crate::out!("\n  Hierarchical implementation: top {}  partitions {}  blocks {}", h.top, h.parts_dir, h.out_dir);
        for b in &h.blocks {
            crate::out!("    {:<16} {:<28} {}  etm {}  spef {}{}", b.name, if b.inst.is_empty() { "-" } else { &b.inst }, if b.ok { "ok" } else { "FAILED" }, b.etm.len(), b.spef.len(), if b.instances.len() > 1 { format!("  (MIM: {} instances: {})", b.instances.len(), b.instances.join(" ")) } else { String::new() });
            crate::out!("      {}", b.qor);
        }
        Ok(h.blocks.len().to_string())
    }

    // ------------------------------------------------------------------ abstract vs flat

    /// slack per key for the comparison. Keys: T:<endpoint> for endpoints outside the blocks,
    /// B:<inst>/<pin> for block input pins (abstract view: the ETM constraint pin; flat view: the
    /// worst path through the boundary pin that ends inside the block)
    pub(crate) fn boundary_slacks(&self, blocks: &[String], si: usize) -> Result<Vec<(String, f64, f64)>, Flow> {
        let nl = self.nl()?;
        let (cons, corner) = self.scen_corner_mode_pub(si);
        let ls = self.libset(&corner);
        let mut t = Timing::new(nl, &ls, cons, &corner, self.sta_opts());
        t.run();
        let in_block = |name: &str| blocks.iter().find(|b| name.starts_with(&format!("{}/", b)) || name == b.as_str()).cloned();
        let mut out = vec![];
        let abstract_cells: HashSet<usize> = nl.cell_ids().into_iter().filter(|c| blocks.contains(&nl.cell(*c).name) && nl.cell(*c).lib().is_some()).collect();
        // endpoints
        let mut flat_inside: HashMap<String, HashSet<u32>> = HashMap::new();
        for ep in &t.endpoints {
            let pr = t.nodes[ep.node as usize];
            if let PinRef::Cell(c, p) = pr {
                if abstract_cells.contains(&c) {
                    if ep.setup_slack.is_finite() || ep.hold_slack.is_finite() {
                        out.push((format!("B:{}/{}", nl.cell(c).name, nl.cell(c).pins[p].name), ep.setup_slack, ep.hold_slack));
                    }
                    continue;
                }
            }
            match in_block(&ep.name) {
                Some(b) => {
                    flat_inside.entry(b).or_default().insert(ep.node);
                }
                None => out.push((format!("T:{}", ep.name), ep.setup_slack, ep.hold_slack)),
            }
        }
        // flat view: block input pins
        for b in blocks {
            let Some(eps) = flat_inside.get(b) else { continue };
            let mut ports: Vec<String> = nl.cell_ids().into_iter().filter_map(|c| nl.hier_pin_of(c)).filter(|(i, _)| i == b).map(|(_, p)| p).collect();
            ports.sort();
            ports.dedup();
            for p in ports {
                let Some(hp) = nl.find_hier_pin(b, &p) else { continue };
                let PinRef::Cell(hc, _) = hp else { continue };
                let input = nl.cell(hc).attrs.iter().any(|a| a.starts_with("hp:") && a.ends_with(":i"));
                if !input {
                    continue;
                }
                let Some(&node) = t.idx.get(&hp) else { continue };
                let mut sl = [f64::INFINITY; 2];
                for (k, hold) in [(0usize, false), (1usize, true)] {
                    let q = PathQuery { hold, through: vec![[node].into_iter().collect()], to: Some(eps.clone()), max_paths: 1, nworst: 1, max_pops: 50_000, ..Default::default() };
                    if let Some(r) = t.enumerate_paths(&q).first() {
                        sl[k] = r.slack;
                    }
                }
                if sl[0].is_finite() || sl[1].is_finite() {
                    out.push((format!("B:{}/{}", b, p), sl[0], sl[1]));
                }
            }
        }
        let _ = Dir::In;
        Ok(out)
    }

    fn c_boundary_slacks(&mut self, a: &[String]) -> R {
        let x = args(a, &["-blocks", "-scenarios", "-scenario"]);
        let blocks: Vec<String> = x.get("-blocks").map(|s| split_list(s)).unwrap_or_default();
        let scens: Vec<usize> = match x.get("-scenarios").or(x.get("-scenario")) {
            Some(s) => split_list(s).iter().filter_map(|n| self.scens.iter().position(|k| &k.name == n)).collect(),
            None => (0..self.scens.len()).filter(|i| self.scens[*i].active).collect(),
        };
        let mut n = 0;
        for si in scens {
            let sn = self.scens[si].name.clone();
            for (k, s, h) in self.boundary_slacks(&blocks, si)? {
                crate::out!("EP {} {} {} {}", sn, k, s, h);
                n += 1;
            }
        }
        Ok(n.to_string())
    }

    fn c_verify_abstracts(&mut self, a: &[String]) -> R {
        let x = args(a, &["-impl_dir", "-input_dir", "-scenarios", "-tolerance", "-hold_tolerance", "-output_dir", "-max_report"]);
        let h = self.himpl.clone().ok_or_else(|| Flow::Err("verify_block_abstracts: run implement_partitions first (HIER-006)".into()))?;
        let bad: Vec<&str> = h.blocks.iter().filter(|b| !b.ok).map(|b| b.name.as_str()).collect();
        if !bad.is_empty() {
            return err(format!("verify_block_abstracts: block(s) {} failed implementation (HIER-007)", bad.join(" ")));
        }
        let tol = x.num("-tolerance").unwrap_or(0.010);
        let htol = x.num("-hold_tolerance").unwrap_or(tol);
        let od = abs(&x.get("-output_dir").cloned().unwrap_or(h.out_dir.clone()));
        let top_v = format!("{}/{}.top.v", h.parts_dir, h.top);
        let top_sdc = format!("{}/{}.top.sdc", h.parts_dir, h.top);
        if !std::path::Path::new(&top_v).exists() {
            return err(format!("verify_block_abstracts: {} missing (HIER-008)", top_v));
        }
        let insts: Vec<String> = h.blocks.iter().flat_map(|b| b.instances.clone()).filter(|i| !i.is_empty()).collect();
        if h.blocks.iter().any(|b| b.instances.is_empty()) {
            return err("verify_block_abstracts: block instance names unknown (implement from a session with partitions) (HIER-009)");
        }
        let mmmc = self.mmmc_script();
        let scen_list = x.get("-scenarios").cloned().unwrap_or_else(|| self.scens.iter().filter(|s| s.active).map(|s| s.name.clone()).collect::<Vec<_>>().join(" "));
        let common_tail = |s: &mut String| {
            for m in &self.modes {
                let _ = writeln!(s, "current_mode {}\nread_sdc {}", m.name, tq(&top_sdc));
            }
            // top-level nets are ideal in both views, so the comparison isolates the block models
            let _ = writeln!(s, "set_app_options -name time.zero_wire_load -value true");
            // the blocks' clock trees are built: clocks are propagated (into the blocks in the flat
            // view; the ETM clock arcs already contain the block-internal latency)
            let _ = writeln!(s, "set_propagated_clock [all_clocks]");
            let _ = writeln!(s, "set_app_options -name time.remove_clock_reconvergence_pessimism -value true");
            let _ = writeln!(s, "report_boundary_slacks -blocks {} -scenarios {}", tq(&insts.join(" ")), tq(&scen_list));
            let _ = writeln!(s, "puts \"VIEW_DONE\"");
        };
        // abstract view: top netlist + ETMs
        let mut sa = String::new();
        let _ = writeln!(sa, "# Top-level timing on block ETMs - generated by verify_block_abstracts");
        sa.push_str(&mmmc);
        for sc in &self.scens {
            for b in &h.blocks {
                if let Some(f) = b.etm.get(&sc.name) {
                    let _ = writeln!(sa, "read_lib -corner {} {}", sc.corner, tq(f));
                }
            }
        }
        let _ = writeln!(sa, "read_verilog {}\nlink_block {}\ncurrent_design {}", tq(&top_v), h.top, h.top);
        common_tail(&mut sa);
        // flat view: top + implemented block netlists, block SPEFs under their instances
        let mut sf = String::new();
        let _ = writeln!(sf, "# Flat timing of the assembled implemented blocks - generated by verify_block_abstracts");
        sf.push_str(&mmmc);
        let files: Vec<String> = h.blocks.iter().map(|b| b.netlist.clone()).chain([top_v.clone()]).collect();
        let _ = writeln!(sf, "set_boundary_optimization -all false\nanalyze -format verilog {}\nelaborate {}", tq(&files.iter().map(|f| tq(f)).collect::<Vec<_>>().join(" ")), h.top);
        for b in &h.blocks {
            // one block SPEF annotated under every instance of the block
            for i in &b.instances {
                for (c, f) in &b.spef {
                    let _ = writeln!(sf, "read_parasitics -corner {} -path {} {}", c, tq(i), tq(f));
                }
            }
        }
        common_tail(&mut sf);
        let fa = format!("{}/top_abstract.tcl", od);
        let ff = format!("{}/top_flat.tcl", od);
        std::fs::write(&fa, sa).map_err(|e| Flow::Err(e.to_string()))?;
        std::fs::write(&ff, sf).map_err(|e| Flow::Err(e.to_string()))?;
        let exe = std::env::current_exe().map_err(|e| Flow::Err(e.to_string()))?;
        let t0 = std::time::Instant::now();
        let run = |f: &str| -> String {
            match std::process::Command::new(&exe).current_dir(&od).args(["-f", f]).output() {
                Ok(o) => String::from_utf8_lossy(&o.stdout).to_string() + &String::from_utf8_lossy(&o.stderr),
                Err(e) => format!("Error: {}", e),
            }
        };
        let (la, lf) = std::thread::scope(|s| {
            let ja = s.spawn(|| run(&fa));
            let jf = s.spawn(|| run(&ff));
            (ja.join().unwrap(), jf.join().unwrap())
        });
        let _ = std::fs::write(format!("{}/top_abstract.log", od), &la);
        let _ = std::fs::write(format!("{}/top_flat.log", od), &lf);
        for (nm, l) in [("abstract", &la), ("flat", &lf)] {
            if !l.contains("VIEW_DONE") {
                return err(format!("verify_block_abstracts: the {} view did not finish; see {}/top_{}.log (HIER-010)", nm, od, nm));
            }
            let errs = l.lines().find(|x| x.trim_start().starts_with("Total:") && x.contains("error(s)")).and_then(|x| x.split_whitespace().nth(1)).and_then(|v| v.parse::<usize>().ok()).unwrap_or(0);
            if errs > 0 {
                crate::warn!("HIER-111", "the {} view reported {} error(s); see {}/top_{}.log", nm, errs, od, nm);
            }
        }
        let parse = |l: &str| -> BTreeMap<(String, String), (f64, f64)> {
            let mut m = BTreeMap::new();
            for line in l.lines().filter(|x| x.starts_with("EP ")) {
                let t: Vec<&str> = line.split_whitespace().collect();
                if t.len() >= 5 {
                    let p = |v: &str| v.parse::<f64>().unwrap_or(f64::INFINITY);
                    m.insert((t[1].to_string(), t[2..t.len() - 2].join(" ")), (p(t[t.len() - 2]), p(t[t.len() - 1])));
                }
            }
            m
        };
        let ma = parse(&la);
        let mf = parse(&lf);
        // compare
        #[derive(Default)]
        struct St {
            n: usize,
            max: f64,
            sum: f64,
            over: usize,
            pess: usize,
            worst_a: f64,
            worst_f: f64,
        }
        let mut stats: BTreeMap<(String, String, &str), St> = BTreeMap::new();
        let mut worst: Vec<(f64, String)> = vec![];
        let (mut only_a, mut only_f) = (0, 0);
        for ((sc, k), (sa_, ha)) in &ma {
            let Some((sf_, hf)) = mf.get(&(sc.clone(), k.clone())) else {
                only_a += 1;
                continue;
            };
            let cat = if k.starts_with("B:") { "block inputs" } else { "top endpoints" };
            let (do_s, do_h) = self.scens.iter().find(|s| &s.name == sc).map(|s| (s.setup, s.hold)).unwrap_or((true, true));
            for (kind, va, vf, tl) in [("setup", *sa_, *sf_, tol), ("hold", *ha, *hf, htol)] {
                if (kind == "setup" && !do_s) || (kind == "hold" && !do_h) {
                    continue;
                }
                if !va.is_finite() || !vf.is_finite() {
                    continue;
                }
                let d = va - vf;
                let e = stats.entry((sc.clone(), kind.to_string(), cat)).or_insert(St { worst_a: f64::INFINITY, worst_f: f64::INFINITY, ..Default::default() });
                e.n += 1;
                e.sum += d;
                e.max = e.max.max(d.abs());
                e.worst_a = e.worst_a.min(va);
                e.worst_f = e.worst_f.min(vf);
                if d.abs() > tl {
                    e.over += 1;
                }
                if d < 0.0 {
                    e.pess += 1;
                }
                worst.push((d.abs(), format!("{} {} {}: abstract {:.4} flat {:.4} ({:+.4})", sc, kind, k, va, vf, d)));
            }
        }
        for k in mf.keys() {
            if !ma.contains_key(k) {
                only_f += 1;
            }
        }
        crate::out!("\n  Block abstract (ETM) vs flat timing  ({:.1}s; top-level nets {})", t0.elapsed().as_secs_f64(), "ideal in both views");
        crate::out!("  {:<10} {:<6} {:<14} {:>6} {:>10} {:>10} {:>10} {:>10} {:>7} {:>9}", "scenario", "check", "points", "count", "WNS abs", "WNS flat", "max |d|", "mean d", "> tol", "pessim.");
        let mut over = 0;
        for ((sc, kind, cat), s) in &stats {
            over += s.over;
            crate::out!("  {:<10} {:<6} {:<14} {:>6} {:>10.4} {:>10.4} {:>10.4} {:>+10.4} {:>7} {:>9}", sc, kind, cat, s.n, s.worst_a, s.worst_f, s.max, s.sum / s.n.max(1) as f64, s.over, s.pess);
        }
        worst.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
        let mr = x.num("-max_report").unwrap_or(8.0) as usize;
        if !worst.is_empty() {
            crate::out!("  largest differences:");
            for w in worst.iter().take(mr) {
                crate::out!("    {}", w.1);
            }
        }
        if only_a + only_f > 0 {
            crate::out!("  points in one view only: abstract {}, flat {}", only_a, only_f);
        }
        // MIM: every instance of a reused block is checked in its own context
        for b in h.blocks.iter().filter(|b| b.instances.len() > 1) {
            crate::out!("  MIM block {} — per-instance context (worst slack at the block inputs, abstract / flat):", b.name);
            crate::out!("    {:<28} {:>10} {:>10} {:>10} {:>10}", "instance", "setup abs", "setup flat", "hold abs", "hold flat");
            for i in &b.instances {
                let pfx = format!("B:{}/", i);
                let mut w = [f64::INFINITY; 4];
                for ((sc, k), (s_, h_)) in &ma {
                    if !k.starts_with(&pfx) {
                        continue;
                    }
                    let (ds, dh) = self.scens.iter().find(|x| &x.name == sc).map(|x| (x.setup, x.hold)).unwrap_or((true, true));
                    if let Some((fs, fh)) = mf.get(&(sc.clone(), k.clone())) {
                        if ds {
                            w[0] = w[0].min(*s_);
                            w[1] = w[1].min(*fs);
                        }
                        if dh {
                            w[2] = w[2].min(*h_);
                            w[3] = w[3].min(*fh);
                        }
                    }
                }
                let f = |v: f64| if v.is_finite() { format!("{:.4}", v) } else { "-".into() };
                crate::out!("    {:<28} {:>10} {:>10} {:>10} {:>10}", i, f(w[0]), f(w[1]), f(w[2]), f(w[3]));
            }
        }
        let total: usize = stats.values().map(|s| s.n).sum();
        if over == 0 && total > 0 {
            crate::info!("HIER-200", "Block abstracts match flat timing: {} comparisons within {} ns setup / {} ns hold", total, tol, htol);
        } else {
            crate::warn!("HIER-210", "Block abstracts differ from flat timing: {} of {} comparisons beyond tolerance", over, total);
        }
        Ok(format!("{} {}", total, over))
    }
}
