//! Clock tree synthesis.
//!
//! * Trace: from each clock root net through existing buffers / inverters / ICGs / clock logic and
//!   hierarchical boundary pins; every driven clock net becomes a tree to synthesize.
//! * Build: sinks are clustered by recursive balanced bisection (cluster size <= max_fanout and
//!   estimated cluster capacitance <= max_cap); each cluster gets a clock buffer at its centroid,
//!   level by level until the root drives at most max_fanout nodes.
//! * Balance (driven by the caller with propagated-clock STA): early leaf clusters get delay cells.

use crate::liberty::{LibCell, Library};
use crate::netlist::*;
use std::collections::{HashMap, HashSet};

#[derive(Clone, Debug)]
pub struct CtsOpts {
    pub max_fanout: usize,
    pub max_cap: f64,
    pub c_per_um: f64,
    /// buffers ordered small -> large drive
    pub bufs: Vec<LibCell>,
}

#[derive(Clone, Debug, Default)]
pub struct TreeStat {
    pub net: String,
    pub sinks: usize,
    pub buffers: usize,
    pub levels: usize,
}

fn lc_of<'a>(libs: &'a [Library], nl: &Netlist, c: CellId) -> Option<&'a LibCell> {
    let l = nl.cell(c).lib()?;
    libs.iter().find_map(|x| x.cells.get(l))
}

/// clock tree exceptions honoured by tracing (full pin names "inst/pin")
#[derive(Clone, Debug, Default)]
pub struct TraceExc {
    /// excluded from the tree: not a sink, not followed, stays on its original net
    pub ignore: HashSet<String>,
    /// sinks where tracing stops (even through buffers / logic)
    pub leaf: HashSet<String>,
    /// tracing continues through the cell (e.g. a clock divider or a macro clock output)
    pub through: HashSet<String>,
}

/// Clock nets to synthesize (root first), with their sink pins.
pub fn trace(nl: &Netlist, libs: &[Library], roots: &[NetId]) -> Vec<(NetId, Vec<PinRef>)> {
    trace_ex(nl, libs, roots, &TraceExc::default()).into_iter().map(|(n, s, _)| (n, s)).collect()
}

/// Like `trace`, honouring ignore / leaf / through pins; also returns the root net of each net
pub fn trace_ex(nl: &Netlist, libs: &[Library], roots: &[NetId], ex: &TraceExc) -> Vec<(NetId, Vec<PinRef>, NetId)> {
    let mut out = vec![];
    let mut seen: HashSet<NetId> = HashSet::new();
    let mut q: Vec<(NetId, NetId)> = roots.iter().map(|r| (*r, *r)).collect();
    while let Some((n, root)) = q.pop() {
        if !seen.insert(n) || !nl.net_alive(n) {
            continue;
        }
        let mut sinks = vec![];
        for l in nl.loads(n) {
            let pn = nl.pin_name(l);
            if ex.ignore.contains(&pn) {
                continue;
            }
            sinks.push(l);
            let PinRef::Cell(c, _) = l else { continue };
            let cl = nl.cell(c);
            // follow the clock through non-sequential cells (buffers, inverters, ICGs, clock muxes,
            // boundary pins); registers and macros are leaves
            let follow = if ex.leaf.contains(&pn) {
                false
            } else if ex.through.contains(&pn) || cl.is_hport() {
                true
            } else {
                match lc_of(libs, nl, c) {
                    Some(lc) => lc.icg.is_some() || (lc.seq.is_none() && !lc.outputs().is_empty()),
                    None => false,
                }
            };
            if follow {
                for p in &cl.pins {
                    if p.dir == Dir::Out {
                        if let Some(o) = p.net {
                            // only continue where a clock actually goes on (to sequential clock pins somewhere)
                            q.push((o, root));
                        }
                    }
                }
            }
        }
        if !sinks.is_empty() {
            out.push((n, sinks, root));
        }
    }
    // keep only nets that lead to register / ICG clock pins (stop at clock-as-data)
    let reaches_clock = |nl: &Netlist, n: NetId| -> bool {
        let mut st = vec![n];
        let mut vis = HashSet::new();
        while let Some(m) = st.pop() {
            if !vis.insert(m) || vis.len() > 4096 {
                continue;
            }
            for l in nl.loads(m) {
                if let PinRef::Cell(c, p) = l {
                    let cl = nl.cell(c);
                    if let Some(lc) = lc_of(libs, nl, c) {
                        if lc.pin(&cl.pins[p].name).map(|x| x.is_clock).unwrap_or(false) {
                            return true;
                        }
                    }
                    if matches!(cl.kind, Kind::BlackBox(_)) {
                        return true;
                    }
                    for q in &cl.pins {
                        if q.dir == Dir::Out {
                            if let Some(o) = q.net {
                                st.push(o);
                            }
                        }
                    }
                }
            }
        }
        false
    };
    out.retain(|(n, s, _)| reaches_clock(nl, *n) || s.iter().any(|p| ex.leaf.contains(&nl.pin_name(*p))));
    out
}

fn centroid(v: &[(PinRef, (f64, f64))]) -> (f64, f64) {
    let n = v.len().max(1) as f64;
    let (x, y) = v.iter().fold((0.0, 0.0), |a, p| (a.0 + (p.1).0, a.1 + (p.1).1));
    (x / n, y / n)
}

fn span(v: &[(PinRef, (f64, f64))]) -> (f64, f64) {
    let (x0, x1) = v.iter().fold((f64::MAX, f64::MIN), |a, p| (a.0.min((p.1).0), a.1.max((p.1).0)));
    let (y0, y1) = v.iter().fold((f64::MAX, f64::MIN), |a, p| (a.0.min((p.1).1), a.1.max((p.1).1)));
    (x1 - x0, y1 - y0)
}

/// balanced recursive bisection into clusters of <= k nodes and <= max_cap estimated load
fn partition(v: Vec<(PinRef, (f64, f64))>, k: usize, cap: &dyn Fn(&[(PinRef, (f64, f64))]) -> f64, max_cap: f64, out: &mut Vec<Vec<(PinRef, (f64, f64))>>) {
    if v.len() <= 1 || (v.len() <= k && cap(&v) <= max_cap) {
        out.push(v);
        return;
    }
    let mut v = v;
    let (sx, sy) = span(&v);
    if sx >= sy {
        v.sort_by(|a, b| (a.1).0.partial_cmp(&(b.1).0).unwrap());
    } else {
        v.sort_by(|a, b| (a.1).1.partial_cmp(&(b.1).1).unwrap());
    }
    // split so that the left part is a multiple of k when possible (fuller clusters)
    let n = v.len();
    let mut cut = n / 2;
    if n > k {
        let groups = n.div_ceil(k);
        cut = (groups / 2).max(1) * k;
        if cut >= n {
            cut = n / 2;
        }
    }
    let right = v.split_off(cut);
    partition(v, k, cap, max_cap, out);
    partition(right, k, cap, max_cap, out);
}

/// Build a buffered tree on `net` for `sinks`. Returns (stat, leaf buffers with their sink pins).
pub fn build(nl: &mut Netlist, libs: &[Library], o: &CtsOpts, net: NetId, sinks: &[PinRef], prefix: &str) -> (TreeStat, Vec<(CellId, Vec<PinRef>)>) {
    let mut st = TreeStat { net: nl.net(net).name.clone(), sinks: sinks.len(), ..Default::default() };
    let pin_cap = |nl: &Netlist, p: PinRef| -> f64 {
        match p {
            PinRef::Cell(c, i) => lc_of(libs, nl, c).and_then(|l| l.pin(&nl.cell(c).pins[i].name)).map(|x| x.cap).unwrap_or(0.002),
            PinRef::Port(_) => 0.002,
        }
    };
    let dl = nl.driver(net).and_then(|d| nl.pin_loc(d));
    let mut nodes: Vec<(PinRef, (f64, f64))> = vec![];
    let mut unplaced = vec![];
    for &s in sinks {
        match nl.pin_loc(s) {
            Some(l) => nodes.push((s, l)),
            None => unplaced.push(s),
        }
    }
    let c0 = if nodes.is_empty() { dl.unwrap_or((0.0, 0.0)) } else { centroid(&nodes) };
    for s in unplaced {
        nodes.push((s, c0));
    }
    let mut leaves: Vec<(CellId, Vec<PinRef>)> = vec![];
    let mut level = 0;
    loop {
        if level > 0 && nodes.len() <= o.max_fanout {
            break;
        }
        let caps: HashMap<PinRef, f64> = nodes.iter().map(|(p, _)| (*p, pin_cap(nl, *p))).collect();
        let capf = |v: &[(PinRef, (f64, f64))]| -> f64 {
            let (sx, sy) = span(v);
            v.iter().map(|(p, _)| caps.get(p).copied().unwrap_or(0.002)).sum::<f64>() + (sx + sy) * 1.2 * o.c_per_um
        };
        // keep pass-through clock pins (ICGs, clock logic, lower-level buffers' inputs at level 0)
        // apart from register clock pins so their insertion delays can be balanced separately
        let is_deep = |nl: &Netlist, p: PinRef| -> bool {
            match p {
                PinRef::Cell(c, _) => {
                    let cl = nl.cell(c);
                    if cl.is_hport() {
                        return true;
                    }
                    match lc_of(libs, nl, c) {
                        Some(lc) => lc.icg.is_some() || (lc.seq.is_none() && !lc.outputs().is_empty() && !cl.has_attr("cts")),
                        None => false,
                    }
                }
                PinRef::Port(_) => false,
            }
        };
        let (deep, flat): (Vec<_>, Vec<_>) = nodes.iter().cloned().partition(|(p, _)| level == 0 && is_deep(nl, *p));
        let mut cl = vec![];
        if !deep.is_empty() {
            partition(deep, o.max_fanout, &capf, o.max_cap, &mut cl);
        }
        if !flat.is_empty() {
            partition(flat, o.max_fanout, &capf, o.max_cap, &mut cl);
        }
        // leaf level uses the smallest adequate buffer, upper levels the strongest
        let bc = if level == 0 { &o.bufs[o.bufs.len() / 2] } else { o.bufs.last().unwrap() };
        let mut next = vec![];
        for c in cl {
            let pins: Vec<PinRef> = c.iter().map(|x| x.0).collect();
            let b = crate::opt::insert_buffer(nl, net, &pins, bc, &format!("{}_L{}_", prefix, level));
            let ctr = centroid(&c);
            {
                let cm = nl.cell_mut(b);
                cm.loc = Some(ctr);
                cm.attrs.retain(|a| a != "opt_buffer");
                cm.attrs.push("cts".into());
                cm.dont_touch = true;
            }
            let inp = nl.cell(b).pins.iter().position(|p| p.dir == Dir::In).unwrap();
            if let Some(on) = nl.cell(b).pins.iter().find(|p| p.dir == Dir::Out).and_then(|p| p.net) {
                nl.net_mut(on).dont_touch = true;
            }
            if level == 0 {
                leaves.push((b, pins));
            }
            st.buffers += 1;
            next.push((PinRef::Cell(b, inp), ctr));
        }
        nodes = next;
        level += 1;
        if level > 24 {
            break;
        }
    }
    nl.net_mut(net).dont_touch = true;
    st.levels = level;
    (st, leaves)
}

/// Insert a delay cell in front of a leaf cluster buffer (balancing). Returns the new cell.
pub fn add_delay_chain(nl: &mut Netlist, leaf: CellId, cell: &LibCell, prefix: &str, n: usize) -> Vec<CellId> {
    (0..n).filter_map(|_| add_delay(nl, leaf, cell, prefix)).collect()
}

/// remove specific CTS cells (merging their nets back)
pub fn remove_cells(nl: &mut Netlist, cells: &[CellId]) {
    for &c in cells.iter().rev() {
        if !nl.cell_alive(c) {
            continue;
        }
        let i = nl.cell(c).pins.iter().find(|p| p.dir == Dir::In).and_then(|p| p.net);
        let o = nl.cell(c).pins.iter().find(|p| p.dir == Dir::Out).and_then(|p| p.net);
        nl.remove_cell(c);
        if let (Some(i), Some(o)) = (i, o) {
            nl.merge_net(i, o);
        }
    }
}

pub fn add_delay(nl: &mut Netlist, leaf: CellId, cell: &LibCell, prefix: &str) -> Option<CellId> {
    let inp = nl.cell(leaf).pins.iter().position(|p| p.dir == Dir::In)?;
    let net = nl.cell(leaf).pins[inp].net?;
    let d = crate::opt::insert_buffer(nl, net, &[PinRef::Cell(leaf, inp)], cell, prefix);
    let loc = nl.cell(leaf).loc;
    let cm = nl.cell_mut(d);
    cm.loc = loc;
    cm.attrs.retain(|a| a != "opt_buffer");
    cm.attrs.push("cts".into());
    cm.attrs.push("cts_delay".into());
    cm.dont_touch = true;
    if let Some(on) = nl.cell(d).pins.iter().find(|p| p.dir == Dir::Out).and_then(|p| p.net) {
        nl.net_mut(on).dont_touch = true;
    }
    Some(d)
}

/// Remove all CTS-inserted cells (merging their nets back).
pub fn remove_trees(nl: &mut Netlist) -> usize {
    let mut n = 0;
    for c in nl.cell_ids() {
        if !nl.cell_alive(c) || !nl.cell(c).has_attr("cts") {
            continue;
        }
        let i = nl.cell(c).pins.iter().find(|p| p.dir == Dir::In).and_then(|p| p.net);
        let o = nl.cell(c).pins.iter().find(|p| p.dir == Dir::Out).and_then(|p| p.net);
        nl.remove_cell(c);
        if let (Some(i), Some(o)) = (i, o) {
            let po = nl.net(o).conns.iter().any(|p| matches!(p, PinRef::Port(_)));
            if po {
                nl.merge_net(o, i);
            } else {
                nl.merge_net(i, o);
            }
        }
        n += 1;
    }
    n
}
