//! Elaboration: parameter resolution, generate unrolling, interface (array) flattening,
//! symbolic execution of procedural blocks into a generic gate netlist with:
//!   * structural hashing + constant folding while building (logic sharing)
//!   * latch inference detection (incomplete assignment in comb blocks)
//!   * enable-flop extraction (feedback mux) -> later clock-gating candidates
//!   * async set/reset recognition
//!   * black-box / empty-module handling with explicit log indicators
//!   * multi-driver and non-uniquified-instance bookkeeping

use crate::hdl::ast::*;
use crate::hdl::HdlLib;
use crate::netlist::*;
use std::collections::{BTreeMap, HashMap, HashSet};

type ER<T> = Result<T, String>;

#[derive(Clone, Debug)]
struct Sig {
    name: String,
    bits: Vec<NetId>,
    dims: Vec<(i64, i64)>,
    signed: bool,
    ty: Option<String>,
    /// leading unpacked dimensions in `dims` (an element select keeps the element signedness)
    udims: usize,
}
impl Sig {
    fn width(&self) -> usize {
        self.bits.len()
    }
}

#[derive(Clone, Debug, Default)]
struct TypeInfo {
    width: usize,
    signed: bool,
    dims: Vec<(i64, i64)>,
    fields: Vec<Field>,
}
#[derive(Clone, Debug, Default)]
struct Field {
    name: String,
    /// offset of the field LSB in the struct
    off: usize,
    width: usize,
    /// struct type of the field
    ty: Option<String>,
    signed: bool,
    /// packed dimensions of the field (empty for a single bit)
    dims: Vec<(i64, i64)>,
}

#[derive(Clone, Debug)]
struct IfInst {
    def: String,
    lo: i64,
    elems: Vec<HashMap<String, Sig>>,
    is_array: bool,
}

#[derive(Default, Clone)]
struct Scope {
    boundary: bool,
    sigs: HashMap<String, Sig>,
    params: HashMap<String, i128>,
    /// width and signedness of value parameters (default: 32-bit signed integer)
    pinfo: HashMap<String, (usize, bool)>,
    /// exact bits of parameters wider than the 127-bit integer value
    pbits: HashMap<String, Vec<NetId>>,
    /// overrides of body `parameter`s, applied when the declaration is reached
    pend: HashMap<String, (i128, Option<(usize, bool)>)>,
    ptypes: HashMap<String, String>,
    ifaces: HashMap<String, IfInst>,
    types: HashMap<String, TypeInfo>,
    funcs: HashMap<String, Func>,
}

#[derive(Clone)]
struct PState {
    vals: BTreeMap<NetId, (NetId, NetId)>,
    blocking: HashSet<NetId>,
    done: NetId,
    /// `break` / `continue` taken in the innermost loop (constant or condition net)
    brk: NetId,
    cont: NetId,
}

#[derive(Clone, Debug)]
pub struct ElabOpts {
    pub empty_as_blackbox: bool,
    pub top_params: Vec<(String, i128)>,
    pub blackboxes: HashSet<String>,
    pub adder: String,
    /// library cells available for linking gate-level netlists: name -> pins
    pub lib_cells: HashMap<String, Vec<(String, Dir)>>,
    /// boundary optimization default (true = optimize across hierarchy boundaries)
    pub boundary_default: bool,
    /// per-instance overrides (instance pattern, boundary optimization), last match wins
    pub boundary: Vec<(String, bool)>,
}
impl Default for ElabOpts {
    fn default() -> Self {
        ElabOpts { empty_as_blackbox: true, top_params: vec![], blackboxes: HashSet::new(), adder: "kogge_stone".into(), lib_cells: HashMap::new(), boundary_default: true, boundary: vec![] }
    }
}
impl ElabOpts {
    /// true when the instance's boundary must be preserved (boundary optimization off)
    pub fn keep_boundary(&self, inst: &str) -> bool {
        let mut opt = self.boundary_default;
        for (p, v) in &self.boundary {
            if crate::netlist::glob(p, inst) {
                opt = *v;
            }
        }
        !opt
    }
}

pub struct ElabResult {
    pub netlist: Netlist,
    pub latches: Vec<String>,
    pub multi_inst: Vec<(String, Vec<String>)>,
    pub blackboxes: Vec<(String, String, &'static str)>, // inst, module, reason
    /// effects of synthesis pragmas (full_case / parallel_case / unique / priority)
    pub pragma_notes: Vec<String>,
}

struct Ctx<'a> {
    lib: &'a HdlLib,
    nl: Netlist,
    c0: NetId,
    c1: NetId,
    hash: HashMap<(GOp, NetId, NetId, NetId), NetId>,
    inv: HashMap<NetId, NetId>,
    opts: ElabOpts,
    stack: Vec<Scope>,
    pkg: Scope,
    prefix: String,
    gpath: String,
    procs: Vec<PState>,
    latches: Vec<String>,
    pragma_notes: Vec<String>,
    /// warnings already issued (once per file / expression)
    warned: HashSet<String>,
    insts: BTreeMap<String, Vec<String>>,
    bbs: Vec<(String, String, &'static str)>,
    unresolved_pins: Vec<(CellId, usize)>,
    depth: usize,
    gcount: usize,
    cur_file: String,
    /// every declared signal by hierarchical name ('.' separated), for references into
    /// generate scopes and instances (g[1].x, u_sub.y)
    hier: HashMap<String, Sig>,
    /// target shape for an assignment pattern '{..} on the right-hand side
    tgt: Option<Sig>,
    /// width / signedness of parameter override values of the instance being bound
    ov_types: HashMap<String, (usize, bool)>,
    /// variable initializers of the module being elaborated: (name, nets, value)
    var_inits: Vec<(String, Vec<NetId>, Vec<NetId>)>,
    /// parameters declared in generate scopes, by hierarchical name (gen[1].P)
    hier_params: HashMap<String, (i128, usize, bool)>,
}

pub fn elaborate(lib: &HdlLib, top: &str, opts: ElabOpts) -> ER<ElabResult> {
    let tm = lib.modules.get(top).ok_or_else(|| format!("Cannot find design '{}' in library WORK (LINK-3)", top))?;
    let mut nl = Netlist::new(top);
    let c0 = nl.add_net("1'b0");
    let c1 = nl.add_net("1'b1");
    nl.add_gen("logic0", GOp::C0, &[], c0);
    nl.add_gen("logic1", GOp::C1, &[], c1);
    let mut cx = Ctx {
        lib,
        nl,
        c0,
        c1,
        hash: HashMap::new(),
        inv: HashMap::new(),
        opts,
        stack: vec![],
        pkg: Scope::default(),
        prefix: String::new(),
        gpath: String::new(),
        procs: vec![],
        latches: vec![],
        pragma_notes: vec![],
        warned: HashSet::new(),
        insts: BTreeMap::new(),
        bbs: vec![],
        unresolved_pins: vec![],
        depth: 0,
        gcount: 0,
        cur_file: tm.file.clone(),
        hier: HashMap::new(),
        tgt: None,
        ov_types: HashMap::new(),
        var_inits: vec![],
        hier_params: HashMap::new(),
    };
    // packages: all packages are visible ($unit + imported)
    for n in &lib.order {
        let m = &lib.modules[n];
        if m.kind == ModKind::Package {
            cx.stack = vec![Scope { boundary: true, ..Default::default() }];
            cx.decl_pass(&m.items)?;
            let s = cx.stack.pop().unwrap();
            cx.pkg.params.extend(s.params);
            cx.pkg.pinfo.extend(s.pinfo);
            cx.pkg.pbits.extend(s.pbits);
            cx.pkg.sigs.extend(s.sigs);
            cx.pkg.types.extend(s.types);
            cx.pkg.funcs.extend(s.funcs);
            cx.pkg.ptypes.extend(s.ptypes);
        }
    }
    cx.stack = vec![Scope { boundary: true, ..Default::default() }];
    let tp = cx.opts.top_params.clone();
    cx.bind_params(tm, &tp.iter().map(|(n, v)| (n.clone(), *v)).collect::<Vec<_>>(), &HashMap::new())?;
    // top ports
    for p in &tm.ports {
        if let Some((ifn, mp)) = &p.iface {
            let inst = cx.make_iface(ifn, &p.name, &p.unpacked, &[], Some((mp.clone(), true)))?;
            cx.stack.last_mut().unwrap().ifaces.insert(p.name.clone(), inst);
            continue;
        }
        let dir = p.dir.unwrap_or(Dir::In);
        let (dims, signed, ty) = cx.type_dims(&p.ty, &p.unpacked)?;
        let names = bit_names(&p.name, &dims);
        if dims.len() == 1 { cx.nl.bus_ranges.insert(p.name.clone(), dims[0]); }
        if dims.is_empty() && p.name.ends_with(']') { cx.nl.scalar_ports.insert(p.name.clone()); }
        let mut bits = vec![];
        for n in &names {
            let pid = cx.nl.add_port(n, dir);
            bits.push(cx.nl.ports[pid].net.unwrap());
        }
        let sg = Sig { name: p.name.clone(), bits, dims, signed, ty, udims: p.unpacked.len() };
        cx.hier.insert(p.name.clone(), sg.clone());
        cx.stack.last_mut().unwrap().sigs.insert(p.name.clone(), sg);
    }
    cx.module_body(tm)?;
    cx.finish()?;
    let multi: Vec<(String, Vec<String>)> = cx.insts.iter().filter(|(_, v)| v.len() > 1).map(|(k, v)| (k.clone(), v.clone())).collect();
    Ok(ElabResult { netlist: cx.nl, latches: cx.latches, multi_inst: multi, blackboxes: cx.bbs, pragma_notes: cx.pragma_notes })
}

fn bit_names(name: &str, dims: &[(i64, i64)]) -> Vec<String> {
    if dims.is_empty() {
        return vec![name.to_string()];
    }
    let mut out = vec![];
    let sizes: Vec<usize> = dims.iter().map(|(l, r)| ((l - r).unsigned_abs() + 1) as usize).collect();
    let total: usize = sizes.iter().product();
    for o in 0..total {
        let mut rem = o;
        let mut idx = vec![0i64; dims.len()];
        for k in (0..dims.len()).rev() {
            let off = (rem % sizes[k]) as i64;
            rem /= sizes[k];
            let (l, r) = dims[k];
            idx[k] = if l >= r { r + off } else { r - off };
        }
        let mut s = name.to_string();
        for i in idx {
            s.push_str(&format!("[{}]", i));
        }
        out.push(s);
    }
    out
}

fn dim_off(d: (i64, i64), i: i64) -> Option<usize> {
    let (l, r) = d;
    let (lo, hi) = (l.min(r), l.max(r));
    if i < lo || i > hi {
        return None;
    }
    Some(if l >= r { (i - r) as usize } else { (r - i) as usize })
}

/// value truncated to `w` bits (sign-extended back when signed)
fn norm_val(v: i128, w: usize, signed: bool) -> i128 {
    if w == 0 || w >= 127 {
        return v;
    }
    let m = v & ((1i128 << w) - 1);
    if signed && (m >> (w - 1)) & 1 == 1 {
        m - (1i128 << w)
    } else {
        m
    }
}
/// declared-order bounds of v[s +: w] / v[s -: w]
fn plus_bounds(bs: &Sig, sv: i128, wv: i128, up: bool) -> (i128, i128) {
    let (l, r) = if up { (sv + wv - 1, sv) } else { (sv, sv - wv + 1) };
    if bs.dims.first().map(|d| d.0 < d.1).unwrap_or(false) { (r, l) } else { (l, r) }
}

fn expr_mentions(e: &Expr, n: &str) -> bool {
    match e {
        Expr::Id(x) => x == n,
        Expr::Un(_, a) | Expr::Member(a, _) | Expr::Fill(a) => expr_mentions(a, n),
        Expr::Bin(_, a, b) | Expr::Index(a, b) | Expr::Cast(a, b) => expr_mentions(a, n) || expr_mentions(b, n),
        Expr::Range(a, b, c) | Expr::PlusRange(a, b, c, _) | Expr::Cond(a, b, c) => expr_mentions(a, n) || expr_mentions(b, n) || expr_mentions(c, n),
        Expr::Concat(v) | Expr::Call(_, v) | Expr::Stream(_, _, v) => v.iter().any(|x| expr_mentions(x, n)),
        Expr::Repl(a, v) | Expr::Inside(a, v) => expr_mentions(a, n) || v.iter().any(|x| expr_mentions(x, n)),
        Expr::Pattern(v, d) => v.iter().any(|(_, x)| expr_mentions(x, n)) || d.as_ref().map(|x| expr_mentions(x, n)).unwrap_or(false),
        _ => false,
    }
}
fn expr_name(e: &Expr) -> Option<String> {
    match e {
        Expr::Id(x) => Some(x.clone()),
        Expr::Index(a, _) | Expr::Member(a, _) => expr_name(a),
        _ => None,
    }
}

impl<'a> Ctx<'a> {
    // ------------------------------------------------------------ gate builder
    fn newnet(&mut self) -> NetId {
        self.gcount += 1;
        let n = format!("{}n{}", self.prefix, self.gcount);
        self.nl.add_net(&n)
    }
    /// Boundary pins (boundary optimization off): one dont_touch zero-delay pass-through per port bit,
    /// so no constant propagation, logic merging, sweeping or mapping crosses the instance boundary.
    fn boundary_pins(&mut self, iname: &str, port: &str, dims: &[(i64, i64)], dir: Dir, bits: Vec<NetId>) -> Vec<NetId> {
        if dir == Dir::InOut {
            crate::warn!("ELAB-420", "inout port '{}' of '{}': boundary preserved without a boundary pin", port, iname);
            return bits;
        }
        let names = bit_names(port, dims);
        if dims.len() == 1 { self.nl.bus_ranges.insert(format!("{}:{}", iname, port), dims[0]); }
        let mut out = Vec::with_capacity(bits.len());
        for (i, b) in bits.into_iter().enumerate() {
            let pb = names.get(i).cloned().unwrap_or_else(|| format!("{}[{}]", port, i));
            let nn = self.nl.add_net(&format!("{}/{}", iname, pb));
            let cname = format!("{}/__hp_{}", iname, pb);
            let c = if dir == Dir::In {
                self.nl.add_gen(&cname, GOp::Buf, &[b], nn)
            } else {
                self.nl.add_gen(&cname, GOp::Buf, &[nn], b)
            };
            let cell = self.nl.cell_mut(c);
            cell.dont_touch = true;
            cell.attrs.push("hier_port".into());
            cell.attrs.push(format!("hp:{}:{}:{}", iname, pb, if dir == Dir::In { "i" } else { "o" }));
            out.push(nn);
        }
        out
    }

    fn gate(&mut self, op: GOp, ins: &[NetId]) -> NetId {
        let key = match ins.len() {
            1 => (op, ins[0], 0, 0),
            2 => {
                let (a, b) = if matches!(op, GOp::And | GOp::Or | GOp::Xor) && ins[0] > ins[1] { (ins[1], ins[0]) } else { (ins[0], ins[1]) };
                (op, a, b, 0)
            }
            _ => (op, ins[0], ins[1], ins[2]),
        };
        if let Some(&n) = self.hash.get(&key) {
            return n;
        }
        let out = self.newnet();
        self.gcount += 1;
        let cname = format!("{}U{}", self.prefix, self.gcount);
        self.nl.add_gen(&cname, op, ins, out);
        self.hash.insert(key, out);
        out
    }
    fn not(&mut self, a: NetId) -> NetId {
        if a == self.c0 {
            return self.c1;
        }
        if a == self.c1 {
            return self.c0;
        }
        if let Some(&x) = self.inv.get(&a) {
            return x;
        }
        let o = self.gate(GOp::Not, &[a]);
        self.inv.insert(a, o);
        self.inv.insert(o, a);
        o
    }
    fn is_compl(&self, a: NetId, b: NetId) -> bool {
        self.inv.get(&a) == Some(&b)
    }
    fn and(&mut self, a: NetId, b: NetId) -> NetId {
        if a == self.c0 || b == self.c0 || self.is_compl(a, b) {
            return self.c0;
        }
        if a == self.c1 {
            return b;
        }
        if b == self.c1 || a == b {
            return a;
        }
        self.gate(GOp::And, &[a, b])
    }
    fn or(&mut self, a: NetId, b: NetId) -> NetId {
        if a == self.c1 || b == self.c1 || self.is_compl(a, b) {
            return self.c1;
        }
        if a == self.c0 {
            return b;
        }
        if b == self.c0 || a == b {
            return a;
        }
        self.gate(GOp::Or, &[a, b])
    }
    fn xor(&mut self, a: NetId, b: NetId) -> NetId {
        if a == self.c0 {
            return b;
        }
        if b == self.c0 {
            return a;
        }
        if a == self.c1 {
            return self.not(b);
        }
        if b == self.c1 {
            return self.not(a);
        }
        if a == b {
            return self.c0;
        }
        if self.is_compl(a, b) {
            return self.c1;
        }
        self.gate(GOp::Xor, &[a, b])
    }
    /// s ? b : a
    fn mux(&mut self, s: NetId, a: NetId, b: NetId) -> NetId {
        if s == self.c0 || a == b {
            return a;
        }
        if s == self.c1 {
            return b;
        }
        if a == self.c0 && b == self.c1 {
            return s;
        }
        if a == self.c1 && b == self.c0 {
            return self.not(s);
        }
        if a == self.c0 {
            return self.and(s, b);
        }
        if b == self.c0 {
            let ns = self.not(s);
            return self.and(ns, a);
        }
        if b == self.c1 {
            return self.or(s, a);
        }
        if a == self.c1 {
            let ns = self.not(s);
            return self.or(ns, b);
        }
        self.gate(GOp::Mux, &[s, a, b])
    }
    fn reduce(&mut self, op: GOp, v: &[NetId]) -> NetId {
        if v.is_empty() {
            return if op == GOp::And { self.c1 } else { self.c0 };
        }
        let mut cur: Vec<NetId> = v.to_vec();
        while cur.len() > 1 {
            let mut nx = vec![];
            for ch in cur.chunks(2) {
                nx.push(if ch.len() == 2 {
                    match op {
                        GOp::And => self.and(ch[0], ch[1]),
                        GOp::Or => self.or(ch[0], ch[1]),
                        _ => self.xor(ch[0], ch[1]),
                    }
                } else {
                    ch[0]
                });
            }
            cur = nx;
        }
        cur[0]
    }
    fn cbits(&self, v: i128, w: usize) -> Vec<NetId> {
        (0..w).map(|k| if if k < 127 { (v >> k) & 1 == 1 } else { v < 0 } { self.c1 } else { self.c0 }).collect()
    }
    fn ext(&self, mut v: Vec<NetId>, w: usize, signed: bool) -> Vec<NetId> {
        if v.len() >= w {
            v.truncate(w);
            return v;
        }
        let f = if signed && !v.is_empty() { *v.last().unwrap() } else { self.c0 };
        v.resize(w, f);
        v
    }
    fn add(&mut self, a: &[NetId], b: &[NetId], cin: NetId) -> (Vec<NetId>, NetId) {
        if self.opts.adder == "kogge_stone" && a.len() >= 4 {
            return self.add_ks(a, b, cin);
        }
        let mut c = cin;
        let mut s = vec![];
        for k in 0..a.len() {
            let x = self.xor(a[k], b[k]);
            s.push(self.xor(x, c));
            let g = self.and(a[k], b[k]);
            let p = self.and(c, x);
            c = self.or(g, p);
        }
        (s, c)
    }
    /// Parallel-prefix (Kogge-Stone) adder: log2(n) carry depth.
    fn add_ks(&mut self, a: &[NetId], b: &[NetId], cin: NetId) -> (Vec<NetId>, NetId) {
        let n = a.len();
        let p0: Vec<NetId> = (0..n).map(|k| self.xor(a[k], b[k])).collect();
        let mut g: Vec<NetId> = (0..n).map(|k| self.and(a[k], b[k])).collect();
        let mut p = p0.clone();
        // fold carry-in into bit 0 generate
        let t = self.and(p[0], cin);
        g[0] = self.or(g[0], t);
        let mut d = 1;
        while d < n {
            let (gp, pp) = (g.clone(), p.clone());
            for k in d..n {
                let t = self.and(pp[k], gp[k - d]);
                g[k] = self.or(gp[k], t);
                p[k] = self.and(pp[k], pp[k - d]);
            }
            d *= 2;
        }
        let mut s = vec![];
        for k in 0..n {
            let c = if k == 0 { cin } else { g[k - 1] };
            s.push(self.xor(p0[k], c));
        }
        (s, g[n - 1])
    }
    fn sub(&mut self, a: &[NetId], b: &[NetId]) -> (Vec<NetId>, NetId) {
        let nb: Vec<NetId> = b.iter().map(|x| self.not(*x)).collect();
        let c1 = self.c1;
        self.add(a, &nb, c1)
    }
    fn mul(&mut self, a: &[NetId], b: &[NetId], w: usize) -> Vec<NetId> {
        if self.opts.adder == "kogge_stone" {
            return self.mul_csa(a, b, w);
        }
        let mut acc = vec![self.c0; w];
        for (i, &bi) in b.iter().enumerate().take(w) {
            let mut pp = vec![self.c0; w];
            for j in 0..w - i {
                if j < a.len() {
                    pp[i + j] = self.and(a[j], bi);
                }
            }
            let c0 = self.c0;
            acc = self.add(&acc, &pp, c0).0;
        }
        acc
    }
    /// Carry-save (Wallace-style) multiplier: partial-product columns reduced with
    /// 3:2 / 2:2 compressors to two rows, then a parallel-prefix final adder.
    fn mul_csa(&mut self, a: &[NetId], b: &[NetId], w: usize) -> Vec<NetId> {
        let mut cols: Vec<Vec<NetId>> = vec![vec![]; w];
        for (i, &bi) in b.iter().enumerate().take(w) {
            if bi == self.c0 {
                continue;
            }
            for (j, &aj) in a.iter().enumerate() {
                if i + j >= w {
                    break;
                }
                let pp = self.and(aj, bi);
                if pp != self.c0 {
                    cols[i + j].push(pp);
                }
            }
        }
        loop {
            if cols.iter().all(|c| c.len() <= 2) {
                break;
            }
            let mut nx: Vec<Vec<NetId>> = vec![vec![]; w];
            for k in 0..w {
                let col = std::mem::take(&mut cols[k]);
                let mut i = 0;
                while col.len() - i >= 3 {
                    let (x, y, z) = (col[i], col[i + 1], col[i + 2]);
                    let t = self.xor(x, y);
                    nx[k].push(self.xor(t, z));
                    let g = self.and(x, y);
                    let p = self.and(t, z);
                    let c = self.or(g, p);
                    if k + 1 < w {
                        nx[k + 1].push(c);
                    }
                    i += 3;
                }
                if col.len() - i == 2 && cols_len_gt2(&nx[k]) {
                    let (x, y) = (col[i], col[i + 1]);
                    nx[k].push(self.xor(x, y));
                    let c = self.and(x, y);
                    if k + 1 < w {
                        nx[k + 1].push(c);
                    }
                    i += 2;
                }
                nx[k].extend_from_slice(&col[i..]);
            }
            cols = nx;
        }
        let r0: Vec<NetId> = cols.iter().map(|c| c.first().copied().unwrap_or(self.c0)).collect();
        let r1: Vec<NetId> = cols.iter().map(|c| c.get(1).copied().unwrap_or(self.c0)).collect();
        let c0 = self.c0;
        self.add(&r0, &r1, c0).0
    }
    fn divmod(&mut self, a: &[NetId], b: &[NetId]) -> (Vec<NetId>, Vec<NetId>) {
        let w = a.len();
        let mut rem = vec![self.c0; w + 1];
        let bb = self.ext(b.to_vec(), w + 1, false);
        let mut q = vec![self.c0; w];
        for i in (0..w).rev() {
            rem.pop();
            rem.insert(0, a[i]);
            let (d, carry) = self.sub(&rem, &bb);
            q[i] = carry; // carry=1 => rem>=b
            rem = (0..w + 1).map(|k| self.mux(carry, rem[k], d[k])).collect();
        }
        rem.truncate(w);
        (q, rem)
    }
    fn eq(&mut self, a: &[NetId], b: &[NetId]) -> NetId {
        let v: Vec<NetId> = a.iter().zip(b).map(|(x, y)| {
            let t = self.xor(*x, *y);
            self.not(t)
        }).collect();
        self.reduce(GOp::And, &v)
    }
    fn lt(&mut self, a: &[NetId], b: &[NetId], signed: bool) -> NetId {
        let (mut a, mut b) = (a.to_vec(), b.to_vec());
        if signed && !a.is_empty() {
            let k = a.len() - 1;
            a[k] = self.not(a[k]);
            b[k] = self.not(b[k]);
        }
        let (_, c) = self.sub(&a, &b);
        self.not(c)
    }
    fn shift(&mut self, v: &[NetId], amt: &[NetId], left: bool, arith: bool) -> Vec<NetId> {
        let w = v.len();
        let fill = if arith && !left { *v.last().unwrap_or(&self.c0) } else { self.c0 };
        let mut cur = v.to_vec();
        let mut over = self.c0;
        for (k, &a) in amt.iter().enumerate() {
            let sh = 1usize.checked_shl(k as u32).unwrap_or(usize::MAX);
            if sh >= w {
                over = self.or(over, a);
                continue;
            }
            let shifted: Vec<NetId> = (0..w).map(|i| {
                if left {
                    if i >= sh { cur[i - sh] } else { self.c0 }
                } else if i + sh < w {
                    cur[i + sh]
                } else {
                    fill
                }
            }).collect();
            cur = (0..w).map(|i| self.mux(a, cur[i], shifted[i])).collect();
        }
        (0..w).map(|i| self.mux(over, cur[i], fill)).collect()
    }
    fn to_bool(&mut self, v: &[NetId]) -> NetId {
        self.reduce(GOp::Or, v)
    }

    // ------------------------------------------------------------ scopes
    fn lookup_sig(&self, n: &str) -> Option<Sig> {
        for s in self.stack.iter().rev() {
            if s.params.contains_key(n) {
                return None;
            }
            if let Some(x) = s.sigs.get(n) {
                return Some(x.clone());
            }
            if s.boundary {
                break;
            }
        }
        // package constants (parameter arrays)
        if self.pkg.params.contains_key(n) {
            return None;
        }
        self.pkg.sigs.get(n).cloned()
    }
    fn lookup_param(&self, n: &str) -> Option<i128> {
        for s in self.stack.iter().rev() {
            if let Some(x) = s.params.get(n) {
                return Some(*x);
            }
            if s.sigs.contains_key(n) {
                return None;
            }
            if s.boundary {
                break;
            }
        }
        self.pkg.params.get(n).copied()
    }
    fn lookup_iface(&self, n: &str) -> Option<IfInst> {
        for s in self.stack.iter().rev() {
            if let Some(x) = s.ifaces.get(n) {
                return Some(x.clone());
            }
            if s.boundary {
                break;
            }
        }
        None
    }
    fn lookup_type(&self, n: &str) -> Option<TypeInfo> {
        for s in self.stack.iter().rev() {
            if let Some(pt) = s.ptypes.get(n) {
                return self.lookup_type(&pt.clone());
            }
            if let Some(x) = s.types.get(n) {
                return Some(x.clone());
            }
            if s.boundary {
                break;
            }
        }
        if let Some(pt) = self.pkg.ptypes.get(n) {
            return self.lookup_type(&pt.clone());
        }
        match n {
            "logic" | "bit" | "reg" => return Some(TypeInfo { width: 1, ..Default::default() }),
            "int" | "integer" => return Some(TypeInfo { width: 32, signed: true, dims: vec![(31, 0)], ..Default::default() }),
            "byte" => return Some(TypeInfo { width: 8, signed: true, dims: vec![(7, 0)], ..Default::default() }),
            "shortint" => return Some(TypeInfo { width: 16, signed: true, dims: vec![(15, 0)], ..Default::default() }),
            "longint" => return Some(TypeInfo { width: 64, signed: true, dims: vec![(63, 0)], ..Default::default() }),
            "time" => return Some(TypeInfo { width: 64, signed: false, dims: vec![(63, 0)], ..Default::default() }),
            _ => {}
        }
        self.pkg.types.get(n).cloned()
    }
    /// declaration of an interface method `ifc.func`
    fn method_decl(&self, f: &str) -> Option<Func> {
        let (ifn, m) = f.rsplit_once('.')?;
        let ii = self.lookup_iface(ifn)?;
        let d = self.lib.modules.get(&ii.def)?;
        d.items.iter().find_map(|i| if let Item::Func(x) = i { if x.name == m { Some(x.clone()) } else { None } } else { None })
    }
    fn lookup_func(&self, n: &str) -> Option<Func> {
        for s in self.stack.iter().rev() {
            if let Some(x) = s.funcs.get(n) {
                return Some(x.clone());
            }
            if s.boundary {
                break;
            }
        }
        self.pkg.funcs.get(n).cloned()
    }
    fn top(&mut self) -> &mut Scope {
        self.stack.last_mut().unwrap()
    }

    fn type_dims(&mut self, t: &DType, unpacked: &[(Expr, Expr)]) -> ER<(Vec<(i64, i64)>, bool, Option<String>)> {
        let mut dims = vec![];
        for (a, b) in unpacked {
            dims.push((self.ceval(a)? as i64, self.ceval(b)? as i64));
        }
        let (packed, signed, ty) = self.type_info(t)?;
        dims.extend(packed);
        Ok((dims, signed, ty))
    }
    /// packed dims, signed, struct type name
    fn type_info(&mut self, t: &DType) -> ER<(Vec<(i64, i64)>, bool, Option<String>)> {
        match t {
            DType::Logic { signed, packed } => {
                let mut d = vec![];
                for (a, b) in packed {
                    d.push((self.ceval(a)? as i64, self.ceval(b)? as i64));
                }
                Ok((d, *signed, None))
            }
            DType::Named { name, packed } => {
                let ti = self.lookup_type(name).ok_or_else(|| format!("{}: unknown type '{}' (ELAB-1001)", self.cur_file, name))?;
                let mut d = vec![];
                for (a, b) in packed {
                    d.push((self.ceval(a)? as i64, self.ceval(b)? as i64));
                }
                if ti.dims.is_empty() && ti.width > 1 {
                    d.push((ti.width as i64 - 1, 0));
                } else {
                    d.extend(ti.dims.iter().copied());
                }
                Ok((d, ti.signed, if ti.fields.is_empty() { None } else { Some(name.clone()) }))
            }
            DType::Enum { base, items } => {
                let (d, s, _) = self.type_info(base)?;
                let w = d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
                let mut v: i128 = 0;
                for (n, e) in items {
                    if let Some(e) = e {
                        v = self.ceval(e)?;
                    }
                    let nv = norm_val(v, w, s);
                    if nv != v {
                        crate::warn!("ELAB-149", "{}: enum value {} of '{}' does not fit the {}-bit base type", self.cur_file, v, n, w);
                    }
                    self.top().params.insert(n.clone(), nv);
                    self.top().pinfo.insert(n.clone(), (w, s));
                    v += 1;
                }
                Ok((d, s, None))
            }
            DType::Struct { packed, .. } => {
                let ti = self.struct_info(t)?;
                let nm = format!("$anon_struct{}", self.gcount);
                self.gcount += 1;
                let w = ti.width;
                let sg = ti.signed;
                self.top().types.insert(nm.clone(), ti);
                let mut d = vec![];
                for (a, b) in packed {
                    d.push((self.ceval(a)? as i64, self.ceval(b)? as i64));
                }
                d.push((w as i64 - 1, 0));
                Ok((d, sg, Some(nm)))
            }
        }
    }
    fn struct_info(&mut self, t: &DType) -> ER<TypeInfo> {
        if let DType::Struct { fields, union, signed, .. } = t {
            let mut infos = vec![];
            for (n, ft) in fields {
                let (d, sg, ty) = self.type_info(ft)?;
                let w: usize = d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
                infos.push(Field { name: n.clone(), off: 0, width: w, ty, signed: sg, dims: d });
            }
            let tot = if *union { infos.iter().map(|f| f.width).max().unwrap_or(1) } else { infos.iter().map(|f| f.width).sum() };
            if *union && infos.iter().any(|f| f.width != tot) {
                crate::warn!("ELAB-150", "{}: members of a packed union differ in width; narrower members are LSB-aligned", self.cur_file);
            }
            if !*union {
                // first field is the MSB
                let mut off = tot;
                for f in infos.iter_mut() {
                    off -= f.width;
                    f.off = off;
                }
            }
            return Ok(TypeInfo { width: tot, signed: *signed, dims: vec![], fields: infos });
        }
        Err("not a struct".into())
    }

    fn mk_sig(&mut self, name: &str, ty: &DType, unpacked: &[(Expr, Expr)]) -> ER<Sig> {
        let (dims, signed, tyn) = self.type_dims(ty, unpacked)?;
        let names = bit_names(&format!("{}{}{}", self.prefix, self.gpath, name), &dims);
        let bits = names.iter().map(|n| self.nl.add_net(n)).collect();
        let s = Sig { name: format!("{}{}{}", self.prefix, self.gpath, name), bits, dims, signed, ty: tyn, udims: unpacked.len() };
        self.hier.insert(s.name.replace('/', "."), s.clone());
        Ok(s)
    }

    fn lookup_pbits(&self, n: &str) -> Option<Vec<NetId>> {
        for s in self.stack.iter().rev() {
            if s.params.contains_key(n) {
                return s.pbits.get(n).cloned();
            }
            if s.sigs.contains_key(n) || s.boundary {
                break;
            }
        }
        self.pkg.pbits.get(n).cloned()
    }
    fn lookup_pinfo(&self, n: &str) -> (usize, bool) {
        for s in self.stack.iter().rev() {
            if s.params.contains_key(n) {
                return s.pinfo.get(n).copied().unwrap_or((32, true));
            }
            if s.sigs.contains_key(n) || s.boundary {
                break;
            }
        }
        self.pkg.pinfo.get(n).copied().unwrap_or((32, true))
    }
    /// true when the expression reads a signal (not a constant expression)
    fn mentions_sig(&self, e: &Expr) -> bool {
        match e {
            Expr::Id(n) => self.lookup_param(n).is_none() && (self.lookup_sig(n).is_some() || self.lookup_iface(n).is_some() || self.lookup_type(n).is_none()),
            Expr::Num { .. } | Expr::Str(_) | Expr::Scoped(..) => false,
            Expr::Un(_, a) | Expr::Fill(a) => self.mentions_sig(a),
            Expr::Member(..) => true,
            Expr::Bin(_, a, b) | Expr::Index(a, b) => self.mentions_sig(a) || self.mentions_sig(b),
            Expr::Cast(t, x) => (!matches!(&**t, Expr::Id(_)) && self.mentions_sig(t)) || self.mentions_sig(x),
            Expr::Range(a, b, c) | Expr::PlusRange(a, b, c, _) | Expr::Cond(a, b, c) => self.mentions_sig(a) || self.mentions_sig(b) || self.mentions_sig(c),
            Expr::Concat(v) => v.iter().any(|x| self.mentions_sig(x)),
            Expr::Call(f, v) => !matches!(f.as_str(), "$bits" | "$size" | "$left" | "$right" | "$high" | "$low" | "$increment" | "$dimensions") && v.iter().any(|x| self.mentions_sig(x)),
            Expr::Repl(a, v) | Expr::Inside(a, v) => self.mentions_sig(a) || v.iter().any(|x| self.mentions_sig(x)),
            Expr::Stream(_, s, v) => s.as_ref().map(|x| self.mentions_sig(x)).unwrap_or(false) || v.iter().any(|x| self.mentions_sig(x)),
            Expr::Pattern(v, d) => v.iter().any(|(_, x)| self.mentions_sig(x)) || d.as_ref().map(|x| self.mentions_sig(x)).unwrap_or(false),
        }
    }
    /// Constant value of an expression with full IEEE width / signedness semantics, computed
    /// by building it with the constant-folding gate builder (constant functions included).
    fn cfold(&mut self, e: &Expr, w: usize) -> ER<(i128, usize, bool)> {
        if self.mentions_sig(e) {
            return Err("not a constant expression".into());
        }
        let (bits, s) = self.ev(e, w)?;
        let mut v: i128 = 0;
        for (k, b) in bits.iter().enumerate() {
            let one = if *b == self.c1 { true } else if *b == self.c0 { false } else { return Err("not a constant expression".into()) };
            if one && k < 127 {
                v |= 1 << k;
            }
        }
        let n = bits.len();
        Ok((norm_val(v, n, s), n, s))
    }

    // ------------------------------------------------------------ constant eval
    fn ceval(&mut self, e: &Expr) -> ER<i128> {
        let r = self.ceval_i(e);
        match r {
            Ok(v) => Ok(v),
            Err(err) => match self.cfold(e, 0) {
                Ok((v, _, _)) => Ok(v),
                Err(_) => Err(err),
            },
        }
    }
    fn ceval_i(&mut self, e: &Expr) -> ER<i128> {
        Ok(match e {
            Expr::Num { bits, signed, width, fill } => {
                if *fill {
                    return Ok(if bits[0] == 1 { -1 } else { 0 });
                }
                if bits.iter().any(|b| *b >= 2) {
                    return Err("x/z in constant expression".into());
                }
                let mut v: i128 = 0;
                for (k, b) in bits.iter().enumerate().take(127) {
                    if *b == 1 {
                        v |= 1 << k
                    }
                }
                let w = width.map(|w| w as usize).unwrap_or(bits.len());
                if *signed && w < 127 && w > 0 && (v >> (w - 1)) & 1 == 1 {
                    v -= 1 << w;
                }
                v
            }
            Expr::Id(n) => match self.lookup_param(n) {
                Some(v) => v,
                None => return Err(format!("'{}' is not a constant", n)),
            },
            Expr::Scoped(_, n) => self.pkg.params.get(n).copied().ok_or_else(|| format!("unknown package item {}", n))?,
            Expr::Un(op, a) => {
                let v = self.ceval(a)?;
                match op.as_str() {
                    "-" => -v,
                    "+" => v,
                    "!" => (v == 0) as i128,
                    "~" => !v,
                    _ => return Err("unsupported const unary".into()),
                }
            }
            Expr::Bin(op, a, b) => {
                let x = self.ceval(a)?;
                let y = self.ceval(b)?;
                match op.as_str() {
                    "+" => x.checked_add(y).ok_or("constant overflow")?,
                    "-" => x.checked_sub(y).ok_or("constant overflow")?,
                    "*" => x.checked_mul(y).ok_or("constant overflow")?,
                    "/" => {
                        if y == 0 {
                            return Err("division by zero".into());
                        }
                        x / y
                    }
                    "%" => {
                        if y == 0 {
                            return Err("division by zero".into());
                        }
                        x % y
                    }
                    "**" => {
                        if y < 0 {
                            return Err("negative exponent".into());
                        }
                        x.checked_pow(y.min(200) as u32).ok_or("constant overflow")?
                    }
                    "<<" | "<<<" => {
                        if !(0..127).contains(&y) {
                            return Err("shift out of range".into());
                        }
                        x << y
                    }
                    ">>" | ">>>" => {
                        if y < 0 {
                            return Err("shift out of range".into());
                        }
                        x >> y.min(127)
                    }
                    "&" => x & y,
                    "|" => x | y,
                    "^" => x ^ y,
                    "==" | "===" => (x == y) as i128,
                    "!=" | "!==" => (x != y) as i128,
                    "<" => (x < y) as i128,
                    "<=" => (x <= y) as i128,
                    ">" => (x > y) as i128,
                    ">=" => (x >= y) as i128,
                    "&&" => (x != 0 && y != 0) as i128,
                    "||" => (x != 0 || y != 0) as i128,
                    _ => return Err(format!("unsupported const op {}", op)),
                }
            }
            Expr::Cond(c, a, b) => {
                if self.ceval(c)? != 0 {
                    self.ceval(a)?
                } else {
                    self.ceval(b)?
                }
            }
            Expr::Call(f, args) => match f.as_str() {
                "$clog2" => {
                    let v = self.ceval(&args[0])?;
                    let mut r = 0;
                    while (1i128 << r) < v {
                        r += 1
                    }
                    r
                }
                "$max1" => self.ceval(&args[0])?.max(1),
                "$bits" => self.swidth_of_name(&args[0])? as i128,
                "$signed" | "$unsigned" => self.ceval(&args[0])?,
                "$size" | "$left" | "$right" | "$high" | "$low" | "$increment" | "$dimensions" => {
                    let dims = self.dims_of(&args[0])?;
                    if f == "$dimensions" {
                        return Ok(dims.len() as i128);
                    }
                    let k = match args.get(1) {
                        Some(x) => self.ceval(x)? as usize,
                        None => 1,
                    };
                    let (l, r) = *dims.get(k.wrapping_sub(1)).ok_or_else(|| format!("{}: dimension {} out of range", f, k))?;
                    (match f.as_str() {
                        "$size" => (l - r).abs() + 1,
                        "$left" => l,
                        "$right" => r,
                        "$high" => l.max(r),
                        "$low" => l.min(r),
                        _ => if l >= r { 1 } else { -1 },
                    }) as i128
                }
                _ => return Err(format!("function {} not constant", f)),
            },
            Expr::Index(b, i) if !self.mentions_sig(b) => {
                let v = self.ceval(b)?;
                let k = self.ceval(i)?;
                if !(0..127).contains(&k) {
                    return Err("constant bit-select out of range".into());
                }
                (v >> k) & 1
            }
            Expr::Range(b, l, r) if !self.mentions_sig(b) => {
                let v = self.ceval(b)?;
                let (l, r) = (self.ceval(l)?, self.ceval(r)?);
                let (lo, hi) = (l.min(r), l.max(r));
                if lo < 0 || hi > 126 {
                    return Err("constant part-select out of range".into());
                }
                (v >> lo) & ((1i128 << (hi - lo + 1)) - 1)
            }
            Expr::Concat(v) if v.len() == 1 => self.ceval(&v[0])?,
            _ => return Err("not a constant expression".into()),
        })
    }
    /// dimensions of an array / vector name (for $size, $left, ...) or a type name
    fn dims_of(&mut self, e: &Expr) -> ER<Vec<(i64, i64)>> {
        if let Expr::Id(n) = e {
            if self.lookup_sig(n).is_none() {
                if let Some(t) = self.lookup_type(n) {
                    return Ok(if t.dims.is_empty() { vec![(t.width as i64 - 1, 0)] } else { t.dims });
                }
            }
        }
        if let Some(sh) = self.shape(e)? {
            return Ok(sh.dims);
        }
        let w = self.swidth(e)?;
        Ok(vec![(w as i64 - 1, 0)])
    }
    fn swidth_of_name(&mut self, e: &Expr) -> ER<usize> {
        if let Expr::Id(n) = e {
            if let Some(t) = self.lookup_type(n) {
                if self.lookup_sig(n).is_none() && self.lookup_param(n).is_none() {
                    return Ok(if t.dims.is_empty() { t.width.max(1) } else { t.dims.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product() });
                }
            }
        }
        self.swidth(e)
    }

    // ------------------------------------------------------------ name resolution
    /// hierarchical name of a reference path (g[1].x, u.y) with constant indices
    fn hier_path(&mut self, e: &Expr) -> Option<String> {
        match e {
            Expr::Id(n) => Some(n.clone()),
            Expr::Index(b, i) => {
                let p = self.hier_path(b)?;
                let v = self.ceval(i).ok()?;
                Some(format!("{}[{}]", p, v))
            }
            Expr::Member(b, m) => Some(format!("{}.{}", self.hier_path(b)?, m)),
            _ => None,
        }
    }
    fn root_name(e: &Expr) -> Option<&str> {
        match e {
            Expr::Id(n) => Some(n),
            Expr::Index(b, _) | Expr::Member(b, _) | Expr::Range(b, _, _) | Expr::PlusRange(b, _, _, _) => Self::root_name(b),
            _ => None,
        }
    }
    /// resolve `path` (relative to the current module and generate scope, innermost first)
    fn hier_lookup(&self, path: &str) -> Option<Sig> {
        let pre = self.prefix.replace('/', ".");
        let mut g = self.gpath.clone();
        loop {
            if let Some(s) = self.hier.get(&format!("{}{}{}", pre, g, path)) {
                return Some(s.clone());
            }
            if g.is_empty() {
                return None;
            }
            // drop the innermost generate scope component
            let t = g.trim_end_matches('.');
            g = match t.rfind('.') {
                Some(k) => t[..k + 1].to_string(),
                None => String::new(),
            };
        }
    }
    fn hier_param_lookup(&self, path: &str) -> Option<(i128, usize, bool)> {
        let pre = self.prefix.replace('/', ".");
        let mut g = self.gpath.clone();
        loop {
            if let Some(x) = self.hier_params.get(&format!("{}{}{}", pre, g, path)) {
                return Some(*x);
            }
            if g.is_empty() {
                return None;
            }
            let t = g.trim_end_matches('.');
            g = match t.rfind('.') {
                Some(k) => t[..k + 1].to_string(),
                None => String::new(),
            };
        }
    }
    /// element / slice / member of a signal-shaped value (bits are nets or values)
    fn sel_index(&mut self, bs: &Sig, iv: i64, nm: &str) -> ER<Sig> {
        if bs.dims.is_empty() {
            if iv == 0 {
                return Ok(Sig { name: bs.name.clone(), bits: bs.bits.clone(), dims: vec![], signed: false, ty: None, udims: 0 });
            }
            return Err(format!("bit-select [{}] of scalar '{}'", iv, nm));
        }
        let ew: usize = bs.dims[1..].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product();
        let signed = bs.udims > 0 && bs.signed;
        let ty = if bs.dims.len() >= 2 { bs.ty.clone() } else { None };
        let udims = bs.udims.saturating_sub(1);
        match dim_off(bs.dims[0], iv) {
            Some(o) => Ok(Sig { name: format!("{}[{}]", bs.name, iv), bits: bs.bits[o * ew..(o + 1) * ew].to_vec(), dims: bs.dims[1..].to_vec(), signed, ty, udims }),
            None => {
                crate::warn!("ELAB-147", "{}: index {} out of range for '{}'", self.cur_file, iv, nm);
                Ok(Sig { name: String::new(), bits: vec![self.c0; ew], dims: bs.dims[1..].to_vec(), signed, ty, udims })
            }
        }
    }
    fn sel_range(&mut self, bs: &Sig, l: i128, r: i128, nm: &str) -> ER<Sig> {
        if bs.dims.is_empty() {
            if l == 0 && r == 0 {
                return Ok(Sig { name: String::new(), bits: bs.bits.clone(), dims: vec![(0, 0)], signed: false, ty: None, udims: 0 });
            }
            return Err(format!("part-select of scalar '{}'", nm));
        }
        let ew: usize = bs.dims[1..].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product();
        let (o1, o2) = (dim_off(bs.dims[0], l as i64), dim_off(bs.dims[0], r as i64));
        let (Some(o1), Some(o2)) = (o1, o2) else { return Err(format!("part-select {}[{}:{}] out of range", nm, l, r)) };
        let d0 = bs.dims[0];
        if l != r && d0.0 != d0.1 && ((l < r) != (d0.0 < d0.1)) {
            // reversed part-select, e.g. v[3:9] on a [15:0] vector: illegal in IEEE 1364 / 1800;
            // read as the same bits in the declared order (v[9:3])
            let key = format!("{}:{}[{}:{}]", self.cur_file, nm, l, r);
            if self.warned.insert(key) {
                crate::warn!("ELAB-148", "{}: reversed part-select {}[{}:{}] on a [{}:{}] vector (illegal in IEEE 1364/1800); synthesized as {}[{}:{}]", self.cur_file, nm, l, r, d0.0, d0.1, nm, r, l);
            }
        }
        let (lo, hi) = (o1.min(o2), o1.max(o2));
        let mut d = vec![((hi - lo) as i64, 0)];
        d.extend(bs.dims[1..].iter().copied());
        let ty = if bs.dims.len() >= 2 { bs.ty.clone() } else { None };
        Ok(Sig { name: String::new(), bits: bs.bits[lo * ew..(hi + 1) * ew].to_vec(), dims: d, signed: false, ty, udims: bs.udims })
    }
    fn sel_member(&mut self, bs: &Sig, m: &str) -> ER<Sig> {
        let tn = bs.ty.clone().ok_or_else(|| format!("member access '.{}' on non-struct '{}'", m, bs.name))?;
        if bs.dims.len() > 1 {
            return Err(format!("member access '.{}' on an array of structs (select an element first)", m));
        }
        let ti = self.lookup_type(&tn).ok_or("unknown struct type")?;
        let f = ti.fields.iter().find(|f| f.name == m).cloned().ok_or_else(|| format!("struct has no member '{}'", m))?;
        Ok(Sig { name: format!("{}.{}", bs.name, m), bits: bs.bits[f.off..f.off + f.width].to_vec(), dims: f.dims.clone(), signed: f.signed, ty: f.ty.clone(), udims: 0 })
    }
    /// interface member or hierarchical reference for a Member expression whose root is not a signal
    fn member_special(&mut self, b: &Expr, m: &str) -> ER<Option<Sig>> {
        let (ifn, idx) = match b {
            Expr::Id(n) => (Some(n.clone()), None),
            Expr::Index(x, i) => match &**x {
                Expr::Id(n) => (Some(n.clone()), Some(i.clone())),
                _ => (None, None),
            },
            _ => (None, None),
        };
        if let Some(ifn) = ifn {
            if let Some(ii) = self.lookup_iface(&ifn) {
                let k = match idx {
                    Some(i) => (self.ceval(&i)? as i64 - ii.lo) as usize,
                    None => 0,
                };
                let el = ii.elems.get(k).ok_or_else(|| format!("interface array index out of range on {}", ifn))?;
                return el.get(m).cloned().map(Some).ok_or_else(|| format!("interface '{}' has no member '{}'", ii.def, m));
            }
        }
        let root = Self::root_name(b).unwrap_or("").to_string();
        if !root.is_empty() && self.lookup_sig(&root).is_none() && self.lookup_iface(&root).is_none() && self.lookup_param(&root).is_none() {
            if let Some(p) = self.hier_path(b) {
                let path = format!("{}.{}", p, m);
                if let Some(s) = self.hier_lookup(&path) {
                    return Ok(Some(s));
                }
                // parameter of a generate scope: a constant
                if let Some((v, w, sg)) = self.hier_param_lookup(&path) {
                    let bits = self.cbits(v, w);
                    let n = w as i64;
                    return Ok(Some(Sig { name: path.clone(), bits, dims: if w > 1 { vec![(n - 1, 0)] } else { vec![] }, signed: sg, ty: None, udims: 0 }));
                }
                return Err(format!("{}: cannot resolve hierarchical reference '{}' (ELAB-HIER)", self.cur_file, path));
            }
        }
        Ok(None)
    }
    /// net-level signal for a name with constant selects (lvalues, ports)
    fn sig_of(&mut self, e: &Expr) -> ER<Option<Sig>> {
        match e {
            Expr::Id(n) => Ok(self.lookup_sig(n)),
            Expr::Member(b, m) => {
                if let Some(s) = self.member_special(b, m)? {
                    return Ok(Some(s));
                }
                let Some(bs) = self.sig_of(b)? else { return Ok(None) };
                Ok(Some(self.sel_member(&bs, m)?))
            }
            Expr::Index(b, i) => {
                let Some(bs) = self.sig_of(b)? else { return Ok(None) };
                let Ok(iv) = self.ceval(i) else { return Ok(None) };
                let nm = expr_name(b).unwrap_or_default();
                Ok(Some(self.sel_index(&bs, iv as i64, &nm)?))
            }
            Expr::Range(b, x, y) => {
                let Some(bs) = self.sig_of(b)? else { return Ok(None) };
                let (Ok(l), Ok(r)) = (self.ceval(x), self.ceval(y)) else { return Ok(None) };
                let nm = expr_name(b).unwrap_or_default();
                Ok(Some(self.sel_range(&bs, l, r, &nm)?))
            }
            Expr::PlusRange(b, s, w, up) => {
                let Some(bs) = self.sig_of(b)? else { return Ok(None) };
                let (Ok(sv), Ok(wv)) = (self.ceval(s), self.ceval(w)) else { return Ok(None) };
                let (l, r) = plus_bounds(&bs, sv, wv, *up);
                let nm = expr_name(b).unwrap_or_default();
                Ok(Some(self.sel_range(&bs, l, r, &nm)?))
            }
            _ => Ok(None),
        }
    }
    /// shape (dims, signedness, struct type, unpacked dims) of a select expression, also with
    /// variable indices; bits are left empty
    fn shape(&mut self, e: &Expr) -> ER<Option<Sig>> {
        let mk = |dims: Vec<(i64, i64)>, signed: bool, ty: Option<String>, udims: usize| Sig { name: String::new(), bits: vec![], dims, signed, ty, udims };
        Ok(match e {
            Expr::Id(n) => self.lookup_sig(n).map(|s| Sig { bits: vec![], ..s }),
            Expr::Index(b, _) => {
                let Some(sb) = self.shape(b)? else { return Ok(None) };
                if sb.dims.is_empty() {
                    return Ok(Some(mk(vec![], false, None, 0)));
                }
                Some(mk(sb.dims[1..].to_vec(), sb.udims > 0 && sb.signed, if sb.dims.len() >= 2 { sb.ty.clone() } else { None }, sb.udims.saturating_sub(1)))
            }
            Expr::Range(b, l, r) => {
                let Some(sb) = self.shape(b)? else { return Ok(None) };
                let w = (self.ceval(l)? - self.ceval(r)?).unsigned_abs() as i64;
                let mut d = vec![(w, 0)];
                d.extend(sb.dims.iter().skip(1).copied());
                Some(mk(d, false, if sb.dims.len() >= 2 { sb.ty.clone() } else { None }, sb.udims))
            }
            Expr::PlusRange(b, _, w, _) => {
                let Some(sb) = self.shape(b)? else { return Ok(None) };
                let w = self.ceval(w)? as i64;
                let mut d = vec![(w - 1, 0)];
                d.extend(sb.dims.iter().skip(1).copied());
                Some(mk(d, false, if sb.dims.len() >= 2 { sb.ty.clone() } else { None }, sb.udims))
            }
            Expr::Member(b, m) => {
                if let Some(s) = self.member_special(b, m)? {
                    return Ok(Some(Sig { bits: vec![], ..s }));
                }
                let Some(sb) = self.shape(b)? else { return Ok(None) };
                let Some(tn) = sb.ty.clone() else { return Ok(None) };
                let Some(ti) = self.lookup_type(&tn) else { return Ok(None) };
                let Some(f) = ti.fields.iter().find(|f| f.name == *m).cloned() else { return Ok(None) };
                Some(mk(f.dims.clone(), f.signed, f.ty.clone(), 0))
            }
            _ => None,
        })
    }
    /// value of a non-signal expression as a vector (parameter, loop variable) for selects
    fn value_sig(&mut self, b: &Expr) -> ER<Sig> {
        let (v, _) = self.ev(b, 0)?;
        let n = v.len().max(1) as i64;
        Ok(Sig { name: expr_name(b).unwrap_or_default(), bits: v, dims: vec![(n - 1, 0)], signed: false, ty: None, udims: 0 })
    }
    /// value-level select: constant or variable indices at any depth
    fn rsel(&mut self, e: &Expr) -> ER<Option<Sig>> {
        if let Some(s) = self.sig_of(e)? {
            let bits = s.bits.iter().map(|x| self.read(*x)).collect();
            return Ok(Some(Sig { bits, ..s }));
        }
        let base = |cx: &mut Self, b: &Expr| -> ER<Option<Sig>> {
            match cx.rsel(b)? {
                Some(s) => Ok(Some(s)),
                None => {
                    if matches!(b, Expr::Id(_)) || cx.ceval(b).is_ok() {
                        Ok(Some(cx.value_sig(b)?))
                    } else {
                        Ok(None)
                    }
                }
            }
        };
        match e {
            Expr::Index(b, i) => {
                let Some(bs) = base(self, b)? else { return Ok(None) };
                let nm = expr_name(b).unwrap_or_default();
                if let Ok(iv) = self.ceval(i) {
                    return Ok(Some(self.sel_index(&bs, iv as i64, &nm)?));
                }
                let bs = if bs.dims.is_empty() { Sig { dims: vec![(0, 0)], ..bs } } else { bs };
                let d0 = bs.dims[0];
                let ew: usize = bs.dims[1..].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product();
                let (lo, hi) = (d0.0.min(d0.1), d0.0.max(d0.1));
                let mut el: BTreeMap<i64, Vec<NetId>> = BTreeMap::new();
                for idx in lo..=hi {
                    let o = dim_off(d0, idx).unwrap();
                    el.insert(idx, bs.bits[o * ew..(o + 1) * ew].to_vec());
                }
                let (iv, isg) = self.ev(i, 0)?;
                let bits = self.index_mux(&el, &iv, isg, ew);
                Ok(Some(Sig { name: String::new(), bits, dims: bs.dims[1..].to_vec(), signed: bs.udims > 0 && bs.signed, ty: if bs.dims.len() >= 2 { bs.ty.clone() } else { None }, udims: bs.udims.saturating_sub(1) }))
            }
            Expr::Range(b, x, y) => {
                let Some(bs) = base(self, b)? else { return Ok(None) };
                let (l, r) = (self.ceval(x)?, self.ceval(y)?);
                let nm = expr_name(b).unwrap_or_default();
                Ok(Some(self.sel_range(&bs, l, r, &nm)?))
            }
            Expr::PlusRange(b, st, wd, up) => {
                let Some(bs) = base(self, b)? else { return Ok(None) };
                let wv = self.ceval(wd)?;
                let nm = expr_name(b).unwrap_or_default();
                if let Ok(sv) = self.ceval(st) {
                    let (l, r) = plus_bounds(&bs, sv, wv, *up);
                    return Ok(Some(self.sel_range(&bs, l, r, &nm)?));
                }
                let wv = wv as usize;
                let dim = bs.dims.first().copied();
                let ew: usize = if bs.dims.len() > 1 { bs.dims[1..].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product() } else { 1 };
                // element offset of the selected right-hand element from the vector's right-hand element:
                //   [hi:lo]  v[s +: w] -> s - lo          v[s -: w] -> s - w + 1 - lo
                //   [lo:hi]  v[s +: w] -> hi - (s + w - 1)  v[s -: w] -> hi - s
                let mut sexpr = (**st).clone();
                match dim {
                    Some((l, r)) if l < r => {
                        if *up {
                            sexpr = Expr::bin("+", sexpr, Expr::int(wv as i64 - 1));
                        }
                        sexpr = Expr::bin("-", Expr::int(r), sexpr);
                    }
                    _ => {
                        let lsb = dim.map(|d| d.1).unwrap_or(0);
                        if !*up {
                            sexpr = Expr::bin("-", sexpr, Expr::int(wv as i64 - 1));
                        }
                        if lsb != 0 {
                            sexpr = Expr::bin("-", sexpr, Expr::int(lsb));
                        }
                    }
                }
                // pad w-1 zero elements below the vector, so a slice that starts below the right-hand
                // element (partly out of range) keeps its in-range bits instead of a negative shift
                let mut sexpr = Expr::bin("+", sexpr, Expr::int(wv as i64 - 1));
                if ew > 1 {
                    sexpr = Expr::bin("*", sexpr, Expr::int(ew as i64));
                }
                let (amt, _) = self.ev(&sexpr, 0)?;
                let mut pv = vec![self.c0; wv.saturating_sub(1) * ew];
                pv.extend(bs.bits.iter().copied());
                let r = self.shift(&pv, &amt, false, false);
                let n = (wv * ew).min(r.len());
                let mut d = vec![(wv as i64 - 1, 0)];
                d.extend(bs.dims.iter().skip(1).copied());
                Ok(Some(Sig { name: String::new(), bits: r[..n].to_vec(), dims: d, signed: false, ty: if bs.dims.len() >= 2 { bs.ty.clone() } else { None }, udims: bs.udims }))
            }
            Expr::Member(b, m) => {
                if let Some(s) = self.member_special(b, m)? {
                    let bits = s.bits.iter().map(|x| self.read(*x)).collect();
                    return Ok(Some(Sig { bits, ..s }));
                }
                let Some(bs) = self.rsel(b)? else { return Ok(None) };
                Ok(Some(self.sel_member(&bs, m)?))
            }
            _ => Ok(None),
        }
    }

    /// self-determined signedness (IEEE 1800 11.8.1)
    fn ssigned(&mut self, e: &Expr) -> ER<bool> {
        Ok(match e {
            Expr::Num { signed, .. } => *signed,
            Expr::Id(n) => {
                if self.lookup_param(n).is_some() {
                    self.lookup_pinfo(n).1
                } else {
                    self.lookup_sig(n).map(|s| s.signed && s.udims == 0).unwrap_or(false)
                }
            }
            Expr::Scoped(_, n) => self.pkg.pinfo.get(n).map(|x| x.1).unwrap_or(true),
            Expr::Index(..) | Expr::Range(..) | Expr::PlusRange(..) | Expr::Member(..) => match self.shape(e)? {
                Some(s) => s.signed && s.udims == 0,
                None => false,
            },
            Expr::Un(op, a) => matches!(op.as_str(), "~" | "-" | "+") && self.ssigned(a)?,
            Expr::Bin(op, a, b) => match op.as_str() {
                "+" | "-" | "*" | "/" | "%" | "&" | "|" | "^" | "~^" | "^~" | "~&" | "~|" => self.ssigned(a)? && self.ssigned(b)?,
                "<<" | ">>" | "<<<" | ">>>" | "**" => self.ssigned(a)?,
                _ => false,
            },
            Expr::Cond(_, a, b) => self.ssigned(a)? && self.ssigned(b)?,
            Expr::Call(f, args) => match f.as_str() {
                "$signed" => true,
                "$unsigned" => false,
                "$clog2" | "$bits" | "$size" | "$countones" | "$left" | "$right" | "$high" | "$low" | "$increment" | "$dimensions" => true,
                "$onehot" | "$onehot0" | "$isunknown" => false,
                _ => match self.lookup_func(f).or_else(|| self.method_decl(f)) {
                    Some(fd) => self.type_info(&fd.ret)?.1,
                    None => {
                        let _ = args;
                        false
                    }
                },
            },
            Expr::Cast(t, x) => match &**t {
                Expr::Id(n) if n == "signed" => true,
                Expr::Id(n) if n == "unsigned" => false,
                Expr::Id(n) if self.lookup_type(n).is_some() && self.lookup_param(n).is_none() && self.lookup_sig(n).is_none() => self.lookup_type(n).map(|t| t.signed).unwrap_or(false),
                _ => self.ssigned(x)?,
            },
            _ => false,
        })
    }

    fn swidth(&mut self, e: &Expr) -> ER<usize> {
        Ok(match e {
            Expr::Num { width, bits, fill, .. } => {
                if *fill {
                    1
                } else {
                    width.map(|w| w as usize).unwrap_or(bits.len().max(32))
                }
            }
            Expr::Str(s) => (s.len() * 8).max(8),
            Expr::Id(n) => {
                if self.lookup_param(n).is_some() {
                    self.lookup_pinfo(n).0
                } else if let Some(s) = self.lookup_sig(n) {
                    s.width()
                } else {
                    1
                }
            }
            Expr::Scoped(_, n) => self.pkg.pinfo.get(n).map(|x| x.0).unwrap_or(32),
            Expr::Index(..) | Expr::Range(..) | Expr::PlusRange(..) | Expr::Member(..) => match self.shape(e)? {
                Some(s) => s.dims.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1),
                None => match e {
                    Expr::Range(_, a, b) => ((self.ceval(a)? - self.ceval(b)?).unsigned_abs() + 1) as usize,
                    Expr::PlusRange(_, _, w, _) => self.ceval(w)? as usize,
                    _ => 1,
                },
            },
            Expr::Un(op, a) => match op.as_str() {
                "~" | "-" | "+" => self.swidth(a)?,
                _ => 1,
            },
            Expr::Bin(op, a, b) => match op.as_str() {
                "==" | "!=" | "===" | "!==" | "<" | "<=" | ">" | ">=" | "&&" | "||" | "==?" | "!=?" | "->" | "<->" => 1,
                "<<" | ">>" | "<<<" | ">>>" | "**" => self.swidth(a)?,
                _ => self.swidth(a)?.max(self.swidth(b)?),
            },
            Expr::Cond(_, a, b) => self.swidth(a)?.max(self.swidth(b)?),
            Expr::Concat(v) | Expr::Stream(_, _, v) => {
                let mut s = 0;
                for x in v {
                    s += self.swidth(x)?
                }
                s
            }
            Expr::Repl(n, v) => {
                let k = self.ceval(n)? as usize;
                let mut s = 0;
                for x in v {
                    s += self.swidth(x)?
                }
                s * k
            }
            Expr::Call(f, args) => match f.as_str() {
                "$signed" | "$unsigned" => self.swidth(&args[0])?,
                "$onehot" | "$onehot0" | "$isunknown" => 1,
                "$clog2" | "$bits" | "$size" | "$countones" | "$left" | "$right" | "$high" | "$low" | "$increment" | "$dimensions" => 32,
                _ => {
                    if let Some(fd) = self.lookup_func(f).or_else(|| self.method_decl(f)) {
                        let (d, _, _) = self.type_info(&fd.ret)?;
                        d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1)
                    } else {
                        1
                    }
                }
            },
            Expr::Cast(w, x) => match &**w {
                Expr::Id(t) if t == "signed" || t == "unsigned" => self.swidth(x)?,
                Expr::Id(t) if self.lookup_type(t).is_some() && self.lookup_param(t).is_none() && self.lookup_sig(t).is_none() => self.swidth_of_name(w)?,
                _ => self.ceval(w).map(|v| v as usize).or_else(|_| self.swidth(x))?,
            },
            Expr::Pattern(parts, _) => match &self.tgt {
                Some(t) => t.dims.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1),
                None => {
                    let mut s = 0;
                    for (_, x) in parts {
                        s += self.swidth(x)?
                    }
                    s.max(1)
                }
            },
            Expr::Inside(..) => 1,
            Expr::Fill(_) => 1,
        })
    }

    fn read(&mut self, n: NetId) -> NetId {
        if let Some(ps) = self.procs.last() {
            if ps.blocking.contains(&n) {
                if let Some(&(v, e)) = ps.vals.get(&n) {
                    if e == self.c1 {
                        return v;
                    }
                    return self.mux(e, n, v);
                }
            }
        }
        n
    }

    // ------------------------------------------------------------ expression eval
    /// Evaluate in a context of at least `cw` bits: the result has max(cw, self width) bits and
    /// the expression's own signedness; context-determined operands are extended according to
    /// the type of the whole expression (IEEE 1800 11.6 / 11.8).
    fn ev(&mut self, e: &Expr, cw: usize) -> ER<(Vec<NetId>, bool)> {
        let sw = self.swidth(e)?;
        let w = cw.max(sw).max(1);
        let s = self.ssigned(e)?;
        Ok((self.ev_t(e, w, s)?, s))
    }
    fn evw(&mut self, e: &Expr, w: usize) -> ER<Vec<NetId>> {
        let (b, s) = self.ev(e, w)?;
        Ok(self.ext(b, w, s))
    }
    /// evaluate an expression with target shape `t` (assignment patterns are typed by it)
    fn ev_to(&mut self, e: &Expr, t: &Sig, w: usize) -> ER<Vec<NetId>> {
        if matches!(e, Expr::Pattern(..)) {
            return self.ev_pattern(e, t);
        }
        self.evw(e, w)
    }
    /// evaluate `e` in context width `w` and context signedness `s` (exactly w bits)
    fn ev_t(&mut self, e: &Expr, w: usize, s: bool) -> ER<Vec<NetId>> {
        match e {
            Expr::Un(op, a) if matches!(op.as_str(), "~" | "-" | "+") => {
                let v = self.ev_t(a, w, s)?;
                Ok(match op.as_str() {
                    "~" => v.iter().map(|x| self.not(*x)).collect(),
                    "-" => {
                        let z = vec![self.c0; v.len()];
                        self.sub(&z, &v).0
                    }
                    _ => v,
                })
            }
            Expr::Bin(op, a, b) if matches!(op.as_str(), "+" | "-" | "*" | "/" | "%" | "&" | "|" | "^" | "~^" | "^~" | "~&" | "~|") => {
                let x = self.ev_t(a, w, s)?;
                let y = self.ev_t(b, w, s)?;
                Ok(match op.as_str() {
                    "&" => (0..w).map(|k| self.and(x[k], y[k])).collect(),
                    "|" => (0..w).map(|k| self.or(x[k], y[k])).collect(),
                    "^" => (0..w).map(|k| self.xor(x[k], y[k])).collect(),
                    "~^" | "^~" => (0..w).map(|k| {
                        let t = self.xor(x[k], y[k]);
                        self.not(t)
                    }).collect(),
                    "~&" => (0..w).map(|k| {
                        let t = self.and(x[k], y[k]);
                        self.not(t)
                    }).collect(),
                    "~|" => (0..w).map(|k| {
                        let t = self.or(x[k], y[k]);
                        self.not(t)
                    }).collect(),
                    "+" => {
                        let c0 = self.c0;
                        self.add(&x, &y, c0).0
                    }
                    "-" => self.sub(&x, &y).0,
                    "*" => self.mul(&x, &y, w),
                    _ => self.divide(op, &x, &y, b, s, w)?,
                })
            }
            Expr::Bin(op, a, b) if matches!(op.as_str(), "<<" | ">>" | "<<<" | ">>>") => {
                let x = self.ev_t(a, w, s)?;
                // arithmetic right shift only when the expression type is signed
                let arith = op == ">>>" && s;
                if !self.mentions_sig(b) {
                    if let Ok(k) = self.ceval(b) {
                        let k = if k < 0 || k > w as i128 { w } else { k as usize };
                        let fill = if arith { *x.last().unwrap() } else { self.c0 };
                        let r: Vec<NetId> = (0..w)
                            .map(|i| if op.starts_with('<') { if i >= k { x[i - k] } else { self.c0 } } else if i + k < w { x[i + k] } else { fill })
                            .collect();
                        return Ok(r);
                    }
                }
                // the shift amount is self-determined and always unsigned
                let (amt, _) = self.ev(b, 0)?;
                Ok(self.shift(&x, &amt, op.starts_with('<'), arith))
            }
            Expr::Bin(op, a, b) if op == "**" => {
                let x = self.ev_t(a, w, s)?;
                self.power(&x, s, b)
            }
            Expr::Cond(c, a, b) => {
                let (cv, _) = self.ev(c, 0)?;
                let cb = self.to_bool(&cv);
                if cb == self.c1 {
                    return self.ev_t(a, w, s);
                }
                if cb == self.c0 {
                    return self.ev_t(b, w, s);
                }
                let av = self.ev_t(a, w, s)?;
                let bv = self.ev_t(b, w, s)?;
                Ok((0..w).map(|k| self.mux(cb, bv[k], av[k])).collect())
            }
            Expr::Stream(..) => {
                // a stream narrower than its target is left-justified (IEEE 1800 11.4.14)
                let (v, _) = self.ev_raw(e, w)?;
                if v.len() >= w {
                    return Ok(v[v.len() - w..].to_vec());
                }
                let mut o = vec![self.c0; w - v.len()];
                o.extend(v);
                Ok(o)
            }
            _ => {
                let (bits, _) = self.ev_raw(e, w)?;
                Ok(self.ext(bits, w, s))
            }
        }
    }
    /// x / y and x % y in w bits, signed when the expression type is signed
    fn divide(&mut self, op: &str, x: &[NetId], y: &[NetId], b: &Expr, s: bool, w: usize) -> ER<Vec<NetId>> {
        if !s && !self.mentions_sig(b) {
            if let Ok(d) = self.ceval(b) {
                if d > 0 && (d & (d - 1)) == 0 {
                    let k = d.trailing_zeros() as usize;
                    return Ok(if op == "/" { (0..w).map(|i| if i + k < w { x[i + k] } else { self.c0 }).collect() } else { (0..w).map(|i| if i < k { x[i] } else { self.c0 }).collect() });
                }
            }
        }
        if self.mentions_sig(b) {
            crate::info!("ELAB-420", "Building array divider for '{}' operator ({} bits{})", op, w, if s { ", signed" } else { "" });
        }
        if !s {
            let (q, r) = self.divmod(x, y);
            return Ok(if op == "/" { q } else { r });
        }
        // signed: divide magnitudes; quotient truncates toward zero, remainder takes the sign of the dividend
        let (sx, sy) = (x[w - 1], y[w - 1]);
        let z = vec![self.c0; w];
        let nx = self.sub(&z, x).0;
        let ny = self.sub(&z, y).0;
        let ax: Vec<NetId> = (0..w).map(|k| self.mux(sx, x[k], nx[k])).collect();
        let ay: Vec<NetId> = (0..w).map(|k| self.mux(sy, y[k], ny[k])).collect();
        let (q, r) = self.divmod(&ax, &ay);
        if op == "/" {
            let neg = self.xor(sx, sy);
            let nq = self.sub(&z, &q).0;
            Ok((0..w).map(|k| self.mux(neg, q[k], nq[k])).collect())
        } else {
            let nr = self.sub(&z, &r).0;
            Ok((0..w).map(|k| self.mux(sx, r[k], nr[k])).collect())
        }
    }
    /// x ** b with x already in context width (IEEE 1800 11.4.3, table 11-4)
    fn power(&mut self, x: &[NetId], s: bool, b: &Expr) -> ER<Vec<NetId>> {
        let w = x.len();
        let one = self.cbits(1, w);
        let (bv, bsg) = if !self.mentions_sig(b) {
            match self.ceval(b) {
                Ok(k) => {
                    let bw = self.swidth(b)?.max(1);
                    let bs = self.ssigned(b)?;
                    (self.cbits(k, bw), bs)
                }
                Err(_) => self.ev(b, 0)?,
            }
        } else {
            self.ev(b, 0)?
        };
        let nb = bv.len();
        let mag_bits = if bsg { nb - 1 } else { nb };
        let last_set = (0..mag_bits).rev().find(|k| bv[*k] != self.c0);
        if mag_bits > 6 && last_set.map(|k| k > 6).unwrap_or(false) && bv[..mag_bits].iter().any(|x| *x != self.c0 && *x != self.c1) {
            crate::info!("ELAB-421", "Building {}-bit power operator with a {}-bit variable exponent", w, nb);
        }
        let mut res = one.clone();
        let mut base = x.to_vec();
        if let Some(hi) = last_set {
            for j in 0..=hi {
                if bv[j] != self.c0 {
                    let m = self.mul(&res, &base, w);
                    res = (0..w).map(|k| self.mux(bv[j], res[k], m[k])).collect();
                }
                if j < hi {
                    base = self.mul(&base, &base, w);
                }
            }
        }
        if bsg && bv[nb - 1] != self.c0 {
            // negative exponent: 1 ** n = 1, (-1) ** n = +-1, otherwise 0 (0 ** -n is x)
            let neg = bv[nb - 1];
            let is1 = self.eq(x, &one);
            let mut nr = (0..w).map(|k| if k == 0 { is1 } else { self.c0 }).collect::<Vec<_>>();
            if s {
                let m1 = vec![self.c1; w];
                let ism1 = self.eq(x, &m1);
                let odd = bv[0];
                // -1: odd -> all ones, even -> 1
                let ones = self.and(ism1, odd);
                let lsb = self.or(is1, ism1);
                nr = (0..w).map(|k| if k == 0 { lsb } else { ones }).collect();
            }
            res = (0..w).map(|k| self.mux(neg, res[k], nr[k])).collect();
        }
        Ok(res)
    }
    fn ev_raw(&mut self, e: &Expr, w: usize) -> ER<(Vec<NetId>, bool)> {
        match e {
            Expr::Num { bits, signed, fill, .. } => {
                if *fill {
                    let b = if bits[0] == 1 { self.c1 } else { self.c0 };
                    return Ok((vec![b; w], false));
                }
                let v: Vec<NetId> = bits.iter().map(|b| if *b == 1 { self.c1 } else { self.c0 }).collect();
                Ok((v, *signed))
            }
            Expr::Str(s) => {
                let mut v = vec![];
                for ch in s.bytes().rev() {
                    for k in 0..8 {
                        v.push(if (ch >> k) & 1 == 1 { self.c1 } else { self.c0 });
                    }
                }
                if v.is_empty() {
                    v = vec![self.c0; 8];
                }
                Ok((v, false))
            }
            Expr::Id(n) => {
                if let Some(p) = self.lookup_param(n) {
                    let (pw, ps) = self.lookup_pinfo(n);
                    if let Some(b) = self.lookup_pbits(n) {
                        return Ok((b, ps));
                    }
                    return Ok((self.cbits(p, pw), ps));
                }
                match self.lookup_sig(n) {
                    Some(s) => Ok((s.bits.iter().map(|b| self.read(*b)).collect(), s.signed && s.udims == 0)),
                    None => {
                        if self.lookup_iface(n).is_some() {
                            return Err(format!("interface '{}' used in expression", n));
                        }
                        Err(format!("{}: undeclared identifier '{}' (ELAB-337)", self.cur_file, n))
                    }
                }
            }
            Expr::Scoped(_, n) => {
                let p = self.pkg.params.get(n).copied().ok_or_else(|| format!("unknown package item {}", n))?;
                let (pw, ps) = self.pkg.pinfo.get(n).copied().unwrap_or((32, true));
                Ok((self.cbits(p, pw), ps))
            }
            Expr::Index(..) | Expr::Range(..) | Expr::PlusRange(..) | Expr::Member(..) => {
                let s = self.rsel(e)?.ok_or_else(|| "unsupported select expression".to_string())?;
                let sg = s.signed && s.udims == 0;
                Ok((s.bits, sg))
            }
            Expr::Un(op, a) => match op.as_str() {
                "~" | "-" | "+" => {
                    let s = self.ssigned(e)?;
                    let sw = self.swidth(e)?.max(w);
                    Ok((self.ev_t(e, sw, s)?, s))
                }
                "!" => {
                    let (v, _) = self.ev(a, 0)?;
                    let b = self.to_bool(&v);
                    Ok((vec![self.not(b)], false))
                }
                _ => {
                    let (v, _) = self.ev(a, 0)?;
                    let r = match op.as_str() {
                        "&" => self.reduce(GOp::And, &v),
                        "|" => self.reduce(GOp::Or, &v),
                        "^" => self.reduce(GOp::Xor, &v),
                        "~&" => {
                            let x = self.reduce(GOp::And, &v);
                            self.not(x)
                        }
                        "~|" => {
                            let x = self.reduce(GOp::Or, &v);
                            self.not(x)
                        }
                        _ => {
                            let x = self.reduce(GOp::Xor, &v);
                            self.not(x)
                        }
                    };
                    Ok((vec![r], false))
                }
            },
            Expr::Bin(op, a, b) => match op.as_str() {
                "&&" | "||" | "==" | "!=" | "===" | "!==" | "<" | "<=" | ">" | ">=" | "==?" | "!=?" | "->" | "<->" => self.ev_bin(op, a, b),
                _ => {
                    let s = self.ssigned(e)?;
                    let sw = self.swidth(e)?.max(w);
                    Ok((self.ev_t(e, sw, s)?, s))
                }
            },
            Expr::Cond(..) => {
                let s = self.ssigned(e)?;
                let sw = self.swidth(e)?.max(w);
                Ok((self.ev_t(e, sw, s)?, s))
            }
            Expr::Concat(v) => {
                let mut out = vec![];
                for x in v.iter().rev() {
                    let sw = self.swidth(x)?;
                    out.extend(self.evw(x, sw)?);
                }
                Ok((out, false))
            }
            Expr::Repl(n, v) => {
                let k = self.ceval(n)?;
                if k < 0 {
                    return Err("negative replication count".into());
                }
                let one = self.ev_raw(&Expr::Concat(v.clone()), 0)?.0;
                let mut out = vec![];
                for _ in 0..k {
                    out.extend(one.iter().copied())
                }
                Ok((out, false))
            }
            Expr::Stream(left, slice, v) => {
                let (bits, _) = self.ev_raw(&Expr::Concat(v.clone()), 0)?;
                if !*left {
                    return Ok((bits, false));
                }
                let k = match slice {
                    Some(x) => self.ceval(x)?.max(1) as usize,
                    None => 1,
                };
                // slices are taken from the right-hand end; their order is reversed
                let chunks: Vec<Vec<NetId>> = bits.chunks(k).map(|c| c.to_vec()).collect();
                let mut out = vec![];
                for c in chunks.iter().rev() {
                    out.extend(c.iter().copied());
                }
                Ok((out, false))
            }
            Expr::Inside(x, set) => {
                let mut r = self.c0;
                for it in set {
                    let t = if let Expr::Range(b, lo, hi) = it {
                        if matches!(&**b, Expr::Id(n) if n == "$range") {
                            let ge = Expr::bin(">=", (**x).clone(), (**lo).clone());
                            let le = Expr::bin("<=", (**x).clone(), (**hi).clone());
                            let (g, _) = self.ev(&ge, 1)?;
                            let (l, _) = self.ev(&le, 1)?;
                            self.and(g[0], l[0])
                        } else {
                            self.ev(&Expr::bin("==?", (**x).clone(), it.clone()), 1)?.0[0]
                        }
                    } else {
                        // set members compare with wildcard equality: x / z / ? bits of a member are don't care
                        self.ev(&Expr::bin("==?", (**x).clone(), it.clone()), 1)?.0[0]
                    };
                    r = self.or(r, t);
                }
                Ok((vec![r], false))
            }
            Expr::Fill(x) => {
                let (v, _) = self.ev(x, 1)?;
                if v.len() == 1 || w % v.len() != 0 {
                    Ok((vec![v[0]; w], false))
                } else {
                    let mut o = vec![];
                    while o.len() < w {
                        o.extend(v.iter().copied())
                    }
                    Ok((o, false))
                }
            }
            Expr::Pattern(parts, fill) => {
                if let Some(t) = self.tgt.clone() {
                    return Ok((self.ev_pattern(e, &t)?, false));
                }
                if parts.is_empty() {
                    if let Some(f) = fill {
                        return self.ev_raw(&Expr::Fill(f.clone()), w);
                    }
                }
                if parts.iter().any(|(k, _)| k.is_some()) || fill.is_some() {
                    return Err(format!("{}: assignment pattern with member / index keys needs a typed target (use type'{{..}})", self.cur_file));
                }
                let v: Vec<Expr> = parts.iter().map(|(_, x)| x.clone()).collect();
                self.ev_raw(&Expr::Concat(v), w)
            }
            Expr::Cast(t, x) => {
                let tyname = match &**t {
                    Expr::Id(n) if n == "signed" => {
                        let (v, _) = self.ev(x, 0)?;
                        return Ok((v, true));
                    }
                    Expr::Id(n) if n == "unsigned" => {
                        let (v, _) = self.ev(x, 0)?;
                        return Ok((v, false));
                    }
                    Expr::Id(n) if self.lookup_type(n).is_some() && self.lookup_param(n).is_none() && self.lookup_sig(n).is_none() => Some(n.clone()),
                    _ => None,
                };
                let (tw, tsg) = match &tyname {
                    Some(n) => (self.swidth_of_name(t)?, self.lookup_type(n).map(|t| t.signed).unwrap_or(false)),
                    None => (self.ceval(t)? as usize, self.ssigned(x)?),
                };
                if let (Some(n), Expr::Pattern(..)) = (&tyname, &**x) {
                    let ti = self.lookup_type(n).unwrap();
                    let dims = if ti.dims.is_empty() { vec![(ti.width as i64 - 1, 0)] } else { ti.dims.clone() };
                    let tg = Sig { name: String::new(), bits: vec![], dims, signed: ti.signed, ty: if ti.fields.is_empty() { None } else { Some(n.clone()) }, udims: 0 };
                    return Ok((self.ev_pattern(x, &tg)?, tsg));
                }
                let (v, s) = self.ev(x, tw)?;
                Ok((self.ext(v, tw, s), tsg))
            }
            Expr::Call(f, args) => match f.as_str() {
                "$signed" => Ok((self.ev(&args[0], 0)?.0, true)),
                "$unsigned" => Ok((self.ev(&args[0], 0)?.0, false)),
                "$clog2" | "$bits" | "$max1" | "$size" | "$left" | "$right" | "$high" | "$low" | "$increment" | "$dimensions" => {
                    let v = self.ceval(e)?;
                    Ok((self.cbits(v, 32), true))
                }
                "$countones" | "$onehot" | "$onehot0" => {
                    let (v, _) = self.ev(&args[0], 0)?;
                    let cnt = self.popcount(&v);
                    let cw = cnt.len();
                    Ok(match f.as_str() {
                        "$countones" => (self.ext(cnt, 32, false), true),
                        "$onehot" => {
                            let one = self.cbits(1, cw);
                            (vec![self.eq(&cnt, &one)], false)
                        }
                        _ => {
                            let one = self.cbits(1, cw);
                            let z = self.cbits(0, cw);
                            let a = self.eq(&cnt, &one);
                            let b = self.eq(&cnt, &z);
                            (vec![self.or(a, b)], false)
                        }
                    })
                }
                "$isunknown" => Ok((vec![self.c0], false)),
                "rising_edge" | "falling_edge" | "'event" => Err(format!("{}: clock edge expression used outside a clocked process", self.cur_file)),
                _ if f.contains('.') && !f.starts_with("$m.") => {
                    let (ifn, m) = f.rsplit_once('.').unwrap();
                    self.iface_method(ifn, m, args)
                }
                _ => self.call_func(f, args),
            },
        }
    }
    fn popcount(&mut self, v: &[NetId]) -> Vec<NetId> {
        let mut w = 1;
        while (1usize << w) <= v.len() {
            w += 1;
        }
        let mut acc = vec![self.c0; w];
        for &b in v {
            let mut add = vec![self.c0; w];
            add[0] = b;
            let c0 = self.c0;
            acc = self.add(&acc, &add, c0).0;
        }
        acc
    }
    /// assignment pattern '{...} for a target of shape `t` (struct, packed / unpacked array, vector)
    fn ev_pattern(&mut self, e: &Expr, t: &Sig) -> ER<Vec<NetId>> {
        let Expr::Pattern(parts, fill) = e else {
            let w = t.dims.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
            return self.evw(e, w);
        };
        let save = self.tgt.take();
        let r = self.ev_pattern_i(parts, fill.as_deref(), t);
        self.tgt = save;
        r
    }
    fn ev_pattern_i(&mut self, parts: &[(Option<Expr>, Expr)], fill: Option<&Expr>, t: &Sig) -> ER<Vec<NetId>> {
        let total: usize = t.dims.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
        let mut out = vec![self.c0; total];
        // expand '{n{a, b}} replications into positional items
        let mut items: Vec<(Option<Expr>, Expr)> = vec![];
        for (k, v) in parts {
            if let (Some(Expr::Id(r)), Expr::Repl(n, vs)) = (k, v) {
                if r == "$repl" {
                    for _ in 0..self.ceval(n)? {
                        for x in vs {
                            items.push((None, x.clone()));
                        }
                    }
                    continue;
                }
            }
            items.push((k.clone(), v.clone()));
        }
        let struct_ty = if t.dims.len() == 1 { t.ty.clone().and_then(|n| self.lookup_type(&n)) } else { None };
        if let Some(ti) = struct_ty {
            let fields = ti.fields.clone();
            let positional = items.iter().all(|(k, _)| k.is_none());
            if positional && !items.is_empty() && items.len() != fields.len() {
                return Err(format!("{}: assignment pattern has {} items for a struct with {} members", self.cur_file, items.len(), fields.len()));
            }
            for (fi, f) in fields.iter().enumerate() {
                let fshape = Sig { name: String::new(), bits: vec![], dims: if f.dims.is_empty() { vec![(0, 0)] } else { f.dims.clone() }, signed: f.signed, ty: f.ty.clone(), udims: 0 };
                let val = if positional && !items.is_empty() {
                    Some(items[fi].1.clone())
                } else {
                    items.iter().find(|(k, _)| matches!(k, Some(Expr::Id(n)) if n == &f.name)).map(|x| x.1.clone())
                };
                let bits = match (val, fill) {
                    (Some(v), _) => self.ev_pattern(&v, &fshape)?,
                    (None, Some(d)) => {
                        if f.ty.is_some() || f.dims.len() > 1 {
                            self.ev_pattern_i(&[], Some(d), &fshape)?
                        } else {
                            self.evw(d, f.width)?
                        }
                    }
                    (None, None) => return Err(format!("{}: assignment pattern does not set member '{}'", self.cur_file, f.name)),
                };
                out[f.off..f.off + f.width].copy_from_slice(&bits[..f.width]);
            }
            if let Some(bad) = items.iter().find_map(|(k, _)| match k { Some(Expr::Id(n)) if !fields.iter().any(|f| &f.name == n) && self.lookup_param(n).is_none() => Some(n.clone()), _ => None }) {
                return Err(format!("{}: assignment pattern names unknown member '{}'", self.cur_file, bad));
            }
            return Ok(out);
        }
        // array (or vector: an array of bits)
        let dims = if t.dims.is_empty() { vec![(0, 0)] } else { t.dims.clone() };
        let d0 = dims[0];
        let eshape = Sig { name: String::new(), bits: vec![], dims: dims[1..].to_vec(), signed: t.signed, ty: if dims.len() >= 2 { t.ty.clone() } else { None }, udims: t.udims.saturating_sub(1) };
        let ew: usize = dims[1..].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product();
        let n = (d0.0 - d0.1).unsigned_abs() as usize + 1;
        let positional = items.iter().all(|(k, _)| k.is_none());
        if positional && !items.is_empty() && items.len() != n {
            return Err(format!("{}: assignment pattern has {} items for {} elements", self.cur_file, items.len(), n));
        }
        let step: i64 = if d0.0 >= d0.1 { -1 } else { 1 };
        for k in 0..n {
            let idx = d0.0 + step * k as i64;
            let val = if positional && !items.is_empty() {
                Some(items[k].1.clone())
            } else {
                let mut found = None;
                for (key, v) in &items {
                    if let Some(key) = key {
                        if self.ceval(key)? as i64 == idx {
                            found = Some(v.clone());
                        }
                    }
                }
                found
            };
            let bits = match (val, fill) {
                (Some(v), _) => self.ev_pattern(&v, &eshape)?,
                (None, Some(d)) => {
                    if eshape.ty.is_some() || eshape.dims.len() > 1 {
                        self.ev_pattern_i(&[], Some(d), &eshape)?
                    } else {
                        self.evw(d, ew)?
                    }
                }
                (None, None) => return Err(format!("{}: assignment pattern does not set element [{}]", self.cur_file, idx)),
            };
            let o = dim_off(d0, idx).unwrap();
            out[o * ew..(o + 1) * ew].copy_from_slice(&bits[..ew]);
        }
        Ok(out)
    }
    fn index_mux(&mut self, elems: &BTreeMap<i64, Vec<NetId>>, iv: &[NetId], signed: bool, ew: usize) -> Vec<NetId> {
        // out-of-range index values read 0 (x in simulation)
        let k = iv.len().min(16);
        let n = 1usize << k;
        let neg = signed && iv.len() <= 16;
        let mut layer: Vec<Vec<NetId>> = (0..n)
            .map(|i| {
                let idx = if neg && k > 0 && i >= n / 2 { i as i64 - n as i64 } else { i as i64 };
                elems.get(&idx).cloned().unwrap_or(vec![self.c0; ew])
            })
            .collect();
        for &s in iv.iter().take(16) {
            let mut nx = vec![];
            for ch in layer.chunks(2) {
                if ch.len() == 2 {
                    nx.push((0..ew).map(|j| self.mux(s, ch[0][j], ch[1][j])).collect());
                } else {
                    nx.push(ch[0].clone());
                }
            }
            layer = nx;
        }
        // higher index bits set => out of range => 0
        let mut over = self.c0;
        for &s in iv.iter().skip(16) {
            over = self.or(over, s);
        }
        let ns = self.not(over);
        layer[0].iter().map(|x| self.and(*x, ns)).collect()
    }
    /// comparisons and logical operators (1-bit unsigned result)
    fn ev_bin(&mut self, op: &str, a: &Expr, b: &Expr) -> ER<(Vec<NetId>, bool)> {
        match op {
            "&&" | "||" | "->" | "<->" => {
                let (x, _) = self.ev(a, 0)?;
                let (y, _) = self.ev(b, 0)?;
                let (bx, by) = (self.to_bool(&x), self.to_bool(&y));
                Ok((vec![match op {
                    "&&" => self.and(bx, by),
                    "||" => self.or(bx, by),
                    "->" => {
                        let n = self.not(bx);
                        self.or(n, by)
                    }
                    _ => {
                        let t = self.xor(bx, by);
                        self.not(t)
                    }
                }], false))
            }
            _ => {
                // operands are sized to each other and are signed only if both are signed
                let ow = self.swidth(a)?.max(self.swidth(b)?);
                let sg = self.ssigned(a)? && self.ssigned(b)?;
                let x = self.ev_t(a, ow, sg)?;
                let y = self.ev_t(b, ow, sg)?;
                let r = match op {
                    "==" | "===" => self.eq(&x, &y),
                    "!=" | "!==" => {
                        let t = self.eq(&x, &y);
                        self.not(t)
                    }
                    "==?" | "!=?" => {
                        // wildcard: x/z bits of the right-hand literal are don't care
                        let mask: Vec<bool> = match b {
                            Expr::Num { bits, .. } => (0..ow).map(|k| bits.get(k).map(|v| *v >= 2).unwrap_or(false)).collect(),
                            _ => vec![false; ow],
                        };
                        let v: Vec<NetId> = (0..ow).filter(|k| !mask[*k]).map(|k| {
                            let t = self.xor(x[k], y[k]);
                            self.not(t)
                        }).collect();
                        let e = self.reduce(GOp::And, &v);
                        if op == "==?" { e } else { self.not(e) }
                    }
                    "<" => self.lt(&x, &y, sg),
                    ">" => self.lt(&y, &x, sg),
                    "<=" => {
                        let t = self.lt(&y, &x, sg);
                        self.not(t)
                    }
                    _ => {
                        let t = self.lt(&x, &y, sg);
                        self.not(t)
                    }
                };
                Ok((vec![r], false))
            }
        }
    }

    fn call_func(&mut self, f: &str, args: &[Expr]) -> ER<(Vec<NetId>, bool)> {
        let fd = self.lookup_func(f).ok_or_else(|| format!("{}: unknown function '{}' (ELAB-357)", self.cur_file, f))?;
        if fd.is_task {
            return Err(format!("{}: task / void function '{}' used in an expression", self.cur_file, f));
        }
        if self.depth > 64 {
            return Err(format!("function '{}' recursion too deep", f));
        }
        if args.len() > fd.args.len() {
            return Err(format!("{}: too many arguments in call of '{}' ({} for {})", self.cur_file, f, args.len(), fd.args.len()));
        }
        self.depth += 1;
        // evaluate input arguments in the caller scope
        let mut vals = vec![];
        let mut outs: Vec<(Expr, String)> = vec![];
        for (k, (an, at)) in fd.args.iter().enumerate() {
            let dir = fd.dirs.get(k).copied().unwrap_or(Dir::In);
            let (d, s, ty) = self.type_info(at)?;
            let wd: usize = d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
            let shape = Sig { name: an.clone(), bits: vec![], dims: d, signed: s, ty, udims: 0 };
            let v = match (dir, args.get(k)) {
                (Dir::Out, _) => None,
                (_, Some(e)) => Some(self.ev_to(e, &shape, wd)?),
                (_, None) => Some(vec![self.c0; wd]),
            };
            if dir != Dir::In {
                let e = args.get(k).cloned().ok_or_else(|| format!("{}: output argument '{}' of '{}' is not connected", self.cur_file, an, f))?;
                outs.push((e, an.clone()));
            }
            vals.push((an.clone(), at.clone(), v));
        }
        if !outs.is_empty() && self.procs.is_empty() {
            self.depth -= 1;
            return Err(format!("{}: function '{}' with output arguments called outside a procedural block", self.cur_file, f));
        }
        let (rd, rs, rty) = self.type_info(&fd.ret)?;
        let save_g = self.gpath.clone();
        self.gpath = format!("{}{}_{}.", self.gpath, f, self.gcount);
        self.gcount += 1;
        self.stack.push(Scope::default());
        // the function sees the caller's current (blocking) values of module variables
        let mut st = match self.procs.last() {
            Some(p) => PState { vals: p.vals.clone(), blocking: p.blocking.clone(), done: self.c0, brk: self.c0, cont: self.c0 },
            None => PState { vals: BTreeMap::new(), blocking: HashSet::new(), done: self.c0, brk: self.c0, cont: self.c0 },
        };
        // arguments are local variables of the call (writable), initialized with the values
        let mut argsigs = vec![];
        for (an, at, v) in vals {
            let sg = match self.mk_sig(&an, &at, &[]) {
                Ok(s) => s,
                Err(e) => {
                    self.stack.pop();
                    self.gpath = save_g;
                    self.depth -= 1;
                    return Err(e);
                }
            };
            if let Some(v) = v {
                for (t, x) in sg.bits.iter().zip(v) {
                    st.vals.insert(*t, (x, self.c1));
                    st.blocking.insert(*t);
                }
            }
            argsigs.push(sg.clone());
            self.top().sigs.insert(an, sg);
        }
        let rwd: usize = rd.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
        let rbits: Vec<NetId> = (0..rwd).map(|i| self.nl.add_net(&format!("{}{}{}[{}]", self.prefix, self.gpath, f, i))).collect();
        self.top().sigs.insert(f.to_string(), Sig { name: f.to_string(), bits: rbits.clone(), dims: rd, signed: rs, ty: rty, udims: 0 });
        self.procs.push(st);
        let r = self.exec(&fd.body, Some(f));
        // output argument values (read inside the function's process state)
        let mut ovals = vec![];
        if r.is_ok() {
            for (e, an) in &outs {
                let s = self.lookup_sig(an).unwrap();
                let v: Vec<NetId> = s.bits.iter().map(|b| self.read(*b)).collect();
                ovals.push((e.clone(), v, s.signed));
            }
        }
        let ps = self.procs.pop().unwrap();
        self.stack.pop();
        self.gpath = save_g;
        self.depth -= 1;
        r?;
        let out: Vec<NetId> = rbits.iter().map(|b| match ps.vals.get(b) {
            Some(&(v, e)) => {
                if e == self.c1 {
                    v
                } else {
                    self.and(v, e)
                }
            }
            None => self.c0,
        }).collect();
        for (e, v, sg) in ovals {
            self.assign_to(&e, Err((v, sg)), true)?;
        }
        Ok((out, rs))
    }

    // ------------------------------------------------------------ lvalues
    fn lval(&mut self, e: &Expr) -> ER<Vec<NetId>> {
        match e {
            Expr::Concat(v) => {
                let mut out = vec![];
                for x in v.iter().rev() {
                    out.extend(self.lval(x)?);
                }
                Ok(out)
            }
            Expr::Id(n) => {
                if let Some(s) = self.lookup_sig(n) {
                    return Ok(s.bits);
                }
                // implicit net
                crate::warn!("VER-936", "{}: implicit 1-bit net '{}' created", self.cur_file, n);
                let s = self.mk_sig(n, &DType::bit(), &[])?;
                self.top().sigs.insert(n.clone(), s.clone());
                Ok(s.bits)
            }
            _ => match self.sig_of(e)? {
                Some(s) => Ok(s.bits),
                None => Err(format!("{}: unsupported or non-constant lvalue (ELAB-208)", self.cur_file)),
            },
        }
    }

    // ------------------------------------------------------------ procedural
    fn assign(&mut self, tgt: &[NetId], val: &[NetId], blocking: bool, cond: Option<NetId>) {
        // statements after a taken return / break / continue do not execute
        let ps = self.procs.last().unwrap();
        let flags = [ps.done, ps.brk, ps.cont];
        let mut guard = cond;
        for f in flags {
            if f != self.c0 {
                let nf = self.not(f);
                guard = Some(match guard {
                    Some(c) => self.and(c, nf),
                    None => nf,
                });
            }
        }
        for (k, &t) in tgt.iter().enumerate() {
            if t == self.c0 || t == self.c1 {
                // constant (parameter array element, out-of-range select): not writable
                continue;
            }
            let v = val[k];
            let entry = match guard {
                None => (v, self.c1),
                Some(g) => {
                    let (ov, oe) = self.procs.last().unwrap().vals.get(&t).copied().unwrap_or((t, self.c0));
                    let nv = self.mux(g, ov, v);
                    let ne = self.or(oe, g);
                    (nv, ne)
                }
            };
            let ps = self.procs.last_mut().unwrap();
            ps.vals.insert(t, entry);
            if blocking {
                ps.blocking.insert(t);
            }
        }
    }
    fn branch(&mut self, c: NetId, t: &mut dyn FnMut(&mut Self) -> ER<()>, e: &mut dyn FnMut(&mut Self) -> ER<()>) -> ER<()> {
        if c == self.c1 {
            return t(self);
        }
        if c == self.c0 {
            return e(self);
        }
        let base = self.procs.last().unwrap().clone();
        t(self)?;
        let a = std::mem::replace(self.procs.last_mut().unwrap(), base.clone());
        e(self)?;
        let b = self.procs.pop().unwrap();
        let mut m = PState { vals: BTreeMap::new(), blocking: a.blocking.union(&b.blocking).copied().collect(), done: self.c0, brk: self.c0, cont: self.c0 };
        let keys: Vec<NetId> = a.vals.keys().chain(b.vals.keys()).copied().collect::<std::collections::BTreeSet<_>>().into_iter().collect();
        for k in keys {
            let (va, ea) = a.vals.get(&k).copied().or(base.vals.get(&k).copied()).unwrap_or((k, self.c0));
            let (vb, eb) = b.vals.get(&k).copied().or(base.vals.get(&k).copied()).unwrap_or((k, self.c0));
            let v = if ea == self.c0 { vb } else if eb == self.c0 { va } else { self.mux(c, vb, va) };
            let en = self.mux(c, eb, ea);
            m.vals.insert(k, (v, en));
        }
        m.done = self.mux(c, b.done, a.done);
        m.brk = self.mux(c, b.brk, a.brk);
        m.cont = self.mux(c, b.cont, a.cont);
        self.procs.push(m);
        Ok(())
    }
    /// lvalue alternatives (condition, target) for selects with variable indices at any depth
    fn lval_alts(&mut self, e: &Expr) -> ER<Option<Vec<(NetId, Sig)>>> {
        if let Some(s) = self.sig_of(e)? {
            return Ok(Some(vec![(self.c1, s)]));
        }
        match e {
            Expr::Member(b, m) => {
                let Some(alts) = self.lval_alts(b)? else { return Ok(None) };
                let mut out = vec![];
                for (c, s) in alts {
                    out.push((c, self.sel_member(&s, m)?));
                }
                Ok(Some(out))
            }
            Expr::Index(b, i) => {
                let Some(alts) = self.lval_alts(b)? else { return Ok(None) };
                let nm = expr_name(b).unwrap_or_default();
                if let Ok(iv) = self.ceval(i) {
                    let mut out = vec![];
                    for (c, s) in alts {
                        out.push((c, self.sel_index(&s, iv as i64, &nm)?));
                    }
                    return Ok(Some(out));
                }
                let (iv, isg) = self.ev(i, 0)?;
                let n = iv.len();
                let mut out = vec![];
                for (c, s) in alts {
                    let d0 = *s.dims.first().ok_or_else(|| format!("bit-select of scalar '{}'", nm))?;
                    for idx in d0.0.min(d0.1)..=d0.0.max(d0.1) {
                        // only index values the index expression can take
                        let ok = if n >= 63 {
                            isg || idx >= 0
                        } else if isg {
                            idx >= -(1i64 << (n - 1)) && idx < (1i64 << (n - 1))
                        } else {
                            idx >= 0 && idx < (1i64 << n)
                        };
                        if !ok {
                            continue;
                        }
                        let kb = self.cbits(idx as i128, n);
                        let hit = self.eq(&iv, &kb);
                        let cc = self.and(c, hit);
                        if cc == self.c0 {
                            continue;
                        }
                        out.push((cc, self.sel_index(&s, idx, &nm)?));
                    }
                }
                Ok(Some(out))
            }
            Expr::Range(b, l, r) => {
                let Some(alts) = self.lval_alts(b)? else { return Ok(None) };
                let (l, r) = (self.ceval(l)?, self.ceval(r)?);
                let nm = expr_name(b).unwrap_or_default();
                let mut out = vec![];
                for (c, s) in alts {
                    out.push((c, self.sel_range(&s, l, r, &nm)?));
                }
                Ok(Some(out))
            }
            Expr::PlusRange(b, st, wd, up) => {
                let Ok(sv) = self.ceval(st) else { return Ok(None) };
                let Some(alts) = self.lval_alts(b)? else { return Ok(None) };
                let wv = self.ceval(wd)?;
                let nm = expr_name(b).unwrap_or_default();
                let mut out = vec![];
                for (c, s) in alts {
                    let (l, r) = plus_bounds(&s, sv, wv, *up);
                    out.push((c, self.sel_range(&s, l, r, &nm)?));
                }
                Ok(Some(out))
            }
            _ => Ok(None),
        }
    }
    /// procedural assignment of an expression (or of already computed bits) to an lvalue
    fn assign_to(&mut self, lhs: &Expr, rhs: Result<&Expr, (Vec<NetId>, bool)>, blocking: bool) -> ER<()> {
        // dynamic indexed part-select on lhs: v[s +: w] / v[s -: w] with a variable s.
        // One conditional assignment per start value that keeps the slice in range.
        if let Expr::PlusRange(b, st, wd, up) = lhs {
            if self.ceval(st).is_err() {
                if let Some(bs) = self.sig_of(b)? {
                    let d0 = *bs.dims.first().ok_or("part-select of scalar")?;
                    let wv = self.ceval(wd)? as i64;
                    let (lo, hi) = (d0.0.min(d0.1), d0.0.max(d0.1));
                    // starts whose slice overlaps the vector: in-range bits are written,
                    // out-of-range bits are ignored (IEEE 1800 11.5.1)
                    let (s0, s1) = if *up { (lo - wv + 1, hi) } else { (lo, hi + wv - 1) };
                    let asc = d0.0 < d0.1;
                    let (sv, ssg) = self.ev(st, 0)?;
                    let ew: usize = bs.dims[1..].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product();
                    let val = match rhs {
                        Ok(e) => self.evw(e, wv as usize * ew)?,
                        Err((v, sg)) => self.ext(v, wv as usize * ew, sg),
                    };
                    let sw = sv.len().max(1);
                    for sidx in s0..=s1 {
                        let ok = if sw >= 63 { ssg || sidx >= 0 } else if ssg { sidx >= -(1i64 << (sw - 1)) && sidx < (1i64 << (sw - 1)) } else { sidx >= 0 && sidx < (1i64 << sw) };
                        if !ok {
                            continue;
                        }
                        let kb = self.cbits(sidx as i128, sv.len());
                        let c = self.eq(&sv, &kb);
                        let (mut tg, mut vv) = (vec![], vec![]);
                        for p in 0..wv {
                            // index of value element p (0 = right-hand element of the slice)
                            let idx = match (asc, *up) {
                                (false, true) => sidx + p,
                                (false, false) => sidx - wv + 1 + p,
                                (true, true) => sidx + wv - 1 - p,
                                (true, false) => sidx - p,
                            };
                            let Some(o) = dim_off(d0, idx) else { continue };
                            tg.extend_from_slice(&bs.bits[o * ew..(o + 1) * ew]);
                            vv.extend_from_slice(&val[p as usize * ew..(p as usize + 1) * ew]);
                        }
                        if !tg.is_empty() {
                            self.assign(&tg, &vv, blocking, Some(c));
                        }
                    }
                    return Ok(());
                }
            }
        }
        let alts = if matches!(lhs, Expr::Concat(_)) { None } else { self.lval_alts(lhs)? };
        match alts {
            Some(alts) => {
                let Some(shape) = alts.first().map(|x| x.1.clone()) else {
                    crate::warn!("ELAB-151", "{}: assignment target '{}' is always out of range; ignored", self.cur_file, expr_name(lhs).unwrap_or_default());
                    return Ok(());
                };
                let w = shape.bits.len();
                let val = match rhs {
                    Ok(e) => self.ev_to(e, &shape, w)?,
                    Err((v, sg)) => self.ext(v, w, sg),
                };
                if alts.len() == 1 && alts[0].0 == self.c1 {
                    self.assign(&shape.bits, &val, blocking, None);
                } else {
                    for (c, s) in alts {
                        self.assign(&s.bits, &val, blocking, Some(c));
                    }
                }
            }
            None => {
                let tg = self.lval(lhs)?;
                let val = match rhs {
                    Ok(e) => self.evw(e, tg.len())?,
                    Err((v, sg)) => self.ext(v, tg.len(), sg),
                };
                self.assign(&tg, &val, blocking, None);
            }
        }
        Ok(())
    }
    fn set_flag(&mut self, which: u8, v: NetId) {
        let ps = self.procs.last_mut().unwrap();
        match which {
            0 => ps.done = v,
            1 => ps.brk = v,
            _ => ps.cont = v,
        }
    }
    fn flags(&self) -> (NetId, NetId, NetId) {
        let ps = self.procs.last().unwrap();
        (ps.done, ps.brk, ps.cont)
    }
    /// run one loop iteration; Ok(false) once a `break` has certainly been taken
    fn loop_iter(&mut self, body: &Stmt, func: Option<&str>) -> ER<bool> {
        let c0 = self.c0;
        self.set_flag(2, c0);
        self.exec(body, func)?;
        self.set_flag(2, c0);
        let (d, b, _) = self.flags();
        Ok(b != self.c1 && d != self.c1)
    }
    /// value of a loop condition, which must be known at elaboration time
    fn loop_cond(&mut self, c: &Expr, kw: &str) -> ER<bool> {
        if let Ok(v) = self.ceval(c) {
            return Ok(v != 0);
        }
        let (v, _) = self.ev(c, 0)?;
        let b = self.to_bool(&v);
        if b == self.c1 {
            Ok(true)
        } else if b == self.c0 {
            Ok(false)
        } else {
            Err(format!("{}: '{}' loop condition is not constant at elaboration time (ELAB-935)", self.cur_file, kw))
        }
    }
    fn foreach_rec(&mut self, dims: &[(i64, i64)], vars: &[Option<String>], k: usize, body: &Stmt, func: Option<&str>) -> ER<bool> {
        if k == vars.len() || k == dims.len() {
            return self.loop_iter(body, func);
        }
        let (l, r) = dims[k];
        let step: i64 = if l <= r { 1 } else { -1 };
        let Some(var) = &vars[k] else { return self.foreach_rec(dims, vars, k + 1, body, func) };
        let mut idx = l;
        loop {
            let mut sc = Scope::default();
            sc.params.insert(var.clone(), idx as i128);
            self.stack.push(sc);
            let r2 = self.foreach_rec(dims, vars, k + 1, body, func);
            self.stack.pop();
            if !r2? {
                return Ok(false);
            }
            if idx == r {
                break;
            }
            idx += step;
        }
        Ok(true)
    }
    fn exec(&mut self, s: &Stmt, func: Option<&str>) -> ER<()> {
        {
            let ps = self.procs.last().unwrap();
            if ps.done == self.c1 || ps.brk == self.c1 || ps.cont == self.c1 {
                return Ok(());
            }
        }
        match s {
            Stmt::Null => Ok(()),
            Stmt::Block(v) => {
                // a block with declarations is a scope of its own
                let scoped = v.iter().any(|x| matches!(x, Stmt::Decl(_)));
                if scoped {
                    self.stack.push(Scope::default());
                }
                let mut r = Ok(());
                for x in v {
                    r = self.exec(x, func);
                    if r.is_err() {
                        break;
                    }
                }
                if scoped {
                    self.stack.pop();
                }
                r
            }
            Stmt::Decl(d) => {
                let sg = self.mk_sig(&d.name, &d.ty, &d.unpacked)?;
                self.top().sigs.insert(d.name.clone(), sg);
                Ok(())
            }
            Stmt::Asgn { lhs, rhs, blocking } => {
                // loop variable assignment inside for() handled by caller
                if let Expr::Id(n) = lhs {
                    if self.lookup_param(n).is_some() && self.lookup_sig(n).is_none() {
                        let v = self.ceval(rhs)?;
                        for sc in self.stack.iter_mut().rev() {
                            if sc.params.contains_key(n) {
                                sc.params.insert(n.clone(), v);
                                break;
                            }
                        }
                        return Ok(());
                    }
                }
                self.assign_to(lhs, Ok(rhs), *blocking)
            }
            Stmt::If(c, t, e) => {
                let (cv, _) = self.ev(c, 0)?;
                let cb = self.to_bool(&cv);
                self.branch(cb, &mut |s| s.exec(t, func), &mut |s| if let Some(e) = e { s.exec(e, func) } else { Ok(()) })
            }
            Stmt::Case { kind, sel, items, default, inside, full, parallel, line } => {
                let sw = self.swidth(sel)?;
                let mut iw = sw;
                // the selector and items are sized to the widest and are signed only if all are signed
                let mut allsg = self.ssigned(sel)?;
                for (es, _) in items {
                    for x in es {
                        if !matches!(x, Expr::Range(b, _, _) if matches!(&**b, Expr::Id(n) if n == "$range")) {
                            iw = iw.max(self.swidth(x)?);
                            allsg = allsg && self.ssigned(x)?;
                        }
                    }
                }
                let sv = self.ev_t(sel, iw, allsg)?;
                let mut conds = vec![];
                for (es, _) in items {
                    let mut c = self.c0;
                    for x in es {
                        let t = if *inside || matches!(x, Expr::Range(b, _, _) if matches!(&**b, Expr::Id(n) if n == "$range")) {
                            self.ev(&Expr::Inside(Box::new(sel.clone()), vec![x.clone()]), 1)?.0[0]
                        } else if *kind == 0 && matches!(x, Expr::Num { bits, .. } if bits.iter().any(|b| *b >= 2)) {
                            // x / z in a plain case item: never matches a known selector value
                            let key = format!("{}:{}:casexz", self.cur_file, line);
                            if self.warned.insert(key) {
                                crate::warn!("ELAB-155", "{}:{}: case item with x/z bits never matches (use casez / casex for wildcards)", self.cur_file, line);
                            }
                            self.c0
                        } else {
                            let xv = self.ev_t(x, iw, allsg)?;
                            let mask: Vec<bool> = match x {
                                Expr::Num { bits, .. } => (0..iw).map(|k| bits.get(k).map(|v| (*kind >= 1 && *v == 3) || (*kind == 2 && *v == 2)).unwrap_or(false)).collect(),
                                _ => vec![false; iw],
                            };
                            let v: Vec<NetId> = (0..iw).filter(|k| !mask[*k]).map(|k| {
                                let t = self.xor(sv[k], xv[k]);
                                self.not(t)
                            }).collect();
                            self.reduce(GOp::And, &v)
                        };
                        c = self.or(c, t);
                    }
                    conds.push(c);
                }
                if *parallel {
                    let note = format!("parallel_case (line {}): case items are kept in RTL priority order, so the netlist matches RTL simulation even if items overlap", line);
                    if !self.pragma_notes.contains(&note) {
                        self.pragma_notes.push(note);
                    }
                }
                if *full && default.is_none() && !items.is_empty() {
                    // full_case: selector values not covered are don't care -> the last item takes
                    // them (no latch, no hold of the previous value)
                    let note = format!("full_case (line {}): uncovered selector values treated as don't care (no latch inferred)", line);
                    if !self.pragma_notes.contains(&note) {
                        self.pragma_notes.push(note);
                    }
                    let n = conds.len();
                    return self.exec_case(&conds[..n - 1], items, Some(&items[n - 1].1), 0, func);
                }
                self.exec_case(&conds, items, default.as_deref(), 0, func)
            }
            Stmt::For { var, init, cond, step, body } => {
                let v0 = self.ceval(init)?;
                let mut sc = Scope::default();
                sc.params.insert(var.clone(), v0);
                self.stack.push(sc);
                let (_, sb, sc0) = self.flags();
                let c0 = self.c0;
                self.set_flag(1, c0);
                let mut n = 0;
                let r = (|| -> ER<()> {
                    loop {
                        let cv = self.ceval(cond).map_err(|e| format!("{}: for-loop condition is not constant at elaboration time: {} (ELAB-935)", self.cur_file, e))?;
                        if cv == 0 {
                            break;
                        }
                        n += 1;
                        if n > 65536 {
                            return Err(format!("{}: for-loop iteration limit (65536) exceeded (ELAB-936)", self.cur_file));
                        }
                        if !self.loop_iter(body, func)? {
                            break;
                        }
                        if let Stmt::Asgn { rhs, .. } = &**step {
                            let nv = self.ceval(rhs)?;
                            self.top().params.insert(var.clone(), nv);
                        }
                    }
                    Ok(())
                })();
                self.stack.pop();
                self.set_flag(1, sb);
                self.set_flag(2, sc0);
                r
            }
            Stmt::While(c, body) | Stmt::DoWhile(body, c) => {
                let kw = if matches!(s, Stmt::While(..)) { "while" } else { "do-while" };
                let (_, sb, sc0) = self.flags();
                let c0 = self.c0;
                self.set_flag(1, c0);
                let mut n = 0;
                let mut first = matches!(s, Stmt::DoWhile(..));
                let r = (|| -> ER<()> {
                    loop {
                        if !first && !self.loop_cond(c, kw)? {
                            break;
                        }
                        first = false;
                        n += 1;
                        if n > 65536 {
                            return Err(format!("{}: '{}' loop iteration limit (65536) exceeded (ELAB-900)", self.cur_file, kw));
                        }
                        if !self.loop_iter(body, func)? {
                            break;
                        }
                    }
                    Ok(())
                })();
                self.set_flag(1, sb);
                self.set_flag(2, sc0);
                r
            }
            Stmt::Repeat(cnt, body) => {
                let k = match self.ceval(cnt) {
                    Ok(k) => k,
                    Err(_) => return Err(format!("{}: repeat count is not constant (ELAB-935)", self.cur_file)),
                };
                if k > 65536 {
                    return Err("repeat iteration limit (65536) exceeded (ELAB-900)".into());
                }
                let (_, sb, sc0) = self.flags();
                let c0 = self.c0;
                self.set_flag(1, c0);
                let mut r = Ok(());
                for _ in 0..k.max(0) {
                    match self.loop_iter(body, func) {
                        Ok(true) => {}
                        Ok(false) => break,
                        Err(e) => {
                            r = Err(e);
                            break;
                        }
                    }
                }
                self.set_flag(1, sb);
                self.set_flag(2, sc0);
                r
            }
            Stmt::Foreach(arr, vars, body) => {
                let dims = self.dims_of(arr)?;
                let (_, sb, sc0) = self.flags();
                let c0 = self.c0;
                self.set_flag(1, c0);
                let r = self.foreach_rec(&dims, vars, 0, body, func);
                self.set_flag(1, sb);
                self.set_flag(2, sc0);
                r.map(|_| ())
            }
            Stmt::Break => {
                let c1 = self.c1;
                self.set_flag(1, c1);
                Ok(())
            }
            Stmt::Continue => {
                let c1 = self.c1;
                self.set_flag(2, c1);
                Ok(())
            }
            Stmt::Call(f, args, line) => self.call_task(f, args, *line),
            Stmt::Return(e) => {
                if let (Some(e), Some(f)) = (e, func) {
                    let rs = self.lookup_sig(f).ok_or_else(|| format!("{}: 'return value' in task / void function '{}'", self.cur_file, f))?;
                    let w = rs.bits.len();
                    let v = self.ev_to(e, &rs, w)?;
                    self.assign(&rs.bits, &v, true, None);
                }
                let c1 = self.c1;
                self.set_flag(0, c1);
                Ok(())
            }
        }
    }
    /// task / void function call statement: runs in the caller's process; output and inout
    /// arguments are copied back to the caller's lvalues with blocking assignments
    fn call_task(&mut self, f: &str, args: &[Expr], line: usize) -> ER<()> {
        let fd = self.lookup_func(f).ok_or_else(|| format!("{}:{}: unknown task or function '{}' (ELAB-357)", self.cur_file, line, f))?;
        if self.depth > 64 {
            return Err(format!("task '{}' recursion too deep", f));
        }
        if args.len() > fd.args.len() {
            return Err(format!("{}:{}: too many arguments in call of '{}' ({} for {})", self.cur_file, line, f, args.len(), fd.args.len()));
        }
        self.depth += 1;
        let save_g = self.gpath.clone();
        let tag = format!("{}{}_{}.", self.gpath, f, self.gcount);
        self.gcount += 1;
        // inputs are evaluated in the caller's scope
        let mut ins = vec![];
        let mut outs: Vec<(Expr, String)> = vec![];
        for (k, (an, at)) in fd.args.iter().enumerate() {
            let dir = fd.dirs.get(k).copied().unwrap_or(Dir::In);
            let (d, sg, ty) = self.type_info(at)?;
            let wd: usize = d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
            let shape = Sig { name: an.clone(), bits: vec![], dims: d.clone(), signed: sg, ty: ty.clone(), udims: 0 };
            let v = match (dir, args.get(k)) {
                (Dir::Out, _) => None,
                (_, Some(e)) => Some(self.ev_to(e, &shape, wd)?),
                (_, None) => Some(vec![self.c0; wd]),
            };
            if dir != Dir::In {
                let e = args.get(k).cloned().ok_or_else(|| format!("{}:{}: output argument '{}' of '{}' is not connected", self.cur_file, line, an, f))?;
                outs.push((e, an.clone()));
            }
            ins.push((an.clone(), at.clone(), dir, v, shape));
        }
        self.stack.push(Scope::default());
        self.gpath = tag;
        let mut locals: Vec<NetId> = vec![];
        let r = (|| -> ER<()> {
            for (an, at, dir, v, shape) in ins {
                let _ = &shape;
                match dir {
                    Dir::In => {
                        // inputs are local variables of the call, initialized with the values
                        let sg = self.mk_sig(&an, &at, &[])?;
                        locals.extend(sg.bits.iter().copied());
                        self.top().sigs.insert(an.clone(), sg.clone());
                        let v = v.unwrap();
                        let c1 = self.c1;
                        let ps = self.procs.last_mut().unwrap();
                        for (t, x) in sg.bits.iter().zip(v) {
                            ps.vals.insert(*t, (x, c1));
                            ps.blocking.insert(*t);
                        }
                    }
                    _ => {
                        let sg = self.mk_sig(&an, &at, &[])?;
                        locals.extend(sg.bits.iter().copied());
                        self.top().sigs.insert(an.clone(), sg.clone());
                        if let Some(v) = v {
                            // inout: starts with the caller's value
                            let c1 = self.c1;
                            let ps = self.procs.last_mut().unwrap();
                            for (t, x) in sg.bits.iter().zip(v) {
                                ps.vals.insert(*t, (x, c1));
                                ps.blocking.insert(*t);
                            }
                        }
                    }
                }
            }
            if !fd.is_task {
                // non-void function called as a statement: its value is discarded
                let rs = self.mk_sig(f, &fd.ret, &[])?;
                locals.extend(rs.bits.iter().copied());
                self.top().sigs.insert(f.to_string(), rs);
            }
            let (d0, _, _) = self.flags();
            let rr = self.exec(&fd.body, if fd.is_task { None } else { Some(f) });
            // a `return` ends the task only
            self.set_flag(0, d0);
            rr?;
            // copy outputs back
            let mut vals = vec![];
            for (e, an) in &outs {
                let s = self.lookup_sig(an).unwrap();
                let v: Vec<NetId> = s.bits.iter().map(|b| self.read(*b)).collect();
                vals.push((e.clone(), v, s.signed));
            }
            // locals of the call are dead now
            for sc in self.stack.last().unwrap().sigs.values() {
                locals.extend(sc.bits.iter().copied());
            }
            self.stack.pop();
            self.gpath = save_g.clone();
            for (e, v, sg) in vals {
                self.assign_to(&e, Err((v, sg)), true)?;
            }
            Ok(())
        })();
        if r.is_err() {
            // restore on error (the closure pops on success)
            if self.gpath != save_g {
                self.stack.pop();
                self.gpath = save_g;
            }
        }
        let ps = self.procs.last_mut().unwrap();
        for n in locals {
            ps.vals.remove(&n);
            ps.blocking.remove(&n);
        }
        self.depth -= 1;
        r
    }
    fn exec_case(&mut self, conds: &[NetId], items: &[(Vec<Expr>, Stmt)], default: Option<&Stmt>, k: usize, func: Option<&str>) -> ER<()> {
        if k == conds.len() {
            if let Some(d) = default {
                return self.exec(d, func);
            }
            return Ok(());
        }
        let c = conds[k];
        self.branch(c, &mut |s| s.exec(&items[k].1, func), &mut |s| s.exec_case(conds, items, default, k + 1, func))
    }

    /// map of net -> local hierarchical bit name for signals visible in the current module scope
    fn local_names(&self) -> HashMap<NetId, String> {
        let mut m = HashMap::new();
        let mut scopes: Vec<&Scope> = vec![];
        for s in self.stack.iter().rev() {
            scopes.push(s);
            if s.boundary {
                break;
            }
        }
        for s in scopes.iter().rev() {
            for sig in s.sigs.values() {
                if sig.name.is_empty() {
                    continue;
                }
                let names = bit_names(&sig.name, &sig.dims);
                if names.len() != sig.bits.len() {
                    continue;
                }
                for (b, n) in sig.bits.iter().zip(names) {
                    m.insert(*b, n);
                }
            }
            for ii in s.ifaces.values() {
                for el in &ii.elems {
                    for sig in el.values() {
                        let names = bit_names(&sig.name, &sig.dims);
                        if names.len() == sig.bits.len() {
                            for (b, n) in sig.bits.iter().zip(names) {
                                m.entry(*b).or_insert(n);
                            }
                        }
                    }
                }
            }
        }
        m
    }
    fn always(&mut self, kind: AKind, sens: &[(Edge, Expr)], body: &Stmt, line: usize) -> ER<()> {
        let loc = format!("{}:{}", self.cur_file, line);
        let lnames = self.local_names();
        let lname = |nl: &Netlist, t: NetId| -> String { lnames.get(&t).cloned().unwrap_or_else(|| nl.net(t).name.clone()) };
        match kind {
            AKind::Comb | AKind::Latch | AKind::Plain => {
                self.procs.push(PState { vals: BTreeMap::new(), blocking: HashSet::new(), done: self.c0, brk: self.c0, cont: self.c0 });
                let r = self.exec(body, None);
                let ps = self.procs.pop().unwrap();
                r?;
                for (t, (v, e)) in ps.vals {
                    if e == self.c1 {
                        if v != t {
                            let c = format!("{}B{}", self.prefix, { self.gcount += 1; self.gcount });
                            self.nl.add_gen(&c, GOp::Buf, &[v], t);
                        }
                    } else {
                        let nm = lname(&self.nl, t);
                        let rn = reg_name(&nm);
                        if kind == AKind::Latch {
                            crate::info!("ELAB-301", "Latch inferred for '{}' (always_latch at {})", nm, loc);
                        } else {
                            crate::warn!("ELAB-302", "Unintentional LATCH inferred for '{}' at {}: not assigned in all branches of combinational block{}", nm, loc, if kind == AKind::Comb { " (always_comb/process)" } else { "" });
                        }
                        let c = self.nl.add_cell(&rn, Kind::Gen(GOp::Latch), &[("D", Dir::In), ("G", Dir::In), ("Q", Dir::Out)]);
                        self.nl.connect(c, 0, v);
                        self.nl.connect(c, 1, e);
                        self.nl.connect(c, 2, t);
                        self.latches.push(nm);
                    }
                }
                Ok(())
            }
            AKind::Ff => {
                if sens.is_empty() {
                    return Err(format!("{}: always_ff without event control", loc));
                }
                // peel async resets
                let mut asyncs: Vec<(&Expr, &Stmt)> = vec![];
                let mut st = body;
                let mut rem = sens.len();
                while rem > 1 {
                    let mut s2 = st;
                    while let Stmt::Block(v) = s2 {
                        if v.len() == 1 {
                            s2 = &v[0]
                        } else {
                            break;
                        }
                    }
                    match s2 {
                        Stmt::If(c, a, Some(b)) => {
                            asyncs.push((c, a));
                            st = b;
                            rem -= 1;
                        }
                        Stmt::If(c, a, None) => {
                            asyncs.push((c, a));
                            st = &Stmt::Null;
                            rem -= 1;
                        }
                        _ => return Err(format!("{}: cannot infer asynchronous reset structure (ELAB-306)", loc)),
                    }
                }
                let clk = sens.iter().find(|(_, e)| {
                    let n = expr_name(e).unwrap_or_default();
                    !asyncs.iter().any(|(c, _)| expr_mentions(c, &n))
                }).or(sens.first()).unwrap();
                let (ck, _) = self.ev(&clk.1, 1)?;
                let mut cknet = ck[0];
                if clk.0 == Edge::Neg {
                    cknet = self.not(cknet);
                }
                // reset values; branch k is active when its condition holds and no earlier one does
                let mut clr: HashMap<NetId, NetId> = HashMap::new();
                let mut set: HashMap<NetId, NetId> = HashMap::new();
                let mut earlier = self.c0;
                let mut actives: Vec<(NetId, HashSet<NetId>)> = vec![];
                for (c, a) in &asyncs {
                    let (cv, _) = self.ev(c, 0)?;
                    let raw = self.to_bool(&cv);
                    let ne = self.not(earlier);
                    let cb = self.and(raw, ne);
                    earlier = self.or(earlier, raw);
                    self.procs.push(PState { vals: BTreeMap::new(), blocking: HashSet::new(), done: self.c0, brk: self.c0, cont: self.c0 });
                    let r = self.exec(a, None);
                    let ps = self.procs.pop().unwrap();
                    r?;
                    actives.push((cb, ps.vals.keys().copied().collect()));
                    for (t, (v, _)) in ps.vals {
                        let m = if v == self.c0 {
                            &mut clr
                        } else if v == self.c1 {
                            &mut set
                        } else {
                            crate::warn!("ELAB-307", "{}: non-constant asynchronous load value for '{}'; modeled with async set/reset logic", loc, self.nl.net(t).name);
                            // async load: set when cond&v, clear when cond&!v
                            let sv = self.and(cb, v);
                            let nv = self.not(v);
                            let cvv = self.and(cb, nv);
                            let o = set.get(&t).copied().unwrap_or(self.c0);
                            let s2 = self.or(o, sv);
                            set.insert(t, s2);
                            let o = clr.get(&t).copied().unwrap_or(self.c0);
                            let c2 = self.or(o, cvv);
                            clr.insert(t, c2);
                            continue;
                        };
                        let o = m.get(&t).copied().unwrap_or(self.c0);
                        let nn = self.or(o, cb);
                        m.insert(t, nn);
                    }
                }
                self.procs.push(PState { vals: BTreeMap::new(), blocking: HashSet::new(), done: self.c0, brk: self.c0, cont: self.c0 });
                let r = self.exec(st, None);
                let ps = self.procs.pop().unwrap();
                r?;
                let mut targets: Vec<NetId> = ps.vals.keys().copied().collect();
                for t in clr.keys().chain(set.keys()) {
                    if !targets.contains(t) {
                        targets.push(*t)
                    }
                }
                targets.sort();
                for t in targets {
                    let (v, e) = ps.vals.get(&t).copied().unwrap_or((t, self.c0));
                    let mut d = if e == self.c1 { v } else { self.mux(e, t, v) };
                    // a register not assigned in an active asynchronous branch keeps its value
                    // (no clocked load while that reset / set is asserted)
                    let mut hold = self.c0;
                    for (cb, assigned) in &actives {
                        if !assigned.contains(&t) {
                            hold = self.or(hold, *cb);
                        }
                    }
                    if hold != self.c0 {
                        d = self.mux(hold, d, t);
                    }
                    let nm = lname(&self.nl, t);
                    let mut pins = vec![("D", Dir::In), ("CK", Dir::In), ("Q", Dir::Out)];
                    let cl = clr.get(&t).copied();
                    let se = set.get(&t).copied();
                    if cl.is_some() {
                        pins.push(("RN", Dir::In))
                    }
                    if se.is_some() {
                        pins.push(("SN", Dir::In))
                    }
                    let c = self.nl.add_cell(&reg_name(&nm), Kind::Gen(GOp::Dff), &pins);
                    self.nl.connect(c, 0, d);
                    self.nl.connect(c, 1, cknet);
                    self.nl.connect(c, 2, t);
                    if let Some(x) = cl {
                        let n = self.not(x);
                        self.nl.connect_name(c, "RN", n);
                    }
                    if let Some(x) = se {
                        let n = self.not(x);
                        self.nl.connect_name(c, "SN", n);
                    }
                }
                Ok(())
            }
        }
    }

    // ------------------------------------------------------------ module level
    /// width / signedness from a parameter's declared type; None = untyped (type of its value)
    fn param_decl_type(&mut self, ty: &Option<DType>) -> ER<Option<(usize, bool)>> {
        Ok(match ty {
            None => None,
            Some(DType::Logic { packed, signed }) if packed.is_empty() => {
                // `parameter signed P = ..` : range from the value
                if *signed { Some((0, true)) } else { None }
            }
            Some(t) => {
                let (d, sg, _) = self.type_info(t)?;
                let w = d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
                Some((w, sg))
            }
        })
    }
    /// bind value parameter `name`: explicit type, else the type of the final value
    /// (override value or default expression), IEEE 1800 6.20.2
    /// parameter array (unpacked dimensions): a read-only constant signal
    fn set_param_array(&mut self, name: &str, ty: &Option<DType>, unpacked: &[(Expr, Expr)], e: Option<&Expr>, ctx: &str) -> ER<()> {
        let t = ty.clone().unwrap_or(DType::Logic { signed: true, packed: vec![(Expr::int(31), Expr::int(0))] });
        let (dims, signed, tyn) = self.type_dims(&t, unpacked)?;
        let shape = Sig { name: name.to_string(), bits: vec![], dims: dims.clone(), signed, ty: tyn.clone(), udims: unpacked.len() };
        let w: usize = dims.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
        let e = e.ok_or_else(|| format!("{}: parameter array '{}' has no value", ctx, name))?;
        let bits = self.ev_to(e, &shape, w).map_err(|x| format!("{}: parameter {}: {}", ctx, name, x))?;
        if bits.iter().any(|b| *b != self.c0 && *b != self.c1) {
            return Err(format!("{}: parameter array '{}' is not constant", ctx, name));
        }
        self.top().sigs.insert(name.to_string(), Sig { bits, ..shape });
        Ok(())
    }
    fn set_param(&mut self, name: &str, ty: &Option<DType>, ov: Option<(i128, Option<(usize, bool)>)>, e: Option<&Expr>, ctx: &str) -> ER<()> {
        // struct-typed parameters are typed constants (member selects work on them)
        if let (Some(t), None) = (ty, &ov) {
            if self.type_info(t)?.2.is_some() {
                return self.set_param_array(name, ty, &[], e, ctx);
            }
        }
        let decl = self.param_decl_type(ty)?;
        // assignment pattern for a vector parameter: evaluate it against the declared type
        if let (Some(t), Some(pe @ Expr::Pattern(..)), None) = (ty, e, &ov) {
            let (d, sg, tyn) = self.type_info(t)?;
            let w = d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
            let shape = Sig { name: name.to_string(), bits: vec![], dims: d, signed: sg, ty: tyn, udims: 0 };
            let bits = self.ev_to(pe, &shape, w).map_err(|x| format!("{}: parameter {}: {}", ctx, name, x))?;
            let mut v: i128 = 0;
            for (k, b) in bits.iter().enumerate() {
                if *b == self.c1 && k < 127 {
                    v |= 1 << k;
                } else if *b != self.c0 && *b != self.c1 {
                    return Err(format!("{}: parameter '{}' is not constant", ctx, name));
                }
            }
            self.top().params.insert(name.to_string(), norm_val(v, w, sg));
            self.top().pinfo.insert(name.to_string(), (w, sg));
            if w > 120 {
                self.top().pbits.insert(name.to_string(), bits);
            }
            return Ok(());
        }
        // wider than the integer value: keep the exact bits too
        if let (None, Some(e), Some((w, s))) = (&ov, e, decl) {
            if w > 120 && !self.mentions_sig(e) {
                let bits = self.evw(e, w)?;
                if bits.iter().all(|b| *b == self.c0 || *b == self.c1) {
                    let v = self.ceval(e).unwrap_or(0);
                    self.top().params.insert(name.to_string(), v);
                    self.top().pinfo.insert(name.to_string(), (w, s));
                    self.top().pbits.insert(name.to_string(), bits);
                    return Ok(());
                }
            }
        }
        let (v, w, sg) = match ov {
            Some((v, ot)) => {
                let (ow, os) = ot.unwrap_or((32, true));
                match decl {
                    Some((0, _)) => (v, ow, true),
                    Some((w, s)) => (v, w, s),
                    None => (v, ow, os),
                }
            }
            None => {
                let e = e.ok_or_else(|| format!("{}: parameter '{}' has no value", ctx, name))?;
                let cw = match decl {
                    Some((w, _)) => w,
                    None => 0,
                };
                match self.cfold(e, cw) {
                    Ok((v, vw, vs)) => match decl {
                        Some((0, _)) => (v, vw, true),
                        Some((w, s)) => (v, w, s),
                        None => (v, vw, vs),
                    },
                    Err(_) => {
                        let v = self.ceval(e).map_err(|x| format!("{}: parameter {}: {}", ctx, name, x))?;
                        match decl {
                            Some((0, _)) | None => (v, 32, true),
                            Some((w, s)) => (v, w, s),
                        }
                    }
                }
            }
        };
        let nv = norm_val(v, w, sg);
        self.top().params.insert(name.to_string(), nv);
        self.top().pinfo.insert(name.to_string(), (w, sg));
        if !self.gpath.is_empty() {
            let key = format!("{}{}{}", self.prefix.replace('/', "."), self.gpath, name);
            self.hier_params.insert(key, (nv, w, sg));
        }
        Ok(())
    }
    fn bind_params(&mut self, m: &Module, overrides: &[(String, i128)], type_over: &HashMap<String, String>) -> ER<()> {
        let ovt = std::mem::take(&mut self.ov_types);
        // resolve every override to a parameter name (positional ones in override order)
        let order: Vec<String> = m.overridable().iter().map(|p| p.name.clone()).collect();
        let mut named: HashMap<String, (i128, Option<(usize, bool)>)> = HashMap::new();
        for (n, v) in overrides {
            let key = match n.strip_prefix("#pos") {
                Some(k) => match k.parse::<usize>().ok().and_then(|k| order.get(k)) {
                    Some(nm) => nm.clone(),
                    None => {
                        crate::warn!("ELAB-152", "{}: too many positional parameter overrides ({} parameters)", m.name, order.len());
                        continue;
                    }
                },
                None => n.clone(),
            };
            if !order.contains(&key) {
                crate::warn!("ELAB-153", "{}: parameter override '{}' does not match an overridable parameter (ignored)", m.name, key);
                continue;
            }
            named.insert(key, (*v, ovt.get(n).copied()));
        }
        for p in &m.params {
            if let Some(t) = type_over.get(&p.name) {
                self.top().ptypes.insert(p.name.clone(), t.clone());
                continue;
            }
            let ov = if p.local { None } else { named.remove(&p.name) };
            if let (None, Some(Expr::Id(t))) = (&ov, &p.value) {
                if self.lookup_type(t).is_some() && self.lookup_param(t).is_none() {
                    self.top().ptypes.insert(p.name.clone(), t.clone());
                    continue;
                }
            }
            if !p.unpacked.is_empty() {
                self.set_param_array(&p.name, &p.ty, &p.unpacked, p.value.as_ref(), &m.name)?;
                continue;
            }
            self.set_param(&p.name, &p.ty, ov, p.value.as_ref(), &m.name)?;
        }
        // overrides of body parameters wait for their declaration
        for (n, t) in type_over {
            if !m.params.iter().any(|p| &p.name == n) {
                self.top().ptypes.insert(n.clone(), t.clone());
            }
        }
        self.top().pend.extend(named);
        // Verilog-95 body parameters may size the port declarations, which are shaped before the
        // body is elaborated: bind the ones that evaluate on their own now (all body parameters
        // are bound again in source order by the declaration pass)
        for it in &m.items {
            if let Item::Param(p) = it {
                let Some(e) = &p.value else { continue };
                if !p.unpacked.is_empty() || matches!(e, Expr::Id(t) if self.lookup_type(t).is_some() && self.lookup_param(t).is_none()) {
                    continue;
                }
                let ov = if p.local { None } else { self.stack.last().unwrap().pend.get(&p.name).copied() };
                let save = self.top().clone();
                if self.set_param(&p.name, &p.ty, ov, Some(e), &m.name).is_err() {
                    *self.top() = save;
                }
            }
        }
        Ok(())
    }

    fn decl_pass(&mut self, items: &[Item]) -> ER<()> {
        for it in items {
            match it {
                Item::Param(p) => {
                    if let Some(e) = &p.value {
                        // a type parameter overridden by the instance
                        if !p.local && self.stack.last().unwrap().ptypes.contains_key(&p.name) {
                            continue;
                        }
                        if let Expr::Id(t) = e {
                            if self.lookup_type(t).is_some() && self.lookup_param(t).is_none() {
                                self.top().ptypes.insert(p.name.clone(), t.clone());
                                continue;
                            }
                        }
                        if self.stack.last().unwrap().ptypes.contains_key(&p.name) {
                            continue;
                        }
                        let f = self.cur_file.clone();
                        if !p.unpacked.is_empty() {
                            self.set_param_array(&p.name, &p.ty, &p.unpacked, Some(e), &f)?;
                            continue;
                        }
                        let ov = if p.local { None } else { self.top().pend.remove(&p.name) };
                        self.set_param(&p.name, &p.ty, ov, Some(e), &f)?;
                    }
                }
                Item::Typedef(n, t) => {
                    let ti = match t {
                        DType::Struct { packed, .. } => {
                            let mut ti = self.struct_info(t)?;
                            if !packed.is_empty() {
                                let mut d = vec![];
                                for (a, b) in packed {
                                    d.push((self.ceval(a)? as i64, self.ceval(b)? as i64));
                                }
                                d.push((ti.width as i64 - 1, 0));
                                ti.width *= d[..d.len() - 1].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>();
                                ti.dims = d;
                            }
                            ti
                        }
                        _ => {
                            let (d, s, ty) = self.type_info(t)?;
                            let w = d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
                            match ty.and_then(|x| self.lookup_type(&x)) {
                                Some(st) => st,
                                None => TypeInfo { width: w, signed: s, dims: d, fields: vec![] },
                            }
                        }
                    };
                    self.top().types.insert(n.clone(), ti);
                }
                Item::Func(f) => {
                    self.top().funcs.insert(f.name.clone(), f.clone());
                }
                Item::Decl(d) => {
                    if self.lookup_sig(&d.name).is_some() && self.stack.last().unwrap().sigs.contains_key(&d.name) {
                        continue;
                    }
                    let s = self.mk_sig(&d.name, &d.ty, &d.unpacked)?;
                    self.top().sigs.insert(d.name.clone(), s);
                }
                Item::Inst { module, params, name, range, .. } => {
                    if let Some(def) = self.lib.modules.get(module) {
                        if def.kind == ModKind::Interface {
                            let mut ov = vec![];
                            for (k, (pn, e)) in params.iter().enumerate() {
                                let v = self.ceval(e)?;
                                ov.push((pn.clone().unwrap_or(format!("#pos{}", k)), v));
                            }
                            let un: Vec<(Expr, Expr)> = range.iter().cloned().collect();
                            let inst = self.make_iface(module, name, &un, &ov, None)?;
                            self.top().ifaces.insert(name.clone(), inst);
                        }
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }

    /// Create an interface instance (or top-level interface port when `as_port` is set).
    fn make_iface(&mut self, def: &str, name: &str, unpacked: &[(Expr, Expr)], ov: &[(String, i128)], as_port: Option<(Option<String>, bool)>) -> ER<IfInst> {
        let d = self.lib.modules.get(def).ok_or_else(|| format!("Cannot find interface '{}' (LINK-3)", def))?.clone();
        if d.kind != ModKind::Interface {
            return Err(format!("'{}' is not an interface", def));
        }
        let (lo, n, is_array) = if let Some((a, b)) = unpacked.first() {
            let (a, b) = (self.ceval(a)? as i64, self.ceval(b)? as i64);
            (a.min(b), (a - b).unsigned_abs() as usize + 1, true)
        } else {
            (0, 1, false)
        };
        let mut elems = vec![];
        for k in 0..n {
            let ename = if is_array { format!("{}[{}]", name, lo + k as i64) } else { name.to_string() };
            let mut sc = Scope { boundary: true, ..Default::default() };
            sc.params = HashMap::new();
            let saved = std::mem::replace(&mut self.stack, vec![sc]);
            self.bind_params(&d, ov, &HashMap::new())?;
            let mut map = HashMap::new();
            let modport: Option<Vec<(Dir, String)>> = match &as_port {
                Some((Some(mp), _)) => d.items.iter().find_map(|i| if let Item::Modport(n, s) = i { if n == mp { Some(s.clone()) } else { None } } else { None }),
                _ => None,
            };
            // interface ports are members too (connected when the instance is elaborated)
            let mut all: Vec<Item> = d.ports.iter().filter(|p| p.iface.is_none()).map(|p| Item::Decl(Decl { name: p.name.clone(), ty: p.ty.clone(), unpacked: p.unpacked.clone(), init: None, dir: p.dir, line: d.line, net: true })).collect();
            all.extend(d.items.iter().cloned());
            for it in &all {
                match it {
                    Item::Param(_) | Item::Typedef(..) => self.decl_pass(std::slice::from_ref(it))?,
                    Item::Decl(dc) => {
                        let (dims, signed, ty) = self.type_dims(&dc.ty, &dc.unpacked)?;
                        let base = format!("{}{}{}.{}", self.prefix_saved(&saved), "", ename, dc.name);
                        let bits: Vec<NetId> = if as_port.is_some() {
                            let pn = format!("{}_{}", ename.replace(['[', ']'], "_").trim_end_matches('_'), dc.name);
                            let pn = pn.replace("__", "_");
                            let pname = if is_array { format!("{}_{}__{}", name, lo + k as i64, dc.name) } else { format!("{}_{}", name, dc.name) };
                            let _ = pn;
                            let dir = match &modport {
                                Some(mp) => mp.iter().find(|(_, s)| s == &dc.name).map(|x| x.0).unwrap_or_else(|| {
                                    crate::warn!("ELAB-961", "Interface signal '{}.{}' not in modport; treated as input", def, dc.name);
                                    Dir::In
                                }),
                                None => {
                                    crate::warn!("ELAB-960", "Top-level generic interface port '{}' without modport; signal '{}' treated as inout", name, dc.name);
                                    Dir::InOut
                                }
                            };
                            bit_names(&pname, &dims).iter().map(|bn| {
                                let p = self.nl.add_port(bn, dir);
                                self.nl.ports[p].net.unwrap()
                            }).collect()
                        } else {
                            bit_names(&base, &dims).iter().map(|bn| self.nl.add_net(bn)).collect()
                        };
                        map.insert(dc.name.clone(), Sig { name: format!("{}{}.{}", self.prefix_saved(&saved), ename, dc.name), bits, dims, signed, ty, udims: dc.unpacked.len() });
                    }
                    // continuous assignments, always blocks and functions are elaborated with the instance
                    Item::Modport(..) | Item::Import(_) | Item::Assign(..) | Item::Always { .. } | Item::Func(_) => {}
                    _ => crate::warn!("ELAB-962", "Interface '{}': instances / generate blocks inside interfaces are ignored", def),
                }
            }
            self.stack = saved;
            elems.push(map);
        }
        if as_port.is_some() {
            crate::info!("ELAB-963", "Top-level interface port '{}' ({}{}) flattened into {} element(s)", name, def, if is_array { format!("[{}]", n) } else { String::new() }, n);
        }
        Ok(IfInst { def: def.to_string(), lo, elems, is_array })
    }
    fn prefix_saved(&self, _s: &[Scope]) -> String {
        format!("{}{}", self.prefix, self.gpath)
    }

    fn module_body(&mut self, m: &Module) -> ER<()> {
        let save_file = std::mem::replace(&mut self.cur_file, m.file.clone());
        let save_inits = std::mem::take(&mut self.var_inits);
        // imports are global; local decls first
        let r = self.decl_pass(&m.items).and_then(|_| self.stmt_pass(&m.items));
        let inits = std::mem::replace(&mut self.var_inits, save_inits);
        r?;
        // a variable initializer is an initial value: it is the variable's value when nothing else
        // drives it, and is ignored for synthesis when the variable is assigned elsewhere
        for (name, bits, v) in inits {
            if bits.iter().any(|b| self.nl.driver(*b).is_some()) {
                crate::warn!("ELAB-154", "{}: initial value of variable '{}' ignored for synthesis (it is assigned elsewhere)", m.file, name);
            } else {
                self.cont_assign(&bits, &v);
            }
        }
        self.cur_file = save_file;
        Ok(())
    }

    /// "file:line: msg" without repeating a file prefix the message already has
    fn at_line(&self, line: usize, e: String) -> String {
        let pre = format!("{}:", self.cur_file);
        if let Some(rest) = e.strip_prefix(&pre) {
            let rest = rest.trim_start();
            // keep an existing line number
            if rest.split(':').next().map(|x| x.chars().all(|c| c.is_ascii_digit()) && !x.is_empty()).unwrap_or(false) {
                return e;
            }
            return format!("{}:{}: {}", self.cur_file, line, rest);
        }
        if e.contains(".sv:") || e.contains(".v:") || e.contains(".vhd:") {
            return e;
        }
        format!("{}:{}: {}", self.cur_file, line, e)
    }
    fn cont_item(&mut self, it: &Item) -> ER<()> {
        match it {
            Item::Assign(l, r, line) => {
                let tg = self.lval(l).map_err(|e| self.at_line(*line, e))?;
                let shape = self.sig_of(l).ok().flatten();
                let v = match shape {
                    Some(sh) => self.ev_to(r, &sh, tg.len()),
                    None => self.evw(r, tg.len()),
                }
                .map_err(|e| self.at_line(*line, e))?;
                self.cont_assign(&tg, &v);
                Ok(())
            }
            Item::Always { kind, sens, body, line } => self.always(*kind, sens, body, *line).map_err(|e| self.at_line(*line, e)),
            _ => Ok(()),
        }
    }
    fn stmt_pass(&mut self, items: &[Item]) -> ER<()> {
        // items that reference generate scopes declared further down are retried at the end
        let mut deferred: Vec<&Item> = vec![];
        for it in items {
            match it {
                Item::Decl(d) => {
                    if let Some(init) = &d.init {
                        let sh = self.lookup_sig(&d.name).unwrap();
                        let n = sh.bits.len();
                        let v = self.ev_to(init, &sh, n)?;
                        if d.net {
                            self.cont_assign(&sh.bits, &v);
                        } else {
                            // variable: initial value, decided once the module's drivers are known
                            self.var_inits.push((d.name.clone(), sh.bits.clone(), v));
                        }
                    }
                }
                Item::Assign(..) | Item::Always { .. } => {
                    if let Err(e) = self.cont_item(it) {
                        if e.contains("(ELAB-HIER)") {
                            deferred.push(it);
                        } else {
                            return Err(e);
                        }
                    }
                }
                Item::Inst { .. } => self.instance(it)?,
                Item::GenFor { var, init, cond, step, label, items } => {
                    let mut v = self.ceval(init)?;
                    let lab = label.clone().unwrap_or_else(|| "genblk".into());
                    let mut n = 0;
                    loop {
                        let mut sc = Scope::default();
                        sc.params.insert(var.clone(), v);
                        self.stack.push(sc);
                        let c = self.ceval(cond)?;
                        if c == 0 {
                            self.stack.pop();
                            break;
                        }
                        n += 1;
                        if n > 100000 {
                            return Err("generate loop limit".into());
                        }
                        let sg = self.gpath.clone();
                        self.gpath = format!("{}{}[{}].", self.gpath, lab, v);
                        let r = self.decl_pass(items).and_then(|_| self.stmt_pass(items));
                        self.gpath = sg;
                        let nv = self.ceval(step);
                        self.stack.pop();
                        r?;
                        v = nv?;
                    }
                }
                Item::GenIf { cond, then, els } => {
                    let c = self.ceval(cond)?;
                    let body = if c != 0 { then } else { els };
                    self.stack.push(Scope::default());
                    let r = self.decl_pass(body).and_then(|_| self.stmt_pass(body));
                    self.stack.pop();
                    r?;
                }
                Item::GenCase { sel, items, default } => {
                    let s = self.ceval(sel)?;
                    let mut chosen: &Vec<Item> = default;
                    'o: for (es, body) in items {
                        for e in es {
                            if self.ceval(e)? == s {
                                chosen = body;
                                break 'o;
                            }
                        }
                    }
                    self.stack.push(Scope::default());
                    let r = self.decl_pass(chosen).and_then(|_| self.stmt_pass(chosen));
                    self.stack.pop();
                    r?;
                }
                Item::GenBlock { label, items } => {
                    let sg = self.gpath.clone();
                    if let Some(l) = label {
                        self.gpath = format!("{}{}.", self.gpath, l);
                    }
                    self.stack.push(Scope::default());
                    let r = self.decl_pass(items).and_then(|_| self.stmt_pass(items));
                    self.stack.pop();
                    self.gpath = sg;
                    r?;
                }
                _ => {}
            }
        }
        for it in deferred {
            self.cont_item(it)?;
        }
        Ok(())
    }
    fn cont_assign(&mut self, tg: &[NetId], v: &[NetId]) {
        for (t, s) in tg.iter().zip(v) {
            if t != s {
                self.gcount += 1;
                let c = format!("{}B{}", self.prefix, self.gcount);
                self.nl.add_gen(&c, GOp::Buf, &[*s], *t);
            }
        }
    }

    fn instance(&mut self, it: &Item) -> ER<()> {
        let Item::Inst { module, params, name, range, conns, wildcard, line } = it else { unreachable!() };
        let def = self.lib.modules.get(module).cloned();
        if let Some(d) = &def {
            if d.kind == ModKind::Interface {
                // members were created in the declaration pass; connect ports, elaborate its logic
                return self.iface_body(d, name, conns, *wildcard, params, line);
            }
        }
        let loc = format!("{}:{}", self.cur_file, line);
        if def.is_none() {
            if let Some(pins) = self.opts.lib_cells.get(module).cloned() {
                return self.lib_inst(module, &pins, name, conns, &loc);
            }
        }
        let count = match range {
            Some((a, b)) => ((self.ceval(a)? - self.ceval(b)?).unsigned_abs() + 1) as usize,
            None => 1,
        };
        let rlo = match range {
            Some((a, b)) => self.ceval(a)?.min(self.ceval(b)?) as i64,
            None => 0,
        };
        // parameter overrides evaluated in the parent scope
        let mut ov = vec![];
        let mut tov = HashMap::new();
        let mut ov_types: HashMap<String, (usize, bool)> = HashMap::new();
        for (k, (pn, e)) in params.iter().enumerate() {
            let pname = pn.clone().unwrap_or_else(|| def.as_ref().and_then(|d| d.overridable().get(k).map(|p| p.name.clone())).unwrap_or(format!("#pos{}", k)));
            if let Expr::Id(t) = e {
                if self.lookup_type(t).is_some() && self.lookup_param(t).is_none() && self.lookup_sig(t).is_none() {
                    tov.insert(pname, t.clone());
                    continue;
                }
            }
            let w = self.swidth(e)?;
            let sg = self.ssigned(e)?;
            ov_types.insert(pname.clone(), (w, sg));
            ov.push((pname, self.ceval(e)?));
        }
        for k in 0..count {
            let iname = if range.is_some() { format!("{}{}{}[{}]", self.prefix, self.gpath, name, rlo + k as i64) } else { format!("{}{}{}", self.prefix, self.gpath, name) };
            let sig = format!("{}#({})", module, ov.iter().map(|(n, v)| format!("{}={}", n, v)).collect::<Vec<_>>().join(","));
            self.insts.entry(sig).or_default().push(iname.clone());
            let is_bb = match &def {
                None => true,
                Some(d) => d.blackbox || self.opts.blackboxes.contains(module) || (d.is_empty() && self.opts.empty_as_blackbox),
            };
            if is_bb {
                self.blackbox_inst(def.as_ref(), module, &iname, conns, *wildcard, &ov, k, count, &loc)?;
                continue;
            }
            let d = def.clone().unwrap();
            if d.is_empty() {
                crate::warn!("ELAB-EMPTY", "[EMPTY MODULE] '{}' (instance {}) has no logic; outputs left undriven (hdlin.elaborate.empty_module_as_blackbox=false)", module, iname);
            }
            if self.depth > 100 {
                return Err(format!("{}: instantiation depth exceeded (recursive instantiation of {}?)", loc, module));
            }
            // build child scope
            let child = Scope { boundary: true, ..Default::default() };
            let parent_stack = std::mem::replace(&mut self.stack, vec![child]);
            let parent_prefix = std::mem::replace(&mut self.prefix, format!("{}/", iname));
            let parent_g = std::mem::take(&mut self.gpath);
            self.ov_types = ov_types.clone();
            let r = self.bind_params(&d, &ov, &tov);
            if let Err(e) = r {
                self.stack = parent_stack;
                self.prefix = parent_prefix;
                self.gpath = parent_g;
                return Err(e);
            }
            // port shapes in child scope
            let mut shapes = vec![];
            for p in &d.ports {
                if p.iface.is_some() {
                    shapes.push(None);
                } else {
                    shapes.push(Some(self.type_dims(&p.ty, &p.unpacked)?));
                }
            }
            let child_scope = std::mem::replace(&mut self.stack, parent_stack);
            let cpfx = std::mem::replace(&mut self.prefix, parent_prefix);
            let cg = std::mem::replace(&mut self.gpath, parent_g);
            // connections evaluated in parent
            let mut bound: Vec<(String, Option<Sig>, Option<IfInst>)> = vec![];
            for (pi, p) in d.ports.iter().enumerate() {
                let conn: Option<Expr> = conns.iter().enumerate().find_map(|(ci, (n, e))| match n {
                    Some(n) if n == &p.name => Some(e.clone()),
                    None if ci == pi => Some(e.clone()),
                    _ => None,
                }).flatten().or_else(|| if *wildcard { Some(Expr::Id(p.name.clone())) } else { None });
                if let Some((ifn, _mp)) = &p.iface {
                    let ce = conn.ok_or_else(|| format!("{}: interface port '{}' of '{}' is unconnected", loc, p.name, module))?;
                    let ii = self.bind_iface(&ce, count, k, &loc)?;
                    if &ii.def != ifn && ifn != "interface" {
                        crate::warn!("ELAB-964", "{}: interface type mismatch on port '{}' ({} vs {})", loc, p.name, ii.def, ifn);
                    }
                    // port declared as array?
                    let want = p.unpacked.len();
                    let mut ii2 = if want == 0 && ii.is_array && ii.elems.len() == 1 { IfInst { is_array: false, ..ii } } else { ii };
                    let arr = ii2.is_array;
                    let lo = ii2.lo;
                    for (k2, el) in ii2.elems.iter_mut().enumerate() {
                        for (mn, sg) in el.iter_mut() {
                            sg.name = if arr { format!("{}/{}[{}].{}", iname, p.name, lo + k2 as i64, mn) } else { format!("{}/{}.{}", iname, p.name, mn) };
                        }
                    }
                    bound.push((p.name.clone(), None, Some(ii2)));
                    continue;
                }
                let (dims, signed, ty) = shapes[pi].clone().unwrap();
                let w: usize = dims.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
                let dir = p.dir.unwrap_or(Dir::In);
                let bits: Vec<NetId> = match conn {
                    None => {
                        if dir == Dir::In {
                            crate::warn!("LINT-33", "{}: input port '{}' of instance '{}' is unconnected (floating)", loc, p.name, iname);
                        }
                        bit_names(&format!("{}/{}", iname, p.name), &dims).iter().map(|n| self.nl.add_net(n)).collect()
                    }
                    Some(ce) => {
                        let cw = self.swidth(&ce)?;
                        let slice = count > 1 && cw == w * count;
                        if dir == Dir::In {
                            let v = self.evw(&ce, if slice { w * count } else { w })?;
                            if slice { v[k * w..(k + 1) * w].to_vec() } else { v }
                        } else {
                            match self.lval(&ce) {
                                Ok(mut v) => {
                                    if slice {
                                        v = v[k * w..(k + 1) * w].to_vec();
                                    }
                                    if v.len() != w {
                                        crate::warn!("ELAB-368", "{}: width mismatch on port '{}' of '{}' ({} vs {})", loc, p.name, iname, v.len(), w);
                                    }
                                    if v.len() > w && w > 0 {
                                        // a narrower output drives the extra bits of the net with its
                                        // zero / sign extension (port connections act as assignments)
                                        let fill = if signed { v[w - 1] } else { self.c0 };
                                        let extra = v[w..].to_vec();
                                        let fv = vec![fill; extra.len()];
                                        self.cont_assign(&extra, &fv);
                                    }
                                    while v.len() < w {
                                        let n = self.nl.add_net(&format!("{}/{}_unconn{}", iname, p.name, v.len()));
                                        v.push(n);
                                    }
                                    v.truncate(w);
                                    v
                                }
                                Err(e) => return Err(format!("{}: output port '{}': {}", loc, p.name, e)),
                            }
                        }
                    }
                };
                if dims.len() == 1 { self.nl.bus_ranges.insert(format!("{}:{}", iname, p.name), dims[0]); }
                let bits = if self.opts.keep_boundary(&iname) {
                    self.boundary_pins(&iname, &p.name, &dims, dir, bits)
                } else {
                    for (bi, bn) in bit_names(&p.name, &dims).into_iter().enumerate() {
                        if let Some(&n) = bits.get(bi) {
                            self.nl.port_alias.push((iname.clone(), bn, n));
                        }
                    }
                    bits
                };
                let psig = Sig { name: format!("{}/{}", iname, p.name), bits, dims, signed, ty, udims: p.unpacked.len() };
                self.hier.insert(psig.name.replace('/', "."), psig.clone());
                bound.push((p.name.clone(), Some(psig), None));
            }
            // enter child
            let ps = std::mem::replace(&mut self.stack, child_scope);
            let pp = std::mem::replace(&mut self.prefix, cpfx);
            let pg = std::mem::replace(&mut self.gpath, cg);
            for (n, s, i) in bound {
                if let Some(s) = s {
                    self.top().sigs.insert(n.clone(), s);
                }
                if let Some(i) = i {
                    self.top().ifaces.insert(n, i);
                }
            }
            self.depth += 1;
            self.nl.hier.push((iname.clone(), module.clone()));
            let r = self.module_body(&d);
            self.depth -= 1;
            self.stack = ps;
            self.prefix = pp;
            self.gpath = pg;
            r?;
        }
        Ok(())
    }

    /// interface instance: port connections and the interface's own logic (assign / always)
    fn iface_body(&mut self, d: &Module, name: &str, conns: &[(Option<String>, Option<Expr>)], wildcard: bool, params: &[(Option<String>, Expr)], line: &usize) -> ER<()> {
        let Some(ii) = self.lookup_iface(name) else { return Ok(()) };
        let loc = format!("{}:{}", self.cur_file, line);
        // port connections, evaluated in the instantiating scope
        let ports: Vec<&PortDecl> = d.ports.iter().filter(|p| p.iface.is_none()).collect();
        for (k, el) in ii.elems.iter().enumerate() {
            let _ = k;
            for (pi, p) in ports.iter().enumerate() {
                let conn: Option<Expr> = conns.iter().enumerate().find_map(|(ci, (n, e))| match n {
                    Some(n) if n == &p.name => Some(e.clone()),
                    None if ci == pi => Some(e.clone()),
                    _ => None,
                }).flatten().or_else(|| if wildcard { Some(Expr::Id(p.name.clone())) } else { None });
                let Some(ce) = conn else {
                    if p.dir.unwrap_or(Dir::In) == Dir::In {
                        crate::warn!("LINT-33", "{}: input port '{}' of interface instance '{}' is unconnected (floating)", loc, p.name, name);
                    }
                    continue;
                };
                let m = el.get(&p.name).cloned().ok_or_else(|| format!("{}: interface port '{}' missing", loc, p.name))?;
                match p.dir.unwrap_or(Dir::In) {
                    Dir::In => {
                        let v = self.ev_to(&ce, &m, m.bits.len())?;
                        self.cont_assign(&m.bits, &v);
                    }
                    _ => {
                        let t = self.lval(&ce)?;
                        let v = self.ext(m.bits.clone(), t.len(), m.signed);
                        self.cont_assign(&t, &v);
                    }
                }
            }
        }
        let logic: Vec<Item> = d.items.iter().filter(|i| matches!(i, Item::Assign(..) | Item::Always { .. })).cloned().collect();
        if logic.is_empty() {
            return Ok(());
        }
        let mut ov = vec![];
        for (k, (pn, e)) in params.iter().enumerate() {
            ov.push((pn.clone().unwrap_or(format!("#pos{}", k)), self.ceval(e)?));
        }
        let save_file = std::mem::replace(&mut self.cur_file, d.file.clone());
        let save_g = self.gpath.clone();
        let mut r = Ok(());
        for (k, el) in ii.elems.iter().enumerate() {
            let ename = if ii.is_array { format!("{}[{}]", name, ii.lo + k as i64) } else { name.to_string() };
            // interface scope: its parameters, types, functions and members by plain name
            self.stack.push(Scope::default());
            r = self.bind_params(d, &ov, &HashMap::new()).and_then(|_| self.decl_pass(&d.items.iter().filter(|i| matches!(i, Item::Typedef(..) | Item::Func(_) | Item::Param(_))).cloned().collect::<Vec<_>>()));
            if r.is_ok() {
                for (mn, sg) in el {
                    self.top().sigs.insert(mn.clone(), sg.clone());
                }
                self.gpath = format!("{}{}.", save_g, ename);
                r = self.stmt_pass(&logic);
            }
            self.gpath = save_g.clone();
            self.stack.pop();
            if r.is_err() {
                break;
            }
        }
        self.cur_file = save_file;
        r
    }
    /// interface method call `ifc.func(args)`: the function runs with the interface members in scope
    fn iface_method(&mut self, ifn: &str, m: &str, args: &[Expr]) -> ER<(Vec<NetId>, bool)> {
        let ii = self.lookup_iface(ifn).ok_or_else(|| format!("{}: '{}' is not an interface (ELAB-965)", self.cur_file, ifn))?;
        let d = self.lib.modules.get(&ii.def).cloned().ok_or("unknown interface")?;
        let f = d.items.iter().find_map(|i| if let Item::Func(f) = i { if f.name == m { Some(f.clone()) } else { None } } else { None }).ok_or_else(|| format!("{}: interface '{}' has no function '{}'", self.cur_file, ii.def, m))?;
        // arguments are evaluated in the caller scope first
        let mut sc = Scope::default();
        sc.funcs.insert(format!("$m.{}", m), f);
        for (mn, sg) in ii.elems.first().cloned().unwrap_or_default() {
            sc.sigs.insert(mn, sg);
        }
        // evaluate arguments in the caller's scope, then call with the interface scope pushed
        let mut vals = vec![];
        for a in args {
            let (v, sg) = self.ev(a, 0)?;
            vals.push((v, sg));
        }
        self.stack.push(sc);
        let tmp: Vec<String> = (0..vals.len()).map(|k| format!("$marg{}", k)).collect();
        for (k, (v, sg)) in vals.into_iter().enumerate() {
            let n = v.len() as i64;
            let s = Sig { name: tmp[k].clone(), bits: v, dims: vec![(n - 1, 0)], signed: sg, ty: None, udims: 0 };
            self.top().sigs.insert(tmp[k].clone(), s);
        }
        let targs: Vec<Expr> = tmp.iter().map(|t| Expr::Id(t.clone())).collect();
        let r = self.call_func(&format!("$m.{}", m), &targs);
        self.stack.pop();
        r
    }

    /// gate-level netlist reading: instantiate a technology library cell directly
    fn lib_inst(&mut self, cell: &str, pins: &[(String, Dir)], name: &str, conns: &[(Option<String>, Option<Expr>)], loc: &str) -> ER<()> {
        let iname = format!("{}{}{}", self.prefix, self.gpath, name);
        let pd: Vec<(&str, Dir)> = pins.iter().map(|(n, d)| (n.as_str(), *d)).collect();
        let c = self.nl.add_cell(&iname, Kind::Lib(cell.to_string()), &pd);
        for (ci, (pn, e)) in conns.iter().enumerate() {
            let Some(e) = e else { continue };
            let pname = match pn {
                Some(p) => p.clone(),
                None => pins.get(ci).map(|x| x.0.clone()).ok_or_else(|| format!("{}: too many positional connections on {}", loc, cell))?,
            };
            let Some(pi) = pins.iter().position(|x| x.0 == pname) else {
                return Err(format!("{}: library cell '{}' has no pin '{}' (LINK-25)", loc, cell, pname));
            };
            let net = if pins[pi].1 == Dir::In { self.evw(e, 1)?[0] } else { self.lval(e)?[0] };
            self.nl.connect(c, pi, net);
        }
        self.nl.mapped = true;
        Ok(())
    }

    fn bind_iface(&mut self, ce: &Expr, count: usize, k: usize, loc: &str) -> ER<IfInst> {
        let (name, sel): (String, Option<(i64, i64)>) = match ce {
            Expr::Id(n) => (n.clone(), None),
            Expr::Index(b, i) => (expr_name(b).unwrap_or_default(), Some({
                let v = self.ceval(i)? as i64;
                (v, v)
            })),
            Expr::Range(b, a, c) => (expr_name(b).unwrap_or_default(), Some((self.ceval(a)? as i64, self.ceval(c)? as i64))),
            _ => return Err(format!("{}: unsupported interface connection", loc)),
        };
        let ii = self.lookup_iface(&name).ok_or_else(|| format!("{}: '{}' is not an interface instance (ELAB-965)", loc, name))?;
        let mut els: Vec<HashMap<String, Sig>> = ii.elems.clone();
        let mut lo = ii.lo;
        if let Some((a, b)) = sel {
            let (l, h) = (a.min(b), a.max(b));
            els = (l..=h).map(|i| ii.elems[(i - ii.lo) as usize].clone()).collect();
            lo = l;
        }
        if count > 1 && els.len() == count {
            // instance array: one element per instance
            return Ok(IfInst { def: ii.def, lo: 0, elems: vec![els[k].clone()], is_array: false });
        }
        let arr = els.len() > 1 || ii.is_array && sel.map(|(a, b)| a != b).unwrap_or(true);
        Ok(IfInst { def: ii.def, lo, elems: els, is_array: arr })
    }

    #[allow(clippy::too_many_arguments)]
    fn blackbox_inst(&mut self, def: Option<&Module>, module: &str, iname: &str, conns: &[(Option<String>, Option<Expr>)], wildcard: bool, ov: &[(String, i128)], k: usize, count: usize, loc: &str) -> ER<()> {
        let reason: &'static str = match def {
            None => "unresolved",
            Some(d) if d.blackbox => "blackbox",
            Some(d) if d.is_empty() => "empty",
            _ => "user",
        };
        match reason {
            "unresolved" => crate::warn!("LINK-5", "[BLACKBOX] Unable to resolve reference '{}' in '{}' ({}). Creating black box; pin directions inferred from connectivity.", module, iname, loc),
            "empty" => crate::warn!("ELAB-EMPTY", "[EMPTY MODULE] '{}' (instance {}) has ports but no content; kept as empty hierarchical black box", module, iname),
            _ => crate::info!("LINK-BB", "[BLACKBOX] Instance '{}' of '{}' treated as black box (imported without implementation)", iname, module),
        }
        self.bbs.push((iname.to_string(), module.to_string(), reason));
        let mut pins: Vec<(String, Dir, NetId)> = vec![];
        let mut unresolved_dir = vec![];
        if let Some(d) = def {
            // shapes in child param scope
            let saved = std::mem::replace(&mut self.stack, vec![Scope { boundary: true, ..Default::default() }]);
            let r = self.bind_params(d, ov, &HashMap::new());
            let mut shapes = vec![];
            if r.is_ok() {
                for p in &d.ports {
                    shapes.push(if p.iface.is_some() { None } else { Some(self.type_dims(&p.ty, &p.unpacked)) });
                }
            }
            self.stack = saved;
            r?;
            for (pi, p) in d.ports.iter().enumerate() {
                let Some(sh) = shapes[pi].clone() else {
                    crate::warn!("ELAB-966", "Interface port '{}' on black box '{}' left unconnected", p.name, module);
                    continue;
                };
                let (dims, _, _) = sh?;
                let w: usize = dims.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
                let conn: Option<Expr> = conns.iter().enumerate().find_map(|(ci, (n, e))| match n {
                    Some(n) if n == &p.name => Some(e.clone()),
                    None if ci == pi => Some(e.clone()),
                    _ => None,
                }).flatten().or_else(|| if wildcard { Some(Expr::Id(p.name.clone())) } else { None });
                let dir = p.dir.unwrap_or(Dir::InOut);
                let names = bit_names(&p.name, &dims);
                let bits: Vec<NetId> = match conn {
                    None => names.iter().map(|n| self.nl.add_net(&format!("{}/{}", iname, n))).collect(),
                    Some(ce) => {
                        let cw = self.swidth(&ce)?;
                        let slice = count > 1 && cw == w * count;
                        let mut v = if dir == Dir::In { self.evw(&ce, if slice { w * count } else { w })? } else { self.lval(&ce)? };
                        if slice {
                            v = v[k * w..(k + 1) * w].to_vec();
                        }
                        while v.len() < w {
                            let n = self.nl.add_net(&format!("{}/{}_nc{}", iname, p.name, v.len()));
                            v.push(n);
                        }
                        v.truncate(w);
                        v
                    }
                };
                for (n, b) in names.iter().zip(bits) {
                    pins.push((n.clone(), dir, b));
                }
            }
        } else {
            for (ci, (n, e)) in conns.iter().enumerate() {
                let pn = n.clone().unwrap_or(format!("p{}", ci));
                let Some(e) = e else { continue };
                let v = match self.lval(e) {
                    Ok(v) => v,
                    Err(_) => {
                        let w = self.swidth(e)?;
                        self.evw(e, w)?
                    }
                };
                let w = v.len();
                for (bi, b) in v.into_iter().enumerate() {
                    let nm = if w > 1 { format!("{}[{}]", pn, bi) } else { pn.clone() };
                    unresolved_dir.push(pins.len());
                    pins.push((nm, Dir::InOut, b));
                }
            }
        }
        let pdesc: Vec<(&str, Dir)> = pins.iter().map(|(n, d, _)| (n.as_str(), *d)).collect();
        let c = self.nl.add_cell(iname, Kind::BlackBox(module.to_string()), &pdesc);
        self.nl.cell_mut(c).attrs.push(reason.to_string());
        self.nl.cell_mut(c).dont_touch = true;
        for (i, (_, _, n)) in pins.iter().enumerate() {
            self.nl.connect(c, i, *n);
        }
        for i in unresolved_dir {
            self.unresolved_pins.push((c, i));
        }
        Ok(())
    }

    fn finish(&mut self) -> ER<()> {
        // resolve unresolved black-box pin directions
        let ups = std::mem::take(&mut self.unresolved_pins);
        for (c, p) in ups {
            let Some(n) = self.nl.cell(c).pins[p].net else { continue };
            let other_driver = self.nl.net(n).conns.iter().any(|pr| *pr != PinRef::Cell(c, p) && self.nl.is_driver(*pr) && !matches!(pr, PinRef::Cell(cc, _) if *cc == c));
            let d = if other_driver { Dir::In } else { Dir::Out };
            self.nl.cell_mut(c).pins[p].dir = d;
            let cn = self.nl.cell(c).name.clone();
            let pn = self.nl.cell(c).pins[p].name.clone();
            crate::info!("LINK-6", "[BLACKBOX] Inferred direction of pin '{}/{}' as {}", cn, pn, if d == Dir::In { "input" } else { "output" });
        }
        // multi-driven detection
        for n in self.nl.net_ids() {
            let d = self.nl.drivers(n);
            if d.len() > 1 {
                let names: Vec<String> = d.iter().map(|p| self.nl.pin_name(*p)).collect();
                crate::warn!("ELAB-366", "Net '{}' is MULTI-DRIVEN by {} drivers: {}", self.nl.net(n).name, d.len(), names.join(", "));
            }
        }
        Ok(())
    }
}

fn reg_name(net: &str) -> String {
    // u/g[1].x/q[3] -> u/g[1].x/q_reg[3] ; bus[0].valid -> bus[0].valid_reg
    let seg_start = net.rfind('/').map(|i| i + 1).unwrap_or(0);
    let seg = &net[seg_start..];
    // last '.'-separated member outside brackets
    let mut depth = 0;
    let mut mstart = 0;
    for (i, ch) in seg.char_indices() {
        match ch {
            '[' => depth += 1,
            ']' => depth -= 1,
            '.' if depth == 0 => mstart = i + 1,
            _ => {}
        }
    }
    let base = &net[..seg_start + mstart];
    let leaf = &seg[mstart..];
    match leaf.find('[') {
        Some(i) => format!("{}{}_reg{}", base, &leaf[..i], &leaf[i..]),
        None => format!("{}{}_reg", base, leaf),
    }
}

fn cols_len_gt2(v: &[NetId]) -> bool {
    v.len() >= 2
}
