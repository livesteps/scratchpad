//! Elaboration: parameter resolution, generate unrolling, interface (array) flattening,
//! symbolic execution of procedural blocks into a generic gate netlist with:
//!   * structural hashing + constant folding while building (logic sharing)
//!   * latch inference detection (incomplete assignment in comb blocks)
//!   * enable-flop extraction (feedback mux) -> later clock-gating candidates
//!   * async set/reset recognition
//!   * black-box / empty-module handling with explicit log indicators
//!   * multi-driver and non-uniquified-instance bookkeeping

use crate::hdl::ast::*;
use crate::hdl::HdlLib;
use crate::netlist::*;
use std::collections::{BTreeMap, HashMap, HashSet};

type ER<T> = Result<T, String>;

#[derive(Clone, Debug)]
struct Sig {
    name: String,
    bits: Vec<NetId>,
    dims: Vec<(i64, i64)>,
    signed: bool,
    ty: Option<String>,
}
impl Sig {
    fn width(&self) -> usize {
        self.bits.len()
    }
}

#[derive(Clone, Debug, Default)]
struct TypeInfo {
    width: usize,
    signed: bool,
    dims: Vec<(i64, i64)>,
    fields: Vec<(String, usize, usize, Option<String>)>, // name, offset(lsb), width, type
}

#[derive(Clone, Debug)]
struct IfInst {
    def: String,
    lo: i64,
    elems: Vec<HashMap<String, Sig>>,
    is_array: bool,
}

#[derive(Default, Clone)]
struct Scope {
    boundary: bool,
    sigs: HashMap<String, Sig>,
    params: HashMap<String, i128>,
    ptypes: HashMap<String, String>,
    ifaces: HashMap<String, IfInst>,
    types: HashMap<String, TypeInfo>,
    funcs: HashMap<String, Func>,
}

#[derive(Clone)]
struct PState {
    vals: BTreeMap<NetId, (NetId, NetId)>,
    blocking: HashSet<NetId>,
    done: NetId,
}

#[derive(Clone, Debug)]
pub struct ElabOpts {
    pub empty_as_blackbox: bool,
    pub top_params: Vec<(String, i128)>,
    pub blackboxes: HashSet<String>,
    pub adder: String,
    /// library cells available for linking gate-level netlists: name -> pins
    pub lib_cells: HashMap<String, Vec<(String, Dir)>>,
    /// boundary optimization default (true = optimize across hierarchy boundaries)
    pub boundary_default: bool,
    /// per-instance overrides (instance pattern, boundary optimization), last match wins
    pub boundary: Vec<(String, bool)>,
}
impl Default for ElabOpts {
    fn default() -> Self {
        ElabOpts { empty_as_blackbox: true, top_params: vec![], blackboxes: HashSet::new(), adder: "kogge_stone".into(), lib_cells: HashMap::new(), boundary_default: true, boundary: vec![] }
    }
}
impl ElabOpts {
    /// true when the instance's boundary must be preserved (boundary optimization off)
    pub fn keep_boundary(&self, inst: &str) -> bool {
        let mut opt = self.boundary_default;
        for (p, v) in &self.boundary {
            if crate::netlist::glob(p, inst) {
                opt = *v;
            }
        }
        !opt
    }
}

pub struct ElabResult {
    pub netlist: Netlist,
    pub latches: Vec<String>,
    pub multi_inst: Vec<(String, Vec<String>)>,
    pub blackboxes: Vec<(String, String, &'static str)>, // inst, module, reason
    /// effects of synthesis pragmas (full_case / parallel_case / unique / priority)
    pub pragma_notes: Vec<String>,
}

struct Ctx<'a> {
    lib: &'a HdlLib,
    nl: Netlist,
    c0: NetId,
    c1: NetId,
    hash: HashMap<(GOp, NetId, NetId, NetId), NetId>,
    inv: HashMap<NetId, NetId>,
    opts: ElabOpts,
    stack: Vec<Scope>,
    pkg: Scope,
    prefix: String,
    gpath: String,
    procs: Vec<PState>,
    latches: Vec<String>,
    pragma_notes: Vec<String>,
    insts: BTreeMap<String, Vec<String>>,
    bbs: Vec<(String, String, &'static str)>,
    unresolved_pins: Vec<(CellId, usize)>,
    depth: usize,
    gcount: usize,
    cur_file: String,
}

pub fn elaborate(lib: &HdlLib, top: &str, opts: ElabOpts) -> ER<ElabResult> {
    let tm = lib.modules.get(top).ok_or_else(|| format!("Cannot find design '{}' in library WORK (LINK-3)", top))?;
    let mut nl = Netlist::new(top);
    let c0 = nl.add_net("1'b0");
    let c1 = nl.add_net("1'b1");
    nl.add_gen("logic0", GOp::C0, &[], c0);
    nl.add_gen("logic1", GOp::C1, &[], c1);
    let mut cx = Ctx {
        lib,
        nl,
        c0,
        c1,
        hash: HashMap::new(),
        inv: HashMap::new(),
        opts,
        stack: vec![],
        pkg: Scope::default(),
        prefix: String::new(),
        gpath: String::new(),
        procs: vec![],
        latches: vec![],
        pragma_notes: vec![],
        insts: BTreeMap::new(),
        bbs: vec![],
        unresolved_pins: vec![],
        depth: 0,
        gcount: 0,
        cur_file: tm.file.clone(),
    };
    // packages: all packages are visible ($unit + imported)
    for n in &lib.order {
        let m = &lib.modules[n];
        if m.kind == ModKind::Package {
            cx.stack = vec![Scope { boundary: true, ..Default::default() }];
            cx.decl_pass(&m.items)?;
            let s = cx.stack.pop().unwrap();
            cx.pkg.params.extend(s.params);
            cx.pkg.types.extend(s.types);
            cx.pkg.funcs.extend(s.funcs);
            cx.pkg.ptypes.extend(s.ptypes);
        }
    }
    cx.stack = vec![Scope { boundary: true, ..Default::default() }];
    let tp = cx.opts.top_params.clone();
    cx.bind_params(tm, &tp.iter().map(|(n, v)| (n.clone(), *v)).collect::<Vec<_>>(), &HashMap::new())?;
    // top ports
    for p in &tm.ports {
        if let Some((ifn, mp)) = &p.iface {
            let inst = cx.make_iface(ifn, &p.name, &p.unpacked, &[], Some((mp.clone(), true)))?;
            cx.stack.last_mut().unwrap().ifaces.insert(p.name.clone(), inst);
            continue;
        }
        let dir = p.dir.unwrap_or(Dir::In);
        let (dims, signed, ty) = cx.type_dims(&p.ty, &p.unpacked)?;
        let names = bit_names(&p.name, &dims);
        let mut bits = vec![];
        for n in &names {
            let pid = cx.nl.add_port(n, dir);
            bits.push(cx.nl.ports[pid].net.unwrap());
        }
        cx.stack.last_mut().unwrap().sigs.insert(p.name.clone(), Sig { name: p.name.clone(), bits, dims, signed, ty });
    }
    cx.module_body(tm)?;
    cx.finish()?;
    let multi: Vec<(String, Vec<String>)> = cx.insts.iter().filter(|(_, v)| v.len() > 1).map(|(k, v)| (k.clone(), v.clone())).collect();
    Ok(ElabResult { netlist: cx.nl, latches: cx.latches, multi_inst: multi, blackboxes: cx.bbs, pragma_notes: cx.pragma_notes })
}

fn bit_names(name: &str, dims: &[(i64, i64)]) -> Vec<String> {
    if dims.is_empty() {
        return vec![name.to_string()];
    }
    let mut out = vec![];
    let sizes: Vec<usize> = dims.iter().map(|(l, r)| ((l - r).unsigned_abs() + 1) as usize).collect();
    let total: usize = sizes.iter().product();
    for o in 0..total {
        let mut rem = o;
        let mut idx = vec![0i64; dims.len()];
        for k in (0..dims.len()).rev() {
            let off = (rem % sizes[k]) as i64;
            rem /= sizes[k];
            let (l, r) = dims[k];
            idx[k] = if l >= r { r + off } else { r - off };
        }
        let mut s = name.to_string();
        for i in idx {
            s.push_str(&format!("[{}]", i));
        }
        out.push(s);
    }
    out
}

fn dim_off(d: (i64, i64), i: i64) -> Option<usize> {
    let (l, r) = d;
    let (lo, hi) = (l.min(r), l.max(r));
    if i < lo || i > hi {
        return None;
    }
    Some(if l >= r { (i - r) as usize } else { (r - i) as usize })
}

fn expr_mentions(e: &Expr, n: &str) -> bool {
    match e {
        Expr::Id(x) => x == n,
        Expr::Un(_, a) | Expr::Member(a, _) | Expr::Fill(a) => expr_mentions(a, n),
        Expr::Bin(_, a, b) | Expr::Index(a, b) | Expr::Cast(a, b) => expr_mentions(a, n) || expr_mentions(b, n),
        Expr::Range(a, b, c) | Expr::PlusRange(a, b, c, _) | Expr::Cond(a, b, c) => expr_mentions(a, n) || expr_mentions(b, n) || expr_mentions(c, n),
        Expr::Concat(v) | Expr::Call(_, v) => v.iter().any(|x| expr_mentions(x, n)),
        Expr::Repl(a, v) | Expr::Inside(a, v) => expr_mentions(a, n) || v.iter().any(|x| expr_mentions(x, n)),
        _ => false,
    }
}
fn expr_name(e: &Expr) -> Option<String> {
    match e {
        Expr::Id(x) => Some(x.clone()),
        Expr::Index(a, _) | Expr::Member(a, _) => expr_name(a),
        _ => None,
    }
}

impl<'a> Ctx<'a> {
    // ------------------------------------------------------------ gate builder
    fn newnet(&mut self) -> NetId {
        self.gcount += 1;
        let n = format!("{}n{}", self.prefix, self.gcount);
        self.nl.add_net(&n)
    }
    /// Boundary pins (boundary optimization off): one dont_touch zero-delay pass-through per port bit,
    /// so no constant propagation, logic merging, sweeping or mapping crosses the instance boundary.
    fn boundary_pins(&mut self, iname: &str, port: &str, dims: &[(i64, i64)], dir: Dir, bits: Vec<NetId>) -> Vec<NetId> {
        if dir == Dir::InOut {
            crate::warn!("ELAB-420", "inout port '{}' of '{}': boundary preserved without a boundary pin", port, iname);
            return bits;
        }
        let names = bit_names(port, dims);
        let mut out = Vec::with_capacity(bits.len());
        for (i, b) in bits.into_iter().enumerate() {
            let pb = names.get(i).cloned().unwrap_or_else(|| format!("{}[{}]", port, i));
            let nn = self.nl.add_net(&format!("{}/{}", iname, pb));
            let cname = format!("{}/__hp_{}", iname, pb);
            let c = if dir == Dir::In {
                self.nl.add_gen(&cname, GOp::Buf, &[b], nn)
            } else {
                self.nl.add_gen(&cname, GOp::Buf, &[nn], b)
            };
            let cell = self.nl.cell_mut(c);
            cell.dont_touch = true;
            cell.attrs.push("hier_port".into());
            cell.attrs.push(format!("hp:{}:{}:{}", iname, pb, if dir == Dir::In { "i" } else { "o" }));
            out.push(nn);
        }
        out
    }

    fn gate(&mut self, op: GOp, ins: &[NetId]) -> NetId {
        let key = match ins.len() {
            1 => (op, ins[0], 0, 0),
            2 => {
                let (a, b) = if matches!(op, GOp::And | GOp::Or | GOp::Xor) && ins[0] > ins[1] { (ins[1], ins[0]) } else { (ins[0], ins[1]) };
                (op, a, b, 0)
            }
            _ => (op, ins[0], ins[1], ins[2]),
        };
        if let Some(&n) = self.hash.get(&key) {
            return n;
        }
        let out = self.newnet();
        self.gcount += 1;
        let cname = format!("{}U{}", self.prefix, self.gcount);
        self.nl.add_gen(&cname, op, ins, out);
        self.hash.insert(key, out);
        out
    }
    fn not(&mut self, a: NetId) -> NetId {
        if a == self.c0 {
            return self.c1;
        }
        if a == self.c1 {
            return self.c0;
        }
        if let Some(&x) = self.inv.get(&a) {
            return x;
        }
        let o = self.gate(GOp::Not, &[a]);
        self.inv.insert(a, o);
        self.inv.insert(o, a);
        o
    }
    fn is_compl(&self, a: NetId, b: NetId) -> bool {
        self.inv.get(&a) == Some(&b)
    }
    fn and(&mut self, a: NetId, b: NetId) -> NetId {
        if a == self.c0 || b == self.c0 || self.is_compl(a, b) {
            return self.c0;
        }
        if a == self.c1 {
            return b;
        }
        if b == self.c1 || a == b {
            return a;
        }
        self.gate(GOp::And, &[a, b])
    }
    fn or(&mut self, a: NetId, b: NetId) -> NetId {
        if a == self.c1 || b == self.c1 || self.is_compl(a, b) {
            return self.c1;
        }
        if a == self.c0 {
            return b;
        }
        if b == self.c0 || a == b {
            return a;
        }
        self.gate(GOp::Or, &[a, b])
    }
    fn xor(&mut self, a: NetId, b: NetId) -> NetId {
        if a == self.c0 {
            return b;
        }
        if b == self.c0 {
            return a;
        }
        if a == self.c1 {
            return self.not(b);
        }
        if b == self.c1 {
            return self.not(a);
        }
        if a == b {
            return self.c0;
        }
        if self.is_compl(a, b) {
            return self.c1;
        }
        self.gate(GOp::Xor, &[a, b])
    }
    /// s ? b : a
    fn mux(&mut self, s: NetId, a: NetId, b: NetId) -> NetId {
        if s == self.c0 || a == b {
            return a;
        }
        if s == self.c1 {
            return b;
        }
        if a == self.c0 && b == self.c1 {
            return s;
        }
        if a == self.c1 && b == self.c0 {
            return self.not(s);
        }
        if a == self.c0 {
            return self.and(s, b);
        }
        if b == self.c0 {
            let ns = self.not(s);
            return self.and(ns, a);
        }
        if b == self.c1 {
            return self.or(s, a);
        }
        if a == self.c1 {
            let ns = self.not(s);
            return self.or(ns, b);
        }
        self.gate(GOp::Mux, &[s, a, b])
    }
    fn reduce(&mut self, op: GOp, v: &[NetId]) -> NetId {
        if v.is_empty() {
            return if op == GOp::And { self.c1 } else { self.c0 };
        }
        let mut cur: Vec<NetId> = v.to_vec();
        while cur.len() > 1 {
            let mut nx = vec![];
            for ch in cur.chunks(2) {
                nx.push(if ch.len() == 2 {
                    match op {
                        GOp::And => self.and(ch[0], ch[1]),
                        GOp::Or => self.or(ch[0], ch[1]),
                        _ => self.xor(ch[0], ch[1]),
                    }
                } else {
                    ch[0]
                });
            }
            cur = nx;
        }
        cur[0]
    }
    fn cbits(&self, v: i128, w: usize) -> Vec<NetId> {
        (0..w).map(|k| if k < 127 && (v >> k) & 1 == 1 { self.c1 } else { self.c0 }).collect()
    }
    fn ext(&self, mut v: Vec<NetId>, w: usize, signed: bool) -> Vec<NetId> {
        if v.len() >= w {
            v.truncate(w);
            return v;
        }
        let f = if signed && !v.is_empty() { *v.last().unwrap() } else { self.c0 };
        v.resize(w, f);
        v
    }
    fn add(&mut self, a: &[NetId], b: &[NetId], cin: NetId) -> (Vec<NetId>, NetId) {
        if self.opts.adder == "kogge_stone" && a.len() >= 4 {
            return self.add_ks(a, b, cin);
        }
        let mut c = cin;
        let mut s = vec![];
        for k in 0..a.len() {
            let x = self.xor(a[k], b[k]);
            s.push(self.xor(x, c));
            let g = self.and(a[k], b[k]);
            let p = self.and(c, x);
            c = self.or(g, p);
        }
        (s, c)
    }
    /// Parallel-prefix (Kogge-Stone) adder: log2(n) carry depth.
    fn add_ks(&mut self, a: &[NetId], b: &[NetId], cin: NetId) -> (Vec<NetId>, NetId) {
        let n = a.len();
        let p0: Vec<NetId> = (0..n).map(|k| self.xor(a[k], b[k])).collect();
        let mut g: Vec<NetId> = (0..n).map(|k| self.and(a[k], b[k])).collect();
        let mut p = p0.clone();
        // fold carry-in into bit 0 generate
        let t = self.and(p[0], cin);
        g[0] = self.or(g[0], t);
        let mut d = 1;
        while d < n {
            let (gp, pp) = (g.clone(), p.clone());
            for k in d..n {
                let t = self.and(pp[k], gp[k - d]);
                g[k] = self.or(gp[k], t);
                p[k] = self.and(pp[k], pp[k - d]);
            }
            d *= 2;
        }
        let mut s = vec![];
        for k in 0..n {
            let c = if k == 0 { cin } else { g[k - 1] };
            s.push(self.xor(p0[k], c));
        }
        (s, g[n - 1])
    }
    fn sub(&mut self, a: &[NetId], b: &[NetId]) -> (Vec<NetId>, NetId) {
        let nb: Vec<NetId> = b.iter().map(|x| self.not(*x)).collect();
        let c1 = self.c1;
        self.add(a, &nb, c1)
    }
    fn mul(&mut self, a: &[NetId], b: &[NetId], w: usize) -> Vec<NetId> {
        if self.opts.adder == "kogge_stone" {
            return self.mul_csa(a, b, w);
        }
        let mut acc = vec![self.c0; w];
        for (i, &bi) in b.iter().enumerate().take(w) {
            let mut pp = vec![self.c0; w];
            for j in 0..w - i {
                if j < a.len() {
                    pp[i + j] = self.and(a[j], bi);
                }
            }
            let c0 = self.c0;
            acc = self.add(&acc, &pp, c0).0;
        }
        acc
    }
    /// Carry-save (Wallace-style) multiplier: partial-product columns reduced with
    /// 3:2 / 2:2 compressors to two rows, then a parallel-prefix final adder.
    fn mul_csa(&mut self, a: &[NetId], b: &[NetId], w: usize) -> Vec<NetId> {
        let mut cols: Vec<Vec<NetId>> = vec![vec![]; w];
        for (i, &bi) in b.iter().enumerate().take(w) {
            if bi == self.c0 {
                continue;
            }
            for (j, &aj) in a.iter().enumerate() {
                if i + j >= w {
                    break;
                }
                let pp = self.and(aj, bi);
                if pp != self.c0 {
                    cols[i + j].push(pp);
                }
            }
        }
        loop {
            if cols.iter().all(|c| c.len() <= 2) {
                break;
            }
            let mut nx: Vec<Vec<NetId>> = vec![vec![]; w];
            for k in 0..w {
                let col = std::mem::take(&mut cols[k]);
                let mut i = 0;
                while col.len() - i >= 3 {
                    let (x, y, z) = (col[i], col[i + 1], col[i + 2]);
                    let t = self.xor(x, y);
                    nx[k].push(self.xor(t, z));
                    let g = self.and(x, y);
                    let p = self.and(t, z);
                    let c = self.or(g, p);
                    if k + 1 < w {
                        nx[k + 1].push(c);
                    }
                    i += 3;
                }
                if col.len() - i == 2 && cols_len_gt2(&nx[k]) {
                    let (x, y) = (col[i], col[i + 1]);
                    nx[k].push(self.xor(x, y));
                    let c = self.and(x, y);
                    if k + 1 < w {
                        nx[k + 1].push(c);
                    }
                    i += 2;
                }
                nx[k].extend_from_slice(&col[i..]);
            }
            cols = nx;
        }
        let r0: Vec<NetId> = cols.iter().map(|c| c.first().copied().unwrap_or(self.c0)).collect();
        let r1: Vec<NetId> = cols.iter().map(|c| c.get(1).copied().unwrap_or(self.c0)).collect();
        let c0 = self.c0;
        self.add(&r0, &r1, c0).0
    }
    fn divmod(&mut self, a: &[NetId], b: &[NetId]) -> (Vec<NetId>, Vec<NetId>) {
        let w = a.len();
        let mut rem = vec![self.c0; w + 1];
        let bb = self.ext(b.to_vec(), w + 1, false);
        let mut q = vec![self.c0; w];
        for i in (0..w).rev() {
            rem.pop();
            rem.insert(0, a[i]);
            let (d, carry) = self.sub(&rem, &bb);
            q[i] = carry; // carry=1 => rem>=b
            rem = (0..w + 1).map(|k| self.mux(carry, rem[k], d[k])).collect();
        }
        rem.truncate(w);
        (q, rem)
    }
    fn eq(&mut self, a: &[NetId], b: &[NetId]) -> NetId {
        let v: Vec<NetId> = a.iter().zip(b).map(|(x, y)| {
            let t = self.xor(*x, *y);
            self.not(t)
        }).collect();
        self.reduce(GOp::And, &v)
    }
    fn lt(&mut self, a: &[NetId], b: &[NetId], signed: bool) -> NetId {
        let (mut a, mut b) = (a.to_vec(), b.to_vec());
        if signed && !a.is_empty() {
            let k = a.len() - 1;
            a[k] = self.not(a[k]);
            b[k] = self.not(b[k]);
        }
        let (_, c) = self.sub(&a, &b);
        self.not(c)
    }
    fn shift(&mut self, v: &[NetId], amt: &[NetId], left: bool, arith: bool) -> Vec<NetId> {
        let w = v.len();
        let fill = if arith && !left { *v.last().unwrap_or(&self.c0) } else { self.c0 };
        let mut cur = v.to_vec();
        let mut over = self.c0;
        for (k, &a) in amt.iter().enumerate() {
            let sh = 1usize.checked_shl(k as u32).unwrap_or(usize::MAX);
            if sh >= w {
                over = self.or(over, a);
                continue;
            }
            let shifted: Vec<NetId> = (0..w).map(|i| {
                if left {
                    if i >= sh { cur[i - sh] } else { self.c0 }
                } else if i + sh < w {
                    cur[i + sh]
                } else {
                    fill
                }
            }).collect();
            cur = (0..w).map(|i| self.mux(a, cur[i], shifted[i])).collect();
        }
        (0..w).map(|i| self.mux(over, cur[i], fill)).collect()
    }
    fn to_bool(&mut self, v: &[NetId]) -> NetId {
        self.reduce(GOp::Or, v)
    }

    // ------------------------------------------------------------ scopes
    fn lookup_sig(&self, n: &str) -> Option<Sig> {
        for s in self.stack.iter().rev() {
            if s.params.contains_key(n) {
                return None;
            }
            if let Some(x) = s.sigs.get(n) {
                return Some(x.clone());
            }
            if s.boundary {
                break;
            }
        }
        None
    }
    fn lookup_param(&self, n: &str) -> Option<i128> {
        for s in self.stack.iter().rev() {
            if let Some(x) = s.params.get(n) {
                return Some(*x);
            }
            if s.sigs.contains_key(n) {
                return None;
            }
            if s.boundary {
                break;
            }
        }
        self.pkg.params.get(n).copied()
    }
    fn lookup_iface(&self, n: &str) -> Option<IfInst> {
        for s in self.stack.iter().rev() {
            if let Some(x) = s.ifaces.get(n) {
                return Some(x.clone());
            }
            if s.boundary {
                break;
            }
        }
        None
    }
    fn lookup_type(&self, n: &str) -> Option<TypeInfo> {
        for s in self.stack.iter().rev() {
            if let Some(pt) = s.ptypes.get(n) {
                return self.lookup_type(&pt.clone());
            }
            if let Some(x) = s.types.get(n) {
                return Some(x.clone());
            }
            if s.boundary {
                break;
            }
        }
        if let Some(pt) = self.pkg.ptypes.get(n) {
            return self.lookup_type(&pt.clone());
        }
        match n {
            "logic" | "bit" | "reg" => return Some(TypeInfo { width: 1, ..Default::default() }),
            "int" | "integer" => return Some(TypeInfo { width: 32, signed: true, dims: vec![(31, 0)], ..Default::default() }),
            "byte" => return Some(TypeInfo { width: 8, signed: true, dims: vec![(7, 0)], ..Default::default() }),
            _ => {}
        }
        self.pkg.types.get(n).cloned()
    }
    fn lookup_func(&self, n: &str) -> Option<Func> {
        for s in self.stack.iter().rev() {
            if let Some(x) = s.funcs.get(n) {
                return Some(x.clone());
            }
            if s.boundary {
                break;
            }
        }
        self.pkg.funcs.get(n).cloned()
    }
    fn top(&mut self) -> &mut Scope {
        self.stack.last_mut().unwrap()
    }

    fn type_dims(&mut self, t: &DType, unpacked: &[(Expr, Expr)]) -> ER<(Vec<(i64, i64)>, bool, Option<String>)> {
        let mut dims = vec![];
        for (a, b) in unpacked {
            dims.push((self.ceval(a)? as i64, self.ceval(b)? as i64));
        }
        let (packed, signed, ty) = self.type_info(t)?;
        dims.extend(packed);
        Ok((dims, signed, ty))
    }
    /// packed dims, signed, struct type name
    fn type_info(&mut self, t: &DType) -> ER<(Vec<(i64, i64)>, bool, Option<String>)> {
        match t {
            DType::Logic { signed, packed } => {
                let mut d = vec![];
                for (a, b) in packed {
                    d.push((self.ceval(a)? as i64, self.ceval(b)? as i64));
                }
                Ok((d, *signed, None))
            }
            DType::Named { name, packed } => {
                let ti = self.lookup_type(name).ok_or_else(|| format!("{}: unknown type '{}' (ELAB-1001)", self.cur_file, name))?;
                let mut d = vec![];
                for (a, b) in packed {
                    d.push((self.ceval(a)? as i64, self.ceval(b)? as i64));
                }
                if ti.dims.is_empty() && ti.width > 1 {
                    d.push((ti.width as i64 - 1, 0));
                } else {
                    d.extend(ti.dims.iter().copied());
                }
                Ok((d, ti.signed, if ti.fields.is_empty() { None } else { Some(name.clone()) }))
            }
            DType::Enum { base, items } => {
                let (d, s, _) = self.type_info(base)?;
                let mut v: i128 = 0;
                for (n, e) in items {
                    if let Some(e) = e {
                        v = self.ceval(e)?;
                    }
                    self.top().params.insert(n.clone(), v);
                    v += 1;
                }
                Ok((d, s, None))
            }
            DType::Struct { .. } => {
                let ti = self.struct_info(t)?;
                let nm = format!("$anon_struct{}", self.gcount);
                self.gcount += 1;
                let w = ti.width;
                self.top().types.insert(nm.clone(), ti);
                Ok((vec![(w as i64 - 1, 0)], false, Some(nm)))
            }
        }
    }
    fn struct_info(&mut self, t: &DType) -> ER<TypeInfo> {
        if let DType::Struct { fields, .. } = t {
            let mut fl = vec![];
            let mut tot = 0usize;
            let mut infos = vec![];
            for (n, ft) in fields {
                let (d, _, ty) = self.type_info(ft)?;
                let w: usize = d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
                infos.push((n.clone(), w, ty));
                tot += w;
            }
            // first field is MSB
            let mut off = tot;
            for (n, w, ty) in infos {
                off -= w;
                fl.push((n, off, w, ty));
            }
            return Ok(TypeInfo { width: tot, signed: false, dims: vec![], fields: fl });
        }
        Err("not a struct".into())
    }

    fn mk_sig(&mut self, name: &str, ty: &DType, unpacked: &[(Expr, Expr)]) -> ER<Sig> {
        let (dims, signed, tyn) = self.type_dims(ty, unpacked)?;
        let names = bit_names(&format!("{}{}{}", self.prefix, self.gpath, name), &dims);
        let bits = names.iter().map(|n| self.nl.add_net(n)).collect();
        Ok(Sig { name: format!("{}{}{}", self.prefix, self.gpath, name), bits, dims, signed, ty: tyn })
    }

    // ------------------------------------------------------------ constant eval
    fn ceval(&mut self, e: &Expr) -> ER<i128> {
        Ok(match e {
            Expr::Num { bits, signed, width, fill } => {
                if *fill {
                    return Ok(if bits[0] == 1 { -1 } else { 0 });
                }
                if bits.iter().any(|b| *b >= 2) {
                    return Err("x/z in constant expression".into());
                }
                let mut v: i128 = 0;
                for (k, b) in bits.iter().enumerate().take(127) {
                    if *b == 1 {
                        v |= 1 << k
                    }
                }
                let w = width.map(|w| w as usize).unwrap_or(bits.len());
                if *signed && w < 127 && w > 0 && (v >> (w - 1)) & 1 == 1 {
                    v -= 1 << w;
                }
                v
            }
            Expr::Id(n) => match self.lookup_param(n) {
                Some(v) => v,
                None => return Err(format!("'{}' is not a constant", n)),
            },
            Expr::Scoped(_, n) => self.pkg.params.get(n).copied().ok_or_else(|| format!("unknown package item {}", n))?,
            Expr::Un(op, a) => {
                let v = self.ceval(a)?;
                match op.as_str() {
                    "-" => -v,
                    "+" => v,
                    "!" => (v == 0) as i128,
                    "~" => !v,
                    _ => return Err("unsupported const unary".into()),
                }
            }
            Expr::Bin(op, a, b) => {
                let x = self.ceval(a)?;
                let y = self.ceval(b)?;
                match op.as_str() {
                    "+" => x + y,
                    "-" => x - y,
                    "*" => x * y,
                    "/" => {
                        if y == 0 {
                            return Err("division by zero".into());
                        }
                        x / y
                    }
                    "%" => {
                        if y == 0 {
                            return Err("division by zero".into());
                        }
                        x % y
                    }
                    "**" => x.pow(y.max(0) as u32),
                    "<<" | "<<<" => x << y,
                    ">>" | ">>>" => x >> y,
                    "&" => x & y,
                    "|" => x | y,
                    "^" => x ^ y,
                    "==" | "===" => (x == y) as i128,
                    "!=" | "!==" => (x != y) as i128,
                    "<" => (x < y) as i128,
                    "<=" => (x <= y) as i128,
                    ">" => (x > y) as i128,
                    ">=" => (x >= y) as i128,
                    "&&" => (x != 0 && y != 0) as i128,
                    "||" => (x != 0 || y != 0) as i128,
                    _ => return Err(format!("unsupported const op {}", op)),
                }
            }
            Expr::Cond(c, a, b) => {
                if self.ceval(c)? != 0 {
                    self.ceval(a)?
                } else {
                    self.ceval(b)?
                }
            }
            Expr::Call(f, args) => match f.as_str() {
                "$clog2" => {
                    let v = self.ceval(&args[0])?;
                    let mut r = 0;
                    while (1i128 << r) < v {
                        r += 1
                    }
                    r
                }
                "$max1" => self.ceval(&args[0])?.max(1),
                "$bits" => self.swidth_of_name(&args[0])? as i128,
                "$signed" | "$unsigned" => self.ceval(&args[0])?,
                _ => return Err(format!("function {} not constant", f)),
            },
            Expr::Cast(_, b) => self.ceval(b)?,
            Expr::Concat(v) if v.len() == 1 => self.ceval(&v[0])?,
            _ => return Err("not a constant expression".into()),
        })
    }
    fn swidth_of_name(&mut self, e: &Expr) -> ER<usize> {
        if let Expr::Id(n) = e {
            if let Some(t) = self.lookup_type(n) {
                if self.lookup_sig(n).is_none() {
                    return Ok(if t.dims.is_empty() { t.width.max(1) } else { t.dims.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product() });
                }
            }
        }
        self.swidth(e)
    }

    // ------------------------------------------------------------ name resolution
    fn sig_of(&mut self, e: &Expr) -> ER<Option<Sig>> {
        match e {
            Expr::Id(n) => Ok(self.lookup_sig(n)),
            Expr::Member(b, m) => {
                // interface member?
                let (ifn, idx) = match &**b {
                    Expr::Id(n) => (Some(n.clone()), None),
                    Expr::Index(x, i) => match &**x {
                        Expr::Id(n) => (Some(n.clone()), Some(i.clone())),
                        _ => (None, None),
                    },
                    _ => (None, None),
                };
                if let Some(ifn) = ifn {
                    if let Some(ii) = self.lookup_iface(&ifn) {
                        let k = match idx {
                            Some(i) => (self.ceval(&i)? as i64 - ii.lo) as usize,
                            None => 0,
                        };
                        let el = ii.elems.get(k).ok_or_else(|| format!("interface array index out of range on {}", ifn))?;
                        return el.get(m).cloned().map(Some).ok_or_else(|| format!("interface '{}' has no member '{}'", ii.def, m));
                    }
                }
                // struct member
                let Some(bs) = self.sig_of(b)? else { return Ok(None) };
                let tn = bs.ty.clone().ok_or_else(|| format!("member access '.{}' on non-struct", m))?;
                let ti = self.lookup_type(&tn).ok_or("unknown struct type")?;
                let (_, off, w, fty) = ti.fields.iter().find(|f| f.0 == *m).cloned().ok_or_else(|| format!("struct has no member {}", m))?;
                let sub_ty = fty.clone();
                let dims = match &sub_ty {
                    Some(t) => vec![(self.lookup_type(t).map(|x| x.width).unwrap_or(w) as i64 - 1, 0)],
                    None => {
                        if w > 1 {
                            vec![(w as i64 - 1, 0)]
                        } else {
                            vec![]
                        }
                    }
                };
                Ok(Some(Sig { name: format!("{}.{}", bs.name, m), bits: bs.bits[off..off + w].to_vec(), dims, signed: false, ty: sub_ty }))
            }
            Expr::Index(b, i) => {
                let Some(bs) = self.sig_of(b)? else { return Ok(None) };
                let Ok(iv) = self.ceval(i) else { return Ok(None) };
                if bs.dims.is_empty() {
                    return Err("bit-select of scalar".into());
                }
                let ew: usize = bs.dims[1..].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product();
                match dim_off(bs.dims[0], iv as i64) {
                    Some(o) => Ok(Some(Sig { name: format!("{}[{}]", bs.name, iv), bits: bs.bits[o * ew..(o + 1) * ew].to_vec(), dims: bs.dims[1..].to_vec(), signed: false, ty: if bs.dims.len() <= 2 { bs.ty.clone() } else { None } })),
                    None => {
                        crate::warn!("ELAB-147", "{}: index {} out of range for '{}'", self.cur_file, iv, expr_name(b).unwrap_or_default());
                        Ok(Some(Sig { name: String::new(), bits: vec![self.c0; ew], dims: bs.dims[1..].to_vec(), signed: false, ty: None }))
                    }
                }
            }
            Expr::Range(b, x, y) => {
                let Some(bs) = self.sig_of(b)? else { return Ok(None) };
                let (Ok(l), Ok(r)) = (self.ceval(x), self.ceval(y)) else { return Ok(None) };
                if bs.dims.is_empty() {
                    return Err("part-select of scalar".into());
                }
                let ew: usize = bs.dims[1..].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product();
                let (o1, o2) = (dim_off(bs.dims[0], l as i64), dim_off(bs.dims[0], r as i64));
                let (Some(o1), Some(o2)) = (o1, o2) else { return Err(format!("part-select [{}:{}] out of range", l, r)) };
                let (lo, hi) = (o1.min(o2), o1.max(o2));
                let mut d = vec![((hi - lo) as i64, 0)];
                d.extend(bs.dims[1..].iter().copied());
                Ok(Some(Sig { name: String::new(), bits: bs.bits[lo * ew..(hi + 1) * ew].to_vec(), dims: d, signed: false, ty: None }))
            }
            Expr::PlusRange(b, s, w, up) => {
                let Some(bs) = self.sig_of(b)? else { return Ok(None) };
                let (Ok(sv), Ok(wv)) = (self.ceval(s), self.ceval(w)) else { return Ok(None) };
                let (l, r) = if *up { (sv + wv - 1, sv) } else { (sv, sv - wv + 1) };
                let (l, r) = if bs.dims.first().map(|d| d.0 < d.1).unwrap_or(false) { (r, l) } else { (l, r) };
                self.sig_of(&Expr::Range(b.clone(), Box::new(Expr::int(l as i64)), Box::new(Expr::int(r as i64))))
            }
            _ => Ok(None),
        }
    }

    fn swidth(&mut self, e: &Expr) -> ER<usize> {
        Ok(match e {
            Expr::Num { width, bits, fill, .. } => {
                if *fill {
                    1
                } else {
                    width.map(|w| w as usize).unwrap_or(bits.len().max(32))
                }
            }
            Expr::Str(s) => s.len() * 8,
            Expr::Id(n) => {
                if let Some(s) = self.lookup_sig(n) {
                    s.width()
                } else if self.lookup_param(n).is_some() {
                    32
                } else {
                    1
                }
            }
            Expr::Scoped(..) => 32,
            Expr::Index(b, i) => {
                if let Some(s) = self.sig_of(e)? {
                    s.width()
                } else if let Some(bs) = self.sig_of(b)? {
                    let _ = i;
                    bs.dims[1..].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product()
                } else {
                    1
                }
            }
            Expr::Range(_, a, b) => {
                if let Some(s) = self.sig_of(e)? {
                    s.width()
                } else {
                    ((self.ceval(a)? - self.ceval(b)?).unsigned_abs() + 1) as usize
                }
            }
            Expr::PlusRange(_, _, w, _) => self.ceval(w)? as usize,
            Expr::Member(..) => self.sig_of(e)?.map(|s| s.width()).unwrap_or(1),
            Expr::Un(op, a) => match op.as_str() {
                "~" | "-" | "+" => self.swidth(a)?,
                _ => 1,
            },
            Expr::Bin(op, a, b) => match op.as_str() {
                "==" | "!=" | "===" | "!==" | "<" | "<=" | ">" | ">=" | "&&" | "||" | "==?" | "!=?" => 1,
                "<<" | ">>" | "<<<" | ">>>" | "**" => self.swidth(a)?,
                _ => self.swidth(a)?.max(self.swidth(b)?),
            },
            Expr::Cond(_, a, b) => self.swidth(a)?.max(self.swidth(b)?),
            Expr::Concat(v) => {
                let mut s = 0;
                for x in v {
                    s += self.swidth(x)?
                }
                s
            }
            Expr::Repl(n, v) => {
                let k = self.ceval(n)? as usize;
                let mut s = 0;
                for x in v {
                    s += self.swidth(x)?
                }
                s * k
            }
            Expr::Call(f, args) => match f.as_str() {
                "$signed" | "$unsigned" => self.swidth(&args[0])?,
                "$clog2" | "$bits" => 32,
                _ => {
                    if let Some(fd) = self.lookup_func(f) {
                        let (d, _, _) = self.type_info(&fd.ret)?;
                        d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1)
                    } else {
                        1
                    }
                }
            },
            Expr::Cast(w, x) => match &**w {
                Expr::Id(t) if self.lookup_type(t).is_some() && self.lookup_param(t).is_none() => self.swidth_of_name(w)?,
                _ => self.ceval(w).map(|v| v as usize).or_else(|_| self.swidth(x))?,
            },
            Expr::Inside(..) => 1,
            Expr::Fill(_) => 1,
        })
    }

    fn read(&mut self, n: NetId) -> NetId {
        if let Some(ps) = self.procs.last() {
            if ps.blocking.contains(&n) {
                if let Some(&(v, e)) = ps.vals.get(&n) {
                    if e == self.c1 {
                        return v;
                    }
                    return self.mux(e, n, v);
                }
            }
        }
        n
    }

    // ------------------------------------------------------------ expression eval
    fn ev(&mut self, e: &Expr, cw: usize) -> ER<(Vec<NetId>, bool)> {
        let sw = self.swidth(e)?;
        let w = cw.max(sw).max(1);
        let (bits, signed) = self.ev_raw(e, w)?;
        Ok((self.ext(bits, w, signed), signed))
    }
    fn evw(&mut self, e: &Expr, w: usize) -> ER<Vec<NetId>> {
        let (b, s) = self.ev(e, w)?;
        Ok(self.ext(b, w, s))
    }
    fn ev_raw(&mut self, e: &Expr, w: usize) -> ER<(Vec<NetId>, bool)> {
        match e {
            Expr::Num { bits, signed, fill, width } => {
                if *fill {
                    let b = if bits[0] == 1 { self.c1 } else { self.c0 };
                    return Ok((vec![b; w], false));
                }
                let v: Vec<NetId> = bits.iter().map(|b| if *b == 1 { self.c1 } else { self.c0 }).collect();
                let sg = *signed && width.is_some() || (*signed && width.is_none());
                Ok((v, sg))
            }
            Expr::Str(s) => {
                let mut v = vec![];
                for ch in s.bytes().rev() {
                    for k in 0..8 {
                        v.push(if (ch >> k) & 1 == 1 { self.c1 } else { self.c0 });
                    }
                }
                Ok((v, false))
            }
            Expr::Id(n) => {
                if let Some(p) = self.lookup_param(n) {
                    return Ok((self.cbits(p, w.max(32)), true));
                }
                match self.lookup_sig(n) {
                    Some(s) => Ok((s.bits.iter().map(|b| self.read(*b)).collect(), s.signed)),
                    None => {
                        if self.lookup_iface(n).is_some() {
                            return Err(format!("interface '{}' used in expression", n));
                        }
                        Err(format!("{}: undeclared identifier '{}' (ELAB-337)", self.cur_file, n))
                    }
                }
            }
            Expr::Scoped(_, n) => {
                let p = self.pkg.params.get(n).copied().ok_or_else(|| format!("unknown package item {}", n))?;
                Ok((self.cbits(p, w.max(32)), true))
            }
            Expr::Index(b, i) => {
                if let Some(s) = self.sig_of(e)? {
                    return Ok((s.bits.iter().map(|x| self.read(*x)).collect(), false));
                }
                // dynamic index
                let (elems, ew) = match self.sig_of(b)? {
                    Some(bs) => {
                        let d0 = *bs.dims.first().ok_or("index of scalar")?;
                        let ew: usize = bs.dims[1..].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product();
                        let bits: Vec<NetId> = bs.bits.iter().map(|x| self.read(*x)).collect();
                        let (lo, hi) = (d0.0.min(d0.1), d0.0.max(d0.1));
                        let mut el: BTreeMap<i64, Vec<NetId>> = BTreeMap::new();
                        for idx in lo..=hi {
                            let o = dim_off(d0, idx).unwrap();
                            el.insert(idx, bits[o * ew..(o + 1) * ew].to_vec());
                        }
                        (el, ew)
                    }
                    None => {
                        let (bv, _) = self.ev(b, 0)?;
                        let mut el = BTreeMap::new();
                        for (k, x) in bv.iter().enumerate() {
                            el.insert(k as i64, vec![*x]);
                        }
                        (el, 1)
                    }
                };
                let (iv, _) = self.ev(i, 0)?;
                Ok((self.index_mux(&elems, &iv, ew), false))
            }
            Expr::Range(..) | Expr::Member(..) => {
                let s = self.sig_of(e)?.ok_or_else(|| "unsupported select expression".to_string())?;
                Ok((s.bits.iter().map(|x| self.read(*x)).collect(), false))
            }
            Expr::PlusRange(b, st, wd, up) => {
                if let Some(s) = self.sig_of(e)? {
                    return Ok((s.bits.iter().map(|x| self.read(*x)).collect(), false));
                }
                // dynamic base: shift right by (base - lsb)
                let wv = self.ceval(wd)? as usize;
                let (bv, lsb) = match self.sig_of(b)? {
                    Some(bs) => (bs.bits.iter().map(|x| self.read(*x)).collect::<Vec<_>>(), bs.dims.first().map(|d| d.0.min(d.1)).unwrap_or(0)),
                    None => (self.ev(b, 0)?.0, 0),
                };
                let mut sexpr = (**st).clone();
                if !*up {
                    sexpr = Expr::bin("-", sexpr, Expr::int(wv as i64 - 1));
                }
                if lsb != 0 {
                    sexpr = Expr::bin("-", sexpr, Expr::int(lsb));
                }
                let (amt, _) = self.ev(&sexpr, 0)?;
                let r = self.shift(&bv, &amt, false, false);
                Ok((r[..wv.min(r.len())].to_vec(), false))
            }
            Expr::Un(op, a) => {
                match op.as_str() {
                    "~" => {
                        let (v, s) = self.ev(a, w)?;
                        Ok((v.iter().map(|x| self.not(*x)).collect(), s))
                    }
                    "-" => {
                        let (v, s) = self.ev(a, w)?;
                        let z = vec![self.c0; v.len()];
                        Ok((self.sub(&z, &v).0, s))
                    }
                    "+" => self.ev(a, w),
                    "!" => {
                        let (v, _) = self.ev(a, 0)?;
                        let b = self.to_bool(&v);
                        Ok((vec![self.not(b)], false))
                    }
                    _ => {
                        let (v, _) = self.ev(a, 0)?;
                        let r = match op.as_str() {
                            "&" => self.reduce(GOp::And, &v),
                            "|" => self.reduce(GOp::Or, &v),
                            "^" => self.reduce(GOp::Xor, &v),
                            "~&" => {
                                let x = self.reduce(GOp::And, &v);
                                self.not(x)
                            }
                            "~|" => {
                                let x = self.reduce(GOp::Or, &v);
                                self.not(x)
                            }
                            _ => {
                                let x = self.reduce(GOp::Xor, &v);
                                self.not(x)
                            }
                        };
                        Ok((vec![r], false))
                    }
                }
            }
            Expr::Bin(op, a, b) => self.ev_bin(op, a, b, w),
            Expr::Cond(c, a, b) => {
                let (cv, _) = self.ev(c, 0)?;
                let cb = self.to_bool(&cv);
                let (av, sa) = self.ev(a, w)?;
                let (bv, sb) = self.ev(b, w)?;
                let av = self.ext(av, w, sa);
                let bv = self.ext(bv, w, sb);
                Ok(((0..w).map(|k| self.mux(cb, bv[k], av[k])).collect(), sa && sb))
            }
            Expr::Concat(v) => {
                let mut out = vec![];
                for x in v.iter().rev() {
                    let sw = self.swidth(x)?;
                    out.extend(self.evw(x, sw)?);
                }
                Ok((out, false))
            }
            Expr::Repl(n, v) => {
                let k = self.ceval(n)? as usize;
                let one = self.ev_raw(&Expr::Concat(v.clone()), 0)?.0;
                let mut out = vec![];
                for _ in 0..k {
                    out.extend(one.iter().copied())
                }
                Ok((out, false))
            }
            Expr::Inside(x, set) => {
                let mut r = self.c0;
                for it in set {
                    let t = if let Expr::Range(b, lo, hi) = it {
                        if matches!(&**b, Expr::Id(n) if n == "$range") {
                            let ge = Expr::bin(">=", (**x).clone(), (**lo).clone());
                            let le = Expr::bin("<=", (**x).clone(), (**hi).clone());
                            let (g, _) = self.ev(&ge, 1)?;
                            let (l, _) = self.ev(&le, 1)?;
                            self.and(g[0], l[0])
                        } else {
                            self.ev(&Expr::bin("==", (**x).clone(), it.clone()), 1)?.0[0]
                        }
                    } else {
                        self.ev(&Expr::bin("==", (**x).clone(), it.clone()), 1)?.0[0]
                    };
                    r = self.or(r, t);
                }
                Ok((vec![r], false))
            }
            Expr::Fill(x) => {
                let (v, _) = self.ev(x, 1)?;
                if v.len() == 1 || w % v.len() != 0 {
                    Ok((vec![v[0]; w], false))
                } else {
                    let mut o = vec![];
                    while o.len() < w {
                        o.extend(v.iter().copied())
                    }
                    Ok((o, false))
                }
            }
            Expr::Cast(t, x) => {
                let tw = match &**t {
                    Expr::Id(n) if self.lookup_type(n).is_some() && self.lookup_param(n).is_none() && self.lookup_sig(n).is_none() => self.swidth_of_name(t)?,
                    Expr::Id(n) if n == "signed" => {
                        let (v, _) = self.ev(x, 0)?;
                        return Ok((v, true));
                    }
                    Expr::Id(n) if n == "unsigned" => {
                        let (v, _) = self.ev(x, 0)?;
                        return Ok((v, false));
                    }
                    _ => self.ceval(t)? as usize,
                };
                let (v, s) = self.ev(x, tw)?;
                Ok((self.ext(v, tw, s), s))
            }
            Expr::Call(f, args) => match f.as_str() {
                "$signed" => Ok((self.ev(&args[0], 0)?.0, true)),
                "$unsigned" => Ok((self.ev(&args[0], 0)?.0, false)),
                "$clog2" | "$bits" | "$max1" => {
                    let v = self.ceval(e)?;
                    Ok((self.cbits(v, 32), true))
                }
                "rising_edge" | "falling_edge" | "'event" => Err(format!("{}: clock edge expression used outside a clocked process", self.cur_file)),
                _ => self.call_func(f, args),
            },
        }
    }
    fn index_mux(&mut self, elems: &BTreeMap<i64, Vec<NetId>>, iv: &[NetId], ew: usize) -> Vec<NetId> {
        let maxi = *elems.keys().max().unwrap_or(&0);
        let k = iv.len().min(20);
        let n = 1usize << k.min(16);
        let mut layer: Vec<Vec<NetId>> = (0..n).map(|i| elems.get(&(i as i64)).cloned().unwrap_or(vec![self.c0; ew])).collect();
        let _ = maxi;
        for (bit, &s) in iv.iter().enumerate().take(16) {
            let _ = bit;
            let mut nx = vec![];
            for ch in layer.chunks(2) {
                if ch.len() == 2 {
                    nx.push((0..ew).map(|j| self.mux(s, ch[0][j], ch[1][j])).collect());
                } else {
                    nx.push(ch[0].clone());
                }
            }
            layer = nx;
        }
        // higher index bits set => out of range => 0
        let mut over = self.c0;
        for &s in iv.iter().skip(16) {
            over = self.or(over, s);
        }
        let ns = self.not(over);
        layer[0].iter().map(|x| self.and(*x, ns)).collect()
    }
    fn ev_bin(&mut self, op: &str, a: &Expr, b: &Expr, w: usize) -> ER<(Vec<NetId>, bool)> {
        match op {
            "&&" | "||" => {
                let (x, _) = self.ev(a, 0)?;
                let (y, _) = self.ev(b, 0)?;
                let (bx, by) = (self.to_bool(&x), self.to_bool(&y));
                Ok((vec![if op == "&&" { self.and(bx, by) } else { self.or(bx, by) }], false))
            }
            "==" | "!=" | "===" | "!==" | "<" | "<=" | ">" | ">=" | "==?" | "!=?" => {
                let ow = self.swidth(a)?.max(self.swidth(b)?);
                let (x, sx) = self.ev(a, ow)?;
                let (y, sy) = self.ev(b, ow)?;
                let sg = sx && sy;
                let x = self.ext(x, ow, sg);
                let y = self.ext(y, ow, sg);
                let r = match op {
                    "==" | "===" => self.eq(&x, &y),
                    "!=" | "!==" => {
                        let t = self.eq(&x, &y);
                        self.not(t)
                    }
                    "==?" | "!=?" => {
                        // wildcard: x/z bits of rhs literal are don't care
                        let mask: Vec<bool> = match b {
                            Expr::Num { bits, .. } => (0..ow).map(|k| bits.get(k).map(|v| *v >= 2).unwrap_or(false)).collect(),
                            _ => vec![false; ow],
                        };
                        let v: Vec<NetId> = (0..ow).filter(|k| !mask[*k]).map(|k| {
                            let t = self.xor(x[k], y[k]);
                            self.not(t)
                        }).collect();
                        let e = self.reduce(GOp::And, &v);
                        if op == "==?" { e } else { self.not(e) }
                    }
                    "<" => self.lt(&x, &y, sg),
                    ">" => self.lt(&y, &x, sg),
                    "<=" => {
                        let t = self.lt(&y, &x, sg);
                        self.not(t)
                    }
                    _ => {
                        let t = self.lt(&x, &y, sg);
                        self.not(t)
                    }
                };
                Ok((vec![r], false))
            }
            "<<" | ">>" | "<<<" | ">>>" => {
                let (x, sx) = self.ev(a, w)?;
                let x = self.ext(x, w, sx);
                let arith = op == ">>>" && sx;
                if let Ok(k) = self.ceval(b) {
                    let k = k.max(0) as usize;
                    let fill = if arith { *x.last().unwrap() } else { self.c0 };
                    let r: Vec<NetId> = (0..w)
                        .map(|i| if op.starts_with('<') { if i >= k { x[i - k] } else { self.c0 } } else if i + k < w { x[i + k] } else { fill })
                        .collect();
                    return Ok((r, sx));
                }
                let (amt, _) = self.ev(b, 0)?;
                Ok((self.shift(&x, &amt, op.starts_with('<'), arith), sx))
            }
            "**" => {
                let v = self.ceval(&Expr::bin("**", a.clone(), b.clone()))?;
                Ok((self.cbits(v, w), false))
            }
            _ => {
                let (x, sx) = self.ev(a, w)?;
                let (y, sy) = self.ev(b, w)?;
                let sg = sx && sy;
                let x = self.ext(x, w, sg);
                let y = self.ext(y, w, sg);
                let r = match op {
                    "&" => (0..w).map(|k| self.and(x[k], y[k])).collect(),
                    "|" => (0..w).map(|k| self.or(x[k], y[k])).collect(),
                    "^" => (0..w).map(|k| self.xor(x[k], y[k])).collect(),
                    "~^" | "^~" => (0..w).map(|k| {
                        let t = self.xor(x[k], y[k]);
                        self.not(t)
                    }).collect(),
                    "~&" => (0..w).map(|k| {
                        let t = self.and(x[k], y[k]);
                        self.not(t)
                    }).collect(),
                    "~|" => (0..w).map(|k| {
                        let t = self.or(x[k], y[k]);
                        self.not(t)
                    }).collect(),
                    "+" => {
                        let c0 = self.c0;
                        self.add(&x, &y, c0).0
                    }
                    "-" => self.sub(&x, &y).0,
                    "*" => self.mul(&x, &y, w),
                    "/" | "%" => {
                        if let Ok(d) = self.ceval(b) {
                            if d > 0 && (d & (d - 1)) == 0 {
                                let k = d.trailing_zeros() as usize;
                                if op == "/" {
                                    (0..w).map(|i| if i + k < w { x[i + k] } else { self.c0 }).collect()
                                } else {
                                    (0..w).map(|i| if i < k { x[i] } else { self.c0 }).collect()
                                }
                            } else {
                                let (q, r) = self.divmod(&x, &y);
                                if op == "/" { q } else { r }
                            }
                        } else {
                            crate::info!("ELAB-420", "Building array divider for '{}' operator ({} bits)", op, w);
                            let (q, r) = self.divmod(&x, &y);
                            if op == "/" { q } else { r }
                        }
                    }
                    _ => return Err(format!("unsupported operator '{}'", op)),
                };
                Ok((r, sg))
            }
        }
    }

    fn call_func(&mut self, f: &str, args: &[Expr]) -> ER<(Vec<NetId>, bool)> {
        let fd = self.lookup_func(f).ok_or_else(|| format!("{}: unknown function '{}' (ELAB-357)", self.cur_file, f))?;
        if self.depth > 64 {
            return Err(format!("function '{}' recursion too deep", f));
        }
        self.depth += 1;
        let mut sc = Scope::default();
        // evaluate args in caller scope
        let mut vals = vec![];
        for (k, (an, at)) in fd.args.iter().enumerate() {
            let (d, s, ty) = self.type_info(at)?;
            let wd: usize = d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
            let v = match args.get(k) {
                Some(e) => self.evw(e, wd)?,
                None => vec![self.c0; wd],
            };
            vals.push((an.clone(), Sig { name: an.clone(), bits: v, dims: d, signed: s, ty }));
        }
        let (rd, rs, rty) = self.type_info(&fd.ret)?;
        let save_g = self.gpath.clone();
        self.gpath = format!("{}{}_{}.", self.gpath, f, self.gcount);
        self.gcount += 1;
        // args become read-only signals whose "nets" are the argument values
        for (n, s) in vals {
            sc.sigs.insert(n, s);
        }
        self.stack.push(sc);
        let rsig = self.mk_sig(f, &DType::Logic { signed: rs, packed: vec![] }, &[])?;
        let rbits: Vec<NetId> = {
            let wd: usize = rd.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
            let mut v = rsig.bits.clone();
            for i in 1..wd {
                v.push(self.nl.add_net(&format!("{}{}{}[{}]", self.prefix, self.gpath, f, i)));
            }
            v
        };
        self.top().sigs.insert(f.to_string(), Sig { name: f.to_string(), bits: rbits.clone(), dims: rd, signed: rs, ty: rty });
        self.procs.push(PState { vals: BTreeMap::new(), blocking: HashSet::new(), done: self.c0 });
        let r = self.exec(&fd.body, Some(f));
        let ps = self.procs.pop().unwrap();
        self.stack.pop();
        self.gpath = save_g;
        self.depth -= 1;
        r?;
        let out: Vec<NetId> = rbits.iter().map(|b| match ps.vals.get(b) {
            Some(&(v, e)) => {
                if e == self.c1 {
                    v
                } else {
                    self.and(v, e)
                }
            }
            None => self.c0,
        }).collect();
        Ok((out, rs))
    }

    // ------------------------------------------------------------ lvalues
    fn lval(&mut self, e: &Expr) -> ER<Vec<NetId>> {
        match e {
            Expr::Concat(v) => {
                let mut out = vec![];
                for x in v.iter().rev() {
                    out.extend(self.lval(x)?);
                }
                Ok(out)
            }
            Expr::Id(n) => {
                if let Some(s) = self.lookup_sig(n) {
                    return Ok(s.bits);
                }
                // implicit net
                crate::warn!("VER-936", "{}: implicit 1-bit net '{}' created", self.cur_file, n);
                let s = self.mk_sig(n, &DType::bit(), &[])?;
                self.top().sigs.insert(n.clone(), s.clone());
                Ok(s.bits)
            }
            _ => match self.sig_of(e)? {
                Some(s) => Ok(s.bits),
                None => Err(format!("{}: unsupported or non-constant lvalue (ELAB-208)", self.cur_file)),
            },
        }
    }

    // ------------------------------------------------------------ procedural
    fn assign(&mut self, tgt: &[NetId], val: &[NetId], blocking: bool, cond: Option<NetId>) {
        let done = self.procs.last().unwrap().done;
        let guard = if done == self.c0 { cond } else {
            let nd = self.not(done);
            Some(match cond {
                Some(c) => self.and(c, nd),
                None => nd,
            })
        };
        for (k, &t) in tgt.iter().enumerate() {
            let v = val[k];
            let entry = match guard {
                None => (v, self.c1),
                Some(g) => {
                    let (ov, oe) = self.procs.last().unwrap().vals.get(&t).copied().unwrap_or((t, self.c0));
                    let nv = self.mux(g, ov, v);
                    let ne = self.or(oe, g);
                    (nv, ne)
                }
            };
            let ps = self.procs.last_mut().unwrap();
            ps.vals.insert(t, entry);
            if blocking {
                ps.blocking.insert(t);
            }
        }
    }
    fn branch(&mut self, c: NetId, t: &mut dyn FnMut(&mut Self) -> ER<()>, e: &mut dyn FnMut(&mut Self) -> ER<()>) -> ER<()> {
        if c == self.c1 {
            return t(self);
        }
        if c == self.c0 {
            return e(self);
        }
        let base = self.procs.last().unwrap().clone();
        t(self)?;
        let a = std::mem::replace(self.procs.last_mut().unwrap(), base.clone());
        e(self)?;
        let b = self.procs.pop().unwrap();
        let mut m = PState { vals: BTreeMap::new(), blocking: a.blocking.union(&b.blocking).copied().collect(), done: self.c0 };
        let keys: Vec<NetId> = a.vals.keys().chain(b.vals.keys()).copied().collect::<std::collections::BTreeSet<_>>().into_iter().collect();
        for k in keys {
            let (va, ea) = a.vals.get(&k).copied().or(base.vals.get(&k).copied()).unwrap_or((k, self.c0));
            let (vb, eb) = b.vals.get(&k).copied().or(base.vals.get(&k).copied()).unwrap_or((k, self.c0));
            let v = if ea == self.c0 { vb } else if eb == self.c0 { va } else { self.mux(c, vb, va) };
            let en = self.mux(c, eb, ea);
            m.vals.insert(k, (v, en));
        }
        m.done = self.mux(c, b.done, a.done);
        self.procs.push(m);
        Ok(())
    }
    fn exec(&mut self, s: &Stmt, func: Option<&str>) -> ER<()> {
        if self.procs.last().unwrap().done == self.c1 {
            return Ok(());
        }
        match s {
            Stmt::Null => Ok(()),
            Stmt::Block(v) => {
                for x in v {
                    self.exec(x, func)?;
                }
                Ok(())
            }
            Stmt::Decl(d) => {
                let sg = self.mk_sig(&d.name, &d.ty, &d.unpacked)?;
                self.top().sigs.insert(d.name.clone(), sg);
                Ok(())
            }
            Stmt::Asgn { lhs, rhs, blocking } => {
                // loop variable assignment inside for() handled by caller
                if let Expr::Id(n) = lhs {
                    if self.lookup_param(n).is_some() && self.lookup_sig(n).is_none() {
                        let v = self.ceval(rhs)?;
                        for sc in self.stack.iter_mut().rev() {
                            if sc.params.contains_key(n) {
                                sc.params.insert(n.clone(), v);
                                break;
                            }
                        }
                        return Ok(());
                    }
                }
                // dynamic index on lhs?
                if let Expr::Index(b, i) = lhs {
                    if self.ceval(i).is_err() {
                        if let Some(bs) = self.sig_of(b)? {
                            let d0 = *bs.dims.first().ok_or("index of scalar")?;
                            let ew: usize = bs.dims[1..].iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product();
                            let (iv, _) = self.ev(i, 0)?;
                            let val = self.evw(rhs, ew)?;
                            let (lo, hi) = (d0.0.min(d0.1), d0.0.max(d0.1));
                            for idx in lo..=hi {
                                let o = dim_off(d0, idx).unwrap();
                                let kb = self.cbits(idx as i128, iv.len());
                                let c = self.eq(&iv, &kb);
                                let tg = bs.bits[o * ew..(o + 1) * ew].to_vec();
                                self.assign(&tg, &val, *blocking, Some(c));
                            }
                            return Ok(());
                        }
                    }
                }
                let tg = self.lval(lhs)?;
                let val = self.evw(rhs, tg.len())?;
                self.assign(&tg, &val, *blocking, None);
                Ok(())
            }
            Stmt::If(c, t, e) => {
                let (cv, _) = self.ev(c, 0)?;
                let cb = self.to_bool(&cv);
                self.branch(cb, &mut |s| s.exec(t, func), &mut |s| if let Some(e) = e { s.exec(e, func) } else { Ok(()) })
            }
            Stmt::Case { kind, sel, items, default, inside, full, parallel, line } => {
                let sw = self.swidth(sel)?;
                let mut iw = sw;
                for (es, _) in items {
                    for x in es {
                        if !matches!(x, Expr::Range(..)) {
                            iw = iw.max(self.swidth(x)?);
                        }
                    }
                }
                let sv = self.evw(sel, iw)?;
                let mut conds = vec![];
                for (es, _) in items {
                    let mut c = self.c0;
                    for x in es {
                        let t = if *inside || matches!(x, Expr::Range(..)) {
                            self.ev(&Expr::Inside(Box::new(sel.clone()), vec![x.clone()]), 1)?.0[0]
                        } else {
                            let xv = self.evw(x, iw)?;
                            let mask: Vec<bool> = match x {
                                Expr::Num { bits, .. } => (0..iw).map(|k| bits.get(k).map(|v| (*kind >= 1 && *v == 3) || (*kind == 2 && *v == 2)).unwrap_or(false)).collect(),
                                _ => vec![false; iw],
                            };
                            let v: Vec<NetId> = (0..iw).filter(|k| !mask[*k]).map(|k| {
                                let t = self.xor(sv[k], xv[k]);
                                self.not(t)
                            }).collect();
                            self.reduce(GOp::And, &v)
                        };
                        c = self.or(c, t);
                    }
                    conds.push(c);
                }
                if *parallel {
                    let note = format!("parallel_case (line {}): case items are kept in RTL priority order, so the netlist matches RTL simulation even if items overlap", line);
                    if !self.pragma_notes.contains(&note) {
                        self.pragma_notes.push(note);
                    }
                }
                if *full && default.is_none() && !items.is_empty() {
                    // full_case: selector values not covered are don't care -> the last item takes
                    // them (no latch, no hold of the previous value)
                    let note = format!("full_case (line {}): uncovered selector values treated as don't care (no latch inferred)", line);
                    if !self.pragma_notes.contains(&note) {
                        self.pragma_notes.push(note);
                    }
                    let n = conds.len();
                    return self.exec_case(&conds[..n - 1], items, Some(&items[n - 1].1), 0, func);
                }
                self.exec_case(&conds, items, default.as_deref(), 0, func)
            }
            Stmt::For { var, init, cond, step, body } => {
                let v0 = self.ceval(init)?;
                let mut sc = Scope::default();
                sc.params.insert(var.clone(), v0);
                self.stack.push(sc);
                let mut n = 0;
                let r = (|| -> ER<()> {
                    loop {
                        if self.ceval(cond)? == 0 {
                            break;
                        }
                        n += 1;
                        if n > 65536 {
                            return Err("for-loop iteration limit (65536) exceeded (ELAB-900)".into());
                        }
                        self.exec(body, func)?;
                        if let Stmt::Asgn { rhs, .. } = &**step {
                            let nv = self.ceval(rhs)?;
                            self.top().params.insert(var.clone(), nv);
                        }
                    }
                    Ok(())
                })();
                self.stack.pop();
                r
            }
            Stmt::Return(e) => {
                if let (Some(e), Some(f)) = (e, func) {
                    let tg = self.lookup_sig(f).unwrap().bits;
                    let v = self.evw(e, tg.len())?;
                    self.assign(&tg, &v, true, None);
                }
                self.procs.last_mut().unwrap().done = self.c1;
                Ok(())
            }
        }
    }
    fn exec_case(&mut self, conds: &[NetId], items: &[(Vec<Expr>, Stmt)], default: Option<&Stmt>, k: usize, func: Option<&str>) -> ER<()> {
        if k == conds.len() {
            if let Some(d) = default {
                return self.exec(d, func);
            }
            return Ok(());
        }
        let c = conds[k];
        self.branch(c, &mut |s| s.exec(&items[k].1, func), &mut |s| s.exec_case(conds, items, default, k + 1, func))
    }

    /// map of net -> local hierarchical bit name for signals visible in the current module scope
    fn local_names(&self) -> HashMap<NetId, String> {
        let mut m = HashMap::new();
        let mut scopes: Vec<&Scope> = vec![];
        for s in self.stack.iter().rev() {
            scopes.push(s);
            if s.boundary {
                break;
            }
        }
        for s in scopes.iter().rev() {
            for sig in s.sigs.values() {
                if sig.name.is_empty() {
                    continue;
                }
                let names = bit_names(&sig.name, &sig.dims);
                if names.len() != sig.bits.len() {
                    continue;
                }
                for (b, n) in sig.bits.iter().zip(names) {
                    m.insert(*b, n);
                }
            }
            for ii in s.ifaces.values() {
                for el in &ii.elems {
                    for sig in el.values() {
                        let names = bit_names(&sig.name, &sig.dims);
                        if names.len() == sig.bits.len() {
                            for (b, n) in sig.bits.iter().zip(names) {
                                m.entry(*b).or_insert(n);
                            }
                        }
                    }
                }
            }
        }
        m
    }
    fn always(&mut self, kind: AKind, sens: &[(Edge, Expr)], body: &Stmt, line: usize) -> ER<()> {
        let loc = format!("{}:{}", self.cur_file, line);
        let lnames = self.local_names();
        let lname = |nl: &Netlist, t: NetId| -> String { lnames.get(&t).cloned().unwrap_or_else(|| nl.net(t).name.clone()) };
        match kind {
            AKind::Comb | AKind::Latch | AKind::Plain => {
                self.procs.push(PState { vals: BTreeMap::new(), blocking: HashSet::new(), done: self.c0 });
                let r = self.exec(body, None);
                let ps = self.procs.pop().unwrap();
                r?;
                for (t, (v, e)) in ps.vals {
                    if e == self.c1 {
                        if v != t {
                            let c = format!("{}B{}", self.prefix, { self.gcount += 1; self.gcount });
                            self.nl.add_gen(&c, GOp::Buf, &[v], t);
                        }
                    } else {
                        let nm = lname(&self.nl, t);
                        let rn = reg_name(&nm);
                        if kind == AKind::Latch {
                            crate::info!("ELAB-301", "Latch inferred for '{}' (always_latch at {})", nm, loc);
                        } else {
                            crate::warn!("ELAB-302", "Unintentional LATCH inferred for '{}' at {}: not assigned in all branches of combinational block{}", nm, loc, if kind == AKind::Comb { " (always_comb/process)" } else { "" });
                        }
                        let c = self.nl.add_cell(&rn, Kind::Gen(GOp::Latch), &[("D", Dir::In), ("G", Dir::In), ("Q", Dir::Out)]);
                        self.nl.connect(c, 0, v);
                        self.nl.connect(c, 1, e);
                        self.nl.connect(c, 2, t);
                        self.latches.push(nm);
                    }
                }
                Ok(())
            }
            AKind::Ff => {
                if sens.is_empty() {
                    return Err(format!("{}: always_ff without event control", loc));
                }
                // peel async resets
                let mut asyncs: Vec<(&Expr, &Stmt)> = vec![];
                let mut st = body;
                let mut rem = sens.len();
                while rem > 1 {
                    let mut s2 = st;
                    while let Stmt::Block(v) = s2 {
                        if v.len() == 1 {
                            s2 = &v[0]
                        } else {
                            break;
                        }
                    }
                    match s2 {
                        Stmt::If(c, a, Some(b)) => {
                            asyncs.push((c, a));
                            st = b;
                            rem -= 1;
                        }
                        Stmt::If(c, a, None) => {
                            asyncs.push((c, a));
                            st = &Stmt::Null;
                            rem -= 1;
                        }
                        _ => return Err(format!("{}: cannot infer asynchronous reset structure (ELAB-306)", loc)),
                    }
                }
                let clk = sens.iter().find(|(_, e)| {
                    let n = expr_name(e).unwrap_or_default();
                    !asyncs.iter().any(|(c, _)| expr_mentions(c, &n))
                }).or(sens.first()).unwrap();
                let (ck, _) = self.ev(&clk.1, 1)?;
                let mut cknet = ck[0];
                if clk.0 == Edge::Neg {
                    cknet = self.not(cknet);
                }
                // reset values
                let mut clr: HashMap<NetId, NetId> = HashMap::new();
                let mut set: HashMap<NetId, NetId> = HashMap::new();
                for (c, a) in &asyncs {
                    let (cv, _) = self.ev(c, 0)?;
                    let cb = self.to_bool(&cv);
                    self.procs.push(PState { vals: BTreeMap::new(), blocking: HashSet::new(), done: self.c0 });
                    let r = self.exec(a, None);
                    let ps = self.procs.pop().unwrap();
                    r?;
                    for (t, (v, _)) in ps.vals {
                        let m = if v == self.c0 {
                            &mut clr
                        } else if v == self.c1 {
                            &mut set
                        } else {
                            crate::warn!("ELAB-307", "{}: non-constant asynchronous load value for '{}'; modeled with async set/reset logic", loc, self.nl.net(t).name);
                            // async load: set when cond&v, clear when cond&!v
                            let sv = self.and(cb, v);
                            let nv = self.not(v);
                            let cvv = self.and(cb, nv);
                            let o = set.get(&t).copied().unwrap_or(self.c0);
                            let s2 = self.or(o, sv);
                            set.insert(t, s2);
                            let o = clr.get(&t).copied().unwrap_or(self.c0);
                            let c2 = self.or(o, cvv);
                            clr.insert(t, c2);
                            continue;
                        };
                        let o = m.get(&t).copied().unwrap_or(self.c0);
                        let nn = self.or(o, cb);
                        m.insert(t, nn);
                    }
                }
                self.procs.push(PState { vals: BTreeMap::new(), blocking: HashSet::new(), done: self.c0 });
                let r = self.exec(st, None);
                let ps = self.procs.pop().unwrap();
                r?;
                let mut targets: Vec<NetId> = ps.vals.keys().copied().collect();
                for t in clr.keys().chain(set.keys()) {
                    if !targets.contains(t) {
                        targets.push(*t)
                    }
                }
                targets.sort();
                for t in targets {
                    let (v, e) = ps.vals.get(&t).copied().unwrap_or((t, self.c0));
                    let d = if e == self.c1 { v } else { self.mux(e, t, v) };
                    let nm = lname(&self.nl, t);
                    let mut pins = vec![("D", Dir::In), ("CK", Dir::In), ("Q", Dir::Out)];
                    let cl = clr.get(&t).copied();
                    let se = set.get(&t).copied();
                    if cl.is_some() {
                        pins.push(("RN", Dir::In))
                    }
                    if se.is_some() {
                        pins.push(("SN", Dir::In))
                    }
                    let c = self.nl.add_cell(&reg_name(&nm), Kind::Gen(GOp::Dff), &pins);
                    self.nl.connect(c, 0, d);
                    self.nl.connect(c, 1, cknet);
                    self.nl.connect(c, 2, t);
                    if let Some(x) = cl {
                        let n = self.not(x);
                        self.nl.connect_name(c, "RN", n);
                    }
                    if let Some(x) = se {
                        let n = self.not(x);
                        self.nl.connect_name(c, "SN", n);
                    }
                }
                Ok(())
            }
        }
    }

    // ------------------------------------------------------------ module level
    fn bind_params(&mut self, m: &Module, overrides: &[(String, i128)], type_over: &HashMap<String, String>) -> ER<()> {
        let mut pos = 0;
        for p in &m.params {
            if let Some(t) = type_over.get(&p.name) {
                self.top().ptypes.insert(p.name.clone(), t.clone());
                continue;
            }
            let ov = overrides.iter().find(|(n, _)| n == &p.name).map(|x| x.1).or_else(|| {
                let r = overrides.iter().filter(|(n, _)| n.starts_with("#pos")).nth(pos).map(|x| x.1);
                r
            });
            pos += 1;
            let v = match (ov, &p.value) {
                (Some(v), _) if !p.local => v,
                (_, Some(e)) => {
                    if let Expr::Id(t) = e {
                        if self.lookup_type(t).is_some() && self.lookup_param(t).is_none() {
                            self.top().ptypes.insert(p.name.clone(), t.clone());
                            continue;
                        }
                    }
                    self.ceval(e).map_err(|x| format!("{}: parameter {}: {}", m.name, p.name, x))?
                }
                _ => return Err(format!("{}: parameter '{}' has no value", m.name, p.name)),
            };
            self.top().params.insert(p.name.clone(), v);
        }
        Ok(())
    }

    fn decl_pass(&mut self, items: &[Item]) -> ER<()> {
        for it in items {
            match it {
                Item::Param(p) => {
                    if let Some(e) = &p.value {
                        if let Expr::Id(t) = e {
                            if self.lookup_type(t).is_some() && self.lookup_param(t).is_none() {
                                self.top().ptypes.insert(p.name.clone(), t.clone());
                                continue;
                            }
                        }
                        let v = self.ceval(e).map_err(|x| format!("{}: parameter {}: {}", self.cur_file, p.name, x))?;
                        self.top().params.insert(p.name.clone(), v);
                    }
                }
                Item::Typedef(n, t) => {
                    let ti = match t {
                        DType::Struct { .. } => self.struct_info(t)?,
                        _ => {
                            let (d, s, ty) = self.type_info(t)?;
                            let w = d.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
                            match ty.and_then(|x| self.lookup_type(&x)) {
                                Some(st) => st,
                                None => TypeInfo { width: w, signed: s, dims: d, fields: vec![] },
                            }
                        }
                    };
                    self.top().types.insert(n.clone(), ti);
                }
                Item::Func(f) => {
                    self.top().funcs.insert(f.name.clone(), f.clone());
                }
                Item::Decl(d) => {
                    if self.lookup_sig(&d.name).is_some() && self.stack.last().unwrap().sigs.contains_key(&d.name) {
                        continue;
                    }
                    let s = self.mk_sig(&d.name, &d.ty, &d.unpacked)?;
                    self.top().sigs.insert(d.name.clone(), s);
                }
                Item::Inst { module, params, name, range, .. } => {
                    if let Some(def) = self.lib.modules.get(module) {
                        if def.kind == ModKind::Interface {
                            let mut ov = vec![];
                            for (k, (pn, e)) in params.iter().enumerate() {
                                let v = self.ceval(e)?;
                                ov.push((pn.clone().unwrap_or(format!("#pos{}", k)), v));
                            }
                            let un: Vec<(Expr, Expr)> = range.iter().cloned().collect();
                            let inst = self.make_iface(module, name, &un, &ov, None)?;
                            self.top().ifaces.insert(name.clone(), inst);
                        }
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }

    /// Create an interface instance (or top-level interface port when `as_port` is set).
    fn make_iface(&mut self, def: &str, name: &str, unpacked: &[(Expr, Expr)], ov: &[(String, i128)], as_port: Option<(Option<String>, bool)>) -> ER<IfInst> {
        let d = self.lib.modules.get(def).ok_or_else(|| format!("Cannot find interface '{}' (LINK-3)", def))?.clone();
        if d.kind != ModKind::Interface {
            return Err(format!("'{}' is not an interface", def));
        }
        let (lo, n, is_array) = if let Some((a, b)) = unpacked.first() {
            let (a, b) = (self.ceval(a)? as i64, self.ceval(b)? as i64);
            (a.min(b), (a - b).unsigned_abs() as usize + 1, true)
        } else {
            (0, 1, false)
        };
        let mut elems = vec![];
        for k in 0..n {
            let ename = if is_array { format!("{}[{}]", name, lo + k as i64) } else { name.to_string() };
            let mut sc = Scope { boundary: true, ..Default::default() };
            sc.params = HashMap::new();
            let saved = std::mem::replace(&mut self.stack, vec![sc]);
            self.bind_params(&d, ov, &HashMap::new())?;
            let mut map = HashMap::new();
            let modport: Option<Vec<(Dir, String)>> = match &as_port {
                Some((Some(mp), _)) => d.items.iter().find_map(|i| if let Item::Modport(n, s) = i { if n == mp { Some(s.clone()) } else { None } } else { None }),
                _ => None,
            };
            for it in &d.items {
                match it {
                    Item::Param(_) | Item::Typedef(..) => self.decl_pass(std::slice::from_ref(it))?,
                    Item::Decl(dc) => {
                        let (dims, signed, ty) = self.type_dims(&dc.ty, &dc.unpacked)?;
                        let base = format!("{}{}{}.{}", self.prefix_saved(&saved), "", ename, dc.name);
                        let bits: Vec<NetId> = if as_port.is_some() {
                            let pn = format!("{}_{}", ename.replace(['[', ']'], "_").trim_end_matches('_'), dc.name);
                            let pn = pn.replace("__", "_");
                            let pname = if is_array { format!("{}_{}__{}", name, lo + k as i64, dc.name) } else { format!("{}_{}", name, dc.name) };
                            let _ = pn;
                            let dir = match &modport {
                                Some(mp) => mp.iter().find(|(_, s)| s == &dc.name).map(|x| x.0).unwrap_or_else(|| {
                                    crate::warn!("ELAB-961", "Interface signal '{}.{}' not in modport; treated as input", def, dc.name);
                                    Dir::In
                                }),
                                None => {
                                    crate::warn!("ELAB-960", "Top-level generic interface port '{}' without modport; signal '{}' treated as inout", name, dc.name);
                                    Dir::InOut
                                }
                            };
                            bit_names(&pname, &dims).iter().map(|bn| {
                                let p = self.nl.add_port(bn, dir);
                                self.nl.ports[p].net.unwrap()
                            }).collect()
                        } else {
                            bit_names(&base, &dims).iter().map(|bn| self.nl.add_net(bn)).collect()
                        };
                        map.insert(dc.name.clone(), Sig { name: format!("{}{}.{}", self.prefix_saved(&saved), ename, dc.name), bits, dims, signed, ty });
                    }
                    Item::Modport(..) | Item::Import(_) => {}
                    _ => crate::warn!("ELAB-962", "Interface '{}': procedural/instance content inside interfaces is ignored", def),
                }
            }
            self.stack = saved;
            elems.push(map);
        }
        if as_port.is_some() {
            crate::info!("ELAB-963", "Top-level interface port '{}' ({}{}) flattened into {} element(s)", name, def, if is_array { format!("[{}]", n) } else { String::new() }, n);
        }
        Ok(IfInst { def: def.to_string(), lo, elems, is_array })
    }
    fn prefix_saved(&self, _s: &[Scope]) -> String {
        format!("{}{}", self.prefix, self.gpath)
    }

    fn module_body(&mut self, m: &Module) -> ER<()> {
        let save_file = std::mem::replace(&mut self.cur_file, m.file.clone());
        // imports are global; local decls first
        self.decl_pass(&m.items)?;
        self.stmt_pass(&m.items)?;
        self.cur_file = save_file;
        Ok(())
    }

    fn stmt_pass(&mut self, items: &[Item]) -> ER<()> {
        for it in items {
            match it {
                Item::Decl(d) => {
                    if let Some(init) = &d.init {
                        let tg = self.lookup_sig(&d.name).unwrap().bits;
                        let v = self.evw(init, tg.len())?;
                        self.cont_assign(&tg, &v);
                    }
                }
                Item::Assign(l, r, line) => {
                    let tg = self.lval(l).map_err(|e| format!("{}:{}: {}", self.cur_file, line, e))?;
                    let v = self.evw(r, tg.len()).map_err(|e| format!("{}:{}: {}", self.cur_file, line, e))?;
                    self.cont_assign(&tg, &v);
                }
                Item::Always { kind, sens, body, line } => self.always(*kind, sens, body, *line).map_err(|e| if e.contains(':') { e } else { format!("{}:{}: {}", self.cur_file, line, e) })?,
                Item::Inst { .. } => self.instance(it)?,
                Item::GenFor { var, init, cond, step, label, items } => {
                    let mut v = self.ceval(init)?;
                    let lab = label.clone().unwrap_or_else(|| "genblk".into());
                    let mut n = 0;
                    loop {
                        let mut sc = Scope::default();
                        sc.params.insert(var.clone(), v);
                        self.stack.push(sc);
                        let c = self.ceval(cond)?;
                        if c == 0 {
                            self.stack.pop();
                            break;
                        }
                        n += 1;
                        if n > 100000 {
                            return Err("generate loop limit".into());
                        }
                        let sg = self.gpath.clone();
                        self.gpath = format!("{}{}[{}].", self.gpath, lab, v);
                        let r = self.decl_pass(items).and_then(|_| self.stmt_pass(items));
                        self.gpath = sg;
                        let nv = self.ceval(step);
                        self.stack.pop();
                        r?;
                        v = nv?;
                    }
                }
                Item::GenIf { cond, then, els } => {
                    let c = self.ceval(cond)?;
                    let body = if c != 0 { then } else { els };
                    self.stack.push(Scope::default());
                    let r = self.decl_pass(body).and_then(|_| self.stmt_pass(body));
                    self.stack.pop();
                    r?;
                }
                Item::GenCase { sel, items, default } => {
                    let s = self.ceval(sel)?;
                    let mut chosen: &Vec<Item> = default;
                    'o: for (es, body) in items {
                        for e in es {
                            if self.ceval(e)? == s {
                                chosen = body;
                                break 'o;
                            }
                        }
                    }
                    self.stack.push(Scope::default());
                    let r = self.decl_pass(chosen).and_then(|_| self.stmt_pass(chosen));
                    self.stack.pop();
                    r?;
                }
                Item::GenBlock { label, items } => {
                    let sg = self.gpath.clone();
                    if let Some(l) = label {
                        self.gpath = format!("{}{}.", self.gpath, l);
                    }
                    self.stack.push(Scope::default());
                    let r = self.decl_pass(items).and_then(|_| self.stmt_pass(items));
                    self.stack.pop();
                    self.gpath = sg;
                    r?;
                }
                _ => {}
            }
        }
        Ok(())
    }
    fn cont_assign(&mut self, tg: &[NetId], v: &[NetId]) {
        for (t, s) in tg.iter().zip(v) {
            if t != s {
                self.gcount += 1;
                let c = format!("{}B{}", self.prefix, self.gcount);
                self.nl.add_gen(&c, GOp::Buf, &[*s], *t);
            }
        }
    }

    fn instance(&mut self, it: &Item) -> ER<()> {
        let Item::Inst { module, params, name, range, conns, wildcard, line } = it else { unreachable!() };
        let def = self.lib.modules.get(module).cloned();
        if let Some(d) = &def {
            if d.kind == ModKind::Interface {
                return Ok(()); // created in decl pass
            }
        }
        let loc = format!("{}:{}", self.cur_file, line);
        if def.is_none() {
            if let Some(pins) = self.opts.lib_cells.get(module).cloned() {
                return self.lib_inst(module, &pins, name, conns, &loc);
            }
        }
        let count = match range {
            Some((a, b)) => ((self.ceval(a)? - self.ceval(b)?).unsigned_abs() + 1) as usize,
            None => 1,
        };
        let rlo = match range {
            Some((a, b)) => self.ceval(a)?.min(self.ceval(b)?) as i64,
            None => 0,
        };
        // parameter overrides evaluated in the parent scope
        let mut ov = vec![];
        let mut tov = HashMap::new();
        for (k, (pn, e)) in params.iter().enumerate() {
            let pname = pn.clone().unwrap_or_else(|| def.as_ref().and_then(|d| d.params.iter().filter(|p| !p.local).nth(k).map(|p| p.name.clone())).unwrap_or(format!("#pos{}", k)));
            if let Expr::Id(t) = e {
                if self.lookup_type(t).is_some() && self.lookup_param(t).is_none() && self.lookup_sig(t).is_none() {
                    tov.insert(pname, t.clone());
                    continue;
                }
            }
            ov.push((pname, self.ceval(e)?));
        }
        for k in 0..count {
            let iname = if range.is_some() { format!("{}{}{}[{}]", self.prefix, self.gpath, name, rlo + k as i64) } else { format!("{}{}{}", self.prefix, self.gpath, name) };
            let sig = format!("{}#({})", module, ov.iter().map(|(n, v)| format!("{}={}", n, v)).collect::<Vec<_>>().join(","));
            self.insts.entry(sig).or_default().push(iname.clone());
            let is_bb = match &def {
                None => true,
                Some(d) => d.blackbox || self.opts.blackboxes.contains(module) || (d.is_empty() && self.opts.empty_as_blackbox),
            };
            if is_bb {
                self.blackbox_inst(def.as_ref(), module, &iname, conns, *wildcard, &ov, k, count, &loc)?;
                continue;
            }
            let d = def.clone().unwrap();
            if d.is_empty() {
                crate::warn!("ELAB-EMPTY", "[EMPTY MODULE] '{}' (instance {}) has no logic; outputs left undriven (hdlin.elaborate.empty_module_as_blackbox=false)", module, iname);
            }
            if self.depth > 100 {
                return Err(format!("{}: instantiation depth exceeded (recursive instantiation of {}?)", loc, module));
            }
            // build child scope
            let child = Scope { boundary: true, ..Default::default() };
            let parent_stack = std::mem::replace(&mut self.stack, vec![child]);
            let parent_prefix = std::mem::replace(&mut self.prefix, format!("{}/", iname));
            let parent_g = std::mem::take(&mut self.gpath);
            let r = self.bind_params(&d, &ov, &tov);
            if let Err(e) = r {
                self.stack = parent_stack;
                self.prefix = parent_prefix;
                self.gpath = parent_g;
                return Err(e);
            }
            // port shapes in child scope
            let mut shapes = vec![];
            for p in &d.ports {
                if p.iface.is_some() {
                    shapes.push(None);
                } else {
                    shapes.push(Some(self.type_dims(&p.ty, &p.unpacked)?));
                }
            }
            let child_scope = std::mem::replace(&mut self.stack, parent_stack);
            let cpfx = std::mem::replace(&mut self.prefix, parent_prefix);
            let cg = std::mem::replace(&mut self.gpath, parent_g);
            // connections evaluated in parent
            let mut bound: Vec<(String, Option<Sig>, Option<IfInst>)> = vec![];
            for (pi, p) in d.ports.iter().enumerate() {
                let conn: Option<Expr> = conns.iter().enumerate().find_map(|(ci, (n, e))| match n {
                    Some(n) if n == &p.name => Some(e.clone()),
                    None if ci == pi => Some(e.clone()),
                    _ => None,
                }).flatten().or_else(|| if *wildcard { Some(Expr::Id(p.name.clone())) } else { None });
                if let Some((ifn, _mp)) = &p.iface {
                    let ce = conn.ok_or_else(|| format!("{}: interface port '{}' of '{}' is unconnected", loc, p.name, module))?;
                    let ii = self.bind_iface(&ce, count, k, &loc)?;
                    if &ii.def != ifn && ifn != "interface" {
                        crate::warn!("ELAB-964", "{}: interface type mismatch on port '{}' ({} vs {})", loc, p.name, ii.def, ifn);
                    }
                    // port declared as array?
                    let want = p.unpacked.len();
                    let mut ii2 = if want == 0 && ii.is_array && ii.elems.len() == 1 { IfInst { is_array: false, ..ii } } else { ii };
                    let arr = ii2.is_array;
                    let lo = ii2.lo;
                    for (k2, el) in ii2.elems.iter_mut().enumerate() {
                        for (mn, sg) in el.iter_mut() {
                            sg.name = if arr { format!("{}/{}[{}].{}", iname, p.name, lo + k2 as i64, mn) } else { format!("{}/{}.{}", iname, p.name, mn) };
                        }
                    }
                    bound.push((p.name.clone(), None, Some(ii2)));
                    continue;
                }
                let (dims, signed, ty) = shapes[pi].clone().unwrap();
                let w: usize = dims.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
                let dir = p.dir.unwrap_or(Dir::In);
                let bits: Vec<NetId> = match conn {
                    None => {
                        if dir == Dir::In {
                            crate::warn!("LINT-33", "{}: input port '{}' of instance '{}' is unconnected (floating)", loc, p.name, iname);
                        }
                        bit_names(&format!("{}/{}", iname, p.name), &dims).iter().map(|n| self.nl.add_net(n)).collect()
                    }
                    Some(ce) => {
                        let cw = self.swidth(&ce)?;
                        let slice = count > 1 && cw == w * count;
                        if dir == Dir::In {
                            let v = self.evw(&ce, if slice { w * count } else { w })?;
                            if slice { v[k * w..(k + 1) * w].to_vec() } else { v }
                        } else {
                            match self.lval(&ce) {
                                Ok(mut v) => {
                                    if slice {
                                        v = v[k * w..(k + 1) * w].to_vec();
                                    }
                                    if v.len() != w {
                                        crate::warn!("ELAB-368", "{}: width mismatch on port '{}' of '{}' ({} vs {})", loc, p.name, iname, v.len(), w);
                                    }
                                    while v.len() < w {
                                        let n = self.nl.add_net(&format!("{}/{}_unconn{}", iname, p.name, v.len()));
                                        v.push(n);
                                    }
                                    v.truncate(w);
                                    v
                                }
                                Err(e) => return Err(format!("{}: output port '{}': {}", loc, p.name, e)),
                            }
                        }
                    }
                };
                let bits = if self.opts.keep_boundary(&iname) {
                    self.boundary_pins(&iname, &p.name, &dims, dir, bits)
                } else {
                    for (bi, bn) in bit_names(&p.name, &dims).into_iter().enumerate() {
                        if let Some(&n) = bits.get(bi) {
                            self.nl.port_alias.push((iname.clone(), bn, n));
                        }
                    }
                    bits
                };
                bound.push((p.name.clone(), Some(Sig { name: format!("{}/{}", iname, p.name), bits, dims, signed, ty }), None));
            }
            // enter child
            let ps = std::mem::replace(&mut self.stack, child_scope);
            let pp = std::mem::replace(&mut self.prefix, cpfx);
            let pg = std::mem::replace(&mut self.gpath, cg);
            for (n, s, i) in bound {
                if let Some(s) = s {
                    self.top().sigs.insert(n.clone(), s);
                }
                if let Some(i) = i {
                    self.top().ifaces.insert(n, i);
                }
            }
            self.depth += 1;
            self.nl.hier.push((iname.clone(), module.clone()));
            let r = self.module_body(&d);
            self.depth -= 1;
            self.stack = ps;
            self.prefix = pp;
            self.gpath = pg;
            r?;
        }
        Ok(())
    }

    /// gate-level netlist reading: instantiate a technology library cell directly
    fn lib_inst(&mut self, cell: &str, pins: &[(String, Dir)], name: &str, conns: &[(Option<String>, Option<Expr>)], loc: &str) -> ER<()> {
        let iname = format!("{}{}{}", self.prefix, self.gpath, name);
        let pd: Vec<(&str, Dir)> = pins.iter().map(|(n, d)| (n.as_str(), *d)).collect();
        let c = self.nl.add_cell(&iname, Kind::Lib(cell.to_string()), &pd);
        for (ci, (pn, e)) in conns.iter().enumerate() {
            let Some(e) = e else { continue };
            let pname = match pn {
                Some(p) => p.clone(),
                None => pins.get(ci).map(|x| x.0.clone()).ok_or_else(|| format!("{}: too many positional connections on {}", loc, cell))?,
            };
            let Some(pi) = pins.iter().position(|x| x.0 == pname) else {
                return Err(format!("{}: library cell '{}' has no pin '{}' (LINK-25)", loc, cell, pname));
            };
            let net = if pins[pi].1 == Dir::In { self.evw(e, 1)?[0] } else { self.lval(e)?[0] };
            self.nl.connect(c, pi, net);
        }
        self.nl.mapped = true;
        Ok(())
    }

    fn bind_iface(&mut self, ce: &Expr, count: usize, k: usize, loc: &str) -> ER<IfInst> {
        let (name, sel): (String, Option<(i64, i64)>) = match ce {
            Expr::Id(n) => (n.clone(), None),
            Expr::Index(b, i) => (expr_name(b).unwrap_or_default(), Some({
                let v = self.ceval(i)? as i64;
                (v, v)
            })),
            Expr::Range(b, a, c) => (expr_name(b).unwrap_or_default(), Some((self.ceval(a)? as i64, self.ceval(c)? as i64))),
            _ => return Err(format!("{}: unsupported interface connection", loc)),
        };
        let ii = self.lookup_iface(&name).ok_or_else(|| format!("{}: '{}' is not an interface instance (ELAB-965)", loc, name))?;
        let mut els: Vec<HashMap<String, Sig>> = ii.elems.clone();
        let mut lo = ii.lo;
        if let Some((a, b)) = sel {
            let (l, h) = (a.min(b), a.max(b));
            els = (l..=h).map(|i| ii.elems[(i - ii.lo) as usize].clone()).collect();
            lo = l;
        }
        if count > 1 && els.len() == count {
            // instance array: one element per instance
            return Ok(IfInst { def: ii.def, lo: 0, elems: vec![els[k].clone()], is_array: false });
        }
        let arr = els.len() > 1 || ii.is_array && sel.map(|(a, b)| a != b).unwrap_or(true);
        Ok(IfInst { def: ii.def, lo, elems: els, is_array: arr })
    }

    #[allow(clippy::too_many_arguments)]
    fn blackbox_inst(&mut self, def: Option<&Module>, module: &str, iname: &str, conns: &[(Option<String>, Option<Expr>)], wildcard: bool, ov: &[(String, i128)], k: usize, count: usize, loc: &str) -> ER<()> {
        let reason: &'static str = match def {
            None => "unresolved",
            Some(d) if d.blackbox => "blackbox",
            Some(d) if d.is_empty() => "empty",
            _ => "user",
        };
        match reason {
            "unresolved" => crate::warn!("LINK-5", "[BLACKBOX] Unable to resolve reference '{}' in '{}' ({}). Creating black box; pin directions inferred from connectivity.", module, iname, loc),
            "empty" => crate::warn!("ELAB-EMPTY", "[EMPTY MODULE] '{}' (instance {}) has ports but no content; kept as empty hierarchical black box", module, iname),
            _ => crate::info!("LINK-BB", "[BLACKBOX] Instance '{}' of '{}' treated as black box (imported without implementation)", iname, module),
        }
        self.bbs.push((iname.to_string(), module.to_string(), reason));
        let mut pins: Vec<(String, Dir, NetId)> = vec![];
        let mut unresolved_dir = vec![];
        if let Some(d) = def {
            // shapes in child param scope
            let saved = std::mem::replace(&mut self.stack, vec![Scope { boundary: true, ..Default::default() }]);
            let r = self.bind_params(d, ov, &HashMap::new());
            let mut shapes = vec![];
            if r.is_ok() {
                for p in &d.ports {
                    shapes.push(if p.iface.is_some() { None } else { Some(self.type_dims(&p.ty, &p.unpacked)) });
                }
            }
            self.stack = saved;
            r?;
            for (pi, p) in d.ports.iter().enumerate() {
                let Some(sh) = shapes[pi].clone() else {
                    crate::warn!("ELAB-966", "Interface port '{}' on black box '{}' left unconnected", p.name, module);
                    continue;
                };
                let (dims, _, _) = sh?;
                let w: usize = dims.iter().map(|(a, b)| ((a - b).unsigned_abs() + 1) as usize).product::<usize>().max(1);
                let conn: Option<Expr> = conns.iter().enumerate().find_map(|(ci, (n, e))| match n {
                    Some(n) if n == &p.name => Some(e.clone()),
                    None if ci == pi => Some(e.clone()),
                    _ => None,
                }).flatten().or_else(|| if wildcard { Some(Expr::Id(p.name.clone())) } else { None });
                let dir = p.dir.unwrap_or(Dir::InOut);
                let names = bit_names(&p.name, &dims);
                let bits: Vec<NetId> = match conn {
                    None => names.iter().map(|n| self.nl.add_net(&format!("{}/{}", iname, n))).collect(),
                    Some(ce) => {
                        let cw = self.swidth(&ce)?;
                        let slice = count > 1 && cw == w * count;
                        let mut v = if dir == Dir::In { self.evw(&ce, if slice { w * count } else { w })? } else { self.lval(&ce)? };
                        if slice {
                            v = v[k * w..(k + 1) * w].to_vec();
                        }
                        while v.len() < w {
                            let n = self.nl.add_net(&format!("{}/{}_nc{}", iname, p.name, v.len()));
                            v.push(n);
                        }
                        v.truncate(w);
                        v
                    }
                };
                for (n, b) in names.iter().zip(bits) {
                    pins.push((n.clone(), dir, b));
                }
            }
        } else {
            for (ci, (n, e)) in conns.iter().enumerate() {
                let pn = n.clone().unwrap_or(format!("p{}", ci));
                let Some(e) = e else { continue };
                let v = match self.lval(e) {
                    Ok(v) => v,
                    Err(_) => {
                        let w = self.swidth(e)?;
                        self.evw(e, w)?
                    }
                };
                let w = v.len();
                for (bi, b) in v.into_iter().enumerate() {
                    let nm = if w > 1 { format!("{}[{}]", pn, bi) } else { pn.clone() };
                    unresolved_dir.push(pins.len());
                    pins.push((nm, Dir::InOut, b));
                }
            }
        }
        let pdesc: Vec<(&str, Dir)> = pins.iter().map(|(n, d, _)| (n.as_str(), *d)).collect();
        let c = self.nl.add_cell(iname, Kind::BlackBox(module.to_string()), &pdesc);
        self.nl.cell_mut(c).attrs.push(reason.to_string());
        self.nl.cell_mut(c).dont_touch = true;
        for (i, (_, _, n)) in pins.iter().enumerate() {
            self.nl.connect(c, i, *n);
        }
        for i in unresolved_dir {
            self.unresolved_pins.push((c, i));
        }
        Ok(())
    }

    fn finish(&mut self) -> ER<()> {
        // resolve unresolved black-box pin directions
        let ups = std::mem::take(&mut self.unresolved_pins);
        for (c, p) in ups {
            let Some(n) = self.nl.cell(c).pins[p].net else { continue };
            let other_driver = self.nl.net(n).conns.iter().any(|pr| *pr != PinRef::Cell(c, p) && self.nl.is_driver(*pr) && !matches!(pr, PinRef::Cell(cc, _) if *cc == c));
            let d = if other_driver { Dir::In } else { Dir::Out };
            self.nl.cell_mut(c).pins[p].dir = d;
            let cn = self.nl.cell(c).name.clone();
            let pn = self.nl.cell(c).pins[p].name.clone();
            crate::info!("LINK-6", "[BLACKBOX] Inferred direction of pin '{}/{}' as {}", cn, pn, if d == Dir::In { "input" } else { "output" });
        }
        // multi-driven detection
        for n in self.nl.net_ids() {
            let d = self.nl.drivers(n);
            if d.len() > 1 {
                let names: Vec<String> = d.iter().map(|p| self.nl.pin_name(*p)).collect();
                crate::warn!("ELAB-366", "Net '{}' is MULTI-DRIVEN by {} drivers: {}", self.nl.net(n).name, d.len(), names.join(", "));
            }
        }
        Ok(())
    }
}

fn reg_name(net: &str) -> String {
    // u/g[1].x/q[3] -> u/g[1].x/q_reg[3] ; bus[0].valid -> bus[0].valid_reg
    let seg_start = net.rfind('/').map(|i| i + 1).unwrap_or(0);
    let seg = &net[seg_start..];
    // last '.'-separated member outside brackets
    let mut depth = 0;
    let mut mstart = 0;
    for (i, ch) in seg.char_indices() {
        match ch {
            '[' => depth += 1,
            ']' => depth -= 1,
            '.' if depth == 0 => mstart = i + 1,
            _ => {}
        }
    }
    let base = &net[..seg_start + mstart];
    let leaf = &seg[mstart..];
    match leaf.find('[') {
        Some(i) => format!("{}{}_reg{}", base, &leaf[..i], &leaf[i..]),
        None => format!("{}{}_reg", base, leaf),
    }
}

fn cols_len_gt2(v: &[NetId]) -> bool {
    v.len() >= 2
}
