//! Small backtracking regular-expression engine (std only) for `-regexp` object queries and
//! `=~` filters. Supports: literals, `.`, `[...]` / `[^...]` classes with ranges, `\d \w \s \D \W \S`,
//! escapes (`\.` `\[` ...), groups `( )` and `(?: )`, alternation `|`, quantifiers `* + ? {m} {m,} {m,n}`
//! (greedy, `?` suffix = lazy), anchors `^ $`.

#[derive(Debug, Clone)]
enum Node {
    Char(char),
    Any,
    Class(Vec<(char, char)>, bool),
    Group(Box<Node>),
    Cap(usize, Box<Node>),
    Alt(Vec<Node>),
    Seq(Vec<Node>),
    Repeat(Box<Node>, usize, usize, bool),
    Start,
    End,
}

#[derive(Debug, Clone)]
pub struct Regex {
    root: Node,
    ncap: usize,
}

struct P<'a> {
    s: &'a [char],
    i: usize,
    ncap: usize,
}

fn class_esc(c: char) -> Option<(Vec<(char, char)>, bool)> {
    let d = vec![('0', '9')];
    let w = vec![('a', 'z'), ('A', 'Z'), ('0', '9'), ('_', '_')];
    let sp = vec![(' ', ' '), ('\t', '\t'), ('\n', '\n'), ('\r', '\r')];
    Some(match c {
        'd' => (d, false),
        'D' => (d, true),
        'w' => (w, false),
        'W' => (w, true),
        's' => (sp, false),
        'S' => (sp, true),
        _ => return None,
    })
}

impl<'a> P<'a> {
    fn peek(&self) -> Option<char> {
        self.s.get(self.i).copied()
    }
    fn alt(&mut self) -> Result<Node, String> {
        let mut v = vec![self.seq()?];
        while self.peek() == Some('|') {
            self.i += 1;
            v.push(self.seq()?);
        }
        Ok(if v.len() == 1 { v.pop().unwrap() } else { Node::Alt(v) })
    }
    fn seq(&mut self) -> Result<Node, String> {
        let mut v = vec![];
        while let Some(c) = self.peek() {
            if c == '|' || c == ')' {
                break;
            }
            let atom = self.atom()?;
            v.push(self.quant(atom)?);
        }
        Ok(Node::Seq(v))
    }
    fn quant(&mut self, a: Node) -> Result<Node, String> {
        let (lo, hi) = match self.peek() {
            Some('*') => {
                self.i += 1;
                (0, usize::MAX)
            }
            Some('+') => {
                self.i += 1;
                (1, usize::MAX)
            }
            Some('?') => {
                self.i += 1;
                (0, 1)
            }
            Some('{') => {
                let save = self.i;
                self.i += 1;
                let mut num = String::new();
                while let Some(c) = self.peek().filter(|c| c.is_ascii_digit() || *c == ',') {
                    num.push(c);
                    self.i += 1;
                }
                if self.peek() != Some('}') || num.is_empty() {
                    self.i = save;
                    return Ok(a);
                }
                self.i += 1;
                let (l, h) = match num.split_once(',') {
                    None => {
                        let n = num.parse().map_err(|_| "bad {m}".to_string())?;
                        (n, n)
                    }
                    Some((l, "")) => (l.parse().map_err(|_| "bad {m,}".to_string())?, usize::MAX),
                    Some((l, h)) => (l.parse().map_err(|_| "bad {m,n}".to_string())?, h.parse().map_err(|_| "bad {m,n}".to_string())?),
                };
                (l, h)
            }
            _ => return Ok(a),
        };
        let lazy = if self.peek() == Some('?') {
            self.i += 1;
            true
        } else {
            false
        };
        Ok(Node::Repeat(Box::new(a), lo, hi, lazy))
    }
    fn atom(&mut self) -> Result<Node, String> {
        let c = self.peek().ok_or("unexpected end")?;
        self.i += 1;
        Ok(match c {
            '.' => Node::Any,
            '^' => Node::Start,
            '$' => Node::End,
            '(' => {
                let mut cap = None;
                if self.s.get(self.i) == Some(&'?') && self.s.get(self.i + 1) == Some(&':') {
                    self.i += 2;
                } else {
                    self.ncap += 1;
                    cap = Some(self.ncap);
                }
                let n = self.alt()?;
                if self.peek() != Some(')') {
                    return Err("missing )".into());
                }
                self.i += 1;
                match cap {
                    Some(k) => Node::Cap(k, Box::new(n)),
                    None => Node::Group(Box::new(n)),
                }
            }
            '[' => {
                let mut neg = false;
                if self.peek() == Some('^') {
                    neg = true;
                    self.i += 1;
                }
                let mut rs = vec![];
                let mut first = true;
                loop {
                    let Some(c) = self.peek() else { return Err("missing ]".into()) };
                    self.i += 1;
                    if c == ']' && !first {
                        break;
                    }
                    first = false;
                    let lo = if c == '\\' {
                        let e = self.peek().ok_or("bad escape")?;
                        self.i += 1;
                        if let Some((v, n)) = class_esc(e) {
                            if !n {
                                rs.extend(v);
                            }
                            continue;
                        }
                        e
                    } else {
                        c
                    };
                    if self.peek() == Some('-') && self.s.get(self.i + 1).map(|x| *x != ']').unwrap_or(false) {
                        self.i += 1;
                        let mut hi = self.peek().unwrap();
                        self.i += 1;
                        if hi == '\\' {
                            hi = self.peek().ok_or("bad escape")?;
                            self.i += 1;
                        }
                        rs.push((lo, hi));
                    } else {
                        rs.push((lo, lo));
                    }
                }
                Node::Class(rs, neg)
            }
            '\\' => {
                let e = self.peek().ok_or("trailing backslash")?;
                self.i += 1;
                if let Some((v, n)) = class_esc(e) {
                    Node::Class(v, n)
                } else {
                    Node::Char(match e {
                        'n' => '\n',
                        't' => '\t',
                        x => x,
                    })
                }
            }
            '*' | '+' | '?' => return Err(format!("quantifier '{}' without operand", c)),
            x => Node::Char(x),
        })
    }
}

impl Regex {
    pub fn new(pat: &str) -> Result<Regex, String> {
        let s: Vec<char> = pat.chars().collect();
        let mut p = P { s: &s, i: 0, ncap: 0 };
        let root = p.alt()?;
        if p.i != s.len() {
            return Err(format!("unbalanced ')' at {}", p.i));
        }
        Ok(Regex { root, ncap: p.ncap })
    }
    /// unanchored search (Tcl `regexp` semantics)
    pub fn is_match(&self, text: &str) -> bool {
        let t: Vec<char> = text.chars().collect();
        (0..=t.len()).any(|st| m(&self.root, &t, st, &mut |_| true))
    }
    /// whole-string match (Synopsys `-regexp` name matching)
    pub fn full_match(&self, text: &str) -> bool {
        let t: Vec<char> = text.chars().collect();
        let n = t.len();
        m(&self.root, &t, 0, &mut |e| e == n)
    }
}

impl Regex {
    pub fn groups(&self) -> usize {
        self.ncap
    }
    /// leftmost match at or after char index `from`: whole-match span + capture spans (char indices)
    pub fn find_at(&self, t: &[char], from: usize) -> Option<Vec<Option<(usize, usize)>>> {
        for st in from..=t.len() {
            let caps = std::cell::RefCell::new(vec![None; self.ncap + 1]);
            let mut end = None;
            if mc(&self.root, t, st, &caps, &mut |e| {
                end = Some(e);
                true
            }) {
                let mut v = caps.into_inner();
                v[0] = Some((st, end.unwrap()));
                return Some(v);
            }
        }
        None
    }
}

type Caps = std::cell::RefCell<Vec<Option<(usize, usize)>>>;

/// matcher that records capture groups
fn mc(n: &Node, t: &[char], i: usize, c: &Caps, k: &mut dyn FnMut(usize) -> bool) -> bool {
    match n {
        Node::Cap(idx, g) => {
            let old = c.borrow()[*idx];
            let ok = mc(g, t, i, c, &mut |j| {
                let prev = c.borrow()[*idx];
                c.borrow_mut()[*idx] = Some((i, j));
                if k(j) {
                    true
                } else {
                    c.borrow_mut()[*idx] = prev;
                    false
                }
            });
            if !ok {
                c.borrow_mut()[*idx] = old;
            }
            ok
        }
        Node::Group(g) => mc(g, t, i, c, k),
        Node::Alt(v) => v.iter().any(|a| mc(a, t, i, c, k)),
        Node::Seq(v) => seqc(v, t, i, c, k),
        Node::Repeat(a, lo, hi, lazy) => repc(a, *lo, *hi, *lazy, t, i, 0, c, k),
        other => m(other, t, i, k),
    }
}
fn seqc(v: &[Node], t: &[char], i: usize, c: &Caps, k: &mut dyn FnMut(usize) -> bool) -> bool {
    match v.split_first() {
        None => k(i),
        Some((f, rest)) => mc(f, t, i, c, &mut |j| seqc(rest, t, j, c, k)),
    }
}
#[allow(clippy::too_many_arguments)]
fn repc(a: &Node, lo: usize, hi: usize, lazy: bool, t: &[char], i: usize, cnt: usize, c: &Caps, k: &mut dyn FnMut(usize) -> bool) -> bool {
    if cnt > t.len() + 1 {
        return false;
    }
    let more = |k: &mut dyn FnMut(usize) -> bool| cnt < hi && mc(a, t, i, c, &mut |j| j != i && repc(a, lo, hi, lazy, t, j, cnt + 1, c, k));
    if cnt < lo {
        return mc(a, t, i, c, &mut |j| repc(a, lo, hi, lazy, t, j, cnt + 1, c, k));
    }
    if lazy {
        k(i) || more(k)
    } else {
        more(k) || k(i)
    }
}

/// match node `n` at position `i`, calling `k` with the end position (continuation passing)
fn m(n: &Node, t: &[char], i: usize, k: &mut dyn FnMut(usize) -> bool) -> bool {
    match n {
        Node::Char(c) => t.get(i) == Some(c) && k(i + 1),
        Node::Any => i < t.len() && k(i + 1),
        Node::Class(rs, neg) => match t.get(i) {
            Some(c) => (rs.iter().any(|(a, b)| c >= a && c <= b) != *neg) && k(i + 1),
            None => false,
        },
        Node::Start => i == 0 && k(i),
        Node::End => i == t.len() && k(i),
        Node::Group(g) | Node::Cap(_, g) => m(g, t, i, k),
        Node::Alt(v) => v.iter().any(|a| m(a, t, i, k)),
        Node::Seq(v) => seq(v, t, i, k),
        Node::Repeat(a, lo, hi, lazy) => rep(a, *lo, *hi, *lazy, t, i, 0, k),
    }
}

fn seq(v: &[Node], t: &[char], i: usize, k: &mut dyn FnMut(usize) -> bool) -> bool {
    match v.split_first() {
        None => k(i),
        Some((f, rest)) => m(f, t, i, &mut |j| seq(rest, t, j, k)),
    }
}

#[allow(clippy::too_many_arguments)]
fn rep(a: &Node, lo: usize, hi: usize, lazy: bool, t: &[char], i: usize, cnt: usize, k: &mut dyn FnMut(usize) -> bool) -> bool {
    if cnt > t.len() + 1 {
        return false;
    }
    let more = |k: &mut dyn FnMut(usize) -> bool| cnt < hi && m(a, t, i, &mut |j| j != i && rep(a, lo, hi, lazy, t, j, cnt + 1, k));
    if cnt < lo {
        return m(a, t, i, &mut |j| rep(a, lo, hi, lazy, t, j, cnt + 1, k));
    }
    if lazy {
        k(i) || more(k)
    } else {
        more(k) || k(i)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn basics() {
        let r = Regex::new(r"u_alu/U\d+").unwrap();
        assert!(r.full_match("u_alu/U182"));
        assert!(!r.full_match("u_alu/U182/A"));
        assert!(Regex::new(r"q_reg\[[0-3]\]").unwrap().full_match("q_reg[2]"));
        assert!(!Regex::new(r"q_reg\[[0-3]\]").unwrap().full_match("q_reg[5]"));
        assert!(Regex::new("^(din|dout)_.*$").unwrap().is_match("dout_vld"));
        assert!(Regex::new("a{2,3}b").unwrap().full_match("aaab"));
        assert!(!Regex::new("a{2,3}b").unwrap().full_match("aaaab"));
        assert!(Regex::new("x.*?y").unwrap().full_match("x12y"));
        assert!(Regex::new("[^/]+").unwrap().full_match("abc"));
        assert!(!Regex::new("[^/]+").unwrap().full_match("a/c"));
        assert!(Regex::new(r"(?:ab)+").unwrap().full_match("ababab"));
        assert!(Regex::new("XOR|XNOR").unwrap().is_match("XNOR2_X1_LVT"));
        let r = Regex::new(r"(\w+)_X(\d)_(\w+)").unwrap();
        let t: Vec<char> = "AND2_X1_SVT".chars().collect();
        let c = r.find_at(&t, 0).unwrap();
        assert_eq!(c[2], Some((6, 7)));
        let r = Regex::new("X1$").unwrap();
        let t: Vec<char> = "BUF_X1".chars().collect();
        assert_eq!(r.find_at(&t, 0).unwrap()[0], Some((4, 6)));
    }
}
