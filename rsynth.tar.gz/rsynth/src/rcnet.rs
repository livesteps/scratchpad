//! RC-tree interconnect delay calculation.
//!
//! One `RcTree` per net (node 0 = driver pin, parents before children), built by the
//! global-route timing engine (`grtime`), the post-route extractor (`droute::extract`) or the
//! SPEF reader. On it:
//!
//! * transfer-function moments m1..m3 at every node (path tracing, O(n) per moment)
//!   H(s) = 1 + m1 s + m2 s^2 + m3 s^3 + ...      (m1 = -Elmore)
//! * metrics: Elmore (-m1), D2M = ln2 * m1^2 / sqrt(m2), S2M step slew = ln9 * sqrt(2 m2 - m1^2)
//! * AWE: two-pole Pade [1/2] fit of m1..m3 -> poles / residues; the ramp response is
//!   evaluated in closed form and its 50 % / 10-90 % crossings give delay and slew.
//!   Unstable or complex fits fall back to one pole (tau = Elmore).
//! * driving-point admittance moments y1..y3 -> O'Brien-Savarino pi model (C1 - R - C2)
//! * effective capacitance of the pi model for a ramp driver (charge matching over the ramp)
//! * a transient reference solver (trapezoidal integration, O(n) tree elimination per step)
//!   used by `report_delay_calculation -reference` and `check_delay_calculation`.
//!
//! Units: R kOhm, C pF, time ns.

use crate::netlist::{NetId, PinRef};

pub const ROOT: u32 = u32::MAX;

#[derive(Clone, Debug, Default)]
pub struct RcTree {
    pub par: Vec<u32>,
    /// resistance to the parent (kOhm)
    pub r: Vec<f64>,
    /// grounded capacitance at the node, including load-pin capacitance (pF)
    pub c: Vec<f64>,
    /// load-pin part of `c` (pF), for reports
    pub cpin: Vec<f64>,
    /// coupling capacitance to other nets: (node, aggressor net, pF)
    pub cc: Vec<(u32, NetId, f64)>,
    /// pin -> node (the driver is at node 0)
    pub pins: Vec<(PinRef, u32)>,
    /// origin of the parasitics ("groute", "extract-fast", "extract-detailed", "spef")
    pub src: &'static str,
}

/// Interconnect results for one node (sink)
#[derive(Clone, Copy, Debug, Default)]
pub struct NodeMoments {
    pub m1: f64,
    pub m2: f64,
    pub m3: f64,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct PiModel {
    pub c1: f64,
    pub r: f64,
    pub c2: f64,
}

/// Two-pole (or one-pole) step response v(t) = 1 + sum k_i exp(p_i t)
#[derive(Clone, Copy, Debug)]
pub struct Poles {
    pub n: usize,
    pub p: [f64; 2],
    pub k: [f64; 2],
}

impl RcTree {
    pub fn len(&self) -> usize {
        self.c.len()
    }
    pub fn is_empty(&self) -> bool {
        self.c.is_empty()
    }
    pub fn add_node(&mut self, parent: u32, r: f64, c: f64) -> u32 {
        self.par.push(parent);
        self.r.push(r);
        self.c.push(c);
        self.cpin.push(0.0);
        (self.c.len() - 1) as u32
    }
    pub fn node_of(&self, p: PinRef) -> Option<usize> {
        self.pins.iter().find(|(q, _)| *q == p).map(|x| x.1 as usize)
    }
    pub fn wire_cap(&self) -> f64 {
        self.c.iter().sum::<f64>() - self.cpin.iter().sum::<f64>() + self.cc.iter().map(|x| x.2).sum::<f64>()
    }
    pub fn coupling_cap(&self) -> f64 {
        self.cc.iter().map(|x| x.2).sum()
    }
    pub fn total_r(&self) -> f64 {
        self.r.iter().sum()
    }
    /// grounded capacitance per node with coupling capacitance scaled by the Miller factor
    pub fn cap_vec(&self, miller: f64) -> Vec<f64> {
        let mut c = self.c.clone();
        for (n, _, v) in &self.cc {
            if let Some(x) = c.get_mut(*n as usize) {
                *x += v * miller;
            }
        }
        c
    }
    /// all nodes: m1..m3 (path tracing; parents precede children)
    pub fn moments(&self, miller: f64) -> Vec<NodeMoments> {
        let n = self.len();
        let cap = self.cap_vec(miller);
        let mut prev = vec![1.0f64; n]; // m0
        let mut out = vec![NodeMoments::default(); n];
        for k in 1..=3 {
            // downstream "charge" sum of C_j * m_{k-1}(j)
            let mut q: Vec<f64> = (0..n).map(|j| cap[j] * prev[j]).collect();
            for i in (1..n).rev() {
                let p = self.par[i];
                if p != ROOT {
                    let v = q[i];
                    q[p as usize] += v;
                }
            }
            let mut m = vec![0.0f64; n];
            for i in 1..n {
                let p = self.par[i];
                if p != ROOT {
                    m[i] = m[p as usize] - self.r[i] * q[i];
                }
            }
            for i in 0..n {
                match k {
                    1 => out[i].m1 = m[i],
                    2 => out[i].m2 = m[i],
                    _ => out[i].m3 = m[i],
                }
            }
            prev = m;
        }
        out
    }
    /// driving-point admittance moments Y(s) = y1 s + y2 s^2 + y3 s^3
    pub fn admittance(&self, mom: &[NodeMoments], miller: f64) -> (f64, f64, f64) {
        let cap = self.cap_vec(miller);
        let mut y = (0.0, 0.0, 0.0);
        for (i, c) in cap.iter().enumerate() {
            y.0 += c;
            y.1 += c * mom[i].m1;
            y.2 += c * mom[i].m2;
        }
        y
    }
    pub fn pi_model(&self, mom: &[NodeMoments], miller: f64) -> PiModel {
        let (y1, y2, y3) = self.admittance(mom, miller);
        pi_from_y(y1, y2, y3)
    }

    /// Transient reference: ramp 0 -> 1 of full duration `t_ramp` applied through `rdrv`
    /// (kOhm, >= 1e-6) at the root. Backward-Euler integration (L-stable: no ringing on stiff
    /// nodes) with O(n) tree elimination per step. Returns per requested node (t50, t10, t90).
    pub fn simulate(&self, rdrv: f64, t_ramp: f64, miller: f64, nodes: &[usize]) -> Vec<(f64, f64, f64)> {
        let n = self.len();
        let cap: Vec<f64> = self.cap_vec(miller).iter().map(|c| c.max(1e-9)).collect();
        let g0 = 1.0 / rdrv.max(1e-6);
        let g: Vec<f64> = (0..n).map(|i| if i == 0 || self.r[i] <= 1e-9 { 1e9 } else { 1.0 / self.r[i] }).collect();
        let mom = self.moments(miller);
        let el = mom.iter().map(|m| -m.m1).fold(0.0f64, f64::max) + rdrv * cap.iter().sum::<f64>();
        let t_end = t_ramp + 12.0 * el.max(1e-6);
        let steps = 60000usize;
        let h = t_end / steps as f64;
        // A = C/h + G
        let mut d: Vec<f64> = (0..n).map(|i| cap[i] / h).collect();
        d[0] += g0;
        for i in 1..n {
            let p = self.par[i] as usize;
            d[i] += g[i];
            d[p] += g[i];
        }
        for i in (1..n).rev() {
            let p = self.par[i] as usize;
            d[p] -= g[i] * g[i] / d[i];
        }
        let vin = |t: f64| -> f64 { if t_ramp <= 0.0 { if t > 0.0 { 1.0 } else { 0.0 } } else { (t / t_ramp).clamp(0.0, 1.0) } };
        let mut v = vec![0.0f64; n];
        let mut res = vec![(f64::NAN, f64::NAN, f64::NAN); nodes.len()];
        let mut prev: Vec<f64> = vec![0.0; nodes.len()];
        let mut rhs = vec![0.0f64; n];
        for s in 0..steps {
            let t0 = s as f64 * h;
            let t1 = t0 + h;
            for i in 0..n {
                rhs[i] = cap[i] / h * v[i];
            }
            rhs[0] += g0 * vin(t1);
            for i in (1..n).rev() {
                let p = self.par[i] as usize;
                let add = g[i] * rhs[i] / d[i];
                rhs[p] += add;
            }
            v[0] = rhs[0] / d[0];
            for i in 1..n {
                let p = self.par[i] as usize;
                v[i] = (rhs[i] + g[i] * v[p]) / d[i];
            }
            for (k, &nd) in nodes.iter().enumerate() {
                let (a, b) = (prev[k], v[nd]);
                for (lvl, slot) in [(0.5, 0usize), (0.1, 1), (0.9, 2)] {
                    let cur = match slot { 0 => res[k].0, 1 => res[k].1, _ => res[k].2 };
                    if cur.is_nan() && a < lvl && b >= lvl {
                        let tc = t0 + h * (lvl - a) / (b - a);
                        match slot { 0 => res[k].0 = tc, 1 => res[k].1 = tc, _ => res[k].2 = tc }
                    }
                }
                prev[k] = b;
            }
        }
        res
    }
}

pub fn pi_from_y(y1: f64, y2: f64, y3: f64) -> PiModel {
    if y2.abs() < 1e-18 || y3 <= 0.0 || y2 >= 0.0 {
        return PiModel { c1: y1, r: 0.0, c2: 0.0 };
    }
    let c2 = (y2 * y2 / y3).min(y1);
    let r = -(y3 * y3) / (y2 * y2 * y2);
    PiModel { c1: (y1 - c2).max(0.0), r, c2 }
}

pub fn elmore(m: &NodeMoments) -> f64 {
    (-m.m1).max(0.0)
}
pub fn d2m(m: &NodeMoments) -> f64 {
    if m.m2 <= 0.0 {
        return elmore(m);
    }
    (std::f64::consts::LN_2 * m.m1 * m.m1 / m.m2.sqrt()).min(elmore(m))
}
/// step-response 10-90 % slew metric (S2M)
pub fn s2m(m: &NodeMoments) -> f64 {
    let v = 2.0 * m.m2 - m.m1 * m.m1;
    if v <= 0.0 {
        return 9f64.ln() * elmore(m);
    }
    9f64.ln() * v.sqrt()
}

/// AWE two-pole Pade [1/2] from m1..m3; falls back to one pole when the fit is not a pair of
/// real negative poles.
pub fn awe(m: &NodeMoments) -> Poles {
    let one = |tau: f64| -> Poles {
        let tau = tau.max(1e-12);
        Poles { n: 1, p: [-1.0 / tau, 0.0], k: [-1.0, 0.0] }
    };
    let (m1, m2, m3) = (m.m1, m.m2, m.m3);
    if m1 >= -1e-15 {
        return one(1e-12);
    }
    // [m1 1; m2 m1] [b1; b2] = -[m2; m3]
    let det = m1 * m1 - m2;
    if det.abs() < 1e-30 {
        return one(-m1);
    }
    let b1 = (-m2 * m1 + m3) / det;
    let b2 = (-m3 * m1 + m2 * m2) / det;
    let a1 = m1 + b1;
    let disc = b1 * b1 - 4.0 * b2;
    if b2 <= 0.0 || disc <= 0.0 || b1 <= 0.0 {
        return one(-m1);
    }
    let sq = disc.sqrt();
    let p1 = (-b1 + sq) / (2.0 * b2);
    let p2 = (-b1 - sq) / (2.0 * b2);
    if p1 >= 0.0 || p2 >= 0.0 || (p1 - p2).abs() < 1e-18 {
        return one(-m1);
    }
    let k1 = (1.0 + a1 * p1) / (b2 * p1 * (p1 - p2));
    let k2 = (1.0 + a1 * p2) / (b2 * p2 * (p2 - p1));
    // residues must give v(0) ~ 0 and a monotone-enough response
    if !(k1.is_finite() && k2.is_finite()) || (1.0 + k1 + k2).abs() > 0.05 {
        return one(-m1);
    }
    Poles { n: 2, p: [p1, p2], k: [k1, k2] }
}

impl Poles {
    /// integral of the step response from 0 to t
    fn g(&self, t: f64) -> f64 {
        if t <= 0.0 {
            return 0.0;
        }
        let mut v = t;
        for i in 0..self.n {
            v += self.k[i] * ((self.p[i] * t).exp() - 1.0) / self.p[i];
        }
        v
    }
    fn step(&self, t: f64) -> f64 {
        if t <= 0.0 {
            return 0.0;
        }
        let mut v = 1.0;
        for i in 0..self.n {
            v += self.k[i] * (self.p[i] * t).exp();
        }
        v
    }
    /// response to a 0 -> 1 ramp of full duration T
    pub fn ramp(&self, t: f64, tr: f64) -> f64 {
        if tr <= 1e-12 {
            return self.step(t);
        }
        (self.g(t) - self.g(t - tr)) / tr
    }
    pub fn slowest(&self) -> f64 {
        (0..self.n).map(|i| -1.0 / self.p[i]).fold(0.0f64, f64::max)
    }
    /// first crossing of `lvl` for a ramp of full duration T
    pub fn cross(&self, lvl: f64, tr: f64) -> f64 {
        let t_max = tr + 30.0 * self.slowest().max(1e-9);
        let n = 400;
        let mut lo = 0.0;
        let mut hi = t_max;
        let mut prev = 0.0;
        for i in 1..=n {
            let t = t_max * i as f64 / n as f64;
            let v = self.ramp(t, tr);
            if v >= lvl {
                lo = t_max * (i - 1) as f64 / n as f64;
                hi = t;
                break;
            }
            prev = v;
        }
        let _ = prev;
        for _ in 0..60 {
            let mid = 0.5 * (lo + hi);
            if self.ramp(mid, tr) >= lvl { hi = mid } else { lo = mid }
        }
        0.5 * (lo + hi)
    }
    /// (delay from the input 50 % point, 10-90 % output slew) for an input slew `sin` (10-90)
    pub fn delay_slew(&self, sin: f64) -> (f64, f64) {
        let tr = sin.max(0.0) / 0.8;
        let t50 = self.cross(0.5, tr);
        let t10 = self.cross(0.1, tr);
        let t90 = self.cross(0.9, tr);
        ((t50 - tr / 2.0).max(0.0), (t90 - t10).max(0.0))
    }
}

/// Effective capacitance of a pi load for a ramp driver of full duration `t` (charge matching
/// over the ramp): Ceff = C1 + C2 * (1 - tau/T * (1 - exp(-T/tau))), tau = R * C2.
pub fn ceff_ramp(pi: &PiModel, t: f64) -> f64 {
    if pi.c2 <= 0.0 || pi.r <= 0.0 {
        return pi.c1 + pi.c2;
    }
    let tau = pi.r * pi.c2;
    if t <= 1e-9 {
        return pi.c1;
    }
    let x = t / tau;
    let f = if x > 50.0 { 1.0 - 1.0 / x } else { 1.0 - (1.0 - (-x).exp()) / x };
    pi.c1 + pi.c2 * f
}

/// Ceff iteration with the driver tables: `tran(c)` = driver output 10-90 slew for load c.
/// Returns (Ceff, iterations).
pub fn ceff_iterate(pi: &PiModel, tran: &dyn Fn(f64) -> f64) -> (f64, usize) {
    let ctot = pi.c1 + pi.c2;
    let mut ce = ctot;
    let mut last_step = f64::MAX;
    for it in 1..=12 {
        let t = tran(ce).max(1e-6) / 0.8;
        let nx = ceff_ramp(pi, t).clamp(pi.c1, ctot);
        let step = (nx - ce).abs();
        if step <= 1e-4 * ctot.max(1e-6) {
            return (nx, it);
        }
        // plain fixed point; damp only if the iteration stops contracting
        ce = if step > 0.7 * last_step { 0.5 * (ce + nx) } else { nx };
        last_step = step;
    }
    (ce, 12)
}

/// Delay-calculation model
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Model {
    /// legacy: lumped estimate pre-route, Elmore on extracted nets, slew = sqrt(s^2 + (2.2 d)^2)
    Elmore,
    /// D2M delay, S2M slew combined with the input slew (PERI)
    D2m,
    /// AWE two-pole ramp response
    Awe,
}

impl Model {
    pub fn parse(s: &str) -> Option<Model> {
        match s.to_lowercase().as_str() {
            "elmore" | "lumped" => Some(Model::Elmore),
            "d2m" => Some(Model::D2m),
            "awe" | "pade" => Some(Model::Awe),
            _ => None,
        }
    }
    pub fn name(&self) -> &'static str {
        match self {
            Model::Elmore => "elmore",
            Model::D2m => "d2m",
            Model::Awe => "awe",
        }
    }
}

/// Wire delay and output slew at a sink for an input slew `sin`
pub fn wire_delay(model: Model, m: &NodeMoments, sin: f64) -> (f64, f64) {
    match model {
        Model::Elmore => {
            let d = elmore(m);
            (d, (sin * sin + (2.2 * d) * (2.2 * d)).sqrt())
        }
        Model::D2m => {
            // D2M is a step metric; for a ramp the delay moves towards Elmore (exact for slow
            // inputs). Blend with the single-pole ramp behaviour: d = D2M + (Elmore - D2M) f(T),
            // f = 0 for a step, 1 for an infinitely slow ramp.
            let (e, d0) = (elmore(m), d2m(m));
            let tau = e.max(1e-12);
            let one = Poles { n: 1, p: [-1.0 / tau, 0.0], k: [-1.0, 0.0] };
            let (d1, _) = one.delay_slew(sin);
            let f = ((d1 - std::f64::consts::LN_2 * tau) / ((1.0 - std::f64::consts::LN_2) * tau)).clamp(0.0, 1.0);
            let s = s2m(m);
            (d0 + (e - d0) * f, (sin * sin + s * s).sqrt())
        }
        Model::Awe => awe(m).delay_slew(sin),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn ladder(n: usize, r: f64, c: f64) -> RcTree {
        let mut t = RcTree::default();
        t.add_node(ROOT, 0.0, c / 2.0);
        for i in 1..=n {
            let cc = if i == n { c / 2.0 } else { c };
            t.add_node((i - 1) as u32, r, cc);
        }
        t
    }
    #[test]
    fn single_pole_exact() {
        let mut t = RcTree::default();
        t.add_node(ROOT, 0.0, 0.0);
        t.add_node(0, 1.0, 0.1); // tau = 0.1 ns
        let m = t.moments(1.0);
        assert!((elmore(&m[1]) - 0.1).abs() < 1e-12);
        assert!((d2m(&m[1]) - 0.1 * std::f64::consts::LN_2).abs() < 1e-9);
        let (d, s) = wire_delay(Model::Awe, &m[1], 0.0);
        assert!((d - 0.1 * std::f64::consts::LN_2).abs() < 1e-6, "{}", d);
        assert!((s - 0.1 * 9f64.ln()).abs() < 1e-5, "{}", s);
    }
    #[test]
    fn distributed_line_vs_reference() {
        // uniform line: 50 sections, total R 1k, C 0.2p -> RC = 0.2 ns
        let t = ladder(50, 0.02, 0.004);
        let m = t.moments(1.0);
        let far = t.len() - 1;
        let mid = far / 4;
        for (sin, nd) in [(0.0, far), (0.05, far), (0.05, mid), (0.3, far)] {
            let refr = t.simulate(1e-6, sin / 0.8, 1.0, &[nd])[0];
            let rd = refr.0 - sin / 0.8 / 2.0;
            let (ad, as_) = wire_delay(Model::Awe, &m[nd], sin);
            let (dd, _) = wire_delay(Model::D2m, &m[nd], sin);
            let ed = elmore(&m[nd]);
            let err = (ad - rd).abs() / rd;
            assert!(err < 0.05, "AWE delay {} vs ref {} (sin {}, node {})", ad, rd, sin, nd);
            assert!(ed >= rd * 0.99, "Elmore is an upper bound");
            assert!((dd - rd).abs() / rd < 0.30, "D2M {} vs ref {}", dd, rd);
            let rs = refr.2 - refr.1;
            assert!((as_ - rs).abs() / rs < 0.10, "AWE slew {} vs ref {}", as_, rs);
        }
    }
    #[test]
    fn pi_model_and_ceff() {
        let t = ladder(40, 0.05, 0.005); // resistive line, Ctot 0.2 pF
        let m = t.moments(1.0);
        let pi = t.pi_model(&m, 1.0);
        let ctot: f64 = t.c.iter().sum();
        assert!((pi.c1 + pi.c2 - ctot).abs() < 1e-9);
        assert!(pi.c2 > 0.0 && pi.r > 0.0);
        // fast driver: shielding -> Ceff close to C1; slow driver -> Ceff close to Ctot
        let fast = ceff_ramp(&pi, 0.01);
        let slow = ceff_ramp(&pi, 100.0);
        assert!(fast < 0.6 * ctot && slow > 0.95 * ctot, "{} {} {}", fast, slow, ctot);
        let (ce, it) = ceff_iterate(&pi, &|c| 0.02 + 2.0 * c);
        assert!(ce > pi.c1 && ce < ctot && it <= 8);
    }
    #[test]
    fn branch_tree_reference() {
        // root - trunk - two branches of different length
        let mut t = RcTree::default();
        t.add_node(ROOT, 0.0, 0.002);
        let mut last = 0u32;
        for _ in 0..10 { last = t.add_node(last, 0.03, 0.004); }
        let mut a = last;
        for _ in 0..20 { a = t.add_node(a, 0.03, 0.004); }
        let mut b = last;
        for _ in 0..3 { b = t.add_node(b, 0.03, 0.004); }
        t.c[a as usize] += 0.01;
        t.c[b as usize] += 0.01;
        let m = t.moments(1.0);
        let refr = t.simulate(1e-6, 0.0, 1.0, &[a as usize, b as usize]);
        for (k, nd) in [a, b].iter().enumerate() {
            let (ad, _) = wire_delay(Model::Awe, &m[*nd as usize], 0.0);
            let err = (ad - refr[k].0).abs() / refr[k].0;
            assert!(err < 0.08, "node {}: AWE {} ref {}", nd, ad, refr[k].0);
        }
    }
}
