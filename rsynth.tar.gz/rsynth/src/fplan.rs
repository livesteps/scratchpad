//! Floorplan engine: placement/routing blockages, route guides, move bounds
//! (soft / hard / exclusive / group), feedthrough permissions, IO pin planning
//! (individual constraints, bundles, bus arrays), constraint-honoring coarse
//! placement with density control, and a grid global router whose routed
//! lengths drive RC estimation in timing (place_opt).

use crate::netlist::*;
use std::collections::{BTreeMap, HashMap, HashSet};

pub type Rect = (f64, f64, f64, f64);

pub fn rnorm(r: Rect) -> Rect {
    (r.0.min(r.2), r.1.min(r.3), r.0.max(r.2), r.1.max(r.3))
}
pub fn inside(r: &Rect, p: (f64, f64)) -> bool {
    p.0 >= r.0 && p.0 <= r.2 && p.1 >= r.1 && p.1 <= r.3
}
pub fn area(r: &Rect) -> f64 {
    (r.2 - r.0).max(0.0) * (r.3 - r.1).max(0.0)
}
pub fn overlap(a: &Rect, b: &Rect) -> f64 {
    let x = (a.2.min(b.2) - a.0.max(b.0)).max(0.0);
    let y = (a.3.min(b.3) - a.1.max(b.1)).max(0.0);
    x * y
}
fn clamp_in(r: &Rect, p: (f64, f64), m: f64) -> (f64, f64) {
    let m = m.min((r.2 - r.0) / 2.0).min((r.3 - r.1) / 2.0).max(0.0);
    (p.0.clamp(r.0 + m, r.2 - m), p.1.clamp(r.1 + m, r.3 - m))
}
/// nearest point just outside rectangle r
fn push_out(r: &Rect, p: (f64, f64), die: &Rect, m: f64) -> (f64, f64) {
    let cands = [(r.0 - m, p.1), (r.2 + m, p.1), (p.0, r.1 - m), (p.0, r.3 + m)];
    let mut best = cands[0];
    let mut bd = f64::MAX;
    for c in cands {
        if !inside(die, c) {
            continue;
        }
        let d = (c.0 - p.0).abs() + (c.1 - p.1).abs();
        if d < bd {
            bd = d;
            best = c;
        }
    }
    best
}

#[derive(Clone, Debug, PartialEq)]
pub enum PbKind {
    Hard,
    Soft,
    Partial(f64),
    HardMacro,
}
#[derive(Clone, Debug)]
pub struct PBlockage {
    pub name: String,
    pub rect: Rect,
    pub kind: PbKind,
    pub source: String,
}
#[derive(Clone, Debug)]
pub struct RBlockage {
    pub name: String,
    pub rect: Rect,
    pub layers: Vec<String>,
    pub source: String,
}
#[derive(Clone, Debug)]
pub struct RGuide {
    pub name: String,
    pub rect: Rect,
    pub layers: Vec<String>,
    pub nets: Vec<String>,
    pub track_util: Option<f64>,
}
#[derive(Clone, Debug, PartialEq)]
pub enum BoundKind {
    Soft,
    Hard,
    Exclusive,
}
#[derive(Clone, Debug)]
pub struct Bound {
    pub name: String,
    pub kind: BoundKind,
    pub rect: Option<Rect>,
    pub dims: Option<(f64, f64)>,
    pub members: Vec<String>,
    pub source: String,
    pub resolved: Option<Rect>,
}
#[derive(Clone, Debug)]
pub struct Feedthrough {
    pub name: String,
    pub region: String,
    pub nets: Vec<String>,
    pub side: Option<String>,
}
#[derive(Clone, Debug, Default)]
pub struct PinCons {
    pub port: String,
    pub sides: Vec<String>,
    pub offset: Option<f64>,
    pub location: Option<(f64, f64)>,
    pub layers: Vec<String>,
}
#[derive(Clone, Debug, Default)]
pub struct Bundle {
    pub name: String,
    pub ports: Vec<String>,
    pub sides: Vec<String>,
    pub offset: Option<f64>,
    pub spacing: Option<f64>,
    pub layers: Vec<String>,
    pub order: String, // increasing | decreasing | interleave | given
}
#[derive(Clone, Debug)]
pub struct BlockPins {
    pub sides: Vec<String>,
    pub spacing: f64,
    pub layers: Vec<String>,
    pub corner_keepout: f64,
    pub group_buses: bool,
    /// first | balanced | round_robin over the allowed layers of a side's direction
    pub layer_assignment: String,
    pub pin_width: Option<f64>,
    pub pin_length: Option<f64>,
}
impl Default for BlockPins {
    fn default() -> Self {
        BlockPins { sides: vec!["left".into(), "top".into(), "right".into(), "bottom".into()], spacing: 1.0, layers: vec!["M3".into(), "M4".into()], corner_keepout: 2.0, group_buses: true, layer_assignment: "first".into(), pin_width: None, pin_length: None }
    }
}
#[derive(Clone, Debug)]
pub struct Layer {
    pub name: String,
    pub horiz: bool,
    pub pitch: f64,
    pub util: f64,
}
/// routing layers from the technology LEF (RDL / AP excluded); None without a LEF
pub fn lef_route_layers(ll: &[crate::lef::LefLayer]) -> Option<Vec<Layer>> {
    let v: Vec<Layer> = ll.iter().filter(|l| l.kind == "ROUTING" && l.name != "AP" && l.pitch > 0.0 && l.pitch < 5.0).enumerate()
        .map(|(i, l)| Layer { name: l.name.clone(), horiz: l.dir != "VERTICAL", pitch: l.pitch, util: match i { 0 => 0.15, 1 => 0.7, _ => 0.8 } }).collect();
    if v.len() >= 2 { Some(v) } else { None }
}
pub fn default_layers() -> Vec<Layer> {
    vec![
        Layer { name: "M1".into(), horiz: true, pitch: 0.2, util: 0.15 },
        Layer { name: "M2".into(), horiz: false, pitch: 0.2, util: 0.7 },
        Layer { name: "M3".into(), horiz: true, pitch: 0.2, util: 0.8 },
        Layer { name: "M4".into(), horiz: false, pitch: 0.2, util: 0.8 },
        Layer { name: "M5".into(), horiz: true, pitch: 0.4, util: 0.8 },
        Layer { name: "M6".into(), horiz: false, pitch: 0.4, util: 0.8 },
    ]
}

#[derive(Clone, Debug, Default)]
pub struct GRoute {
    pub gcell: f64,
    pub nx: usize,
    pub ny: usize,
    pub cap: Vec<[f64; 2]>,
    pub dem: Vec<[f64; 2]>,
    pub net_len: HashMap<NetId, f64>,
    pub overflow: f64,
    pub overflow_cells: usize,
    pub max_util: f64,
    pub wirelength: f64,
    pub detoured: Vec<String>,
    pub unroutable: Vec<String>,
    pub feed_used: Vec<(String, String)>,
}

pub fn side_name(s: &str) -> String {
    match s.to_lowercase().as_str() {
        "1" | "left" | "l" | "w" | "west" => "left",
        "2" | "top" | "t" | "n" | "north" => "top",
        "3" | "right" | "r" | "e" | "east" => "right",
        "4" | "bottom" | "b" | "s" | "south" => "bottom",
        _ => "",
    }
    .to_string()
}

// ------------------------------------------------------------------ membership helpers
pub fn member_of(name: &str, pats: &[String]) -> bool {
    pats.iter().any(|p| glob(p, name) || name.starts_with(&format!("{}/", p)))
}

pub struct Ctx<'a> {
    pub die: Rect,
    pub pblk: &'a [PBlockage],
    pub bounds: &'a [Bound],
    pub area_of: &'a dyn Fn(&Cell) -> f64,
}

/// Bound index (if any) of a cell: last matching bound wins
pub fn bound_of(bounds: &[Bound], cname: &str) -> Option<usize> {
    let mut r = None;
    for (i, b) in bounds.iter().enumerate() {
        if member_of(cname, &b.members) {
            r = Some(i);
        }
    }
    r
}

/// Resolve group bounds (dimensions only) to rectangles around their members' centroid.
pub fn resolve_bounds(nl: &Netlist, bounds: &mut [Bound], die: Rect) {
    for b in bounds.iter_mut() {
        if let Some(r) = b.rect {
            b.resolved = Some(rnorm(r));
            continue;
        }
        let (w, h) = b.dims.unwrap_or(((die.2 - die.0) / 4.0, (die.3 - die.1) / 4.0));
        let (mut sx, mut sy, mut k) = (0.0, 0.0, 0.0);
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            if member_of(&cell.name, &b.members) {
                if let Some((x, y)) = cell.loc {
                    sx += x;
                    sy += y;
                    k += 1.0;
                }
            }
        }
        let (cx, cy) = if k > 0.0 { (sx / k, sy / k) } else { ((die.0 + die.2) / 2.0, (die.1 + die.3) / 2.0) };
        let cx = cx.clamp(die.0 + w / 2.0, die.2 - w / 2.0);
        let cy = cy.clamp(die.1 + h / 2.0, die.3 - h / 2.0);
        b.resolved = Some((cx - w / 2.0, cy - h / 2.0, cx + w / 2.0, cy + h / 2.0));
    }
}

/// Apply region constraints to a single movable cell position.
fn project(cx: &Ctx, cell: &Cell, bidx: Option<usize>, p: (f64, f64), relax_soft: bool) -> (f64, f64) {
    let mut p = clamp_in(&cx.die, p, 0.2);
    if let Some(bi) = bidx {
        let b = &cx.bounds[bi];
        if let Some(r) = b.resolved {
            match b.kind {
                BoundKind::Hard | BoundKind::Exclusive => p = clamp_in(&r, p, 0.3),
                BoundKind::Soft => {
                    if !inside(&r, p) {
                        let q = clamp_in(&r, p, 0.3);
                        p = if relax_soft { ((p.0 + q.0) / 2.0, (p.1 + q.1) / 2.0) } else { q };
                    }
                }
            }
        }
    }
    // exclusive bounds keep non-members out
    for (i, b) in cx.bounds.iter().enumerate() {
        if b.kind == BoundKind::Exclusive && Some(i) != bidx {
            if let Some(r) = b.resolved {
                if inside(&r, p) {
                    p = push_out(&r, p, &cx.die, 0.3);
                }
            }
        }
    }
    let is_buf = cell.has_attr("opt_buffer");
    for blk in cx.pblk {
        let hit = match blk.kind {
            PbKind::Hard | PbKind::HardMacro => true,
            PbKind::Soft => !is_buf,
            PbKind::Partial(_) => false,
        };
        if hit && inside(&blk.rect, p) {
            // keep inside own hard bound if the push would leave it
            let q = push_out(&blk.rect, p, &cx.die, 0.3);
            let ok = bidx.map(|bi| cx.bounds[bi].kind == BoundKind::Soft || cx.bounds[bi].resolved.map(|r| inside(&r, q)).unwrap_or(true)).unwrap_or(true);
            if ok {
                p = q;
            }
        }
    }
    p
}

#[derive(Default, Debug)]
pub struct PlaceStats {
    pub placed: usize,
    pub moved_by_constraints: usize,
    pub spread: usize,
    pub overflow_bins: usize,
    pub util: f64,
    pub bound_violations: usize,
    pub blockage_violations: usize,
}

pub struct Bins {
    pub bs: f64,
    pub nx: usize,
    pub ny: usize,
    pub cap: Vec<f64>,
    pub hard: Vec<bool>,
}
pub fn bins(die: Rect, bs: f64, max_density: f64, pblk: &[PBlockage]) -> Bins {
    let nx = (((die.2 - die.0) / bs).ceil() as usize).max(1);
    let ny = (((die.3 - die.1) / bs).ceil() as usize).max(1);
    let mut cap = vec![0.0; nx * ny];
    let mut hard = vec![false; nx * ny];
    for j in 0..ny {
        for i in 0..nx {
            let r = (die.0 + i as f64 * bs, die.1 + j as f64 * bs, (die.0 + (i + 1) as f64 * bs).min(die.2), (die.1 + (j + 1) as f64 * bs).min(die.3));
            let a = area(&r);
            let mut free = a * max_density;
            for b in pblk {
                let o = overlap(&r, &b.rect);
                if o <= 0.0 {
                    continue;
                }
                match b.kind {
                    PbKind::Hard | PbKind::HardMacro | PbKind::Soft => free -= o * max_density,
                    PbKind::Partial(pct) => {
                        let allowed = ((100.0 - pct) / 100.0).min(max_density);
                        free -= o * (max_density - allowed).max(0.0);
                    }
                }
                if matches!(b.kind, PbKind::Hard | PbKind::HardMacro) && o >= a * 0.99 {
                    hard[j * nx + i] = true;
                }
            }
            cap[j * nx + i] = free.max(0.0);
        }
    }
    Bins { bs, nx, ny, cap, hard }
}

/// Constraint-honoring coarse placement + density spreading. `only_unplaced` keeps existing locations as seeds.
pub fn place(nl: &mut Netlist, cx: &Ctx, iters: usize, max_density: f64, bin: f64) -> PlaceStats {
    let mut st = PlaceStats::default();
    let die = cx.die;
    let cells: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| !nl.cell(*c).fixed && !matches!(nl.cell(*c).kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1))).collect();
    let bidx: HashMap<CellId, Option<usize>> = cells.iter().map(|c| (*c, bound_of(cx.bounds, &nl.cell(*c).name))).collect();
    // seed
    let n = cells.len().max(1) as f64;
    let mut k = 0usize;
    for &c in &cells {
        if nl.cell(c).loc.is_some() {
            continue;
        }
        let ctr = match bidx[&c].and_then(|b| cx.bounds[b].resolved) {
            Some(r) => ((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0),
            None => ((die.0 + die.2) / 2.0, (die.1 + die.3) / 2.0),
        };
        let a = k as f64 * 2.399;
        let rad = (k as f64).sqrt() * ((die.2 - die.0).min(die.3 - die.1) / 2.0 / n.sqrt());
        nl.cell_mut(c).loc = Some((ctr.0 + rad * a.cos(), ctr.1 + rad * a.sin()));
        k += 1;
        st.placed += 1;
    }
    for it in 0..iters {
        // net-centroid pull
        for &c in &cells {
            let (mut sx, mut sy, mut w) = (0.0, 0.0, 0.0);
            for p in &nl.cell(c).pins {
                let Some(net) = p.net else { continue };
                let deg = nl.net(net).conns.len();
                if deg > 64 || deg < 2 {
                    continue;
                }
                let wt = 1.0 / (deg as f64 - 1.0);
                for pr in &nl.net(net).conns {
                    if matches!(pr, PinRef::Cell(o, _) if *o == c) {
                        continue;
                    }
                    if let Some((x, y)) = nl.pin_loc(*pr) {
                        sx += x * wt;
                        sy += y * wt;
                        w += wt;
                    }
                }
            }
            let cur = nl.cell(c).loc.unwrap();
            let tgt = if w > 0.0 { (0.5 * cur.0 + 0.5 * sx / w, 0.5 * cur.1 + 0.5 * sy / w) } else { cur };
            let q = project(cx, nl.cell(c), bidx[&c], tgt, it + 1 < iters);
            nl.cell_mut(c).loc = Some(q);
        }
        if it % 3 == 2 || it + 1 == iters {
            st.spread += spread(nl, cx, &cells, &bidx, max_density, bin);
        }
    }
    // final hard projection
    for &c in &cells {
        let p = nl.cell(c).loc.unwrap();
        let q = project(cx, nl.cell(c), bidx[&c], p, false);
        if (q.0 - p.0).abs() + (q.1 - p.1).abs() > 1e-6 {
            st.moved_by_constraints += 1;
        }
        nl.cell_mut(c).loc = Some(q);
    }
    let (ov, util) = density_report(nl, cx, max_density, bin);
    st.overflow_bins = ov;
    st.util = util;
    let v = violations(nl, cx);
    st.bound_violations = v.0.len();
    st.blockage_violations = v.1.len();
    st
}

fn spread(nl: &mut Netlist, cx: &Ctx, cells: &[CellId], bidx: &HashMap<CellId, Option<usize>>, maxd: f64, bs: f64) -> usize {
    let die = cx.die;
    let b = bins(die, bs, maxd, cx.pblk);
    let bin_of = |p: (f64, f64)| -> usize {
        let i = (((p.0 - die.0) / bs) as usize).min(b.nx - 1);
        let j = (((p.1 - die.1) / bs) as usize).min(b.ny - 1);
        j * b.nx + i
    };
    let mut used = vec![0.0; b.cap.len()];
    let mut members: Vec<Vec<CellId>> = vec![vec![]; b.cap.len()];
    for c in nl.cell_ids() {
        let cell = nl.cell(c);
        if let Some(p) = cell.loc {
            let k = bin_of(p);
            used[k] += (cx.area_of)(cell);
            if !cell.fixed {
                members[k].push(c);
            }
        }
    }
    let _ = cells;
    let mut moved = 0;
    for k in 0..b.cap.len() {
        if used[k] <= b.cap[k] + 1e-9 {
            continue;
        }
        let (bi, bj) = ((k % b.nx) as i64, (k / b.nx) as i64);
        let ctr = (die.0 + (bi as f64 + 0.5) * bs, die.1 + (bj as f64 + 0.5) * bs);
        let mut ms = members[k].clone();
        ms.sort_by(|x, y| {
            let dx = nl.cell(*x).loc.unwrap();
            let dy = nl.cell(*y).loc.unwrap();
            let a = (dx.0 - ctr.0).abs() + (dx.1 - ctr.1).abs();
            let bb = (dy.0 - ctr.0).abs() + (dy.1 - ctr.1).abs();
            bb.partial_cmp(&a).unwrap()
        });
        for c in ms {
            if used[k] <= b.cap[k] + 1e-9 {
                break;
            }
            let a = (cx.area_of)(nl.cell(c));
            // ring search for a bin with room that is legal for this cell
            let mut done = false;
            'ring: for r in 1..(b.nx.max(b.ny) as i64) {
                for dj in -r..=r {
                    for di in -r..=r {
                        if di.abs() != r && dj.abs() != r {
                            continue;
                        }
                        let (ni, nj) = (bi + di, bj + dj);
                        if ni < 0 || nj < 0 || ni >= b.nx as i64 || nj >= b.ny as i64 {
                            continue;
                        }
                        let nk = nj as usize * b.nx + ni as usize;
                        if b.hard[nk] || used[nk] + a > b.cap[nk] {
                            continue;
                        }
                        let p = (die.0 + (ni as f64 + 0.5) * bs + (moved % 7) as f64 * 0.05, die.1 + (nj as f64 + 0.5) * bs);
                        let q = project(cx, nl.cell(c), bidx.get(&c).copied().flatten(), p, false);
                        if bin_of(q) != nk {
                            continue;
                        }
                        nl.cell_mut(c).loc = Some(q);
                        used[k] -= a;
                        used[nk] += a;
                        moved += 1;
                        done = true;
                        break 'ring;
                    }
                }
            }
            if !done {
                break;
            }
        }
    }
    moved
}

pub fn density_report(nl: &Netlist, cx: &Ctx, maxd: f64, bs: f64) -> (usize, f64) {
    let die = cx.die;
    let b = bins(die, bs, maxd, cx.pblk);
    let mut used = vec![0.0; b.cap.len()];
    let mut tot = 0.0;
    for c in nl.cell_ids() {
        let cell = nl.cell(c);
        if let Some(p) = cell.loc {
            let i = (((p.0 - die.0) / bs) as usize).min(b.nx - 1);
            let j = (((p.1 - die.1) / bs) as usize).min(b.ny - 1);
            let a = (cx.area_of)(cell);
            used[j * b.nx + i] += a;
            tot += a;
        }
    }
    let ov = used.iter().zip(b.cap.iter()).filter(|(u, c)| **u > **c * 1.05 + 1e-9).count();
    (ov, tot / area(&die).max(1e-9))
}

/// (bound violations, blockage violations)
pub fn violations(nl: &Netlist, cx: &Ctx) -> (Vec<String>, Vec<String>) {
    let mut bv = vec![];
    let mut kv = vec![];
    for c in nl.cell_ids() {
        let cell = nl.cell(c);
        let Some(p) = cell.loc else { continue };
        if cell.fixed {
            continue;
        }
        let bi = bound_of(cx.bounds, &cell.name);
        if let Some(i) = bi {
            let b = &cx.bounds[i];
            if let Some(r) = b.resolved {
                if b.kind != BoundKind::Soft && !inside(&r, p) {
                    bv.push(format!("{} outside {} bound '{}'", cell.name, if b.kind == BoundKind::Hard { "hard" } else { "exclusive" }, b.name));
                }
            }
        }
        for (i, b) in cx.bounds.iter().enumerate() {
            if b.kind == BoundKind::Exclusive && Some(i) != bi {
                if let Some(r) = b.resolved {
                    if inside(&r, p) {
                        bv.push(format!("{} intrudes exclusive bound '{}'", cell.name, b.name));
                    }
                }
            }
        }
        for blk in cx.pblk {
            let hit = match blk.kind {
                PbKind::Hard | PbKind::HardMacro => true,
                PbKind::Soft => !cell.has_attr("opt_buffer"),
                _ => false,
            };
            if hit && inside(&blk.rect, p) {
                kv.push(format!("{} inside {:?} placement blockage '{}'", cell.name, blk.kind, blk.name));
            }
        }
    }
    (bv, kv)
}

// ------------------------------------------------------------------ IO pin planning
#[derive(Default, Debug)]
pub struct PinStats {
    pub placed: usize,
    pub fixed: usize,
    pub bundles: usize,
    pub failed: Vec<String>,
}

fn side_len(die: &Rect, s: &str) -> f64 {
    if s == "left" || s == "right" {
        die.3 - die.1
    } else {
        die.2 - die.0
    }
}
pub fn side_point(die: &Rect, s: &str, t: f64) -> (f64, f64) {
    match s {
        "left" => (die.0, die.1 + t),
        "right" => (die.2, die.1 + t),
        "top" => (die.0 + t, die.3),
        _ => (die.0 + t, die.1),
    }
}
fn project_side(die: &Rect, s: &str, p: (f64, f64)) -> f64 {
    match s {
        "left" | "right" => p.1 - die.1,
        _ => p.0 - die.0,
    }
}
fn nearest_side(die: &Rect, p: (f64, f64), allowed: &[String]) -> String {
    let mut best = ("left".to_string(), f64::MAX);
    for s in allowed {
        let d = match s.as_str() {
            "left" => p.0 - die.0,
            "right" => die.2 - p.0,
            "top" => die.3 - p.1,
            _ => p.1 - die.1,
        };
        if d < best.1 {
            best = (s.clone(), d);
        }
    }
    best.0
}
/// natural sort key: base name, index
pub fn bus_key(n: &str) -> (String, i64) {
    if n.ends_with(']') {
        if let Some(i) = n.rfind('[') {
            if let Ok(v) = n[i + 1..n.len() - 1].parse::<i64>() {
                return (n[..i].to_string(), v);
            }
        }
    }
    (n.to_string(), -1)
}
/// track pitch shared by all candidate pin layers (pin slots are multiples of it, so every slot
/// is on a track of every allowed layer; tracks run from the die origin, see `write_def` TRACKS)
pub fn pin_pitch(bp: &BlockPins, layers: &[Layer]) -> f64 {
    bp.layers.iter().filter_map(|l| layers.iter().find(|x| &x.name == l)).map(|l| l.pitch).fold(0.0, f64::max).max(0.01)
}

/// candidate layers of a side: allowed layers whose preferred direction runs into the die
/// (horizontal layers on left/right, vertical on top/bottom); the first allowed layer if none fits
fn side_layers(side: &str, allowed: &[String], layers: &[Layer]) -> Vec<String> {
    let want_horiz = side == "left" || side == "right";
    let v: Vec<String> = allowed.iter().filter(|l| layers.iter().find(|x| &x.name == *l).map(|x| x.horiz == want_horiz).unwrap_or(false)).cloned().collect();
    if v.is_empty() {
        vec![allowed.first().cloned().unwrap_or("M3".into())]
    } else {
        v
    }
}

/// pin placement result per port: (side, layer, source)
pub fn place_pins(nl: &mut Netlist, die: Rect, bp: &BlockPins, cons: &[PinCons], bundles: &[Bundle], layers: &[Layer], fixed: &HashSet<String>, info: &mut HashMap<String, (String, String, String)>) -> PinStats {
    let mut st = PinStats::default();
    let tp = pin_pitch(bp, layers);
    // slot step: the pin spacing rounded up to whole tracks; first slot on the first track past the keepout
    let step = ((bp.spacing.max(tp) / tp - 1e-6).ceil() * tp).max(tp);
    let ko = bp.corner_keepout;
    let first = ((ko / tp - 1e-6).ceil() * tp).max(tp);
    let sides = ["left", "top", "right", "bottom"];
    let nslots = |s: &str| -> usize {
        let room = side_len(&die, s) - ko.max(tp) - first;
        if room < 0.0 { 0 } else { (room / step + 1e-6).floor() as usize + 1 }
    };
    let slot_pos = |k: usize| -> f64 { first + k as f64 * step };
    // occupancy per (side, layer)
    let mut occ: HashMap<(String, String), Vec<bool>> = HashMap::new();
    let mut used: HashMap<(String, String), usize> = HashMap::new();
    let mut rr: HashMap<String, usize> = HashMap::new();
    let get_occ = |occ: &mut HashMap<(String, String), Vec<bool>>, s: &str, l: &str| -> () {
        occ.entry((s.to_string(), l.to_string())).or_insert_with(|| vec![false; nslots(s)]);
    };
    let constrained: HashSet<String> = cons.iter().map(|c| c.port.clone()).chain(bundles.iter().flat_map(|b| b.ports.iter().cloned())).collect();
    // layer order for a new pin on side s
    let order = |s: &str, allowed: &[String], used: &HashMap<(String, String), usize>, rr: &HashMap<String, usize>| -> Vec<String> {
        let mut c = side_layers(s, allowed, layers);
        match bp.layer_assignment.as_str() {
            "balanced" => c.sort_by_key(|l| used.get(&(s.to_string(), l.clone())).copied().unwrap_or(0)),
            "round_robin" => {
                let k = rr.get(s).copied().unwrap_or(0) % c.len();
                c.rotate_left(k);
            }
            _ => {}
        }
        c
    };
    // fixed (DEF / location) pins first
    for p in nl.port_ids() {
        let name = nl.ports[p].name.clone();
        let loc_cons = cons.iter().find(|c| c.port == name).and_then(|c| c.location);
        if let Some(l) = loc_cons {
            nl.ports[p].loc = Some(l);
        } else if !(fixed.contains(&name) && !constrained.contains(&name)) {
            continue;
        }
        let Some(l) = nl.ports[p].loc else { continue };
        let s = nearest_side(&die, l, &sides.iter().map(|x| x.to_string()).collect::<Vec<_>>());
        let t = project_side(&die, &s, l);
        let allowed = cons.iter().find(|c| c.port == name).map(|c| c.layers.clone()).filter(|v| !v.is_empty()).unwrap_or(bp.layers.clone());
        // DEF pins keep their layer; location-constrained pins take the constraint's layers
        let ly = info.get(&name).filter(|x| loc_cons.is_none() && x.2 == "def").map(|x| x.1.clone()).unwrap_or_else(|| side_layers(&s, &allowed, layers)[0].clone());
        get_occ(&mut occ, &s, &ly);
        if let Some(v) = occ.get_mut(&(s.clone(), ly.clone())) {
            for (k, o) in v.iter_mut().enumerate() {
                if (slot_pos(k) - t).abs() < step - 1e-9 {
                    *o = true;
                }
            }
        }
        *used.entry((s.clone(), ly.clone())).or_default() += 1;
        info.insert(name, (s, ly, if loc_cons.is_some() { "location".into() } else { "def".into() }));
        st.fixed += 1;
    }
    let is_done = |info: &HashMap<String, (String, String, String)>, n: &str| info.get(n).map(|x| x.2 == "def" || x.2 == "location").unwrap_or(false);
    // desired position of a port from its connected cells
    let desire = |nl: &Netlist, p: PortId| -> Option<(f64, f64)> {
        let n = nl.ports[p].net?;
        let (mut sx, mut sy, mut k) = (0.0, 0.0, 0.0);
        for pr in &nl.net(n).conns {
            if let PinRef::Cell(c, _) = pr {
                if let Some((x, y)) = nl.cell(*c).loc {
                    sx += x;
                    sy += y;
                    k += 1.0;
                }
            }
        }
        if k > 0.0 {
            Some((sx / k, sy / k))
        } else {
            None
        }
    };
    let find_run = |v: &Vec<bool>, start: f64, len: usize, every: usize| -> Option<usize> {
        let need = (len - 1) * every + 1;
        if need > v.len() {
            return None;
        }
        let want = (((start - first) / step).round().max(0.0) as usize).min(v.len() - need);
        for d in 0..v.len() {
            for cand in [want.saturating_sub(d), want + d] {
                if cand + need <= v.len() && (0..len).all(|i| !v[cand + i * every]) {
                    return Some(cand);
                }
            }
        }
        None
    };
    // bundles (explicit + automatic bus grouping)
    let mut all_bundles: Vec<Bundle> = bundles.to_vec();
    if bp.group_buses {
        let mut by_base: BTreeMap<String, Vec<String>> = BTreeMap::new();
        for p in nl.port_ids() {
            let n = &nl.ports[p].name;
            if constrained.contains(n) || is_done(info, n) {
                continue;
            }
            let (b, i) = bus_key(n);
            if i >= 0 {
                by_base.entry(b).or_default().push(n.clone());
            }
        }
        for (b, ps) in by_base {
            if ps.len() > 1 {
                all_bundles.push(Bundle { name: format!("bus:{}", b), ports: ps, order: "increasing".into(), ..Default::default() });
            }
        }
    }
    for b in &all_bundles {
        let mut ports: Vec<String> = b.ports.iter().filter(|p| nl.port_by_name(p).is_some() && !is_done(info, p)).cloned().collect();
        if ports.is_empty() {
            continue;
        }
        match b.order.as_str() {
            "given" => {}
            "decreasing" => {
                ports.sort_by(|x, y| bus_key(x).cmp(&bus_key(y)));
                ports.reverse()
            }
            "interleave" => ports.sort_by(|x, y| {
                let (bx, ix) = bus_key(x);
                let (by, iy) = bus_key(y);
                ix.cmp(&iy).then(bx.cmp(&by))
            }),
            _ => ports.sort_by(|x, y| bus_key(x).cmp(&bus_key(y))),
        }
        let allowed = if b.sides.is_empty() { bp.sides.clone() } else { b.sides.clone() };
        let lys: Vec<String> = if b.layers.is_empty() { bp.layers.clone() } else { b.layers.clone() };
        let cents: Vec<(f64, f64)> = ports.iter().filter_map(|p| nl.port_by_name(p)).filter_map(|p| desire(nl, p)).collect();
        let c = if cents.is_empty() { ((die.0 + die.2) / 2.0, die.1) } else { (cents.iter().map(|x| x.0).sum::<f64>() / cents.len() as f64, cents.iter().map(|x| x.1).sum::<f64>() / cents.len() as f64) };
        let every = ((b.spacing.unwrap_or(step) / step).round() as usize).max(1);
        let mut order_sides = allowed.clone();
        let ns = nearest_side(&die, c, &allowed);
        order_sides.sort_by_key(|s| if *s == ns { 0 } else { 1 });
        let mut placed = false;
        'sides: for s in &order_sides {
            let span = ((ports.len() - 1) * every) as f64 * step;
            let start = b.offset.unwrap_or(project_side(&die, s, c) - span / 2.0);
            for ly in order(s, &lys, &used, &rr) {
                get_occ(&mut occ, s, &ly);
                let v = occ.get_mut(&(s.clone(), ly.clone())).unwrap();
                if let Some(k0) = find_run(v, start, ports.len(), every) {
                    for (i, pn) in ports.iter().enumerate() {
                        let k = k0 + i * every;
                        v[k] = true;
                        let pid = nl.port_by_name(pn).unwrap();
                        nl.ports[pid].loc = Some(side_point(&die, s, slot_pos(k)));
                        info.insert(pn.clone(), (s.clone(), ly.clone(), format!("bundle {}", b.name)));
                        st.placed += 1;
                    }
                    *used.entry((s.clone(), ly.clone())).or_default() += ports.len();
                    *rr.entry(s.clone()).or_default() += 1;
                    placed = true;
                    st.bundles += 1;
                    break 'sides;
                }
            }
        }
        if !placed {
            st.failed.push(format!("bundle '{}' ({} pins) does not fit on sides {:?}", b.name, ports.len(), allowed));
        }
    }
    // individual constraints, then the rest
    let mut rest: Vec<(PortId, String, f64, Vec<String>, Vec<String>)> = vec![];
    for p in nl.port_ids() {
        let name = nl.ports[p].name.clone();
        if info.get(&name).map(|x| x.2 != "auto").unwrap_or(false) && (is_done(info, &name) || info[&name].2.starts_with("bundle")) {
            continue;
        }
        let c = cons.iter().find(|c| c.port == name);
        let allowed = c.map(|c| c.sides.clone()).filter(|v| !v.is_empty()).unwrap_or(bp.sides.clone());
        let d = desire(nl, p).unwrap_or(((die.0 + die.2) / 2.0, (die.1 + die.3) / 2.0));
        let s = nearest_side(&die, d, &allowed);
        let t = c.and_then(|c| c.offset).unwrap_or(project_side(&die, &s, d));
        rest.push((p, s, t, c.map(|c| c.layers.clone()).unwrap_or_default(), allowed));
    }
    // offsets first (more constrained), then by position
    rest.sort_by(|a, b| a.2.partial_cmp(&b.2).unwrap());
    for (p, s, t, ly, allowed) in rest {
        let name = nl.ports[p].name.clone();
        let mut sidelist = vec![s.clone()];
        for x in &allowed {
            if *x != s {
                sidelist.push(x.clone());
            }
        }
        let lys = if ly.is_empty() { bp.layers.clone() } else { ly };
        let mut ok = false;
        'outer: for s2 in sidelist {
            let want = if s2 == s { t } else { side_len(&die, &s2) / 2.0 };
            for l in order(&s2, &lys, &used, &rr) {
                get_occ(&mut occ, &s2, &l);
                let v = occ.get_mut(&(s2.clone(), l.clone())).unwrap();
                if let Some(k) = find_run(v, want, 1, 1) {
                    v[k] = true;
                    nl.ports[p].loc = Some(side_point(&die, &s2, slot_pos(k)));
                    let src = if cons.iter().any(|c| c.port == name) { "constraint" } else { "auto" };
                    info.insert(name.clone(), (s2.clone(), l.clone(), src.into()));
                    *used.entry((s2.clone(), l.clone())).or_default() += 1;
                    *rr.entry(s2.clone()).or_default() += 1;
                    st.placed += 1;
                    ok = true;
                    break 'outer;
                }
            }
        }
        if !ok {
            st.failed.push(format!("{}: no free pin slot", name));
        }
    }
    st
}

/// pin shape of a port on `layer`: (width along the edge, length into the die)
pub fn pin_shape(bp: &BlockPins, layers: &[Layer], layer: &str) -> (f64, f64) {
    let p = layers.iter().find(|l| l.name == layer).map(|l| l.pitch).unwrap_or(0.2);
    (bp.pin_width.unwrap_or(p / 2.0), bp.pin_length.unwrap_or(p * 2.0))
}

/// check_pin_assignment: (category, message) for every violation
pub fn check_pin_assignment(nl: &Netlist, fp: &crate::phys::Floorplan) -> Vec<(String, String)> {
    let die = fp.die;
    let bp = &fp.block_pins;
    let layers = &fp.layers;
    let info = &fp.pin_info;
    let mut v: Vec<(String, String)> = vec![];
    let mut push = |c: &str, m: String| v.push((c.to_string(), m));
    let mut locs: Vec<(String, String, String, f64)> = vec![]; // name, side, layer, position along side
    let eps = 1e-6;
    for p in nl.port_ids() {
        let n = &nl.ports[p].name;
        let cons = fp.pin_cons.iter().find(|c| &c.port == n);
        let Some(l) = nl.ports[p].loc else {
            push("unplaced", format!("{}: not placed", n));
            continue;
        };
        if l.0 < die.0 - eps || l.0 > die.2 + eps || l.1 < die.1 - eps || l.1 > die.3 + eps {
            push("outside_die", format!("{}: ({:.3},{:.3}) is outside the die", n, l.0, l.1));
            continue;
        }
        let on_edge = (l.0 - die.0).abs() < eps || (l.0 - die.2).abs() < eps || (l.1 - die.1).abs() < eps || (l.1 - die.3).abs() < eps;
        if !on_edge {
            push("off_edge", format!("{}: ({:.3},{:.3}) is not on the die boundary", n, l.0, l.1));
        }
        let Some((side, ly, src)) = info.get(n) else {
            push("no_layer", format!("{}: placed without a pin layer", n));
            continue;
        };
        let t = project_side(&die, side, l);
        let sides_ok: Vec<String> = cons.map(|c| c.sides.clone()).filter(|x| !x.is_empty()).unwrap_or(bp.sides.clone());
        if !sides_ok.contains(side) && src != "location" && src != "def" {
            push("side", format!("{}: on side '{}', allowed {:?}", n, side, sides_ok));
        }
        let bundle = fp.bundles.iter().find(|b| b.ports.contains(n));
        let lys: Vec<String> = cons.map(|c| c.layers.clone()).filter(|x| !x.is_empty()).or(bundle.map(|b| b.layers.clone()).filter(|x| !x.is_empty())).unwrap_or(bp.layers.clone());
        if !lys.contains(ly) {
            push("layer", format!("{}: on layer {}, allowed {:?}", n, ly, lys));
        }
        match layers.iter().find(|x| &x.name == ly) {
            None => push("layer", format!("{}: unknown layer {}", n, ly)),
            Some(lr) => {
                if lr.horiz != (side == "left" || side == "right") {
                    push("direction", format!("{}: {} ({}) cannot leave the {} side in its preferred direction", n, ly, if lr.horiz { "horizontal" } else { "vertical" }, side));
                }
                let k = t / lr.pitch;
                if (k - k.round()).abs() > 1e-3 {
                    push("off_track", format!("{}: {:.4} along the {} side is not on a {} track (pitch {})", n, t, side, ly, lr.pitch));
                }
            }
        }
        let len = side_len(&die, side);
        if t < bp.corner_keepout - eps || t > len - bp.corner_keepout + eps {
            push("corner_keepout", format!("{}: {:.3} from the corner, keepout {}", n, t.min(len - t), bp.corner_keepout));
        }
        if let Some(c) = cons {
            if let Some(o) = c.offset {
                if (o - t).abs() > pin_pitch(bp, layers) + eps && src != "location" {
                    push("constraint", format!("{}: offset {:.3}, constrained to {:.3}", n, t, o));
                }
            }
            if let Some(cl) = c.location {
                if (cl.0 - l.0).abs() + (cl.1 - l.1).abs() > eps {
                    push("constraint", format!("{}: at ({:.3},{:.3}), constrained to ({:.3},{:.3})", n, l.0, l.1, cl.0, cl.1));
                }
            }
        }
        // routing blockage on the pin layer covering the pin
        let (w, d) = pin_shape(bp, layers, ly);
        let r = match side.as_str() {
            "left" => (l.0, l.1 - w / 2.0, l.0 + d, l.1 + w / 2.0),
            "right" => (l.0 - d, l.1 - w / 2.0, l.0, l.1 + w / 2.0),
            "top" => (l.0 - w / 2.0, l.1 - d, l.0 + w / 2.0, l.1),
            _ => (l.0 - w / 2.0, l.1, l.0 + w / 2.0, l.1 + d),
        };
        for b in &fp.rblk {
            let on_layer = b.layers.is_empty() || b.layers.contains(ly);
            if on_layer && r.0 < b.rect.2 - eps && r.2 > b.rect.0 + eps && r.1 < b.rect.3 - eps && r.3 > b.rect.1 + eps {
                push("blockage", format!("{}: pin shape on {} overlaps a routing blockage", n, ly));
            }
        }
        if nl.ports[p].net.map(|x| nl.net(x).conns.len() <= 1).unwrap_or(true) {
            push("unconnected", format!("{}: port drives / is driven by nothing", n));
        }
        locs.push((n.clone(), side.clone(), ly.clone(), t));
    }
    // shorts and spacing between pins on the same side and layer
    locs.sort_by(|a, b| (&a.1, &a.2).cmp(&(&b.1, &b.2)).then(a.3.partial_cmp(&b.3).unwrap()));
    for i in 0..locs.len() {
        for j in i + 1..locs.len() {
            if locs[j].1 != locs[i].1 || locs[j].2 != locs[i].2 {
                break;
            }
            let dd = locs[j].3 - locs[i].3;
            if dd >= bp.spacing - eps {
                break;
            }
            let (w, _) = pin_shape(bp, layers, &locs[i].2);
            if dd < w - eps {
                push("short", format!("{} / {}: pin shapes overlap on {} ({:.3} apart)", locs[i].0, locs[j].0, locs[i].2, dd));
            } else {
                push("spacing", format!("{} / {}: {:.3} apart on {}, minimum {}", locs[i].0, locs[j].0, dd, locs[i].2, bp.spacing));
            }
        }
    }
    // bundles: one side, requested order
    for b in &fp.bundles {
        let ss: HashSet<String> = b.ports.iter().filter_map(|p| info.get(p).map(|x| x.0.clone())).collect();
        if ss.len() > 1 {
            push("bundle", format!("bundle '{}' split across sides {:?}", b.name, ss));
            continue;
        }
        let pos: Vec<((String, i64), f64)> = b.ports.iter().filter_map(|p| nl.port_by_name(p).and_then(|q| nl.ports[q].loc).zip(info.get(p)).map(|(l, i)| (bus_key(p), project_side(&die, &i.0, l)))).collect();
        if b.order == "increasing" || b.order == "decreasing" {
            // the placer orders a bundle by (bus base name, bit index)
            let mut s2 = pos.clone();
            s2.sort_by(|a, b| a.0.cmp(&b.0));
            let mono = s2.windows(2).all(|w| if b.order == "increasing" { w[0].1 <= w[1].1 } else { w[0].1 >= w[1].1 });
            if !mono {
                push("bundle", format!("bundle '{}' is not in {} order", b.name, b.order));
            }
        }
    }
    v
}

/// legacy summary used by check_pin_placement
pub fn check_pins(nl: &Netlist, fp: &crate::phys::Floorplan) -> Vec<String> {
    check_pin_assignment(nl, fp).into_iter().filter(|(c, _)| c != "unconnected").map(|(_, m)| m).collect()
}

// ------------------------------------------------------------------ global routing
pub struct RouteCtx<'a> {
    pub die: Rect,
    pub gcell: f64,
    pub layers: &'a [Layer],
    pub rblk: &'a [RBlockage],
    pub guides: &'a [RGuide],
    pub bounds: &'a [Bound],
    pub feeds: &'a [Feedthrough],
    pub no_feed_regions: Vec<(String, Rect)>,
}

pub fn global_route(nl: &Netlist, rc: &RouteCtx, skip_nets: &HashSet<NetId>) -> GRoute {
    let g = rc.gcell.max(0.5);
    let nx = (((rc.die.2 - rc.die.0) / g).ceil() as usize).max(1);
    let ny = (((rc.die.3 - rc.die.1) / g).ceil() as usize).max(1);
    let mut gr = GRoute { gcell: g, nx, ny, cap: vec![[0.0; 2]; nx * ny], dem: vec![[0.0; 2]; nx * ny], ..Default::default() };
    let cell_rect = |i: usize, j: usize| -> Rect { (rc.die.0 + i as f64 * g, rc.die.1 + j as f64 * g, rc.die.0 + (i + 1) as f64 * g, rc.die.1 + (j + 1) as f64 * g) };
    for j in 0..ny {
        for i in 0..nx {
            let r = cell_rect(i, j);
            let a = area(&r).max(1e-9);
            for l in rc.layers {
                let mut tracks = g / l.pitch * l.util;
                for b in rc.rblk {
                    if b.layers.is_empty() || b.layers.contains(&l.name) {
                        tracks *= 1.0 - overlap(&r, &b.rect) / a;
                    }
                }
                for gd in rc.guides {
                    if let Some(u) = gd.track_util {
                        if gd.layers.is_empty() || gd.layers.contains(&l.name) {
                            let f = overlap(&r, &gd.rect) / a;
                            tracks *= 1.0 - f + f * (u / 100.0);
                        }
                    }
                }
                gr.cap[j * nx + i][if l.horiz { 0 } else { 1 }] += tracks.max(0.0);
            }
        }
    }
    // feedthrough-restricted regions: map gcell -> region index
    let mut region_of: Vec<Option<usize>> = vec![None; nx * ny];
    for (ri, (_, r)) in rc.no_feed_regions.iter().enumerate() {
        for j in 0..ny {
            for i in 0..nx {
                let cr = cell_rect(i, j);
                let ctr = ((cr.0 + cr.2) / 2.0, (cr.1 + cr.3) / 2.0);
                if inside(r, ctr) {
                    region_of[j * nx + i] = Some(ri);
                }
            }
        }
    }
    let gc = |p: (f64, f64)| -> (usize, usize) { ((((p.0 - rc.die.0) / g) as usize).min(nx - 1), (((p.1 - rc.die.1) / g) as usize).min(ny - 1)) };
    // order nets: small bbox first
    let mut nets: Vec<(NetId, Vec<(usize, usize)>, f64)> = vec![];
    // hierarchical boundary pins are not physical: the nets they join are routed as one wire,
    // attributed to the group's root (the real driver's net)
    let is_hp = |p: &PinRef| matches!(p, PinRef::Cell(c, _) if nl.cell(*c).is_hport());
    let group_of = |root: NetId| -> Vec<NetId> {
        let mut grp = vec![root];
        let mut k = 0;
        while k < grp.len() {
            let m = grp[k];
            k += 1;
            for l in nl.loads(m) {
                if let PinRef::Cell(c, _) = l {
                    if nl.cell(c).is_hport() {
                        if let Some(y) = nl.cell(c).pin_net("Y") {
                            if !grp.contains(&y) {
                                grp.push(y);
                            }
                        }
                    }
                }
            }
        }
        grp
    };
    for n in nl.net_ids() {
        if skip_nets.contains(&n) {
            continue;
        }
        if nl.driver(n).map(|d| is_hp(&d)).unwrap_or(false) {
            continue; // routed with its group root
        }
        let grp = group_of(n);
        let locs: Vec<(f64, f64)> = grp.iter().flat_map(|m| nl.net(*m).conns.clone()).filter(|p| !is_hp(p)).filter_map(|p| nl.pin_loc(p)).collect();
        if locs.len() < 2 {
            continue;
        }
        let mut pts: Vec<(usize, usize)> = locs.iter().map(|p| gc(*p)).collect();
        pts.sort();
        pts.dedup();
        let hp = (locs.iter().map(|p| p.0).fold(f64::MIN, f64::max) - locs.iter().map(|p| p.0).fold(f64::MAX, f64::min)) + (locs.iter().map(|p| p.1).fold(f64::MIN, f64::max) - locs.iter().map(|p| p.1).fold(f64::MAX, f64::min));
        nets.push((n, pts, hp));
    }
    nets.sort_by(|a, b| a.2.partial_cmp(&b.2).unwrap());
    for (n, pts, hp) in nets {
        let name = &nl.net(n).name;
        // regions this net is allowed into: regions containing any of its pins, or feedthrough-permitted
        let mut allowed: HashSet<usize> = HashSet::new();
        for p in &pts {
            if let Some(r) = region_of[p.1 * nx + p.0] {
                allowed.insert(r);
            }
        }
        for (ri, (rn, _)) in rc.no_feed_regions.iter().enumerate() {
            if rc.feeds.iter().any(|f| f.region == *rn && f.nets.iter().any(|x| glob(x, name))) {
                allowed.insert(ri);
            }
        }
        let attract: Vec<&RGuide> = rc.guides.iter().filter(|gd| gd.nets.iter().any(|x| glob(x, name))).collect();
        if pts.len() < 2 {
            gr.net_len.insert(n, hp.max(g * 0.5));
            continue;
        }
        // Prim MST over gcell points
        let mut in_tree = vec![false; pts.len()];
        in_tree[0] = true;
        let mut tree_cells: Vec<(usize, usize)> = vec![pts[0]];
        let mut len = 0.0;
        let mut detour = false;
        let mut failed = false;
        let mut crossed: HashSet<usize> = HashSet::new();
        let pin_regions: HashSet<usize> = pts.iter().filter_map(|p| region_of[p.1 * nx + p.0]).collect();
        for _ in 1..pts.len() {
            // nearest unconnected point to any tree cell
            let mut best = (usize::MAX, usize::MAX, usize::MAX);
            for (pi, p) in pts.iter().enumerate() {
                if in_tree[pi] {
                    continue;
                }
                for (ti, t) in tree_cells.iter().enumerate() {
                    let d = (p.0 as i64 - t.0 as i64).unsigned_abs() as usize + (p.1 as i64 - t.1 as i64).unsigned_abs() as usize;
                    if d < best.0 {
                        best = (d, pi, ti);
                    }
                }
            }
            let (manh, pi, ti) = best;
            in_tree[pi] = true;
            let src = tree_cells[ti];
            let dst = pts[pi];
            match maze(&gr, &region_of, &allowed, &attract, rc, src, dst) {
                Some(path) => {
                    if path.len() > manh + 2 {
                        detour = true;
                    }
                    for c in &path {
                        if let Some(r) = region_of[c.1 * nx + c.0] {
                            if !pin_regions.contains(&r) {
                                crossed.insert(r);
                            }
                        }
                    }
                    for w in path.windows(2) {
                        let (a, b) = (w[0], w[1]);
                        let d = if a.1 == b.1 { 0 } else { 1 };
                        gr.dem[b.1 * nx + b.0][d] += 1.0;
                        gr.dem[a.1 * nx + a.0][d] += 0.0;
                        len += g;
                    }
                    tree_cells.extend(path);
                }
                None => {
                    failed = true;
                    len += manh as f64 * g;
                }
            }
        }
        if detour {
            gr.detoured.push(name.clone());
        }
        if failed {
            gr.unroutable.push(name.clone());
        }
        for ri in crossed {
            gr.feed_used.push((name.clone(), rc.no_feed_regions[ri].0.clone()));
        }
        gr.net_len.insert(n, len.max(hp).max(g * 0.5));
        gr.wirelength += len;
    }
    for k in 0..nx * ny {
        for d in 0..2 {
            let (c, u) = (gr.cap[k][d], gr.dem[k][d]);
            if u > c {
                gr.overflow += u - c;
            }
            if c > 0.0 {
                gr.max_util = gr.max_util.max(u / c);
            }
        }
        if gr.dem[k][0] > gr.cap[k][0] || gr.dem[k][1] > gr.cap[k][1] {
            gr.overflow_cells += 1;
        }
    }
    gr
}

fn maze(gr: &GRoute, region_of: &[Option<usize>], allowed: &HashSet<usize>, attract: &[&RGuide], rc: &RouteCtx, s: (usize, usize), t: (usize, usize)) -> Option<Vec<(usize, usize)>> {
    use std::cmp::Reverse;
    use std::collections::BinaryHeap;
    if s == t {
        return Some(vec![s]);
    }
    let (nx, ny) = (gr.nx, gr.ny);
    let g = gr.gcell;
    let mut dist = vec![f64::INFINITY; nx * ny];
    let mut prev = vec![usize::MAX; nx * ny];
    let mut h = BinaryHeap::new();
    let key = |p: (usize, usize)| p.1 * nx + p.0;
    dist[key(s)] = 0.0;
    h.push(Reverse((0u64, key(s))));
    let tk = key(t);
    while let Some(Reverse((dq, k))) = h.pop() {
        let d = dq as f64 / 1000.0;
        if d > dist[k] + 1e-9 {
            continue;
        }
        if k == tk {
            break;
        }
        let (x, y) = ((k % nx) as i64, (k / nx) as i64);
        for (dx, dy, dir) in [(1i64, 0i64, 0usize), (-1, 0, 0), (0, 1, 1), (0, -1, 1)] {
            let (x2, y2) = (x + dx, y + dy);
            if x2 < 0 || y2 < 0 || x2 >= nx as i64 || y2 >= ny as i64 {
                continue;
            }
            let k2 = y2 as usize * nx + x2 as usize;
            if let Some(r) = region_of[k2] {
                if !allowed.contains(&r) {
                    continue; // physical hierarchy without feedthrough permission
                }
            }
            let cap = gr.cap[k2][dir];
            let dem = gr.dem[k2][dir];
            let mut c = 1.0;
            if cap <= 1e-6 {
                c += 200.0;
            } else if dem + 1.0 > cap {
                c += 8.0 * (dem + 1.0 - cap) / cap.max(1.0) + 2.0;
            } else {
                c += 0.5 * (dem / cap);
            }
            if !attract.is_empty() {
                let ctr = (rc.die.0 + (x2 as f64 + 0.5) * g, rc.die.1 + (y2 as f64 + 0.5) * g);
                if attract.iter().any(|gd| inside(&gd.rect, ctr)) {
                    c *= 0.4;
                } else {
                    c *= 1.2;
                }
            }
            let nd = d + c;
            if nd < dist[k2] {
                dist[k2] = nd;
                prev[k2] = k;
                h.push(Reverse(((nd * 1000.0) as u64, k2)));
            }
        }
    }
    if !dist[tk].is_finite() {
        return None;
    }
    let mut path = vec![];
    let mut k = tk;
    while k != usize::MAX {
        path.push((k % nx, k / nx));
        if k == key(s) {
            break;
        }
        k = prev[k];
    }
    path.reverse();
    Some(path)
}
