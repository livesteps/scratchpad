//! Language-neutral HDL AST shared by the SystemVerilog/Verilog and VHDL front-ends.

use crate::netlist::Dir;

#[derive(Clone, Debug)]
pub enum Expr {
    /// bits LSB-first: 0,1,2=x,3=z/?   `fill` = SV unsized '0/'1/'x
    Num { width: Option<u32>, bits: Vec<u8>, signed: bool, fill: bool },
    Str(String),
    Id(String),
    Scoped(String, String),
    Index(Box<Expr>, Box<Expr>),
    Range(Box<Expr>, Box<Expr>, Box<Expr>),
    PlusRange(Box<Expr>, Box<Expr>, Box<Expr>, bool),
    Member(Box<Expr>, String),
    Un(String, Box<Expr>),
    Bin(String, Box<Expr>, Box<Expr>),
    Cond(Box<Expr>, Box<Expr>, Box<Expr>),
    Concat(Vec<Expr>),
    Repl(Box<Expr>, Vec<Expr>),
    Call(String, Vec<Expr>),
    /// width'(expr)  or  type'(expr)
    Cast(Box<Expr>, Box<Expr>),
    Inside(Box<Expr>, Vec<Expr>),
    /// VHDL (others => x) / SV '{default:x}
    Fill(Box<Expr>),
}

impl Expr {
    pub fn int(v: i64) -> Expr {
        let mut bits = vec![];
        let mut x = v as u64;
        for _ in 0..32 {
            bits.push((x & 1) as u8);
            x >>= 1;
        }
        Expr::Num { width: None, bits, signed: true, fill: false }
    }
    pub fn bin(op: &str, a: Expr, b: Expr) -> Expr {
        Expr::Bin(op.into(), Box::new(a), Box::new(b))
    }
    pub fn un(op: &str, a: Expr) -> Expr {
        Expr::Un(op.into(), Box::new(a))
    }
    pub fn id(s: &str) -> Expr {
        Expr::Id(s.into())
    }
}

#[derive(Clone, Debug)]
pub enum DType {
    Logic { signed: bool, packed: Vec<(Expr, Expr)> },
    Named { name: String, packed: Vec<(Expr, Expr)> },
    Enum { base: Box<DType>, items: Vec<(String, Option<Expr>)> },
    Struct { fields: Vec<(String, DType)>, packed: Vec<(Expr, Expr)> },
}
impl DType {
    pub fn bit() -> DType {
        DType::Logic { signed: false, packed: vec![] }
    }
    pub fn int32() -> DType {
        DType::Logic { signed: true, packed: vec![(Expr::int(31), Expr::int(0))] }
    }
    pub fn vec(msb: i64, lsb: i64) -> DType {
        DType::Logic { signed: false, packed: vec![(Expr::int(msb), Expr::int(lsb))] }
    }
}

#[derive(Clone, Debug)]
pub struct Decl {
    pub name: String,
    pub ty: DType,
    pub unpacked: Vec<(Expr, Expr)>,
    pub init: Option<Expr>,
    pub dir: Option<Dir>,
    pub line: usize,
}

#[derive(Clone, Debug)]
pub struct PortDecl {
    pub name: String,
    pub dir: Option<Dir>,
    pub ty: DType,
    pub unpacked: Vec<(Expr, Expr)>,
    /// interface port: (interface name, modport)
    pub iface: Option<(String, Option<String>)>,
}

#[derive(Clone, Debug)]
pub struct ParamDecl {
    pub name: String,
    pub value: Option<Expr>,
    pub local: bool,
    pub ty: Option<DType>,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum AKind {
    Comb,
    Ff,
    Latch,
    Plain,
}
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Edge {
    Pos,
    Neg,
    Any,
}

#[derive(Clone, Debug)]
pub struct Func {
    pub name: String,
    pub ret: DType,
    pub args: Vec<(String, DType)>,
    pub body: Stmt,
}

#[derive(Clone, Debug)]
pub enum Stmt {
    Block(Vec<Stmt>),
    If(Expr, Box<Stmt>, Option<Box<Stmt>>),
    Case { kind: u8, sel: Expr, items: Vec<(Vec<Expr>, Stmt)>, default: Option<Box<Stmt>>, inside: bool, full: bool, parallel: bool, line: usize },
    Asgn { lhs: Expr, rhs: Expr, blocking: bool },
    For { var: String, init: Expr, cond: Expr, step: Box<Stmt>, body: Box<Stmt> },
    Decl(Decl),
    Return(Option<Expr>),
    Null,
}

#[derive(Clone, Debug)]
pub enum Item {
    Decl(Decl),
    Param(ParamDecl),
    Assign(Expr, Expr, usize),
    Always { kind: AKind, sens: Vec<(Edge, Expr)>, body: Stmt, line: usize },
    Inst { module: String, params: Vec<(Option<String>, Expr)>, name: String, range: Option<(Expr, Expr)>, conns: Vec<(Option<String>, Option<Expr>)>, wildcard: bool, line: usize },
    GenFor { var: String, init: Expr, cond: Expr, step: Expr, label: Option<String>, items: Vec<Item> },
    GenIf { cond: Expr, then: Vec<Item>, els: Vec<Item> },
    GenCase { sel: Expr, items: Vec<(Vec<Expr>, Vec<Item>)>, default: Vec<Item> },
    GenBlock { label: Option<String>, items: Vec<Item> },
    Typedef(String, DType),
    Func(Func),
    Modport(String, Vec<(Dir, String)>),
    Import(String),
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum ModKind {
    Module,
    Interface,
    Package,
}

#[derive(Clone, Debug)]
pub struct Module {
    pub name: String,
    pub kind: ModKind,
    pub params: Vec<ParamDecl>,
    pub ports: Vec<PortDecl>,
    pub items: Vec<Item>,
    pub file: String,
    pub line: usize,
    pub blackbox: bool,
    pub lang: &'static str,
}

impl Module {
    /// A module with ports but no functional content.
    pub fn is_empty(&self) -> bool {
        self.kind == ModKind::Module
            && !self.items.iter().any(|i| !matches!(i, Item::Decl(_) | Item::Param(_) | Item::Typedef(..) | Item::Import(_)))
    }
}
