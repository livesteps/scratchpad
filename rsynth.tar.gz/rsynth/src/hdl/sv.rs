//! SystemVerilog (IEEE 1800-2017 synthesizable subset) / Verilog-2005 parser.
//! Modules, interfaces (+modports, interface & interface-array ports), packages,
//! typedef/enum/packed struct, parameters (incl. typed), generate for/if/case,
//! always_ff/always_comb/always_latch/always, functions, gate primitives,
//! ANSI and non-ANSI port lists, instance arrays, .name / .* connections.

use super::ast::*;
use super::lex::{parse_number, Tok, T};
use crate::netlist::Dir;
use std::collections::HashSet;

pub struct Parser {
    t: Vec<Tok>,
    i: usize,
    pub file: String,
    pub types: HashSet<String>,
    case_mod: Option<String>,
}

type PR<T> = Result<T, String>;

const TYPE_KW: &[&str] = &["logic", "reg", "wire", "bit", "int", "integer", "byte", "shortint", "longint", "tri", "wand", "wor", "supply0", "supply1", "var", "signed", "unsigned", "enum", "struct", "union", "genvar", "uwire", "tri0", "tri1", "time"];

impl Parser {
    pub fn new(t: Vec<Tok>, file: &str, types: HashSet<String>) -> Self {
        Parser { t, i: 0, file: file.into(), types, case_mod: None }
    }
    fn peek(&self) -> &T {
        &self.t[self.i.min(self.t.len() - 1)].t
    }
    fn peek_at(&self, k: usize) -> &T {
        &self.t[(self.i + k).min(self.t.len() - 1)].t
    }
    fn line(&self) -> usize {
        self.t[self.i.min(self.t.len() - 1)].line
    }
    fn err<X>(&self, m: &str) -> PR<X> {
        Err(format!("{}:{}: syntax error: {} (near {:?})", self.file, self.line(), m, self.peek()))
    }
    fn is(&self, s: &str) -> bool {
        match self.peek() {
            T::Sym(x) | T::Id(x) => x == s,
            _ => false,
        }
    }
    fn is_at(&self, k: usize, s: &str) -> bool {
        match self.peek_at(k) {
            T::Sym(x) | T::Id(x) => x == s,
            _ => false,
        }
    }
    fn eat(&mut self, s: &str) -> bool {
        if self.is(s) {
            self.i += 1;
            true
        } else {
            false
        }
    }
    fn expect(&mut self, s: &str) -> PR<()> {
        if self.eat(s) {
            Ok(())
        } else {
            self.err(&format!("expected '{}'", s))
        }
    }
    fn ident(&mut self) -> PR<String> {
        match self.peek().clone() {
            T::Id(s) => {
                self.i += 1;
                Ok(s)
            }
            _ => self.err("expected identifier"),
        }
    }
    fn is_ident(&self) -> bool {
        matches!(self.peek(), T::Id(_))
    }
    fn skip_to(&mut self, end: &str) {
        while !matches!(self.peek(), T::Eof) && !self.is(end) {
            self.i += 1;
        }
        self.eat(end);
    }
    fn skip_label(&mut self) {
        if self.is(":") && matches!(self.peek_at(1), T::Id(_)) {
            self.i += 2;
        }
    }

    pub fn parse_file(&mut self) -> PR<Vec<Module>> {
        let mut mods = vec![];
        let mut unit_items: Vec<Item> = vec![]; // $unit-scope typedefs/params
        while !matches!(self.peek(), T::Eof) {
            if self.is("module") || self.is("macromodule") {
                self.i += 1;
                mods.push(self.parse_module(ModKind::Module)?);
            } else if self.is("interface") {
                self.i += 1;
                mods.push(self.parse_module(ModKind::Interface)?);
            } else if self.is("package") {
                self.i += 1;
                mods.push(self.parse_module(ModKind::Package)?);
            } else if self.is("typedef") || self.is("parameter") || self.is("localparam") || self.is("import") || self.is("function") {
                self.parse_item(&mut unit_items)?;
            } else if self.is("timeunit") || self.is("timeprecision") {
                self.skip_to(";");
            } else if self.eat(";") {
            } else {
                return self.err("expected module/interface/package");
            }
        }
        if !unit_items.is_empty() {
            mods.push(Module { name: "$unit".into(), kind: ModKind::Package, params: vec![], ports: vec![], items: unit_items, file: self.file.clone(), line: 1, blackbox: false, lang: "sv" });
        }
        Ok(mods)
    }

    fn parse_module(&mut self, kind: ModKind) -> PR<Module> {
        let line = self.line();
        if self.is("automatic") || self.is("static") {
            self.i += 1
        }
        let name = self.ident()?;
        let mut m = Module { name, kind, params: vec![], ports: vec![], items: vec![], file: self.file.clone(), line, blackbox: false, lang: "sv" };
        while self.is("import") {
            self.parse_item(&mut m.items)?;
        }
        if self.eat("#") {
            self.expect("(")?;
            let mut local = false;
            while !self.is(")") {
                if self.eat("parameter") {
                    local = false
                } else if self.eat("localparam") {
                    local = true
                }
                let (ty, istype) = if self.eat("type") { (None, true) } else { (self.parse_dtype_opt()?, false) };
                let pname = self.ident()?;
                while self.is("[") {
                    self.parse_dim()?;
                }
                let value = if self.eat("=") { Some(if istype { self.parse_type_as_expr()? } else { self.parse_expr()? }) } else { None };
                m.params.push(ParamDecl { name: pname, value, local, ty });
                if !self.eat(",") {
                    break;
                }
            }
            self.expect(")")?;
        }
        if self.eat("(") {
            self.parse_port_list(&mut m)?;
            self.expect(")")?;
        }
        self.expect(";")?;
        let endkw = match kind {
            ModKind::Module => "endmodule",
            ModKind::Interface => "endinterface",
            ModKind::Package => "endpackage",
        };
        while !self.is(endkw) {
            if matches!(self.peek(), T::Eof) {
                return self.err(&format!("missing {}", endkw));
            }
            self.parse_item(&mut m.items)?;
        }
        self.i += 1;
        self.skip_label();
        // merge non-ANSI port declarations
        let mut keep = vec![];
        for it in std::mem::take(&mut m.items) {
            match it {
                Item::Decl(d) if d.dir.is_some() => {
                    if let Some(p) = m.ports.iter_mut().find(|p| p.name == d.name) {
                        p.dir = d.dir;
                        p.ty = d.ty;
                        p.unpacked = d.unpacked;
                    } else {
                        m.ports.push(PortDecl { name: d.name, dir: d.dir, ty: d.ty, unpacked: d.unpacked, iface: None });
                    }
                }
                Item::Decl(d) if m.ports.iter().any(|p| p.name == d.name && p.dir.is_some()) => {
                    // "output reg [3:0] q;" style re-declaration: refine type
                    if let Some(p) = m.ports.iter_mut().find(|p| p.name == d.name) {
                        if let DType::Logic { packed, .. } = &d.ty {
                            if !packed.is_empty() {
                                p.ty = d.ty.clone()
                            }
                        }
                    }
                }
                x => keep.push(x),
            }
        }
        // Verilog-2001 body parameters: bind together with header parameters (overridable unless localparam)
        let mut items2 = vec![];
        for it in keep {
            match it {
                Item::Param(p) if kind != ModKind::Package => m.params.push(p),
                x => items2.push(x),
            }
        }
        m.items = items2;
        Ok(m)
    }

    fn parse_port_list(&mut self, m: &mut Module) -> PR<()> {
        let mut cur_dir: Option<Dir> = None;
        let mut cur_ty = DType::bit();
        let mut cur_if: Option<(String, Option<String>)> = None;
        loop {
            if self.is(")") {
                return Ok(());
            }
            let mut dir = None;
            if self.eat("input") {
                dir = Some(Dir::In)
            } else if self.eat("output") {
                dir = Some(Dir::Out)
            } else if self.eat("inout") || self.eat("ref") {
                dir = Some(Dir::InOut)
            }
            let explicit_dir = dir.is_some();
            if explicit_dir {
                cur_dir = dir;
                cur_if = None;
            }
            // interface port:  ifname[.modport] name
            if !explicit_dir && self.is_ident() && !self.types.contains(&self.id_str(0)) && (self.is_at(1, ".") || matches!(self.peek_at(1), T::Id(_))) && !TYPE_KW.contains(&self.id_str(0).as_str()) {
                let ifn = self.ident()?;
                let mp = if self.eat(".") { Some(self.ident()?) } else { None };
                cur_if = Some((ifn, mp));
                cur_dir = None;
            }
            let ty = self.parse_dtype_opt()?;
            if let Some(t) = ty {
                cur_ty = t;
            } else if explicit_dir {
                cur_ty = DType::bit();
            }
            let name = self.ident()?;
            let mut unpacked = vec![];
            while self.is("[") {
                unpacked.push(self.parse_dim()?);
            }
            if self.eat("=") {
                self.parse_expr()?;
            }
            // non-ANSI header: names only (dir None, no type) -> filled later by body decls
            m.ports.push(PortDecl { name, dir: if cur_if.is_some() { None } else { cur_dir }, ty: cur_ty.clone(), unpacked, iface: cur_if.clone() });
            if !self.eat(",") {
                return Ok(());
            }
        }
    }
    fn id_str(&self, k: usize) -> String {
        match self.peek_at(k) {
            T::Id(s) => s.clone(),
            _ => String::new(),
        }
    }

    fn parse_dim(&mut self) -> PR<(Expr, Expr)> {
        self.expect("[")?;
        let a = self.parse_expr()?;
        let r = if self.eat(":") {
            let b = self.parse_expr()?;
            (a, b)
        } else {
            // [N] => [0:N-1]
            (Expr::int(0), Expr::bin("-", a, Expr::int(1)))
        };
        self.expect("]")?;
        Ok(r)
    }

    fn parse_type_as_expr(&mut self) -> PR<Expr> {
        // type parameter defaults: we encode as Id of the type name
        let t = self.parse_dtype_opt()?;
        Ok(match t {
            Some(DType::Named { name, .. }) => Expr::Id(name),
            _ => Expr::Id("logic".into()),
        })
    }

    /// Parse an optional data type. Returns None if the next tokens are not a type.
    pub fn parse_dtype_opt(&mut self) -> PR<Option<DType>> {
        let mut signed = false;
        let mut had = false;
        let mut base_int: Option<i64> = None;
        loop {
            let s = self.id_str(0);
            match s.as_str() {
                "wire" | "tri" | "wand" | "wor" | "uwire" | "var" | "supply0" | "supply1" | "tri0" | "tri1" | "const" | "automatic" | "static" => {
                    self.i += 1;
                    had = true;
                }
                "logic" | "reg" | "bit" => {
                    self.i += 1;
                    had = true;
                }
                "int" | "integer" | "time" => {
                    self.i += 1;
                    had = true;
                    signed = s != "time";
                    base_int = Some(if s == "time" { 64 } else { 32 });
                }
                "byte" => {
                    self.i += 1;
                    had = true;
                    signed = true;
                    base_int = Some(8)
                }
                "shortint" => {
                    self.i += 1;
                    had = true;
                    signed = true;
                    base_int = Some(16)
                }
                "longint" => {
                    self.i += 1;
                    had = true;
                    signed = true;
                    base_int = Some(64)
                }
                "signed" => {
                    self.i += 1;
                    had = true;
                    signed = true
                }
                "unsigned" => {
                    self.i += 1;
                    had = true;
                    signed = false
                }
                "enum" => {
                    self.i += 1;
                    let base = if self.is("{") { DType::int32() } else { self.parse_dtype_opt()?.unwrap_or(DType::int32()) };
                    self.expect("{")?;
                    let mut items = vec![];
                    while !self.is("}") {
                        let n = self.ident()?;
                        let v = if self.eat("=") { Some(self.parse_expr()?) } else { None };
                        items.push((n, v));
                        if !self.eat(",") {
                            break;
                        }
                    }
                    self.expect("}")?;
                    return Ok(Some(DType::Enum { base: Box::new(base), items }));
                }
                "struct" | "union" => {
                    self.i += 1;
                    self.eat("packed");
                    self.eat("signed");
                    self.eat("unsigned");
                    self.expect("{")?;
                    let mut fields = vec![];
                    while !self.is("}") {
                        let ft = self.parse_dtype_opt()?.ok_or_else(|| format!("{}:{}: expected struct field type", self.file, self.line()))?;
                        loop {
                            let fname = self.ident()?;
                            fields.push((fname, ft.clone()));
                            if !self.eat(",") {
                                break;
                            }
                        }
                        self.expect(";")?;
                    }
                    self.expect("}")?;
                    let mut packed = vec![];
                    while self.is("[") {
                        packed.push(self.parse_dim()?);
                    }
                    return Ok(Some(DType::Struct { fields, packed }));
                }
                _ => {
                    // named type? (typedef or pkg::type)
                    if !had && self.is_ident() && self.is_at(1, "::") && self.types.contains(&self.id_str(2)) {
                        self.i += 2;
                        continue;
                    }
                    if !had && self.types.contains(&s) {
                        self.i += 1;
                        let mut packed = vec![];
                        while self.is("[") {
                            packed.push(self.parse_dim()?);
                        }
                        return Ok(Some(DType::Named { name: s, packed }));
                    }
                    break;
                }
            }
        }
        let mut packed = vec![];
        if let Some(w) = base_int {
            packed.push((Expr::int(w - 1), Expr::int(0)));
        }
        while self.is("[") {
            packed.push(self.parse_dim()?);
            had = true;
        }
        Ok(if had { Some(DType::Logic { signed, packed }) } else { None })
    }

    fn parse_decl_list(&mut self, ty: DType, dir: Option<Dir>, out: &mut Vec<Item>) -> PR<()> {
        loop {
            let line = self.line();
            let name = self.ident()?;
            let mut unpacked = vec![];
            while self.is("[") {
                unpacked.push(self.parse_dim()?);
            }
            let init = if self.eat("=") { Some(self.parse_expr()?) } else { None };
            out.push(Item::Decl(Decl { name, ty: ty.clone(), unpacked, init, dir, line }));
            if !self.eat(",") {
                break;
            }
        }
        self.expect(";")
    }

    fn parse_item(&mut self, items: &mut Vec<Item>) -> PR<()> {
        let line = self.line();
        let kw = self.id_str(0);
        match kw.as_str() {
            "input" | "output" | "inout" => {
                self.i += 1;
                let dir = match kw.as_str() {
                    "input" => Dir::In,
                    "output" => Dir::Out,
                    _ => Dir::InOut,
                };
                let ty = self.parse_dtype_opt()?.unwrap_or(DType::bit());
                return self.parse_decl_list(ty, Some(dir), items);
            }
            "parameter" | "localparam" => {
                self.i += 1;
                let local = kw == "localparam";
                let istype = self.eat("type");
                let ty = if istype { None } else { self.parse_dtype_opt()? };
                loop {
                    let name = self.ident()?;
                    while self.is("[") {
                        self.parse_dim()?;
                    }
                    self.expect("=")?;
                    let v = if istype { self.parse_type_as_expr()? } else { self.parse_expr()? };
                    items.push(Item::Param(ParamDecl { name, value: Some(v), local, ty: ty.clone() }));
                    if !self.eat(",") {
                        break;
                    }
                }
                return self.expect(";");
            }
            "typedef" => {
                self.i += 1;
                let ty = self.parse_dtype_opt()?.ok_or_else(|| format!("{}:{}: bad typedef", self.file, line))?;
                let name = self.ident()?;
                while self.is("[") {
                    self.parse_dim()?;
                }
                self.expect(";")?;
                self.types.insert(name.clone());
                items.push(Item::Typedef(name, ty));
                return Ok(());
            }
            "import" => {
                self.i += 1;
                loop {
                    let p = self.ident()?;
                    self.expect("::")?;
                    if !self.eat("*") {
                        self.ident()?;
                    }
                    items.push(Item::Import(p));
                    if !self.eat(",") {
                        break;
                    }
                }
                return self.expect(";");
            }
            "genvar" => {
                self.skip_to(";");
                return Ok(());
            }
            "generate" | "endgenerate" => {
                self.i += 1;
                return Ok(());
            }
            "assign" => {
                self.i += 1;
                if self.is("#") {
                    self.i += 1;
                    self.parse_primary()?;
                }
                loop {
                    let l = self.parse_postfix()?;
                    self.expect("=")?;
                    let r = self.parse_expr()?;
                    items.push(Item::Assign(l, r, line));
                    if !self.eat(",") {
                        break;
                    }
                }
                return self.expect(";");
            }
            "always" | "always_ff" | "always_comb" | "always_latch" => {
                self.i += 1;
                let mut kind = match kw.as_str() {
                    "always_ff" => AKind::Ff,
                    "always_comb" => AKind::Comb,
                    "always_latch" => AKind::Latch,
                    _ => AKind::Plain,
                };
                let mut sens = vec![];
                if self.eat("@") {
                    if self.eat("*") {
                    } else {
                        self.expect("(")?;
                        if self.eat("*") {
                        } else {
                            loop {
                                let e = if self.eat("posedge") {
                                    Edge::Pos
                                } else if self.eat("negedge") {
                                    Edge::Neg
                                } else {
                                    self.eat("edge");
                                    Edge::Any
                                };
                                let x = self.parse_expr()?;
                                sens.push((e, x));
                                if !(self.eat("or") || self.eat(",")) {
                                    break;
                                }
                            }
                        }
                        self.expect(")")?;
                    }
                }
                if kind == AKind::Plain {
                    if sens.iter().any(|(e, _)| *e != Edge::Any) {
                        kind = AKind::Ff
                    } else {
                        kind = AKind::Comb
                    }
                }
                let body = self.parse_stmt()?;
                items.push(Item::Always { kind, sens, body, line });
                return Ok(());
            }
            "initial" | "final" => {
                self.i += 1;
                self.parse_stmt()?; // ignored for synthesis
                crate::warn!("ELAB-311", "{}:{}: '{}' block ignored for synthesis", self.file, line, kw);
                return Ok(());
            }
            "function" => {
                self.i += 1;
                self.eat("automatic");
                self.eat("static");
                let ret = if self.eat("void") { DType::bit() } else { self.parse_dtype_opt()?.unwrap_or(DType::bit()) };
                let name = self.ident()?;
                let mut args = vec![];
                let mut body = vec![];
                if self.eat("(") {
                    let mut cur = DType::bit();
                    while !self.is(")") {
                        self.eat("input");
                        if let Some(t) = self.parse_dtype_opt()? {
                            cur = t
                        }
                        let an = self.ident()?;
                        args.push((an, cur.clone()));
                        if !self.eat(",") {
                            break;
                        }
                    }
                    self.expect(")")?;
                }
                self.expect(";")?;
                while !self.is("endfunction") {
                    if self.is("input") {
                        self.i += 1;
                        let t = self.parse_dtype_opt()?.unwrap_or(DType::bit());
                        loop {
                            args.push((self.ident()?, t.clone()));
                            if !self.eat(",") {
                                break;
                            }
                        }
                        self.expect(";")?;
                        continue;
                    }
                    body.push(self.parse_stmt()?);
                }
                self.i += 1;
                self.skip_label();
                items.push(Item::Func(Func { name, ret, args, body: Stmt::Block(body) }));
                return Ok(());
            }
            "task" => {
                self.skip_to("endtask");
                crate::warn!("ELAB-312", "{}:{}: task ignored (not supported for synthesis)", self.file, line);
                return Ok(());
            }
            "modport" => {
                self.i += 1;
                loop {
                    let name = self.ident()?;
                    self.expect("(")?;
                    let mut sigs = vec![];
                    let mut d = Dir::In;
                    while !self.is(")") {
                        if self.eat("input") {
                            d = Dir::In
                        } else if self.eat("output") {
                            d = Dir::Out
                        } else if self.eat("inout") || self.eat("ref") {
                            d = Dir::InOut
                        } else if self.eat("import") || self.eat("export") {
                            self.ident()?;
                            if !self.eat(",") {
                                break;
                            }
                            continue;
                        }
                        sigs.push((d, self.ident()?));
                        if !self.eat(",") {
                            break;
                        }
                    }
                    self.expect(")")?;
                    items.push(Item::Modport(name, sigs));
                    if !self.eat(",") {
                        break;
                    }
                }
                return self.expect(";");
            }
            "for" => {
                self.i += 1;
                self.expect("(")?;
                self.eat("genvar");
                self.eat("int");
                let var = self.ident()?;
                self.expect("=")?;
                let init = self.parse_expr()?;
                self.expect(";")?;
                let cond = self.parse_expr()?;
                self.expect(";")?;
                let step = self.parse_step(&var)?;
                self.expect(")")?;
                let (label, body) = self.parse_gen_body()?;
                items.push(Item::GenFor { var, init, cond, step, label, items: body });
                return Ok(());
            }
            "if" => {
                self.i += 1;
                self.expect("(")?;
                let cond = self.parse_expr()?;
                self.expect(")")?;
                let (_, then) = self.parse_gen_body()?;
                let els = if self.eat("else") {
                    if self.is("if") {
                        let mut v = vec![];
                        self.parse_item(&mut v)?;
                        v
                    } else {
                        self.parse_gen_body()?.1
                    }
                } else {
                    vec![]
                };
                items.push(Item::GenIf { cond, then, els });
                return Ok(());
            }
            "case" => {
                self.i += 1;
                self.expect("(")?;
                let sel = self.parse_expr()?;
                self.expect(")")?;
                let mut citems = vec![];
                let mut default = vec![];
                while !self.eat("endcase") {
                    if self.eat("default") {
                        self.eat(":");
                        default = self.parse_gen_body()?.1;
                        continue;
                    }
                    let mut es = vec![self.parse_expr()?];
                    while self.eat(",") {
                        es.push(self.parse_expr()?);
                    }
                    self.expect(":")?;
                    citems.push((es, self.parse_gen_body()?.1));
                }
                items.push(Item::GenCase { sel, items: citems, default });
                return Ok(());
            }
            "begin" => {
                let (label, body) = self.parse_gen_body()?;
                items.push(Item::GenBlock { label, items: body });
                return Ok(());
            }
            "and" | "or" | "nand" | "nor" | "xor" | "xnor" | "not" | "buf" => {
                // gate primitive:  and [name] (out, in1, in2, ...);
                self.i += 1;
                loop {
                    if self.is_ident() {
                        self.i += 1;
                    }
                    self.expect("(")?;
                    let mut args = vec![self.parse_expr()?];
                    while self.eat(",") {
                        args.push(self.parse_expr()?);
                    }
                    self.expect(")")?;
                    let out = args.remove(0);
                    let op = match kw.as_str() {
                        "and" | "nand" => "&",
                        "or" | "nor" => "|",
                        "xor" | "xnor" => "^",
                        _ => "",
                    };
                    let mut e = args[0].clone();
                    for a in &args[1..] {
                        e = Expr::bin(op, e, a.clone());
                    }
                    if matches!(kw.as_str(), "nand" | "nor" | "xnor" | "not") {
                        e = Expr::un("~", e);
                    }
                    items.push(Item::Assign(out, e, line));
                    if !self.eat(",") {
                        break;
                    }
                }
                return self.expect(";");
            }
            "assert" | "assume" | "cover" | "restrict" => {
                self.skip_to(";");
                return Ok(());
            }
            "property" => {
                self.skip_to("endproperty");
                return Ok(());
            }
            "sequence" => {
                self.skip_to("endsequence");
                return Ok(());
            }
            "covergroup" => {
                self.skip_to("endgroup");
                return Ok(());
            }
            "specify" => {
                self.skip_to("endspecify");
                return Ok(());
            }
            "clocking" | "default" => {
                self.skip_to(";");
                return Ok(());
            }
            "defparam" => {
                crate::warn!("ELAB-900", "{}:{}: defparam not supported; ignored", self.file, line);
                self.skip_to(";");
                return Ok(());
            }
            ";" => {
                self.i += 1;
                return Ok(());
            }
            _ => {}
        }
        // declarations with explicit type keywords
        if TYPE_KW.contains(&kw.as_str()) {
            let ty = self.parse_dtype_opt()?.unwrap_or(DType::bit());
            return self.parse_decl_list(ty, None, items);
        }
        // label: assert property...
        if self.is_ident() && self.is_at(1, ":") {
            self.i += 2;
            return self.parse_item(items);
        }
        // Named: instance / typed decl
        if self.is_ident() {
            let first = kw.clone();
            if self.is_at(1, "#") || (matches!(self.peek_at(1), T::Id(_)) && self.inst_follows(1)) {
                return self.parse_inst(items, line);
            }
            if self.types.contains(&first) || (self.is_at(1, "::")) {
                let ty = self.parse_dtype_opt()?.ok_or_else(|| format!("{}:{}: unknown type {}", self.file, line, first))?;
                return self.parse_decl_list(ty, None, items);
            }
            if matches!(self.peek_at(1), T::Id(_)) {
                // unknown type name used as type (e.g. typedef from not-yet-parsed package)
                self.types.insert(first.clone());
                let ty = self.parse_dtype_opt()?.unwrap();
                return self.parse_decl_list(ty, None, items);
            }
        }
        self.err("unexpected token in module item")
    }

    /// after `Mod Name`, check if `[dims]* (` follows => instance.
    fn inst_follows(&self, mut k: usize) -> bool {
        k += 1; // skip name
        loop {
            if self.is_at(k, "(") {
                return true;
            }
            if self.is_at(k, "[") {
                let mut d = 0;
                loop {
                    if self.is_at(k, "[") {
                        d += 1
                    }
                    if self.is_at(k, "]") {
                        d -= 1;
                        if d == 0 {
                            k += 1;
                            break;
                        }
                    }
                    if matches!(self.peek_at(k), T::Eof) {
                        return false;
                    }
                    k += 1;
                }
                continue;
            }
            return false;
        }
    }

    fn parse_inst(&mut self, items: &mut Vec<Item>, line: usize) -> PR<()> {
        let module = self.ident()?;
        let mut params = vec![];
        if self.eat("#") {
            self.expect("(")?;
            while !self.is(")") {
                if self.eat(".") {
                    let n = self.ident()?;
                    self.expect("(")?;
                    let v = if self.is(")") { None } else { Some(self.parse_param_value()?) };
                    self.expect(")")?;
                    if let Some(v) = v {
                        params.push((Some(n), v));
                    }
                } else {
                    params.push((None, self.parse_param_value()?));
                }
                if !self.eat(",") {
                    break;
                }
            }
            self.expect(")")?;
        }
        loop {
            let name = self.ident()?;
            let range = if self.is("[") { Some(self.parse_dim()?) } else { None };
            self.expect("(")?;
            let mut conns = vec![];
            let mut wildcard = false;
            while !self.is(")") {
                if self.eat(".*") {
                    wildcard = true;
                } else if self.eat(".") {
                    if self.eat("*") {
                        wildcard = true;
                    } else {
                        let n = self.ident()?;
                        if self.eat("(") {
                            let e = if self.is(")") { None } else { Some(self.parse_expr()?) };
                            self.expect(")")?;
                            conns.push((Some(n), e));
                        } else {
                            conns.push((Some(n.clone()), Some(Expr::Id(n)))); // .name implicit
                        }
                    }
                } else if self.is(",") {
                    conns.push((None, None));
                } else {
                    conns.push((None, Some(self.parse_expr()?)));
                }
                if !self.eat(",") {
                    break;
                }
            }
            self.expect(")")?;
            items.push(Item::Inst { module: module.clone(), params: params.clone(), name, range, conns, wildcard, line });
            if !self.eat(",") {
                break;
            }
        }
        self.expect(";")
    }
    fn parse_param_value(&mut self) -> PR<Expr> {
        // could be a type
        if let T::Id(s) = self.peek().clone() {
            if self.types.contains(&s) || ["logic", "bit", "int", "integer", "byte"].contains(&s.as_str()) {
                if matches!(self.peek_at(1), T::Sym(x) if x == ")" || x == ",") {
                    self.i += 1;
                    return Ok(Expr::Id(s));
                }
            }
        }
        self.parse_expr()
    }

    fn parse_gen_body(&mut self) -> PR<(Option<String>, Vec<Item>)> {
        let mut label = None;
        if self.eat("begin") {
            if self.eat(":") {
                label = Some(self.ident()?)
            }
            let mut v = vec![];
            while !self.eat("end") {
                if matches!(self.peek(), T::Eof) {
                    return self.err("missing end");
                }
                self.parse_item(&mut v)?;
            }
            self.skip_label();
            Ok((label, v))
        } else {
            let mut v = vec![];
            self.parse_item(&mut v)?;
            Ok((None, v))
        }
    }

    fn parse_step(&mut self, var: &str) -> PR<Expr> {
        // returns the new-value expression for var
        let _ = self.ident()?;
        if self.eat("++") {
            return Ok(Expr::bin("+", Expr::id(var), Expr::int(1)));
        }
        if self.eat("--") {
            return Ok(Expr::bin("-", Expr::id(var), Expr::int(1)));
        }
        for (op, b) in [("+=", "+"), ("-=", "-"), ("*=", "*"), ("<<=", "<<"), (">>=", ">>")] {
            if self.eat(op) {
                let e = self.parse_expr()?;
                return Ok(Expr::bin(b, Expr::id(var), e));
            }
        }
        self.expect("=")?;
        self.parse_expr()
    }

    // ------------------------------------------------------------ statements
    pub fn parse_stmt(&mut self) -> PR<Stmt> {
        let line = self.line();
        let kw = self.id_str(0);
        match kw.as_str() {
            "begin" => {
                self.i += 1;
                self.skip_label();
                let mut v = vec![];
                while !self.eat("end") {
                    if matches!(self.peek(), T::Eof) {
                        return self.err("missing end");
                    }
                    v.push(self.parse_stmt()?);
                }
                self.skip_label();
                return Ok(Stmt::Block(v));
            }
            "unique" | "unique0" | "priority" => {
                // SystemVerilog case modifiers: unique = full + parallel, priority = full
                self.i += 1;
                self.case_mod = Some(kw.clone());
                let r = self.parse_stmt();
                self.case_mod = None;
                return r;
            }
            "if" => {
                self.i += 1;
                self.expect("(")?;
                let c = self.parse_expr()?;
                self.expect(")")?;
                let t = self.parse_stmt()?;
                let e = if self.eat("else") { Some(Box::new(self.parse_stmt()?)) } else { None };
                return Ok(Stmt::If(c, Box::new(t), e));
            }
            "case" | "casez" | "casex" => {
                self.i += 1;
                let k = match kw.as_str() {
                    "case" => 0,
                    "casez" => 1,
                    _ => 2,
                };
                self.expect("(")?;
                let sel = self.parse_expr()?;
                self.expect(")")?;
                let line = self.t[self.i.saturating_sub(1)].line;
                let pr = crate::hdl::lex::pragmas_at(line);
                let m = self.case_mod.take();
                let full = pr.iter().any(|p| p == "full_case") || matches!(m.as_deref(), Some("unique") | Some("priority"));
                let parallel = pr.iter().any(|p| p == "parallel_case") || matches!(m.as_deref(), Some("unique") | Some("unique0"));
                let inside = self.eat("inside");
                let mut items = vec![];
                let mut default = None;
                while !self.eat("endcase") {
                    if matches!(self.peek(), T::Eof) {
                        return self.err("missing endcase");
                    }
                    if self.eat("default") {
                        self.eat(":");
                        default = Some(Box::new(self.parse_stmt()?));
                        continue;
                    }
                    let mut es = vec![self.parse_case_label()?];
                    while self.eat(",") {
                        es.push(self.parse_case_label()?);
                    }
                    self.expect(":")?;
                    items.push((es, self.parse_stmt()?));
                }
                return Ok(Stmt::Case { kind: k, sel, items, default, inside, full, parallel, line });
            }
            "for" => {
                self.i += 1;
                self.expect("(")?;
                let _ = self.parse_dtype_opt()?;
                let var = self.ident()?;
                self.expect("=")?;
                let init = self.parse_expr()?;
                self.expect(";")?;
                let cond = self.parse_expr()?;
                self.expect(";")?;
                let stepe = self.parse_step(&var)?;
                self.expect(")")?;
                let body = self.parse_stmt()?;
                return Ok(Stmt::For { var: var.clone(), init, cond, step: Box::new(Stmt::Asgn { lhs: Expr::Id(var), rhs: stepe, blocking: true }), body: Box::new(body) });
            }
            "return" => {
                self.i += 1;
                let e = if self.is(";") { None } else { Some(self.parse_expr()?) };
                self.expect(";")?;
                return Ok(Stmt::Return(e));
            }
            "while" | "repeat" | "forever" | "do" | "foreach" => {
                return Err(format!("{}:{}: '{}' loops are not supported for synthesis (use for with constant bounds) (ELAB-934)", self.file, line, kw));
            }
            "disable" | "assert" | "assume" | "cover" | "wait" => {
                self.skip_to(";");
                return Ok(Stmt::Null);
            }
            ";" => {
                self.i += 1;
                return Ok(Stmt::Null);
            }
            _ => {}
        }
        if self.is("#") {
            self.i += 1;
            self.parse_primary()?;
            return self.parse_stmt();
        }
        if self.is("@") {
            self.i += 1;
            if self.eat("(") {
                self.skip_to(")");
            } else {
                self.i += 1;
            }
            return self.parse_stmt();
        }
        if let T::Sys(_) = self.peek() {
            self.i += 1;
            if self.eat("(") {
                let mut d = 1;
                while d > 0 && !matches!(self.peek(), T::Eof) {
                    if self.is("(") {
                        d += 1
                    }
                    if self.is(")") {
                        d -= 1
                    }
                    self.i += 1;
                }
            }
            self.eat(";");
            return Ok(Stmt::Null);
        }
        if TYPE_KW.contains(&kw.as_str()) || (self.types.contains(&kw) && matches!(self.peek_at(1), T::Id(_))) {
            let ty = self.parse_dtype_opt()?.unwrap();
            let name = self.ident()?;
            let mut unpacked = vec![];
            while self.is("[") {
                unpacked.push(self.parse_dim()?);
            }
            let init = if self.eat("=") { Some(self.parse_expr()?) } else { None };
            let mut v = vec![Stmt::Decl(Decl { name: name.clone(), ty: ty.clone(), unpacked, init: None, dir: None, line })];
            if let Some(i) = init {
                v.push(Stmt::Asgn { lhs: Expr::Id(name), rhs: i, blocking: true });
            }
            while self.eat(",") {
                let n = self.ident()?;
                v.push(Stmt::Decl(Decl { name: n, ty: ty.clone(), unpacked: vec![], init: None, dir: None, line }));
            }
            self.expect(";")?;
            return Ok(if v.len() == 1 { v.pop().unwrap() } else { Stmt::Block(v) });
        }
        // assignment
        let lhs = self.parse_postfix()?;
        if self.eat("++") || self.eat("--") {
            let op = if matches!(&self.t[self.i - 1].t, T::Sym(s) if s=="++") { "+" } else { "-" };
            self.expect(";")?;
            return Ok(Stmt::Asgn { lhs: lhs.clone(), rhs: Expr::bin(op, lhs, Expr::int(1)), blocking: true });
        }
        for (op, b) in [("+=", "+"), ("-=", "-"), ("*=", "*"), ("&=", "&"), ("|=", "|"), ("^=", "^"), ("<<=", "<<"), (">>=", ">>")] {
            if self.eat(op) {
                let e = self.parse_expr()?;
                self.expect(";")?;
                return Ok(Stmt::Asgn { lhs: lhs.clone(), rhs: Expr::bin(b, lhs, e), blocking: true });
            }
        }
        let blocking = if self.eat("=") {
            true
        } else if self.eat("<=") {
            false
        } else {
            if self.eat("(") {
                // task/function call statement
                self.skip_to(")");
                self.eat(";");
                return Ok(Stmt::Null);
            }
            if self.eat(";") {
                return Ok(Stmt::Null);
            }
            return self.err("expected assignment");
        };
        if self.is("#") {
            self.i += 1;
            self.parse_primary()?;
        }
        let rhs = self.parse_expr()?;
        self.expect(";")?;
        Ok(Stmt::Asgn { lhs, rhs, blocking })
    }
    fn parse_case_label(&mut self) -> PR<Expr> {
        if self.is("[") {
            self.i += 1;
            let a = self.parse_expr()?;
            self.expect(":")?;
            let b = self.parse_expr()?;
            self.expect("]")?;
            return Ok(Expr::Range(Box::new(Expr::Id("$range".into())), Box::new(a), Box::new(b)));
        }
        self.parse_expr()
    }

    // ------------------------------------------------------------ expressions
    pub fn parse_expr(&mut self) -> PR<Expr> {
        let c = self.parse_bin(0)?;
        if self.eat("?") {
            let a = self.parse_expr()?;
            self.expect(":")?;
            let b = self.parse_expr()?;
            return Ok(Expr::Cond(Box::new(c), Box::new(a), Box::new(b)));
        }
        Ok(c)
    }
    fn prec(op: &str) -> Option<u8> {
        Some(match op {
            "||" => 1,
            "&&" => 2,
            "|" | "~|" => 3,
            "^" | "~^" | "^~" => 4,
            "&" | "~&" => 5,
            "==" | "!=" | "===" | "!==" | "==?" | "!=?" => 6,
            "<" | "<=" | ">" | ">=" | "inside" => 7,
            "<<" | ">>" | "<<<" | ">>>" => 8,
            "+" | "-" => 9,
            "*" | "/" | "%" => 10,
            "**" => 11,
            _ => return None,
        })
    }
    fn parse_bin(&mut self, min: u8) -> PR<Expr> {
        let mut l = self.parse_unary()?;
        loop {
            let op = match self.peek() {
                T::Sym(s) => s.clone(),
                T::Id(s) if s == "inside" => s.clone(),
                _ => break,
            };
            let Some(p) = Self::prec(&op) else { break };
            if p < min {
                break;
            }
            self.i += 1;
            if op == "inside" {
                self.expect("{")?;
                let mut set = vec![];
                while !self.is("}") {
                    set.push(self.parse_case_label()?);
                    if !self.eat(",") {
                        break;
                    }
                }
                self.expect("}")?;
                l = Expr::Inside(Box::new(l), set);
                continue;
            }
            let r = if op == "**" { self.parse_bin(p)? } else { self.parse_bin(p + 1)? };
            l = Expr::bin(&op, l, r);
        }
        Ok(l)
    }
    fn parse_unary(&mut self) -> PR<Expr> {
        for op in ["!", "~", "-", "+", "&", "|", "^", "~&", "~|", "~^", "^~"] {
            if self.is(op) {
                self.i += 1;
                let e = self.parse_unary()?;
                return Ok(Expr::un(op, e));
            }
        }
        self.parse_postfix()
    }
    pub fn parse_postfix(&mut self) -> PR<Expr> {
        let mut e = self.parse_primary()?;
        loop {
            if self.is("[") {
                self.i += 1;
                let a = self.parse_expr()?;
                if self.eat(":") {
                    let b = self.parse_expr()?;
                    self.expect("]")?;
                    e = Expr::Range(Box::new(e), Box::new(a), Box::new(b));
                } else if self.eat("+:") {
                    let b = self.parse_expr()?;
                    self.expect("]")?;
                    e = Expr::PlusRange(Box::new(e), Box::new(a), Box::new(b), true);
                } else if self.eat("-:") {
                    let b = self.parse_expr()?;
                    self.expect("]")?;
                    e = Expr::PlusRange(Box::new(e), Box::new(a), Box::new(b), false);
                } else {
                    self.expect("]")?;
                    e = Expr::Index(Box::new(e), Box::new(a));
                }
            } else if self.is(".") && matches!(self.peek_at(1), T::Id(_)) {
                self.i += 1;
                let m = self.ident()?;
                e = Expr::Member(Box::new(e), m);
            } else if self.is("'") && self.is_at(1, "(") {
                self.i += 2;
                let x = self.parse_expr()?;
                self.expect(")")?;
                e = Expr::Cast(Box::new(e), Box::new(x));
            } else {
                break;
            }
        }
        Ok(e)
    }
    fn parse_primary(&mut self) -> PR<Expr> {
        match self.peek().clone() {
            T::Num(s) => {
                self.i += 1;
                let (width, bits, signed, fill) = parse_number(&s).map_err(|e| format!("{}:{}: {}", self.file, self.line(), e))?;
                Ok(Expr::Num { width, bits, signed, fill })
            }
            T::Str(s) => {
                self.i += 1;
                Ok(Expr::Str(s))
            }
            T::Sys(s) => {
                self.i += 1;
                let mut args = vec![];
                if self.eat("(") {
                    while !self.is(")") {
                        // $bits(type)
                        if let T::Id(n) = self.peek().clone() {
                            if self.types.contains(&n) && matches!(self.peek_at(1), T::Sym(x) if x==")") {
                                self.i += 1;
                                args.push(Expr::Id(n));
                                continue;
                            }
                        }
                        args.push(self.parse_expr()?);
                        if !self.eat(",") {
                            break;
                        }
                    }
                    self.expect(")")?;
                }
                Ok(Expr::Call(s, args))
            }
            T::Id(s) => {
                self.i += 1;
                if self.eat("::") {
                    let n = self.ident()?;
                    if self.is("(") {
                        return self.call_args(n);
                    }
                    return Ok(Expr::Scoped(s, n));
                }
                if self.is("(") && !self.types.contains(&s) {
                    return self.call_args(s);
                }
                Ok(Expr::Id(s))
            }
            T::Sym(s) if s == "(" => {
                self.i += 1;
                let e = self.parse_expr()?;
                self.expect(")")?;
                Ok(e)
            }
            T::Sym(s) if s == "'{" => {
                self.i += 1;
                let mut parts = vec![];
                let mut fill = None;
                while !self.is("}") {
                    if self.eat("default") {
                        self.expect(":")?;
                        fill = Some(self.parse_expr()?);
                    } else {
                        let e = self.parse_expr()?;
                        if self.eat(":") {
                            // member: value  -- positional fallback
                            parts.push(self.parse_expr()?);
                        } else {
                            parts.push(e);
                        }
                    }
                    if !self.eat(",") {
                        break;
                    }
                }
                self.expect("}")?;
                if let Some(f) = fill {
                    return Ok(Expr::Fill(Box::new(f)));
                }
                Ok(Expr::Concat(parts))
            }
            T::Sym(s) if s == "{" => {
                self.i += 1;
                let first = self.parse_expr()?;
                if self.is("{") {
                    // replication
                    self.i += 1;
                    let mut v = vec![self.parse_expr()?];
                    while self.eat(",") {
                        v.push(self.parse_expr()?);
                    }
                    self.expect("}")?;
                    self.expect("}")?;
                    return Ok(Expr::Repl(Box::new(first), v));
                }
                let mut v = vec![first];
                while self.eat(",") {
                    v.push(self.parse_expr()?);
                }
                self.expect("}")?;
                Ok(Expr::Concat(v))
            }
            _ => self.err("expected expression"),
        }
    }
    fn call_args(&mut self, name: String) -> PR<Expr> {
        self.expect("(")?;
        let mut args = vec![];
        while !self.is(")") {
            args.push(self.parse_expr()?);
            if !self.eat(",") {
                break;
            }
        }
        self.expect(")")?;
        Ok(Expr::Call(name, args))
    }
}
