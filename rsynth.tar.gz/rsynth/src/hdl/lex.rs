//! Verilog/SystemVerilog preprocessor and lexer.

use std::collections::HashMap;

#[derive(Clone, Debug, PartialEq)]
pub enum T {
    Id(String),
    Num(String),
    Str(String),
    Sym(String),
    Sys(String),
    Eof,
}
#[derive(Clone, Debug)]
pub struct Tok {
    pub t: T,
    pub line: usize,
}

#[derive(Default)]
pub struct Preproc {
    pub defines: HashMap<String, (Vec<String>, String)>,
    pub incdirs: Vec<String>,
}

impl Preproc {
    pub fn run(&mut self, src: &str, file: &str, depth: usize) -> Result<String, String> {
        if depth > 20 {
            return Err("include depth exceeded".into());
        }
        let mut out = String::new();
        let mut stack: Vec<(bool, bool)> = vec![]; // (active, taken)
        let active = |st: &Vec<(bool, bool)>| st.iter().all(|x| x.0);
        let lines: Vec<&str> = src.lines().collect();
        let mut li = 0;
        while li < lines.len() {
            let mut line = lines[li].to_string();
            // join continuation lines for defines
            while line.ends_with('\\') && li + 1 < lines.len() {
                line.pop();
                li += 1;
                line.push('\n');
                line.push_str(lines[li]);
                out.push('\n');
            }
            li += 1;
            let t = line.trim_start();
            if let Some(d) = t.strip_prefix('`') {
                let word: String = d.chars().take_while(|c| c.is_alphanumeric() || *c == '_').collect();
                let rest = d[word.len()..].trim();
                match word.as_str() {
                    "ifdef" | "ifndef" => {
                        let n = rest.split_whitespace().next().unwrap_or("");
                        let def = self.defines.contains_key(n);
                        let c = if word == "ifdef" { def } else { !def };
                        stack.push((c, c));
                        out.push('\n');
                        continue;
                    }
                    "elsif" => {
                        let n = rest.split_whitespace().next().unwrap_or("");
                        if let Some(top) = stack.last_mut() {
                            if top.1 {
                                top.0 = false
                            } else {
                                let c = self.defines.contains_key(n);
                                top.0 = c;
                                top.1 = c;
                            }
                        }
                        out.push('\n');
                        continue;
                    }
                    "else" => {
                        if let Some(top) = stack.last_mut() {
                            top.0 = !top.1;
                            top.1 = true;
                        }
                        out.push('\n');
                        continue;
                    }
                    "endif" => {
                        stack.pop();
                        out.push('\n');
                        continue;
                    }
                    _ => {}
                }
                if !active(&stack) {
                    out.push('\n');
                    continue;
                }
                match word.as_str() {
                    "define" => {
                        let name: String = rest.chars().take_while(|c| c.is_alphanumeric() || *c == '_').collect();
                        let after = &rest[name.len()..];
                        let (args, body) = if after.starts_with('(') {
                            let e = after.find(')').unwrap_or(after.len() - 1);
                            (after[1..e].split(',').map(|s| s.trim().to_string()).collect(), after[e + 1..].trim().to_string())
                        } else {
                            (vec![], after.trim().to_string())
                        };
                        let body = strip_line_comment(&body);
                        self.defines.insert(name, (args, body));
                        out.push('\n');
                        continue;
                    }
                    "undef" => {
                        self.defines.remove(rest.trim());
                        out.push('\n');
                        continue;
                    }
                    "include" => {
                        let f = rest.trim().trim_matches(|c| c == '"' || c == '<' || c == '>');
                        let f = strip_line_comment(f).trim().trim_matches('"').to_string();
                        let base = std::path::Path::new(file).parent().map(|p| p.to_string_lossy().to_string()).unwrap_or(".".into());
                        let mut cands = vec![format!("{}/{}", base, f), f.clone()];
                        for d in &self.incdirs {
                            cands.push(format!("{}/{}", d, f));
                        }
                        let p = cands.into_iter().find(|p| std::path::Path::new(p).exists()).ok_or_else(|| format!("{}: cannot find include file '{}'", file, f))?;
                        let s = std::fs::read_to_string(&p).map_err(|e| e.to_string())?;
                        let x = self.run(&s, &p, depth + 1)?;
                        out.push_str(&x.replace('\n', " "));
                        out.push('\n');
                        continue;
                    }
                    "timescale" | "default_nettype" | "resetall" | "celldefine" | "endcelldefine" | "pragma" | "line" | "unconnected_drive" | "nounconnected_drive" => {
                        out.push('\n');
                        continue;
                    }
                    _ => {}
                }
            }
            if !active(&stack) {
                out.push('\n');
                continue;
            }
            out.push_str(&self.expand(&line, 0));
            out.push('\n');
        }
        Ok(out)
    }
    fn expand(&self, line: &str, depth: usize) -> String {
        if depth > 16 || !line.contains('`') {
            return line.to_string();
        }
        let c: Vec<char> = line.chars().collect();
        let mut o = String::new();
        let mut i = 0;
        while i < c.len() {
            if c[i] == '`' {
                let mut j = i + 1;
                while j < c.len() && (c[j].is_alphanumeric() || c[j] == '_') {
                    j += 1
                }
                let name: String = c[i + 1..j].iter().collect();
                if let Some((args, body)) = self.defines.get(&name) {
                    let mut b = body.clone();
                    if !args.is_empty() && j < c.len() && c[j] == '(' {
                        let mut d = 0;
                        let mut k = j;
                        let mut vals = vec![];
                        let mut cur = String::new();
                        while k < c.len() {
                            let ch = c[k];
                            if ch == '(' {
                                d += 1;
                                if d > 1 {
                                    cur.push(ch)
                                }
                            } else if ch == ')' {
                                d -= 1;
                                if d == 0 {
                                    break;
                                }
                                cur.push(ch)
                            } else if ch == ',' && d == 1 {
                                vals.push(cur.trim().to_string());
                                cur.clear();
                            } else {
                                cur.push(ch)
                            }
                            k += 1;
                        }
                        vals.push(cur.trim().to_string());
                        for (a, v) in args.iter().zip(vals.iter()) {
                            b = replace_word(&b, a, v);
                        }
                        j = k + 1;
                    }
                    o.push_str(&self.expand(&b, depth + 1));
                    i = j;
                    continue;
                }
                o.push_str(&c[i..j].iter().collect::<String>());
                i = j;
                continue;
            }
            o.push(c[i]);
            i += 1;
        }
        o
    }
}

fn strip_line_comment(s: &str) -> String {
    match s.find("//") {
        Some(i) => s[..i].trim().to_string(),
        None => s.to_string(),
    }
}
fn replace_word(s: &str, w: &str, v: &str) -> String {
    let c: Vec<char> = s.chars().collect();
    let wc: Vec<char> = w.chars().collect();
    let mut o = String::new();
    let mut i = 0;
    while i < c.len() {
        if c[i..].starts_with(&wc[..])
            && (i == 0 || !(c[i - 1].is_alphanumeric() || c[i - 1] == '_'))
            && (i + wc.len() >= c.len() || !(c[i + wc.len()].is_alphanumeric() || c[i + wc.len()] == '_'))
        {
            o.push_str(v);
            i += wc.len();
        } else {
            o.push(c[i]);
            i += 1;
        }
    }
    o
}

const SYMS: &[&str] = &[
    "<<<=", ">>>=", "===", "!==", "<<<", ">>>", "<<=", ">>=", "==?", "!=?", "->", "::", "+:", "-:", "**", "&&", "||", "==", "!=", "<=", ">=", "<<", ">>", "~&", "~|", "~^", "^~", "++", "--", "+=", "-=", "*=", "&=", "|=", "^=", ".*", "'{",
];

/// pragma kinds recorded at a source line
pub fn pragmas_at(line: usize) -> Vec<String> {
    PRAGMAS.with(|v| v.borrow().iter().filter(|p| p.line == line).map(|p| p.kind.clone()).collect())
}
pub fn take_pragmas() -> Vec<Pragma> {
    PRAGMAS.with(|v| std::mem::take(&mut *v.borrow_mut()))
}

/// a synthesis directive found in a comment: (line, directive, arguments)
#[derive(Clone, Debug)]
pub struct Pragma {
    pub line: usize,
    pub kind: String,
    pub args: String,
}

thread_local! {
    /// pragmas of the last lexed source (drained by the reader)
    pub static PRAGMAS: std::cell::RefCell<Vec<Pragma>> = std::cell::RefCell::new(vec![]);
}

const PRAGMA_WORDS: &[&str] = &["synopsys", "pragma", "synthesis", "ambit", "cadence", "rtl_synthesis", "exemplar"];

/// "synopsys full_case parallel_case" -> [("full_case", ""), ("parallel_case", "")];
/// "synopsys sync_set_reset \"rst\"" -> [("sync_set_reset", "rst")]
pub fn parse_pragma(text: &str) -> Option<Vec<(String, String)>> {
    let t = text.trim();
    let mut w = t.split_whitespace();
    let first = w.next()?.to_lowercase();
    if !PRAGMA_WORDS.contains(&first.as_str()) {
        return None;
    }
    let rest: Vec<&str> = w.collect();
    if rest.is_empty() {
        return None;
    }
    // rtl_synthesis off / on
    if first == "rtl_synthesis" {
        return Some(vec![(if rest[0] == "off" { "translate_off" } else { "translate_on" }.to_string(), String::new())]);
    }
    let mut out = vec![];
    let mut i = 0;
    while i < rest.len() {
        let k = rest[i].to_lowercase();
        let k = match k.as_str() {
            "synthesis_off" | "synthesis" if rest.get(i + 1) == Some(&"off") => {
                i += 1;
                "translate_off".to_string()
            }
            "synthesis_on" => "translate_on".to_string(),
            _ => k,
        };
        // quoted argument (or the remainder for scripts)
        let mut arg = String::new();
        if i + 1 < rest.len() && rest[i + 1].starts_with('"') {
            let mut j = i + 1;
            let mut parts = vec![];
            loop {
                parts.push(rest[j]);
                if rest[j].ends_with('"') && (j > i + 1 || rest[j].len() > 1) {
                    break;
                }
                j += 1;
                if j >= rest.len() {
                    break;
                }
            }
            arg = parts.join(" ").trim_matches('"').to_string();
            i = j;
        }
        out.push((k, arg));
        i += 1;
    }
    Some(out)
}

fn record(line: usize, ps: &[(String, String)]) {
    PRAGMAS.with(|v| {
        for (k, a) in ps {
            v.borrow_mut().push(Pragma { line, kind: k.clone(), args: a.clone() });
        }
    });
}

/// after a translate_off comment ending at `i`: index just past the matching translate_on comment
fn skip_translate_off(c: &[char], mut i: usize, line: &mut usize) -> usize {
    while i < c.len() {
        if c[i] == '\n' {
            *line += 1;
            i += 1;
            continue;
        }
        if c[i] == '/' && i + 1 < c.len() && (c[i + 1] == '/' || c[i + 1] == '*') {
            let block = c[i + 1] == '*';
            let st = i + 2;
            let mut j = st;
            if block {
                while j + 1 < c.len() && !(c[j] == '*' && c[j + 1] == '/') {
                    j += 1;
                }
            } else {
                while j < c.len() && c[j] != '\n' {
                    j += 1;
                }
            }
            let text: String = c[st..j.min(c.len())].iter().collect();
            let nl = text.matches('\n').count();
            let end = if block { (j + 2).min(c.len()) } else { j };
            if let Some(ps) = parse_pragma(&text) {
                if ps.iter().any(|(k, _)| k == "translate_on") {
                    *line += nl;
                    return end;
                }
            }
            *line += nl;
            i = end;
            continue;
        }
        i += 1;
    }
    i
}

pub fn lex(src: &str) -> Result<Vec<Tok>, String> {
    let mut in_script = false;
    let c: Vec<char> = src.chars().collect();
    let mut i = 0;
    let mut line = 1;
    let mut v = vec![];
    while i < c.len() {
        let ch = c[i];
        if ch == '\n' {
            line += 1;
            i += 1;
            continue;
        }
        if ch.is_whitespace() {
            i += 1;
            continue;
        }
        if ch == '/' && i + 1 < c.len() && c[i + 1] == '/' {
            let st = i + 2;
            while i < c.len() && c[i] != '\n' {
                i += 1
            }
            let text: String = c[st..i].iter().collect();
            if in_script {
                match parse_pragma(&text) {
                    Some(ps) if ps.iter().any(|(k, _)| k == "dc_tcl_script_end" || k == "dc_script_end") => {
                        in_script = false;
                        record(line, &ps);
                    }
                    _ => record(line, &[("dc_tcl".to_string(), text.trim().to_string())]),
                }
                continue;
            }
            if let Some(ps) = parse_pragma(&text) {
                if ps.iter().any(|(k, _)| k == "dc_tcl_script_begin" || k == "dc_script_begin") {
                    in_script = true;
                }
                if ps.iter().any(|(k, _)| k == "translate_off") {
                    record(line, &[("translate_off".to_string(), String::new())]);
                    i = skip_translate_off(&c, i, &mut line);
                    continue;
                }
                record(line, &ps);
            }
            continue;
        }
        if ch == '/' && i + 1 < c.len() && c[i + 1] == '*' {
            let l0 = line;
            i += 2;
            let st = i;
            while i + 1 < c.len() && !(c[i] == '*' && c[i + 1] == '/') {
                if c[i] == '\n' {
                    line += 1
                }
                i += 1;
            }
            let text: String = c[st..i.min(c.len())].iter().collect();
            i += 2;
            if in_script {
                match parse_pragma(&text) {
                    Some(ps) if ps.iter().any(|(k, _)| k == "dc_tcl_script_end" || k == "dc_script_end") => {
                        in_script = false;
                        record(l0, &ps);
                    }
                    _ => {
                        for l in text.lines().map(|l| l.trim()).filter(|l| !l.is_empty()) {
                            record(l0, &[("dc_tcl".to_string(), l.to_string())]);
                        }
                    }
                }
                continue;
            }
            if let Some(ps) = parse_pragma(&text) {
                if ps.iter().any(|(k, _)| k == "dc_tcl_script_begin" || k == "dc_script_begin") {
                    in_script = true;
                    // script lines may follow inside the same block comment
                    for l in text.lines().skip(1).map(|l| l.trim()).filter(|l| !l.is_empty()) {
                        record(l0, &[("dc_tcl".to_string(), l.to_string())]);
                    }
                }
                if ps.iter().any(|(k, _)| k == "translate_off") {
                    record(l0, &[("translate_off".to_string(), String::new())]);
                    i = skip_translate_off(&c, i, &mut line);
                    continue;
                }
                record(l0, &ps);
            }
            continue;
        }
        // attribute (* ... *) — but not @(*)
        if ch == '(' && i + 1 < c.len() && c[i + 1] == '*' {
            let mut j = i + 2;
            while j < c.len() && c[j] == ' ' {
                j += 1
            }
            if j < c.len() && c[j] == ')' {
                v.push(Tok { t: T::Sym("(".into()), line });
                v.push(Tok { t: T::Sym("*".into()), line });
                v.push(Tok { t: T::Sym(")".into()), line });
                i = j + 1;
                continue;
            }
            i += 2;
            while i + 1 < c.len() && !(c[i] == '*' && c[i + 1] == ')') {
                if c[i] == '\n' {
                    line += 1
                }
                i += 1;
            }
            i += 2;
            continue;
        }
        if ch == '"' {
            let mut s = String::new();
            i += 1;
            while i < c.len() && c[i] != '"' {
                if c[i] == '\\' {
                    i += 1
                }
                if i < c.len() {
                    s.push(c[i])
                }
                i += 1;
            }
            i += 1;
            v.push(Tok { t: T::Str(s), line });
            continue;
        }
        if ch == '\\' {
            // escaped identifier
            let mut s = String::new();
            i += 1;
            while i < c.len() && !c[i].is_whitespace() {
                s.push(c[i]);
                i += 1
            }
            v.push(Tok { t: T::Id(s), line });
            continue;
        }
        if ch == '$' && i + 1 < c.len() && (c[i + 1].is_alphabetic() || c[i + 1] == '_') {
            let mut s = String::from("$");
            i += 1;
            while i < c.len() && (c[i].is_alphanumeric() || c[i] == '_') {
                s.push(c[i]);
                i += 1
            }
            v.push(Tok { t: T::Sys(s), line });
            continue;
        }
        if ch.is_alphabetic() || ch == '_' {
            let mut s = String::new();
            while i < c.len() && (c[i].is_alphanumeric() || c[i] == '_' || c[i] == '$') {
                s.push(c[i]);
                i += 1
            }
            v.push(Tok { t: T::Id(s), line });
            continue;
        }
        // numbers: [size]'[s]base digits | decimal | real | '0 '1 'x
        let based_start = |k: usize| -> bool {
            k < c.len() && c[k] == '\'' && k + 1 < c.len() && {
                let mut m = k + 1;
                if m < c.len() && (c[m] == 's' || c[m] == 'S') {
                    m += 1
                }
                m < c.len() && "bBoOdDhH".contains(c[m])
            }
        };
        if ch.is_ascii_digit() || (ch == '\'' && (based_start(i) || (i + 1 < c.len() && "01xXzZ".contains(c[i + 1]) && !(i + 2 < c.len() && c[i + 2].is_alphanumeric())))) {
            let mut s = String::new();
            if ch.is_ascii_digit() {
                while i < c.len() && (c[i].is_ascii_digit() || c[i] == '_') {
                    s.push(c[i]);
                    i += 1
                }
                if i < c.len() && c[i] == '.' && i + 1 < c.len() && c[i + 1].is_ascii_digit() {
                    s.push('.');
                    i += 1;
                    while i < c.len() && (c[i].is_ascii_digit() || c[i] == 'e' || c[i] == 'E') {
                        s.push(c[i]);
                        i += 1
                    }
                    v.push(Tok { t: T::Num(s), line });
                    continue;
                }
                let mut j = i;
                while j < c.len() && c[j] == ' ' {
                    j += 1
                }
                if based_start(j) {
                    i = j;
                } else {
                    v.push(Tok { t: T::Num(s), line });
                    continue;
                }
            }
            // based part
            s.push('\'');
            i += 1;
            if i < c.len() && "01xXzZ".contains(c[i]) && !based_start(i - 1) {
                s.push(c[i]);
                i += 1;
                v.push(Tok { t: T::Num(s), line });
                continue;
            }
            if c[i] == 's' || c[i] == 'S' {
                s.push('s');
                i += 1
            }
            s.push(c[i].to_ascii_lowercase());
            i += 1;
            while i < c.len() && c[i] == ' ' {
                i += 1
            }
            while i < c.len() && (c[i].is_ascii_hexdigit() || "xXzZ?_".contains(c[i])) {
                s.push(c[i]);
                i += 1
            }
            v.push(Tok { t: T::Num(s), line });
            continue;
        }
        let mut matched = false;
        for s in SYMS {
            let sc: Vec<char> = s.chars().collect();
            if c[i..].starts_with(&sc[..]) {
                v.push(Tok { t: T::Sym(s.to_string()), line });
                i += sc.len();
                matched = true;
                break;
            }
        }
        if matched {
            continue;
        }
        if "()[]{};:,.=<>+-*/%&|^~!?#@'".contains(ch) {
            v.push(Tok { t: T::Sym(ch.to_string()), line });
            i += 1;
            continue;
        }
        return Err(format!("line {}: unexpected character '{}'", line, ch));
    }
    v.push(Tok { t: T::Eof, line });
    Ok(v)
}

/// Convert a Verilog number literal into (width, bits LSB-first, signed, fill)
pub fn parse_number(s: &str) -> Result<(Option<u32>, Vec<u8>, bool, bool), String> {
    let s = s.replace('_', "");
    if !s.contains('\'') {
        if s.contains('.') {
            let f: f64 = s.parse().map_err(|_| format!("bad real {}", s))?;
            return Ok((None, to_bits(f as i64 as u128, 32), true, false));
        }
        let v: u128 = s.parse().map_err(|_| format!("bad number {}", s))?;
        let w = (128 - v.leading_zeros()).max(32);
        return Ok((None, to_bits(v, w as usize), true, false));
    }
    let (sz, rest) = s.split_once('\'').unwrap();
    let width: Option<u32> = if sz.is_empty() { None } else { Some(sz.parse().map_err(|_| format!("bad size {}", s))?) };
    let mut r = rest.chars().peekable();
    if rest.len() == 1 {
        let b = match rest {
            "0" => 0,
            "1" => 1,
            "x" | "X" => 2,
            _ => 3,
        };
        return Ok((None, vec![b], false, true));
    }
    let mut signed = false;
    if r.peek() == Some(&'s') {
        signed = true;
        r.next();
    }
    let base = r.next().ok_or("bad number")?;
    let digits: String = r.collect();
    let (bpd, radix) = match base {
        'b' => (1, 2),
        'o' => (3, 8),
        'h' => (4, 16),
        _ => (0, 10),
    };
    let mut bits: Vec<u8> = vec![];
    if radix == 10 {
        if digits.chars().all(|c| "xXzZ?".contains(c)) {
            bits = vec![if digits.to_lowercase().starts_with('x') { 2 } else { 3 }; width.unwrap_or(32) as usize];
        } else {
            let v: u128 = digits.parse().map_err(|_| format!("bad decimal {}", s))?;
            bits = to_bits(v, width.unwrap_or(32) as usize);
        }
    } else {
        for ch in digits.chars().rev() {
            let (val, special) = match ch {
                'x' | 'X' => (0, Some(2u8)),
                'z' | 'Z' | '?' => (0, Some(3u8)),
                d => (d.to_digit(radix).ok_or(format!("bad digit in {}", s))?, None),
            };
            for k in 0..bpd {
                bits.push(match special {
                    Some(x) => x,
                    None => ((val >> k) & 1) as u8,
                });
            }
        }
    }
    let w = width.map(|w| w as usize).unwrap_or(bits.len().max(32));
    let ext = if bits.last().map(|b| *b >= 2).unwrap_or(false) { *bits.last().unwrap() } else { 0 };
    bits.resize(w, ext);
    Ok((width, bits, signed, false))
}
pub fn to_bits(v: u128, w: usize) -> Vec<u8> {
    (0..w).map(|k| if k < 128 { ((v >> k) & 1) as u8 } else { 0 }).collect()
}
