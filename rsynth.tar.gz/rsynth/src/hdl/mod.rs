pub mod ast;
pub mod lex;
pub mod sv;
pub mod vhdl;

use ast::*;
use std::collections::{HashMap, HashSet};

/// Design library of analyzed units (equivalent of the WORK library).
#[derive(Default)]
pub struct HdlLib {
    pub modules: HashMap<String, Module>,
    pub order: Vec<String>,
    pub types: HashSet<String>,
    pub pre: lex::Preproc,
    /// synthesis pragmas found while reading: (file, pragma)
    pub pragmas: Vec<(String, lex::Pragma)>,
}

impl HdlLib {
    pub fn add(&mut self, m: Module, as_blackbox: bool) {
        let mut m = m;
        if as_blackbox {
            m.blackbox = true;
            m.items.retain(|i| matches!(i, Item::Param(_) | Item::Typedef(..) | Item::Import(_)));
        }
        if let Some(old) = self.modules.get(&m.name) {
            // a VHDL component stub never overrides a real definition
            if m.blackbox && !old.blackbox && !as_blackbox {
                return;
            }
            crate::warn!("VER-130", "Design unit '{}' redefined ({} overrides {})", m.name, m.file, old.file);
        } else {
            self.order.push(m.name.clone());
        }
        self.modules.insert(m.name.clone(), m);
    }

    pub fn read_sv(&mut self, path: &str, blackbox: bool) -> Result<Vec<String>, String> {
        let src = std::fs::read_to_string(path).map_err(|e| format!("cannot read {}: {}", path, e))?;
        let pp = self.pre.run(&src, path, 0)?;
        lex::take_pragmas();
        let toks = lex::lex(&pp).map_err(|e| format!("{}: {}", path, e))?;
        let mut p = sv::Parser::new(toks, path, self.types.clone());
        let mods = p.parse_file();
        for pr in lex::take_pragmas() {
            self.pragmas.push((path.to_string(), pr));
        }
        let mods = mods?;
        self.types.extend(p.types.into_iter());
        let names: Vec<String> = mods.iter().map(|m| m.name.clone()).collect();
        for m in mods {
            self.add(m, blackbox && true);
        }
        Ok(names)
    }
    pub fn read_vhdl(&mut self, path: &str, blackbox: bool) -> Result<Vec<String>, String> {
        let src = std::fs::read_to_string(path).map_err(|e| format!("cannot read {}: {}", path, e))?;
        lex::take_pragmas();
        let mods = vhdl::parse_vhdl(&src, path);
        for pr in lex::take_pragmas() {
            self.pragmas.push((path.to_string(), pr));
        }
        let mods = mods?;
        let names: Vec<String> = mods.iter().map(|m| m.name.clone()).collect();
        for m in mods {
            self.add(m, blackbox);
        }
        Ok(names)
    }
    /// Candidate top modules = modules never instantiated by another.
    pub fn tops(&self) -> Vec<String> {
        let mut used = HashSet::new();
        fn walk(items: &[Item], used: &mut HashSet<String>) {
            for i in items {
                match i {
                    Item::Inst { module, .. } => {
                        used.insert(module.clone());
                    }
                    Item::GenFor { items, .. } | Item::GenBlock { items, .. } => walk(items, used),
                    Item::GenIf { then, els, .. } => {
                        walk(then, used);
                        walk(els, used)
                    }
                    Item::GenCase { items, default, .. } => {
                        for (_, it) in items {
                            walk(it, used)
                        }
                        walk(default, used)
                    }
                    _ => {}
                }
            }
        }
        for m in self.modules.values() {
            walk(&m.items, &mut used);
        }
        self.order.iter().filter(|n| !used.contains(*n) && self.modules[*n].kind == ModKind::Module && !self.modules[*n].blackbox).cloned().collect()
    }
}
