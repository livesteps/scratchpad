//! VHDL-93/2008 synthesizable-subset front-end. Lowers entities/architectures
//! into the common AST (so elaboration, optimization and mapping are shared).
//! Supported: entity generics/ports, std_logic(_vector), (un)signed, integer
//! ranges, enumeration types, constants, signals, concurrent assignments,
//! when/else, with/select, processes (clocked with sync/async reset, comb),
//! if/elsif/case/for-loop, component & entity instantiation, for/if-generate,
//! numeric_std conversions, aggregates (others => ..), component stubs (-> black boxes).

use super::ast::*;
use crate::netlist::Dir;

#[derive(Clone, Debug, PartialEq)]
enum V {
    Id(String),
    Num(String),
    Chr(char),
    Str(String),
    BStr(char, String),
    Sym(String),
    Eof,
}

fn lex(src: &str) -> Result<Vec<(V, usize)>, String> {
    let c: Vec<char> = src.chars().collect();
    let mut i = 0;
    let mut line = 1;
    let mut v: Vec<(V, usize)> = vec![];
    while i < c.len() {
        let ch = c[i];
        if ch == '\n' {
            line += 1;
            i += 1;
            continue;
        }
        if ch.is_whitespace() {
            i += 1;
            continue;
        }
        if ch == '-' && i + 1 < c.len() && c[i + 1] == '-' {
            let st = i + 2;
            while i < c.len() && c[i] != '\n' {
                i += 1
            }
            let text: String = c[st..i].iter().collect();
            if let Some(ps) = crate::hdl::lex::parse_pragma(&text) {
                crate::hdl::lex::PRAGMAS.with(|v| {
                    for (k, a) in &ps {
                        v.borrow_mut().push(crate::hdl::lex::Pragma { line, kind: k.clone(), args: a.clone() });
                    }
                });
                if ps.iter().any(|(k, _)| k == "translate_off") {
                    // skip to the matching "-- ... translate_on"
                    while i < c.len() {
                        if c[i] == '\n' {
                            line += 1;
                            i += 1;
                            continue;
                        }
                        if c[i] == '-' && i + 1 < c.len() && c[i + 1] == '-' {
                            let st2 = i + 2;
                            while i < c.len() && c[i] != '\n' {
                                i += 1;
                            }
                            let t2: String = c[st2..i].iter().collect();
                            if crate::hdl::lex::parse_pragma(&t2).map(|p| p.iter().any(|(k, _)| k == "translate_on")).unwrap_or(false) {
                                break;
                            }
                            continue;
                        }
                        i += 1;
                    }
                }
            }
            continue;
        }
        if ch == '\'' {
            let prev_name = matches!(v.last(), Some((V::Id(_), _)) | Some((V::Sym(_), _)) if matches!(&v.last().unwrap().0, V::Id(_)) || matches!(&v.last().unwrap().0, V::Sym(s) if s == ")"));
            if !prev_name && i + 2 < c.len() && c[i + 2] == '\'' {
                v.push((V::Chr(c[i + 1].to_ascii_lowercase()), line));
                i += 3;
                continue;
            }
            v.push((V::Sym("'".into()), line));
            i += 1;
            continue;
        }
        if ch == '"' {
            let mut s = String::new();
            i += 1;
            while i < c.len() && c[i] != '"' {
                s.push(c[i]);
                i += 1
            }
            i += 1;
            v.push((V::Str(s), line));
            continue;
        }
        if (ch == 'x' || ch == 'X' || ch == 'b' || ch == 'B' || ch == 'o' || ch == 'O') && i + 1 < c.len() && c[i + 1] == '"' {
            let mut s = String::new();
            i += 2;
            while i < c.len() && c[i] != '"' {
                if c[i] != '_' {
                    s.push(c[i])
                }
                i += 1
            }
            i += 1;
            v.push((V::BStr(ch.to_ascii_lowercase(), s), line));
            continue;
        }
        if ch.is_alphabetic() {
            let mut s = String::new();
            while i < c.len() && (c[i].is_alphanumeric() || c[i] == '_') {
                s.push(c[i].to_ascii_lowercase());
                i += 1
            }
            v.push((V::Id(s), line));
            continue;
        }
        if ch.is_ascii_digit() {
            let mut s = String::new();
            while i < c.len() && (c[i].is_ascii_digit() || c[i] == '_' || c[i] == '#' || c[i].is_ascii_hexdigit() && s.contains('#')) {
                if c[i] != '_' {
                    s.push(c[i])
                }
                i += 1
            }
            v.push((V::Num(s), line));
            continue;
        }
        let two: String = c[i..(i + 2).min(c.len())].iter().collect();
        if ["<=", "=>", ":=", "/=", ">=", "**"].contains(&two.as_str()) {
            v.push((V::Sym(two), line));
            i += 2;
            continue;
        }
        if "(),;:.&+-*/<>=|".contains(ch) {
            v.push((V::Sym(ch.to_string()), line));
            i += 1;
            continue;
        }
        return Err(format!("VHDL line {}: unexpected character '{}'", line, ch));
    }
    v.push((V::Eof, line));
    Ok(v)
}

struct P {
    t: Vec<(V, usize)>,
    i: usize,
    file: String,
}
type PR<T> = Result<T, String>;

impl P {
    fn pk(&self) -> &V {
        &self.t[self.i.min(self.t.len() - 1)].0
    }
    fn pk_at(&self, k: usize) -> &V {
        &self.t[(self.i + k).min(self.t.len() - 1)].0
    }
    fn line(&self) -> usize {
        self.t[self.i.min(self.t.len() - 1)].1
    }
    fn is(&self, s: &str) -> bool {
        matches!(self.pk(), V::Id(x) | V::Sym(x) if x == s)
    }
    fn is_at(&self, k: usize, s: &str) -> bool {
        matches!(self.pk_at(k), V::Id(x) | V::Sym(x) if x == s)
    }
    fn eat(&mut self, s: &str) -> bool {
        if self.is(s) {
            self.i += 1;
            true
        } else {
            false
        }
    }
    fn err<X>(&self, m: &str) -> PR<X> {
        Err(format!("{}:{}: VHDL syntax error: {} (near {:?})", self.file, self.line(), m, self.pk()))
    }
    fn expect(&mut self, s: &str) -> PR<()> {
        if self.eat(s) {
            Ok(())
        } else {
            self.err(&format!("expected '{}'", s))
        }
    }
    fn ident(&mut self) -> PR<String> {
        match self.pk().clone() {
            V::Id(s) => {
                self.i += 1;
                Ok(s)
            }
            _ => self.err("expected identifier"),
        }
    }
    fn skip_to(&mut self, s: &str) {
        while !matches!(self.pk(), V::Eof) && !self.is(s) {
            self.i += 1
        }
        self.eat(s);
    }
    fn end_clause(&mut self) {
        // after 'end': [keyword] [name] ;
        while !self.is(";") && !matches!(self.pk(), V::Eof) {
            self.i += 1
        }
        self.eat(";");
    }

    fn parse(&mut self) -> PR<Vec<Module>> {
        let mut ents: Vec<Module> = vec![];
        let mut out: Vec<Module> = vec![];
        let mut stubs: Vec<Module> = vec![];
        while !matches!(self.pk(), V::Eof) {
            if self.eat("library") || self.eat("use") || self.eat("context") {
                self.skip_to(";");
            } else if self.eat("entity") {
                ents.push(self.entity()?);
            } else if self.eat("architecture") {
                let _an = self.ident()?;
                self.expect("of")?;
                let en = self.ident()?;
                self.expect("is")?;
                let mut m = match ents.iter().position(|e| e.name == en) {
                    Some(k) => ents.remove(k),
                    None => return self.err(&format!("architecture for unknown entity {}", en)),
                };
                let mut items = std::mem::take(&mut m.items);
                self.decls(&mut items, &mut stubs)?;
                self.expect("begin")?;
                self.conc_list(&mut items, &["end"])?;
                self.expect("end")?;
                self.end_clause();
                m.items = items;
                out.push(m);
            } else if self.eat("package") {
                if self.eat("body") {
                    self.skip_to("end");
                    self.end_clause();
                    continue;
                }
                let name = self.ident()?;
                self.expect("is")?;
                let mut items = vec![];
                self.decls(&mut items, &mut stubs)?;
                self.expect("end")?;
                self.end_clause();
                out.push(Module { name, kind: ModKind::Package, params: vec![], ports: vec![], items, file: self.file.clone(), line: 1, blackbox: false, lang: "vhdl" });
            } else if self.eat("configuration") {
                self.skip_to("end");
                self.end_clause();
            } else {
                return self.err("expected design unit");
            }
        }
        // entities without architecture => empty modules
        out.extend(ents);
        for s in stubs {
            if !out.iter().any(|m| m.name == s.name) {
                out.push(s);
            }
        }
        Ok(out)
    }

    fn entity(&mut self) -> PR<Module> {
        let line = self.line();
        let name = self.ident()?;
        self.expect("is")?;
        let mut m = Module { name, kind: ModKind::Module, params: vec![], ports: vec![], items: vec![], file: self.file.clone(), line, blackbox: false, lang: "vhdl" };
        self.generics_ports(&mut m.params, &mut m.ports)?;
        while !self.is("end") && !self.is("begin") && !matches!(self.pk(), V::Eof) {
            self.i += 1;
        }
        if self.eat("begin") {
            self.skip_to("end");
            self.i -= 1;
        }
        self.expect("end")?;
        self.end_clause();
        Ok(m)
    }
    fn generics_ports(&mut self, params: &mut Vec<ParamDecl>, ports: &mut Vec<PortDecl>) -> PR<()> {
        if self.eat("generic") {
            self.expect("(")?;
            loop {
                self.eat("constant");
                let mut names = vec![self.ident()?];
                while self.eat(",") {
                    names.push(self.ident()?);
                }
                self.expect(":")?;
                let ty = self.dtype()?;
                let v = if self.eat(":=") { Some(self.expr()?) } else { None };
                for n in names {
                    params.push(ParamDecl { name: n, value: v.clone(), local: false, ty: Some(ty.clone()), unpacked: vec![] });
                }
                if !self.eat(";") {
                    break;
                }
            }
            self.expect(")")?;
            self.expect(";")?;
        }
        if self.eat("port") {
            self.expect("(")?;
            loop {
                self.eat("signal");
                let mut names = vec![self.ident()?];
                while self.eat(",") {
                    names.push(self.ident()?);
                }
                self.expect(":")?;
                let dir = if self.eat("in") {
                    Dir::In
                } else if self.eat("out") || self.eat("buffer") {
                    Dir::Out
                } else if self.eat("inout") {
                    Dir::InOut
                } else {
                    Dir::In
                };
                let ty = self.dtype()?;
                if self.eat(":=") {
                    self.expr()?;
                }
                for n in names {
                    ports.push(PortDecl { name: n, dir: Some(dir), ty: ty.clone(), unpacked: vec![], iface: None });
                }
                if !self.eat(";") {
                    break;
                }
            }
            self.expect(")")?;
            self.expect(";")?;
        }
        Ok(())
    }
    fn dtype(&mut self) -> PR<DType> {
        let n = self.ident()?;
        if self.eat(".") {
            // work.pkg.type
            return self.dtype();
        }
        Ok(match n.as_str() {
            "std_logic" | "std_ulogic" | "bit" | "boolean" => DType::bit(),
            "std_logic_vector" | "std_ulogic_vector" | "unsigned" | "signed" | "bit_vector" => {
                let signed = n == "signed";
                let mut packed = vec![];
                if self.eat("(") {
                    let a = self.expr()?;
                    let up = self.eat("to");
                    if !up {
                        self.expect("downto")?;
                    }
                    let b = self.expr()?;
                    self.expect(")")?;
                    packed.push((a, b));
                }
                DType::Logic { signed, packed }
            }
            "integer" | "natural" | "positive" => {
                if self.eat("range") {
                    let a = self.expr()?;
                    let up = self.eat("to");
                    if !up {
                        self.expect("downto")?;
                    }
                    let b = self.expr()?;
                    let hi = if up { b } else { a };
                    // width = clog2(hi+1)
                    let w = Expr::Call("$clog2".into(), vec![Expr::bin("+", hi, Expr::int(1))]);
                    return Ok(DType::Logic { signed: false, packed: vec![(Expr::bin("-", Expr::Call("$max1".into(), vec![w]), Expr::int(1)), Expr::int(0))] });
                }
                DType::int32()
            }
            _ => DType::Named { name: n, packed: vec![] },
        })
    }

    fn decls(&mut self, items: &mut Vec<Item>, stubs: &mut Vec<Module>) -> PR<()> {
        loop {
            let line = self.line();
            if self.eat("signal") || self.eat("variable") || self.eat("shared") {
                self.eat("variable");
                let mut names = vec![self.ident()?];
                while self.eat(",") {
                    names.push(self.ident()?);
                }
                self.expect(":")?;
                let ty = self.dtype()?;
                let init = if self.eat(":=") { Some(self.expr()?) } else { None };
                self.expect(";")?;
                for n in names {
                    items.push(Item::Decl(Decl { name: n, ty: ty.clone(), unpacked: vec![], init: init.clone(), dir: None, line, net: false }));
                }
            } else if self.eat("constant") {
                let mut names = vec![self.ident()?];
                while self.eat(",") {
                    names.push(self.ident()?);
                }
                self.expect(":")?;
                let ty = self.dtype()?;
                self.expect(":=")?;
                let v = self.expr()?;
                self.expect(";")?;
                for n in names {
                    items.push(Item::Param(ParamDecl { name: n, value: Some(v.clone()), local: true, ty: Some(ty.clone()), unpacked: vec![] }));
                }
            } else if self.eat("type") {
                let name = self.ident()?;
                self.expect("is")?;
                if self.eat("(") {
                    let mut it = vec![];
                    loop {
                        it.push((self.ident()?, None));
                        if !self.eat(",") {
                            break;
                        }
                    }
                    self.expect(")")?;
                    self.expect(";")?;
                    let n = it.len().max(2) as f64;
                    let w = n.log2().ceil() as i64;
                    items.push(Item::Typedef(name, DType::Enum { base: Box::new(DType::vec(w - 1, 0)), items: it }));
                } else {
                    crate::warn!("VHDL-101", "{}:{}: unsupported type definition '{}' ignored", self.file, line, name);
                    self.skip_to(";");
                }
            } else if self.eat("subtype") {
                let name = self.ident()?;
                self.expect("is")?;
                let ty = self.dtype()?;
                self.expect(";")?;
                items.push(Item::Typedef(name, ty));
            } else if self.eat("component") {
                let name = self.ident()?;
                self.eat("is");
                let mut m = Module { name, kind: ModKind::Module, params: vec![], ports: vec![], items: vec![], file: self.file.clone(), line, blackbox: true, lang: "vhdl" };
                self.generics_ports(&mut m.params, &mut m.ports)?;
                self.expect("end")?;
                self.end_clause();
                stubs.push(m);
            } else if self.eat("attribute") || self.eat("alias") || self.eat("file") {
                self.skip_to(";");
            } else if self.eat("function") || self.eat("procedure") || self.eat("impure") || self.eat("pure") {
                crate::warn!("VHDL-102", "{}:{}: subprogram declarations are not supported; skipped", self.file, line);
                // skip to matching "end function/procedure;"
                let mut depth = 0;
                while !matches!(self.pk(), V::Eof) {
                    if self.is("begin") {
                        depth += 1
                    }
                    if self.is("end") {
                        self.i += 1;
                        if depth <= 1 && (self.is("function") || self.is("procedure") || matches!(self.pk(), V::Id(_)) || self.is(";")) {
                            self.end_clause();
                            break;
                        }
                        depth -= 1;
                        continue;
                    }
                    if self.is(";") && depth == 0 {
                        self.i += 1;
                        break;
                    }
                    self.i += 1;
                }
            } else {
                return Ok(());
            }
        }
    }

    fn conc_list(&mut self, items: &mut Vec<Item>, ends: &[&str]) -> PR<()> {
        while !ends.iter().any(|e| self.is(e)) && !matches!(self.pk(), V::Eof) {
            self.conc(items)?;
        }
        Ok(())
    }
    fn conc(&mut self, items: &mut Vec<Item>) -> PR<()> {
        let line = self.line();
        let mut label = None;
        if matches!(self.pk(), V::Id(_)) && self.is_at(1, ":") {
            label = Some(self.ident()?);
            self.i += 1;
        }
        if self.eat("process") {
            let mut sens = vec![];
            if self.eat("(") {
                while !self.is(")") {
                    sens.push(self.expr()?);
                    if !self.eat(",") {
                        break;
                    }
                }
                self.expect(")")?;
            }
            self.eat("is");
            let mut dummy = vec![];
            let mut locals = vec![];
            self.decls(&mut locals, &mut dummy)?;
            self.expect("begin")?;
            let body = self.seq_list(&["end"])?;
            self.expect("end")?;
            self.end_clause();
            for l in locals {
                items.push(l);
            }
            items.push(self.lower_process(body, line)?);
            return Ok(());
        }
        if self.eat("for") {
            let var = self.ident()?;
            self.expect("in")?;
            let a = self.expr()?;
            let up = self.eat("to");
            if !up {
                self.expect("downto")?;
            }
            let b = self.expr()?;
            self.expect("generate")?;
            if self.eat("begin") {}
            let mut body = vec![];
            self.conc_list(&mut body, &["end"])?;
            self.expect("end")?;
            self.end_clause();
            let (init, cond, step) = if up {
                (a, Expr::bin("<=", Expr::id(&var), b), Expr::bin("+", Expr::id(&var), Expr::int(1)))
            } else {
                (a, Expr::bin(">=", Expr::id(&var), b), Expr::bin("-", Expr::id(&var), Expr::int(1)))
            };
            items.push(Item::GenFor { var, init, cond, step, label, items: body });
            return Ok(());
        }
        if self.is("if") && !self.is_at(1, "(") || (self.is("if") && self.gen_if_ahead()) {
            self.i += 1;
            let c = self.expr()?;
            self.expect("generate")?;
            let mut body = vec![];
            self.conc_list(&mut body, &["end", "else", "elsif"])?;
            let mut els = vec![];
            if self.eat("else") {
                self.eat("generate");
                self.conc_list(&mut els, &["end"])?;
            }
            self.expect("end")?;
            self.end_clause();
            items.push(Item::GenIf { cond: c, then: body, els });
            return Ok(());
        }
        if self.eat("with") {
            let sel = self.expr()?;
            self.expect("select")?;
            let tgt = self.name()?;
            self.expect("<=")?;
            let mut alts: Vec<(Expr, Option<Vec<Expr>>)> = vec![];
            loop {
                let v = self.expr()?;
                self.expect("when")?;
                if self.eat("others") {
                    alts.push((v, None));
                } else {
                    let mut cs = vec![self.expr()?];
                    while self.eat("|") {
                        cs.push(self.expr()?);
                    }
                    alts.push((v, Some(cs)));
                }
                if !self.eat(",") {
                    break;
                }
            }
            self.expect(";")?;
            let mut e = alts.iter().find(|a| a.1.is_none()).map(|a| a.0.clone()).unwrap_or(Expr::Num { width: None, bits: vec![0], signed: false, fill: true });
            for (v, cs) in alts.iter().rev() {
                if let Some(cs) = cs {
                    let mut cond = Expr::bin("==", sel.clone(), cs[0].clone());
                    for c in &cs[1..] {
                        cond = Expr::bin("||", cond, Expr::bin("==", sel.clone(), c.clone()));
                    }
                    e = Expr::Cond(Box::new(cond), Box::new(v.clone()), Box::new(e));
                }
            }
            items.push(Item::Assign(tgt, e, line));
            return Ok(());
        }
        if self.eat("assert") {
            self.skip_to(";");
            return Ok(());
        }
        // instantiation
        if label.is_some() && (self.is("entity") || self.is("component") || (matches!(self.pk(), V::Id(_)) && (self.is_at(1, "port") || self.is_at(1, "generic")))) {
            if self.eat("entity") {
                let mut n = self.ident()?;
                while self.eat(".") {
                    n = self.ident()?;
                }
                if self.eat("(") {
                    self.ident()?;
                    self.expect(")")?;
                }
                return self.inst_rest(items, n, label.unwrap(), line);
            }
            self.eat("component");
            let n = self.ident()?;
            return self.inst_rest(items, n, label.unwrap(), line);
        }
        // concurrent signal assignment
        let tgt = self.name()?;
        self.expect("<=")?;
        let mut v = self.expr()?;
        if self.is("when") {
            let mut parts = vec![];
            while self.eat("when") {
                let c = self.expr()?;
                parts.push((v.clone(), c));
                self.expect("else")?;
                v = self.expr()?;
            }
            for (val, c) in parts.into_iter().rev() {
                v = Expr::Cond(Box::new(c), Box::new(val), Box::new(v));
            }
        }
        self.expect(";")?;
        items.push(Item::Assign(tgt, v, line));
        Ok(())
    }
    fn gen_if_ahead(&self) -> bool {
        let mut k = 1;
        loop {
            match self.pk_at(k) {
                V::Id(s) if s == "generate" => return true,
                V::Sym(s) if s == ";" => return false,
                V::Id(s) if s == "then" => return false,
                V::Eof => return false,
                _ => {}
            }
            k += 1;
        }
    }
    fn inst_rest(&mut self, items: &mut Vec<Item>, module: String, name: String, line: usize) -> PR<()> {
        let mut params = vec![];
        let mut conns = vec![];
        if self.eat("generic") {
            self.expect("map")?;
            for (n, e) in self.assoc()? {
                if let Some(e) = e {
                    params.push((n, e));
                }
            }
        }
        if self.eat("port") {
            self.expect("map")?;
            conns = self.assoc()?;
        }
        self.expect(";")?;
        items.push(Item::Inst { module, params, name, range: None, conns, wildcard: false, line });
        Ok(())
    }
    fn assoc(&mut self) -> PR<Vec<(Option<String>, Option<Expr>)>> {
        self.expect("(")?;
        let mut v = vec![];
        while !self.is(")") {
            if matches!(self.pk(), V::Id(_)) && self.is_at(1, "=>") {
                let n = self.ident()?;
                self.i += 1;
                if self.eat("open") {
                    v.push((Some(n), None));
                } else {
                    v.push((Some(n), Some(self.expr()?)));
                }
            } else if self.eat("open") {
                v.push((None, None));
            } else {
                v.push((None, Some(self.expr()?)));
            }
            if !self.eat(",") {
                break;
            }
        }
        self.expect(")")?;
        Ok(v)
    }

    fn lower_process(&self, body: Vec<Stmt>, line: usize) -> PR<Item> {
        // detect clocked processes
        fn edge_of(e: &Expr) -> Option<(Edge, Expr)> {
            match e {
                Expr::Call(n, a) if n == "rising_edge" && a.len() == 1 => Some((Edge::Pos, a[0].clone())),
                Expr::Call(n, a) if n == "falling_edge" && a.len() == 1 => Some((Edge::Neg, a[0].clone())),
                Expr::Bin(op, a, b) if op == "&&" || op == "&" => {
                    // clk'event and clk = '1'
                    if let (Expr::Call(n, x), Expr::Bin(eq, c, v)) = (&**a, &**b) {
                        if n == "'event" && eq == "==" {
                            let one = matches!(&**v, Expr::Num{bits,..} if bits.first()==Some(&1));
                            let _ = c;
                            return Some((if one { Edge::Pos } else { Edge::Neg }, x[0].clone()));
                        }
                    }
                    None
                }
                _ => None,
            }
        }
        if body.len() == 1 {
            if let Stmt::If(c, t, e) = &body[0] {
                if let Some((ed, clk)) = edge_of(c) {
                    return Ok(Item::Always { kind: AKind::Ff, sens: vec![(ed, clk)], body: (**t).clone(), line });
                }
                if let Some(eb) = e {
                    if let Stmt::If(c2, t2, None) = &**eb {
                        if let Some((ed, clk)) = edge_of(c2) {
                            // async reset: if (rst_cond) A elsif edge B
                            return Ok(Item::Always { kind: AKind::Ff, sens: vec![(ed, clk), (Edge::Any, c.clone())], body: Stmt::If(c.clone(), t.clone(), Some(t2.clone())), line });
                        }
                    }
                }
            }
        }
        Ok(Item::Always { kind: AKind::Comb, sens: vec![], body: Stmt::Block(body), line })
    }

    fn seq_list(&mut self, ends: &[&str]) -> PR<Vec<Stmt>> {
        let mut v = vec![];
        while !ends.iter().any(|e| self.is(e)) && !matches!(self.pk(), V::Eof) {
            v.push(self.seq()?);
        }
        Ok(v)
    }
    fn seq(&mut self) -> PR<Stmt> {
        if matches!(self.pk(), V::Id(_)) && self.is_at(1, ":") && !self.is_at(1, ":=") {
            self.i += 2;
        }
        if self.eat("if") {
            let c = self.expr()?;
            self.expect("then")?;
            let t = self.seq_list(&["elsif", "else", "end"])?;
            let e = if self.is("elsif") {
                self.i += 1;
                self.i -= 1;
                // rewrite elsif as nested if
                self.t[self.i].0 = V::Id("if".into());
                let s = self.seq_elsif()?;
                return Ok(Stmt::If(c, Box::new(Stmt::Block(t)), Some(Box::new(s))));
            } else if self.eat("else") {
                Some(Box::new(Stmt::Block(self.seq_list(&["end"])?)))
            } else {
                None
            };
            self.expect("end")?;
            self.expect("if")?;
            self.end_clause();
            return Ok(Stmt::If(c, Box::new(Stmt::Block(t)), e));
        }
        if self.eat("case") {
            let sel = self.expr()?;
            self.expect("is")?;
            let mut items = vec![];
            let mut default = None;
            while self.eat("when") {
                if self.eat("others") {
                    self.expect("=>")?;
                    default = Some(Box::new(Stmt::Block(self.seq_list(&["when", "end"])?)));
                    continue;
                }
                let mut cs = vec![self.expr()?];
                while self.eat("|") {
                    cs.push(self.expr()?);
                }
                self.expect("=>")?;
                items.push((cs, Stmt::Block(self.seq_list(&["when", "end"])?)));
            }
            self.expect("end")?;
            self.end_clause();
            return Ok(Stmt::Case { kind: 0, sel, items, default, inside: false, full: false, parallel: false, line: 0 });
        }
        if self.eat("for") {
            let var = self.ident()?;
            self.expect("in")?;
            let a = self.expr()?;
            let up = self.eat("to");
            if !up {
                self.expect("downto")?;
            }
            let b = self.expr()?;
            self.expect("loop")?;
            let body = self.seq_list(&["end"])?;
            self.expect("end")?;
            self.end_clause();
            let (cond, step) = if up {
                (Expr::bin("<=", Expr::id(&var), b), Expr::bin("+", Expr::id(&var), Expr::int(1)))
            } else {
                (Expr::bin(">=", Expr::id(&var), b), Expr::bin("-", Expr::id(&var), Expr::int(1)))
            };
            return Ok(Stmt::For { var: var.clone(), init: a, cond, step: Box::new(Stmt::Asgn { lhs: Expr::Id(var), rhs: step, blocking: true }), body: Box::new(Stmt::Block(body)) });
        }
        if self.eat("null") {
            self.expect(";")?;
            return Ok(Stmt::Null);
        }
        if self.eat("report") || self.eat("assert") {
            self.skip_to(";");
            return Ok(Stmt::Null);
        }
        if self.is("wait") || self.is("while") {
            return self.err("'wait'/'while' not supported for synthesis");
        }
        let lhs = self.name()?;
        let blocking = if self.eat(":=") {
            true
        } else {
            self.expect("<=")?;
            false
        };
        let rhs = self.expr()?;
        self.expect(";")?;
        Ok(Stmt::Asgn { lhs, rhs, blocking })
    }
    fn seq_elsif(&mut self) -> PR<Stmt> {
        // token at i is now "if" (rewritten elsif); parse a nested if that shares the outer 'end if'
        self.expect("if")?;
        let c = self.expr()?;
        self.expect("then")?;
        let t = self.seq_list(&["elsif", "else", "end"])?;
        let e = if self.is("elsif") {
            self.t[self.i].0 = V::Id("if".into());
            Some(Box::new(self.seq_elsif()?))
        } else if self.eat("else") {
            let b = self.seq_list(&["end"])?;
            self.expect("end")?;
            self.expect("if")?;
            self.end_clause();
            return Ok(Stmt::If(c, Box::new(Stmt::Block(t)), Some(Box::new(Stmt::Block(b)))));
        } else {
            self.expect("end")?;
            self.expect("if")?;
            self.end_clause();
            None
        };
        if e.is_some() {
            return Ok(Stmt::If(c, Box::new(Stmt::Block(t)), e));
        }
        Ok(Stmt::If(c, Box::new(Stmt::Block(t)), None))
    }

    // ---------------------------------------------------------- expressions
    fn expr(&mut self) -> PR<Expr> {
        let mut l = self.rel()?;
        loop {
            let op = match self.pk() {
                V::Id(s) if ["and", "or", "xor", "nand", "nor", "xnor"].contains(&s.as_str()) => s.clone(),
                _ => return Ok(l),
            };
            self.i += 1;
            let r = self.rel()?;
            l = match op.as_str() {
                "and" => Expr::bin("&", l, r),
                "or" => Expr::bin("|", l, r),
                "xor" => Expr::bin("^", l, r),
                "nand" => Expr::un("~", Expr::bin("&", l, r)),
                "nor" => Expr::un("~", Expr::bin("|", l, r)),
                _ => Expr::un("~", Expr::bin("^", l, r)),
            };
        }
    }
    fn rel(&mut self) -> PR<Expr> {
        let l = self.shift()?;
        for (s, o) in [("=", "=="), ("/=", "!="), ("<=", "<="), (">=", ">="), ("<", "<"), (">", ">")] {
            if self.is(s) {
                // '<=' at statement level is assignment; rel() is only called inside expressions
                self.i += 1;
                let r = self.shift()?;
                return Ok(Expr::bin(o, l, r));
            }
        }
        Ok(l)
    }
    fn shift(&mut self) -> PR<Expr> {
        let l = self.add()?;
        for (s, o) in [("sll", "<<"), ("srl", ">>"), ("sla", "<<<"), ("sra", ">>>")] {
            if self.eat(s) {
                let r = self.add()?;
                return Ok(Expr::bin(o, l, r));
            }
        }
        Ok(l)
    }
    fn add(&mut self) -> PR<Expr> {
        let mut l = self.mul()?;
        loop {
            if self.eat("+") {
                l = Expr::bin("+", l, self.mul()?)
            } else if self.eat("-") {
                l = Expr::bin("-", l, self.mul()?)
            } else if self.eat("&") {
                let r = self.mul()?;
                l = match l {
                    Expr::Concat(mut v) => {
                        v.push(r);
                        Expr::Concat(v)
                    }
                    x => Expr::Concat(vec![x, r]),
                }
            } else {
                return Ok(l);
            }
        }
    }
    fn mul(&mut self) -> PR<Expr> {
        let mut l = self.un()?;
        loop {
            if self.eat("*") {
                l = Expr::bin("*", l, self.un()?)
            } else if self.eat("/") {
                l = Expr::bin("/", l, self.un()?)
            } else if self.eat("mod") || self.eat("rem") {
                l = Expr::bin("%", l, self.un()?)
            } else if self.eat("**") {
                l = Expr::bin("**", l, self.un()?)
            } else {
                return Ok(l);
            }
        }
    }
    fn un(&mut self) -> PR<Expr> {
        if self.eat("not") {
            return Ok(Expr::un("~", self.un()?));
        }
        if self.eat("-") {
            return Ok(Expr::un("-", self.un()?));
        }
        if self.eat("abs") {
            return self.un();
        }
        self.prim()
    }
    fn prim(&mut self) -> PR<Expr> {
        match self.pk().clone() {
            V::Chr(c) => {
                self.i += 1;
                Ok(Expr::Num { width: Some(1), bits: vec![if c == '1' || c == 'h' { 1 } else if c == '0' || c == 'l' { 0 } else { 2 }], signed: false, fill: false })
            }
            V::Str(s) => {
                self.i += 1;
                let bits: Vec<u8> = s.chars().rev().filter(|c| *c != '_').map(|c| match c {
                    '1' => 1,
                    '0' => 0,
                    '-' => 3,
                    _ => 2,
                }).collect();
                Ok(Expr::Num { width: Some(bits.len() as u32), bits, signed: false, fill: false })
            }
            V::BStr(b, s) => {
                self.i += 1;
                let bpd = match b {
                    'x' => 4,
                    'o' => 3,
                    _ => 1,
                };
                let mut bits = vec![];
                for ch in s.chars().rev() {
                    let v = ch.to_digit(16).unwrap_or(0);
                    for k in 0..bpd {
                        bits.push(((v >> k) & 1) as u8);
                    }
                }
                Ok(Expr::Num { width: Some(bits.len() as u32), bits, signed: false, fill: false })
            }
            V::Num(s) => {
                self.i += 1;
                let v: i64 = if let Some((b, d)) = s.split_once('#') {
                    i64::from_str_radix(d.trim_end_matches('#'), b.parse().unwrap_or(10)).unwrap_or(0)
                } else {
                    s.parse().unwrap_or(0)
                };
                Ok(Expr::int(v))
            }
            V::Sym(s) if s == "(" => {
                self.i += 1;
                if self.eat("others") {
                    self.expect("=>")?;
                    let e = self.expr()?;
                    self.expect(")")?;
                    return Ok(Expr::Fill(Box::new(e)));
                }
                let e = self.expr()?;
                if self.eat(",") {
                    let mut v = vec![e];
                    loop {
                        v.push(self.expr()?);
                        if !self.eat(",") {
                            break;
                        }
                    }
                    self.expect(")")?;
                    return Ok(Expr::Concat(v));
                }
                self.expect(")")?;
                Ok(e)
            }
            V::Id(_) => self.name(),
            _ => self.err("expected expression"),
        }
    }
    fn name(&mut self) -> PR<Expr> {
        let n = self.ident()?;
        if n == "true" {
            return Ok(Expr::Num { width: Some(1), bits: vec![1], signed: false, fill: false });
        }
        if n == "false" {
            return Ok(Expr::Num { width: Some(1), bits: vec![0], signed: false, fill: false });
        }
        let mut e = Expr::Id(n.clone());
        loop {
            if self.is("(") {
                self.i += 1;
                let a = self.expr()?;
                if self.eat("downto") || self.eat("to") {
                    let b = self.expr()?;
                    self.expect(")")?;
                    e = Expr::Range(Box::new(e), Box::new(a), Box::new(b));
                    continue;
                }
                let mut args = vec![a];
                while self.eat(",") {
                    args.push(self.expr()?);
                }
                self.expect(")")?;
                e = match (&e, n.as_str()) {
                    (Expr::Id(_), "rising_edge" | "falling_edge") => Expr::Call(n.clone(), args),
                    (Expr::Id(_), "std_logic_vector" | "unsigned" | "std_ulogic_vector" | "to_integer" | "conv_integer" | "to_stdlogicvector" | "to_bitvector") => args.remove(0),
                    (Expr::Id(_), "signed") => Expr::Call("$signed".into(), args),
                    (Expr::Id(_), "to_unsigned" | "to_signed" | "conv_std_logic_vector" | "resize") => Expr::Cast(Box::new(args[1].clone()), Box::new(args[0].clone())),
                    (Expr::Id(_), "shift_left") => Expr::bin("<<", args[0].clone(), args[1].clone()),
                    (Expr::Id(_), "shift_right") => Expr::bin(">>", args[0].clone(), args[1].clone()),
                    _ => Expr::Index(Box::new(e), Box::new(args.remove(0))),
                };
            } else if self.is("'") {
                self.i += 1;
                let a = self.ident()?;
                e = match a.as_str() {
                    "event" => Expr::Call("'event".into(), vec![e]),
                    "length" => Expr::Call("$bits".into(), vec![e]),
                    "high" | "left" => Expr::bin("-", Expr::Call("$bits".into(), vec![e]), Expr::int(1)),
                    "low" | "right" => Expr::int(0),
                    _ => return self.err(&format!("unsupported attribute '{}", a)),
                };
            } else if self.is(".") {
                self.i += 1;
                let m = self.ident()?;
                e = if m == "all" { e } else { Expr::Member(Box::new(e), m) };
            } else {
                return Ok(e);
            }
        }
    }
}

pub fn parse_vhdl(src: &str, file: &str) -> Result<Vec<Module>, String> {
    let t = lex(src)?;
    let mut p = P { t, i: 0, file: file.into() };
    p.parse()
}
