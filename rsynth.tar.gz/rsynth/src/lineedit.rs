//! Interactive line editor for the rsynth shell (std only; terminal mode via `stty`).
//!
//! Emacs keys: ^A/Home start, ^E/End end, ^B/^F/arrows move, Alt-B/Alt-F word move,
//! ^K kill to end, ^U kill to start, ^W kill word back, Alt-D kill word forward, ^Y yank,
//! ^T transpose, ^D delete (EOF on an empty line), ^H/Backspace, Delete, ^L clear screen,
//! ^P/^N/Up/Down history, ^R reverse history search, ^C cancel line, ^G abort search.
//! Tab: complete commands, command options (-opt), $variables and file names; a second
//! Tab lists the candidates.

use std::io::{Read, Write};

pub struct Editor {
    pub history: Vec<String>,
    hist_file: Option<std::path::PathBuf>,
    kill: String,
}

/// completion request: whole line and cursor (char index); returns (start of the word, candidates)
pub type Completer<'a> = dyn FnMut(&str, usize) -> (usize, Vec<String>) + 'a;

fn stty(args: &[&str]) -> Option<String> {
    let tty = std::fs::File::open("/dev/tty").ok()?;
    let o = std::process::Command::new("stty").args(args).stdin(tty).output().ok()?;
    if o.status.success() { Some(String::from_utf8_lossy(&o.stdout).trim().to_string()) } else { None }
}

fn term_width() -> usize {
    stty(&["size"]).and_then(|s| s.split_whitespace().nth(1).and_then(|w| w.parse().ok())).unwrap_or(100)
}

/// raw terminal mode on stdin: termios directly on Linux (every control key, ^D included, reaches the
/// editor as a byte), `stty` elsewhere / as a fallback
#[cfg(target_os = "linux")]
mod term {
    #[repr(C)]
    #[derive(Clone, Copy)]
    pub struct Termios { pub iflag: u32, pub oflag: u32, pub cflag: u32, pub lflag: u32, pub line: u8, pub cc: [u8; 32], pub ispeed: u32, pub ospeed: u32 }
    extern "C" {
        fn tcgetattr(fd: i32, t: *mut Termios) -> i32;
        fn tcsetattr(fd: i32, act: i32, t: *const Termios) -> i32;
        fn isatty(fd: i32) -> i32;
    }
    pub fn raw() -> Option<Termios> {
        unsafe {
            if isatty(0) != 1 { return None; }
            let mut t: Termios = std::mem::zeroed();
            if tcgetattr(0, &mut t) != 0 { return None; }
            let saved = t;
            // ICANON ECHO ISIG IEXTEN off; IXON ICRNL off; VMIN 1 VTIME 0
            t.lflag &= !(0o000002 | 0o000010 | 0o000001 | 0o100000);
            t.iflag &= !(0o002000 | 0o000400);
            t.cc[6] = 1;
            t.cc[5] = 0;
            if tcsetattr(0, 0, &t) != 0 { return None; }
            Some(saved)
        }
    }
    pub fn restore(t: &Termios) { unsafe { tcsetattr(0, 0, t); } }
}

struct Raw(Option<String>, #[cfg(target_os = "linux")] Option<term::Termios>);
impl Raw {
    fn on() -> Raw {
        #[cfg(target_os = "linux")]
        if let Some(t) = term::raw() { return Raw(Some(String::new()), Some(t)); }
        let saved = stty(&["-g"]);
        if saved.is_some() {
            let _ = stty(&["-icanon", "-echo", "-isig", "-ixon", "-icrnl", "-iexten", "min", "1", "time", "0"]);
        }
        Raw(saved, #[cfg(target_os = "linux")] None)
    }
}
impl Drop for Raw {
    fn drop(&mut self) {
        #[cfg(target_os = "linux")]
        if let Some(t) = &self.1 { term::restore(t); return; }
        if let Some(s) = &self.0 { let _ = stty(&[s.as_str()]); }
    }
}

/// common prefix of the candidates
pub fn common_prefix(v: &[String]) -> String {
    let Some(f) = v.first() else { return String::new() };
    let mut n = f.chars().count();
    for s in &v[1..] {
        n = n.min(f.chars().zip(s.chars()).take_while(|(a, b)| a == b).count());
    }
    f.chars().take(n).collect()
}

fn is_word(c: char) -> bool {
    c.is_alphanumeric() || c == '_'
}

impl Editor {
    pub fn new() -> Editor {
        let hist_file = std::env::var_os("HOME").map(|h| std::path::Path::new(&h).join(".rsynth_history"));
        let history = hist_file.as_ref().and_then(|f| std::fs::read_to_string(f).ok())
            .map(|t| t.lines().map(|l| l.to_string()).filter(|l| !l.is_empty()).collect()).unwrap_or_default();
        Editor { history, hist_file, kill: String::new() }
    }

    pub fn add_history(&mut self, line: &str) {
        let l = line.trim_end().to_string();
        if l.is_empty() || self.history.last() == Some(&l) { return; }
        self.history.push(l.clone());
        if self.history.len() > 2000 { self.history.drain(..self.history.len() - 2000); }
        if let Some(f) = &self.hist_file {
            if let Ok(mut fh) = std::fs::OpenOptions::new().create(true).append(true).open(f) {
                let _ = writeln!(fh, "{}", l.replace('\n', " "));
            }
        }
    }

    /// read one line; None on EOF (^D on an empty line)
    pub fn read_line(&mut self, prompt: &str, comp: &mut Completer) -> Option<String> {
        let _raw = Raw::on();
        if _raw.0.is_none() {
            // no terminal control: plain read
            print!("{}", prompt);
            let _ = std::io::stdout().flush();
            let mut s = String::new();
            return if std::io::stdin().read_line(&mut s).unwrap_or(0) == 0 { None } else { Some(s.trim_end_matches(['\n', '\r']).to_string()) };
        }
        let mut line: Vec<char> = vec![];
        let mut cur = 0usize;
        let mut hpos = self.history.len();
        let mut saved_line: Vec<char> = vec![];
        let mut last_tab = false;
        let mut out = std::io::stdout();
        let mut inp = std::io::stdin();
        let mut prev_rows = 0usize; // wrapped rows of the previous render below the prompt row
        let width = term_width().max(20);
        let plen = prompt.chars().count();
        let mut search: Option<(String, usize)> = None; // (pattern, history index)
        let render = |out: &mut std::io::Stdout, line: &[char], cur: usize, prompt: &str, prev_rows: &mut usize| {
            // move to the start of the prompt row, clear to the end of the screen, redraw
            let mut s = String::new();
            if *prev_rows > 0 { s += &format!("\x1b[{}A", prev_rows); }
            s += "\r\x1b[J";
            s += prompt;
            let txt: String = line.iter().collect();
            s += &txt;
            let total = plen + line.len();
            let end_row = total / width;
            // when the text ends exactly at the margin the cursor stays on the last column
            if total > 0 && total % width == 0 { s += " \r"; }
            let crow = (plen + cur) / width;
            let ccol = (plen + cur) % width;
            let rows_now = end_row;
            if rows_now > crow { s += &format!("\x1b[{}A", rows_now - crow); }
            s += &format!("\r{}", if ccol > 0 { format!("\x1b[{}C", ccol) } else { String::new() });
            *prev_rows = crow;
            let _ = out.write_all(s.as_bytes());
            let _ = out.flush();
        };
        render(&mut out, &line, cur, prompt, &mut prev_rows);
        let mut buf = [0u8; 1];
        let mut utf: Vec<u8> = vec![];
        loop {
            if inp.read(&mut buf).unwrap_or(0) == 0 {
                return None;
            }
            let b = buf[0];
            // ---- reverse incremental search
            if let Some((pat, idx)) = search.as_mut() {
                match b {
                    0x12 => { // ^R: next older match
                        let start = (*idx).min(self.history.len());
                        if let Some(i) = (0..start).rev().find(|i| self.history[*i].contains(pat.as_str())) { *idx = i; }
                    }
                    0x7f | 0x08 => { pat.pop(); }
                    0x07 | 0x03 => { // ^G / ^C: abort
                        search = None;
                        line = saved_line.clone();
                        cur = line.len();
                        render(&mut out, &line, cur, prompt, &mut prev_rows);
                        continue;
                    }
                    c if c >= 0x20 && c < 0x7f => {
                        pat.push(c as char);
                        let start = (*idx + 1).min(self.history.len());
                        if !self.history.get(*idx).map(|h| h.contains(pat.as_str())).unwrap_or(false) {
                            if let Some(i) = (0..start).rev().find(|i| self.history[*i].contains(pat.as_str())) { *idx = i; }
                        }
                    }
                    _ => {
                        // accept the match and handle the key normally
                        if let Some(h) = self.history.get(*idx) { if h.contains(pat.as_str()) { line = h.chars().collect(); cur = line.len(); } }
                        search = None;
                        if b == b'\r' || b == b'\n' {
                            render(&mut out, &line, cur, prompt, &mut prev_rows);
                            let _ = out.write_all(b"\r\n");
                            return Some(line.iter().collect());
                        }
                        render(&mut out, &line, cur, prompt, &mut prev_rows);
                        continue;
                    }
                }
                if let Some((pat, idx)) = search.as_ref() {
                    let m = self.history.get(*idx).filter(|h| h.contains(pat.as_str())).cloned().unwrap_or_default();
                    let sp = format!("(reverse-i-search)`{}': ", pat);
                    let disp: Vec<char> = m.chars().collect();
                    render(&mut out, &disp, disp.len(), &sp, &mut prev_rows);
                }
                continue;
            }
            let was_tab = last_tab;
            last_tab = false;
            match b {
                b'\r' | b'\n' => {
                    cur = line.len();
                    render(&mut out, &line, cur, prompt, &mut prev_rows);
                    let _ = out.write_all(b"\r\n");
                    let _ = out.flush();
                    return Some(line.iter().collect());
                }
                0x01 => cur = 0,                                   // ^A
                0x05 => cur = line.len(),                          // ^E
                0x02 => cur = cur.saturating_sub(1),               // ^B
                0x06 => cur = (cur + 1).min(line.len()),           // ^F
                0x0b => { self.kill = line[cur..].iter().collect(); line.truncate(cur); } // ^K
                0x15 => { self.kill = line[..cur].iter().collect(); line.drain(..cur); cur = 0; } // ^U
                0x17 => { // ^W
                    let mut s = cur;
                    while s > 0 && line[s - 1] == ' ' { s -= 1; }
                    while s > 0 && line[s - 1] != ' ' { s -= 1; }
                    self.kill = line[s..cur].iter().collect();
                    line.drain(s..cur);
                    cur = s;
                }
                0x19 => { let k: Vec<char> = self.kill.chars().collect(); let n = k.len(); line.splice(cur..cur, k); cur += n; } // ^Y
                0x14 => { // ^T
                    if line.len() >= 2 && cur > 0 {
                        let c = if cur == line.len() { cur - 1 } else { cur };
                        line.swap(c - 1, c);
                        cur = (c + 1).min(line.len());
                    }
                }
                0x04 => { // ^D
                    if line.is_empty() { let _ = out.write_all(b"\r\n"); return None; }
                    if cur < line.len() { line.remove(cur); }
                }
                0x7f | 0x08 => { if cur > 0 { line.remove(cur - 1); cur -= 1; } } // Backspace / ^H
                0x0c => { // ^L
                    let _ = out.write_all(b"\x1b[H\x1b[2J");
                    prev_rows = 0;
                }
                0x03 => { // ^C: cancel the line
                    let _ = out.write_all(b"^C\r\n");
                    line.clear();
                    cur = 0;
                    prev_rows = 0;
                    hpos = self.history.len();
                }
                0x07 => {} // ^G
                0x10 => { // ^P
                    if hpos > 0 { if hpos == self.history.len() { saved_line = line.clone(); } hpos -= 1; line = self.history[hpos].chars().collect(); cur = line.len(); }
                }
                0x0e => { // ^N
                    if hpos < self.history.len() { hpos += 1; line = if hpos == self.history.len() { saved_line.clone() } else { self.history[hpos].chars().collect() }; cur = line.len(); }
                }
                0x12 => { saved_line = line.clone(); search = Some((String::new(), self.history.len())); } // ^R
                0x09 => { // Tab
                    last_tab = true;
                    let txt: String = line.iter().collect();
                    let (start, mut cands) = comp(&txt, cur);
                    cands.sort();
                    cands.dedup();
                    let word: String = line[start.min(cur)..cur].iter().collect();
                    if cands.is_empty() {
                        let _ = out.write_all(b"\x07");
                    } else if cands.len() == 1 {
                        let c = &cands[0];
                        let ins: Vec<char> = c.chars().collect();
                        line.splice(start..cur, ins.iter().cloned());
                        cur = start + ins.len();
                        if !c.ends_with('/') && (cur == line.len() || line[cur] != ' ') { line.insert(cur, ' '); cur += 1; }
                    } else {
                        let cp = common_prefix(&cands);
                        if cp.chars().count() > word.chars().count() {
                            let ins: Vec<char> = cp.chars().collect();
                            line.splice(start..cur, ins.iter().cloned());
                            cur = start + ins.len();
                        } else if was_tab || cands.len() <= 1 {
                            // list the candidates in columns under the line
                            let disp: Vec<String> = cands.iter().map(|c| c.trim_end_matches('/').rsplit('/').next().map(|t| if c.ends_with('/') { format!("{}/", t) } else { t.to_string() }).unwrap_or(c.clone())).collect();
                            let cw = disp.iter().map(|c| c.chars().count()).max().unwrap_or(1) + 2;
                            let ncol = (width / cw).max(1);
                            let mut s = String::from("\r\n");
                            let shown = disp.len().min(400);
                            for (i, c) in disp[..shown].iter().enumerate() {
                                s += &format!("{:<w$}", c, w = cw);
                                if (i + 1) % ncol == 0 { s += "\r\n"; }
                            }
                            if shown % ncol != 0 { s += "\r\n"; }
                            if disp.len() > shown { s += &format!("... {} more\r\n", disp.len() - shown); }
                            let _ = out.write_all(s.as_bytes());
                            prev_rows = 0;
                        } else {
                            let _ = out.write_all(b"\x07");
                        }
                    }
                }
                0x1b => { // escape sequences
                    let mut s = [0u8; 1];
                    if inp.read(&mut s).unwrap_or(0) == 0 { continue; }
                    match s[0] {
                        b'[' | b'O' => {
                            let mut seq = vec![];
                            loop {
                                if inp.read(&mut s).unwrap_or(0) == 0 { break; }
                                seq.push(s[0]);
                                if s[0].is_ascii_alphabetic() || s[0] == b'~' { break; }
                            }
                            match seq.as_slice() {
                                b"A" => { if hpos > 0 { if hpos == self.history.len() { saved_line = line.clone(); } hpos -= 1; line = self.history[hpos].chars().collect(); cur = line.len(); } }
                                b"B" => { if hpos < self.history.len() { hpos += 1; line = if hpos == self.history.len() { saved_line.clone() } else { self.history[hpos].chars().collect() }; cur = line.len(); } }
                                b"C" => cur = (cur + 1).min(line.len()),
                                b"D" => cur = cur.saturating_sub(1),
                                b"H" | b"1~" | b"7~" => cur = 0,
                                b"F" | b"4~" | b"8~" => cur = line.len(),
                                b"3~" => { if cur < line.len() { line.remove(cur); } }
                                b"1;5C" | b"1;3C" => { while cur < line.len() && !is_word(line[cur]) { cur += 1; } while cur < line.len() && is_word(line[cur]) { cur += 1; } }
                                b"1;5D" | b"1;3D" => { while cur > 0 && !is_word(line[cur - 1]) { cur -= 1; } while cur > 0 && is_word(line[cur - 1]) { cur -= 1; } }
                                _ => {}
                            }
                        }
                        b'b' => { while cur > 0 && !is_word(line[cur - 1]) { cur -= 1; } while cur > 0 && is_word(line[cur - 1]) { cur -= 1; } } // Alt-B
                        b'f' => { while cur < line.len() && !is_word(line[cur]) { cur += 1; } while cur < line.len() && is_word(line[cur]) { cur += 1; } } // Alt-F
                        b'd' => { // Alt-D
                            let mut e = cur;
                            while e < line.len() && !is_word(line[e]) { e += 1; }
                            while e < line.len() && is_word(line[e]) { e += 1; }
                            self.kill = line[cur..e].iter().collect();
                            line.drain(cur..e);
                        }
                        0x7f => { // Alt-Backspace
                            let mut st = cur;
                            while st > 0 && !is_word(line[st - 1]) { st -= 1; }
                            while st > 0 && is_word(line[st - 1]) { st -= 1; }
                            self.kill = line[st..cur].iter().collect();
                            line.drain(st..cur);
                            cur = st;
                        }
                        _ => {}
                    }
                }
                c if c >= 0x20 => {
                    // UTF-8 assembly
                    utf.push(c);
                    let need = if utf[0] < 0x80 { 1 } else if utf[0] >= 0xf0 { 4 } else if utf[0] >= 0xe0 { 3 } else { 2 };
                    if utf.len() >= need {
                        if let Ok(st) = std::str::from_utf8(&utf) {
                            for ch in st.chars() { line.insert(cur, ch); cur += 1; }
                        }
                        utf.clear();
                    } else {
                        continue;
                    }
                }
                _ => {}
            }
            render(&mut out, &line, cur, prompt, &mut prev_rows);
        }
    }
}

/// candidates for the word before the cursor
pub fn complete(line: &str, cur: usize, cmds: &[String], opts_of: &dyn Fn(&str) -> Vec<String>, vars: &[String]) -> (usize, Vec<String>) {
    let chars: Vec<char> = line.chars().collect();
    let cur = cur.min(chars.len());
    // word start: after whitespace, '[', '{', ';' or '"'
    let mut s = cur;
    while s > 0 && !matches!(chars[s - 1], ' ' | '\t' | '[' | '{' | ';' | '"') { s -= 1; }
    let word: String = chars[s..cur].iter().collect();
    // command position: first word of the line / after '[' or ';'
    let mut k = s;
    while k > 0 && chars[k - 1] == ' ' { k -= 1; }
    let cmd_pos = k == 0 || matches!(chars[k - 1], '[' | ';');
    if let Some(v) = word.strip_prefix('$') {
        let v = v.trim_start_matches('{');
        let mut out: Vec<String> = vars.iter().filter(|n| n.starts_with(v)).map(|n| format!("${}", n)).collect();
        out.sort();
        return (s, out);
    }
    if cmd_pos {
        return (s, cmds.iter().filter(|c| c.starts_with(&word)).cloned().collect());
    }
    // the command this word belongs to: first word after the last unmatched '[' / ';' / line start
    let mut depth = 0i32;
    let mut b = s;
    while b > 0 {
        match chars[b - 1] {
            ']' => depth += 1,
            '[' if depth == 0 => break,
            '[' => depth -= 1,
            ';' if depth == 0 => break,
            _ => {}
        }
        b -= 1;
    }
    let rest: String = chars[b..s].iter().collect();
    let cmd = rest.split_whitespace().next().unwrap_or("").to_string();
    if word.starts_with('-') {
        let used: Vec<&str> = rest.split_whitespace().filter(|w| w.starts_with('-')).collect();
        let mut o: Vec<String> = opts_of(&cmd).into_iter().filter(|x| x.starts_with(&word) && !used.contains(&x.as_str())).collect();
        o.sort();
        o.dedup();
        return (s, o);
    }
    // file names
    let (dir, base) = match word.rfind('/') { Some(i) => (word[..=i].to_string(), word[i + 1..].to_string()), None => (String::new(), word.clone()) };
    let rd = if dir.is_empty() { ".".to_string() } else if let Some(r) = dir.strip_prefix("~/") { std::env::var("HOME").map(|h| format!("{}/{}", h, r)).unwrap_or(dir.clone()) } else { dir.clone() };
    let mut out = vec![];
    if let Ok(rdir) = std::fs::read_dir(&rd) {
        for e in rdir.flatten() {
            let n = e.file_name().to_string_lossy().to_string();
            if !n.starts_with(&base) || (n.starts_with('.') && !base.starts_with('.')) { continue; }
            let isd = e.file_type().map(|t| t.is_dir()).unwrap_or(false);
            out.push(format!("{}{}{}", dir, n, if isd { "/" } else { "" }));
        }
    }
    // option values that are command names (help / man)
    if out.is_empty() && matches!(cmd.as_str(), "help" | "man" | "list_commands") {
        out = cmds.iter().filter(|c| c.starts_with(&word)).cloned().collect();
    }
    (s, out)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn completion_cases() {
        let cmds: Vec<String> = ["place_opt", "place_io_pins", "place_macros", "report_timing", "help", "set"].iter().map(|s| s.to_string()).collect();
        let opts = |c: &str| if c == "place_io_pins" { vec!["-layer".to_string(), "-length".into(), "-ports".into()] } else { vec![] };
        let vars = vec!["design".to_string(), "dir".to_string()];
        assert_eq!(complete("pla", 3, &cmds, &opts, &vars).1.len(), 3);
        let (s, v) = complete("set x [place_io", 15, &cmds, &opts, &vars);
        assert_eq!((s, v), (7, vec!["place_io_pins".to_string()]));
        let (_, v) = complete("place_io_pins -ports a -l", 25, &cmds, &opts, &vars);
        assert_eq!(v, vec!["-layer".to_string(), "-length".into()]);
        let (_, v) = complete("place_io_pins -ports a -p", 25, &cmds, &opts, &vars);
        assert!(v.is_empty(), "used option not offered again");
        assert_eq!(complete("puts $d", 7, &cmds, &opts, &vars).1, vec!["$design".to_string(), "$dir".into()]);
        assert_eq!(complete("help rep", 8, &cmds, &opts, &vars).1, vec!["report_timing".to_string()]);
        assert_eq!(common_prefix(&["place_opt".into(), "place_io".into()]), "place_");
    }
}
