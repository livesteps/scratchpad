//! Parasitic and delay exports:
//!   * write_spef / write_parasitics : SPEF per extraction corner (detailed-route RC, read SPEF,
//!     or estimated), units, name map, net subsets, coordinates
//!   * write_dspf                    : detailed standard parasitic format (SPICE RC per net with
//!     pin/sub-node coordinates and an instance section)
//!   * write_sdf                     : SDF 2.1/3.0 with min/typ/max triplets from one scenario or
//!     from min/typ/max corners, single-value -min/-typ/-max files, per-corner files,
//!     IOPATH / INTERCONNECT / TIMINGCHECK (SETUP HOLD RECOVERY REMOVAL, SETUPHOLD, RECREM)
//!   * read_sdf                      : back-annotation of SDF delays (round-trip check)
use crate::netlist::{Dir, NetId, Netlist, PinRef};
use crate::session::*;
use crate::sta::{AnnDelay, SdfArc, SdfCheck, Timing};
use crate::tcl::{split_list, to_list, Flow};
use std::collections::{BTreeMap, HashMap, HashSet};
use std::fmt::Write;
type R = Result<String, Flow>;

fn err(m: impl Into<String>) -> R {
    Err(Flow::Err(m.into()))
}

/// escape an identifier: everything that is not alphanumeric, '_' (or the divider when kept) gets '\'
fn esc(s: &str, keep_div: bool) -> String {
    let mut o = String::new();
    for ch in s.chars() {
        if ch.is_ascii_alphanumeric() || ch == '_' || (keep_div && ch == '/') {
            o.push(ch);
        } else {
            o.push('\\');
            o.push(ch);
        }
    }
    o
}
/// escape but keep a trailing bus index ("din[3]")
fn esc_bus(s: &str, keep_div: bool) -> String {
    if let Some(p) = s.rfind('[') {
        let idx = &s[p..];
        if idx.ends_with(']') && idx[1..idx.len() - 1].chars().all(|c| c.is_ascii_digit()) && p > 0 {
            return format!("{}{}", esc(&s[..p], keep_div), idx);
        }
    }
    esc(s, keep_div)
}

// ------------------------------------------------------------------ parasitic collection

#[derive(Clone, Debug)]
struct PConn {
    pr: PinRef,
    node: String,
    io: char,
    cap: f64,
    cell: String,
}
#[derive(Clone, Debug)]
struct PNet {
    name: String,
    wire_c: f64,
    conns: Vec<PConn>,
    caps: Vec<(String, f64)>,
    res: Vec<(String, String, f64)>,
    /// coupling: (node, aggressor net, aggressor node, pF)
    cc: Vec<(String, String, String, f64)>,
    routed: bool,
}

fn lib_pin_cap(t: &Timing, pr: PinRef) -> f64 {
    match pr {
        PinRef::Cell(c, p) => {
            let cl = t.nl.cell(c);
            cl.lib().and_then(|l| t.libs.cell(l)).and_then(|lc| lc.pins.iter().find(|x| x.name == cl.pins[p].name)).map(|x| x.cap).unwrap_or(0.0)
        }
        PinRef::Port(_) => 0.0,
    }
}

/// node name of a pin: "inst:pin" / port
fn pin_node(nl: &Netlist, pr: PinRef) -> String {
    match pr {
        PinRef::Cell(c, p) => format!("{}:{}", nl.cell(c).name, nl.cell(c).pins[p].name),
        PinRef::Port(p) => nl.ports[p].name.clone(),
    }
}

fn collect_parasitics(t: &Timing, only: &Option<HashSet<NetId>>) -> (Vec<PNet>, &'static str) {
    let nl = t.nl;
    let rc = t.opts.routed.as_deref();
    let (rs, cs) = if t.routed_raw { (1.0, 1.0) } else { (t.corner.r_scale, t.corner.c_scale) };
    let src = if t.routed_raw { "ANNOTATED_SPEF" } else if rc.is_some() { "DETAILED_ROUTE" } else { "ESTIMATED" };
    let mut out = vec![];
    for n in nl.net_ids() {
        if let Some(o) = only {
            if !o.contains(&n) {
                continue;
            }
        }
        // a net behind a hierarchy boundary is written as part of its root net
        if let Some(PinRef::Cell(c, _)) = nl.driver(n) {
            if nl.cell(c).is_hport() {
                continue;
            }
        }
        let leaf: Vec<PinRef> = Session::leaf_conns(nl, n).into_iter().filter(|p| !matches!(p, PinRef::Cell(c, _) if nl.cell(*c).is_hport())).collect();
        if leaf.is_empty() {
            continue;
        }
        let conns: Vec<PConn> = leaf
            .iter()
            .map(|pr| {
                let io = match pr {
                    PinRef::Port(p) => match nl.ports[*p].dir {
                        Dir::In => 'I',
                        Dir::Out => 'O',
                        Dir::InOut => 'B',
                    },
                    PinRef::Cell(..) => {
                        if nl.is_driver(*pr) {
                            'O'
                        } else {
                            'I'
                        }
                    }
                };
                let cell = match pr {
                    PinRef::Cell(c, _) => nl.cell(*c).lib().unwrap_or("").to_string(),
                    _ => String::new(),
                };
                PConn { pr: *pr, node: pin_node(nl, *pr), io, cap: if io == 'I' || matches!(pr, PinRef::Port(_)) { lib_pin_cap(t, *pr) } else { 0.0 }, cell }
            })
            .collect();
        let name = nl.net(n).name.clone();
        let node = |x: &str| -> String {
            if x.chars().all(|c| c.is_ascii_digit()) {
                format!("{}:{}", name, x)
            } else {
                match x.rsplit_once('/') {
                    Some((c, p)) if nl.cell_by_name(c).is_some() => format!("{}:{}", c, p),
                    _ => x.to_string(),
                }
            }
        };
        if let Some(segs) = rc.and_then(|r| r.segs.get(&n)) {
            let wire_c = rc.and_then(|r| r.wire_c.get(&n)).copied().unwrap_or(0.0) * cs;
            let caps = segs.iter().filter(|s| s.3 != 0.0).map(|(_, to, _, c)| (node(to), c * cs)).collect();
            let res = segs.iter().filter(|s| s.0 != s.1).map(|(f, to, r, _)| (node(f), node(to), r * rs)).collect();
            let cc = rc.and_then(|r| r.coupling.get(&n)).map(|v| v.iter().map(|(a, an, b, c)| (node(a), nl.net(*an).name.clone(), b.clone(), c * cs)).collect()).unwrap_or_default();
            out.push(PNet { name, wire_c, conns, caps, res, cc, routed: true });
        } else {
            // estimated: a star through one sub-node
            let wc = t.net_wc.get(n).copied().unwrap_or(0.0);
            let wr = t.net_wr.get(n).copied().unwrap_or(0.0);
            let mut caps = vec![];
            let mut res = vec![];
            let drv = conns.iter().find(|c| c.io == 'O' || (c.io == 'I' && matches!(c.pr, PinRef::Port(_)) && nl.is_driver(c.pr))).map(|c| c.node.clone());
            if wc > 0.0 || wr > 0.0 {
                let mid = format!("{}:1", name);
                caps.push((mid.clone(), wc));
                if let Some(d) = &drv {
                    res.push((d.clone(), mid.clone(), wr * 0.5));
                }
                for c in &conns {
                    if Some(&c.node) != drv.as_ref() {
                        res.push((mid.clone(), c.node.clone(), wr * 0.5));
                    }
                }
            }
            out.push(PNet { name, wire_c: wc, conns, caps, res, cc: vec![], routed: false });
        }
    }
    (out, src)
}

#[derive(Clone, Copy)]
struct Units {
    t: (f64, &'static str),
    c: (f64, &'static str),
    r: (f64, &'static str),
}
fn units(x: &A) -> Result<Units, Flow> {
    let pick = |k: &str, d: &str, tbl: &[(&'static str, f64)]| -> Result<(f64, &'static str), Flow> {
        let v = x.get(k).cloned().unwrap_or(d.into()).to_uppercase();
        tbl.iter().find(|(n, _)| *n == v).map(|(n, f)| (*f, *n)).ok_or_else(|| Flow::Err(format!("{} must be one of {} (OUT-210)", k, tbl.iter().map(|t| t.0).collect::<Vec<_>>().join(" "))))
    };
    Ok(Units {
        t: pick("-time_unit", "NS", &[("NS", 1.0), ("PS", 1000.0)])?,
        c: pick("-cap_unit", "PF", &[("PF", 1.0), ("FF", 1000.0)])?,
        r: pick("-res_unit", "KOHM", &[("KOHM", 1.0), ("OHM", 1000.0)])?,
    })
}

// ------------------------------------------------------------------ SPEF

fn spef_text(nl: &Netlist, nets: &[PNet], corner: &str, src: &str, u: Units, name_map: bool, prec: usize, xy: &dyn Fn(PinRef) -> Option<(f64, f64)>) -> String {
    let mut s = String::new();
    let _ = writeln!(
        s,
        "*SPEF \"IEEE 1481-1998\"\n*DESIGN \"{}\"\n*DATE \"{}\"\n*VENDOR \"RSynth\"\n*PROGRAM \"rsynth\"\n*VERSION \"0.3\"\n*DESIGN_FLOW \"{}\" \"CORNER {}\" \"PIN_CAP NONE\"\n*DIVIDER /\n*DELIMITER :\n*BUS_DELIMITER [ ]\n*T_UNIT 1 {}\n*C_UNIT 1 {}\n*R_UNIT 1 {}\n*L_UNIT 1 HENRY\n",
        nl.name,
        stamp(),
        src,
        corner,
        u.t.1,
        u.c.1,
        u.r.1
    );
    // name map: nets and instances
    let mut map: BTreeMap<String, usize> = BTreeMap::new();
    if name_map {
        let mut k = 0;
        let mut add = |n: &str, map: &mut BTreeMap<String, usize>| {
            if !map.contains_key(n) {
                k += 1;
                map.insert(n.to_string(), k);
            }
        };
        for n in nets {
            add(&n.name, &mut map);
        }
        for n in nets {
            for c in &n.conns {
                if let PinRef::Cell(ci, _) = c.pr {
                    add(&nl.cell(ci).name, &mut map);
                }
            }
        }
        let mut inv: Vec<(&usize, &String)> = map.iter().map(|(a, b)| (b, a)).collect();
        inv.sort();
        let _ = writeln!(s, "*NAME_MAP");
        for (i, n) in inv {
            let _ = writeln!(s, "*{} {}", i, esc_bus(n, true));
        }
        let _ = writeln!(s);
    }
    let _ = writeln!(s, "*PORTS");
    for p in nl.port_ids() {
        let d = match nl.ports[p].dir {
            Dir::In => "I",
            Dir::Out => "O",
            Dir::InOut => "B",
        };
        let _ = writeln!(s, "{} {}", esc_bus(&nl.ports[p].name, false), d);
    }
    let _ = writeln!(s);
    let mapped = |n: &str| -> String { map.get(n).map(|i| format!("*{}", i)).unwrap_or_else(|| esc_bus(n, true)) };
    // a node "a:b": map the instance (pin) or the net (sub-node)
    let nd = |x: &str, net: &str| -> String {
        if let Some((a, b)) = x.rsplit_once(':') {
            if a == net {
                return format!("{}:{}", mapped(a), b);
            }
            if nl.cell_by_name(a).is_some() {
                return format!("{}:{}", mapped(a), esc_bus(b, false));
            }
        }
        esc_bus(x, false)
    };
    let f = |v: f64| format!("{:.*}", prec, v);
    for n in nets {
        let total = n.wire_c + n.conns.iter().map(|c| c.cap).sum::<f64>() * 0.0;
        let _ = writeln!(s, "*D_NET {} {}\n*CONN", mapped(&n.name), f(total * u.c.0));
        for c in &n.conns {
            let kind = if matches!(c.pr, PinRef::Port(_)) { "*P" } else { "*I" };
            let mut line = format!("{} {} {}", kind, nd(&c.node, &n.name), c.io);
            if let Some((x, y)) = xy(c.pr) {
                let _ = write!(line, " *C {:.3} {:.3}", x, y);
            }
            if c.cap > 0.0 {
                let _ = write!(line, " *L {}", f(c.cap * u.c.0));
            }
            if !c.cell.is_empty() && c.io == 'O' {
                let _ = write!(line, " *D {}", c.cell);
            }
            let _ = writeln!(s, "{}", line);
        }
        if !n.caps.is_empty() || !n.cc.is_empty() {
            let _ = writeln!(s, "*CAP");
            for (i, (a, c)) in n.caps.iter().enumerate() {
                let _ = writeln!(s, "{} {} {}", i + 1, nd(a, &n.name), f(c * u.c.0));
            }
            for (i, (a, an, b, c)) in n.cc.iter().enumerate() {
                // aggressor node: a pin keeps its instance:pin name, an internal node is net:index
                let bn = if b.chars().all(|ch| ch.is_ascii_digit()) { format!("{}:{}", an, b) } else {
                    match b.rsplit_once('/') { Some((ci, p)) => format!("{}:{}", ci, p), None => b.clone() }
                };
                let _ = writeln!(s, "{} {} {} {}", n.caps.len() + i + 1, nd(a, &n.name), nd(&bn, an), f(c * u.c.0));
            }
        }
        if !n.res.is_empty() {
            let _ = writeln!(s, "*RES");
            for (i, (a, b, r)) in n.res.iter().enumerate() {
                let _ = writeln!(s, "{} {} {} {}", i + 1, nd(a, &n.name), nd(b, &n.name), f(r * u.r.0));
            }
        }
        let _ = writeln!(s, "*END\n");
    }
    s
}

fn stamp() -> String {
    let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0);
    format!("epoch {}", t)
}

// ------------------------------------------------------------------ DSPF

fn spice_num(v: f64, unit: char) -> String {
    let a = v.abs();
    let (m, sfx) = if a == 0.0 {
        (0.0, "")
    } else if unit == 'F' {
        // v in pF
        if a >= 1.0 {
            (v, "p")
        } else {
            (v * 1000.0, "f")
        }
    } else {
        // v in kohm
        if a >= 1.0 {
            (v, "k")
        } else {
            (v * 1000.0, "")
        }
    };
    let s = format!("{:.5}", m);
    let s = s.trim_end_matches('0').trim_end_matches('.');
    format!("{}{}", if s.is_empty() { "0" } else { s }, sfx)
}

fn dspf_text(nl: &Netlist, nets: &[PNet], corner: &str, src: &str, ground: &str, xy: &dyn Fn(PinRef) -> Option<(f64, f64)>, instances: bool, lib_pins: &dyn Fn(usize) -> Vec<String>) -> String {
    let mut s = String::new();
    let _ = writeln!(
        s,
        "*|DSPF 1.5\n*|DESIGN \"{}\"\n*|DATE \"{}\"\n*|VENDOR \"RSynth\"\n*|PROGRAM \"rsynth\"\n*|VERSION \"0.3\"\n*|DIVIDER /\n*|DELIMITER :\n*|BUSBIT []\n*|GROUND_NET {}\n* corner {} ; parasitics from {} ; C in F (p/f suffix), R in ohm (k suffix)\n",
        nl.name,
        stamp(),
        ground,
        corner,
        src
    );
    let ports: Vec<String> = nl.port_ids().into_iter().map(|p| nl.ports[p].name.clone()).collect();
    let _ = writeln!(s, ".SUBCKT {} {}", nl.name, ports.join(" "));
    let (mut nc, mut nr) = (0usize, 0usize);
    let loc = |pr: PinRef| xy(pr).map(|(x, y)| format!(" {:.3} {:.3}", x, y)).unwrap_or_default();
    for n in nets {
        let pin_c: f64 = n.conns.iter().map(|c| c.cap).sum();
        let _ = writeln!(s, "\n*|NET {} {}F", n.name, spice_num(n.wire_c + pin_c, 'F'));
        for c in &n.conns {
            match c.pr {
                PinRef::Port(_) => {
                    let _ = writeln!(s, "*|P ({} {} {}{})", c.node, c.io, spice_num(c.cap, 'F'), loc(c.pr));
                }
                PinRef::Cell(ci, p) => {
                    let _ = writeln!(s, "*|I ({} {} {} {} {}{})", c.node, nl.cell(ci).name, nl.cell(ci).pins[p].name, c.io, spice_num(c.cap, 'F'), loc(c.pr));
                }
            }
        }
        let pins: HashSet<&str> = n.conns.iter().map(|c| c.node.as_str()).collect();
        let mut subs: Vec<&String> = n.caps.iter().map(|c| &c.0).chain(n.res.iter().flat_map(|r| [&r.0, &r.1])).filter(|x| !pins.contains(x.as_str())).collect();
        subs.sort();
        subs.dedup();
        for sn in subs {
            let _ = writeln!(s, "*|S ({})", sn);
        }
        for (a, c) in &n.caps {
            nc += 1;
            let _ = writeln!(s, "C{} {} {} {}", nc, a, ground, spice_num(*c, 'F'));
        }
        for (a, b, r) in &n.res {
            nr += 1;
            let _ = writeln!(s, "R{} {} {} {}", nr, a, b, spice_num(*r, 'R'));
        }
    }
    if instances {
        let _ = writeln!(s, "\n* Instance Section");
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.is_hport() {
                continue;
            }
            let Some(lib) = cl.lib() else { continue };
            let order = lib_pins(c);
            let nodes: Vec<String> = order.iter().map(|p| format!("{}:{}", cl.name, p)).collect();
            let _ = writeln!(s, "X{} {} {}", cl.name, nodes.join(" "), lib);
        }
    }
    let _ = writeln!(s, "\n.ENDS");
    s
}

// ------------------------------------------------------------------ SDF data

#[derive(Clone, Copy, Debug, PartialEq)]
enum Pick {
    Min,
    Typ,
    Max,
}
type ArcKey = (PinRef, PinRef);
type ChkKey = (PinRef, PinRef, &'static str, bool);
struct SdfSet {
    arcs: Vec<SdfArc>,
    checks: Vec<SdfCheck>,
}

impl Session {
    pub(crate) fn xout_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "write_spef" | "write_parasitics" => self.c_write_spef(a, false),
            "write_dspf" => self.c_write_spef(a, true),
            "write_sdf" => self.c_write_sdf(a),
            "read_sdf" => self.c_read_sdf(a),
            _ => return None,
        })
    }

    /// scenarios for a set of corner names (the first active scenario using each corner)
    fn corner_scens(&self, x: &A) -> Result<Vec<(String, usize)>, Flow> {
        let list: Vec<String> = match x.get("-corners").or(x.get("-corner")).or(x.get("-extraction_corner")).or(x.get("-extraction_corners")) {
            Some(s) => split_list(s),
            None => {
                if let Some(sc) = x.get("-scenario").or(x.get("-scenarios")) {
                    let mut v = vec![];
                    for n in split_list(sc) {
                        let i = self.scens.iter().position(|s| s.name == n).ok_or_else(|| Flow::Err(format!("scenario '{}' does not exist (OUT-211)", n)))?;
                        v.push((self.scens[i].corner.clone(), i));
                    }
                    return Ok(v);
                }
                let mut seen = vec![];
                for s in self.scens.iter().filter(|s| s.active) {
                    if !seen.contains(&s.corner) {
                        seen.push(s.corner.clone());
                    }
                }
                seen
            }
        };
        let mut v = vec![];
        for cn in list {
            match self.scens.iter().position(|s| s.corner == cn && s.active).or(self.scens.iter().position(|s| s.corner == cn)) {
                Some(i) => v.push((cn, i)),
                None => {
                    if self.scens.is_empty() {
                        v.push((cn, 0));
                    } else {
                        return Err(Flow::Err(format!("no scenario uses corner '{}' (OUT-201)", cn)));
                    }
                }
            }
        }
        if v.is_empty() {
            v.push(("default".into(), 0));
        }
        Ok(v)
    }

    fn pin_xy(&self, pr: PinRef) -> Option<(f64, f64)> {
        let nl = self.nl.as_ref()?;
        if let Some((p, _)) = self.pin_phys(pr) {
            return Some(p);
        }
        match pr {
            PinRef::Cell(c, _) => nl.cell(c).loc,
            PinRef::Port(p) => nl.ports[p].loc,
        }
    }

    fn c_write_spef(&mut self, a: &[String], dspf: bool) -> R {
        let cmd = if dspf { "write_dspf" } else { "write_spef" };
        let x = args(a, &["-output", "-format", "-corner", "-corners", "-extraction_corner", "-extraction_corners", "-scenario", "-scenarios", "-nets", "-net", "-time_unit", "-cap_unit", "-res_unit", "-precision", "-significant_digits", "-ground_net", "-stage"]);
        if let Some(fm) = x.get("-format") {
            let fm = fm.to_lowercase();
            if fm == "dspf" && !dspf {
                return self.c_write_spef(a, true);
            }
            if fm != "spef" && fm != "dspf" {
                return err(format!("{}: -format must be spef or dspf (OUT-212)", cmd));
            }
        }
        let nl = self.nl()?;
        let ext = if dspf { "dspf" } else { "spef" };
        let prefix = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or(format!("{}", nl.name));
        let u = units(&x)?;
        let prec = x.num("-precision").or(x.num("-significant_digits")).map(|v| v as usize).unwrap_or(6).min(12);
        let only: Option<HashSet<NetId>> = match x.get("-nets").or(x.get("-net")) {
            Some(s) => {
                let mut set = HashSet::new();
                for n in split_list(s) {
                    let nm = crate::cons::Obj::parse(&n).map(|o| o.name().to_string()).unwrap_or(n);
                    let mut any = false;
                    for id in nl.net_ids() {
                        if nl.net(id).name == nm || crate::netlist::glob(&nm, &nl.net(id).name) {
                            set.insert(id);
                            any = true;
                        }
                    }
                    if !any {
                        crate::warn!("OUT-213", "{}: net '{}' not found", cmd, nm);
                    }
                }
                Some(set)
            }
            None => None,
        };
        let stage = x.get("-stage").cloned().unwrap_or_default();
        if stage == "detail_route" || stage == "detailed_route" || x.has("-require_routed") {
            if self.routed_rc.is_none() && self.spef_rc.is_empty() {
                return err(format!("{}: no detailed-route parasitics (run route_detail / route_opt or read_parasitics first) (OUT-214)", cmd));
            }
        }
        let scen = self.corner_scens(&x)?;
        let multi = scen.len() > 1 || prefix.contains("%c") || !(prefix.ends_with(&format!(".{}", ext)));
        let name_map = !x.has("-no_name_map");
        let xy_on = dspf || x.has("-coordinates") || x.has("-include_coordinates");
        let ground = x.get("-ground_net").cloned().unwrap_or("0".into());
        let mut files = vec![];
        for (cn, si) in scen {
            let f = if prefix.contains("%c") {
                prefix.replace("%c", &cn)
            } else if multi {
                format!("{}.{}.{}", prefix.trim_end_matches(&format!(".{}", ext)), cn, ext)
            } else {
                prefix.clone()
            };
            let me: &Session = self;
            let res = self.with_timing(si, |t| {
                let (nets, src) = collect_parasitics(t, &only);
                let xy = |pr: PinRef| if xy_on { me.pin_xy(pr) } else { None };
                let lib_pins = |c: usize| -> Vec<String> {
                    let cl = t.nl.cell(c);
                    cl.lib().and_then(|l| t.libs.cell(l)).map(|lc| lc.pins.iter().map(|p| p.name.clone()).collect()).unwrap_or_else(|| cl.pins.iter().map(|p| p.name.clone()).collect())
                };
                let txt = if dspf { dspf_text(t.nl, &nets, &cn, src, &ground, &xy, !x.has("-no_instances"), &lib_pins) } else { spef_text(t.nl, &nets, &cn, src, u, name_map, prec, &xy) };
                let routed = nets.iter().filter(|n| n.routed).count();
                (txt, nets.len(), routed, src)
            })?;
            let (txt, n, routed, src) = res;
            std::fs::write(&f, txt).map_err(|e| Flow::Err(format!("{}: {}: {}", cmd, f, e)))?;
            let how = match src {
                "DETAILED_ROUTE" => "extracted from detailed routes",
                "ANNOTATED_SPEF" => "from annotated SPEF",
                _ => "estimated",
            };
            crate::info!("OUT-200", "Wrote {} '{}' (corner {}, {} nets, {} with RC networks {}, units {} {} {})", ext.to_uppercase(), f, cn, n, routed, how, u.t.1, u.c.1, u.r.1);
            if src == "ESTIMATED" {
                crate::warn!("OUT-215", "{}: no routed parasitics for corner {}; wrote estimated (star) RC networks", cmd, cn);
            }
            files.push(f);
        }
        Ok(to_list(&files))
    }

    // ------------------------------------------------------------------ SDF

    fn sdf_set(&self, si: usize) -> Result<SdfSet, Flow> {
        self.with_timing(si, |t| SdfSet { arcs: t.sdf_arcs(), checks: t.sdf_checks() })
    }

    fn c_write_sdf(&mut self, a: &[String]) -> R {
        let x = args(
            a,
            &["-output", "-version", "-scenario", "-corner", "-corners", "-min_corner", "-typ_corner", "-max_corner", "-significant_digits", "-precision", "-include", "-no_negative_values", "-instance", "-context", "-time_unit", "-exclude"],
        );
        let nl = self.nl()?;
        let ver = x.get("-version").cloned().unwrap_or("3.0".into());
        if ver != "3.0" && ver != "2.1" {
            return err("write_sdf: -version must be 2.1 or 3.0 (SDF-001)");
        }
        let base = x.get("-output").cloned().or(x.pos.first().cloned()).unwrap_or(format!("{}.sdf", nl.name));
        let dig = x.num("-significant_digits").or(x.num("-precision")).map(|v| v as usize).unwrap_or(4).min(10);
        let tu = x.get("-time_unit").map(|s| s.to_lowercase()).unwrap_or("ns".into());
        let tk = match tu.as_str() {
            "ns" | "1ns" => 1.0,
            "ps" | "1ps" => 1000.0,
            "100ps" => 10.0,
            _ => return err("write_sdf: -time_unit must be ns, 100ps or ps (SDF-002)"),
        };
        let include: HashSet<String> = x.get("-include").map(|s| split_list(s).into_iter().map(|v| v.to_uppercase()).collect()).unwrap_or_default();
        let excl: HashSet<String> = x.get("-exclude").map(|s| split_list(s).into_iter().map(|v| v.to_lowercase()).collect()).unwrap_or_default();
        let no_ic = x.has("-no_interconnect") || x.has("-no_net_delays") || excl.contains("interconnect") || excl.contains("net_delays");
        let no_tc = x.has("-no_timing_checks") || excl.contains("timing_checks") || excl.contains("checks");
        let no_neg: HashSet<String> = match x.get("-no_negative_values") {
            Some(s) => split_list(s).into_iter().collect(),
            None => HashSet::new(),
        };
        let neg_all = a.iter().any(|v| v == "-no_negative_values") && no_neg.is_empty();
        let single: Option<Pick> = if x.has("-min") { Some(Pick::Min) } else if x.has("-typ") { Some(Pick::Typ) } else if x.has("-max") { Some(Pick::Max) } else { None };
        let inst = x.get("-instance").cloned();
        // the jobs: (file, [scen for min, typ, max], label)
        let mut jobs: Vec<(String, [Option<usize>; 3], String)> = vec![];
        let scen_of_corner = |c: &str| -> Result<usize, Flow> { self.scens.iter().position(|s| s.corner == c && s.active).or(self.scens.iter().position(|s| s.corner == c)).ok_or_else(|| Flow::Err(format!("write_sdf: no scenario uses corner '{}' (SDF-003)", c))) };
        let def_scen = match x.get("-scenario") {
            Some(s) => self.scens.iter().position(|k| &k.name == s).ok_or_else(|| Flow::Err(format!("write_sdf: scenario '{}' does not exist (SDF-004)", s)))?,
            None => self.active("setup").first().copied().unwrap_or(0),
        };
        if x.get("-min_corner").is_some() || x.get("-max_corner").is_some() || x.get("-typ_corner").is_some() {
            let mn = x.get("-min_corner").map(|c| scen_of_corner(c)).transpose()?;
            let ty = x.get("-typ_corner").map(|c| scen_of_corner(c)).transpose()?;
            let mx = x.get("-max_corner").map(|c| scen_of_corner(c)).transpose()?;
            let lbl = format!("min {} typ {} max {}", x.get("-min_corner").cloned().unwrap_or("-".into()), x.get("-typ_corner").cloned().unwrap_or("-".into()), x.get("-max_corner").cloned().unwrap_or("-".into()));
            jobs.push((base.clone(), [mn, ty, mx], lbl));
        } else if let Some(cs) = x.get("-corners").or(x.get("-corner")) {
            let cl = split_list(cs);
            for c in &cl {
                let si = scen_of_corner(c)?;
                let f = if cl.len() == 1 { base.clone() } else { format!("{}.{}.sdf", base.trim_end_matches(".sdf"), c) };
                jobs.push((f, [Some(si), None, Some(si)], format!("corner {}", c)));
            }
        } else {
            jobs.push((base.clone(), [Some(def_scen), None, Some(def_scen)], format!("scenario {}", self.scens.get(def_scen).map(|s| s.name.clone()).unwrap_or_default())));
        }
        let mut files = vec![];
        for (f, sc, lbl) in jobs {
            // timing data per needed scenario
            let mut cache: HashMap<usize, SdfSet> = HashMap::new();
            for s in sc.iter().flatten() {
                if !cache.contains_key(s) {
                    cache.insert(*s, self.sdf_set(*s)?);
                }
            }
            // a typ with no typ corner: the late values of the max scenario (written only when asked)
            let vals = |p: Pick| -> Option<(HashMap<ArcKey, [f64; 2]>, HashMap<ChkKey, [f64; 2]>, Vec<(ArcKey, Option<usize>, Option<bool>)>)> {
                let (si, early) = match p {
                    Pick::Min => (sc[0]?, true),
                    Pick::Typ => (sc[1].or(if single == Some(Pick::Typ) { sc[2] } else { None })?, false),
                    Pick::Max => (sc[2]?, false),
                };
                let set = &cache[&si];
                let mut am = HashMap::new();
                let mut order = vec![];
                for ar in &set.arcs {
                    let k = (ar.from, ar.to);
                    if !am.contains_key(&k) {
                        order.push((k, ar.cell, ar.edge));
                    }
                    am.insert(k, ar.d[if early { 0 } else { 1 }]);
                }
                let mut cm = HashMap::new();
                for c in &set.checks {
                    // setup-like checks take the max value at max corners, hold-like the min-slew value
                    let hold_like = c.kind == "HOLD" || c.kind == "REMOVAL";
                    let i = if early || hold_like { 0 } else { 1 };
                    let _ = i;
                    cm.insert((c.data, c.clock, c.kind, c.clk_rise), c.v[if early { 0 } else { 1 }]);
                }
                Some((am, cm, order))
            };
            let picks: Vec<Pick> = match single {
                Some(p) => vec![p],
                None => vec![Pick::Min, Pick::Typ, Pick::Max],
            };
            let tables: Vec<Option<_>> = picks.iter().map(|p| vals(*p)).collect();
            if tables.iter().all(|t| t.is_none()) {
                return err(format!("write_sdf: no data for the requested {} values (SDF-005)", match single { Some(Pick::Typ) => "typ", Some(Pick::Min) => "min", _ => "" }));
            }
            let order = tables.iter().flatten().next().map(|t| t.2.clone()).unwrap_or_default();
            let ckeys: Vec<ChkKey> = {
                let set = &cache[&sc.iter().flatten().next().copied().unwrap()];
                let mut v: Vec<ChkKey> = vec![];
                let mut seen = HashSet::new();
                for c in &set.checks {
                    let k = (c.data, c.clock, c.kind, c.clk_rise);
                    if seen.insert(k) {
                        v.push(k);
                    }
                }
                v
            };
            let fmt_v = |v: f64, cat: &str| -> String {
                if !v.is_finite() {
                    return String::new();
                }
                let v = if (neg_all || no_neg.contains(cat)) && v < 0.0 { 0.0 } else { v };
                let s = format!("{:.*}", dig, v * tk);
                if s.starts_with("-0") && s.trim_start_matches('-').chars().all(|c| c == '0' || c == '.') {
                    s[1..].to_string()
                } else {
                    s
                }
            };
            // triplet for an arc / check: values per pick
            let trip = |vs: Vec<f64>, cat: &str| -> String {
                if vs.iter().all(|v| !v.is_finite()) {
                    return "()".into();
                }
                if single.is_some() {
                    return format!("({})", fmt_v(vs[0], cat));
                }
                format!("({}:{}:{})", fmt_v(vs[0], cat), fmt_v(vs[1], cat), fmt_v(vs[2], cat))
            };
            let arc_trip = |k: &ArcKey, rf: usize, cat: &str| -> String { trip(tables.iter().map(|t| t.as_ref().and_then(|t| t.0.get(k)).map(|v| v[rf]).unwrap_or(f64::NAN)).collect(), cat) };
            let chk_trip = |k: &ChkKey, rf: usize| -> String { trip(tables.iter().map(|t| t.as_ref().and_then(|t| t.1.get(k)).map(|v| v[rf]).unwrap_or(f64::NAN)).collect(), "timing_checks") };
            let in_scope = |n: &str| -> Option<String> {
                match &inst {
                    None => Some(n.to_string()),
                    Some(p) => n.strip_prefix(&format!("{}/", p)).map(|s| s.to_string()),
                }
            };
            let pin_str = |pr: PinRef| -> Option<String> {
                match pr {
                    PinRef::Port(p) => if inst.is_some() { None } else { Some(esc_bus(&nl.ports[p].name, false)) },
                    PinRef::Cell(c, p) => in_scope(&nl.cell(c).name).map(|i| format!("{}/{}", esc(&i, true), esc_bus(&nl.cell(c).pins[p].name, false))),
                }
            };
            // header
            let mut s = String::new();
            let corner_of = |si: Option<usize>| si.and_then(|i| self.scens.get(i)).and_then(|sc| self.corners.iter().find(|c| c.name == sc.corner));
            let triple = |g: &dyn Fn(&crate::cons::Corner) -> Option<f64>| -> String {
                let v: Vec<String> = [sc[0], sc[1].or(sc[2]), sc[2]].iter().map(|s| corner_of(*s).and_then(|c| g(c)).map(|v| format!("{}", v)).unwrap_or_default()).collect();
                if single.is_some() {
                    let i = match single.unwrap() {
                        Pick::Min => 0,
                        Pick::Typ => 1,
                        Pick::Max => 2,
                    };
                    return v[i].clone();
                }
                format!("{}:{}:{}", v[0], v[1], v[2])
            };
            let _ = writeln!(s, "(DELAYFILE\n  (SDFVERSION \"{}\")\n  (DESIGN \"{}\")\n  (DATE \"{}\")\n  (VENDOR \"RSynth\")\n  (PROGRAM \"rsynth\")\n  (VERSION \"0.3\")\n  (DIVIDER /)", ver, inst.clone().unwrap_or(nl.name.clone()), stamp());
            let vt = triple(&|c| c.voltage);
            if vt.chars().any(|c| c.is_ascii_digit()) {
                let _ = writeln!(s, "  (VOLTAGE {})", vt);
            }
            let pt = corner_of(sc[2].or(sc[0])).map(|c| c.process_label.clone()).unwrap_or_default();
            if !pt.is_empty() {
                let _ = writeln!(s, "  (PROCESS \"{}\")", pt);
            }
            let tt = triple(&|c| c.temperature);
            if tt.chars().any(|c| c.is_ascii_digit()) {
                let _ = writeln!(s, "  (TEMPERATURE {})", tt);
            }
            let _ = writeln!(s, "  (TIMESCALE {})", if tk == 1.0 { "1ns" } else if tk == 10.0 { "100ps" } else { "1ps" });
            // interconnect in the top cell
            let mut n_ic = 0;
            if !no_ic {
                let mut body = String::new();
                for (k, cell, _) in &order {
                    if cell.is_some() {
                        continue;
                    }
                    let (Some(fs), Some(ts)) = (pin_str(k.0), pin_str(k.1)) else { continue };
                    n_ic += 1;
                    let r = arc_trip(k, 0, "net_delays");
                    let f = arc_trip(k, 1, "net_delays");
                    let _ = writeln!(body, "      (INTERCONNECT {} {} {}{})", fs, ts, r, if f != r { format!(" {}", f) } else { String::new() });
                }
                if n_ic > 0 {
                    let _ = writeln!(s, "  (CELL\n    (CELLTYPE \"{}\")\n    (INSTANCE)\n    (DELAY\n     (ABSOLUTE\n{}     )\n    )\n  )", inst.clone().map(|i| nl.hier.iter().find(|h| h.0 == i).map(|h| h.1.clone()).unwrap_or(i)).unwrap_or(nl.name.clone()), body);
                }
            }
            // per cell
            let mut by_cell: BTreeMap<usize, (Vec<ArcKey>, Vec<(ArcKey, bool)>)> = BTreeMap::new();
            for (k, cell, edge) in &order {
                if let Some(c) = cell {
                    let e = by_cell.entry(*c).or_default();
                    match edge {
                        Some(pos) => e.1.push((*k, *pos)),
                        None => e.0.push(*k),
                    }
                }
            }
            let mut chk_by_cell: BTreeMap<usize, Vec<ChkKey>> = BTreeMap::new();
            if !no_tc {
                for k in &ckeys {
                    if let PinRef::Cell(c, _) = k.0 {
                        chk_by_cell.entry(c).or_default().push(*k);
                    }
                }
            }
            let cells: Vec<usize> = by_cell.keys().chain(chk_by_cell.keys()).copied().collect::<std::collections::BTreeSet<_>>().into_iter().collect();
            let (mut n_io, mut n_tc, mut n_cells) = (0, 0, 0);
            let pname = |pr: PinRef| match pr {
                PinRef::Cell(c, p) => esc_bus(&nl.cell(c).pins[p].name, false),
                PinRef::Port(p) => esc_bus(&nl.ports[p].name, false),
            };
            for c in cells {
                let cl = nl.cell(c);
                let Some(iname) = in_scope(&cl.name) else { continue };
                n_cells += 1;
                let _ = writeln!(s, "  (CELL\n    (CELLTYPE \"{}\")\n    (INSTANCE {})", cl.lib().unwrap_or("?"), esc(&iname, true));
                if let Some((comb, launch)) = by_cell.get(&c) {
                    let _ = writeln!(s, "    (DELAY\n     (ABSOLUTE");
                    for k in comb {
                        n_io += 1;
                        let r = arc_trip(k, 0, "cell_delays");
                        let f = arc_trip(k, 1, "cell_delays");
                        let _ = writeln!(s, "      (IOPATH {} {} {} {})", pname(k.0), pname(k.1), r, f);
                    }
                    for (k, pos) in launch {
                        n_io += 1;
                        let r = arc_trip(k, 0, "cell_delays");
                        let f = arc_trip(k, 1, "cell_delays");
                        let _ = writeln!(s, "      (IOPATH ({} {}) {} {} {})", if *pos { "posedge" } else { "negedge" }, pname(k.0), pname(k.1), r, f);
                    }
                    let _ = writeln!(s, "     )\n    )");
                }
                if let Some(ks) = chk_by_cell.get(&c) {
                    let _ = writeln!(s, "    (TIMINGCHECK");
                    let mut done: HashSet<ChkKey> = HashSet::new();
                    for k in ks {
                        if done.contains(k) {
                            continue;
                        }
                        let ce = if k.3 { "posedge" } else { "negedge" };
                        // combined SETUPHOLD / RECREM
                        let pair = match k.2 {
                            "SETUP" if include.contains("SETUPHOLD") => Some(("SETUPHOLD", "HOLD")),
                            "RECOVERY" if include.contains("RECREM") => Some(("RECREM", "REMOVAL")),
                            _ => None,
                        };
                        if let Some((nm, other)) = pair {
                            let ok = (k.0, k.1, if other == "HOLD" { "HOLD" } else { "REMOVAL" }, k.3);
                            if ks.contains(&ok) {
                                done.insert(*k);
                                done.insert(ok);
                                for rf in 0..2 {
                                    n_tc += 1;
                                    let _ = writeln!(s, "      ({} ({} {}) ({} {}) {} {})", nm, if rf == 0 { "posedge" } else { "negedge" }, pname(k.0), ce, pname(k.1), chk_trip(k, rf), chk_trip(&ok, rf));
                                }
                                continue;
                            }
                        }
                        if (k.2 == "HOLD" && include.contains("SETUPHOLD")) || (k.2 == "REMOVAL" && include.contains("RECREM")) {
                            let partner = (k.0, k.1, if k.2 == "HOLD" { "SETUP" } else { "RECOVERY" }, k.3);
                            if ks.contains(&partner) {
                                continue;
                            }
                        }
                        done.insert(*k);
                        let (r, f) = (chk_trip(k, 0), chk_trip(k, 1));
                        if r == f {
                            n_tc += 1;
                            let _ = writeln!(s, "      ({} {} ({} {}) {})", k.2, pname(k.0), ce, pname(k.1), r);
                        } else {
                            n_tc += 2;
                            let _ = writeln!(s, "      ({} (posedge {}) ({} {}) {})", k.2, pname(k.0), ce, pname(k.1), r);
                            let _ = writeln!(s, "      ({} (negedge {}) ({} {}) {})", k.2, pname(k.0), ce, pname(k.1), f);
                        }
                    }
                    let _ = writeln!(s, "    )");
                }
                let _ = writeln!(s, "  )");
            }
            let _ = writeln!(s, ")");
            std::fs::write(&f, s).map_err(|e| Flow::Err(format!("write_sdf: {}: {}", f, e)))?;
            let what = match single {
                Some(Pick::Min) => "min",
                Some(Pick::Typ) => "typ",
                Some(Pick::Max) => "max",
                None => "min:typ:max",
            };
            crate::info!("SDF-100", "Wrote SDF {} '{}' ({} values, {}): {} cells, {} IOPATH, {} INTERCONNECT, {} timing checks", ver, f, what, lbl, n_cells, n_io, n_ic, n_tc);
            files.push(f);
        }
        Ok(to_list(&files))
    }

    // ------------------------------------------------------------------ read_sdf

    fn c_read_sdf(&mut self, a: &[String]) -> R {
        let x = args(a, &["-type", "-analysis_type", "-corner", "-corners", "-path", "-min_type", "-max_type"]);
        let Some(f) = x.pos.first().cloned() else { return err("read_sdf: file name required (SDF-010)") };
        let txt = std::fs::read_to_string(&f).map_err(|e| Flow::Err(format!("read_sdf: {}: {}", f, e)))?;
        // an SDF is corner specific: by default it applies to the corner of the current scenario
        let corners: Vec<String> = match x.get("-corners").or(x.get("-corner")) {
            Some(s) if s == "all" || s == "*" => vec![],
            Some(s) => split_list(s),
            None => self.active("setup").first().and_then(|i| self.scens.get(*i)).map(|s| vec![s.corner.clone()]).unwrap_or_default(),
        };
        let ty = x.get("-type").map(|s| s.to_lowercase()).unwrap_or_default();
        // which triplet field feeds early (min) and late (max) analysis
        let (fe, fl) = match ty.as_str() {
            "sdf_min" | "min" => (0, 0),
            "sdf_typ" | "typ" => (1, 1),
            "sdf_max" | "max" => (2, 2),
            _ => (x.get("-min_type").map(|s| if s.contains("typ") { 1 } else if s.contains("max") { 2 } else { 0 }).unwrap_or(0), x.get("-max_type").map(|s| if s.contains("typ") { 1 } else if s.contains("min") { 0 } else { 2 }).unwrap_or(2)),
        };
        let path = x.get("-path").cloned();
        // tokenizer: parens, quoted strings, atoms (with backslash escapes)
        let mut toks: Vec<String> = vec![];
        let mut cur = String::new();
        let mut it = txt.chars().peekable();
        while let Some(c) = it.next() {
            match c {
                '\\' => {
                    if let Some(n) = it.next() {
                        cur.push(n);
                    }
                }
                '(' | ')' => {
                    if !cur.is_empty() {
                        toks.push(std::mem::take(&mut cur));
                    }
                    toks.push(c.to_string());
                }
                '"' => {
                    let mut q = String::new();
                    for n in it.by_ref() {
                        if n == '"' {
                            break;
                        }
                        q.push(n);
                    }
                    toks.push(format!("\"{}\"", q));
                }
                c if c.is_whitespace() => {
                    if !cur.is_empty() {
                        toks.push(std::mem::take(&mut cur));
                    }
                }
                _ => cur.push(c),
            }
        }
        // tree
        #[derive(Debug)]
        enum N {
            A(String),
            L(Vec<N>),
        }
        fn parse(t: &[String], i: &mut usize) -> N {
            if t[*i] == "(" {
                *i += 1;
                let mut v = vec![];
                while *i < t.len() && t[*i] != ")" {
                    v.push(parse(t, i));
                }
                *i += 1;
                N::L(v)
            } else {
                *i += 1;
                N::A(t[*i - 1].clone())
            }
        }
        let mut i = 0;
        let root = if toks.is_empty() { N::L(vec![]) } else { parse(&toks, &mut i) };
        let N::L(top) = root else { return err("read_sdf: not an SDF file (SDF-011)") };
        let head = |v: &[N]| -> String {
            match v.first() {
                Some(N::A(s)) => s.to_uppercase(),
                _ => String::new(),
            }
        };
        if head(&top) != "DELAYFILE" {
            return err("read_sdf: missing DELAYFILE (SDF-011)");
        }
        let tscale = std::cell::Cell::new(1.0f64);
        let divider = std::cell::Cell::new('/');
        let nl = self.nl()?;
        let triple = |n: &N| -> [Option<f64>; 3] {
            match n {
                N::L(v) => {
                    let s: String = v.iter().filter_map(|x| if let N::A(a) = x { Some(a.clone()) } else { None }).collect::<Vec<_>>().join("");
                    if s.is_empty() {
                        return [None; 3];
                    }
                    let p: Vec<Option<f64>> = s.split(':').map(|x| x.parse::<f64>().ok()).collect();
                    if p.len() == 1 {
                        [p[0]; 3]
                    } else {
                        [p.first().copied().flatten(), p.get(1).copied().flatten(), p.get(2).copied().flatten()]
                    }
                }
                _ => [None; 3],
            }
        };
        let mut added: Vec<((String, String, String), AnnDelay)> = vec![];
        let (mut n_ok, mut n_miss, mut n_tc) = (0usize, 0usize, 0usize);
        let mut missing: Vec<String> = vec![];
        let resolve_pin = |inst: &str, pin: &str| -> Option<PinRef> {
            let dv = divider.get();
            let full = if inst.is_empty() { pin.to_string() } else { format!("{}{}{}", inst, dv, pin) };
            let full = full.replace(dv, "/");
            let full = match &path {
                Some(p) => format!("{}/{}", p, full),
                None => full,
            };
            if !full.contains('/') {
                if let Some(p) = nl.port_by_name(&full) {
                    return Some(PinRef::Port(p));
                }
            }
            let (c, p) = full.rsplit_once('/')?;
            let ci = nl.cell_by_name(c)?;
            let pi = nl.cell(ci).pins.iter().position(|x| x.name == p)?;
            Some(PinRef::Cell(ci, pi))
        };
        // INTERCONNECT through hierarchy boundaries lands on the last segment (boundary pin -> load)
        let net_arc_from = |from: PinRef, to: PinRef| -> PinRef {
            if let Some(n) = nl.pin_net(to) {
                if let Some(d @ PinRef::Cell(c, _)) = nl.driver(n) {
                    if nl.cell(c).is_hport() && d != from {
                        return d;
                    }
                }
            }
            from
        };
        let push = |from: PinRef, to: PinRef, vals: &[[Option<f64>; 3]], cell: bool, added: &mut Vec<_>| {
            let rv = vals.first().copied().unwrap_or([None; 3]);
            let fv = vals.get(1).copied().unwrap_or(rv);
            for (rf, v) in [(0usize, rv), (1usize, fv)] {
                for (early, fi) in [(true, fe), (false, fl)] {
                    if let Some(d) = v[fi] {
                        let ad = AnnDelay { from, to, rise: rf == 0, fall: rf == 1, max: !early, min: early, incr: false, value: d * tscale.get(), corners: corners.clone() };
                        added.push(((nl.pin_name(from), nl.pin_name(to), if cell { "cell".to_string() } else { "net".to_string() }), ad));
                    }
                }
            }
        };
        for item in &top[1..] {
            let N::L(v) = item else { continue };
            match head(v).as_str() {
                "TIMESCALE" => {
                    let s: String = v[1..].iter().filter_map(|x| if let N::A(a) = x { Some(a.clone()) } else { None }).collect::<Vec<_>>().join("").to_lowercase();
                    let num: f64 = s.trim_end_matches(|c: char| c.is_alphabetic()).parse().unwrap_or(1.0);
                    let u = s.trim_start_matches(|c: char| c.is_ascii_digit() || c == '.');
                    tscale.set(num * match u {
                        "ps" => 0.001,
                        "us" => 1000.0,
                        _ => 1.0,
                    });
                }
                "DIVIDER" => {
                    if let Some(N::A(d)) = v.get(1) {
                        divider.set(d.chars().next().unwrap_or('/'));
                    }
                }
                "CELL" => {
                    let mut inst = String::new();
                    for c in &v[1..] {
                        if let N::L(w) = c {
                            if head(w) == "INSTANCE" {
                                inst = w.get(1).and_then(|x| if let N::A(a) = x { Some(a.clone()) } else { None }).unwrap_or_default();
                                if inst == "*" {
                                    inst.clear();
                                }
                            }
                        }
                    }
                    for c in &v[1..] {
                        let N::L(w) = c else { continue };
                        match head(w).as_str() {
                            "DELAY" => {
                                for blk in &w[1..] {
                                    let N::L(b) = blk else { continue };
                                    let incr = head(b) == "INCREMENT";
                                    for e in &b[1..] {
                                        let N::L(e) = e else { continue };
                                        let kind = head(e);
                                        let pin_of = |n: &N| -> Option<String> {
                                            match n {
                                                N::A(s) => Some(s.clone()),
                                                N::L(l) => l.get(1).and_then(|x| if let N::A(a) = x { Some(a.clone()) } else { None }),
                                            }
                                        };
                                        let (from, to, rest) = match kind.as_str() {
                                            "IOPATH" | "INTERCONNECT" | "PORT" if e.len() >= 3 => (pin_of(&e[1]), pin_of(&e[2]), &e[3..]),
                                            _ => continue,
                                        };
                                        let vals: Vec<[Option<f64>; 3]> = rest.iter().filter(|r| matches!(r, N::L(_))).map(|r| triple(r)).collect();
                                        let (Some(fs), Some(ts)) = (from, to) else { continue };
                                        let (fp, tp) = if kind == "IOPATH" { (resolve_pin(&inst, &fs), resolve_pin(&inst, &ts)) } else { (resolve_pin("", &if inst.is_empty() { fs.clone() } else { format!("{}{}{}", inst, divider.get(), fs) }), resolve_pin("", &if inst.is_empty() { ts.clone() } else { format!("{}{}{}", inst, divider.get(), ts) })) };
                                        match (fp, tp) {
                                            (Some(fp), Some(tp)) => {
                                                let fp = if kind == "IOPATH" { fp } else { net_arc_from(fp, tp) };
                                                let before = added.len();
                                                push(fp, tp, &vals, kind == "IOPATH", &mut added);
                                                if incr {
                                                    for ad in added[before..].iter_mut() {
                                                        ad.1.incr = true;
                                                    }
                                                }
                                                n_ok += 1;
                                            }
                                            _ => {
                                                n_miss += 1;
                                                if missing.len() < 10 {
                                                    missing.push(format!("{} {} -> {} (instance '{}')", kind, fs, ts, inst));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            "TIMINGCHECK" => n_tc += w.len() - 1,
                            _ => {}
                        }
                    }
                }
                _ => {}
            }
        }
        let na = added.len();
        for (k, d) in added {
            self.ann_delays.retain(|(k2, d2)| !(k2.0 == k.0 && k2.1 == k.1 && d2.rise == d.rise && d2.fall == d.fall && d2.max == d.max && d2.min == d.min && d2.corners == d.corners));
            self.ann_delays.push((k, d));
        }
        self.bump_epoch();
        crate::info!("SDF-200", "Read SDF '{}' for corner(s) {}: {} delay entries annotated ({} arc values), {} not found in the design, {} timing checks read but not annotated (library checks are used)", f, if corners.is_empty() { "all".to_string() } else { corners.join(" ") }, n_ok, na, n_miss, n_tc);
        for m in &missing {
            crate::warn!("SDF-201", "read_sdf: no such arc in the design: {}", m);
        }
        Ok(n_ok.to_string())
    }
}

#[allow(dead_code)]
fn _unused(_: &Netlist) {}
