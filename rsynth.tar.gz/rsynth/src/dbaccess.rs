//! Innovus / Tempus-style object access for ECO automation:
//!   * `get_property obj prop` / `set_property obj prop value` (Tempus names mapped onto the
//!     native attributes; unknown names become user properties), `define_property`/
//!     `define_user_attribute`, FC-style `set_attribute`
//!   * `dbGet obj.prop.prop ...` with `top`/`head`, pointer lists, pattern filtering and
//!     `-p[N] -e -u -v -regexp`; `dbSet obj.prop value`; `dbGetInstByName`, `dbGetNetByName`,
//!     `dbGetTermByName`, `dbGetCellByName`, `dbGetInstTermByName`
//!   * Innovus ECO commands: `ecoChangeCell`, `ecoAddRepeater`, `ecoDeleteRepeater`,
//!     `ecoPlace`, `ecoRoute`, `setEcoMode`
//! All netlist edits go through the native ECO commands, so `write_eco_changes` records them.
use crate::cons::Obj;
use crate::netlist::{Dir, PinRef};
use crate::session::*;
use crate::tcl::{split_list, to_list, Flow};
use std::collections::HashMap;
type R = Result<String, Flow>;

pub const DB_ECO_CMDS: &[&str] = &["ecoChangeCell", "ecoAddRepeater", "ecoDeleteRepeater", "set_property", "set_attribute", "dbSet"];

const NULL: &str = "0x0";

fn bool_word(v: &str) -> Result<String, Flow> {
    match v.to_lowercase().as_str() {
        "true" | "1" | "yes" | "on" => Ok("true".into()),
        "false" | "0" | "no" | "off" => Ok("false".into()),
        _ => Err(Flow::Err(format!("set_property: expected a boolean, got '{}' (ATTR-006)", v))),
    }
}

fn fnum(x: f64) -> String {
    let s = format!("{:.4}", x);
    let s = s.trim_end_matches('0').trim_end_matches('.').to_string();
    if s == "-0" { "0".into() } else { s }
}

fn tempus_alias(p: &str) -> &str {
    match p {
        "timing_points" | "timing_point" => "points",
        "launching_point" => "startpoint",
        "capturing_point" => "endpoint",
        "launching_clock" => "startpoint_clock",
        "capturing_clock" => "endpoint_clock",
        "required_time" => "required",
        "arrival_time" => "arrival",
        "cppr_adjustment" => "crpr_value",
        "view_name" | "analysis_view" | "analysis_view_name" => "scenario",
        "transition_type" => "rise_fall",
        "hierarchical_name" => "full_name",
        "ref_lib_cell_name" | "lib_cell_name" | "cell_name" => "ref_name",
        _ => p,
    }
}

impl Session {
    pub(crate) fn db_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "get_property" | "get_db_property" => self.c_get_property(a),
            "set_property" | "set_attribute" => self.c_set_property(a),
            "define_property" | "define_user_attribute" | "define_attribute" => {
                let x = args(a, &["-type", "-classes", "-class", "-default", "-name"]);
                let n = x.get("-name").cloned().or(x.pos.first().cloned()).unwrap_or_default();
                if let Some(d) = x.get("-default") {
                    self.user_prop_defaults.insert(n.clone(), d.clone());
                }
                crate::info!("ATTR-001", "Defined user property '{}'", n);
                Ok(n)
            }
            "list_property" | "list_attributes" => Ok("slack arrival required startpoint endpoint timing_points pin hierarchical_name ref_lib_cell_name cell net direction location dont_touch size_only area is_sequential transition rise_fall".into()),
            "dbGet" => self.c_db_get(a),
            "dbSet" => self.c_db_set(a),
            "dbGetInstByName" | "dbGetNetByName" | "dbGetTermByName" | "dbGetCellByName" | "dbGetInstTermByName" | "dbGetTermByInstTermName" => {
                // accept a one-element list (e.g. from get_object_name) or an object handle
                let raw = a.first().cloned().unwrap_or_default();
                let l = split_list(&raw);
                let n0 = if l.len() == 1 { l[0].clone() } else { raw };
                let n = Obj::parse(&n0).map(|o| o.name().to_string()).unwrap_or(n0);
                let Some(nl) = self.nl.as_ref() else { return Some(Ok(NULL.into())) };
                let h = match name {
                    "dbGetInstByName" => nl.cell_by_name(&n).filter(|c| !nl.cell(*c).is_hport()).map(|_| Obj::Cell(n.clone()).handle()),
                    "dbGetNetByName" => nl.net_by_name(&n).map(|_| Obj::Net(n.clone()).handle()),
                    "dbGetTermByName" => nl.port_by_name(&n).map(|_| Obj::Port(n.clone()).handle()),
                    "dbGetCellByName" => self.libs.iter().any(|l| l.cells.contains_key(&n)).then(|| Obj::LibCell(n.clone()).handle()),
                    _ => nl.find_pin(&n).map(|_| Obj::Pin(n.clone()).handle()),
                };
                Ok(h.unwrap_or_else(|| NULL.into()))
            }
            "ecoChangeCell" => {
                let x = args(a, &["-inst", "-cell"]);
                let Some(inst) = x.get("-inst").cloned() else { return Some(Err(Flow::Err("ecoChangeCell: -inst <instName> is required".into()))) };
                let insts: Vec<String> = split_list(&inst).into_iter().map(|s| Obj::parse(&s).map(|o| o.name().to_string()).unwrap_or(s)).collect();
                if x.has("-upsize") || x.has("-downsize") {
                    let mut v = vec!["-inst".to_string(), to_list(&insts), if x.has("-upsize") { "-autoup".into() } else { "-autodown".into() }];
                    v.dedup();
                    return Some(self.cmd("eco_sizecell", &v).unwrap_or(Ok(String::new())));
                }
                let Some(cell) = x.get("-cell").cloned() else { return Some(Err(Flow::Err("ecoChangeCell: -cell <cellName> (or -upsize/-downsize) is required".into()))) };
                let cell = Obj::parse(&cell).map(|o| o.name().to_string()).unwrap_or(cell);
                if !self.libs.iter().any(|l| l.cells.contains_key(&cell)) {
                    return Some(Err(Flow::Err(format!("ecoChangeCell: cell '{}' not found in the libraries (ECO-002)", cell))));
                }
                let mut n = 0;
                for i in &insts {
                    let ok = self.nl.as_ref().map(|nl| nl.cell_by_name(i).is_some()).unwrap_or(false);
                    if !ok {
                        crate::error!("ECO-401", "ecoChangeCell: instance '{}' not found", i);
                        continue;
                    }
                    match self.cmd("size_cell", &[i.clone(), cell.clone()]) {
                        Some(Ok(r)) if r != "0" => {
                            n += 1;
                            crate::info!("ECO-400", "ecoChangeCell: {} -> {}", i, cell);
                        }
                        Some(Err(e)) => return Some(Err(e)),
                        _ => {}
                    }
                }
                Ok(n.to_string())
            }
            "ecoAddRepeater" => {
                let x = args(a, &["-net", "-cell", "-term", "-name", "-newNetName", "-loc", "-relativeDistToSink"]);
                let mut v = vec!["-cell".to_string(), x.get("-cell").cloned().unwrap_or_default()];
                if let Some(t) = x.get("-term") {
                    v.push("-pin".into());
                    v.push(t.clone());
                } else if let Some(n) = x.get("-net") {
                    v.push("-net".into());
                    v.push(n.clone());
                }
                if let Some(n) = x.get("-name") {
                    v.push("-name".into());
                    v.push(n.clone());
                }
                self.cmd("eco_add_repeater", &v).unwrap_or(Ok(String::new()))
            }
            "ecoDeleteRepeater" => {
                let x = args(a, &["-inst"]);
                let insts = x.get("-inst").cloned().or(x.pos.first().cloned()).unwrap_or_default();
                self.cmd("eco_delete_repeater", &[insts]).unwrap_or(Ok(String::new()))
            }
            "setEcoMode" | "getEcoMode" => {
                for w in a.chunks(2) {
                    if w.len() == 2 {
                        self.app.insert(format!("eco_mode.{}", w[0].trim_start_matches('-')), w[1].clone());
                    }
                }
                Ok(String::new())
            }
            "ecoPlace" => {
                if self.fp.is_none() {
                    crate::info!("ECO-410", "ecoPlace: no floorplan; nothing to place");
                    return Some(Ok(String::new()));
                }
                self.cmd("legalize_placement", &["-incremental".to_string()]).unwrap_or(Ok(String::new()))
            }
            "ecoRoute" => {
                if self.routes.is_none() {
                    crate::info!("ECO-411", "ecoRoute: design is not detail-routed; nothing to route");
                    return Some(Ok(String::new()));
                }
                self.cmd("route_eco", &[]).unwrap_or(Ok(String::new()))
            }
            _ => return None,
        })
    }

    /// property value of one object (Tempus names, native attributes, then user properties)
    pub(crate) fn prop_of(&self, h: &str, p: &str) -> Option<String> {
        let nl = self.nl.as_ref();
        let o = Obj::parse(h);
        // a few object-relation properties the native attribute table does not have
        match (&o, p) {
            (Some(Obj::Pin(n)), "cell" | "inst" | "instance") => {
                return nl.and_then(|nl| nl.find_pin(n)).and_then(|pr| match pr {
                    PinRef::Cell(c, _) => Some(Obj::Cell(nl.unwrap().cell(c).name.clone()).handle()),
                    _ => None,
                })
            }
            (Some(Obj::Pin(n)) | Some(Obj::Port(n)), "net") => {
                let nl = nl?;
                let pr = nl.find_pin(n)?;
                return nl.pin_net(pr).map(|x| Obj::Net(nl.net(x).name.clone()).handle());
            }
            (Some(Obj::Pin(n)), "is_hierarchical" | "is_hier") => {
                let nl = nl?;
                return Some(matches!(nl.find_pin(n)?, PinRef::Cell(c, _) if nl.cell(c).is_hport()).to_string());
            }
            (Some(Obj::Pin(n)) | Some(Obj::Port(n)), "location" | "pt" | "x_coordinate" | "y_coordinate" | "layer" | "layer_name" | "pin_layer") => {
                let nl = nl?;
                let pr = nl.find_pin(n)?;
                if matches!(p, "layer" | "layer_name" | "pin_layer") {
                    return Some(self.pin_layer(pr).unwrap_or_default());
                }
                return Some(match self.pin_phys(pr) {
                    None => String::new(),
                    Some(((x, y), _)) => match p {
                        "x_coordinate" => fnum(x),
                        "y_coordinate" => fnum(y),
                        _ => format!("{} {}", fnum(x), fnum(y)),
                    },
                });
            }
            (Some(Obj::Cell(c)), "lib_cell" | "ref_lib_cell") => {
                let nl = nl?;
                return nl.cell_by_name(c).and_then(|ci| nl.cell(ci).lib().map(|l| Obj::LibCell(l.to_string()).handle()));
            }
            (Some(Obj::Cell(c)), "dont_touch" | "is_dont_touch") => {
                let nl = nl?;
                return nl.cell_by_name(c).map(|ci| nl.cell(ci).dont_touch.to_string());
            }
            (Some(Obj::Cell(c)), "size_only" | "is_size_only") => {
                let nl = nl?;
                return nl.cell_by_name(c).map(|ci| nl.cell(ci).has_attr("size_only").to_string());
            }
            (Some(Obj::Cell(c)), "x_coordinate" | "y_coordinate") => {
                let nl = nl?;
                return nl.cell_by_name(c).and_then(|ci| nl.cell(ci).loc).map(|(x, y)| format!("{}", if p == "x_coordinate" { x } else { y }));
            }
            (Some(Obj::Cell(c)), "pins") => {
                let nl = nl?;
                let ci = nl.cell_by_name(c)?;
                return Some(to_list(&nl.cell(ci).pins.iter().map(|pp| Obj::Pin(format!("{}/{}", c, pp.name)).handle()).collect::<Vec<_>>()));
            }
            (
                Some(Obj::Net(n)),
                "leafpins" | "leaf_pins" | "leaf_pin" | "leafPins" | "leaf_load_pins" | "leaf_loads" | "leaf_driver_pins" | "leaf_drivers" | "leaf_driver" | "leaf_ports" | "num_leaf_pins" | "leaf_pin_count",
            ) => {
                // leaf pins of the whole logical net, through hierarchy boundaries (hierarchical
                // boundary pins are not leaves); top-level ports are reported by leaf_ports
                let nl = nl?;
                let id = nl.net_by_name(n)?;
                let conns = Session::leaf_conns(nl, id);
                let dir = |pr: &PinRef| match *pr {
                    PinRef::Cell(c, k) => nl.cell(c).pins[k].dir,
                    PinRef::Port(q) => nl.ports[q].dir,
                };
                let want = |pr: &PinRef| -> bool {
                    let is_port = matches!(pr, PinRef::Port(_));
                    match p {
                        "leaf_ports" => is_port,
                        "leaf_load_pins" | "leaf_loads" => !is_port && dir(pr) != Dir::Out,
                        "leaf_driver_pins" | "leaf_drivers" | "leaf_driver" => !is_port && dir(pr) != Dir::In,
                        _ => !is_port,
                    }
                };
                let mut v: Vec<String> = conns
                    .iter()
                    .filter(|x| want(x))
                    .map(|x| match *x {
                        PinRef::Port(q) => Obj::Port(nl.ports[q].name.clone()).handle(),
                        pr => Obj::Pin(nl.pin_name(pr)).handle(),
                    })
                    .collect();
                let mut seen = std::collections::HashSet::new();
                v.retain(|x| seen.insert(x.clone()));
                if p == "num_leaf_pins" || p == "leaf_pin_count" {
                    return Some(v.len().to_string());
                }
                return Some(to_list(&v));
            }
            (Some(Obj::Net(n)), "dont_touch" | "is_dont_touch") => {
                let nl = nl?;
                return nl.net_by_name(n).map(|x| nl.net(x).dont_touch.to_string());
            }
            (Some(Obj::LibCell(l)), "dont_use" | "is_dont_use") => {
                let n = l.rsplit('/').next().unwrap_or(l);
                return Some((self.dont_use.iter().any(|d| crate::netlist::glob(d, n)) || self.libs.iter().any(|x| x.cells.get(n).map(|c| c.dont_use).unwrap_or(false))).to_string());
            }
            (Some(Obj::Cell(c)), "dont_use" | "is_dont_use") => {
                let nl = nl?;
                let lc = nl.cell(nl.cell_by_name(c)?).lib()?.to_string();
                return self.prop_of(&Obj::LibCell(lc).handle(), "is_dont_use");
            }
            (Some(Obj::LibCell(l)), "area" | "name" | "full_name") => {
                let lc = self.libs.iter().find_map(|x| x.cells.get(l))?;
                return Some(if p == "area" { lc.area.to_string() } else { lc.name.clone() });
            }
            _ => {}
        }
        if let Some(v) = self.attr_pub(h, tempus_alias(p)) {
            return Some(v);
        }
        if let Some(v) = self.attr_pub(h, p) {
            return Some(v);
        }
        self.user_props.get(&(h.to_string(), p.to_string())).cloned().or_else(|| self.user_prop_defaults.get(p).cloned())
    }

    fn c_get_property(&mut self, a: &[String]) -> R {
        let x = args(a, &["-name", "-objects", "-scenario", "-scenarios", "-view"]);
        self.prop_scen.set(self.scen_opt(&x)?);
        let r = self.get_property_inner(&x);
        self.prop_scen.set(None);
        r
    }

    fn get_property_inner(&mut self, x: &A) -> R {
        let quiet = x.has("-quiet");
        let objs = x.get("-objects").cloned().or(x.pos.first().cloned()).unwrap_or_default();
        let p = x.get("-name").cloned().or(x.pos.get(1).cloned()).ok_or_else(|| Flow::Err("get_property <object(s)> <property> (CMD-001)".into()))?;
        let items = split_list(&objs);
        if items.is_empty() {
            return if quiet { Ok(String::new()) } else { Err(Flow::Err(format!("get_property: empty object list for property '{}' (ATTR-002)", p))) };
        }
        let mut vals = vec![];
        let mut missing = 0;
        for h in &items {
            match self.prop_of(h, &p) {
                Some(v) => vals.push(v),
                None => missing += 1,
            }
        }
        if missing == items.len() && !quiet {
            return Err(Flow::Err(format!("get_property: property '{}' does not exist for object '{}' (ATTR-003)", p, items[0])));
        }
        // collection-valued properties (points, pins, cells, ...) are flattened into one collection
        let is_coll = vals.iter().all(|v| { let it = split_list(v); !it.is_empty() && it.iter().all(|e| e.contains("::")) });
        Ok(if vals.len() == 1 {
            vals.remove(0)
        } else if is_coll {
            to_list(&vals.iter().flat_map(|v| split_list(v)).collect::<Vec<_>>())
        } else {
            to_list(&vals)
        })
    }

    fn c_set_property(&mut self, a: &[String]) -> R {
        let x = args(a, &["-name", "-objects", "-value"]);
        let objs = x.get("-objects").cloned().or(x.pos.first().cloned()).unwrap_or_default();
        let p = x.get("-name").cloned().or(x.pos.get(1).cloned()).ok_or_else(|| Flow::Err("set_property <object(s)> <property> <value> (CMD-001)".into()))?;
        let v = x.get("-value").cloned().or(x.pos.get(2).cloned()).unwrap_or_default();
        let items = split_list(&objs);
        let mut n = 0;
        for h in items {
            let o = Obj::parse(&h);
            match (&o, tempus_alias(&p)) {
                (Some(Obj::Cell(c)), "ref_name" | "lib_cell" | "ref_lib_cell" | "cell") => {
                    let lc = Obj::parse(&v).map(|o| o.name().to_string()).unwrap_or(v.clone());
                    if let Some(Err(e)) = self.cmd("size_cell", &[c.clone(), lc]) {
                        return Err(e);
                    }
                }
                (Some(Obj::Cell(_)) | Some(Obj::Net(_)), "dont_touch" | "is_dont_touch") => {
                    if let Some(Err(e)) = self.cmd("set_dont_touch", &[h.clone(), bool_word(&v)?]) {
                        return Err(e);
                    }
                }
                (Some(Obj::LibCell(_)), "dont_use" | "is_dont_use") => {
                    if let Some(Err(e)) = self.cmd("set_dont_use", &[h.clone(), bool_word(&v)?]) {
                        return Err(e);
                    }
                }
                (Some(Obj::Cell(c)), "dont_use" | "is_dont_use") => {
                    // dont_use is a library-cell property: applied to the instance's reference cell
                    let lc = self.nl.as_ref().and_then(|nl| nl.cell_by_name(c).and_then(|ci| nl.cell(ci).lib().map(|l| l.to_string())));
                    let Some(lc) = lc else { return Err(Flow::Err(format!("set_property: '{}' is not a mapped cell instance (ATTR-005)", c))) };
                    crate::info!("ATTR-010", "is_dont_use on instance '{}' applies to its library cell {} (all its instances)", c, lc);
                    if let Some(Err(e)) = self.cmd("set_dont_use", &[Obj::LibCell(lc).handle(), bool_word(&v)?]) {
                        return Err(e);
                    }
                }
                (Some(Obj::Cell(_)), "size_only" | "is_size_only") => {
                    if let Some(Err(e)) = self.cmd("set_size_only", &[h.clone(), v.clone()]) {
                        return Err(e);
                    }
                }
                (Some(Obj::Cell(c)), "location" | "x_coordinate" | "y_coordinate" | "pt" | "pt_x" | "pt_y") => {
                    let Some(nl) = self.nl.as_mut() else { continue };
                    let Some(ci) = nl.cell_by_name(c) else { continue };
                    let (ox, oy) = nl.cell(ci).loc.unwrap_or((0.0, 0.0));
                    let nums: Vec<f64> = split_list(&v.replace(['{', '}'], " ")).iter().filter_map(|s| s.parse().ok()).collect();
                    let loc = match p.as_str() {
                        "x_coordinate" | "pt_x" => (nums.first().copied().unwrap_or(ox), oy),
                        "y_coordinate" | "pt_y" => (ox, nums.first().copied().unwrap_or(oy)),
                        _ => (nums.first().copied().unwrap_or(ox), nums.get(1).copied().unwrap_or(oy)),
                    };
                    nl.cell_mut(ci).loc = Some(loc);
                    self.bump_epoch();
                    self.eco_changes.push(format!("set_property {{{}}} location {{{} {}}}", h, loc.0, loc.1));
                }
                _ => {
                    // user property (also on timing paths / points)
                    self.user_props.insert((h.clone(), p.clone()), v.clone());
                }
            }
            n += 1;
        }
        Ok(n.to_string())
    }

    /// routing layer of a pin's access shape: the lowest routing layer for cell pins, the
    /// assigned pin layer for ports (none for hierarchical pins or unassigned ports)
    pub(crate) fn pin_layer(&self, pr: PinRef) -> Option<String> {
        let nl = self.nl.as_ref()?;
        if let Some((_, _, l)) = self.routed_access(pr) {
            return self.routes.as_ref().and_then(|db| db.layers.get(l).map(|x| x.name.clone()));
        }
        let layers = self.route_layers();
        match pr {
            PinRef::Port(q) => {
                if let Some(i) = self.fp.as_ref().and_then(|f| f.pin_info.get(&nl.ports[q].name)) {
                    return Some(i.1.clone());
                }
                nl.ports[q].loc.map(|_| layers.get(2.min(layers.len().saturating_sub(1))).map(|l| l.name.clone()).unwrap_or_else(|| "M3".into()))
            }
            PinRef::Cell(c, _) => {
                if nl.cell(c).is_hport() {
                    return None;
                }
                Some(layers.first().map(|l| l.name.clone()).unwrap_or_else(|| "M1".into()))
            }
        }
    }

    /// physical pin-access point and layer of a leaf pin or port, as the detailed router uses it
    /// (cell pins spread across the cell width at its row, on the lowest routing layer; macro pins
    /// along the macro's bottom edge; ports at their placed location on their assigned layer).
    /// Hierarchical boundary pins and unplaced cells have no physical location.
    /// the detailed router's actual access node of a pin (after collision nudging), when routed
    fn routed_access(&self, pr: PinRef) -> Option<(f64, f64, usize)> {
        let db = self.routes.as_ref()?;
        let ep = self.epoch.get();
        {
            let c = self.phys_cache.borrow();
            if c.0 == ep {
                return c.1.get(&pr).copied();
            }
        }
        let mut m = HashMap::new();
        for rn in db.nets.values() {
            for (p, n) in &rn.pins {
                m.insert(*p, db.pos(*n));
            }
        }
        let r = m.get(&pr).copied();
        *self.phys_cache.borrow_mut() = (ep, m);
        r
    }

    pub(crate) fn pin_phys(&self, pr: PinRef) -> Option<((f64, f64), String)> {
        let nl = self.nl.as_ref()?;
        let layers = self.route_layers();
        if let Some((x, y, l)) = self.routed_access(pr) {
            let name = self.routes.as_ref().and_then(|db| db.layers.get(l).map(|x| x.name.clone())).unwrap_or_default();
            return Some(((x, y), name));
        }
        let lname = |i: usize| layers.get(i.min(layers.len().saturating_sub(1))).map(|l| l.name.clone()).unwrap_or_else(|| "M1".into());
        let g = {
            let gg = self.appf("route.detail.grid");
            if gg > 0.0 { gg } else { self.site_w() / 2.0 }
        };
        let (x0, y0) = self.fp.as_ref().map(|f| (f.die.0, f.die.1)).unwrap_or((0.0, 0.0));
        let snap = |v: f64, o: f64| o + ((v - o) / g).round() * g;
        match pr {
            PinRef::Port(q) => {
                let l = nl.ports[q].loc?;
                let lay = self.fp.as_ref().and_then(|f| f.pin_info.get(&nl.ports[q].name)).map(|i| i.1.clone()).unwrap_or_else(|| lname(2));
                Some(((snap(l.0, x0), snap(l.1, y0)), lay))
            }
            PinRef::Cell(c, i) => {
                let cl = nl.cell(c);
                if cl.is_hport() {
                    return None;
                }
                let l = cl.loc?;
                let rh = self.row_h();
                let width = cl.lib().and_then(|n| self.libs.iter().find_map(|x| x.cells.get(n))).map(|x| x.area / rh).unwrap_or(0.4);
                let np = cl.pins.len().max(1) as f64;
                let (px, py) = if matches!(cl.kind, crate::netlist::Kind::BlackBox(_)) || width > 8.0 {
                    let side = if matches!(cl.kind, crate::netlist::Kind::BlackBox(_)) { self.appf("place.macro_default_size") } else { width.sqrt().max(2.0) };
                    (l.0 - side / 2.0 + (i as f64 + 0.5) * side / np, l.1 - side / 2.0 - 2.0 * g)
                } else {
                    let w = width.max(g * 2.0);
                    (l.0 - w / 2.0 + (i as f64 + 0.5) * w / np, l.1)
                };
                Some(((snap(px, x0), snap(py, y0)), lname(0)))
            }
        }
    }

    // ------------------------------------------------------------------ dbGet

    fn db_children(&self, h: &str, seg: &str) -> Result<Vec<String>, String> {
        let nl = self.nl.as_ref().ok_or("no design")?;
        if h == NULL {
            return Ok(vec![NULL.into()]);
        }
        if h == "top" || h == "head" || h == "design::top" {
            return Ok(match seg {
                "name" => vec![nl.name.clone()],
                "insts" => nl.cell_ids().into_iter().filter(|c| !nl.cell(*c).is_hport()).map(|c| Obj::Cell(nl.cell(c).name.clone()).handle()).collect(),
                "nets" => nl.net_ids().into_iter().map(|n| Obj::Net(nl.net(n).name.clone()).handle()).collect(),
                "terms" => nl.port_ids().into_iter().map(|p| Obj::Port(nl.ports[p].name.clone()).handle()).collect(),
                "numInsts" => vec![nl.cell_ids().into_iter().filter(|c| !nl.cell(*c).is_hport()).count().to_string()],
                "numNets" => vec![nl.net_ids().len().to_string()],
                "numTerms" => vec![nl.port_ids().len().to_string()],
                "objType" => vec!["design".into()],
                "fPlan" | "head" | "top" => vec!["top".into()],
                "libCells" | "allCells" => self.libs.iter().flat_map(|l| l.cells.keys().map(|k| Obj::LibCell(k.clone()).handle())).collect(),
                _ => return Err(format!("unknown design property '{}'", seg)),
            });
        }
        let o = Obj::parse(h).ok_or_else(|| format!("'{}' is not a db object", h))?;
        let b = |x: bool| if x { "1".to_string() } else { "0".to_string() };
        Ok(match (&o, seg) {
            (_, "objType") => vec![match o {
                Obj::Cell(_) => "inst",
                Obj::Pin(_) => "instTerm",
                Obj::Net(_) => "net",
                Obj::Port(_) => "term",
                Obj::LibCell(_) => "cell",
                Obj::Clock(_) => "clock",
            }
            .into()],
            (Obj::Cell(c), _) => {
                let ci = nl.cell_by_name(c).ok_or_else(|| format!("instance '{}' not found", c))?;
                let cl = nl.cell(ci);
                match seg {
                    "name" => vec![cl.name.clone()],
                    "cell" => vec![cl.lib().map(|l| Obj::LibCell(l.to_string()).handle()).unwrap_or(NULL.into())],
                    "instTerms" | "allTerms" => cl.pins.iter().map(|p| Obj::Pin(format!("{}/{}", c, p.name)).handle()).collect(),
                    "pt" => vec![cl.loc.map(|(x, y)| format!("{} {}", x, y)).unwrap_or_else(|| "0 0".into())],
                    "pt_x" => vec![cl.loc.map(|l| l.0.to_string()).unwrap_or("0".into())],
                    "pt_y" => vec![cl.loc.map(|l| l.1.to_string()).unwrap_or("0".into())],
                    "box" => {
                        let (x, y) = cl.loc.unwrap_or((0.0, 0.0));
                        let w = cl.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|l| l.area / 1.6).unwrap_or(0.0);
                        vec![format!("{{{} {} {} {}}}", x, y, x + w, y + 1.6)]
                    }
                    "dontTouch" | "isDontTouch" => vec![b(cl.dont_touch)],
                    "isFixed" | "pStatus" | "placementStatus" => vec![if seg == "isFixed" { b(cl.fixed) } else if cl.fixed { "fixed".into() } else if cl.loc.is_some() { "placed".into() } else { "unplaced".into() }],
                    "isSequential" => vec![b(self.prop_of(h, "is_sequential").as_deref() == Some("true"))],
                    "area" => vec![self.prop_of(h, "area").unwrap_or("0".into())],
                    "isSpareGate" => vec![b(cl.has_attr("spare"))],
                    "isPhysOnly" => vec!["0".into()],
                    _ => return Err(format!("unknown inst property '{}'", seg)),
                }
            }
            (Obj::LibCell(l), _) => {
                let lc = self.libs.iter().find_map(|x| x.cells.get(l)).ok_or_else(|| format!("cell '{}' not found", l))?;
                match seg {
                    "name" => vec![lc.name.clone()],
                    "area" => vec![lc.area.to_string()],
                    "size_x" => vec![format!("{}", lc.area / 1.6)],
                    "size_y" => vec!["1.6".into()],
                    "isSequential" => vec![b(lc.seq.is_some())],
                    "isBuffer" => vec![b(lc.is_buf)],
                    "isInverter" => vec![b(lc.is_inv)],
                    "isDontUse" | "dontUse" => vec![b(lc.dont_use)],
                    "baseClass" => vec!["core".into()],
                    "terms" => lc.pins.iter().map(|p| p.name.clone()).collect(),
                    "vt" | "vtName" => vec![lc.vt.clone()],
                    _ => return Err(format!("unknown cell property '{}'", seg)),
                }
            }
            (Obj::Pin(p), _) => {
                let pr = nl.find_pin(p).ok_or_else(|| format!("instTerm '{}' not found", p))?;
                let dir = match pr {
                    PinRef::Cell(c, i) => nl.cell(c).pins[i].dir,
                    PinRef::Port(q) => nl.ports[q].dir,
                };
                match seg {
                    "name" => vec![p.clone()],
                    "inst" => vec![match pr {
                        PinRef::Cell(c, _) => Obj::Cell(nl.cell(c).name.clone()).handle(),
                        _ => NULL.into(),
                    }],
                    "net" => vec![nl.pin_net(pr).map(|n| Obj::Net(nl.net(n).name.clone()).handle()).unwrap_or(NULL.into())],
                    "isInput" => vec![b(dir == Dir::In)],
                    "isOutput" => vec![b(dir == Dir::Out)],
                    "cellTerm" | "term" => vec![p.rsplit('/').next().unwrap_or(p).to_string()],
                    "pt" => vec![self.pin_phys(pr).map(|((x, y), _)| format!("{} {}", fnum(x), fnum(y))).unwrap_or("0 0".into())],
                    "pt_x" | "pt_y" => vec![self.pin_phys(pr).map(|((x, y), _)| fnum(if seg == "pt_x" { x } else { y })).unwrap_or("0".into())],
                    "layer" => vec![self.pin_layer(pr).unwrap_or_default()],
                    "slack" | "slack_max" | "slack_min" | "slew_max" | "slew_min" | "arrival_max" | "arrival_min" | "load" | "pin_capacitance" => vec![self.prop_of(h, seg).unwrap_or_default()],
                    _ => return Err(format!("unknown instTerm property '{}'", seg)),
                }
            }
            (Obj::Net(n), _) => {
                let id = nl.net_by_name(n).ok_or_else(|| format!("net '{}' not found", n))?;
                let hp = |pr: PinRef| match pr {
                    PinRef::Port(q) => Obj::Port(nl.ports[q].name.clone()).handle(),
                    p => Obj::Pin(nl.pin_name(p)).handle(),
                };
                match seg {
                    "name" => vec![n.clone()],
                    "instTerms" => nl.net(id).conns.iter().filter(|p| matches!(p, PinRef::Cell(..))).map(|p| hp(*p)).collect(),
                    "terms" => nl.net(id).conns.iter().filter(|p| matches!(p, PinRef::Port(_))).map(|p| hp(*p)).collect(),
                    "allTerms" => nl.net(id).conns.iter().map(|p| hp(*p)).collect(),
                    "leafInstTerms" | "leafPins" => Session::leaf_conns(nl, id).into_iter().filter(|p| matches!(p, PinRef::Cell(..))).map(hp).collect(),
                    "leafTerms" => Session::leaf_conns(nl, id).into_iter().filter(|p| matches!(p, PinRef::Port(_))).map(hp).collect(),
                    "numInputTerms" => vec![nl.loads(id).len().to_string()],
                    "numOutputTerms" => vec![nl.drivers(id).len().to_string()],
                    "dontTouch" => vec![b(nl.net(id).dont_touch)],
                    _ => return Err(format!("unknown net property '{}'", seg)),
                }
            }
            (Obj::Port(n), _) => {
                let q = nl.port_by_name(n).ok_or_else(|| format!("term '{}' not found", n))?;
                match seg {
                    "name" => vec![n.clone()],
                    "net" => vec![nl.ports[q].net.map(|x| Obj::Net(nl.net(x).name.clone()).handle()).unwrap_or(NULL.into())],
                    "isInput" => vec![b(nl.ports[q].dir == Dir::In)],
                    "isOutput" => vec![b(nl.ports[q].dir == Dir::Out)],
                    "pt" => vec![nl.ports[q].loc.map(|(x, y)| format!("{} {}", fnum(x), fnum(y))).unwrap_or("0 0".into())],
                    "layer" => vec![self.pin_layer(PinRef::Port(q)).unwrap_or_default()],
                    _ => return Err(format!("unknown term property '{}'", seg)),
                }
            }
            (Obj::Clock(c), "name") => vec![c.clone()],
            _ => return Err(format!("unknown property '{}'", seg)),
        })
    }

    /// split "objects.prop.prop" — the object part may itself contain dots (hierarchical names)
    fn db_split(&self, e: &str) -> (String, Vec<String>) {
        let is_ident = |s: &str| !s.is_empty() && s.chars().next().unwrap().is_ascii_alphabetic() && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '_');
        for root in ["top", "head"] {
            if e == root || e.starts_with(&format!("{}.", root)) {
                return (root.to_string(), e.split('.').skip(1).map(|s| s.to_string()).collect());
            }
        }
        let mut obj = e.to_string();
        let mut segs = vec![];
        while let Some(i) = obj.rfind('.') {
            let tail = &obj[i + 1..];
            // stop at the object part: handles look like kind::name, names contain / [ ]
            if !is_ident(tail) || !obj[..i].contains("::") && obj[..i] != *NULL {
                break;
            }
            segs.push(tail.to_string());
            obj.truncate(i);
        }
        segs.reverse();
        (obj, segs)
    }

    fn c_db_get(&mut self, a: &[String]) -> R {
        let mut up = 0usize;
        let (mut empty_ok, mut uniq, mut inv, mut rx) = (false, false, false, false);
        let mut pos = vec![];
        for x in a {
            match x.as_str() {
                "-p" => up = 1,
                s if s.starts_with("-p") && s[2..].parse::<usize>().is_ok() => up = s[2..].parse().unwrap(),
                "-e" => empty_ok = true,
                "-u" => uniq = true,
                "-v" => inv = true,
                "-regexp" => rx = true,
                "-d" | "-i" => {}
                _ => pos.push(x.clone()),
            }
        }
        let expr = pos.first().cloned().ok_or_else(|| Flow::Err("dbGet <object>.<property>... [pattern] (CMD-001)".into()))?;
        let pat = pos.get(1).cloned();
        let (objs, segs) = self.db_split(&expr);
        // (value, ancestry chain)
        let mut cur: Vec<(String, Vec<String>)> = split_list(&objs).into_iter().map(|o| (o.clone(), vec![o])).collect();
        if cur.is_empty() {
            return Ok(if empty_ok { String::new() } else { NULL.into() });
        }
        for s in &segs {
            let mut next = vec![];
            for (v, chain) in &cur {
                if v == NULL {
                    next.push((NULL.to_string(), chain.clone()));
                    continue;
                }
                let kids = self.db_children(v, s).map_err(|e| Flow::Err(format!("dbGet: {} (DB-001)", e)))?;
                for k in kids {
                    let mut c = chain.clone();
                    c.push(k.clone());
                    next.push((k, c));
                }
            }
            cur = next;
        }
        if let Some(p) = &pat {
            let re = if rx { crate::regex::Regex::new(p).ok() } else { None };
            cur.retain(|(v, _)| {
                let m = match &re {
                    Some(r) => r.is_match(v),
                    None => crate::netlist::glob(p, v),
                };
                m != inv
            });
        }
        let mut out: Vec<String> = cur.iter().map(|(v, c)| if up > 0 && c.len() > up { c[c.len() - 1 - up].clone() } else { v.clone() }).collect();
        if uniq {
            let mut seen = std::collections::HashSet::new();
            out.retain(|x| seen.insert(x.clone()));
        }
        if out.is_empty() {
            return Ok(if empty_ok || pat.is_none() { String::new() } else { NULL.into() });
        }
        Ok(if out.len() == 1 { out.remove(0) } else { to_list(&out) })
    }

    fn c_db_set(&mut self, a: &[String]) -> R {
        let expr = a.first().cloned().ok_or_else(|| Flow::Err("dbSet <object>.<property> <value> (CMD-001)".into()))?;
        let v = a.get(1).cloned().unwrap_or_default();
        let (objs, segs) = self.db_split(&expr);
        let Some(p) = segs.last().cloned() else { return Err(Flow::Err("dbSet: no property given (DB-002)".into())) };
        let mut targets = split_list(&objs);
        for s in &segs[..segs.len() - 1] {
            let mut n = vec![];
            for t in &targets {
                n.extend(self.db_children(t, s).map_err(|e| Flow::Err(format!("dbSet: {} (DB-001)", e)))?);
            }
            targets = n;
        }
        let prop = match p.as_str() {
            "dontTouch" | "isDontTouch" => "dont_touch",
            "pt" => "location",
            "pt_x" => "x_coordinate",
            "pt_y" => "y_coordinate",
            "cell" => "ref_name",
            "pStatus" | "placementStatus" => "placement_status",
            o => o,
        };
        let val = if prop == "dont_touch" { if v == "1" || v == "true" { "true".to_string() } else { "false".into() } } else { v };
        self.c_set_property(&[to_list(&targets), prop.to_string(), val])
    }
}
