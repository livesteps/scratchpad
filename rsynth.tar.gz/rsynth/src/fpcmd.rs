//! Floorplan / IO-planning / global-route / place_opt commands (Fusion-Compiler-style).
//! Every object is stored in the session floorplan and honored by placement,
//! pin placement and global routing; objects survive a re-read of DEF.

use crate::fplan::*;
use crate::netlist::*;
use crate::phys::Floorplan;
use crate::session::{args, e2f, ok, Session};
use crate::tcl::{err, split_list, to_list, Flow, R};
use std::collections::HashSet;

pub fn parse_rect(s: &str) -> Option<Rect> {
    let v: Vec<f64> = s.split(|c: char| c.is_whitespace() || c == '{' || c == '}' || c == ',').filter_map(|x| x.parse().ok()).collect();
    if v.len() < 4 {
        return None;
    }
    let xs: Vec<f64> = v.iter().step_by(2).copied().collect();
    let ys: Vec<f64> = v.iter().skip(1).step_by(2).copied().collect();
    Some((xs.iter().cloned().fold(f64::MAX, f64::min), ys.iter().cloned().fold(f64::MAX, f64::min), xs.iter().cloned().fold(f64::MIN, f64::max), ys.iter().cloned().fold(f64::MIN, f64::max)))
}
fn nums(s: &str) -> Vec<f64> {
    s.split(|c: char| c.is_whitespace() || c == '{' || c == '}' || c == ',').filter_map(|x| x.parse().ok()).collect()
}
fn names(s: &str) -> Vec<String> {
    split_list(s).into_iter().map(|x| crate::cons::Obj::parse(&x).map(|o| o.name().to_string()).unwrap_or(x)).collect()
}
pub(crate) fn fmt_r(r: &Rect) -> String {
    format!("({:.2},{:.2})-({:.2},{:.2})", r.0, r.1, r.2, r.3)
}

impl Session {
    fn fpm(&mut self) -> Result<&mut Floorplan, Flow> {
        self.fp.as_mut().ok_or_else(|| Flow::Err("No floorplan: run read_def or initialize_floorplan first (FP-001)".into()))
    }
    fn port_names(&self, s: &str) -> Vec<String> {
        let mut v = vec![];
        for o in self.objs(s, "port") {
            if let crate::cons::Obj::Port(p) = o {
                v.push(p);
            }
        }
        v
    }

    /// regions that block routing of non-member nets (exclusive bounds and partitions)
    pub(crate) fn no_feed_regions(&self) -> Vec<(String, Rect)> {
        let Some(fp) = &self.fp else { return vec![] };
        let mut v: Vec<(String, Rect)> = fp.bounds.iter().filter(|b| b.kind == BoundKind::Exclusive).filter_map(|b| b.resolved.map(|r| (b.name.clone(), r))).collect();
        for p in &self.partitions {
            if let Some(b) = &p.bound {
                if let Some(r) = fp.bounds.iter().find(|x| &x.name == b).and_then(|x| x.resolved) {
                    if !v.iter().any(|x| x.0 == *b) {
                        v.push((p.name.clone(), r));
                    }
                }
            }
        }
        v
    }

    pub(crate) fn auto_pins(&mut self) {
        let (Some(fp), Some(nl)) = (self.fp.as_mut(), self.nl.as_mut()) else { return };
        let fixed = fp.fixed_ports.clone();
        let mut info = fp.pin_info.clone();
        let st = place_pins(nl, fp.die, &fp.block_pins, &fp.pin_cons, &fp.bundles, &fp.layers, &fixed, &mut info);
        fp.pin_info = info;
        crate::info!("PIN-100", "Pin placement: {} fixed (DEF/location), {} placed ({} bundle(s)){}", st.fixed, st.placed, st.bundles, if st.failed.is_empty() { String::new() } else { format!(", {} failed", st.failed.len()) });
        for f in &st.failed {
            crate::warn!("PIN-110", "{}", f);
        }
    }

    pub(crate) fn fp_place(&mut self, incremental: bool) -> Result<PlaceStats, Flow> {
        let rbd = self.appf("place.routing_blockage_density");
        let maxd = self.appf("place.coarse.max_density").clamp(0.05, 1.0);
        let iters = self.appu("place.coarse.iterations").max(1);
        let bin = self.appf("place.bin_size");
        let mut fp = self.fp.take().ok_or_else(|| Flow::Err("No floorplan (FP-001)".into()))?;
        let libs = &self.libs;
        let nl = match self.nl.as_mut() {
            Some(n) => n,
            None => {
                self.fp = Some(fp);
                return err("No design (UID-109)");
            }
        };
        if !incremental {
            for c in nl.cell_ids() {
                if !nl.cell(c).fixed {
                    nl.cell_mut(c).loc = None;
                }
            }
        }
        { let pr = fp.place_region(); resolve_bounds(nl, &mut fp.bounds, pr); }
        let area_of = |c: &Cell| -> f64 {
            match &c.kind {
                Kind::Lib(l) => libs.iter().find_map(|x| x.cells.get(l)).map(|x| x.area).unwrap_or(1.0),
                Kind::Gen(_) => 1.0,
                Kind::BlackBox(_) => 0.0,
            }
        };
        let binsz = if bin > 0.0 { bin } else { ((fp.die.2 - fp.die.0).min(fp.die.3 - fp.die.1) / 12.0).max(1.0) };
        let st = {
            let pb = place_blockages(&fp, rbd);
            let cx = Ctx { die: fp.place_region(), pblk: &pb, bounds: &fp.bounds, area_of: &area_of };
            let s = place(nl, &cx, iters, maxd, binsz);
            // group bounds: re-center on final member locations, then re-project
            s
        };
        if fp.bounds.iter().any(|b| b.rect.is_none()) {
            { let pr = fp.place_region(); resolve_bounds(nl, &mut fp.bounds, pr); }
        }
        fp.groute = None;
        self.fp = Some(fp);
        // pins follow the new placement
        self.auto_pins();
        Ok(st)
    }

    /// project all movable cells into legal regions and spread density (after optimization moves)
    pub(crate) fn fp_enforce(&mut self) -> Result<(), Flow> {
        let rbd = self.appf("place.routing_blockage_density");
        let maxd = self.appf("place.coarse.max_density").clamp(0.05, 1.0);
        let bin = self.appf("place.bin_size");
        let Some(fp) = self.fp.as_mut() else { return Ok(()) };
        let libs = &self.libs;
        let Some(nl) = self.nl.as_mut() else { return Ok(()) };
        let area_of = |c: &Cell| -> f64 {
            match &c.kind {
                Kind::Lib(l) => libs.iter().find_map(|x| x.cells.get(l)).map(|x| x.area).unwrap_or(1.0),
                _ => 1.0,
            }
        };
        let binsz = if bin > 0.0 { bin } else { ((fp.die.2 - fp.die.0).min(fp.die.3 - fp.die.1) / 12.0).max(1.0) };
        let pb = place_blockages(&fp, rbd);
            let cx = Ctx { die: fp.place_region(), pblk: &pb, bounds: &fp.bounds, area_of: &area_of };
        place(nl, &cx, 1, maxd, binsz);
        Ok(())
    }

    pub(crate) fn fp_route(&mut self, quiet: bool) -> Result<GRoute, Flow> {
        let gsz = self.appf("route.global.gcell_size");
        let nfr = self.no_feed_regions();
        let fp = self.fp.as_ref().ok_or_else(|| Flow::Err("No floorplan (FP-001)".into()))?;
        let nl = self.nl()?;
        let g = if gsz > 0.0 { gsz } else { ((fp.die.2 - fp.die.0).max(fp.die.3 - fp.die.1) / 40.0).max(fp.row_h.max(1.0)) };
        let skip: HashSet<NetId> = nl.net_ids().into_iter().filter(|n| crate::genopt::const_of(nl, *n).is_some()).collect();
        // feedthroughs may name a partition: translate to the region that implements it
        let feeds: Vec<Feedthrough> = fp.feeds.iter().map(|f| {
            let mut f = f.clone();
            if let Some(p) = self.partitions.iter().find(|p| p.name == f.region) {
                if let Some(b) = &p.bound {
                    if nfr.iter().any(|r| &r.0 == b) {
                        f.region = b.clone();
                    }
                }
            }
            f
        }).collect();
        // -min_layer / -max_layer: global route capacity only from the layers in range
        let lay: Vec<_> = fp.layers.iter().enumerate().filter(|(i, _)| self.rt.min_layer.map(|m| *i >= m || *i == 0).unwrap_or(true) && self.rt.max_layer.map(|m| *i <= m).unwrap_or(true)).map(|x| x.1.clone()).collect();
        let rc = RouteCtx { die: fp.place_region(), gcell: g, layers: &lay, rblk: &fp.rblk, guides: &fp.guides, bounds: &fp.bounds, feeds: &feeds, no_feed_regions: nfr };
        let gr = global_route(nl, &rc, &skip);
        if !quiet || gr.overflow > 0.0 {
            crate::info!("GR-100", "Global route: {}x{} gcells ({:.2}um), wirelength {:.1}um, overflow {:.1} in {} gcell(s), max utilization {:.0}%, {} detoured net(s), {} feedthrough use(s){}", gr.nx, gr.ny, gr.gcell, gr.wirelength, gr.overflow, gr.overflow_cells, gr.max_util * 100.0, gr.detoured.len(), gr.feed_used.len(), if gr.unroutable.is_empty() { String::new() } else { format!(", {} UNROUTABLE", gr.unroutable.len()) });
        }
        for u in gr.unroutable.iter().take(10) {
            crate::warn!("GR-110", "Net '{}' cannot reach all pins (blocked by routing blockages or physical hierarchy without feedthrough)", u);
        }
        let r = gr.clone();
        self.fp.as_mut().unwrap().groute = Some(gr);
        Ok(r)
    }

    pub fn fp_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "initialize_floorplan" | "create_floorplan" => self.c_init_fp(a),
            "create_placement_blockage" => {
                let x = args(a, &["-name", "-boundary", "-type", "-blocked_percentage"]);
                let Some(r) = x.get("-boundary").and_then(|b| parse_rect(b)) else { return Some(err("create_placement_blockage: -boundary {{x1 y1} {x2 y2}} required")) };
                let kind = match x.get("-type").map(|s| s.as_str()).unwrap_or("hard") {
                    "soft" => PbKind::Soft,
                    "partial" => PbKind::Partial(x.num("-blocked_percentage").unwrap_or(50.0)),
                    "hard_macro" => PbKind::HardMacro,
                    _ => PbKind::Hard,
                };
                let fp = match self.fpm() {
                    Ok(f) => f,
                    Err(e) => return Some(Err(e)),
                };
                let n = x.get("-name").cloned().unwrap_or_else(|| fp.fresh("pblk"));
                crate::info!("FP-200", "Placement blockage '{}' {:?} {}", n, kind, fmt_r(&r));
                fp.pblk.retain(|b| b.name != n);
                fp.pblk.push(PBlockage { name: n.clone(), rect: r, kind, source: "user".into() });
                Ok(n)
            }
            "create_routing_blockage" | "create_route_blockage" => {
                let x = args(a, &["-name", "-boundary", "-layers", "-net_types"]);
                let Some(r) = x.get("-boundary").and_then(|b| parse_rect(b)) else { return Some(err(format!("{}: -boundary required", name))) };
                let layers = x.get("-layers").map(|l| split_list(l)).unwrap_or_default();
                let fp = match self.fpm() {
                    Ok(f) => f,
                    Err(e) => return Some(Err(e)),
                };
                for l in &layers {
                    if !fp.layers.iter().any(|x| &x.name == l) {
                        crate::warn!("FP-301", "Routing layer '{}' is not defined (route.layers)", l);
                    }
                }
                let n = x.get("-name").cloned().unwrap_or_else(|| fp.fresh("rblk"));
                crate::info!("FP-300", "Routing blockage '{}' on {} {}", n, if layers.is_empty() { "all layers".into() } else { layers.join(",") }, fmt_r(&r));
                fp.rblk.retain(|b| b.name != n);
                fp.rblk.push(RBlockage { name: n.clone(), rect: r, layers, source: "user".into() });
                Ok(n)
            }
            "create_routing_guide" | "create_route_guide" => {
                let x = args(a, &["-name", "-boundary", "-layers", "-nets", "-track_utilization", "-horizontal_track_utilization", "-vertical_track_utilization"]);
                let Some(r) = x.get("-boundary").and_then(|b| parse_rect(b)) else { return Some(err(format!("{}: -boundary required", name))) };
                let nets = x.get("-nets").map(|s| names(s)).unwrap_or_default();
                let tu = x.num("-track_utilization").or(x.num("-horizontal_track_utilization")).or(x.num("-vertical_track_utilization"));
                let layers = x.get("-layers").map(|l| split_list(l)).unwrap_or_default();
                if nets.is_empty() && tu.is_none() {
                    crate::warn!("FP-401", "{}: neither -nets nor -track_utilization given; guide has no effect", name);
                }
                let fp = match self.fpm() {
                    Ok(f) => f,
                    Err(e) => return Some(Err(e)),
                };
                let n = x.get("-name").cloned().unwrap_or_else(|| fp.fresh("rguide"));
                crate::info!("FP-400", "Route guide '{}' {} nets={:?} track_util={:?}", n, fmt_r(&r), nets, tu);
                fp.guides.retain(|b| b.name != n);
                fp.guides.push(RGuide { name: n.clone(), rect: r, layers, nets, track_util: tu });
                Ok(n)
            }
            "create_bound" | "create_group_bound" | "create_move_bound" => {
                let x = args(a, &["-name", "-boundary", "-dimensions", "-type", "-effort"]);
                let rect = x.get("-boundary").and_then(|b| parse_rect(b));
                let dims = x.get("-dimensions").map(|d| nums(d)).filter(|v| v.len() >= 2).map(|v| (v[0], v[1]));
                if rect.is_none() && dims.is_none() {
                    return Some(err("create_bound: -boundary or -dimensions required"));
                }
                let kind = match x.get("-type").map(|s| s.as_str()).unwrap_or("soft") {
                    "hard" => BoundKind::Hard,
                    "exclusive" => BoundKind::Exclusive,
                    _ => BoundKind::Soft,
                };
                let mut members = vec![];
                for p in &x.pos {
                    members.extend(names(p));
                }
                let n_cells = self.nl.as_ref().map(|nl| nl.cell_ids().iter().filter(|c| member_of(&nl.cell(**c).name, &members)).count()).unwrap_or(0);
                if n_cells == 0 && !members.is_empty() {
                    crate::warn!("FP-501", "create_bound: no cells match {:?}", members);
                }
                let fp = match self.fpm() {
                    Ok(f) => f,
                    Err(e) => return Some(Err(e)),
                };
                let n = x.get("-name").cloned().unwrap_or_else(|| fp.fresh("bound"));
                if let Some(r) = rect {
                    if overlap(&r, &fp.die) < area(&r) * 0.999 {
                        crate::warn!("FP-502", "Bound '{}' extends outside the die", n);
                    }
                }
                crate::info!("FP-500", "{:?} bound '{}' {} with {} cell(s){}", kind, n, rect.map(|r| fmt_r(&r)).unwrap_or(format!("(group bound {:?})", dims)), n_cells, if kind == BoundKind::Exclusive { "; blocks non-member placement and routing feedthrough" } else { "" });
                fp.bounds.retain(|b| b.name != n);
                fp.bounds.push(Bound { name: n.clone(), kind, rect, dims, members, source: "user".into(), resolved: rect });
                Ok(n)
            }
            "create_feedthrough" | "set_feedthrough" => {
                let x = args(a, &["-name", "-region", "-bound", "-partition", "-nets", "-side"]);
                let region = x.get("-region").or(x.get("-bound")).or(x.get("-partition")).cloned().unwrap_or_default();
                let nets = x.get("-nets").map(|s| names(s)).unwrap_or(x.pos.iter().flat_map(|p| names(p)).collect());
                let known = self.no_feed_regions().iter().any(|r| r.0 == region) || self.partitions.iter().any(|p| p.name == region && p.bound.is_some());
                if !known {
                    crate::warn!("FP-601", "create_feedthrough: '{}' is not an exclusive bound or partition region (feedthrough has no effect)", region);
                }
                let fp = match self.fpm() {
                    Ok(f) => f,
                    Err(e) => return Some(Err(e)),
                };
                let n = x.get("-name").cloned().unwrap_or_else(|| fp.fresh("ft"));
                crate::info!("FP-600", "Feedthrough '{}': {} net pattern(s) may route through '{}'{}", n, nets.len(), region, x.get("-side").map(|s| format!(" (side {})", s)).unwrap_or_default());
                fp.feeds.push(Feedthrough { name: n.clone(), region, nets, side: x.get("-side").cloned() });
                Ok(n)
            }
            "set_block_pin_constraints" => {
                let x = args(a, &["-allowed_layers", "-sides", "-pin_spacing", "-corner_keepout_distance", "-group_buses", "-layer_assignment", "-pin_width", "-pin_length"]);
                let fp = match self.fpm() {
                    Ok(f) => f,
                    Err(e) => return Some(Err(e)),
                };
                if let Some(l) = x.get("-allowed_layers") {
                    fp.block_pins.layers = split_list(l);
                }
                if let Some(s) = x.get("-sides") {
                    fp.block_pins.sides = split_list(s).iter().map(|x| side_name(x)).filter(|x| !x.is_empty()).collect();
                }
                if let Some(v) = x.num("-pin_spacing") {
                    fp.block_pins.spacing = v;
                }
                if let Some(v) = x.num("-corner_keepout_distance") {
                    fp.block_pins.corner_keepout = v;
                }
                if let Some(v) = x.get("-group_buses") {
                    fp.block_pins.group_buses = v == "true" || v == "1";
                }
                if let Some(v) = x.get("-layer_assignment") {
                    if !["first", "balanced", "round_robin"].contains(&v.as_str()) {
                        return Some(err(format!("set_block_pin_constraints: -layer_assignment must be first, balanced or round_robin (got '{}')", v)));
                    }
                    fp.block_pins.layer_assignment = v.clone();
                }
                if let Some(v) = x.num("-pin_width") {
                    fp.block_pins.pin_width = Some(v);
                }
                if let Some(v) = x.num("-pin_length") {
                    fp.block_pins.pin_length = Some(v);
                }
                crate::info!("PIN-200", "Block pin constraints: sides {:?}, layers {:?} ({} assignment), spacing {}, corner keepout {}, bus grouping {}", fp.block_pins.sides, fp.block_pins.layers, fp.block_pins.layer_assignment, fp.block_pins.spacing, fp.block_pins.corner_keepout, fp.block_pins.group_buses);
                ok()
            }
            "set_individual_pin_constraints" => {
                let x = args(a, &["-ports", "-sides", "-offset", "-location", "-allowed_layers"]);
                let ports = x.get("-ports").map(|p| self.port_names(p)).unwrap_or_default();
                if ports.is_empty() {
                    return Some(err("set_individual_pin_constraints: -ports matched nothing"));
                }
                let sides: Vec<String> = x.get("-sides").map(|s| split_list(s).iter().map(|x| side_name(x)).filter(|x| !x.is_empty()).collect()).unwrap_or_default();
                let loc = x.get("-location").map(|l| nums(l)).filter(|v| v.len() >= 2).map(|v| (v[0], v[1]));
                let fp = match self.fpm() {
                    Ok(f) => f,
                    Err(e) => return Some(Err(e)),
                };
                for p in &ports {
                    fp.pin_cons.retain(|c| &c.port != p);
                    fp.pin_cons.push(PinCons { port: p.clone(), sides: sides.clone(), offset: x.num("-offset"), location: loc, layers: x.get("-allowed_layers").map(|l| split_list(l)).unwrap_or_default() });
                }
                crate::info!("PIN-210", "Individual pin constraints on {} port(s)", ports.len());
                ok()
            }
            "create_bundle" | "create_pin_group" => {
                let x = args(a, &["-name", "-order", "-sides", "-offset", "-pin_spacing", "-allowed_layers"]);
                let mut ports = vec![];
                for p in &x.pos {
                    ports.extend(self.port_names(p));
                }
                if ports.is_empty() {
                    return Some(err(format!("{}: no ports given", name)));
                }
                let order = x.get("-order").cloned().unwrap_or(if x.has("-interleave") { "interleave".into() } else { "increasing".into() });
                let fp = match self.fpm() {
                    Ok(f) => f,
                    Err(e) => return Some(Err(e)),
                };
                let n = x.get("-name").cloned().unwrap_or_else(|| fp.fresh("bundle"));
                let buses: HashSet<String> = ports.iter().map(|p| bus_key(p).0).collect();
                crate::info!("PIN-220", "Pin bundle '{}': {} port(s) from {} bus(es), order {}", n, ports.len(), buses.len(), order);
                fp.bundles.retain(|b| b.name != n);
                fp.bundles.push(Bundle {
                    name: n.clone(),
                    ports,
                    sides: x.get("-sides").map(|s| split_list(s).iter().map(|x| side_name(x)).filter(|x| !x.is_empty()).collect()).unwrap_or_default(),
                    offset: x.num("-offset"),
                    spacing: x.num("-pin_spacing"),
                    layers: x.get("-allowed_layers").map(|l| split_list(l)).unwrap_or_default(),
                    order,
                });
                Ok(n)
            }
            "set_bundle_pin_constraints" => {
                let x = args(a, &["-bundles", "-sides", "-offset", "-pin_spacing", "-allowed_layers", "-bundle_order"]);
                let bs = x.get("-bundles").map(|s| split_list(s)).unwrap_or_default();
                let fp = match self.fpm() {
                    Ok(f) => f,
                    Err(e) => return Some(Err(e)),
                };
                let mut n = 0;
                for b in fp.bundles.iter_mut().filter(|b| bs.contains(&b.name)) {
                    if let Some(s) = x.get("-sides") {
                        b.sides = split_list(s).iter().map(|x| side_name(x)).filter(|x| !x.is_empty()).collect();
                    }
                    if let Some(v) = x.num("-offset") {
                        b.offset = Some(v);
                    }
                    if let Some(v) = x.num("-pin_spacing") {
                        b.spacing = Some(v);
                    }
                    if let Some(l) = x.get("-allowed_layers") {
                        b.layers = split_list(l);
                    }
                    if let Some(o) = x.get("-bundle_order") {
                        b.order = o.clone();
                    }
                    n += 1;
                }
                if n == 0 {
                    return Some(err("set_bundle_pin_constraints: no such bundle"));
                }
                ok()
            }
            "place_pins" => {
                let x = args(a, &["-ports"]);
                if self.fp.is_none() {
                    return Some(err("No floorplan (FP-001)"));
                }
                if x.has("-replace_fixed") {
                    let fp = self.fp.as_mut().unwrap();
                    fp.fixed_ports.clear();
                    fp.pin_info.clear();
                } else {
                    let fp = self.fp.as_mut().unwrap();
                    fp.pin_info.retain(|_, v| v.2 == "def" || v.2 == "location");
                }
                self.auto_pins();
                ok()
            }
            "check_pin_assignment" | "checkPinAssignment" => {
                let x = args(a, &["-pins", "-ports", "-report_file", "-output", "-categories"]);
                let Some(fp) = &self.fp else { return Some(err("No floorplan (FP-001)")) };
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                let mut v = crate::fplan::check_pin_assignment(nl, fp);
                if let Some(ps) = x.get("-pins").or(x.get("-ports")) {
                    let pats: Vec<String> = split_list(ps).into_iter().map(|p| crate::cons::Obj::parse(&p).map(|o| o.name().to_string()).unwrap_or(p)).collect();
                    v.retain(|(_, m)| pats.iter().any(|p| m.split(|c| c == ':' || c == ' ').any(|w| crate::netlist::glob(p, w))));
                }
                if let Some(c) = x.get("-categories") {
                    let cs = split_list(c);
                    v.retain(|(k, _)| cs.contains(k));
                }
                const CATS: &[(&str, &str)] = &[
                    ("unplaced", "pins not placed"),
                    ("outside_die", "pins outside the die"),
                    ("off_edge", "pins not on the die boundary"),
                    ("no_layer", "pins without a layer"),
                    ("side", "pins on a side not allowed"),
                    ("layer", "pins on a layer not allowed"),
                    ("direction", "layer direction does not match the side"),
                    ("off_track", "pins off the layer track grid"),
                    ("corner_keepout", "pins inside the corner keepout"),
                    ("constraint", "individual constraint (offset/location) not met"),
                    ("short", "overlapping pin shapes (same layer)"),
                    ("spacing", "pin spacing below minimum (same layer)"),
                    ("blockage", "pin shape over a routing blockage"),
                    ("bundle", "bundle split or out of order"),
                    ("unconnected", "ports without connections (warning)"),
                ];
                let mut out = String::new();
                out += &format!("\n****************************************\nReport : check_pin_assignment\nDesign : {}\n****************************************\n", nl.name);
                let np = nl.port_ids().len();
                let placed = nl.port_ids().iter().filter(|p| nl.ports[**p].loc.is_some()).count();
                out += &format!("  Ports: {}  placed: {}  layer assignment: {}  pin pitch {:.3}  spacing {}\n\n", np, placed, fp.block_pins.layer_assignment, crate::fplan::pin_pitch(&fp.block_pins, &fp.layers), fp.block_pins.spacing);
                let mut by_layer: std::collections::BTreeMap<(String, String), usize> = Default::default();
                for (_, (sd, ly, _)) in fp.pin_info.iter() {
                    *by_layer.entry((sd.clone(), ly.clone())).or_default() += 1;
                }
                out += "  Pins per side / layer:";
                for ((sd, ly), n) in &by_layer {
                    out += &format!("  {}:{}={}", sd, ly, n);
                }
                out += "\n\n";
                out += &format!("  {:<16} {:>6}  {}\n", "Check", "Count", "Description");
                let mut errs = 0;
                for (c, d) in CATS {
                    let n = v.iter().filter(|x| x.0 == *c).count();
                    if *c != "unconnected" {
                        errs += n;
                    }
                    out += &format!("  {:<16} {:>6}  {}\n", c, n, d);
                }
                out += &format!("\n  Total: {} violation(s), {} warning(s)\n", errs, v.iter().filter(|x| x.0 == "unconnected").count());
                let verbose = x.has("-verbose");
                if !v.is_empty() {
                    out += "\n";
                    for (i, (c, m)) in v.iter().enumerate() {
                        if !verbose && i >= 30 {
                            out += &format!("  ... {} more (use -verbose)\n", v.len() - 30);
                            break;
                        }
                        out += &format!("  [{}] {}\n", c, m);
                    }
                }
                if let Some(f) = x.get("-report_file").or(x.get("-output")) {
                    if let Err(e) = std::fs::write(f, &out) {
                        return Some(err(format!("cannot write '{}': {}", f, e)));
                    }
                }
                for l in out.lines() {
                    crate::out!("{}", l);
                }
                Ok(errs.to_string())
            }
            "check_pin_placement" => {
                let Some(fp) = &self.fp else { return Some(err("No floorplan (FP-001)")) };
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                let v = check_pins(nl, fp);
                crate::out!("\n**** check_pin_placement ****");
                for l in &v {
                    crate::out!("  {}", l);
                }
                crate::out!("  {} pin placement violation(s)", v.len());
                Ok(v.len().to_string())
            }
            "report_pin_placement" => {
                let Some(fp) = &self.fp else { return Some(err("No floorplan (FP-001)")) };
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                crate::out!("\n{:<26} {:<7} {:>9} {:>9} {:<6} {}", "Port", "Side", "X", "Y", "Layer", "Source");
                let mut ps: Vec<PortId> = nl.port_ids();
                ps.sort_by(|a, b| {
                    let (sa, sb) = (fp.pin_info.get(&nl.ports[*a].name).map(|x| x.0.clone()).unwrap_or_default(), fp.pin_info.get(&nl.ports[*b].name).map(|x| x.0.clone()).unwrap_or_default());
                    sa.cmp(&sb).then(bus_key(&nl.ports[*a].name).cmp(&bus_key(&nl.ports[*b].name)))
                });
                for p in ps {
                    let pt = &nl.ports[p];
                    let (s, l, src) = fp.pin_info.get(&pt.name).cloned().unwrap_or_default();
                    let (x, y) = pt.loc.unwrap_or((f64::NAN, f64::NAN));
                    crate::out!("{:<26} {:<7} {:>9.3} {:>9.3} {:<6} {}", pt.name, s, x, y, l, src);
                }
                ok()
            }
            "remove_placement_blockages" | "remove_routing_blockages" | "remove_route_blockages" | "remove_route_guides" | "remove_routing_guides" | "remove_bounds" | "remove_feedthroughs" | "remove_bundles" | "remove_pin_constraints" => {
                let all = a.iter().any(|x| x == "-all");
                let ns: Vec<String> = a.iter().filter(|x| !x.starts_with('-')).flat_map(|x| split_list(x)).collect();
                let fp = match self.fpm() {
                    Ok(f) => f,
                    Err(e) => return Some(Err(e)),
                };
                let keep = |n: &str| !(all || ns.iter().any(|p| glob(p, n)));
                let before;
                let after;
                match name {
                    "remove_placement_blockages" => {
                        before = fp.pblk.len();
                        fp.pblk.retain(|b| keep(&b.name));
                        after = fp.pblk.len();
                    }
                    "remove_routing_blockages" | "remove_route_blockages" => {
                        before = fp.rblk.len();
                        fp.rblk.retain(|b| keep(&b.name));
                        after = fp.rblk.len();
                    }
                    "remove_route_guides" | "remove_routing_guides" => {
                        before = fp.guides.len();
                        fp.guides.retain(|b| keep(&b.name));
                        after = fp.guides.len();
                    }
                    "remove_bounds" => {
                        before = fp.bounds.len();
                        fp.bounds.retain(|b| keep(&b.name));
                        after = fp.bounds.len();
                    }
                    "remove_feedthroughs" => {
                        before = fp.feeds.len();
                        fp.feeds.retain(|b| keep(&b.name));
                        after = fp.feeds.len();
                    }
                    "remove_bundles" => {
                        before = fp.bundles.len();
                        fp.bundles.retain(|b| keep(&b.name));
                        after = fp.bundles.len();
                    }
                    _ => {
                        before = fp.pin_cons.len();
                        fp.pin_cons.retain(|b| keep(&b.port));
                        after = fp.pin_cons.len();
                    }
                }
                Ok((before - after).to_string())
            }
            "report_placement_blockages" | "report_routing_blockages" | "report_route_guides" | "report_bounds" | "report_feedthroughs" | "report_floorplan" => {
                let Some(fp) = &self.fp else { return Some(err("No floorplan (FP-001)")) };
                let all = name == "report_floorplan";
                if all {
                    crate::out!("\nFloorplan of '{}': die {} ({:.1} um^2), {} rows (h={:.2}), layers {}", fp.design, fmt_r(&fp.die), area(&fp.die), fp.rows, fp.row_h, fp.layers.iter().map(|l| format!("{}{}", l.name, if l.horiz { "H" } else { "V" })).collect::<Vec<_>>().join(" "));
                }
                if all || name == "report_placement_blockages" {
                    crate::out!("\nPlacement blockages ({}):", fp.pblk.len());
                    for b in &fp.pblk {
                        crate::out!("  {:<16} {:<14} {:<34} [{}]", b.name, format!("{:?}", b.kind), fmt_r(&b.rect), b.source);
                    }
                }
                if all || name == "report_routing_blockages" {
                    crate::out!("\nRouting blockages ({}):", fp.rblk.len());
                    for b in &fp.rblk {
                        crate::out!("  {:<16} {:<20} {:<34} [{}]", b.name, if b.layers.is_empty() { "all".into() } else { b.layers.join(",") }, fmt_r(&b.rect), b.source);
                    }
                }
                if all || name == "report_route_guides" {
                    crate::out!("\nRoute guides ({}):", fp.guides.len());
                    for g in &fp.guides {
                        crate::out!("  {:<16} {:<34} layers={:?} nets={:?} track_util={:?}", g.name, fmt_r(&g.rect), g.layers, g.nets, g.track_util);
                    }
                }
                if all || name == "report_bounds" {
                    crate::out!("\nBounds ({}):", fp.bounds.len());
                    let nl = self.nl.as_ref();
                    for b in &fp.bounds {
                        let n = nl.map(|nl| nl.cell_ids().iter().filter(|c| member_of(&nl.cell(**c).name, &b.members)).count()).unwrap_or(0);
                        let ar: f64 = nl.map(|nl| nl.cell_ids().iter().filter(|c| member_of(&nl.cell(**c).name, &b.members)).filter_map(|c| nl.cell(*c).lib()).filter_map(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|c| c.area).sum()).unwrap_or(0.0);
                        let r = b.resolved.or(b.rect);
                        let util = r.map(|r| ar / area(&r).max(1e-9) * 100.0).unwrap_or(0.0);
                        crate::out!("  {:<14} {:<9} {:<34} cells {:>5} area {:>9.2} util {:>5.1}%{} [{}] members {:?}", b.name, format!("{:?}", b.kind), r.map(|r| fmt_r(&r)).unwrap_or(format!("group {:?}", b.dims)), n, ar, util, if util > 100.0 { " OVERFULL" } else { "" }, b.source, b.members);
                    }
                }
                if all || name == "report_feedthroughs" {
                    crate::out!("\nFeedthroughs ({}):", fp.feeds.len());
                    for f in &fp.feeds {
                        let used: Vec<&String> = fp.groute.as_ref().map(|g| g.feed_used.iter().filter(|u| u.1 == f.region).map(|u| &u.0).collect()).unwrap_or_default();
                        crate::out!("  {:<14} region {:<14} nets {:?} side {:?} used-by-router {}", f.name, f.region, f.nets, f.side, used.len());
                    }
                }
                if all {
                    crate::out!("\nPin bundles ({}): {}", fp.bundles.len(), fp.bundles.iter().map(|b| format!("{}[{}]", b.name, b.ports.len())).collect::<Vec<_>>().join(" "));
                    crate::out!("Individual pin constraints: {}", fp.pin_cons.len());
                }
                ok()
            }
            "create_placement" | "place_cells" => {
                let inc = a.iter().any(|x| x == "-incremental");
                let st = match self.fp_place(inc) {
                    Ok(s) => s,
                    Err(e) => return Some(Err(e)),
                };
                crate::info!("PLC-200", "create_placement: {} cell(s) seeded, {} density spreading move(s), {} constraint projections; utilization {:.1}%, {} overflow bin(s), {} bound / {} blockage violation(s)", st.placed, st.spread, st.moved_by_constraints, st.util * 100.0, st.overflow_bins, st.bound_violations, st.blockage_violations);
                ok()
            }
            "check_placement" | "report_placement" | "report_utilization" | "check_legality" => {
                let maxd = self.appf("place.coarse.max_density").clamp(0.05, 1.0);
                let bin = self.appf("place.bin_size");
                let Some(fp) = &self.fp else { return Some(err("No floorplan (FP-001)")) };
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                let libs = &self.libs;
                let area_of = |c: &Cell| -> f64 {
                    match &c.kind {
                        Kind::Lib(l) => libs.iter().find_map(|x| x.cells.get(l)).map(|x| x.area).unwrap_or(1.0),
                        _ => 1.0,
                    }
                };
                let pb = place_blockages(&fp, 60.0);
            let cx = Ctx { die: fp.place_region(), pblk: &pb, bounds: &fp.bounds, area_of: &area_of };
                let binsz = if bin > 0.0 { bin } else { ((fp.die.2 - fp.die.0).min(fp.die.3 - fp.die.1) / 12.0).max(1.0) };
                let (ov, util) = density_report(nl, &cx, maxd, binsz);
                let (bv, kv) = violations(nl, &cx);
                let unplaced = nl.cell_ids().iter().filter(|c| nl.cell(**c).loc.is_none() && !matches!(nl.cell(**c).kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1))).count();
                crate::out!("\n**** {} ****\n  utilization {:.1}% (max density {:.0}%, bin {:.1}um)\n  density overflow bins {}\n  unplaced cells {}\n  bound violations {}\n  blockage violations {}", name, util * 100.0, maxd * 100.0, binsz, ov, unplaced, bv.len(), kv.len());
                for v in bv.iter().chain(kv.iter()).take(20) {
                    crate::out!("    {}", v);
                }
                crate::out!("  note: coarse (non-legalized) placement — no row/site legalization without LEF");
                Ok((bv.len() + kv.len()).to_string())
            }
            "route_global" | "estimate_global_route" => match self.route_options(name, a).and_then(|_| self.fp_route(false)) {
                Ok(g) => Ok(format!("{:.1}", g.overflow)),
                Err(e) => Err(e),
            },
            "report_congestion" => {
                let Some(fp) = &self.fp else { return Some(err("No floorplan (FP-001)")) };
                let Some(g) = &fp.groute else { return Some(err("No global route; run route_global (GR-001)")) };
                crate::out!("\n**** report_congestion ****\n  grid {} x {} gcells of {:.2} um\n  total wirelength {:.1} um\n  overflow {:.1} (H+V tracks) in {} gcell(s) ({:.2}%)\n  max gcell utilization {:.0}%\n  detoured nets {}\n  unroutable nets {}\n  feedthrough uses {}", g.nx, g.ny, g.gcell, g.wirelength, g.overflow, g.overflow_cells, g.overflow_cells as f64 / (g.nx * g.ny).max(1) as f64 * 100.0, g.max_util * 100.0, g.detoured.len(), g.unroutable.len(), g.feed_used.len());
                let mut hot: Vec<(f64, usize)> = (0..g.nx * g.ny).map(|k| ((g.dem[k][0] / g.cap[k][0].max(1e-9)).max(g.dem[k][1] / g.cap[k][1].max(1e-9)), k)).collect();
                hot.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap());
                crate::out!("  hotspots:");
                for (u, k) in hot.iter().take(8) {
                    let (i, j) = (k % g.nx, k / g.nx);
                    crate::out!("    gcell ({:>3},{:>3}) @ ({:>7.2},{:>7.2})  util {:>5.0}%  H {:.0}/{:.0}  V {:.0}/{:.0}", i, j, fp.die.0 + (i as f64 + 0.5) * g.gcell, fp.die.1 + (j as f64 + 0.5) * g.gcell, u.min(99.99) * 100.0, g.dem[*k][0], g.cap[*k][0], g.dem[*k][1], g.cap[*k][1]);
                }
                if a.iter().any(|x| x == "-verbose") {
                    for (n, r) in &g.feed_used {
                        crate::out!("    feedthrough: net {} through {}", n, r);
                    }
                    for n in &g.detoured {
                        crate::out!("    detoured: {}", n);
                    }
                }
                Ok(format!("{:.1}", g.overflow))
            }
            "report_routing_layers" => {
                let Some(fp) = &self.fp else { return Some(err("No floorplan (FP-001)")) };
                for l in &fp.layers {
                    crate::out!("  {:<4} {} pitch {:.3} um, usable {:.0}%", l.name, if l.horiz { "horizontal" } else { "vertical  " }, l.pitch, l.util * 100.0);
                }
                ok()
            }
            "set_routing_layers" => {
                // set_routing_layers {M1:H:0.2 M2:V:0.2 ...}
                let fp = match self.fpm() {
                    Ok(f) => f,
                    Err(e) => return Some(Err(e)),
                };
                let mut v = vec![];
                for s in a.iter().flat_map(|x| split_list(x)) {
                    let p: Vec<&str> = s.split(':').collect();
                    if p.len() >= 3 {
                        v.push(Layer { name: p[0].into(), horiz: p[1].starts_with('H') || p[1].starts_with('h'), pitch: p[2].parse().unwrap_or(0.2), util: p.get(3).and_then(|u| u.parse().ok()).unwrap_or(0.8) });
                    }
                }
                if v.is_empty() {
                    return Some(err("set_routing_layers {NAME:H|V:pitch[:util] ...}"));
                }
                fp.layers = v;
                ok()
            }
            "place_opt" => {
                let (sv, a2) = match self.place_options_begin("place_opt", a) { Ok(v) => v, Err(e) => return Some(Err(e)) };
                let r = self.with_opt_ctl("place_opt", &a2, |s, rest, ctl| {
                    let incr = ctl.map(|c| c.incremental).unwrap_or(false);
                    s.c_place_opt(rest, incr)
                });
                let e = self.place_options_end("place_opt", sv);
                r.and_then(|v| e.map(|_| v))
            }
            "gui_write_state" => {
                // the document the GTK GUI draws (for scripts / regression checks)
                let f = a.iter().find(|x| !x.starts_with('-')).cloned().unwrap_or("gui_state.json".into());
                let st = crate::gui::state_json(self);
                std::fs::write(&f, &st).map(|_| { crate::info!("GUI-010", "Wrote GUI state '{}' ({} bytes)", f, st.len()); f.clone() }).map_err(|e| Flow::Err(format!("gui_write_state: {}", e)))
            }
            _ => return self.va_cmd(name, a),
        })
    }

    fn c_place_opt(&mut self, a: &[String], incremental: bool) -> R {
        let x = args(a, &["-from", "-to"]);
        if self.fp.is_none() {
            return err("place_opt requires a floorplan (read_def / initialize_floorplan) (FP-001)");
        }
        if self.libs.is_empty() || self.nl.as_ref().map(|n| !n.mapped).unwrap_or(true) {
            return err("place_opt requires a mapped design (compile_fusion -to logic_opto) (PLC-001)");
        }
        if incremental {
            // keep the placement: optimize what is left, ECO-legalize what changed
            let nl = self.nl()?;
            let unplaced = nl.cell_ids().iter().filter(|c| !nl.cell(**c).is_hport() && nl.cell(**c).lib().is_some() && nl.cell(**c).loc.is_none()).count();
            if unplaced > 0 {
                return err(format!("place_opt -incremental: {} cell(s) are not placed; run place_opt first (OPT-930)", unplaced));
            }
            if x.get("-from").is_some() || x.get("-to").is_some() {
                crate::warn!("OPT-931", "place_opt -incremental: -from/-to ignored (only the optimization runs)");
            }
            crate::out!("\n==== place_opt : incremental_opto ====");
            self.stage("final_opto", true)?;
            let bad = self.illegal_cells().unwrap_or_default();
            let nb = bad.len();
            if nb > 0 {
                self.fp_legalize(Some(bad), false, true)?;
            }
            // with -endpoints the other nets keep their global routes (changed nets are estimated
            // from the placement), so nothing outside the focus cones moves
            if self.opt_ctl.as_ref().map(|c| c.focus.is_none()).unwrap_or(true) {
                self.fp_route(true)?;
            }
            let q = self.with_env(|nl, env| {
                let a = env.analyze(nl, 0);
                (a.wns, a.tns, a.whs, a.drv.len(), nl.num_cells())
            })?;
            crate::out!("  [{:<13}] WNS {:>8.4}  TNS {:>9.4}  WHS {:>8.4}  DRV {:>4}  cells {:>6}  area {:>10.3}  ECO-legalized {}", "incremental", q.0, q.1, q.2, q.3, q.4, self.total_area(), nb);
            return ok();
        }
        const ST: &[&str] = &["initial_place", "initial_drc", "initial_opto", "final_place", "final_opto"];
        let fi = x.get("-from").and_then(|s| ST.iter().position(|t| t == s)).unwrap_or(0);
        let ti = x.get("-to").and_then(|s| ST.iter().position(|t| t == s)).unwrap_or(ST.len() - 1);
        for st in &ST[fi..=ti] {
            crate::out!("\n==== place_opt : {} ====", st);
            match *st {
                "initial_place" => {
                    let s = self.fp_place(false)?;
                    crate::info!("PLC-200", "place_opt placement: utilization {:.1}%, {} overflow bin(s), {} bound / {} blockage violation(s)", s.util * 100.0, s.overflow_bins, s.bound_violations, s.blockage_violations);
                    self.fp_route(false)?;
                }
                "final_place" => {
                    self.fp_place(true)?;
                    let die = self.fp.as_ref().unwrap().die;
                    let (r, g) = self.with_env(|nl, env| crate::opt::move_registers(nl, env, die))?;
                    self.fp_enforce()?;
                    crate::info!("PLC-210", "final_place: incremental placement, {} register / {} clock-gate move(s)", r, g);
                    self.fp_route(false)?;
                }
                s => {
                    self.stage(s, true)?;
                    self.fp_enforce()?;
                    if s == "final_opto" && self.appb("place.legalize") {
                        // end of place_opt: legal rows/sites + detailed placement
                        self.fp_legalize(None, true, false)?;
                    }
                    self.fp_route(true)?;
                }
            }
            let q = self.with_env(|nl, env| {
                let a = env.analyze(nl, 0);
                (a.wns, a.tns, a.whs, a.drv.len(), nl.num_cells())
            })?;
            let g = self.fp.as_ref().and_then(|f| f.groute.as_ref()).map(|g| (g.wirelength, g.overflow)).unwrap_or((0.0, 0.0));
            crate::out!("  [{:<13}] WNS {:>8.4}  TNS {:>9.4}  WHS {:>8.4}  DRV {:>4}  cells {:>6}  area {:>10.3}  GR-WL {:>9.1}um  overflow {:>6.1}", st, q.0, q.1, q.2, q.3, q.4, self.total_area(), g.0, g.1);
        }
        let _ = to_list::<String>(&[]);
        let _ = e2f;
        ok()
    }
}

/// placement blockages plus routing blockages over 2+ layers as partial (congestion-aware placement)
pub(crate) fn place_blockages(fp: &crate::phys::Floorplan, pct: f64) -> Vec<PBlockage> {
    let mut v = fp.pblk.clone();
    if pct > 0.0 {
        for b in &fp.rblk {
            if b.layers.is_empty() || b.layers.len() >= 2 {
                v.push(PBlockage { name: format!("{}_rt", b.name), rect: b.rect, kind: PbKind::Partial(pct.min(100.0)), source: "routing_blockage".into() });
            }
        }
    }
    v
}
