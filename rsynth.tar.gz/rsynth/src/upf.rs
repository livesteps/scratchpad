//! UPF 1.0 / 1.1 / 2.x (IEEE 1801) power intent: domains, supply nets/ports/sets,
//! port & power states, PSTs, isolation/level-shifter/retention strategies,
//! power switches. `commit` inserts isolation cells, level shifters, retention
//! flops and identifies always-on nets for AON buffering.

use crate::liberty::{parse_func, Library};
use crate::netlist::*;
use std::collections::{BTreeMap, HashMap, HashSet};

#[derive(Clone, Debug, Default)]
pub struct Domain {
    pub name: String,
    pub elements: Vec<String>,
    pub include_scope: bool,
    pub power: Option<String>,
    pub ground: Option<String>,
    pub supply_set: Option<String>,
}
#[derive(Clone, Debug, Default)]
pub struct IsoStrat {
    pub name: String,
    pub domain: String,
    pub applies_to: String,
    pub clamp: String,
    pub signal: Option<String>,
    pub sense: String,
    pub location: String,
    pub elements: Vec<String>,
    pub none: bool,
    pub supply: Option<String>,
    pub lib_cells: Vec<String>,
}
#[derive(Clone, Debug, Default)]
pub struct LsStrat {
    pub name: String,
    pub domain: String,
    pub applies_to: String,
    pub rule: String,
    pub location: String,
    pub elements: Vec<String>,
    pub none: bool,
    pub threshold: f64,
    pub lib_cells: Vec<String>,
}
#[derive(Clone, Debug, Default)]
pub struct RetStrat {
    pub name: String,
    pub domain: String,
    pub save: Option<(String, String)>,
    pub restore: Option<(String, String)>,
    pub elements: Vec<String>,
    pub supply: Option<String>,
    pub lib_cells: Vec<String>,
}
#[derive(Clone, Debug, Default)]
pub struct Switch {
    pub name: String,
    pub domain: String,
    pub input: String,
    pub output: String,
    pub control: String,
    pub on_state: String,
}

#[derive(Clone, Debug, Default)]
pub struct Upf {
    pub version: String,
    pub scope: String,
    pub domains: Vec<Domain>,
    pub supply_nets: BTreeMap<String, Vec<(String, Option<f64>)>>, // net -> states
    pub supply_ports: Vec<(String, String)>,                       // port, direction
    pub connections: Vec<(String, Vec<String>)>,                   // net -> ports
    pub supply_sets: BTreeMap<String, (Option<String>, Option<String>)>,
    pub iso: Vec<IsoStrat>,
    pub ls: Vec<LsStrat>,
    pub ret: Vec<RetStrat>,
    pub switches: Vec<Switch>,
    pub psts: Vec<(String, Vec<String>, Vec<(String, Vec<String>)>)>,
    pub power_states: Vec<(String, String, String)>,
    pub loaded: bool,
    pub committed: bool,
    pub files: Vec<String>,
    pub aon_nets: HashSet<String>,
    pub log: Vec<String>,
}

fn opt<'a>(a: &'a [String], k: &str) -> Option<&'a String> {
    a.iter().position(|x| x == k).and_then(|i| a.get(i + 1))
}
fn flag(a: &[String], k: &str) -> bool {
    a.iter().any(|x| x == k)
}
fn list(s: &str) -> Vec<String> {
    crate::tcl::split_list(s).into_iter().map(|x| crate::cons::Obj::parse(&x).map(|o| o.name().to_string()).unwrap_or(x)).collect()
}
fn nums(s: &str) -> Vec<f64> {
    s.split(|c: char| c.is_whitespace() || c == '{' || c == '}' || c == ',').filter_map(|x| x.parse().ok()).collect()
}

pub const UPF_CMDS: &[&str] = &[
    "upf_version", "set_design_top", "set_scope", "create_power_domain", "create_supply_port", "create_supply_net", "connect_supply_net", "set_domain_supply_net", "create_supply_set", "associate_supply_set", "add_port_state", "add_power_state", "add_supply_state", "create_pst", "add_pst_state", "set_isolation", "set_isolation_control", "set_level_shifter", "set_retention", "set_retention_control", "set_retention_elements", "map_retention_cell", "map_isolation_cell", "map_level_shifter_cell", "create_power_switch", "map_power_switch", "set_related_supply_net", "set_port_attributes", "set_design_attributes", "load_upf_protected", "name_format", "set_partial_on_translation", "describe_state_transition", "use_interface_cell", "create_power_state_group", "set_power_switch", "create_logic_port", "create_logic_net", "connect_logic_net", "set_simstate_behavior", "set_voltage",
];

impl Upf {
    pub fn cmd(&mut self, name: &str, a: &[String]) -> Result<String, String> {
        self.loaded = true;
        self.log.push(format!("{} {}", name, crate::tcl::to_list(a)));
        let pos: Vec<&String> = {
            let mut v = vec![];
            let mut i = 0;
            while i < a.len() {
                if a[i].starts_with('-') && !a[i][1..].starts_with(|c: char| c.is_ascii_digit()) {
                    // value options
                    let flags = ["-include_scope", "-no_isolation", "-no_shift", "-reuse", "-update", "-diff_supply_only", "-resolve", "-supply"];
                    if !flags.contains(&a[i].as_str()) || a[i] == "-resolve" || a[i] == "-supply" {
                        i += 2;
                        continue;
                    }
                    i += 1;
                    continue;
                }
                v.push(&a[i]);
                i += 1;
            }
            v
        };
        let first = pos.first().map(|s| s.to_string()).unwrap_or_default();
        match name {
            "upf_version" => {
                self.version = first.clone();
                if !["1.0", "1.1", "2.0", "2.1", "3.0", "3.1"].contains(&first.as_str()) && !first.is_empty() {
                    crate::warn!("UPF-001", "Unrecognized UPF version '{}'; parsing with 2.1 semantics", first);
                }
            }
            "set_design_top" | "set_scope" => self.scope = first,
            "create_power_domain" => {
                let mut d = Domain { name: first.clone(), include_scope: flag(a, "-include_scope"), ..Default::default() };
                if let Some(e) = opt(a, "-elements") {
                    d.elements = list(e).into_iter().filter(|x| x != ".").collect();
                    if list(e).iter().any(|x| x == ".") {
                        d.include_scope = true;
                    }
                }
                if let Some(s) = opt(a, "-supply") {
                    let l = list(s);
                    if l.len() >= 2 && l[0] == "primary" {
                        d.supply_set = Some(l[1].clone());
                    }
                }
                if let Some(x) = self.domains.iter_mut().find(|x| x.name == d.name) {
                    if flag(a, "-update") {
                        x.elements.extend(d.elements);
                        if d.supply_set.is_some() {
                            x.supply_set = d.supply_set;
                        }
                    }
                } else {
                    self.domains.push(d);
                }
            }
            "create_supply_port" => self.supply_ports.push((first, opt(a, "-direction").cloned().unwrap_or("in".into()))),
            "create_supply_net" => {
                self.supply_nets.entry(first).or_default();
            }
            "connect_supply_net" => {
                let ports = opt(a, "-ports").map(|p| list(p)).unwrap_or_default();
                self.connections.push((first, ports));
            }
            "set_domain_supply_net" => {
                if let Some(d) = self.domains.iter_mut().find(|d| d.name == first) {
                    d.power = opt(a, "-primary_power_net").cloned();
                    d.ground = opt(a, "-primary_ground_net").cloned();
                } else {
                    return Err(format!("UPF: unknown power domain '{}' (UPF-010)", first));
                }
            }
            "create_supply_set" => {
                let e = self.supply_sets.entry(first.clone()).or_default();
                for (i, x) in a.iter().enumerate() {
                    if x == "-function" {
                        let l = list(&a[i + 1]);
                        if l.len() >= 2 {
                            if l[0] == "power" {
                                e.0 = Some(l[1].clone())
                            } else if l[0] == "ground" {
                                e.1 = Some(l[1].clone())
                            }
                        }
                    }
                }
            }
            "associate_supply_set" => {}
            "add_port_state" | "add_supply_state" => {
                let mut states = vec![];
                for (i, x) in a.iter().enumerate() {
                    if x == "-state" {
                        let l = list(&a[i + 1]);
                        let v = l.get(1).and_then(|s| s.parse::<f64>().ok());
                        states.push((l.first().cloned().unwrap_or_default(), v));
                    }
                }
                // map port -> net through connections later; store under the object name
                self.supply_nets.entry(first).or_default().extend(states);
            }
            "add_power_state" => {
                for (i, x) in a.iter().enumerate() {
                    if x == "-state" {
                        let nm = a.get(i + 1).cloned().unwrap_or_default();
                        let body = a.get(i + 2).cloned().unwrap_or_default();
                        self.power_states.push((first.clone(), nm.clone(), body.clone()));
                        // supply_expr {power == {FULL_ON 0.9}}
                        let v = nums(&body);
                        let off = body.contains("OFF");
                        let obj = if first.contains('.') { first.clone() } else { format!("{}.power", first) };
                        let net = self.resolve_func(&obj);
                        if let Some(n) = net {
                            self.supply_nets.entry(n).or_default().push((if off { "OFF".into() } else { nm }, v.first().copied()));
                        }
                    }
                }
            }
            "create_pst" => {
                let sup = opt(a, "-supplies").map(|s| list(s)).unwrap_or_default();
                self.psts.push((first, sup, vec![]));
            }
            "add_pst_state" => {
                let pst = opt(a, "-pst").cloned().unwrap_or_default();
                let st = opt(a, "-state").map(|s| list(s)).unwrap_or_default();
                if let Some(p) = self.psts.iter_mut().find(|p| p.0 == pst) {
                    p.2.push((first, st));
                }
            }
            "set_isolation" => {
                if let Some(s) = self.iso.iter_mut().find(|s| s.name == first && flag(a, "-update")) {
                    if let Some(v) = opt(a, "-isolation_signal") {
                        s.signal = Some(list(v).join(""));
                    }
                    if let Some(v) = opt(a, "-isolation_sense") {
                        s.sense = v.clone();
                    }
                    if let Some(v) = opt(a, "-location") {
                        s.location = v.clone();
                    }
                    return Ok(String::new());
                }
                self.iso.push(IsoStrat {
                    name: first,
                    domain: opt(a, "-domain").cloned().unwrap_or_default(),
                    applies_to: opt(a, "-applies_to").cloned().unwrap_or("outputs".into()),
                    clamp: opt(a, "-clamp_value").cloned().unwrap_or("0".into()),
                    signal: opt(a, "-isolation_signal").map(|s| list(s).join("")),
                    sense: opt(a, "-isolation_sense").cloned().unwrap_or("high".into()),
                    location: opt(a, "-location").cloned().unwrap_or("self".into()),
                    elements: opt(a, "-elements").map(|e| list(e)).unwrap_or_default(),
                    none: flag(a, "-no_isolation"),
                    supply: opt(a, "-isolation_supply_set").or(opt(a, "-isolation_power_net")).cloned(),
                    lib_cells: vec![],
                });
            }
            "set_isolation_control" => {
                let dom = opt(a, "-domain").cloned().unwrap_or_default();
                if let Some(s) = self.iso.iter_mut().find(|s| s.name == first || (s.domain == dom && first.is_empty())) {
                    s.signal = opt(a, "-isolation_signal").map(|x| list(x).join(""));
                    if let Some(v) = opt(a, "-isolation_sense") {
                        s.sense = v.clone()
                    }
                    if let Some(v) = opt(a, "-location") {
                        s.location = v.clone()
                    }
                } else {
                    return Err(format!("UPF: set_isolation_control references unknown strategy '{}' (UPF-020)", first));
                }
            }
            "set_level_shifter" => self.ls.push(LsStrat {
                name: first,
                domain: opt(a, "-domain").cloned().unwrap_or_default(),
                applies_to: opt(a, "-applies_to").cloned().unwrap_or("both".into()),
                rule: opt(a, "-rule").cloned().unwrap_or("both".into()),
                location: opt(a, "-location").cloned().unwrap_or("self".into()),
                elements: opt(a, "-elements").map(|e| list(e)).unwrap_or_default(),
                none: flag(a, "-no_shift"),
                threshold: opt(a, "-threshold").and_then(|s| s.parse().ok()).unwrap_or(0.0),
                lib_cells: vec![],
            }),
            "set_retention" => self.ret.push(RetStrat {
                name: first,
                domain: opt(a, "-domain").cloned().unwrap_or_default(),
                save: opt(a, "-save_signal").map(|s| {
                    let l = list(s);
                    (l[0].clone(), l.get(1).cloned().unwrap_or("high".into()))
                }),
                restore: opt(a, "-restore_signal").map(|s| {
                    let l = list(s);
                    (l[0].clone(), l.get(1).cloned().unwrap_or("high".into()))
                }),
                elements: opt(a, "-elements").map(|e| list(e)).unwrap_or_default(),
                supply: opt(a, "-retention_supply_set").or(opt(a, "-retention_power_net")).cloned(),
                lib_cells: vec![],
            }),
            "set_retention_control" => {
                if let Some(s) = self.ret.iter_mut().find(|s| s.name == first) {
                    if let Some(v) = opt(a, "-save_signal") {
                        let l = list(v);
                        s.save = Some((l[0].clone(), l.get(1).cloned().unwrap_or("high".into())));
                    }
                    if let Some(v) = opt(a, "-restore_signal") {
                        let l = list(v);
                        s.restore = Some((l[0].clone(), l.get(1).cloned().unwrap_or("high".into())));
                    }
                } else {
                    return Err(format!("UPF: unknown retention strategy '{}' (UPF-030)", first));
                }
            }
            "map_retention_cell" | "map_isolation_cell" | "map_level_shifter_cell" => {
                let cells = opt(a, "-lib_cells").map(|s| list(s)).unwrap_or_default();
                match name {
                    "map_retention_cell" => self.ret.iter_mut().filter(|s| s.name == first).for_each(|s| s.lib_cells = cells.clone()),
                    "map_isolation_cell" => self.iso.iter_mut().filter(|s| s.name == first).for_each(|s| s.lib_cells = cells.clone()),
                    _ => self.ls.iter_mut().filter(|s| s.name == first).for_each(|s| s.lib_cells = cells.clone()),
                }
            }
            "create_power_switch" => {
                let sp = |k: &str| opt(a, k).map(|v| list(v).last().cloned().unwrap_or_default()).unwrap_or_default();
                self.switches.push(Switch { name: first, domain: opt(a, "-domain").cloned().unwrap_or_default(), input: sp("-input_supply_port"), output: sp("-output_supply_port"), control: sp("-control_port"), on_state: opt(a, "-on_state").cloned().unwrap_or_default() });
            }
            _ => {
                crate::info!("UPF-100", "UPF command '{}' accepted (no synthesis effect)", name);
            }
        }
        Ok(String::new())
    }

    fn resolve_func(&self, obj: &str) -> Option<String> {
        // SS.power -> net
        let (ss, f) = obj.split_once('.')?;
        let e = self.supply_sets.get(ss)?;
        if f == "power" { e.0.clone() } else { e.1.clone() }
    }
    pub fn domain_power(&self, d: &Domain) -> Option<String> {
        d.power.clone().or_else(|| d.supply_set.as_ref().and_then(|s| self.supply_sets.get(s)).and_then(|x| x.0.clone()))
    }
    fn net_states(&self, net: &str) -> Vec<(String, Option<f64>)> {
        let mut v = self.supply_nets.get(net).cloned().unwrap_or_default();
        for (n, ports) in &self.connections {
            if n == net {
                for p in ports {
                    v.extend(self.supply_nets.get(p).cloned().unwrap_or_default());
                }
            }
        }
        // switched net: output of a power switch
        for s in &self.switches {
            if s.output == net || self.connections.iter().any(|(n, ps)| n == net && ps.iter().any(|p| *p == s.output)) {
                v.push(("OFF".into(), None));
            }
        }
        v
    }
    pub fn domain_voltage(&self, d: &str) -> Option<f64> {
        let dm = self.domains.iter().find(|x| x.name == d)?;
        let net = self.domain_power(dm)?;
        let st = self.net_states(&net);
        let mut v = st.iter().filter_map(|x| x.1).fold(f64::NAN, f64::max);
        if v.is_nan() {
            // switch input voltage
            for s in &self.switches {
                if s.domain == d {
                    for (n, ps) in &self.connections {
                        if ps.iter().any(|p| *p == s.input) || s.input == *n {
                            v = self.net_states(n).iter().filter_map(|x| x.1).fold(f64::NAN, f64::max);
                        }
                    }
                }
            }
        }
        if v.is_nan() { None } else { Some(v) }
    }
    pub fn switchable(&self, d: &str) -> bool {
        let Some(dm) = self.domains.iter().find(|x| x.name == d) else { return false };
        if self.switches.iter().any(|s| s.domain == d) {
            return true;
        }
        if dm.supply_set.as_ref().map(|s| self.power_states.iter().any(|p| p.0 == *s && p.2.contains("OFF"))).unwrap_or(false) {
            return true;
        }
        self.domain_power(dm).map(|n| self.net_states(&n).iter().any(|s| s.0.to_uppercase().contains("OFF"))).unwrap_or(false)
    }
    pub fn top_domain(&self) -> Option<String> {
        self.domains.iter().find(|d| d.include_scope || d.elements.is_empty()).map(|d| d.name.clone()).or(self.domains.first().map(|d| d.name.clone()))
    }
    /// domain of a hierarchical instance name (longest matching element)
    pub fn domain_of(&self, inst: &str) -> Option<String> {
        let mut best: Option<(usize, String)> = None;
        for d in &self.domains {
            for e in &d.elements {
                if inst == e || inst.starts_with(&format!("{}/", e)) {
                    if best.as_ref().map(|b| e.len() > b.0).unwrap_or(true) {
                        best = Some((e.len(), d.name.clone()));
                    }
                }
            }
        }
        best.map(|b| b.1).or_else(|| self.top_domain())
    }
    pub fn pin_domain(&self, nl: &Netlist, pr: PinRef) -> Option<String> {
        match pr {
            PinRef::Cell(c, _) => self.domain_of(&nl.cell(c).name),
            PinRef::Port(_) => self.top_domain(),
        }
    }

    /// Insert isolation cells, level shifters and retention registers.
    pub fn commit(&mut self, nl: &mut Netlist, lib: &Library) -> Result<(usize, usize, usize), String> {
        let mut no_iso_cell: std::collections::BTreeMap<String, (String, usize)> = Default::default();
        if self.domains.is_empty() {
            return Err("No power domains defined (UPF-200)".into());
        }
        let (mut niso, mut nls, mut nret) = (0, 0, 0);
        let iso_cells: Vec<_> = lib.cells_sorted().into_iter().filter(|c| c.is_iso && !c.dont_use).collect();
        let ls_cells: Vec<_> = lib.cells_sorted().into_iter().filter(|c| c.is_ls && !c.dont_use).collect();
        // ---------- crossings
        let nets = nl.net_ids();
        for n in nets {
            if !nl.net_alive(n) {
                continue;
            }
            let Some(d) = nl.driver(n) else { continue };
            if let PinRef::Cell(dc, _) = d {
                if nl.cell(dc).has_attr("iso") || nl.cell(dc).has_attr("ls") || matches!(nl.cell(dc).kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) {
                    continue;
                }
                if nl.cell(dc).lib().and_then(|l| lib.cells.get(l)).map(|x| x.tie.is_some()).unwrap_or(false) {
                    continue;
                }
            }
            let Some(dd) = self.pin_domain(nl, d) else { continue };
            let mut by_dom: BTreeMap<String, Vec<PinRef>> = BTreeMap::new();
            for l in nl.loads(n) {
                if let PinRef::Cell(lc, _) = l {
                    if nl.cell(lc).has_attr("iso") || nl.cell(lc).has_attr("ls") {
                        continue;
                    }
                }
                if let Some(ld) = self.pin_domain(nl, l) {
                    if ld != dd {
                        by_dom.entry(ld).or_default().push(l);
                    }
                }
            }
            for (ld, loads) in by_dom {
                let mut cur_net = n;
                let mut cur_loads = loads.clone();
                // isolation
                let strat = self
                    .iso
                    .iter()
                    .find(|s| s.domain == dd && (s.applies_to == "outputs" || s.applies_to == "both"))
                    .or_else(|| self.iso.iter().find(|s| s.domain == ld && (s.applies_to == "inputs" || s.applies_to == "both")))
                    .cloned();
                if let Some(s) = strat {
                    if !s.none {
                        let clamp1 = s.clamp == "1";
                        let Some(sig) = s.signal.clone() else {
                            crate::error!("UPF-210", "Isolation strategy '{}' has no isolation signal; crossing net '{}' left unisolated", s.name, nl.net(n).name);
                            continue;
                        };
                        let en = nl.net_by_name(&sig).or_else(|| nl.port_by_name(&sig).and_then(|p| nl.ports[p].net));
                        let Some(en) = en else {
                            crate::error!("UPF-211", "Isolation signal '{}' of strategy '{}' not found in design", sig, s.name);
                            continue;
                        };
                        self.aon_nets.insert(nl.net(en).name.clone());
                        let active_high = s.sense == "high";
                        // pick iso cell: output == clamp when enable active, == data otherwise
                        let mut pick = None;
                        for c in iso_cells.iter().filter(|c| s.lib_cells.is_empty() || s.lib_cells.contains(&c.name)) {
                            let Some(enp) = c.pins.iter().find(|p| p.iso_enable).or_else(|| c.inputs().into_iter().find(|p| p.name.to_uppercase().contains("EN") || p.name.to_uppercase() == "ISO")) else { continue };
                            let Some(dp) = c.inputs().into_iter().find(|p| p.name != enp.name) else { continue };
                            let Some(f) = c.outputs().first().and_then(|o| o.function.clone()).and_then(|f| parse_func(&f)) else { continue };
                            let ev = |e: bool, dv: bool| f.eval(&|p: &str| if p == enp.name { e } else if p == dp.name { dv } else { false });
                            let act = active_high;
                            if ev(act, false) == clamp1 && ev(act, true) == clamp1 && !ev(!act, false) && ev(!act, true) {
                                pick = Some((c, enp.name.clone(), dp.name.clone()));
                                break;
                            }
                        }
                        let Some((ic, enp, dp)) = pick else {
                            let e = no_iso_cell.entry(s.name.clone()).or_insert((format!("clamp={} sense={}", s.clamp, s.sense), 0));
                            e.1 += 1;
                            continue;
                        };
                        let host = if s.location == "parent" {
                            // parent of the isolated domain = load side for outputs
                            match cur_loads[0] {
                                PinRef::Cell(c, _) => nl.cell(c).hier_prefix().to_string(),
                                _ => String::new(),
                            }
                        } else {
                            match d {
                                PinRef::Cell(c, _) => nl.cell(c).hier_prefix().to_string(),
                                _ => String::new(),
                            }
                        };
                        let base = nl.net(n).name.replace(['/', '[', ']', '.'], "_");
                        let host = nl.outside_frozen(&host);
                        let cname = if host.is_empty() { format!("{}_UPF_ISO", base) } else { format!("{}/{}_UPF_ISO", host, base) };
                        let pins: Vec<(&str, Dir)> = ic.pins.iter().map(|p| (p.name.as_str(), p.dir.unwrap_or(Dir::In))).collect();
                        let c = nl.add_cell(&cname, Kind::Lib(ic.name.clone()), &pins);
                        nl.cell_mut(c).attrs.push("iso".into());
                        nl.cell_mut(c).dont_touch = true;
                        let on = nl.add_net(&format!("{}_iso", nl.net(n).name.clone()));
                        nl.connect_name(c, &dp, cur_net);
                        nl.connect_name(c, &enp, en);
                        nl.connect_name(c, &ic.outputs()[0].name, on);
                        for l in &cur_loads {
                            match *l {
                                PinRef::Cell(lc, lp) => nl.connect(lc, lp, on),
                                PinRef::Port(p) => nl.connect_port(p, on),
                            }
                        }
                        nl.cell_mut(c).loc = nl.driver(cur_net).and_then(|d| nl.pin_loc(d)).or(cur_loads.iter().find_map(|l| nl.pin_loc(*l)));
                        cur_net = on;
                        cur_loads = vec![];
                        cur_loads.extend(nl.loads(on).into_iter().filter(|x| *x != PinRef::Cell(c, 0)));
                        niso += 1;
                    }
                } else if self.switchable(&dd) && !self.switchable(&ld) {
                    crate::warn!("UPF-300", "Net '{}' crosses from switchable domain '{}' to always-on domain '{}' without an isolation strategy", nl.net(n).name, dd, ld);
                }
                // level shifting
                let (vd, vl) = (self.domain_voltage(&dd), self.domain_voltage(&ld));
                if let (Some(vd), Some(vl)) = (vd, vl) {
                    if (vd - vl).abs() > 1e-6 {
                        let strat = self.ls.iter().find(|s| (s.domain == dd && s.applies_to != "inputs") || (s.domain == ld && s.applies_to != "outputs")).cloned();
                        let rule_ok = |s: &LsStrat| match s.rule.as_str() {
                            "low_to_high" => vl > vd,
                            "high_to_low" => vl < vd,
                            _ => true,
                        };
                        match strat {
                            Some(s) if s.none => {}
                            Some(s) if (vd - vl).abs() <= s.threshold => {}
                            Some(s) if !rule_ok(&s) => {}
                            Some(s) => {
                                let want = if vl > vd { "LH" } else { "HL" };
                                let pick = ls_cells
                                    .iter()
                                    .filter(|c| s.lib_cells.is_empty() || s.lib_cells.contains(&c.name))
                                    .find(|c| c.ls_type.as_deref().map(|t| t.to_uppercase().contains(want) || t.contains(if want == "LH" { "low_to_high" } else { "high_to_low" }) || t == "HL_LH").unwrap_or(true))
                                    .copied();
                                let Some(lc) = pick else {
                                    crate::error!("UPF-220", "No level-shifter cell ({}) available for '{}' ({}V -> {}V)", want, nl.net(n).name, vd, vl);
                                    continue;
                                };
                                let dp = lc.inputs().into_iter().find(|p| !p.ls_enable).map(|p| p.name.clone()).unwrap();
                                let pins: Vec<(&str, Dir)> = lc.pins.iter().map(|p| (p.name.as_str(), p.dir.unwrap_or(Dir::In))).collect();
                                let base = nl.net(n).name.replace(['/', '[', ']', '.'], "_");
                                let host = match cur_loads.first() {
                                    Some(PinRef::Cell(c, _)) => nl.cell(*c).hier_prefix().to_string(),
                                    _ => String::new(),
                                };
                                let host = nl.outside_frozen(&host);
                                let cname = if host.is_empty() { format!("{}_UPF_LS", base) } else { format!("{}/{}_UPF_LS", host, base) };
                                let c = nl.add_cell(&cname, Kind::Lib(lc.name.clone()), &pins);
                                nl.cell_mut(c).attrs.push("ls".into());
                                nl.cell_mut(c).dont_touch = true;
                                let dl = nl.driver(cur_net).and_then(|d| nl.pin_loc(d));
                                let ll = cur_loads.first().and_then(|l| nl.pin_loc(*l));
                                nl.cell_mut(c).loc = match (dl, ll) {
                                    (Some(a), Some(b)) => Some(((a.0 + b.0) / 2.0, (a.1 + b.1) / 2.0)),
                                    (a, b) => a.or(b),
                                };
                                let on = nl.add_net(&format!("{}_ls", nl.net(n).name.clone()));
                                let loads_now: Vec<PinRef> = if cur_net == n { cur_loads.clone() } else { nl.loads(cur_net) };
                                nl.connect_name(c, &dp, cur_net);
                                nl.connect_name(c, &lc.outputs()[0].name, on);
                                for l in loads_now {
                                    match l {
                                        PinRef::Cell(lc2, lp) => nl.connect(lc2, lp, on),
                                        PinRef::Port(p) => nl.connect_port(p, on),
                                    }
                                }
                                nls += 1;
                            }
                            None => crate::warn!("UPF-310", "Net '{}' crosses {}V ('{}') -> {}V ('{}') without a level-shifter strategy", nl.net(n).name, vd, dd, vl, ld),
                        }
                    }
                }
            }
        }
        // ---------- retention
        for s in self.ret.clone() {
            let rcells: Vec<_> = lib.cells_sorted().into_iter().filter(|c| c.retention && !c.dont_use && (s.lib_cells.is_empty() || s.lib_cells.contains(&c.name))).collect();
            let ffs: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| {
                let cell = nl.cell(*c);
                self.domain_of(&cell.name).as_deref() == Some(&s.domain) && cell.lib().and_then(|l| lib.cells.get(l)).map(|x| x.seq.is_some() && !x.seq.as_ref().unwrap().is_latch && !x.retention).unwrap_or(false) && (s.elements.is_empty() || s.elements.iter().any(|e| cell.name.starts_with(e.as_str())))
            }).collect();
            let (ffs, frozen): (Vec<CellId>, Vec<CellId>) = ffs.into_iter().partition(|c| !nl.cell(*c).frozen());
            if !frozen.is_empty() {
                crate::warn!("UPF-235", "Retention strategy '{}': {} dont_touch/size_only register(s) not retention-mapped", s.name, frozen.len());
            }
            if ffs.is_empty() {
                continue;
            }
            for f in ffs {
                let cell = nl.cell(f).clone();
                let old = lib.cells.get(cell.lib().unwrap()).unwrap();
                let need: HashSet<&str> = cell.pins.iter().filter(|p| p.net.is_some()).map(|p| p.name.as_str()).collect();
                let Some(rc) = rcells.iter().filter(|r| need.iter().all(|p| r.pin(p).is_some()) && r.seq.as_ref().map(|q| q.clear.is_some() == old.seq.as_ref().unwrap().clear.is_some()).unwrap_or(false)).min_by(|a, b| a.area.partial_cmp(&b.area).unwrap()) else {
                    crate::error!("UPF-230", "No retention register in library compatible with '{}' ({}) for strategy '{}'", cell.name, old.name, s.name);
                    break;
                };
                let pins: Vec<(&str, Dir)> = rc.pins.iter().map(|p| (p.name.as_str(), p.dir.unwrap_or(Dir::In))).collect();
                nl.remove_cell(f);
                let nc = nl.add_cell(&cell.name, Kind::Lib(rc.name.clone()), &pins);
                nl.cell_mut(nc).loc = cell.loc;
                nl.cell_mut(nc).attrs.push("retention".into());
                for p in &cell.pins {
                    if let Some(n) = p.net {
                        nl.connect_name(nc, &p.name, n);
                    }
                }
                for pin in rc.pins.iter().filter(|p| p.retention_pin.is_some() || ["SAVE", "RESTORE", "RET", "NRET", "SLEEP"].contains(&p.name.to_uppercase().as_str())) {
                    let role = pin.retention_pin.clone().unwrap_or_else(|| pin.name.to_lowercase());
                    let sig = if role.contains("restore") { s.restore.clone() } else { s.save.clone().or(s.restore.clone()) };
                    if let Some((sn, _)) = sig {
                        if let Some(net) = nl.net_by_name(&sn).or_else(|| nl.port_by_name(&sn).and_then(|p| nl.ports[p].net)) {
                            nl.connect_name(nc, &pin.name, net);
                            self.aon_nets.insert(nl.net(net).name.clone());
                        } else {
                            crate::error!("UPF-231", "Retention control signal '{}' not found", sn);
                        }
                    }
                }
                nret += 1;
            }
        }
        self.committed = true;
        for (st, (what, k)) in &no_iso_cell {
            crate::error!("UPF-212", "No usable isolation cell implements {} (strategy {}): {} crossing net(s) left unisolated (check set_dont_use / -lib_cells)", what, st, k);
        }
        Ok((niso, nls, nret))
    }

    pub fn report(&self) -> Vec<String> {
        let mut o = vec![];
        o.push(format!("UPF version: {}   scope: {}", if self.version.is_empty() { "(unspecified)" } else { &self.version }, if self.scope.is_empty() { "/" } else { &self.scope }));
        o.push(format!("{:<14} {:<10} {:<10} {:<10} {}", "Domain", "Voltage", "Switchable", "Primary", "Elements"));
        for d in &self.domains {
            o.push(format!(
                "{:<14} {:<10} {:<10} {:<10} {}",
                d.name,
                self.domain_voltage(&d.name).map(|v| format!("{:.3}", v)).unwrap_or("-".into()),
                if self.switchable(&d.name) { "yes" } else { "no" },
                self.domain_power(d).unwrap_or("-".into()),
                if d.elements.is_empty() { "(scope)".into() } else { d.elements.join(" ") }
            ));
        }
        for s in &self.iso {
            o.push(format!("  isolation {:<12} domain={} applies_to={} clamp={} signal={} sense={} location={}{}", s.name, s.domain, s.applies_to, s.clamp, s.signal.clone().unwrap_or("-".into()), s.sense, s.location, if s.none { " (no_isolation)" } else { "" }));
        }
        for s in &self.ls {
            o.push(format!("  level_shifter {:<8} domain={} applies_to={} rule={} location={}", s.name, s.domain, s.applies_to, s.rule, s.location));
        }
        for s in &self.ret {
            o.push(format!("  retention {:<12} domain={} save={:?} restore={:?}", s.name, s.domain, s.save, s.restore));
        }
        for s in &self.switches {
            o.push(format!("  power_switch {:<9} domain={} in={} out={} ctrl={}", s.name, s.domain, s.input, s.output, s.control));
        }
        for (p, sup, st) in &self.psts {
            o.push(format!("  PST {} supplies={:?} states={}", p, sup, st.len()));
        }
        o
    }

    /// Multi-voltage design rule check of the current netlist.
    pub fn check(&self, nl: &Netlist, lib: &Library) -> Vec<String> {
        let mut v = vec![];
        let mut seen: HashMap<(String, String), usize> = HashMap::new();
        for n in nl.net_ids() {
            let Some(d) = nl.driver(n) else { continue };
            let Some(dd) = self.pin_domain(nl, d) else { continue };
            let dcell_iso = matches!(d, PinRef::Cell(c, _) if nl.cell(c).has_attr("iso"));
            for l in nl.loads(n) {
                let Some(ld) = self.pin_domain(nl, l) else { continue };
                if ld == dd {
                    continue;
                }
                if let PinRef::Cell(lc, _) = l {
                    // isolation / level-shifter cells are domain-boundary cells
                    if nl.cell(lc).has_attr("iso") || nl.cell(lc).has_attr("ls") {
                        *seen.entry((dd.clone(), ld.clone())).or_default() += 1;
                        continue;
                    }
                }
                *seen.entry((dd.clone(), ld.clone())).or_default() += 1;
                if self.switchable(&dd) && !self.switchable(&ld) && !dcell_iso {
                    let iso_load = matches!(l, PinRef::Cell(c, _) if nl.cell(c).has_attr("iso"));
                    if !iso_load {
                        v.push(format!("MV-ISO: missing isolation on '{}' ({} -> {})", nl.net(n).name, dd, ld));
                    }
                }
                if let (Some(a), Some(b)) = (self.domain_voltage(&dd), self.domain_voltage(&ld)) {
                    let ls_present = matches!(l, PinRef::Cell(c, _) if nl.cell(c).has_attr("ls")) || matches!(d, PinRef::Cell(c, _) if nl.cell(c).has_attr("ls"));
                    if (a - b).abs() > 1e-6 && !ls_present && !self.ls.iter().any(|s| s.none && (s.domain == dd || s.domain == ld)) {
                        v.push(format!("MV-LS: missing level shifter on '{}' ({} {}V -> {} {}V)", nl.net(n).name, dd, a, ld, b));
                    }
                }
            }
        }
        // always-on: buffers in switchable domains driving AON control nets must be AON cells
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            let Some(lc) = cell.lib().and_then(|l| lib.cells.get(l)) else { continue };
            if !lc.is_buf && !lc.is_inv {
                continue;
            }
            let Some(dom) = self.domain_of(&cell.name) else { continue };
            if !self.switchable(&dom) || lc.always_on {
                continue;
            }
            if cell.pins.iter().filter(|p| p.dir == Dir::Out).filter_map(|p| p.net).any(|n| self.aon_nets.contains(&nl.net(n).name)) {
                v.push(format!("MV-AON: buffer '{}' ({}) in switchable domain '{}' drives always-on control net; use an always-on buffer", cell.name, lc.name, dom));
            }
        }
        let mut uniq = std::collections::BTreeSet::new();
        v.retain(|x| uniq.insert(x.clone()));
        let mut sum: Vec<String> = seen.iter().map(|((a, b), n)| format!("crossing {} -> {}: {} pin(s)", a, b, n)).collect();
        sum.sort();
        v.extend(sum);
        v
    }
}
