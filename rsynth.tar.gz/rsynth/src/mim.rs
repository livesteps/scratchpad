//! Multiply instantiated modules (MIM) on top of the partitions:
//!   * check_mim / report_mim : per instance of a MIM partition — functional identity with the
//!     master (sequential co-simulation of the extracted block netlists through their boundary
//!     ports), structural identity (same cells by relative name, same lib cells, same
//!     connectivity), cell count, area, and the worst setup / hold slack in that instance's
//!     context (endpoints inside the instance and paths through its boundary pins)
//!   * commit_mim : make every instance a copy of the master implementation (the block is then
//!     implemented once): the instance's own logic is replaced by the master's cells, nets inside
//!     are recreated, boundary nets map pin-by-pin through the preserved boundary, placement is
//!     mapped into the instance's region with its orientation; refused when an instance is not
//!     functionally identical to the master (unless -force). Re-running it propagates an ECO
//!     made on the master to every instance (`-master` picks another source instance).
use crate::netlist::{Dir, Kind, NetId, Netlist, PinRef};
use crate::part::Partition;
use crate::paths::PathQuery;
use crate::session::*;
use crate::sta::Timing;
use crate::tcl::{split_list, Flow};
use std::collections::{BTreeMap, HashMap, HashSet};
type R = Result<String, Flow>;

fn err(m: impl Into<String>) -> R {
    Err(Flow::Err(m.into()))
}
fn under(name: &str, inst: &str) -> bool {
    name.starts_with(&format!("{}/", inst))
}

/// map a point of a w x h block (master frame, orientation N) into the placed frame of an
/// instance with orientation `o` (DEF semantics: the placed bounding box keeps its lower-left)
pub fn orient_point(o: &str, w: f64, h: f64, u: f64, v: f64) -> (f64, f64) {
    match o {
        "S" => (w - u, h - v),
        "FN" => (w - u, v),
        "FS" => (u, h - v),
        "W" => (h - v, u),
        "E" => (v, w - u),
        "FW" => (h - v, w - u),
        "FE" => (v, u),
        _ => (u, v),
    }
}

impl Session {
    pub(crate) fn mim_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "check_mim" | "report_mim" => self.c_report_mim(a),
            "commit_mim" | "propagate_mim_eco" | "make_mim_identical" => self.c_commit_mim(a),
            _ => return None,
        })
    }

    fn mim_parts(&self, x: &A) -> Result<Vec<Partition>, Flow> {
        let sel: Option<Vec<String>> = x.get("-partition").or(x.get("-partitions")).map(|s| split_list(s));
        let v: Vec<Partition> = self.partitions.iter().filter(|p| p.is_mim() && sel.as_ref().map(|s| s.contains(&p.name)).unwrap_or(true)).cloned().collect();
        if v.is_empty() {
            return Err(Flow::Err(format!("no multiply instantiated partition{} (create_partition with several instances) (MIM-020)", sel.map(|s| format!(" named {}", s.join(" "))).unwrap_or_default())));
        }
        Ok(v)
    }

    /// the block netlist of one instance (boundary pins become ports)
    pub(crate) fn instance_block(&self, p: &Partition, inst: &str) -> Result<Netlist, Flow> {
        let nl = self.nl()?;
        let ports = self.part_ports_of(p, inst);
        let mut blk = Netlist::new(&p.name);
        let mut bnet: HashMap<NetId, NetId> = HashMap::new();
        for bp in ports.iter().filter(|b| !b.feed) {
            let pid = blk.add_port(&bp.name, if bp.input { Dir::In } else { Dir::Out });
            let pn = blk.ports[pid].net.unwrap();
            let inner = match bp.inside.as_slice() {
                [PinRef::Cell(hc, k)] if nl.cell(*hc).is_hport() => (0..nl.cell(*hc).pins.len()).find(|q| q != k).and_then(|q| nl.cell(*hc).pins[q].net),
                _ => None,
            };
            let key = inner.unwrap_or(bp.net);
            match bnet.get(&key).copied() {
                Some(prev) => blk.merge_net(prev, pn),
                None => {
                    bnet.insert(key, pn);
                }
            }
        }
        let pfx = format!("{}/", inst);
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            if !under(&cell.name, inst) || nl.hier_pin_of(c).map(|(i, _)| i == inst).unwrap_or(false) {
                continue;
            }
            let pins: Vec<(&str, Dir)> = cell.pins.iter().map(|q| (q.name.as_str(), q.dir)).collect();
            let k = blk.add_cell(cell.name.strip_prefix(&pfx).unwrap_or(&cell.name), cell.kind.clone(), &pins);
            blk.cell_mut(k).attrs = cell.attrs.clone();
            for (i, q) in cell.pins.iter().enumerate() {
                if let Some(n) = q.net {
                    let bn = match bnet.get(&n) {
                        Some(x) => *x,
                        None => {
                            let x = match crate::genopt::const_of(nl, n) {
                                Some(v) => crate::genopt::const_net(&mut blk, v),
                                None => blk.add_net(nl.net(n).name.strip_prefix(&pfx).unwrap_or(&nl.net(n).name)),
                            };
                            bnet.insert(n, x);
                            x
                        }
                    };
                    blk.connect(k, i, bn);
                }
            }
        }
        blk.mapped = nl.mapped;
        Ok(blk)
    }

    /// relative structure of an instance: cell -> (reference, [pin -> net class])
    fn mim_signature(&self, inst: &str) -> Result<BTreeMap<String, (String, Vec<String>)>, Flow> {
        let nl = self.nl()?;
        let pfx = format!("{}/", inst);
        let mut m = BTreeMap::new();
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            if !under(&cell.name, inst) || nl.hier_pin_of(c).map(|(i, _)| i == inst).unwrap_or(false) {
                continue;
            }
            let rf = match &cell.kind {
                Kind::Lib(l) => l.clone(),
                Kind::BlackBox(b) => format!("bb:{}", b),
                Kind::Gen(g) => format!("{:?}", g),
            };
            let pins: Vec<String> = cell
                .pins
                .iter()
                .map(|q| match q.net {
                    None => format!("{}=-", q.name),
                    Some(n) => {
                        if let Some(v) = crate::genopt::const_of(nl, n) {
                            return format!("{}=const{}", q.name, v as u8);
                        }
                        // boundary net: the module port it reaches
                        for pr in &nl.net(n).conns {
                            if let PinRef::Cell(hc, _) = pr {
                                if let Some((i, port)) = nl.hier_pin_of(*hc) {
                                    if i == inst {
                                        return format!("{}=port:{}", q.name, port);
                                    }
                                }
                            }
                        }
                        format!("{}={}", q.name, nl.net(n).name.strip_prefix(&pfx).unwrap_or(&nl.net(n).name))
                    }
                })
                .collect();
            m.insert(cell.name[pfx.len()..].to_string(), (rf, pins));
        }
        Ok(m)
    }

    fn mim_equal(&self, p: &Partition, inst: &str, cycles: usize, resets: &[String]) -> Result<(bool, usize, Vec<String>), Flow> {
        let gold = self.instance_block(p, &p.inst)?;
        let rev = self.instance_block(p, inst)?;
        let r = crate::sim::equivalence(&gold, &rev, &self.libs, cycles, &HashMap::new(), resets, 7).map_err(|e| Flow::Err(format!("MIM equivalence {} vs {}: {}", inst, p.inst, e)))?;
        let mism: Vec<String> = r.mismatches.iter().take(4).map(|(cy, o, g, v)| format!("{} at cycle {} (master {}, {} {})", o, cy, *g as u8, inst, *v as u8)).collect();
        Ok((r.mismatches.is_empty(), r.compared_outputs, mism))
    }

    fn default_resets(&self, p: &Partition, x: &A) -> Vec<String> {
        match x.get("-resets") {
            Some(r) => split_list(r),
            None => self.part_ports_of(p, &p.inst).iter().filter(|b| b.input && (b.name.contains("rst") || b.name.contains("reset"))).map(|b| b.name.clone()).collect(),
        }
    }

    /// worst setup/hold slack of one instance context: endpoints inside it, and paths through
    /// its boundary pins
    fn mim_context_slack(&self, inst: &str, si: usize) -> Result<(f64, f64, usize), Flow> {
        let nl = self.nl()?;
        let (cons, corner) = self.scen_corner_mode_pub(si);
        let ls = self.libset(&corner);
        let mut t = Timing::new(nl, &ls, cons, &corner, self.sta_opts());
        t.run();
        let (mut s, mut h, mut viol) = (f64::INFINITY, f64::INFINITY, 0usize);
        for ep in &t.endpoints {
            if under(&ep.name, inst) {
                s = s.min(ep.setup_slack);
                h = h.min(ep.hold_slack);
                if ep.setup_slack < 0.0 {
                    viol += 1;
                }
            }
        }
        // outputs of the instance: paths starting inside and leaving through its boundary
        let outs: HashSet<u32> = nl
            .cell_ids()
            .into_iter()
            .filter(|c| nl.hier_pin_of(*c).map(|(i, _)| i == inst).unwrap_or(false) && nl.cell(*c).attrs.iter().any(|a| a.starts_with("hp:") && a.ends_with(":o")))
            .flat_map(|c| (0..nl.cell(c).pins.len()).map(move |k| PinRef::Cell(c, k)))
            .filter_map(|pr| t.idx.get(&pr).copied())
            .collect();
        if !outs.is_empty() {
            for hold in [false, true] {
                let q = PathQuery { hold, through: vec![outs.clone()], max_paths: 1, nworst: 1, max_pops: 50_000, ..Default::default() };
                if let Some(r) = t.enumerate_paths(&q).first() {
                    if hold {
                        h = h.min(r.slack);
                    } else {
                        s = s.min(r.slack);
                    }
                }
            }
        }
        Ok((s, h, viol))
    }

    fn c_report_mim(&mut self, a: &[String]) -> R {
        let x = args(a, &["-partition", "-partitions", "-cycles", "-resets", "-scenarios"]);
        let parts = self.mim_parts(&x)?;
        let cycles = x.num("-cycles").unwrap_or(1000.0) as usize;
        let no_timing = x.has("-no_timing");
        let scen_setup = self.active("setup").first().copied();
        let scen_hold = self.active("hold").first().copied();
        let mut bad = 0;
        for p in &parts {
            let resets = self.default_resets(p, &x);
            let sig0 = self.mim_signature(&p.inst)?;
            crate::out!("\n  MIM partition {}  ({} instances, master {}{})", p.name, p.insts().len(), p.inst, if p.committed { ", committed" } else { "" });
            crate::out!("  {:<26} {:<6} {:>6} {:>9} {:<10} {:<22} {:>9} {:>9} {:>5}", "instance", "orient", "cells", "area", "function", "structure", "WNS", "WHS", "NVP");
            for (k, inst) in p.insts().iter().enumerate() {
                let sig = self.mim_signature(inst)?;
                let nl = self.nl()?;
                let area: f64 = nl.cell_ids().iter().filter(|c| under(&nl.cell(**c).name, inst)).filter_map(|c| nl.cell(*c).lib()).filter_map(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|c| c.area).sum();
                let (func, mism) = if k == 0 {
                    ("master".to_string(), vec![])
                } else {
                    let (ok, n, m) = self.mim_equal(p, inst, cycles, &resets)?;
                    (if ok { format!("equal({})", n) } else { "DIFFERENT".to_string() }, m)
                };
                let mut verbose_diffs: Vec<String> = vec![];
                let structure = if k == 0 {
                    "-".to_string()
                } else if sig == sig0 {
                    "identical".to_string()
                } else {
                    let diffs: Vec<String> = sig0.iter().filter(|(c, v)| sig.get(*c) != Some(v)).map(|(c, v)| format!("{}: master {} {:?} / {:?}", c, v.0, v.1, sig.get(c))).chain(sig.keys().filter(|c| !sig0.contains_key(*c)).map(|c| format!("{}: only in {}", c, inst))).collect();
                    verbose_diffs = diffs.iter().take(6).cloned().collect();
                    format!("differs ({} cells)", diffs.len())
                };
                let (ws, wh, nv) = if no_timing {
                    (f64::NAN, f64::NAN, 0)
                } else {
                    let s = scen_setup.map(|si| self.mim_context_slack(inst, si)).transpose()?.unwrap_or((f64::NAN, f64::NAN, 0));
                    let h = scen_hold.map(|si| self.mim_context_slack(inst, si)).transpose()?.unwrap_or((f64::NAN, f64::NAN, 0));
                    (s.0, h.1, s.2)
                };
                if func == "DIFFERENT" {
                    bad += 1;
                }
                let f = |v: f64| if v.is_finite() { format!("{:.4}", v) } else { "-".into() };
                crate::out!("  {:<26} {:<6} {:>6} {:>9.2} {:<10} {:<22} {:>9} {:>9} {:>5}", inst, p.orient_of(k), sig.len(), area, func, structure, f(ws), f(wh), nv);
                for m in mism {
                    crate::out!("      mismatch: {}", m);
                }
                if x.has("-verbose") {
                    for d in &verbose_diffs {
                        crate::out!("      structure: {}", d);
                    }
                }
            }
        }
        if bad > 0 {
            crate::warn!("MIM-210", "{} instance(s) are not functionally identical to their master", bad);
        }
        Ok(bad.to_string())
    }

    fn c_commit_mim(&mut self, a: &[String]) -> R {
        let x = args(a, &["-partition", "-partitions", "-master", "-cycles", "-resets"]);
        let parts = self.mim_parts(&x)?;
        let cycles = x.num("-cycles").unwrap_or(1000.0) as usize;
        let force = x.has("-force");
        let mut total = 0;
        for mut p in parts {
            // another source instance (e.g. an ECO was done there)
            if let Some(m) = x.get("-master") {
                let Some(k) = p.insts().iter().position(|i| i == m) else { return err(format!("commit_mim: '{}' is not an instance of partition '{}' (MIM-021)", m, p.name)) };
                if p.orient_of(k) != "N" && self.fp.is_some() {
                    return err(format!("commit_mim: -master '{}' has orientation {}; the source must be an N instance (MIM-022)", m, p.orient_of(k)));
                }
                p.instances.swap(0, k);
                p.bounds.swap(0, k);
                p.orients.swap(0, k);
                p.inst = m.clone();
            }
            let resets = self.default_resets(&p, &x);
            let master = p.inst.clone();
            // identity check before replacing anything
            for inst in p.insts().iter().skip(1) {
                let (ok, n, mism) = self.mim_equal(&p, inst, cycles, &resets)?;
                if !ok && !force {
                    return err(format!("commit_mim: '{}' is not functionally identical to the master '{}' ({} of {} outputs differ: {}); use -force to overwrite it with the master (MIM-023)", inst, master, mism.len(), n, mism.join("; ")));
                }
                if !ok {
                    crate::warn!("MIM-120", "commit_mim -force: '{}' differs from the master and is overwritten", inst);
                }
            }
            let sig0 = self.mim_signature(&master)?;
            let region = |s: &Session, b: Option<String>| -> Option<(f64, f64, f64, f64)> { s.fp.as_ref().and_then(|fp| b.and_then(|n| fp.bounds.iter().find(|q| q.name == n).and_then(|q| q.resolved.or(q.rect)))) };
            let mr = region(self, p.bound_of(0));
            let mut replaced = 0;
            let mut new_cells_all = vec![];
            for (k, inst) in p.insts().iter().enumerate().skip(1) {
                if self.mim_signature(inst)? == sig0 {
                    continue; // already identical
                }
                let ir = region(self, p.bound_of(k));
                let orient = p.orient_of(k);
                let nl = self.nl.as_mut().unwrap();
                let mpfx = format!("{}/", master);
                // placement frame: regions, else the cell bounding boxes
                let bbox = |nl: &Netlist, i: &str| -> Option<(f64, f64, f64, f64)> {
                    let mut r: Option<(f64, f64, f64, f64)> = None;
                    for c in nl.cell_ids() {
                        if under(&nl.cell(c).name, i) {
                            if let Some((x, y)) = nl.cell(c).loc {
                                r = Some(match r {
                                    None => (x, y, x, y),
                                    Some(b) => (b.0.min(x), b.1.min(y), b.2.max(x), b.3.max(y)),
                                });
                            }
                        }
                    }
                    r
                };
                let mframe = mr.or_else(|| bbox(nl, &master));
                let iframe = ir.or_else(|| bbox(nl, inst));
                // boundary: master inner net -> instance inner net (per module port)
                let mut nmap: HashMap<NetId, NetId> = HashMap::new();
                let hp_inner = |nl: &Netlist, i: &str| -> HashMap<String, NetId> {
                    let mut m = HashMap::new();
                    for c in nl.cell_ids() {
                        if let Some((h, port)) = nl.hier_pin_of(c) {
                            if h == i {
                                let input = nl.cell(c).attrs.iter().any(|a| a.starts_with("hp:") && a.ends_with(":i"));
                                // input: A outer, Y inner ; output: A inner, Y outer
                                let pin = nl.cell(c).pins.iter().position(|q| q.dir == if input { Dir::Out } else { Dir::In });
                                if let Some(n) = pin.and_then(|q| nl.cell(c).pins[q].net) {
                                    m.insert(port, n);
                                }
                            }
                        }
                    }
                    m
                };
                let mi = hp_inner(nl, &master);
                let ii = hp_inner(nl, inst);
                for (port, mn) in &mi {
                    match ii.get(port) {
                        Some(n) => {
                            nmap.insert(*mn, *n);
                        }
                        None => return err(format!("commit_mim: boundary pin '{}' missing on '{}' (MIM-024)", port, inst)),
                    }
                }
                // remove the instance's own logic (its boundary pins stay)
                let olds: Vec<usize> = nl.cell_ids().into_iter().filter(|c| under(&nl.cell(*c).name, inst) && !nl.hier_pin_of(*c).map(|(h, _)| &h == inst).unwrap_or(false)).collect();
                for c in &olds {
                    nl.remove_cell(*c);
                }
                nl.sweep_nets(); // frees the old net names for the copies
                // copy the master's cells
                let mcells: Vec<usize> = nl.cell_ids().into_iter().filter(|c| under(&nl.cell(*c).name, &master) && !nl.hier_pin_of(*c).map(|(h, _)| h == master).unwrap_or(false)).collect();
                for &mc in &mcells {
                    let cell = nl.cell(mc).clone();
                    let rel = &cell.name[mpfx.len()..];
                    let pins: Vec<(&str, Dir)> = cell.pins.iter().map(|q| (q.name.as_str(), q.dir)).collect();
                    let nc = nl.add_cell(&format!("{}/{}", inst, rel), cell.kind.clone(), &pins);
                    {
                        let c2 = nl.cell_mut(nc);
                        c2.attrs = cell.attrs.clone();
                        c2.dont_touch = cell.dont_touch;
                        c2.fixed = cell.fixed;
                    }
                    if let (Some((x, y)), Some(mf), Some(inf)) = (cell.loc, mframe, iframe) {
                        let (w, h) = (mf.2 - mf.0, mf.3 - mf.1);
                        let (u, v) = (x - mf.0, y - mf.1);
                        let (a2, b2) = orient_point(&orient, w, h, u, v);
                        nl.cell_mut(nc).loc = Some((inf.0 + a2, inf.1 + b2));
                    }
                    for (pi, q) in cell.pins.iter().enumerate() {
                        let Some(n) = q.net else { continue };
                        let tn = match nmap.get(&n) {
                            Some(t) => *t,
                            None => {
                                if crate::genopt::const_of(nl, n).is_some() {
                                    n
                                } else if nl.net(n).conns.iter().all(|pr| matches!(pr, PinRef::Cell(c, _) if under(&nl.cell(*c).name, &master))) {
                                    let nm = nl.net(n).name.clone();
                                    let rel = nm.strip_prefix(&mpfx).map(|r| format!("{}/{}", inst, r)).unwrap_or(format!("{}/{}", inst, nm));
                                    let mut nn = rel.clone();
                                    let mut kk = 1;
                                    while nl.net_by_name(&nn).is_some() {
                                        nn = format!("{}_{}", rel, kk);
                                        kk += 1;
                                    }
                                    let t = nl.add_net(&nn);
                                    nmap.insert(n, t);
                                    t
                                } else {
                                    return err(format!("commit_mim: net '{}' connects the master's logic to the outside without a boundary pin (MIM-025)", nl.net(n).name));
                                }
                            }
                        };
                        nl.connect(nc, pi, tn);
                    }
                    new_cells_all.push(nc);
                }
                nl.sweep_nets();
                replaced += 1;
                crate::info!("MIM-200", "'{}' <- copy of '{}': {} cells replaced by {} (orientation {})", inst, master, olds.len(), mcells.len(), orient);
            }
            // keep a legal placement after mapping into the regions
            if self.fp.is_some() && !new_cells_all.is_empty() && self.nl.as_ref().map(|n| n.cell_ids().iter().any(|c| n.cell(*c).loc.is_some())).unwrap_or(false) {
                let _ = self.fp_legalize(Some(new_cells_all.clone()), false, true);
            }
            if let Some(q) = self.partitions.iter_mut().find(|q| q.name == p.name) {
                q.committed = true;
            }
            total += replaced;
            crate::info!("MIM-201", "Partition '{}': {} instance(s) made identical to '{}'; every instance now uses one implementation", p.name, replaced, master);
        }
        self.bump_epoch();
        Ok(total.to_string())
    }
}

#[allow(dead_code)]
fn _u(_: &Netlist) {}

#[cfg(test)]
mod tests {
    use super::orient_point;
    #[test]
    fn mim_orientation_matches_gds_transform() {
        let (w, h) = (50.0, 30.0);
        for o in ["N", "S", "E", "W", "FN", "FS", "FE", "FW"] {
            let (refl, ang) = crate::gds::orient_tf(o);
            let tf = |x: f64, y: f64| -> (f64, f64) {
                let y = if refl { -y } else { y };
                match ang {
                    90 => (-y, x),
                    180 => (-x, -y),
                    270 => (y, -x),
                    _ => (x, y),
                }
            };
            let cs = [tf(0.0, 0.0), tf(w, 0.0), tf(w, h), tf(0.0, h)];
            let (mx, my) = (cs.iter().map(|c| c.0).fold(f64::MAX, f64::min), cs.iter().map(|c| c.1).fold(f64::MAX, f64::min));
            for (u, v) in [(0.0, 0.0), (10.0, 5.0), (w, h), (3.5, 29.0)] {
                let g = tf(u, v);
                let p = orient_point(o, w, h, u, v);
                assert!((g.0 - mx - p.0).abs() < 1e-9 && (g.1 - my - p.1).abs() < 1e-9, "{}: ({},{}) gds {:?} mim {:?}", o, u, v, (g.0 - mx, g.1 - my), p);
            }
        }
    }
}
