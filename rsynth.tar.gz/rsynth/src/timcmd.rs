//! Timing-constraint and analysis commands:
//!   read_parasitics / read_spef (per corner / scenario), report_annotated_parasitics,
//!   remove_parasitics; set_annotated_delay / remove_annotated_delay / report_annotated_delay;
//!   set_timing_derate with -net/-cell/-clock/-data and object lists, reset_timing_derate,
//!   report_timing_derate; path_adjust / set_path_adjust; set_analysis_type / report_analysis_type
//!   (and set_operating_conditions -analysis_type).
use crate::cons::{Obj, ObjDerate};
use crate::netlist::PinRef;
use crate::session::*;
use crate::sta::AnnDelay;
use crate::tcl::{split_list, to_list, Flow};
use std::collections::HashMap;
use std::sync::Arc;
type R = Result<String, Flow>;

fn err(m: impl Into<String>) -> R {
    Err(Flow::Err(m.into()))
}

impl Session {
    pub(crate) fn tim_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "read_parasitics" | "read_spef" => self.c_read_parasitics(a),
            "report_annotated_parasitics" => self.c_report_annotated_parasitics(a),
            "remove_parasitics" | "remove_annotated_parasitics" | "reset_parasitics" => {
                let x = args(a, &["-corners", "-corner"]);
                let cs: Vec<String> = x.get("-corners").or(x.get("-corner")).map(|s| split_list(s)).unwrap_or_else(|| self.spef_rc.keys().cloned().collect());
                let mut n = 0;
                for c in cs {
                    if self.spef_rc.remove(&c).is_some() {
                        n += 1;
                    }
                    self.spef_stats.remove(&c);
                }
                crate::info!("PARA-110", "Removed annotated parasitics of {} corner(s)", n);
                Ok(n.to_string())
            }
            "set_annotated_delay" => self.c_set_annotated_delay(a),
            "remove_annotated_delay" | "reset_annotated_delay" => {
                let x = args(a, &["-from", "-to"]);
                let before = self.ann_delays.len();
                if x.has("-all") || (x.get("-from").is_none() && x.get("-to").is_none()) {
                    self.ann_delays.clear();
                } else {
                    let f: Vec<String> = x.get("-from").map(|s| self.pin_names(s)).unwrap_or_default();
                    let t: Vec<String> = x.get("-to").map(|s| self.pin_names(s)).unwrap_or_default();
                    self.ann_delays.retain(|(d, _)| !((f.is_empty() || f.contains(&d.0)) && (t.is_empty() || t.contains(&d.1))));
                }
                Ok((before - self.ann_delays.len()).to_string())
            }
            "report_annotated_delay" => {
                crate::out!("\n****************************************\nReport : annotated_delay\n****************************************");
                crate::out!("  {:<44} {:<44} {:<5} {:<9} {:<9} {:>9} {}", "From", "To", "Type", "Edge", "Min/Max", "Value", "Corners");
                for ((f, t, ty), d) in &self.ann_delays {
                    let edge = match (d.rise, d.fall) {
                        (true, true) => "rise/fall",
                        (true, false) => "rise",
                        _ => "fall",
                    };
                    let mm = match (d.max, d.min) {
                        (true, true) => "min/max",
                        (true, false) => "max",
                        _ => "min",
                    };
                    crate::out!("  {:<44} {:<44} {:<5} {:<9} {:<9} {:>9.4}{} {}", f, t, ty, edge, mm, d.value, if d.incr { " (incr)" } else { "" }, if d.corners.is_empty() { "all".to_string() } else { d.corners.join(",") });
                }
                crate::out!("  {} annotated delay(s)", self.ann_delays.len());
                Ok(self.ann_delays.len().to_string())
            }
            "set_timing_derate" => self.c_set_timing_derate(a),
            "reset_timing_derate" => {
                let x = args(a, &["-corners", "-corner"]);
                let cs: Vec<String> = x.get("-corners").or(x.get("-corner")).map(|s| split_list(s)).unwrap_or_else(|| self.corners.iter().map(|c| c.name.clone()).collect());
                for c in &cs {
                    if let Some(k) = self.corners.iter_mut().find(|k| &k.name == c) {
                        k.late_cell = 1.0;
                        k.early_cell = 1.0;
                        k.late_net = 1.0;
                        k.early_net = 1.0;
                        k.late_cell_clk = None;
                        k.early_cell_clk = None;
                        k.late_net_clk = None;
                        k.early_net_clk = None;
                        k.obj_derates.clear();
                    }
                }
                Ok(cs.len().to_string())
            }
            "report_timing_derate" => self.c_report_timing_derate(a),
            "path_adjust" | "set_path_adjust" => {
                // path_adjust -delay <value> [-from] [-to] [-through] [-setup|-hold]: extra delay on matching paths
                let x = args(a, &["-delay", "-from", "-to", "-through", "-view", "-views", "-rise_from", "-fall_from", "-rise_to", "-fall_to"]);
                let v = x.get("-delay").cloned().or(x.pos.iter().find(|p| p.parse::<f64>().is_ok()).cloned());
                let Some(v) = v else { return Some(err(format!("{}: -delay <value> is required (TIM-320)", name))) };
                if x.get("-view").or(x.get("-views")).is_some() {
                    crate::info!("TIM-321", "{}: -view is applied to every scenario of the current mode", name);
                }
                let mut f = vec![v];
                for k in ["-from", "-to", "-through", "-rise_from", "-fall_from", "-rise_to", "-fall_to"] {
                    if let Some(s) = x.get(k) {
                        f.push(k.into());
                        f.push(s.clone());
                    }
                }
                for k in ["-setup", "-hold"] {
                    if x.has(k) {
                        f.push(k.into());
                    }
                }
                self.cmd("set_path_margin", &f).unwrap_or(Ok(String::new()))
            }
            "reset_path_adjust" | "remove_path_adjust" => self.cmd("remove_path_margin", &[]).unwrap_or(Ok(String::new())),
            "report_path_adjust" | "report_path_margin" => {
                let pm = self.modes[self.cur_mode].sdc.path_margins.clone();
                crate::out!("\n  {:>9}  {:<6} {:<40} {:<40}", "Delay", "Checks", "From", "To");
                for m in &pm {
                    let names = |v: &Vec<Obj>| if v.is_empty() { "*".to_string() } else { v.iter().map(|o| o.name().to_string()).collect::<Vec<_>>().join(" ") };
                    crate::out!("  {:>9.4}  {:<6} {:<40} {:<40}", m.value, match (m.setup, m.hold) { (true, true) => "both", (true, false) => "setup", _ => "hold" }, names(&m.from), names(&m.to));
                }
                Ok(pm.len().to_string())
            }
            "set_analysis_type" => self.c_set_analysis_type(a),
            "define_name_rules" => self.c_define_name_rules(a),
            "report_name_rules" => {
                let mut names: Vec<&String> = self.name_rules.keys().collect();
                names.sort();
                for n in names {
                    let r = &self.name_rules[n];
                    crate::out!("  {}: replacement '{}', hierarchy delimiter {:?}, hier bus char {:?}, dot char {:?}, bus style {}, angle->square {}, max length {:?}, types {:?}", n, r.replacement, r.hier_delimiter, r.hier_bus_char, r.dot_char, r.bus_style, r.angle_to_square, r.max_length, r.types);
                }
                crate::out!("  built-in: verilog, vhdl");
                Ok(self.name_rules.len().to_string())
            }
            "change_names" | "report_names" => self.c_change_names(name, a),
            "report_analysis_type" | "report_analysis_coverage_type" => {
                crate::out!("\n  Analysis type: {}", self.analysis_type);
                for s in &self.scens {
                    crate::out!("    scenario {:<12} corner {:<8} active {:<5} setup {:<5} hold {}", s.name, s.corner, s.active, s.setup, s.hold);
                }
                Ok(self.analysis_type.clone())
            }
            _ => return None,
        })
    }

    fn pin_names(&self, spec: &str) -> Vec<String> {
        self.objs(spec, "any").into_iter().map(|o| o.name().to_string()).collect()
    }

    // ------------------------------------------------------------------ name rules

    fn rules_named(&self, n: &str) -> Option<crate::names::NameRules> {
        self.name_rules.get(n).cloned().or_else(|| crate::names::NameRules::builtin(n))
    }

    fn c_define_name_rules(&mut self, a: &[String]) -> R {
        let x = args(
            a,
            &["-allowed", "-first_restricted", "-last_restricted", "-replacement_char", "-max_length", "-map", "-type", "-target_bus_naming_style", "-hierarchy_delimiter", "-hier_delimiter", "-hier_bus_char", "-bussed_hier_char", "-dot_char", "-from", "-bus_bit_chars"],
        );
        let Some(name) = x.pos.first().cloned() else { return err("define_name_rules: rule name required (NAME-001)") };
        let mut r = if x.has("-reset") { None } else { self.name_rules.get(&name).cloned() }
            .or_else(|| x.get("-from").and_then(|f| self.rules_named(f)))
            .unwrap_or_else(|| crate::names::NameRules::new(&name));
        r.name = name.clone();
        let ch1 = |k: &str| -> Result<Option<char>, Flow> {
            match x.get(k) {
                None => Ok(None),
                Some(v) => {
                    let v = v.trim_matches('"');
                    let mut it = v.chars();
                    match (it.next(), it.next()) {
                        (Some(c), None) => Ok(Some(c)),
                        _ => Err(Flow::Err(format!("define_name_rules {}: a single character is required, got '{}' (NAME-002)", k, v))),
                    }
                }
            }
        };
        if let Some(v) = x.get("-allowed") {
            r.set_allowed(v.trim_matches('"'));
        }
        if let Some(v) = x.get("-first_restricted") {
            r.set_first(v.trim_matches('"'));
        }
        if let Some(v) = x.get("-last_restricted") {
            r.set_last(v.trim_matches('"'));
        }
        if let Some(c) = ch1("-replacement_char")? {
            r.replacement = c;
        }
        if let Some(v) = x.num("-max_length") {
            r.max_length = Some(v as usize);
        }
        if let Some(m) = x.get("-map") {
            for pair in split_list(m) {
                let p = split_list(&pair);
                if p.len() == 2 {
                    r.map.push((p[0].trim_matches('"').to_string(), p[1].trim_matches('"').to_string()));
                }
            }
        }
        if let Some(t) = x.get("-type") {
            r.types = split_list(t);
        }
        if let Some(v) = x.get("-target_bus_naming_style") {
            r.bus_style = v.trim_matches('"').to_string();
        }
        if let Some(c) = ch1("-hierarchy_delimiter")?.or(ch1("-hier_delimiter")?) {
            r.hier_delimiter = if c == '/' { None } else { Some(c) };
        }
        if let Some(c) = ch1("-hier_bus_char")?.or(ch1("-bussed_hier_char")?) {
            r.hier_bus_char = Some(c);
        }
        if let Some(c) = ch1("-dot_char")? {
            r.dot_char = Some(c);
        }
        if x.has("-angle_to_square") || x.get("-bus_bit_chars").map(|v| v.contains('[')).unwrap_or(false) {
            r.angle_to_square = true;
        }
        if x.has("-case_insensitive") {
            r.case_insensitive = true;
        }
        if x.has("-equal_ports_nets") {
            r.equal_ports_nets = true;
        }
        if x.has("-no_double_underscore") {
            r.no_double_underscore = true;
        }
        self.name_rules.insert(name.clone(), r);
        crate::info!("NAME-100", "Defined name rules '{}'", name);
        Ok(name)
    }

    fn c_change_names(&mut self, cmd: &str, a: &[String]) -> R {
        let x = args(a, &["-rules", "-log_changes", "-output"]);
        let rn = x.get("-rules").cloned().unwrap_or("verilog".into());
        let Some(rules) = self.rules_named(&rn) else { return err(format!("{}: name rules '{}' are not defined (NAME-003)", cmd, rn)) };
        let apply = cmd == "change_names" && !x.has("-dry_run");
        let nl = self.nl.as_mut().ok_or_else(|| Flow::Err(format!("{}: no design", cmd)))?;
        let ch = crate::names::change_names(nl, &rules, x.has("-hierarchy"), apply);
        let mut by: std::collections::BTreeMap<&str, usize> = Default::default();
        for (t, _, _) in &ch.list {
            *by.entry(t.as_str()).or_default() += 1;
        }
        crate::out!("\n****************************************\nReport : {} -rules {}{}\n****************************************", cmd, rn, if x.has("-hierarchy") { " -hierarchy" } else { "" });
        crate::out!("  cells {}  nets {}  ports {}  hierarchical ports {}  hierarchical instances {}", by.get("cell").unwrap_or(&0), by.get("net").unwrap_or(&0), by.get("port").unwrap_or(&0), by.get("hier_port").unwrap_or(&0), ch.hier.len());
        let verbose = x.has("-verbose") || cmd == "report_names";
        let mut log = String::new();
        for (o, n) in &ch.hier {
            log += &format!("hier_instance {} {}\n", o, n);
        }
        for (t, o, n) in &ch.list {
            log += &format!("{} {} {}\n", t, o, n);
        }
        if verbose {
            for (i, l) in log.lines().enumerate() {
                if cmd == "report_names" && !x.has("-verbose") && i >= 40 {
                    crate::out!("  ... {} more (use -verbose)", ch.list.len() + ch.hier.len() - 40);
                    break;
                }
                let f: Vec<&str> = l.splitn(3, ' ').collect();
                crate::out!("  {:<14} {:<56} -> {}", f[0], f.get(1).unwrap_or(&""), f.get(2).unwrap_or(&""));
            }
        }
        if let Some(f) = x.get("-log_changes").or(x.get("-output")) {
            std::fs::write(f, &log).map_err(|e| Flow::Err(format!("{}: cannot write '{}': {}", cmd, f, e)))?;
        }
        if apply {
            // name references held outside the netlist
            let nl = self.nl.as_ref().unwrap();
            for (_, _, regs) in self.dft.chains.iter_mut() {
                for r in regs.iter_mut() {
                    if let Some(c) = nl.cell_by_name(r) {
                        *r = nl.cell(c).name.clone();
                    }
                }
            }
            if let Some(fp) = self.fp.as_mut() {
                for b in fp.bounds.iter_mut() {
                    for m in b.members.iter_mut() {
                        if let Some(n) = ch.hier.iter().find(|(o, _)| o == m).map(|x| x.1.clone()) {
                            *m = n;
                        }
                    }
                }
            }
            self.bump_epoch();
            crate::info!("NAME-200", "change_names -rules {}: renamed {} object(s); old names remain usable as aliases", rn, ch.list.len() + ch.hier.len());
        }
        Ok((ch.list.len() + ch.hier.len()).to_string())
    }

    // ------------------------------------------------------------------ SPEF

    fn c_read_parasitics(&mut self, a: &[String]) -> R {
        let x = args(a, &["-corners", "-corner", "-scenario", "-scenarios", "-format", "-pin_cap_included", "-path"]);
        if let Some(f) = x.get("-format") {
            if !f.eq_ignore_ascii_case("spef") {
                return err(format!("read_parasitics: format '{}' not supported (SPEF only) (PARA-001)", f));
            }
        }
        let files: Vec<String> = x.pos.iter().flat_map(|p| split_list(p)).collect();
        if files.is_empty() {
            return err("read_parasitics: SPEF file name required (PARA-002)");
        }
        let mut corners: Vec<String> = x.get("-corners").or(x.get("-corner")).map(|s| split_list(s)).unwrap_or_default();
        if let Some(sc) = x.get("-scenario").or(x.get("-scenarios")) {
            for n in split_list(sc) {
                match self.scens.iter().find(|s| s.name == n) {
                    Some(s) => corners.push(s.corner.clone()),
                    None => return err(format!("read_parasitics: scenario '{}' does not exist (MV-SCN)", n)),
                }
            }
        }
        if corners.is_empty() {
            corners = self.corners.iter().map(|c| c.name.clone()).collect();
        }
        for c in &corners {
            if !self.corners.iter().any(|k| &k.name == c) {
                return err(format!("read_parasitics: corner '{}' does not exist (MV-CRN)", c));
            }
        }
        let nl = self.nl()?;
        // load pin caps from the corner's libraries (first corner's)
        let libs = &self.libs;
        let corner0 = self.corners.iter().find(|k| k.name == corners[0]).cloned();
        let pin_cap = |pr: PinRef| -> f64 {
            match pr {
                PinRef::Cell(c, p) => {
                    let cl = nl.cell(c);
                    let Some(l) = cl.lib() else { return 0.0 };
                    let order: Vec<usize> = corner0.as_ref().map(|k| k.libs.clone()).unwrap_or_default();
                    let lc = order.iter().filter_map(|i| libs.get(*i)).chain(libs.iter()).find_map(|x| x.cells.get(l));
                    lc.and_then(|lc| lc.pin(&cl.pins[p].name)).map(|x| x.cap).unwrap_or(0.0)
                }
                PinRef::Port(_) => 0.0,
            }
        };
        // -path inst: a block SPEF annotated onto that hierarchical instance; it is merged with
        // the parasitics already read for the corner (as is -incremental)
        let path = x.get("-path").cloned();
        if let Some(p) = &path {
            if !nl.hier.iter().any(|h| &h.0 == p) && !nl.cell_ids().iter().any(|c| nl.cell(*c).name.starts_with(&format!("{}/", p))) {
                return err(format!("read_parasitics: -path '{}' is not a hierarchical instance (PARA-004)", p));
            }
        }
        let incremental = path.is_some() || x.has("-incremental");
        let mut merged = if incremental { self.spef_rc.get(&corners[0]).map(|r| (**r).clone()).unwrap_or_default() } else { crate::droute::RoutedRc::default() };
        let mut stats = if incremental { self.spef_stats.get(&corners[0]).cloned().unwrap_or_default() } else { crate::spef::SpefStats::default() };
        for f in &files {
            let (rc, st) = crate::spef::read_spef_at(f, nl, &pin_cap, path.as_deref()).map_err(|e| Flow::Err(format!("read_parasitics: {} (PARA-003)", e)))?;
            if path.is_none() && !st.design.is_empty() && st.design != nl.name {
                crate::warn!("PARA-010", "SPEF '{}' is for design '{}', current design is '{}'", f, st.design, nl.name);
            }
            merged.wire_c.extend(rc.wire_c);
            merged.elmore.extend(rc.elmore);
            merged.trees.extend(rc.trees);
            merged.coupling.extend(rc.coupling);
            merged.segs.extend(rc.segs);
            stats.file = if stats.file.is_empty() { st.file.clone() } else { format!("{} {}", stats.file, st.file) };
            stats.design = st.design.clone();
            stats.nets_in_file += st.nets_in_file;
            stats.nets_annotated += st.nets_annotated;
            stats.unmatched_nets.extend(st.unmatched_nets);
            stats.missing_pins.extend(st.missing_pins);
            stats.unknown_pins.extend(st.unknown_pins);
            stats.coupling_caps += st.coupling_caps;
            stats.res_loops += st.res_loops;
            stats.lumped_nets += st.lumped_nets;
            stats.total_cap += st.total_cap;
        }
        let rc = Arc::new(merged);
        for c in &corners {
            self.spef_rc.insert(c.clone(), rc.clone());
            self.spef_stats.insert(c.clone(), stats.clone());
        }
        crate::info!(
            "PARA-100",
            "Read SPEF {} for corner(s) {}: {} net(s) in file, {} annotated, {} not in the design, {} netlist pin(s) missing, {} coupling cap(s), total wire cap {:.4} pF",
            files.join(" "),
            corners.join(" "),
            stats.nets_in_file,
            stats.nets_annotated,
            stats.unmatched_nets.len(),
            stats.missing_pins.len(),
            stats.coupling_caps,
            stats.total_cap
        );
        if !stats.unmatched_nets.is_empty() {
            crate::warn!("PARA-020", "{} SPEF net(s) not found in the design, e.g. {}", stats.unmatched_nets.len(), stats.unmatched_nets[0]);
        }
        Ok(stats.nets_annotated.to_string())
    }

    fn c_report_annotated_parasitics(&mut self, a: &[String]) -> R {
        let x = args(a, &["-corners", "-corner", "-max_nets", "-scenarios"]);
        let verbose = x.has("-verbose") || x.has("-list_not_annotated");
        let max = x.num("-max_nets").map(|v| v as usize).unwrap_or(if x.has("-verbose") { usize::MAX } else { 20 });
        let corners: Vec<String> = x.get("-corners").or(x.get("-corner")).map(|s| split_list(s)).unwrap_or_else(|| self.corners.iter().map(|c| c.name.clone()).collect());
        let nl = self.nl()?;
        crate::out!("\n****************************************\nReport : annotated_parasitics{}\nDesign : {}\n****************************************", if x.has("-verbose") { " -verbose" } else { "" }, nl.name);
        // nets that need parasitics: driven, with at least one load, not constant, not a segment behind a boundary pin
        let consts = |n: crate::netlist::NetId| nl.driver(n).map(|d| matches!(d, PinRef::Cell(c, _) if matches!(nl.cell(c).kind, crate::netlist::Kind::Gen(crate::netlist::GOp::C0) | crate::netlist::Kind::Gen(crate::netlist::GOp::C1)))).unwrap_or(false);
        let want: Vec<crate::netlist::NetId> = nl
            .net_ids()
            .into_iter()
            .filter(|n| nl.driver(*n).is_some() && !nl.loads(*n).is_empty() && !consts(*n) && !nl.driver(*n).map(|d| nl.cell_is_hport(d)).unwrap_or(false))
            .collect();
        let mut total_unann = 0;
        for c in &corners {
            crate::out!("\n  Corner: {}", c);
            let Some(rc) = self.spef_rc.get(c) else {
                crate::out!("    no annotated parasitics (timing uses {})", if self.routed_rc.is_some() { "detailed-route extraction" } else { "estimated wire parasitics" });
                total_unann += want.len();
                continue;
            };
            let st = self.spef_stats.get(c).cloned().unwrap_or_default();
            let is_port = |n: crate::netlist::NetId| nl.net(n).conns.iter().any(|p| matches!(p, PinRef::Port(_)));
            let mut rows: Vec<(&str, usize, usize)> = vec![];
            let (mut ia, mut it, mut pa, mut pt) = (0, 0, 0, 0);
            let mut unann = vec![];
            let (mut la, mut lt) = (0, 0);
            for &n in &want {
                let ok = rc.wire_c.contains_key(&n);
                if is_port(n) {
                    pt += 1;
                    pa += ok as usize;
                } else {
                    it += 1;
                    ia += ok as usize;
                }
                if !ok {
                    unann.push(nl.net(n).name.clone());
                }
                for l in nl.loads(n) {
                    if nl.cell_is_hport(l) {
                        continue;
                    }
                    lt += 1;
                    la += rc.elmore.contains_key(&l) as usize;
                }
            }
            rows.push(("Internal nets", it, ia));
            rows.push(("Port nets", pt, pa));
            rows.push(("Total nets", it + pt, ia + pa));
            rows.push(("Load pins (RC delay)", lt, la));
            crate::out!("    File(s): {}", st.file);
            crate::out!("    {:<24} {:>8} {:>10} {:>14} {:>8}", "Object", "Total", "Annotated", "Not annotated", "%");
            for (k, t, a_) in &rows {
                crate::out!("    {:<24} {:>8} {:>10} {:>14} {:>7.1}%", k, t, a_, t - a_, if *t > 0 { *a_ as f64 * 100.0 / *t as f64 } else { 100.0 });
            }
            crate::out!("    SPEF: {} net(s) in file, {} not in the design, {} coupling cap(s), {} resistor loop(s), {} lumped-C net(s), total wire cap {:.4} pF", st.nets_in_file, st.unmatched_nets.len(), st.coupling_caps, st.res_loops, st.lumped_nets, st.total_cap);
            total_unann += unann.len();
            if verbose {
                let show = |title: &str, v: &[String]| {
                    if v.is_empty() {
                        return;
                    }
                    crate::out!("    {} ({}):", title, v.len());
                    for s in v.iter().take(max) {
                        crate::out!("      {}", s);
                    }
                    if v.len() > max {
                        crate::out!("      ... {} more", v.len() - max);
                    }
                };
                show("Nets not annotated", &unann);
                let mut nodelay = vec![];
                for &n in &want {
                    if rc.wire_c.contains_key(&n) {
                        for l in nl.loads(n) {
                            if !nl.cell_is_hport(l) && !rc.elmore.contains_key(&l) {
                                nodelay.push(format!("{} (net {})", nl.pin_name(l), nl.net(n).name));
                            }
                        }
                    }
                }
                show("Load pins without an RC delay (wire delay estimated)", &nodelay);
                show("Netlist pins missing from *CONN", &st.missing_pins);
                show("SPEF pins not on the net in the design", &st.unknown_pins);
                show("SPEF nets not in the design", &st.unmatched_nets);
            }
        }
        Ok(total_unann.to_string())
    }

    // ------------------------------------------------------------------ annotated delays

    fn c_set_annotated_delay(&mut self, a: &[String]) -> R {
        let x = args(a, &["-from", "-to", "-corners", "-corner", "-load_delay"]);
        let Some(v) = x.pos.iter().find_map(|p| p.parse::<f64>().ok()) else { return err("set_annotated_delay: delay value required (TIM-330)") };
        let cell = x.has("-cell");
        let net = x.has("-net");
        if cell == net {
            return err("set_annotated_delay: exactly one of -cell or -net is required (TIM-331)");
        }
        let (rise, fall) = match (x.has("-rise"), x.has("-fall")) {
            (false, false) => (true, true),
            r => r,
        };
        let (max, min) = match (x.has("-max"), x.has("-min")) {
            (false, false) => (true, true),
            r => r,
        };
        let corners = x.get("-corners").or(x.get("-corner")).map(|s| split_list(s)).unwrap_or_default();
        let nl = self.nl()?;
        let resolve = |spec: &str| -> Vec<PinRef> { self.objs(spec, "pin").iter().filter_map(|o| nl.find_pin(o.name())).collect() };
        let to: Vec<PinRef> = x.get("-to").map(|s| resolve(s)).unwrap_or_default();
        if to.is_empty() {
            return err("set_annotated_delay: -to pins required (TIM-332)");
        }
        let from: Vec<PinRef> = match x.get("-from") {
            Some(s) => resolve(s),
            None if net => to.iter().filter_map(|t| nl.pin_net(*t).and_then(|n| nl.driver(n))).collect(),
            None => return err("set_annotated_delay -cell: -from pins required (TIM-333)"),
        };
        let mut n = 0;
        let mut added = vec![];
        for &t in &to {
            for &f in &from {
                let ok = if cell {
                    matches!((f, t), (PinRef::Cell(a1, _), PinRef::Cell(b1, _)) if a1 == b1) && nl.is_driver(t) && !nl.is_driver(f)
                } else {
                    nl.pin_net(f).is_some() && nl.pin_net(f) == nl.pin_net(t) && nl.is_driver(f) && !nl.is_driver(t)
                };
                if !ok {
                    continue;
                }
                added.push(((nl.pin_name(f), nl.pin_name(t), if cell { "cell".to_string() } else { "net".to_string() }), AnnDelay { from: f, to: t, rise, fall, max, min, incr: x.has("-increment"), value: v, corners: corners.clone() }));
                n += 1;
            }
        }
        if n == 0 {
            return err(format!("set_annotated_delay: no {} arc between the -from and -to pins (TIM-334)", if cell { "cell (input -> output of the same cell)" } else { "net (driver -> load on the same net)" }));
        }
        // a new annotation replaces an earlier one on the same arc
        for (k, d) in added {
            self.ann_delays.retain(|(k2, d2)| !(k2.0 == k.0 && k2.1 == k.1 && d2.rise == d.rise && d2.fall == d.fall && d2.max == d.max && d2.min == d.min));
            self.ann_delays.push((k, d));
        }
        self.rawsdc("set_annotated_delay", a);
        crate::info!("TIM-335", "Annotated {} {} arc(s) with {} {:.4} ns", n, if cell { "cell" } else { "net" }, if x.has("-increment") { "an increment of" } else { "a delay of" }, v);
        Ok(n.to_string())
    }

    // ------------------------------------------------------------------ derates

    fn c_set_timing_derate(&mut self, a: &[String]) -> R {
        let x = args(a, &["-corners", "-corner"]);
        let value_idx = x.pos.iter().position(|p| p.parse::<f64>().is_ok());
        let Some(vi) = value_idx else { return err("set_timing_derate: derate value required (TIM-340)") };
        let v: f64 = x.pos[vi].parse().unwrap();
        if v <= 0.0 {
            return err("set_timing_derate: derate must be positive (TIM-341)");
        }
        let objs: Vec<Obj> = x.pos.iter().enumerate().filter(|(i, _)| *i != vi).flat_map(|(_, p)| self.objs(p, "any")).collect();
        // normalize -net / -cell to -net_delay / -cell_delay
        let norm: Vec<String> = a
            .iter()
            .map(|s| match s.as_str() {
                "-net" => "-net_delay".to_string(),
                "-cell" => "-cell_delay".to_string(),
                o => o.to_string(),
            })
            .collect();
        if objs.is_empty() {
            return self.cmd("c_derate_internal", &norm).unwrap_or(Ok(String::new()));
        }
        let has = |k: &str| norm.iter().any(|s| s == k);
        let late = has("-late") || !has("-early");
        let early = has("-early") || !has("-late");
        let cell = has("-cell_delay") || !has("-net_delay");
        let net = has("-net_delay") || !has("-cell_delay") && objs.iter().any(|o| matches!(o, Obj::Net(_)));
        let clock = has("-clock") || !has("-data");
        let data = has("-data") || !has("-clock");
        let cs = x.get("-corners").or(x.get("-corner")).map(|s| split_list(s)).unwrap_or(vec![self.corners[self.cur_corner].name.clone()]);
        let mut n = 0;
        for c in &cs {
            let i = self.corner_index(c);
            for o in &objs {
                let is_net = matches!(o, Obj::Net(_));
                self.corners[i].obj_derates.push(ObjDerate { obj: o.clone(), late, early, cell: cell && !is_net, net: net || is_net, clock, data, value: v });
                n += 1;
            }
        }
        self.rawsdc("set_timing_derate", a);
        crate::info!("TIM-342", "Derate {:.4} ({}{}{}) on {} object(s) in corner(s) {}", v, if late && early { "late/early" } else if late { "late" } else { "early" }, if cell && net { ", cell+net" } else if net { ", net" } else { ", cell" }, if clock && data { "" } else if clock { ", clock paths" } else { ", data paths" }, objs.len(), cs.join(" "));
        Ok(n.to_string())
    }

    fn c_report_timing_derate(&mut self, a: &[String]) -> R {
        let x = args(a, &["-corners", "-corner", "-scenarios"]);
        let mut cs: Vec<String> = x.get("-corners").or(x.get("-corner")).map(|s| split_list(s)).unwrap_or_else(|| self.corners.iter().map(|c| c.name.clone()).collect());
        if let Some(sc) = x.get("-scenarios") {
            cs = split_list(sc).iter().filter_map(|n| self.scens.iter().find(|s| &s.name == n).map(|s| s.corner.clone())).collect();
        }
        let filter: Vec<String> = x.pos.iter().flat_map(|p| self.objs(p, "any")).map(|o| o.name().to_string()).collect();
        crate::out!("\n****************************************\nReport : timing_derate\n****************************************");
        crate::out!("  Analysis type: {}{}", self.analysis_type, if self.analysis_type == "single_corner" { " (derates not applied)" } else { "" });
        crate::out!("  AOCV: {}   POCV: {}", if self.appb("time.aocvm_enable_analysis") { "on" } else { "off" }, if self.appb("time.pocvm_enable_analysis") { format!("on ({} sigma)", self.appf("time.pocvm_corner_sigma")) } else { "off".into() });
        let mut n = 0;
        for c in &cs {
            let Some(k) = self.corners.iter().find(|k| &k.name == c) else { continue };
            crate::out!("\n  Corner {}  (design)", k.name);
            crate::out!("    {:<10} {:>10} {:>10} {:>10} {:>10}", "", "Late data", "Early data", "Late clock", "Early clock");
            for (lbl, cell) in [("Cell delay", true), ("Net delay", false)] {
                crate::out!("    {:<10} {:>10.4} {:>10.4} {:>10.4} {:>10.4}", lbl, k.derate(cell, false, false), k.derate(cell, true, false), k.derate(cell, false, true), k.derate(cell, true, true));
            }
            let objs: Vec<&ObjDerate> = k.obj_derates.iter().filter(|d| filter.is_empty() || filter.iter().any(|f| f == d.obj.name())).collect();
            if !objs.is_empty() {
                crate::out!("    Object derates (later entries win):");
                crate::out!("      {:<10} {:<44} {:>8}  {:<11} {:<9} {}", "Type", "Object", "Derate", "Late/Early", "Cell/Net", "Clock/Data");
                for d in objs {
                    let ty = match d.obj {
                        Obj::Cell(_) => "cell",
                        Obj::LibCell(_) => "lib_cell",
                        Obj::Net(_) => "net",
                        _ => "other",
                    };
                    crate::out!(
                        "      {:<10} {:<44} {:>8.4}  {:<11} {:<9} {}",
                        ty,
                        d.obj.name(),
                        d.value,
                        if d.late && d.early { "both" } else if d.late { "late" } else { "early" },
                        if d.cell && d.net { "both" } else if d.cell { "cell" } else { "net" },
                        if d.clock && d.data { "both" } else if d.clock { "clock" } else { "data" }
                    );
                    n += 1;
                }
            }
        }
        Ok(n.to_string())
    }

    // ------------------------------------------------------------------ analysis type

    fn c_set_analysis_type(&mut self, a: &[String]) -> R {
        let x = args(a, &["-max_corner", "-min_corner", "-type"]);
        let ty = if x.has("-min_max") || x.has("-bc_wc") || x.get("-type").map(|t| t == "min_max" || t == "bc_wc").unwrap_or(false) {
            "min_max"
        } else if x.has("-single_corner") || x.has("-single") || x.get("-type").map(|t| t.starts_with("single")).unwrap_or(false) {
            "single_corner"
        } else if x.has("-ocv") || x.has("-on_chip_variation") || x.get("-type").map(|t| t == "ocv" || t == "on_chip_variation").unwrap_or(false) {
            "ocv"
        } else {
            return err("set_analysis_type: one of -min_max, -ocv, -single_corner is required (TIM-350)");
        };
        self.analysis_type = ty.to_string();
        match ty {
            "min_max" => {
                // setup in the max (slow) corner, hold in the min (fast) corner
                let pick = |setup: bool| -> Option<String> { self.scens.iter().find(|s| s.active && if setup { s.setup } else { s.hold }).map(|s| s.corner.clone()) };
                let maxc = x.get("-max_corner").cloned().or_else(|| pick(true)).or_else(|| self.corners.first().map(|c| c.name.clone()));
                let minc = x.get("-min_corner").cloned().or_else(|| pick(false)).or_else(|| self.corners.last().map(|c| c.name.clone()));
                let (Some(maxc), Some(minc)) = (maxc, minc) else { return err("set_analysis_type -min_max: no corners (TIM-351)") };
                for c in [&maxc, &minc] {
                    if !self.corners.iter().any(|k| &k.name == c) {
                        return err(format!("set_analysis_type: corner '{}' does not exist (MV-CRN)", c));
                    }
                }
                for s in self.scens.iter_mut() {
                    s.setup = s.corner == maxc;
                    s.hold = s.corner == minc;
                    s.active = s.setup || s.hold;
                }
                crate::info!("TIM-352", "Analysis type min_max: setup checks in corner {}, hold checks in corner {}", maxc, minc);
            }
            "single_corner" => {
                for s in self.scens.iter_mut().filter(|s| s.active) {
                    s.setup = true;
                    s.hold = true;
                }
                crate::info!("TIM-353", "Analysis type single_corner: each active scenario checks setup and hold in its own corner; early/late derates, AOCV and POCV are not applied");
            }
            _ => crate::info!("TIM-354", "Analysis type ocv: early/late derates (and AOCV/POCV when enabled) apply within each corner"),
        }
        self.bump_epoch();
        Ok(ty.to_string())
    }

    pub(crate) fn corner_index(&mut self, c: &str) -> usize {
        match self.corners.iter().position(|k| k.name == c) {
            Some(i) => i,
            None => {
                self.corners.push(crate::cons::Corner::new(c));
                self.corners.len() - 1
            }
        }
    }

    pub(crate) fn sta_overrides(&self) -> (Option<Arc<HashMap<String, Arc<crate::droute::RoutedRc>>>>, Option<Arc<Vec<AnnDelay>>>) {
        let spef = if self.spef_rc.is_empty() { None } else { Some(Arc::new(self.spef_rc.clone())) };
        let ann = if self.ann_delays.is_empty() { None } else { Some(Arc::new(self.ann_delays.iter().map(|x| x.1.clone()).collect())) };
        (spef, ann)
    }
}

#[allow(dead_code)]
fn _l(v: &[String]) -> String {
    to_list(v)
}
