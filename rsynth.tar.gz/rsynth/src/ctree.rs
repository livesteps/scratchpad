//! Clock-tree model built from the propagated-clock timing graph: every clock-path cell
//! (CTS buffer / inverter / delay cell, ICG, level shifter, isolation, clock logic) becomes a
//! node with its level, late/early input and output latency, transition, fanout and load; register
//! and macro clock pins are the leaves.  Used by `report_clock_qor -type ...`, `report_clock_tree`
//! and `write_clock_tree` (JSON export).
use crate::cons::Obj;
use crate::netlist::{Dir, NetId, Netlist, PinRef};
use crate::sta::Timing;
use std::collections::{HashMap, HashSet};

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum Kind {
    Root,
    Buf,
    Inv,
    Delay,
    Icg,
    Ls,
    Iso,
    Logic,
    Sink,
    Macro,
}

impl Kind {
    pub fn name(self) -> &'static str {
        match self {
            Kind::Root => "root",
            Kind::Buf => "buffer",
            Kind::Inv => "inverter",
            Kind::Delay => "delay",
            Kind::Icg => "icg",
            Kind::Ls => "level_shifter",
            Kind::Iso => "isolation",
            Kind::Logic => "logic",
            Kind::Sink => "sink",
            Kind::Macro => "macro",
        }
    }
    pub fn is_leaf(self) -> bool {
        matches!(self, Kind::Sink | Kind::Macro)
    }
}

#[derive(Clone, Debug)]
pub struct Node {
    pub kind: Kind,
    /// instance name (port name for a port root)
    pub name: String,
    pub lib: String,
    /// input (clock) pin, full name
    pub pin: String,
    pub out_net: String,
    pub parent: usize,
    pub children: Vec<usize>,
    /// number of clock-path cells from the root up to and including this cell
    /// (for a sink: the number of cells above it)
    pub level: usize,
    pub lat_in: [f64; 2],
    pub lat_out: [f64; 2],
    pub tr_in: f64,
    pub tr_out: f64,
    pub fanout: usize,
    pub cap: f64,
    pub loc: Option<(f64, f64)>,
    pub cts: bool,
    pub area: f64,
    pub sinks: usize,
    /// late latency range of the sinks below
    pub smax: f64,
    pub smin: f64,
}

#[derive(Clone, Debug)]
pub struct Tree {
    pub clock: String,
    pub period: f64,
    pub nodes: Vec<Node>,
    pub roots: Vec<usize>,
    /// clock pins reached that are data inputs (clock used as data)
    pub as_data: Vec<String>,
    pub pruned: usize,
}

pub const NONE: usize = usize::MAX;

fn lat(t: &Timing, pr: PinRef, ci: usize) -> Option<([f64; 2], f64)> {
    let u = *t.idx.get(&pr)?;
    let v: Vec<_> = t.ctags[u as usize].iter().filter(|x| x.clk as usize == ci).collect();
    if v.is_empty() {
        return None;
    }
    let mx = v.iter().map(|x| x.lmax).fold(f64::MIN, f64::max);
    let mn = v.iter().map(|x| x.lmin).fold(f64::MAX, f64::min);
    let sl = v.iter().map(|x| x.slew).fold(0.0, f64::max);
    Some(([mx, mn], sl))
}

/// loads of a net, looking through STA-transparent hierarchy boundary pins; also returns every
/// physical net segment visited (for the load capacitance)
fn leaf_loads(nl: &Netlist, n: NetId) -> (Vec<PinRef>, Vec<NetId>) {
    let mut out = vec![];
    let mut nets = vec![];
    let mut st = vec![n];
    let mut seen = HashSet::new();
    while let Some(n) = st.pop() {
        if !seen.insert(n) || !nl.net_alive(n) {
            continue;
        }
        nets.push(n);
        for l in nl.loads(n) {
            if let PinRef::Cell(c, _) = l {
                if nl.cell(c).is_hport() {
                    for p in &nl.cell(c).pins {
                        if p.dir == Dir::Out {
                            if let Some(o) = p.net {
                                st.push(o);
                            }
                        }
                    }
                    continue;
                }
            }
            out.push(l);
        }
    }
    (out, nets)
}

/// Build the tree of clock `ci` from a timed (propagated) graph.
pub fn build(t: &Timing, ci: usize) -> Option<Tree> {
    let nl = t.nl;
    let ck = &t.cons.clocks[ci];
    if ck.is_virtual() {
        return None;
    }
    let clk_pins: HashSet<u32> = t.clk_pins.iter().copied().collect();
    let mut tr = Tree { clock: ck.name.clone(), period: ck.period, nodes: vec![], roots: vec![], as_data: vec![], pruned: 0 };
    let mut q: Vec<(NetId, usize)> = vec![];
    for s in &ck.sources {
        let pr = match s {
            Obj::Port(p) => nl.port_by_name(p).map(PinRef::Port),
            Obj::Pin(p) => nl.find_pin(p),
            _ => None,
        };
        let Some(pr) = pr else { continue };
        let Some(net) = nl.pin_net(pr) else { continue };
        let (l, sl) = lat(t, pr, ci).unwrap_or(([0.0; 2], 0.0));
        let (name, lib) = match pr {
            PinRef::Port(p) => (nl.ports[p].name.clone(), "port".to_string()),
            PinRef::Cell(c, _) => (nl.cell(c).name.clone(), nl.cell(c).lib().unwrap_or("").to_string()),
        };
        let id = tr.nodes.len();
        tr.nodes.push(Node { kind: Kind::Root, name, lib, pin: nl.pin_name(pr), out_net: nl.net(net).name.clone(), parent: NONE, children: vec![], level: 0, lat_in: l, lat_out: l, tr_in: sl, tr_out: sl, fanout: 0, cap: 0.0, loc: nl.pin_loc(pr), cts: false, area: 0.0, sinks: 0, smax: f64::MIN, smin: f64::MAX });
        tr.roots.push(id);
        q.push((net, id));
    }
    let mut seen_cells = HashSet::new();
    while let Some((net, par)) = q.pop() {
        let (loads, segs) = leaf_loads(nl, net);
        tr.nodes[par].fanout = loads.len();
        tr.nodes[par].cap = segs.iter().map(|n| t.net_c.get(*n).copied().unwrap_or(0.0)).sum();
        tr.nodes[par].out_net = nl.net(net).name.clone();
        let plevel = tr.nodes[par].level;
        for l in loads {
            let PinRef::Cell(c, _) = l else { continue };
            let cl = nl.cell(c);
            let lc = cl.lib().and_then(|n| t.libs.cell(n));
            let u = t.idx.get(&l).copied();
            let is_ck = u.map(|u| clk_pins.contains(&u)).unwrap_or(false);
            let kind = match lc {
                None => Kind::Macro,
                Some(lc) if lc.icg.is_some() => Kind::Icg,
                Some(lc) if lc.seq.is_some() => {
                    if is_ck {
                        Kind::Sink
                    } else {
                        tr.as_data.push(nl.pin_name(l));
                        continue;
                    }
                }
                Some(lc) if lc.outputs().is_empty() => Kind::Macro,
                Some(lc) => {
                    if lc.is_ls {
                        Kind::Ls
                    } else if lc.is_iso {
                        Kind::Iso
                    } else if cl.has_attr("cts_delay") || lc.is_delay {
                        Kind::Delay
                    } else if lc.is_inv {
                        Kind::Inv
                    } else if lc.is_buf {
                        Kind::Buf
                    } else {
                        Kind::Logic
                    }
                }
            };
            if !kind.is_leaf() && !seen_cells.insert(c) {
                continue; // reconvergent clock logic: keep the first path only
            }
            let (li, si) = lat(t, l, ci).unwrap_or(([f64::NAN; 2], 0.0));
            let outp = cl.pins.iter().position(|p| p.dir == Dir::Out);
            let (lo, so) = match (kind.is_leaf(), outp) {
                (false, Some(op)) => lat(t, PinRef::Cell(c, op), ci).unwrap_or((li, si)),
                _ => (li, si),
            };
            let id = tr.nodes.len();
            tr.nodes.push(Node {
                kind,
                name: cl.name.clone(),
                lib: cl.lib().unwrap_or("").to_string(),
                pin: nl.pin_name(l),
                out_net: String::new(),
                parent: par,
                children: vec![],
                level: if kind.is_leaf() { plevel } else { plevel + 1 },
                lat_in: li,
                lat_out: lo,
                tr_in: si,
                tr_out: so,
                fanout: 0,
                cap: 0.0,
                loc: cl.loc,
                cts: cl.has_attr("cts"),
                area: lc.map(|x| x.area).unwrap_or(0.0),
                sinks: 0,
                smax: f64::MIN,
                smin: f64::MAX,
            });
            tr.nodes[par].children.push(id);
            if !kind.is_leaf() {
                if let Some(o) = outp.and_then(|op| cl.pins[op].net) {
                    q.push((o, id));
                }
            }
        }
    }
    // sinks below each node (children always have larger ids than their parent)
    for i in (0..tr.nodes.len()).rev() {
        let (k, l) = (tr.nodes[i].kind, tr.nodes[i].lat_in[0]);
        if k.is_leaf() {
            tr.nodes[i].sinks = 1;
            if l.is_finite() {
                tr.nodes[i].smax = l;
                tr.nodes[i].smin = l;
            }
        }
        let p = tr.nodes[i].parent;
        if p != NONE {
            let (s, mx, mn) = (tr.nodes[i].sinks, tr.nodes[i].smax, tr.nodes[i].smin);
            let pn = &mut tr.nodes[p];
            pn.sinks += s;
            pn.smax = pn.smax.max(mx);
            pn.smin = pn.smin.min(mn);
        }
    }
    // prune clock logic that reaches no clock pin (clock used as data)
    let keep: Vec<bool> = tr.nodes.iter().map(|n| n.sinks > 0 || n.kind == Kind::Root).collect();
    tr.pruned = keep.iter().filter(|k| !**k).count();
    if tr.pruned > 0 {
        let mut map = vec![NONE; tr.nodes.len()];
        let mut nn = vec![];
        for (i, n) in tr.nodes.iter().enumerate() {
            if keep[i] {
                map[i] = nn.len();
                nn.push(n.clone());
            }
        }
        for n in nn.iter_mut() {
            if n.parent != NONE {
                n.parent = map[n.parent];
            }
            n.children = n.children.iter().filter(|c| map[**c] != NONE).map(|c| map[*c]).collect();
        }
        tr.roots = tr.roots.iter().map(|r| map[*r]).collect();
        tr.nodes = nn;
    }
    Some(tr)
}

impl Tree {
    pub fn sinks(&self) -> impl Iterator<Item = &Node> {
        self.nodes.iter().filter(|n| n.kind.is_leaf())
    }
    pub fn cells(&self) -> impl Iterator<Item = &Node> {
        self.nodes.iter().filter(|n| !n.kind.is_leaf() && n.kind != Kind::Root)
    }
    pub fn max_level(&self) -> usize {
        self.sinks().map(|n| n.level).max().unwrap_or(0)
    }
    pub fn min_level(&self) -> usize {
        self.sinks().map(|n| n.level).min().unwrap_or(0)
    }
    /// (max, min) late sink latency, skew
    pub fn latency(&self) -> (f64, f64, f64) {
        let v: Vec<f64> = self.sinks().map(|n| n.lat_in[0]).filter(|x| x.is_finite()).collect();
        if v.is_empty() {
            return (0.0, 0.0, 0.0);
        }
        let mx = v.iter().cloned().fold(f64::MIN, f64::max);
        let mn = v.iter().cloned().fold(f64::MAX, f64::min);
        (mx, mn, mx - mn)
    }
    pub fn path(&self, mut i: usize) -> Vec<usize> {
        let mut v = vec![];
        while i != NONE {
            v.push(i);
            i = self.nodes[i].parent;
        }
        v.reverse();
        v
    }
}

fn f4(x: f64) -> String {
    if x.is_finite() {
        format!("{:.4}", x)
    } else {
        "-".into()
    }
}

// ---------------------------------------------------------------- text reports

pub fn report_summary(trees: &[Tree], scen: &str) -> String {
    let mut s = String::new();
    s += &format!("  Scenario: {}\n\n", scen);
    s += &format!("  {:<34} {:>6} {:>6} {:>5} {:>5} {:>5} {:>5} {:>5} {:>7} {:>9} {:>9} {:>8} {:>7} {:>8}\n", "Clock", "Sinks", "Levels", "Buf", "Inv", "Dly", "ICG", "Other", "Area", "MaxLat", "MinLat", "Skew", "MaxTr", "MaxFo");
    s += &format!("  {}\n", "-".repeat(140));
    let (mut ts, mut tb, mut ti, mut td, mut tg, mut to, mut ta) = (0, 0, 0, 0, 0, 0, 0.0);
    let (mut gmx, mut gmn, mut gtr, mut gfo, mut glv) = (f64::MIN, f64::MAX, 0.0f64, 0usize, 0usize);
    for t in trees {
        let c = |k: Kind| t.cells().filter(|n| n.kind == k).count();
        let (b, i, d, g) = (c(Kind::Buf), c(Kind::Inv), c(Kind::Delay), c(Kind::Icg));
        let o = t.cells().count() - b - i - d - g;
        let area: f64 = t.cells().map(|n| n.area).sum();
        let (mx, mn, sk) = t.latency();
        let mtr = t.nodes.iter().map(|n| n.tr_in).fold(0.0, f64::max);
        let mfo = t.nodes.iter().filter(|n| !n.kind.is_leaf()).map(|n| n.fanout).max().unwrap_or(0);
        let lv = if t.min_level() == t.max_level() { format!("{}", t.max_level()) } else { format!("{}-{}", t.min_level(), t.max_level()) };
        let ns = t.sinks().count();
        s += &format!("  {:<34} {:>6} {:>6} {:>5} {:>5} {:>5} {:>5} {:>5} {:>7.2} {:>9} {:>9} {:>8} {:>7.4} {:>8}\n", trunc(&t.clock, 34), ns, lv, b, i, d, g, o, area, f4(mx), f4(mn), f4(sk), mtr, mfo);
        ts += ns;
        tb += b;
        ti += i;
        td += d;
        tg += g;
        to += o;
        ta += area;
        if ns > 0 {
            gmx = gmx.max(mx);
            gmn = gmn.min(mn);
        }
        gtr = gtr.max(mtr);
        gfo = gfo.max(mfo);
        glv = glv.max(t.max_level());
    }
    s += &format!("  {}\n", "-".repeat(140));
    s += &format!("  {:<34} {:>6} {:>6} {:>5} {:>5} {:>5} {:>5} {:>5} {:>7.2} {:>9} {:>9} {:>8} {:>7.4} {:>8}\n", "All clocks", ts, glv, tb, ti, td, tg, to, ta, f4(gmx), f4(gmn), f4(if ts > 0 { gmx - gmn } else { f64::NAN }), gtr, gfo);
    s += "\n  Levels = clock-path cells from the source to a sink (min-max over the sinks); Other = level shifters, isolation, clock logic.\n";
    s += "  Skew = late-latency spread over register / macro clock pins of the clock; the All-clocks row spans every clock.\n";
    s
}

pub fn report_levels(t: &Tree) -> String {
    let mut s = format!("\n  Clock: {}   (sinks {}, levels {}-{})\n", t.clock, t.sinks().count(), t.min_level(), t.max_level());
    s += &format!("  {:>5} {:>6} {:<40} {:>8} {:>8} {:>9} {:>9} {:>9} {:>7} {:>8} {:>8}\n", "Level", "Cells", "Cell types", "AvgFo", "MaxFo", "MinInLat", "MaxInLat", "MaxOutLat", "MaxTr", "Sinks@L", "Area");
    let ml = t.nodes.iter().map(|n| n.level).max().unwrap_or(0);
    for lv in 0..=ml {
        let cells: Vec<&Node> = t.nodes.iter().filter(|n| !n.kind.is_leaf() && n.level == lv).collect();
        let sinks = t.sinks().filter(|n| n.level == lv).count();
        if cells.is_empty() && sinks == 0 {
            continue;
        }
        let mut ty: HashMap<String, usize> = HashMap::new();
        for c in &cells {
            *ty.entry(if c.kind == Kind::Root { "source".into() } else { c.lib.clone() }).or_default() += 1;
        }
        let mut tv: Vec<_> = ty.into_iter().collect();
        tv.sort_by(|a, b| b.1.cmp(&a.1).then(a.0.cmp(&b.0)));
        let tys = tv.iter().map(|(k, v)| format!("{}x{}", v, k)).collect::<Vec<_>>().join(" ");
        let fo: Vec<usize> = cells.iter().map(|c| c.fanout).collect();
        let mn = |v: &dyn Fn(&Node) -> f64| cells.iter().map(|c| v(c)).filter(|x| x.is_finite()).fold(f64::MAX, f64::min);
        let mx = |v: &dyn Fn(&Node) -> f64| cells.iter().map(|c| v(c)).filter(|x| x.is_finite()).fold(f64::MIN, f64::max);
        let avg = if fo.is_empty() { 0.0 } else { fo.iter().sum::<usize>() as f64 / fo.len() as f64 };
        let cv = |x: f64| if x == f64::MAX || x == f64::MIN { "-".to_string() } else { format!("{:.4}", x) };
        s += &format!(
            "  {:>5} {:>6} {:<40} {:>8.1} {:>8} {:>9} {:>9} {:>9} {:>7} {:>8} {:>8.2}\n",
            lv,
            cells.len(),
            trunc(&tys, 40),
            avg,
            fo.iter().max().copied().unwrap_or(0),
            cv(mn(&|c| c.lat_in[0])),
            cv(mx(&|c| c.lat_in[0])),
            cv(mx(&|c| c.lat_out[0])),
            cv(mx(&|c| c.tr_out)),
            sinks,
            cells.iter().map(|c| c.area).sum::<f64>()
        );
    }
    s
}

pub fn report_structure(t: &Tree, max_level: usize, show_sinks: bool) -> String {
    let mut s = format!("\n  Clock: {}   (period {:.3}ns, {} sinks, {} clock-path cells)\n", t.clock, t.period, t.sinks().count(), t.cells().count());
    s += "  L<level> cell (lib cell) [type]  fo <fanout>  cap <load pF>  lat <in late>/<in early> -> <out late>  tran <out>  <sinks below: count min..max (sub-skew)>  (x,y)\n";
    fn rec(t: &Tree, i: usize, d: usize, max_level: usize, show: bool, s: &mut String) {
        let n = &t.nodes[i];
        let ind = "  ".repeat(d);
        let loc = n.loc.map(|(x, y)| format!("({:.1},{:.1})", x, y)).unwrap_or_default();
        if n.kind.is_leaf() {
            *s += &format!("  {}L{:<2} {} ({}) [{}]  lat {}/{}  tran {:.4}  {}\n", ind, n.level, n.pin, n.lib, n.kind.name(), f4(n.lat_in[0]), f4(n.lat_in[1]), n.tr_in, loc);
            return;
        }
        let sk = if n.sinks > 0 { format!("{} sinks {}..{} ({:.4})", n.sinks, f4(n.smin), f4(n.smax), n.smax - n.smin) } else { String::new() };
        *s += &format!(
            "  {}L{:<2} {} ({}) [{}{}]  fo {}  cap {:.4}  lat {}/{} -> {}  tran {:.4}  {}  {}\n",
            ind, n.level, if n.kind == Kind::Root { &n.pin } else { &n.name }, n.lib, n.kind.name(), if n.cts { ",cts" } else { "" },
            n.fanout, n.cap, f4(n.lat_in[0]), f4(n.lat_in[1]), f4(n.lat_out[0]), n.tr_out, sk, loc
        );
        let mut cells: Vec<usize> = n.children.iter().copied().filter(|c| !t.nodes[*c].kind.is_leaf()).collect();
        cells.sort_by_key(|c| std::cmp::Reverse(t.nodes[*c].sinks));
        let leaves: Vec<usize> = n.children.iter().copied().filter(|c| t.nodes[*c].kind.is_leaf()).collect();
        if n.level >= max_level && n.kind != Kind::Root && !cells.is_empty() {
            *s += &format!("  {}  ... {} clock cell(s) below not shown (-max_level {})\n", ind, cells.len(), max_level);
        } else {
            for c in cells {
                rec(t, c, d + 1, max_level, show, s);
            }
        }
        if show {
            for c in leaves {
                rec(t, c, d + 1, max_level, show, s);
            }
        } else if !leaves.is_empty() {
            let v: Vec<f64> = leaves.iter().map(|c| t.nodes[*c].lat_in[0]).filter(|x| x.is_finite()).collect();
            let mx = v.iter().cloned().fold(f64::MIN, f64::max);
            let mn = v.iter().cloned().fold(f64::MAX, f64::min);
            *s += &format!("  {}  {} direct sink(s)  lat {}..{} ({})\n", ind, leaves.len(), f4(mn), f4(mx), if v.is_empty() { "-".into() } else { format!("{:.4}", mx - mn) });
        }
    }
    for r in &t.roots {
        rec(t, *r, 0, max_level, show_sinks, &mut s);
    }
    s
}

pub fn report_latency(t: &Tree, nworst: usize, verbose: bool) -> String {
    let mut v: Vec<usize> = (0..t.nodes.len()).filter(|i| t.nodes[*i].kind.is_leaf()).collect();
    v.sort_by(|a, b| t.nodes[*b].lat_in[0].partial_cmp(&t.nodes[*a].lat_in[0]).unwrap_or(std::cmp::Ordering::Equal));
    let mut s = format!("\n  Clock: {}\n  {:<50} {:>5} {:>9} {:>9} {:>8}\n", t.clock, "Sink pin", "Level", "Late", "Early", "Tran");
    let show: Vec<usize> = if v.len() <= 2 * nworst { v.clone() } else { v.iter().take(nworst).chain(v.iter().rev().take(nworst).collect::<Vec<_>>().into_iter().rev()).copied().collect() };
    for (k, i) in show.iter().enumerate() {
        if v.len() > 2 * nworst && k == nworst {
            s += &format!("  {:<50}\n", format!("... {} sink(s) ...", v.len() - 2 * nworst));
        }
        let n = &t.nodes[*i];
        s += &format!("  {:<50} {:>5} {:>9} {:>9} {:>8.4}\n", trunc(&n.pin, 50), n.level, f4(n.lat_in[0]), f4(n.lat_in[1]), n.tr_in);
        if verbose {
            for j in t.path(*i) {
                let p = &t.nodes[j];
                if p.kind.is_leaf() {
                    continue;
                }
                let inc = if p.parent != NONE { p.lat_out[0] - t.nodes[p.parent].lat_out[0] } else { p.lat_out[0] };
                s += &format!("      L{:<2} {:<40} {:<14} {:>9} (+{:.4})\n", p.level, trunc(if p.kind == Kind::Root { &p.pin } else { &p.name }, 40), trunc(&p.lib, 14), f4(p.lat_out[0]), inc);
            }
        }
    }
    let (mx, mn, sk) = t.latency();
    s += &format!("  Latency late max {} / min {}, skew {}\n", f4(mx), f4(mn), f4(sk));
    s
}

pub fn report_histogram(t: &Tree, bins: usize) -> String {
    let v: Vec<f64> = t.sinks().map(|n| n.lat_in[0]).filter(|x| x.is_finite()).collect();
    let mut s = format!("\n  Clock: {}   sink latency histogram ({} sinks)\n", t.clock, v.len());
    if v.is_empty() {
        return s;
    }
    let mx = v.iter().cloned().fold(f64::MIN, f64::max);
    let mn = v.iter().cloned().fold(f64::MAX, f64::min);
    let w = ((mx - mn) / bins as f64).max(1e-6);
    let mut h = vec![0usize; bins];
    for x in &v {
        h[(((x - mn) / w) as usize).min(bins - 1)] += 1;
    }
    let top = *h.iter().max().unwrap_or(&1);
    for (i, c) in h.iter().enumerate() {
        s += &format!("  {:>8.4} - {:>8.4} | {:<50} {}\n", mn + i as f64 * w, mn + (i + 1) as f64 * w, "#".repeat((c * 50 + top - 1) / top.max(1)), c);
    }
    s
}

pub fn report_drc(t: &Tree, max_tr: f64, max_cap: f64, max_fo: usize) -> (String, usize) {
    let mut s = format!("\n  Clock: {}   limits: max_transition {:.4}  max_capacitance {:.4}  max_fanout {}\n", t.clock, max_tr, max_cap, max_fo);
    let mut n = 0;
    for x in &t.nodes {
        if !x.kind.is_leaf() {
            if x.cap > max_cap + 1e-9 {
                s += &format!("  max_capacitance  {:<44} {:>9.4} > {:.4}\n", trunc(&x.out_net, 44), x.cap, max_cap);
                n += 1;
            }
            if x.fanout > max_fo && x.kind != Kind::Root {
                s += &format!("  max_fanout       {:<44} {:>9} > {}\n", trunc(&x.out_net, 44), x.fanout, max_fo);
                n += 1;
            }
        }
        if x.kind != Kind::Root && x.tr_in > max_tr + 1e-9 {
            s += &format!("  max_transition   {:<44} {:>9.4} > {:.4}\n", trunc(&x.pin, 44), x.tr_in, max_tr);
            n += 1;
        }
    }
    if !t.as_data.is_empty() {
        s += &format!("  clock used as data at {} pin(s), e.g. {}\n", t.as_data.len(), t.as_data[0]);
    }
    s += &format!("  {} violation(s)\n", n);
    (s, n)
}

fn trunc(s: &str, n: usize) -> String {
    if s.chars().count() <= n {
        s.to_string()
    } else {
        let k: String = s.chars().rev().take(n - 2).collect::<Vec<_>>().into_iter().rev().collect();
        format!("..{}", k)
    }
}

// ---------------------------------------------------------------- JSON export

fn js(s: &str) -> String {
    let mut o = String::from("\"");
    for ch in s.chars() {
        match ch {
            '"' => o += "\\\"",
            '\\' => o += "\\\\",
            '<' => o += "\\u003c",
            c if (c as u32) < 0x20 => o += &format!("\\u{:04x}", c as u32),
            c => o.push(c),
        }
    }
    o + "\""
}
fn jn(x: f64) -> String {
    if x.is_finite() {
        format!("{:.5}", x)
    } else {
        "null".into()
    }
}

pub fn to_json(trees: &[Tree], die: Option<(f64, f64, f64, f64)>, design: &str, scen: &str) -> String {
    let mut s = format!("{{\"design\":{},\"scenario\":{},", js(design), js(scen));
    s += &match die {
        Some(d) => format!("\"die\":[{},{},{},{}],", d.0, d.1, d.2, d.3),
        None => "\"die\":null,".into(),
    };
    s += "\"clocks\":[";
    for (k, t) in trees.iter().enumerate() {
        if k > 0 {
            s += ",";
        }
        let (mx, mn, sk) = t.latency();
        s += &format!("{{\"name\":{},\"period\":{},\"maxlat\":{},\"minlat\":{},\"skew\":{},\"levels\":[{},{}],\"nodes\":[", js(&t.clock), t.period, jn(mx), jn(mn), jn(sk), t.min_level(), t.max_level());
        for (i, n) in t.nodes.iter().enumerate() {
            if i > 0 {
                s += ",";
            }
            let (x, y) = n.loc.map(|(x, y)| (jn(x), jn(y))).unwrap_or(("null".into(), "null".into()));
            s += &format!(
                "[{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}]",
                if n.parent == NONE { -1 } else { n.parent as i64 },
                js(n.kind.name()),
                js(if n.kind == Kind::Root || n.kind.is_leaf() { &n.pin } else { &n.name }),
                js(&n.lib),
                n.level,
                jn(n.lat_in[0]),
                jn(n.lat_in[1]),
                jn(n.lat_out[0]),
                jn(n.tr_out.max(n.tr_in)),
                n.fanout,
                jn(n.cap),
                x,
                y,
                n.sinks,
                jn(if n.sinks > 0 { n.smin } else { f64::NAN }),
                jn(if n.sinks > 0 { n.smax } else { f64::NAN }),
                if n.cts { 1 } else { 0 },
                js(&n.out_net)
            );
        }
        s += "]}";
    }
    s + "]}"
}


