//! Per-pin timing snapshot for property queries on every pin: setup / hold slack, max / min
//! arrival and required time, max / min transition (each rise and fall), pin and net load.
//!
//! The required times use their own backward pass, separate from the optimizer's arrays.
//! Endpoints are seeded per transition from their launch-tag required records (with CRPR),
//! then setup required times go back over the late arc delays and hold over the early ones.
//! Slack at a pin is graph-based: the worst over every clock passing through it.
use crate::netlist::{Dir, PinRef};
use crate::sta::{Timing, AK, NOCLK, NONE};

#[derive(Clone, Copy, Debug)]
pub struct PinTime {
    pub setup_slack: [f64; 2],
    pub hold_slack: [f64; 2],
    pub at_max: [f64; 2],
    pub at_min: [f64; 2],
    pub req_max: [f64; 2],
    pub req_min: [f64; 2],
    pub slew_max: [f64; 2],
    pub slew_min: [f64; 2],
    pub pin_cap: f64,
    pub net_cap: f64,
    pub fanout: usize,
    pub is_clock: bool,
}

impl PinTime {
    pub fn empty() -> PinTime {
        let i = f64::INFINITY;
        PinTime { setup_slack: [i; 2], hold_slack: [i; 2], at_max: [f64::NAN; 2], at_min: [f64::NAN; 2], req_max: [f64::NAN; 2], req_min: [f64::NAN; 2], slew_max: [0.0; 2], slew_min: [0.0; 2], pin_cap: 0.0, net_cap: 0.0, fanout: 0, is_clock: false }
    }
    /// merge another scenario: worst setup (late) and worst hold (early) values
    pub fn merge(&mut self, o: &PinTime, setup: bool, hold: bool) {
        for rf in 0..2 {
            if setup {
                self.setup_slack[rf] = self.setup_slack[rf].min(o.setup_slack[rf]);
                self.at_max[rf] = fmax(self.at_max[rf], o.at_max[rf]);
                self.req_max[rf] = fmin(self.req_max[rf], o.req_max[rf]);
                self.slew_max[rf] = self.slew_max[rf].max(o.slew_max[rf]);
            }
            if hold {
                self.hold_slack[rf] = self.hold_slack[rf].min(o.hold_slack[rf]);
                self.at_min[rf] = fmin(self.at_min[rf], o.at_min[rf]);
                self.req_min[rf] = fmax(self.req_min[rf], o.req_min[rf]);
                self.slew_min[rf] = if self.slew_min[rf] == 0.0 { o.slew_min[rf] } else if o.slew_min[rf] == 0.0 { self.slew_min[rf] } else { self.slew_min[rf].min(o.slew_min[rf]) };
            }
        }
        self.pin_cap = self.pin_cap.max(o.pin_cap);
        self.net_cap = self.net_cap.max(o.net_cap);
        self.fanout = self.fanout.max(o.fanout);
        self.is_clock |= o.is_clock;
    }
}

fn fmax(a: f64, b: f64) -> f64 {
    if a.is_nan() {
        b
    } else if b.is_nan() {
        a
    } else {
        a.max(b)
    }
}
fn fmin(a: f64, b: f64) -> f64 {
    if a.is_nan() {
        b
    } else if b.is_nan() {
        a
    } else {
        a.min(b)
    }
}

impl<'a> Timing<'a> {
    fn min_at(&self, n: u32, rf: usize) -> f64 {
        self.tags[n as usize].iter().filter(|t| t.clk != NOCLK).map(|t| t.atn[rf]).fold(f64::INFINITY, f64::min)
    }

    /// timing of every node of the graph (indexed like `nodes`)
    pub fn pin_times(&self) -> Vec<PinTime> {
        let n = self.nodes.len();
        let inf = f64::INFINITY;
        let mut req = vec![[inf; 2]; n];
        let mut reqn = vec![[f64::NEG_INFINITY; 2]; n];
        // ---- endpoint seeds, per transition and launch tag, with CRPR
        for ep in &self.endpoints {
            let e = ep.node as usize;
            for rf in 0..2usize {
                let (mut ss, mut hs) = (inf, inf);
                let (mut has_s, mut has_h) = (false, false);
                for r in ep.reqs.iter().filter(|r| r.rf as usize == rf) {
                    let tg: Vec<_> = self.tags[e].iter().filter(|t| t.clk == r.clk && t.ledge == r.ledge).collect();
                    if r.hold {
                        let Some(t) = tg.iter().min_by(|a, b| a.atn[rf].partial_cmp(&b.atn[rf]).unwrap_or(std::cmp::Ordering::Equal)) else { continue };
                        if !t.atn[rf].is_finite() {
                            continue;
                        }
                        let cr = if r.crpr_ok && r.ck != NONE && self.opts.crpr && t.startn != NONE { self.crpr(t.startn, r.ck, r.clk).0 } else { 0.0 };
                        hs = hs.min(t.atn[rf] - (r.req - cr));
                        has_h = true;
                    } else {
                        let Some(t) = tg.iter().max_by(|a, b| a.at[rf].partial_cmp(&b.at[rf]).unwrap_or(std::cmp::Ordering::Equal)) else { continue };
                        if !t.at[rf].is_finite() {
                            continue;
                        }
                        let cr = if r.crpr_ok && r.ck != NONE && self.opts.crpr && t.start != NONE { self.crpr(t.start, r.ck, r.clk).0 } else { 0.0 };
                        ss = ss.min(r.req + cr - t.at[rf]);
                        has_s = true;
                    }
                }
                // checks without a per-tag record (exception-bounded, data checks): endpoint slack
                if !has_s && ep.setup_slack.is_finite() {
                    ss = ep.setup_slack;
                }
                if !has_h && ep.hold_slack.is_finite() {
                    hs = ep.hold_slack;
                }
                let a = self.max_at(ep.node, rf);
                if ss.is_finite() && a.is_finite() {
                    req[e][rf] = req[e][rf].min(a + ss);
                }
                let an = self.min_at(ep.node, rf);
                if hs.is_finite() && an.is_finite() {
                    reqn[e][rf] = reqn[e][rf].max(an - hs);
                }
            }
        }
        // ---- backward: setup over late delays, hold over early delays
        for &u in self.topo.iter().rev() {
            for &ai in &self.fan_out[u as usize] {
                let a = &self.arcs[ai as usize];
                if matches!(a.k, AK::Launch(..) | AK::GenLaunch(_)) {
                    continue;
                }
                for irf in 0..2 {
                    for orf in 0..2 {
                        let d = self.arc_d[ai as usize][irf][orf];
                        if !d.is_nan() {
                            let r = req[a.to as usize][orf] - d;
                            if r < req[u as usize][irf] {
                                req[u as usize][irf] = r;
                            }
                        }
                        let dn = self.arc_dn[ai as usize][irf][orf];
                        if !dn.is_nan() {
                            let r = reqn[a.to as usize][orf] - dn;
                            if r > reqn[u as usize][irf] {
                                reqn[u as usize][irf] = r;
                            }
                        }
                    }
                }
            }
        }
        // ---- per node values
        let nl = self.nl;
        let mut out: Vec<PinTime> = (0..n)
            .map(|i| {
                let mut p = PinTime::empty();
                let tags = &self.tags[i];
                let ctags = &self.ctags[i];
                for rf in 0..2 {
                    let am = self.max_at(i as u32, rf);
                    let an = self.min_at(i as u32, rf);
                    if am.is_finite() {
                        p.at_max[rf] = am;
                        if req[i][rf].is_finite() {
                            p.req_max[rf] = req[i][rf];
                            p.setup_slack[rf] = req[i][rf] - am;
                        }
                    }
                    if an.is_finite() {
                        p.at_min[rf] = an;
                        if reqn[i][rf].is_finite() {
                            p.req_min[rf] = reqn[i][rf];
                            p.hold_slack[rf] = an - reqn[i][rf];
                        }
                    }
                    let mut smax = tags.iter().filter(|t| t.clk != NOCLK).map(|t| t.sl[rf]).fold(0.0, f64::max);
                    let mut smin = tags.iter().filter(|t| t.clk != NOCLK && t.sln[rf] > 0.0).map(|t| t.sln[rf]).fold(f64::INFINITY, f64::min);
                    if !ctags.is_empty() {
                        // clock network pin: clock latency as arrival, clock slew
                        p.is_clock = true;
                        smax = smax.max(ctags.iter().map(|c| c.slew).fold(0.0, f64::max));
                        smin = smin.min(ctags.iter().map(|c| c.slew).fold(f64::INFINITY, f64::min));
                        if p.at_max[rf].is_nan() {
                            p.at_max[rf] = ctags.iter().map(|c| c.lmax).fold(f64::NEG_INFINITY, f64::max);
                            p.at_min[rf] = ctags.iter().map(|c| c.lmin).fold(f64::INFINITY, f64::min);
                        }
                    }
                    p.slew_max[rf] = smax;
                    p.slew_min[rf] = if smin.is_finite() { smin } else { smax };
                }
                let pr = self.nodes[i];
                if let Some(net) = nl.pin_net(pr) {
                    p.net_cap = self.net_c.get(net).copied().unwrap_or(0.0);
                    if nl.is_driver(pr) {
                        p.fanout = nl.loads(net).len();
                    }
                }
                p.pin_cap = match pr {
                    PinRef::Cell(c, k) => {
                        let cl = nl.cell(c);
                        cl.lib().and_then(|l| self.libs.cell(l)).and_then(|lc| lc.pins.iter().find(|x| x.name == cl.pins[k].name)).map(|x| if x.dir == Some(Dir::Out) { 0.0 } else { x.cap }).unwrap_or(0.0)
                    }
                    PinRef::Port(_) => 0.0,
                };
                p
            })
            .collect();
        // launch clock pins carry the slack of the paths they launch
        for i in 0..n {
            for &ai in &self.fan_out[i] {
                let a = &self.arcs[ai as usize];
                if !matches!(a.k, AK::Launch(..) | AK::GenLaunch(_)) {
                    continue;
                }
                let q = out[a.to as usize];
                let (s, h) = (q.setup_slack[0].min(q.setup_slack[1]), q.hold_slack[0].min(q.hold_slack[1]));
                for rf in 0..2 {
                    out[i].setup_slack[rf] = out[i].setup_slack[rf].min(s);
                    out[i].hold_slack[rf] = out[i].hold_slack[rf].min(h);
                }
            }
        }
        out
    }
}

// ---------------------------------------------------------------- session side
use crate::cons::Obj;
use crate::session::Session;
use std::collections::HashMap;
use std::rc::Rc;

pub type PinSnap = Rc<HashMap<PinRef, PinTime>>;

/// commands that cannot change the design or its timing (they keep the pin-timing cache)
pub fn read_only(name: &str) -> bool {
    const RO: &[&str] = &[
        "sizeof_collection", "index_collection", "filter_collection", "sort_collection", "foreach_in_collection", "add_to_collection", "remove_from_collection", "copy_collection", "compare_collections",
        "get_property", "get_db_property", "get_attribute", "set_property", "set_attribute", "define_property", "define_user_attribute", "define_attribute", "list_property", "list_attributes",
        "dbGet", "dbGetInstByName", "dbGetNetByName", "dbGetTermByName", "dbGetCellByName", "dbGetInstTermByName", "dbGetTermByInstTermName", "get_object_name", "query_objects",
        "select_obj", "add_to_selection", "remove_from_selection", "deselect_all", "change_selection", "help", "man", "printvar", "print_message_info", "redirect", "sh", "date", "getenv",
    ];
    RO.contains(&name) || ["get_", "report_", "all_", "check_", "list_", "write_", "gui_", "print_", "verify_"].iter().any(|p| name.starts_with(p))
}

fn num(x: f64) -> String {
    if x.is_nan() {
        String::new()
    } else if x == f64::INFINITY {
        "INFINITY".into()
    } else if x == f64::NEG_INFINITY {
        "-INFINITY".into()
    } else {
        let s = format!("{:.6}", x);
        let s = s.trim_end_matches('0').trim_end_matches('.').to_string();
        if s == "-0" { "0".into() } else { s }
    }
}

impl Session {
    pub(crate) fn bump_epoch(&self) {
        self.epoch.set(self.epoch.get() + 1);
    }

    /// pin timing merged over the active scenarios (setup values from setup scenarios, hold values
    /// from hold scenarios), or of one scenario; cached until the design changes
    pub(crate) fn pin_snapshot(&self, scen: Option<usize>) -> Option<PinSnap> {
        let ep = self.epoch.get();
        {
            let c = self.pin_cache.borrow();
            if c.0 == ep {
                if let Some(s) = c.1.get(&scen) {
                    return Some(s.clone());
                }
            }
        }
        let scens: Vec<usize> = match scen {
            Some(s) => vec![s],
            None => self.active(""),
        };
        let mut m: HashMap<PinRef, PinTime> = HashMap::new();
        for si in scens {
            let (su, ho) = if scen.is_some() { (true, true) } else { (self.scens[si].setup, self.scens[si].hold) };
            if !su && !ho {
                continue;
            }
            let v = self.with_timing(si, |t| t.nodes.iter().copied().zip(t.pin_times()).collect::<Vec<_>>()).ok()?;
            for (pr, p) in v {
                m.entry(pr)
                    .and_modify(|e| e.merge(&p, su, ho))
                    .or_insert_with(|| {
                        let mut e = PinTime::empty();
                        e.merge(&p, su, ho);
                        e
                    });
            }
        }
        let snap = Rc::new(m);
        let mut c = self.pin_cache.borrow_mut();
        if c.0 != ep {
            c.0 = ep;
            c.1.clear();
        }
        c.1.insert(scen, snap.clone());
        Some(snap)
    }

    /// timing / load properties of pins, ports and nets
    pub(crate) fn pin_time_attr(&self, h: &str, at: &str) -> Option<Option<String>> {
        const PROPS: &[&str] = &[
            "slack", "max_slack", "slack_max", "setup_slack", "worst_slack", "max_rise_slack", "slack_max_rise", "max_fall_slack", "slack_max_fall", "min_slack", "slack_min", "hold_slack", "min_rise_slack", "slack_min_rise", "min_fall_slack", "slack_min_fall",
            "arrival", "arrival_max", "max_arrival", "arrival_max_rise", "max_rise_arrival", "arrival_max_fall", "max_fall_arrival", "arrival_min", "min_arrival", "arrival_min_rise", "min_rise_arrival", "arrival_min_fall", "min_fall_arrival",
            "required", "required_max", "max_required", "required_max_rise", "max_rise_required", "required_max_fall", "max_fall_required", "required_min", "min_required", "required_min_rise", "min_rise_required", "required_min_fall", "min_fall_required",
            "transition", "slew", "slew_max", "actual_transition_max", "max_transition_actual", "slew_max_rise", "actual_rise_transition_max", "slew_max_fall", "actual_fall_transition_max", "slew_min", "actual_transition_min", "slew_min_rise", "actual_rise_transition_min", "slew_min_fall", "actual_fall_transition_min",
            "pin_capacitance", "pin_capacitance_max", "pin_capacitance_min", "capacitance", "capacitance_max", "capacitance_min", "pin_cap", "load", "total_capacitance", "total_capacitance_max", "net_capacitance", "load_capacitance", "wire_capacitance", "fanout", "is_clock_pin", "is_clock_network",
        ];
        if !PROPS.contains(&at) {
            return None;
        }
        let o = Obj::parse(h)?;
        let nl = self.nl.as_ref()?;
        let pr = match &o {
            Obj::Pin(n) | Obj::Port(n) => nl.find_pin(n)?,
            Obj::Net(n) => {
                // a net's timing is its driver's; its load is the net total
                let id = nl.net_by_name(n)?;
                nl.driver(id).or_else(|| nl.net(id).conns.first().copied())?
            }
            _ => return None,
        };
        if matches!(o, Obj::Net(_)) && at == "fanout" {
            return None; // native net fanout attribute
        }
        let snap = self.pin_snapshot(self.prop_scen.get())?;
        let p = snap.get(&pr).copied().unwrap_or_else(PinTime::empty);
        let mn = |a: [f64; 2]| a[0].min(a[1]);
        let mx = |a: [f64; 2]| if a[0].is_nan() { a[1] } else if a[1].is_nan() { a[0] } else { a[0].max(a[1]) };
        let mnn = |a: [f64; 2]| if a[0].is_nan() { a[1] } else if a[1].is_nan() { a[0] } else { a[0].min(a[1]) };
        let v = match at {
            "slack" | "max_slack" | "slack_max" | "setup_slack" | "worst_slack" => mn(p.setup_slack),
            "max_rise_slack" | "slack_max_rise" => p.setup_slack[0],
            "max_fall_slack" | "slack_max_fall" => p.setup_slack[1],
            "min_slack" | "slack_min" | "hold_slack" => mn(p.hold_slack),
            "min_rise_slack" | "slack_min_rise" => p.hold_slack[0],
            "min_fall_slack" | "slack_min_fall" => p.hold_slack[1],
            "arrival" | "arrival_max" | "max_arrival" => mx(p.at_max),
            "arrival_max_rise" | "max_rise_arrival" => p.at_max[0],
            "arrival_max_fall" | "max_fall_arrival" => p.at_max[1],
            "arrival_min" | "min_arrival" => mnn(p.at_min),
            "arrival_min_rise" | "min_rise_arrival" => p.at_min[0],
            "arrival_min_fall" | "min_fall_arrival" => p.at_min[1],
            "required" | "required_max" | "max_required" => mnn(p.req_max),
            "required_max_rise" | "max_rise_required" => p.req_max[0],
            "required_max_fall" | "max_fall_required" => p.req_max[1],
            "required_min" | "min_required" => mx(p.req_min),
            "required_min_rise" | "min_rise_required" => p.req_min[0],
            "required_min_fall" | "min_fall_required" => p.req_min[1],
            "transition" | "slew" | "slew_max" | "actual_transition_max" | "max_transition_actual" => mx(p.slew_max),
            "slew_max_rise" | "actual_rise_transition_max" => p.slew_max[0],
            "slew_max_fall" | "actual_fall_transition_max" => p.slew_max[1],
            "slew_min" | "actual_transition_min" => mnn(p.slew_min),
            "slew_min_rise" | "actual_rise_transition_min" => p.slew_min[0],
            "slew_min_fall" | "actual_fall_transition_min" => p.slew_min[1],
            "pin_capacitance" | "pin_capacitance_max" | "pin_capacitance_min" | "pin_cap" | "capacitance" | "capacitance_max" | "capacitance_min" => {
                if matches!(o, Obj::Net(_)) {
                    p.net_cap
                } else {
                    p.pin_cap
                }
            }
            "load" | "total_capacitance" | "total_capacitance_max" | "net_capacitance" | "load_capacitance" => p.net_cap,
            "wire_capacitance" => {
                let pins: f64 = nl.pin_net(pr).map(|n| nl.net(n).conns.iter().map(|c| snap.get(c).map(|x| x.pin_cap).unwrap_or(0.0)).sum()).unwrap_or(0.0);
                (p.net_cap - pins).max(0.0)
            }
            "fanout" => return Some(Some(p.fanout.to_string())),
            "is_clock_pin" | "is_clock_network" => return Some(Some(p.is_clock.to_string())),
            _ => return None,
        };
        Some(Some(num(v)))
    }
}
