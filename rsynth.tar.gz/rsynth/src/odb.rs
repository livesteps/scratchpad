//! Design database (`save_db design.odb` / `restore_db design.odb`).
//!
//! The database is one gzip file (RFC 1952 / DEFLATE RFC 1951, written and read by the built-in
//! codec below; `zcat design.odb | head -c 8` shows the `RSYNTHDB` magic). Inside, a versioned
//! binary image of the design state:
//! * netlist (cells, pins, nets, ports, hierarchy, names, attributes, placement),
//! * libraries (all parsed Liberty corners) and LEF (layers, macros, sites),
//! * MMMC timing setup: modes with all their constraints, corners (libraries, derates, OCV,
//!   parasitic scaling), scenarios with their analysis status, current mode / corner,
//!   annotated (SDF) delays, OCV / AOCV tables,
//! * extraction: routed RC networks and SPEF annotation per corner,
//! * floorplan / placement / PG / blockages / fill, the detailed routing database,
//!   CTS specification, route options, UPF, DFT setup, markers, app options, dont_use and stage
//!   history,
//! * a timing snapshot (WNS / TNS / WHS / THS per active scenario at save time) that
//!   `restore_db` compares with the restored timing.

use crate::session::{args, Session};
use crate::tcl::{err, R};
use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet};
use std::hash::Hash;
use std::sync::Arc;

pub const MAGIC: &[u8; 8] = b"RSYNTHDB";
pub const FORMAT: u32 = 1;

// ------------------------------------------------------------------ binary writer / reader
#[derive(Default)]
pub struct W {
    pub b: Vec<u8>,
}
impl W {
    pub fn u8(&mut self, v: u8) { self.b.push(v); }
    pub fn u32(&mut self, v: u32) { self.uv(v as u64); }
    /// LEB128 unsigned
    pub fn uv(&mut self, mut v: u64) {
        loop {
            let byte = (v & 0x7f) as u8;
            v >>= 7;
            if v == 0 { self.b.push(byte); break; }
            self.b.push(byte | 0x80);
        }
    }
    pub fn iv(&mut self, v: i64) { self.uv(((v << 1) ^ (v >> 63)) as u64); }
    pub fn bytes(&mut self, s: &[u8]) { self.uv(s.len() as u64); self.b.extend_from_slice(s); }
}
pub struct Rd<'a> {
    pub b: &'a [u8],
    pub p: usize,
}
impl<'a> Rd<'a> {
    pub fn u8(&mut self) -> Result<u8, String> {
        let v = *self.b.get(self.p).ok_or("design database truncated")?;
        self.p += 1;
        Ok(v)
    }
    pub fn uv(&mut self) -> Result<u64, String> {
        let mut v = 0u64;
        let mut sh = 0;
        loop {
            let byte = self.u8()?;
            v |= ((byte & 0x7f) as u64) << sh;
            if byte & 0x80 == 0 { return Ok(v); }
            sh += 7;
            if sh > 63 { return Err("design database: bad integer".into()); }
        }
    }
    pub fn u32(&mut self) -> Result<u32, String> { Ok(self.uv()? as u32) }
    pub fn iv(&mut self) -> Result<i64, String> { let u = self.uv()?; Ok(((u >> 1) as i64) ^ -((u & 1) as i64)) }
    pub fn bytes(&mut self) -> Result<&'a [u8], String> {
        let n = self.uv()? as usize;
        if self.p + n > self.b.len() { return Err("design database truncated".into()); }
        let s = &self.b[self.p..self.p + n];
        self.p += n;
        Ok(s)
    }
}

pub trait Odb: Sized {
    fn put(&self, w: &mut W);
    fn get(r: &mut Rd) -> Result<Self, String>;
}
macro_rules! uint { ($($t:ty),*) => { $( impl Odb for $t { fn put(&self, w: &mut W) { w.uv(*self as u64) } fn get(r: &mut Rd) -> Result<Self, String> { Ok(r.uv()? as $t) } } )* } }
macro_rules! sint { ($($t:ty),*) => { $( impl Odb for $t { fn put(&self, w: &mut W) { w.iv(*self as i64) } fn get(r: &mut Rd) -> Result<Self, String> { Ok(r.iv()? as $t) } } )* } }
uint!(u8, u16, u32, u64, usize);
sint!(i8, i16, i32, i64, isize);
impl Odb for bool { fn put(&self, w: &mut W) { w.u8(*self as u8) } fn get(r: &mut Rd) -> Result<Self, String> { Ok(r.u8()? != 0) } }
impl Odb for f64 { fn put(&self, w: &mut W) { w.b.extend_from_slice(&self.to_le_bytes()) } fn get(r: &mut Rd) -> Result<Self, String> { let mut a = [0u8; 8]; for x in a.iter_mut() { *x = r.u8()?; } Ok(f64::from_le_bytes(a)) } }
impl Odb for f32 { fn put(&self, w: &mut W) { w.b.extend_from_slice(&self.to_le_bytes()) } fn get(r: &mut Rd) -> Result<Self, String> { let mut a = [0u8; 4]; for x in a.iter_mut() { *x = r.u8()?; } Ok(f32::from_le_bytes(a)) } }
impl Odb for char { fn put(&self, w: &mut W) { w.uv(*self as u64) } fn get(r: &mut Rd) -> Result<Self, String> { char::from_u32(r.u32()?).ok_or_else(|| "bad char".into()) } }
impl Odb for String { fn put(&self, w: &mut W) { w.bytes(self.as_bytes()) } fn get(r: &mut Rd) -> Result<Self, String> { String::from_utf8(r.bytes()?.to_vec()).map_err(|_| "bad string".into()) } }
impl Odb for &'static str { fn put(&self, w: &mut W) { w.bytes(self.as_bytes()) } fn get(r: &mut Rd) -> Result<Self, String> { Ok(Box::leak(String::get(r)?.into_boxed_str())) } }
impl Odb for () { fn put(&self, _w: &mut W) {} fn get(_r: &mut Rd) -> Result<Self, String> { Ok(()) } }
impl<T: Odb> Odb for Vec<T> {
    fn put(&self, w: &mut W) { w.uv(self.len() as u64); for x in self { x.put(w); } }
    fn get(r: &mut Rd) -> Result<Self, String> {
        let n = r.uv()? as usize;
        let mut v = Vec::with_capacity(n.min(1 << 24));
        for _ in 0..n { v.push(T::get(r)?); }
        Ok(v)
    }
}
impl<T: Odb, const N: usize> Odb for [T; N] {
    fn put(&self, w: &mut W) { for x in self { x.put(w); } }
    fn get(r: &mut Rd) -> Result<Self, String> {
        let mut v = Vec::with_capacity(N);
        for _ in 0..N { v.push(T::get(r)?); }
        v.try_into().map_err(|_| "array".to_string())
    }
}
impl<T: Odb> Odb for Option<T> {
    fn put(&self, w: &mut W) { match self { None => w.u8(0), Some(x) => { w.u8(1); x.put(w) } } }
    fn get(r: &mut Rd) -> Result<Self, String> { Ok(if r.u8()? == 0 { None } else { Some(T::get(r)?) }) }
}
impl<T: Odb> Odb for Box<T> { fn put(&self, w: &mut W) { (**self).put(w) } fn get(r: &mut Rd) -> Result<Self, String> { Ok(Box::new(T::get(r)?)) } }
impl<T: Odb> Odb for Arc<T> { fn put(&self, w: &mut W) { (**self).put(w) } fn get(r: &mut Rd) -> Result<Self, String> { Ok(Arc::new(T::get(r)?)) } }
impl<T: Odb> Odb for std::rc::Rc<T> { fn put(&self, w: &mut W) { (**self).put(w) } fn get(r: &mut Rd) -> Result<Self, String> { Ok(std::rc::Rc::new(T::get(r)?)) } }
impl<K: Odb + Eq + Hash + Ord, V: Odb> Odb for HashMap<K, V> {
    // sorted, so the same design always writes the same bytes
    fn put(&self, w: &mut W) { w.uv(self.len() as u64); let mut v: Vec<(&K, &V)> = self.iter().collect(); v.sort_by(|a, b| a.0.cmp(b.0)); for (k, x) in v { k.put(w); x.put(w); } }
    fn get(r: &mut Rd) -> Result<Self, String> { let n = r.uv()? as usize; let mut m = HashMap::with_capacity(n.min(1 << 24)); for _ in 0..n { let k = K::get(r)?; m.insert(k, V::get(r)?); } Ok(m) }
}
impl<K: Odb + Ord, V: Odb> Odb for BTreeMap<K, V> {
    fn put(&self, w: &mut W) { w.uv(self.len() as u64); for (k, x) in self { k.put(w); x.put(w); } }
    fn get(r: &mut Rd) -> Result<Self, String> { let n = r.uv()? as usize; let mut m = BTreeMap::new(); for _ in 0..n { let k = K::get(r)?; m.insert(k, V::get(r)?); } Ok(m) }
}
impl<K: Odb + Eq + Hash + Ord> Odb for HashSet<K> {
    fn put(&self, w: &mut W) { w.uv(self.len() as u64); let mut v: Vec<&K> = self.iter().collect(); v.sort(); for k in v { k.put(w); } }
    fn get(r: &mut Rd) -> Result<Self, String> { let n = r.uv()? as usize; let mut m = HashSet::with_capacity(n.min(1 << 24)); for _ in 0..n { m.insert(K::get(r)?); } Ok(m) }
}
impl<K: Odb + Ord> Odb for BTreeSet<K> {
    fn put(&self, w: &mut W) { w.uv(self.len() as u64); for k in self { k.put(w); } }
    fn get(r: &mut Rd) -> Result<Self, String> { let n = r.uv()? as usize; let mut m = BTreeSet::new(); for _ in 0..n { m.insert(K::get(r)?); } Ok(m) }
}
macro_rules! tup { ($($n:ident $i:tt),*) => { impl<$($n: Odb),*> Odb for ($($n,)*) { fn put(&self, w: &mut W) { $( self.$i.put(w); )* } fn get(r: &mut Rd) -> Result<Self, String> { Ok(($( $n::get(r)?, )*)) } } } }
tup!(A 0, B 1);
tup!(A 0, B 1, C 2);
tup!(A 0, B 1, C 2, D 3);
tup!(A 0, B 1, C 2, D 3, E 4);
tup!(A 0, B 1, C 2, D 3, E 4, F 5);
tup!(A 0, B 1, C 2, D 3, E 4, F 5, G 6);
tup!(A 0, B 1, C 2, D 3, E 4, F 5, G 6, H 7);

// ------------------------------------------------------------------ CRC32 / DEFLATE / gzip
fn crc_table() -> [u32; 256] {
    let mut t = [0u32; 256];
    for (i, e) in t.iter_mut().enumerate() {
        let mut c = i as u32;
        for _ in 0..8 { c = if c & 1 != 0 { 0xEDB88320 ^ (c >> 1) } else { c >> 1 }; }
        *e = c;
    }
    t
}
pub fn crc32(d: &[u8]) -> u32 {
    let t = crc_table();
    let mut c = !0u32;
    for &b in d { c = t[((c ^ b as u32) & 0xff) as usize] ^ (c >> 8); }
    !c
}

const LBASE: [u16; 29] = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
const LEXT: [u8; 29] = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
const DBASE: [u16; 30] = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
const DEXT: [u8; 30] = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
const CLORD: [usize; 19] = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];

struct Bits { out: Vec<u8>, acc: u64, n: u32 }
impl Bits {
    fn put(&mut self, v: u32, n: u32) {
        self.acc |= (v as u64) << self.n;
        self.n += n;
        while self.n >= 8 { self.out.push(self.acc as u8); self.acc >>= 8; self.n -= 8; }
    }
    fn flush(&mut self) { if self.n > 0 { self.out.push(self.acc as u8); } self.acc = 0; self.n = 0; }
}

/// code lengths of a length-limited Huffman code for `freq`
fn huff_lengths(freq: &[u32], limit: u8) -> Vec<u8> {
    let mut f: Vec<u64> = freq.iter().map(|&x| x as u64).collect();
    loop {
        let syms: Vec<usize> = (0..f.len()).filter(|&i| f[i] > 0).collect();
        let mut len = vec![0u8; f.len()];
        if syms.is_empty() { return len; }
        if syms.len() == 1 { len[syms[0]] = 1; return len; }
        // nodes: (weight, id); parents for depth
        let mut parent: Vec<usize> = vec![usize::MAX; syms.len() * 2];
        let mut heap: std::collections::BinaryHeap<std::cmp::Reverse<(u64, usize)>> = syms.iter().enumerate().map(|(k, &s)| std::cmp::Reverse((f[s], k))).collect();
        let mut next = syms.len();
        while heap.len() > 1 {
            let std::cmp::Reverse((wa, a)) = heap.pop().unwrap();
            let std::cmp::Reverse((wb, b)) = heap.pop().unwrap();
            parent[a] = next;
            parent[b] = next;
            heap.push(std::cmp::Reverse((wa + wb, next)));
            next += 1;
        }
        let mut maxl = 0;
        for (k, &s) in syms.iter().enumerate() {
            let mut d = 0u8;
            let mut x = k;
            while parent[x] != usize::MAX { x = parent[x]; d += 1; }
            len[s] = d;
            maxl = maxl.max(d);
        }
        if maxl <= limit { return len; }
        for x in f.iter_mut() { if *x > 0 { *x = (*x >> 1).max(1); } }
    }
}
/// canonical codes (bit-reversed for the LSB-first stream)
fn huff_codes(len: &[u8]) -> Vec<u32> {
    let mut bl = [0u32; 16];
    for &l in len { if l > 0 { bl[l as usize] += 1; } }
    let mut next = [0u32; 16];
    let mut code = 0;
    for b in 1..16 { code = (code + bl[b - 1]) << 1; next[b] = code; }
    len.iter().map(|&l| {
        if l == 0 { return 0; }
        let c = next[l as usize];
        next[l as usize] += 1;
        let mut r = 0;
        for i in 0..l { if c & (1 << i) != 0 { r |= 1 << (l - 1 - i); } }
        r
    }).collect()
}

enum Tok { Lit(u8), Match(u16, u16) }

fn lz77(d: &[u8]) -> Vec<Tok> {
    const WIN: usize = 32768;
    const HB: usize = 15;
    let mut head = vec![usize::MAX; 1 << HB];
    let mut prev = vec![usize::MAX; WIN];
    let mut toks = Vec::with_capacity(d.len() / 3);
    let h = |i: usize| -> usize { (((d[i] as usize) << 10) ^ ((d[i + 1] as usize) << 5) ^ d[i + 2] as usize) & ((1 << HB) - 1) };
    let mut i = 0;
    let n = d.len();
    let ins = |i: usize, head: &mut Vec<usize>, prev: &mut Vec<usize>| {
        if i + 2 < n { let k = h(i); prev[i % WIN] = head[k]; head[k] = i; }
    };
    while i < n {
        let mut best = (0usize, 0usize);
        if i + 2 < n {
            let mut c = head[h(i)];
            let mut chain = 48;
            while c != usize::MAX && i - c <= WIN - 1 && chain > 0 {
                if d[c + best.0.min(n - i - 1)] == d[i + best.0.min(n - i - 1)] {
                    let mut l = 0;
                    let maxl = (n - i).min(258);
                    while l < maxl && d[c + l] == d[i + l] { l += 1; }
                    if l > best.0 { best = (l, i - c); if l == maxl { break; } }
                }
                let pc = prev[c % WIN];
                if pc == usize::MAX || pc >= c { break; }
                c = pc;
                chain -= 1;
            }
        }
        if best.0 >= 3 {
            toks.push(Tok::Match(best.0 as u16, best.1 as u16));
            for k in 0..best.0 { ins(i + k, &mut head, &mut prev); }
            i += best.0;
        } else {
            toks.push(Tok::Lit(d[i]));
            ins(i, &mut head, &mut prev);
            i += 1;
        }
    }
    toks
}
fn lcode(l: u16) -> usize { let mut k = 28; while LBASE[k] > l { k -= 1; } k }
fn dcode(d: u16) -> usize { let mut k = 29; while DBASE[k] > d { k -= 1; } k }

/// DEFLATE (dynamic Huffman blocks)
pub fn deflate(d: &[u8]) -> Vec<u8> {
    let toks = lz77(d);
    let mut bw = Bits { out: Vec::with_capacity(d.len() / 4 + 64), acc: 0, n: 0 };
    let chunks: Vec<&[Tok]> = if toks.is_empty() { vec![&toks[..]] } else { toks.chunks(1 << 16).collect() };
    let nchunks = chunks.len();
    for (ci, ch) in chunks.into_iter().enumerate() {
        let mut lf = vec![0u32; 286];
        let mut df = vec![0u32; 30];
        for t in ch {
            match t { Tok::Lit(b) => lf[*b as usize] += 1, Tok::Match(l, dd) => { lf[257 + lcode(*l)] += 1; df[dcode(*dd)] += 1; } }
        }
        lf[256] = 1;
        if df.iter().all(|x| *x == 0) { df[0] = 1; }
        let ll = huff_lengths(&lf, 15);
        let dl = huff_lengths(&df, 15);
        let lc = huff_codes(&ll);
        let dc = huff_codes(&dl);
        let nlit = (257..=286).rev().find(|&k| ll[k - 1] > 0).unwrap_or(257).max(257);
        let ndist = (1..=30).rev().find(|&k| dl[k - 1] > 0).unwrap_or(1).max(1);
        let all: Vec<u8> = ll[..nlit].iter().chain(dl[..ndist].iter()).copied().collect();
        // run-length encode the code lengths
        let mut rle: Vec<(u8, u8)> = vec![];
        let mut k = 0;
        while k < all.len() {
            let v = all[k];
            let mut run = 1;
            while k + run < all.len() && all[k + run] == v { run += 1; }
            if v == 0 && run >= 3 {
                let mut r = run;
                while r >= 3 { let t = r.min(138); if t >= 11 { rle.push((18, (t - 11) as u8)); } else { rle.push((17, (t - 3) as u8)); } r -= t; }
                for _ in 0..r { rle.push((0, 0)); }
            } else if v != 0 && run >= 4 {
                rle.push((v, 0));
                let mut r = run - 1;
                while r >= 3 { let t = r.min(6); rle.push((16, (t - 3) as u8)); r -= t; }
                for _ in 0..r { rle.push((v, 0)); }
            } else {
                for _ in 0..run { rle.push((v, 0)); }
            }
            k += run;
        }
        let mut cf = vec![0u32; 19];
        for (s, _) in &rle { cf[*s as usize] += 1; }
        let cl = huff_lengths(&cf, 7);
        let cc = huff_codes(&cl);
        let nclen = (4..=19).rev().find(|&k| cl[CLORD[k - 1]] > 0).unwrap_or(4).max(4);
        bw.put((ci + 1 == nchunks) as u32, 1);
        bw.put(2, 2);
        bw.put((nlit - 257) as u32, 5);
        bw.put((ndist - 1) as u32, 5);
        bw.put((nclen - 4) as u32, 4);
        for &o in CLORD.iter().take(nclen) { bw.put(cl[o] as u32, 3); }
        for (s, e) in &rle {
            bw.put(cc[*s as usize], cl[*s as usize] as u32);
            match s { 16 => bw.put(*e as u32, 2), 17 => bw.put(*e as u32, 3), 18 => bw.put(*e as u32, 7), _ => {} }
        }
        for t in ch {
            match t {
                Tok::Lit(b) => bw.put(lc[*b as usize], ll[*b as usize] as u32),
                Tok::Match(l, dd) => {
                    let c = lcode(*l);
                    bw.put(lc[257 + c], ll[257 + c] as u32);
                    if LEXT[c] > 0 { bw.put((*l - LBASE[c]) as u32, LEXT[c] as u32); }
                    let e = dcode(*dd);
                    bw.put(dc[e], dl[e] as u32);
                    if DEXT[e] > 0 { bw.put((*dd - DBASE[e]) as u32, DEXT[e] as u32); }
                }
            }
        }
        bw.put(lc[256], ll[256] as u32);
    }
    bw.flush();
    bw.out
}

struct BitIn<'a> { d: &'a [u8], p: usize, acc: u64, n: u32 }
impl<'a> BitIn<'a> {
    fn need(&mut self, n: u32) -> Result<(), String> {
        while self.n < n {
            let b = *self.d.get(self.p).ok_or("compressed data truncated")?;
            self.p += 1;
            self.acc |= (b as u64) << self.n;
            self.n += 8;
        }
        Ok(())
    }
    fn get(&mut self, n: u32) -> Result<u32, String> {
        if n == 0 { return Ok(0); }
        self.need(n)?;
        let v = (self.acc & ((1u64 << n) - 1)) as u32;
        self.acc >>= n;
        self.n -= n;
        Ok(v)
    }
    fn align(&mut self) { let r = self.n % 8; self.acc >>= r; self.n -= r; }
}
/// decoding table: (first code, count, symbol offset) per length, canonical order
struct Huff { cnt: [u16; 16], sym: Vec<u16> }
impl Huff {
    fn new(len: &[u8]) -> Huff {
        let mut cnt = [0u16; 16];
        for &l in len { cnt[l as usize] += 1; }
        cnt[0] = 0;
        let mut offs = [0u16; 16];
        for i in 1..16 { offs[i] = offs[i - 1] + cnt[i - 1]; }
        let mut sym = vec![0u16; len.len()];
        for (s, &l) in len.iter().enumerate() { if l > 0 { sym[offs[l as usize] as usize] = s as u16; offs[l as usize] += 1; } }
        Huff { cnt, sym }
    }
    fn decode(&self, b: &mut BitIn) -> Result<u16, String> {
        let (mut code, mut first, mut index) = (0i32, 0i32, 0i32);
        for l in 1..16 {
            code |= b.get(1)? as i32;
            let c = self.cnt[l] as i32;
            if code - c < first { return Ok(self.sym[(index + (code - first)) as usize]); }
            index += c;
            first += c;
            first <<= 1;
            code <<= 1;
        }
        Err("bad Huffman code".into())
    }
}
pub fn inflate(d: &[u8]) -> Result<Vec<u8>, String> {
    let mut b = BitIn { d, p: 0, acc: 0, n: 0 };
    let mut out: Vec<u8> = Vec::with_capacity(d.len() * 4);
    loop {
        let last = b.get(1)?;
        let ty = b.get(2)?;
        match ty {
            0 => {
                b.align();
                let len = b.get(16)? as usize;
                let _nlen = b.get(16)?;
                for _ in 0..len { out.push(b.get(8)? as u8); }
            }
            1 | 2 => {
                let (lh, dh) = if ty == 1 {
                    let mut l = vec![8u8; 288];
                    for x in l.iter_mut().take(256).skip(144) { *x = 9; }
                    for x in l.iter_mut().take(280).skip(256) { *x = 7; }
                    (Huff::new(&l), Huff::new(&[5u8; 30]))
                } else {
                    let nlit = b.get(5)? as usize + 257;
                    let ndist = b.get(5)? as usize + 1;
                    let nclen = b.get(4)? as usize + 4;
                    let mut cl = [0u8; 19];
                    for &o in CLORD.iter().take(nclen) { cl[o] = b.get(3)? as u8; }
                    let ch = Huff::new(&cl);
                    let mut lens = vec![];
                    while lens.len() < nlit + ndist {
                        let s = ch.decode(&mut b)?;
                        match s {
                            0..=15 => lens.push(s as u8),
                            16 => { let p = *lens.last().ok_or("bad repeat")?; for _ in 0..3 + b.get(2)? { lens.push(p); } }
                            17 => { for _ in 0..3 + b.get(3)? { lens.push(0); } }
                            _ => { for _ in 0..11 + b.get(7)? { lens.push(0); } }
                        }
                    }
                    (Huff::new(&lens[..nlit]), Huff::new(&lens[nlit..nlit + ndist]))
                };
                loop {
                    let s = lh.decode(&mut b)? as usize;
                    if s < 256 { out.push(s as u8); continue; }
                    if s == 256 { break; }
                    let c = s - 257;
                    if c >= 29 { return Err("bad length code".into()); }
                    let len = LBASE[c] as usize + b.get(LEXT[c] as u32)? as usize;
                    let e = dh.decode(&mut b)? as usize;
                    if e >= 30 { return Err("bad distance code".into()); }
                    let dist = DBASE[e] as usize + b.get(DEXT[e] as u32)? as usize;
                    if dist > out.len() { return Err("bad distance".into()); }
                    let st = out.len() - dist;
                    for k in 0..len { let v = out[st + k]; out.push(v); }
                }
            }
            _ => return Err("bad block type".into()),
        }
        if last == 1 { break; }
    }
    Ok(out)
}
pub fn gzip(d: &[u8]) -> Vec<u8> {
    let mut o = vec![0x1f, 0x8b, 8, 0, 0, 0, 0, 0, 0, 0xff];
    o.extend(deflate(d));
    o.extend_from_slice(&crc32(d).to_le_bytes());
    o.extend_from_slice(&(d.len() as u32).to_le_bytes());
    o
}
pub fn gunzip(g: &[u8]) -> Result<Vec<u8>, String> {
    if g.len() < 18 || g[0] != 0x1f || g[1] != 0x8b || g[2] != 8 { return Err("not a gzip file".into()); }
    let flg = g[3];
    let mut p = 10;
    if flg & 4 != 0 { let x = g[p] as usize | (g[p + 1] as usize) << 8; p += 2 + x; }
    if flg & 8 != 0 { while g[p] != 0 { p += 1; } p += 1; }
    if flg & 16 != 0 { while g[p] != 0 { p += 1; } p += 1; }
    if flg & 2 != 0 { p += 2; }
    let d = inflate(&g[p..g.len() - 8])?;
    let crc = u32::from_le_bytes(g[g.len() - 8..g.len() - 4].try_into().unwrap());
    if crc32(&d) != crc { return Err("CRC mismatch (corrupt database)".into()); }
    Ok(d)
}

// ------------------------------------------------------------------ design state
/// timing snapshot: (scenario, wns, tns, whs, ths)
type Snap = Vec<(String, f64, f64, f64, f64)>;

impl Session {
    /// worst slacks per active scenario (each analysed alone), then all active scenarios together
    pub(crate) fn timing_snapshot(&mut self) -> Snap {
        if self.nl.is_none() || self.libs.is_empty() { return vec![]; }
        let act: Vec<bool> = self.scens.iter().map(|s| s.active).collect();
        let mut out = vec![];
        for i in (0..self.scens.len()).filter(|&i| act[i]) {
            for (j, s) in self.scens.iter_mut().enumerate() { s.active = j == i; }
            let name = self.scens[i].name.clone();
            if let Ok(q) = self.with_env(|nl, env| { let a = env.analyze(nl, 0); (a.wns, a.tns, a.whs, a.ths) }) { out.push((name, q.0, q.1, q.2, q.3)); }
        }
        for (s, a) in self.scens.iter_mut().zip(act.iter()) { s.active = *a; }
        if let Ok(q) = self.with_env(|nl, env| { let a = env.analyze(nl, 0); (a.wns, a.tns, a.whs, a.ths) }) { out.push(("(all active)".to_string(), q.0, q.1, q.2, q.3)); }
        out
    }

    fn db_image(&mut self, snap: &Snap) -> Vec<u8> {
        let mut w = W::default();
        w.b.extend_from_slice(MAGIC);
        FORMAT.put(&mut w);
        env!("CARGO_PKG_VERSION").to_string().put(&mut w);
        crate::metrics::now_stamp().put(&mut w);
        self.top.put(&mut w);
        snap.put(&mut w);
        // netlist & libraries
        self.nl.put(&mut w);
        self.golden.put(&mut w);
        self.libs.put(&mut w);
        self.lef.put(&mut w);
        self.lef_layers.put(&mut w);
        self.lef_sites.put(&mut w);
        // MMMC / timing
        self.modes.put(&mut w);
        self.corners.put(&mut w);
        self.scens.put(&mut w);
        self.cur_mode.put(&mut w);
        self.cur_corner.put(&mut w);
        self.ocv.put(&mut w);
        self.ann_delays.put(&mut w);
        self.analysis_type.put(&mut w);
        // extraction
        self.routed_rc.put(&mut w);
        self.spef_rc.put(&mut w);
        self.spef_stats.put(&mut w);
        // physical
        self.fp.put(&mut w);
        self.routes.put(&mut w);
        self.pgx.put(&mut w);
        self.ctspec.put(&mut w);
        self.cts_nets.put(&mut w);
        self.rt.put(&mut w);
        self.upf.put(&mut w);
        self.dft.put(&mut w);
        // settings / history
        self.app.put(&mut w);
        self.dont_use.put(&mut w);
        self.dont_use_cmds.put(&mut w);
        self.stages_done.put(&mut w);
        self.activity.put(&mut w);
        self.user_props.put(&mut w);
        self.user_prop_defaults.put(&mut w);
        self.eco_changes.put(&mut w);
        self.route_edits.put(&mut w);
        self.cg_exclude.put(&mut w);
        self.latches.put(&mut w);
        self.uniquified.put(&mut w);
        w.b
    }

    fn db_load(&mut self, b: &[u8]) -> Result<(String, String, Snap), String> {
        if b.len() < 8 || &b[..8] != MAGIC { return Err("not an RSynth design database (RSYNTHDB magic missing)".into()); }
        let mut r = Rd { b, p: 8 };
        let fmt = u32::get(&mut r)?;
        if fmt != FORMAT { return Err(format!("database format {} (this RSynth reads format {})", fmt, FORMAT)); }
        let ver = String::get(&mut r)?;
        let when = String::get(&mut r)?;
        if ver != env!("CARGO_PKG_VERSION") {
            return Err(format!("database written by RSynth {} (this is {}): the binary image is release-specific; restore it with RSynth {}", ver, env!("CARGO_PKG_VERSION"), ver));
        }
        let top = Option::<String>::get(&mut r)?;
        let snap = Snap::get(&mut r)?;
        // decode everything first: a bad database leaves the session untouched
        let nl = Odb::get(&mut r)?;
        let golden = Odb::get(&mut r)?;
        let libs = Odb::get(&mut r)?;
        let lef = Odb::get(&mut r)?;
        let lef_layers = Odb::get(&mut r)?;
        let lef_sites = Odb::get(&mut r)?;
        let modes = Odb::get(&mut r)?;
        let corners = Odb::get(&mut r)?;
        let scens = Odb::get(&mut r)?;
        let cur_mode = Odb::get(&mut r)?;
        let cur_corner = Odb::get(&mut r)?;
        let ocv = Odb::get(&mut r)?;
        let ann_delays = Odb::get(&mut r)?;
        let analysis_type = Odb::get(&mut r)?;
        let routed_rc = Odb::get(&mut r)?;
        let spef_rc = Odb::get(&mut r)?;
        let spef_stats = Odb::get(&mut r)?;
        let fp = Odb::get(&mut r)?;
        let routes = Odb::get(&mut r)?;
        let pgx = Odb::get(&mut r)?;
        let ctspec = Odb::get(&mut r)?;
        let cts_nets = Odb::get(&mut r)?;
        let rt = Odb::get(&mut r)?;
        let upf = Odb::get(&mut r)?;
        let dft = Odb::get(&mut r)?;
        let app = Odb::get(&mut r)?;
        let dont_use = Odb::get(&mut r)?;
        let dont_use_cmds = Odb::get(&mut r)?;
        let stages_done = Odb::get(&mut r)?;
        let activity = Odb::get(&mut r)?;
        let user_props = Odb::get(&mut r)?;
        let user_prop_defaults = Odb::get(&mut r)?;
        let eco_changes = Odb::get(&mut r)?;
        let route_edits = Odb::get(&mut r)?;
        let cg_exclude = Odb::get(&mut r)?;
        let latches = Odb::get(&mut r)?;
        let uniquified = Odb::get(&mut r)?;
        if r.p != b.len() { return Err(format!("database has {} trailing byte(s)", b.len() - r.p)); }
        self.top = top; self.nl = nl; self.golden = golden; self.libs = libs; self.lef = lef; self.lef_layers = lef_layers; self.lef_sites = lef_sites;
        self.modes = modes; self.corners = corners; self.scens = scens; self.cur_mode = cur_mode; self.cur_corner = cur_corner; self.ocv = ocv; self.ann_delays = ann_delays; self.analysis_type = analysis_type;
        self.routed_rc = routed_rc; self.spef_rc = spef_rc; self.spef_stats = spef_stats;
        self.fp = fp; self.routes = routes; self.pgx = pgx; self.ctspec = ctspec; self.cts_nets = cts_nets; self.rt = rt; self.upf = upf; self.dft = dft;
        self.app = app; self.dont_use = dont_use; self.dont_use_cmds = dont_use_cmds; self.stages_done = stages_done; self.activity = activity; self.user_props = user_props; self.user_prop_defaults = user_prop_defaults;
        self.eco_changes = eco_changes; self.route_edits = route_edits; self.cg_exclude = cg_exclude; self.latches = latches; self.uniquified = uniquified;
        // derived caches
        self.epoch.set(self.epoch.get() + 1);
        self.gr_cache.replace(None);
        self.prop_scen.set(None);
        Ok((ver, when, snap))
    }

    pub(crate) fn odb_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            // save the design database (gzip): netlist, libraries, LEF, MMMC modes / corners / scenarios with constraints, extraction, floorplan, routing, settings and a timing snapshot
            "save_db" | "write_db" | "saveDesign" | "save_design" | "write_design_db" => {
                let x = args(a, &[]);
                let Some(f) = x.pos.first().cloned() else { return Some(err(format!("{}: {} <design.odb>", name, name))) };
                let f = if f.contains('.') { f } else { format!("{}.odb", f) };
                if self.nl.is_none() { return Some(err(format!("{}: no design loaded (DB-001)", name))); }
                let t0 = std::time::Instant::now();
                let snap = if x.has("-no_timing_snapshot") { vec![] } else { self.timing_snapshot() };
                let img = self.db_image(&snap);
                let gz = gzip(&img);
                if let Err(e) = std::fs::write(&f, &gz) { return Some(err(format!("{}: cannot write '{}': {} (DB-002)", name, f, e))); }
                let nl = self.nl.as_ref().unwrap();
                crate::info!("DB-100", "Saved design '{}' to '{}': {} cell(s), {} net(s), {} lib(s), {} mode(s), {} corner(s), {} scenario(s){}{}{}; {:.1} MB -> {:.2} MB gzip ({:.1}x) in {:.2}s",
                    nl.name, f, nl.cell_ids().len(), nl.net_ids().len(), self.libs.len(), self.modes.len(), self.corners.len(), self.scens.len(),
                    if self.fp.is_some() { ", floorplan" } else { "" }, if self.routes.is_some() { ", routing" } else { "" },
                    if self.routed_rc.is_some() || !self.spef_rc.is_empty() { ", extraction" } else { "" },
                    img.len() as f64 / 1e6, gz.len() as f64 / 1e6, img.len() as f64 / gz.len().max(1) as f64, t0.elapsed().as_secs_f64());
                for (s, wns, tns, whs, ths) in &snap {
                    crate::info!("DB-101", "  timing saved  {:<16} WNS {:>9.4}  TNS {:>10.4}  WHS {:>9.4}  THS {:>10.4}", s, wns, tns, whs, ths);
                }
                Ok(f)
            }
            // restore a design database saved with save_db and check the restored timing against its snapshot
            "restore_db" | "read_design_db" | "restoreDesign" | "restore_design" | "open_db" => {
                let x = args(a, &[]);
                let Some(f) = x.pos.first().cloned() else { return Some(err(format!("{}: {} <design.odb>", name, name))) };
                let t0 = std::time::Instant::now();
                let gz = match std::fs::read(&f) { Ok(v) => v, Err(e) => return Some(err(format!("{}: cannot read '{}': {} (DB-003)", name, f, e))) };
                let img = match gunzip(&gz) { Ok(v) => v, Err(e) => return Some(err(format!("{}: '{}': {} (DB-004)", name, f, e))) };
                let (ver, when, snap) = match self.db_load(&img) { Ok(v) => v, Err(e) => return Some(err(format!("{}: '{}': {} (DB-005)", name, f, e))) };
                let nl = self.nl.as_ref().map(|n| (n.name.clone(), n.cell_ids().len(), n.net_ids().len())).unwrap_or_default();
                crate::info!("DB-110", "Restored design '{}' from '{}' (RSynth {}, saved {}): {} cell(s), {} net(s), {} lib(s), {} mode(s), {} corner(s), {} scenario(s){}{}{} in {:.2}s",
                    nl.0, f, ver, when, nl.1, nl.2, self.libs.len(), self.modes.len(), self.corners.len(), self.scens.len(),
                    if self.fp.is_some() { ", floorplan" } else { "" }, if self.routes.is_some() { ", routing" } else { "" },
                    if self.routed_rc.is_some() || !self.spef_rc.is_empty() { ", extraction" } else { "" }, t0.elapsed().as_secs_f64());
                if !snap.is_empty() && !x.has("-no_timing_check") {
                    let now = self.timing_snapshot();
                    let mut bad = 0;
                    for (s, wns, tns, whs, ths) in &snap {
                        match now.iter().find(|q| &q.0 == s) {
                            Some(q) => {
                                let ok = (q.1 - wns).abs() < 1e-6 && (q.2 - tns).abs() < 1e-5 && (q.3 - whs).abs() < 1e-6 && (q.4 - ths).abs() < 1e-5;
                                if !ok { bad += 1; }
                                crate::info!("DB-111", "  timing {:<8} {:<16} WNS {:>9.4}  TNS {:>10.4}  WHS {:>9.4}  THS {:>10.4}", if ok { "matches" } else { "DIFFERS" }, s, q.1, q.2, q.3, q.4);
                            }
                            None => { bad += 1; }
                        }
                    }
                    if bad == 0 { crate::info!("DB-112", "Restored timing matches the saved database in all {} scenario(s)", snap.len()); } else { crate::warn!("DB-113", "Restored timing differs from the saved database in {} scenario(s)", bad); }
                }
                Ok(nl.0)
            }
            // show the header of a design database file (format, release, date, top, saved timing)
            "report_db" | "report_design_db" => {
                let Some(f) = a.iter().find(|x| !x.starts_with('-')).cloned() else { return Some(err("report_db <design.odb>")) };
                let gz = match std::fs::read(&f) { Ok(v) => v, Err(e) => return Some(err(format!("report_db: '{}': {}", f, e))) };
                let img = match gunzip(&gz) { Ok(v) => v, Err(e) => return Some(err(format!("report_db: '{}': {}", f, e))) };
                if img.len() < 8 || &img[..8] != MAGIC { return Some(err("report_db: not an RSynth design database")); }
                let mut r = Rd { b: &img, p: 8 };
                let hdr = (|| -> Result<(u32, String, String, Option<String>, Snap), String> { Ok((u32::get(&mut r)?, String::get(&mut r)?, String::get(&mut r)?, Odb::get(&mut r)?, Odb::get(&mut r)?)) })();
                match hdr {
                    Ok((fmt, ver, when, top, snap)) => {
                        crate::out!("\n****************************************\nReport : design database {}\n****************************************", f);
                        crate::out!("  Format     : RSYNTHDB {} (gzip, {:.2} MB, {:.1} MB uncompressed, {:.1}x)", fmt, gz.len() as f64 / 1e6, img.len() as f64 / 1e6, img.len() as f64 / gz.len().max(1) as f64);
                        crate::out!("  Written by : RSynth {} on {}", ver, when);
                        crate::out!("  Top        : {}", top.unwrap_or_default());
                        for (s, wns, tns, whs, ths) in &snap { crate::out!("  Timing     : {:<16} WNS {:>9.4}  TNS {:>10.4}  WHS {:>9.4}  THS {:>10.4}", s, wns, tns, whs, ths); }
                        Ok(ver)
                    }
                    Err(e) => Err(crate::tcl::Flow::Err(format!("report_db: {}", e))),
                }
            }
            _ => return None,
        })
    }
}
