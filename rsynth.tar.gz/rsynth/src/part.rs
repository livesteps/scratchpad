//! Hierarchical partitioning, time budgeting and partition write-out.
//!  * create_partition / auto_partition (size-driven hierarchy selection, optional bounds)
//!  * boundary extraction (ports, directions, clock ports, feedthroughs from global route)
//!  * compute_budget_constraints: slack-proportional (or fixed-ratio) IO budgets per
//!    partition port from full-chip MMMC timing; report_budget / write_budgets
//!  * write_partitions: block netlists, block SDC (clocks + budgets), block DEF (bound as
//!    die, pins at boundary crossings), top netlist with partition instances, assemble script

use crate::cons::Obj;
use crate::fplan::*;
use crate::netlist::*;
use crate::session::{args, ok, Session};
use crate::sta::{Timing, NOCLK};
use crate::tcl::{err, split_list, Flow, R};
use std::collections::{BTreeMap, HashMap, HashSet};
use std::fmt::Write as _;

#[derive(Clone, Debug, Default)]
pub struct Partition {
    pub name: String,
    /// the (master) instance
    pub inst: String,
    pub bound: Option<String>,
    pub budgets: Vec<PortBudget>,
    /// MIM: every instance of the partition's module, master first (empty = single instance)
    pub instances: Vec<String>,
    /// MIM: region bound per instance (same order as `instances`)
    pub bounds: Vec<Option<String>>,
    /// MIM: placement orientation per instance (DEF names: N S E W FN FS FE FW)
    pub orients: Vec<String>,
    /// MIM: the instances were made identical to the master (commit_mim)
    pub committed: bool,
}
impl Partition {
    pub fn insts(&self) -> Vec<String> {
        if self.instances.is_empty() {
            vec![self.inst.clone()]
        } else {
            self.instances.clone()
        }
    }
    pub fn is_mim(&self) -> bool {
        self.instances.len() > 1
    }
    pub fn bound_of(&self, i: usize) -> Option<String> {
        if i == 0 {
            self.bound.clone().or(self.bounds.first().cloned().flatten())
        } else {
            self.bounds.get(i).cloned().flatten()
        }
    }
    pub fn orient_of(&self, i: usize) -> String {
        self.orients.get(i).cloned().unwrap_or("N".into())
    }
}

#[derive(Clone, Debug)]
pub struct PortBudget {
    pub port: String,
    pub input: bool,
    pub clock: Option<String>,
    pub ext: f64,
    pub int: f64,
    pub slack: f64,
    pub period: f64,
    pub delay: Option<f64>,
    pub is_clock: bool,
}

#[derive(Clone, Debug)]
pub struct BPort {
    pub name: String,
    pub net: NetId,
    pub input: bool,
    pub inside: Vec<PinRef>,
    pub outside: Vec<PinRef>,
    pub clock: bool,
    pub feed: bool,
}

pub fn sanitize(s: &str) -> String {
    let mut o: String = s.chars().map(|c| if c.is_ascii_alphanumeric() || c == '_' { c } else { '_' }).collect();
    while o.contains("__") {
        o = o.replace("__", "_");
    }
    let o = o.trim_matches('_').to_string();
    if o.is_empty() || o.chars().next().unwrap().is_ascii_digit() {
        format!("p_{}", o)
    } else {
        o
    }
}

fn in_part(name: &str, inst: &str) -> bool {
    name.starts_with(&format!("{}/", inst))
}

/// Extract the boundary of a partition. `feeds`: nets that route through the partition region.
pub fn boundary(nl: &Netlist, inst: &str, is_clock_pin: &dyn Fn(PinRef) -> bool, feeds: &HashSet<NetId>) -> Vec<BPort> {
    let mut v = vec![];
    let mut used = HashSet::new();
    let pfx = format!("{}/", inst);
    for n in nl.net_ids() {
        let conns = &nl.net(n).conns;
        let (mut ins, mut outs) = (vec![], vec![]);
        for pr in conns {
            let inside = matches!(pr, PinRef::Cell(c, _) if in_part(&nl.cell(*c).name, inst));
            if inside {
                ins.push(*pr)
            } else {
                outs.push(*pr)
            }
        }
        let feed = ins.is_empty() && feeds.contains(&n);
        if (ins.is_empty() || outs.is_empty()) && !feed {
            continue;
        }
        let drv_inside = nl.drivers(n).iter().any(|d| ins.contains(d));
        // a preserved boundary: one port per boundary pin, named after the module port, so
        // every instance of the module gets the same port list
        let hps: Vec<(PinRef, String)> = ins
            .iter()
            .filter_map(|pr| match pr {
                PinRef::Cell(c, _) => nl.hier_pin_of(*c).filter(|(i, _)| i == inst).map(|(_, p)| (*pr, p)),
                _ => None,
            })
            .collect();
        if !hps.is_empty() && !feed {
            for (pr, pn) in hps {
                let PinRef::Cell(hc, _) = pr else { continue };
                let input = nl.cell(hc).attrs.iter().any(|a| a.starts_with("hp:") && a.ends_with(":i"));
                // clock: a clock pin is reached through the boundary pin
                let inner = (0..nl.cell(hc).pins.len()).find_map(|k| if PinRef::Cell(hc, k) != pr { nl.cell(hc).pins[k].net } else { None });
                let clock = inner.map(|m| nl.net(m).conns.iter().any(|q| is_clock_pin(*q))).unwrap_or(false);
                let nm = sanitize(&pn);
                used.insert(nm.clone());
                v.push(BPort { name: nm, net: n, input, inside: vec![pr], outside: outs.clone(), clock, feed: false });
            }
            continue;
        }
        let clock = ins.iter().any(|p| is_clock_pin(*p));
        let raw = nl.net(n).name.strip_prefix(&pfx).unwrap_or(&nl.net(n).name).to_string();
        let mut nm = sanitize(&raw);
        let base = nm.clone();
        let mut k = 1;
        while !used.insert(nm.clone()) {
            nm = format!("{}_{}", base, k);
            k += 1;
        }
        v.push(BPort { name: nm, net: n, input: !drv_inside, inside: ins, outside: outs, clock, feed });
    }
    v.sort_by(|a, b| (!a.input, &a.name).cmp(&(!b.input, &b.name)));
    v
}

/// Budget one partition from a timing run (worst over calls is kept by the caller).
pub fn budget(t: &Timing, ports: &[BPort], mode: &str, ratio: f64, margin: f64) -> Vec<PortBudget> {
    let nl = t.nl;
    let mut out = vec![];
    for bp in ports {
        if bp.feed {
            continue;
        }
        // reference pins: inputs -> inside loads; outputs -> inside driver
        let refs: Vec<u32> = if bp.input {
            bp.inside.iter().filter(|p| nl.is_load(**p)).filter_map(|p| t.idx.get(p).copied()).collect()
        } else {
            bp.inside.iter().filter(|p| nl.is_driver(**p)).filter_map(|p| t.idx.get(p).copied()).collect()
        };
        let mut best: Option<(f64, f64, u16)> = None; // arrival, required, clk
        for n in refs {
            for tg in &t.tags[n as usize] {
                if tg.clk == NOCLK {
                    continue;
                }
                for rf in 0..2 {
                    let a = tg.at[rf];
                    let r = t.req[n as usize][rf];
                    if !a.is_finite() || !r.is_finite() {
                        continue;
                    }
                    if best.map(|b| r - a < b.1 - b.0).unwrap_or(true) {
                        best = Some((a, r, tg.clk));
                    }
                }
            }
        }
        let Some((a, r, clk)) = best else {
            out.push(PortBudget { port: bp.name.clone(), input: bp.input, clock: None, ext: 0.0, int: 0.0, slack: f64::INFINITY, period: 0.0, delay: None, is_clock: bp.clock });
            continue;
        };
        let per = t.clk_period[clk as usize];
        let (r0, _) = t.clk_edges[clk as usize];
        let a = a - r0;
        let r = r - r0;
        let s = r - a;
        // input: ext = path before the boundary, int = path after; output: the reverse
        let (ext, int) = if bp.input { (a.max(0.0), (per - r).max(0.0)) } else { ((per - r).max(0.0), a.max(0.0)) };
        let avail = per * (1.0 - margin);
        let d = match mode {
            "fixed_ratio" => avail * ratio,
            _ => {
                if ext + int > 1e-9 {
                    avail * ext / (ext + int)
                } else {
                    avail * ratio
                }
            }
        };
        out.push(PortBudget { port: bp.name.clone(), input: bp.input, clock: Some(t.cons.clocks[clk as usize].name.clone()), ext, int, slack: s, period: per, delay: Some(d), is_clock: bp.clock });
    }
    out
}

impl Session {
    fn part_feeds(&self, p: &Partition) -> HashSet<NetId> {
        let mut s = HashSet::new();
        if let Some(g) = self.fp.as_ref().and_then(|f| f.groute.as_ref()) {
            let nl = self.nl.as_ref().unwrap();
            let region = p.bound.clone().unwrap_or_default();
            for (n, r) in &g.feed_used {
                if *r == p.name || *r == region {
                    if let Some(id) = nl.net_by_name(n) {
                        s.insert(id);
                    }
                }
            }
        }
        s
    }
    fn clock_pin_fn(&self) -> impl Fn(PinRef) -> bool + '_ {
        let nl = self.nl.as_ref().unwrap();
        move |p: PinRef| match p {
            PinRef::Cell(c, i) => {
                let cell = nl.cell(c);
                match &cell.kind {
                    Kind::Lib(l) => self.libs.iter().find_map(|x| x.cells.get(l)).and_then(|lc| lc.pin(&cell.pins[i].name)).map(|lp| lp.is_clock || lp.cg_role.as_deref() == Some("clock")).unwrap_or(false),
                    Kind::Gen(GOp::Dff) => cell.pins[i].name == "CK",
                    _ => false,
                }
            }
            _ => false,
        }
    }
    fn part_ports(&self, p: &Partition) -> Vec<BPort> {
        self.part_ports_of(p, &p.inst)
    }
    pub(crate) fn part_ports_of(&self, p: &Partition, inst: &str) -> Vec<BPort> {
        let nl = self.nl.as_ref().unwrap();
        let feeds = if inst == p.inst { self.part_feeds(p) } else { HashSet::new() };
        let f = self.clock_pin_fn();
        boundary(nl, inst, &f, &feeds)
    }

    pub fn part_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "create_partition" | "create_physical_hierarchy" => {
                let x = args(a, &["-name", "-bound", "-bounds", "-orientations", "-instances"]);
                // one hierarchical instance, or several instances of one module (MIM)
                let mut insts: Vec<String> = vec![];
                for p in x.pos.iter().chain(x.get("-instances")) {
                    let objs = self.objs(p, "cell");
                    if objs.is_empty() {
                        insts.extend(split_list(p).into_iter().map(|s| Obj::parse(&s).map(|o| o.name().to_string()).unwrap_or(s)));
                    } else {
                        insts.extend(objs.into_iter().map(|o| o.name().to_string()));
                    }
                }
                insts.dedup();
                let Some(inst) = insts.first().cloned() else { return Some(err("create_partition: hierarchical instance required")) };
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                let mut n_cells = 0;
                for i in &insts {
                    let n = nl.cell_ids().iter().filter(|c| in_part(&nl.cell(**c).name, i)).count();
                    if n == 0 {
                        return Some(err(format!("create_partition: no cells under hierarchy '{}' (PART-002)", i)));
                    }
                    if i == &inst {
                        n_cells = n;
                    }
                    if self.partitions.iter().any(|p| p.insts().iter().any(|q| in_part(i, q) || in_part(q, i) || q == i)) {
                        return Some(err(format!("create_partition: '{}' overlaps an existing partition (nested partitions are not supported) (PART-003)", i)));
                    }
                }
                for (k, i) in insts.iter().enumerate() {
                    if insts.iter().skip(k + 1).any(|q| in_part(i, q) || in_part(q, i)) {
                        return Some(err(format!("create_partition: instances '{}' are nested (PART-003)", i)));
                    }
                }
                let pname = sanitize(&x.get("-name").cloned().unwrap_or(if insts.len() > 1 { nl.hier.iter().find(|h| h.0 == inst).map(|h| h.1.clone()).unwrap_or(inst.clone()) } else { inst.clone() }));
                let mut part = Partition { name: pname.clone(), inst: inst.clone(), bound: x.get("-bound").cloned(), ..Default::default() };
                if insts.len() > 1 {
                    // MIM: same module, preserved boundaries, same boundary pins
                    let module = |i: &str| nl.hier.iter().find(|h| h.0 == i).map(|h| h.1.clone());
                    let m0 = module(&inst);
                    let hp_ports = |i: &str| -> Vec<String> {
                        let mut v: Vec<String> = nl.cell_ids().into_iter().filter_map(|c| nl.hier_pin_of(c)).filter(|(h, _)| h == i).map(|(_, p)| p).collect();
                        v.sort();
                        v.dedup();
                        v
                    };
                    let p0 = hp_ports(&inst);
                    // same module AND same parameters: the instances must form one group of the
                    // elaborated non-uniquified module instances
                    let grp = self.multi_inst.iter().find(|(_, v)| v.contains(&inst));
                    for i in &insts {
                        match grp {
                            Some((sig, v)) if v.contains(i) => {
                                let _ = sig;
                            }
                            _ => {
                                let si = self.multi_inst.iter().find(|(_, v)| v.contains(i)).map(|g| g.0.clone());
                                let msg = match grp {
                                    None => format!("'{}' (module {}) has parameter values no other instance shares", inst, m0.clone().unwrap_or("?".into())),
                                    Some(g) => format!("'{}' ({}) is not an instance of '{}'", i, si.unwrap_or(format!("{} with other parameters", module(i).unwrap_or("?".into()))), g.0),
                                };
                                return Some(err(format!("create_partition: {}: a multiply instantiated partition needs instances of one module with identical parameters (MIM-001)", msg)));
                            }
                        }
                    }
                    for i in &insts {
                        if module(i) != m0 || m0.is_none() {
                            return Some(err(format!("create_partition: '{}' is an instance of '{}', '{}' of '{}': a multiply instantiated partition needs instances of one module (MIM-001)", i, module(i).unwrap_or("?".into()), inst, m0.clone().unwrap_or("?".into()))));
                        }
                        let pi = hp_ports(i);
                        if pi.is_empty() {
                            return Some(err(format!("create_partition: '{}' has no preserved boundary: run set_boundary_optimization {{{}}} false before compile so every instance keeps the module's ports (MIM-002)", i, insts.join(" "))));
                        }
                        if pi != p0 {
                            return Some(err(format!("create_partition: boundary pins of '{}' differ from '{}' ({} vs {}) (MIM-003)", i, inst, pi.len(), p0.len())));
                        }
                    }
                    part.instances = insts.clone();
                    part.bounds = match x.get("-bounds") {
                        Some(b) => {
                            let v: Vec<String> = split_list(b);
                            if v.len() != insts.len() {
                                return Some(err(format!("create_partition: -bounds needs one bound per instance ({} given, {} instances) (MIM-004)", v.len(), insts.len())));
                            }
                            v.into_iter().map(Some).collect()
                        }
                        None => insts.iter().enumerate().map(|(k, _)| if k == 0 { x.get("-bound").cloned() } else { None }).collect(),
                    };
                    part.orients = match x.get("-orientations") {
                        Some(o) => {
                            let v: Vec<String> = split_list(o).into_iter().map(|s| s.to_uppercase()).collect();
                            if v.len() != insts.len() || v.iter().any(|o| !["N", "S", "E", "W", "FN", "FS", "FE", "FW"].contains(&o.as_str())) {
                                return Some(err("create_partition: -orientations needs one of N S E W FN FS FE FW per instance (MIM-005)"));
                            }
                            if v[0] != "N" {
                                return Some(err("create_partition: the master (first) instance must have orientation N (MIM-006)"));
                            }
                            v
                        }
                        None => vec!["N".into(); insts.len()],
                    };
                    // equal-size regions (rotated by E/W/FE/FW)
                    if let Some(fp) = &self.fp {
                        let rect = |b: &Option<String>| b.as_ref().and_then(|n| fp.bounds.iter().find(|q| &q.name == n)).and_then(|q| q.resolved.or(q.rect));
                        let r0 = rect(&part.bounds[0]);
                        for (k, b) in part.bounds.iter().enumerate() {
                            if let Some(n) = b {
                                if !fp.bounds.iter().any(|q| &q.name == n) {
                                    return Some(err(format!("create_partition: bound '{}' does not exist (MIM-007)", n)));
                                }
                            }
                            if let (Some(a0), Some(ak)) = (r0, rect(b)) {
                                let (w0, h0) = (a0.2 - a0.0, a0.3 - a0.1);
                                let (wk, hk) = (ak.2 - ak.0, ak.3 - ak.1);
                                let rot = matches!(part.orients[k].as_str(), "E" | "W" | "FE" | "FW");
                                let (ew, eh) = if rot { (h0, w0) } else { (w0, h0) };
                                if (ew - wk).abs() > 1e-6 || (eh - hk).abs() > 1e-6 {
                                    return Some(err(format!("create_partition: region of '{}' is {:.2} x {:.2}, the master's is {:.2} x {:.2}{} (MIM-008)", insts[k], wk, hk, w0, h0, if rot { " (rotated)" } else { "" })));
                                }
                            }
                        }
                    }
                    crate::info!("MIM-100", "Multiply instantiated partition '{}' (module {}): {} instances, master {} ({} cells), orientations {}", pname, m0.unwrap_or_default(), insts.len(), inst, n_cells, part.orients.join(" "));
                } else {
                    if let Some(b) = x.get("-bound") {
                        if !self.fp.as_ref().map(|f| f.bounds.iter().any(|q| &q.name == b)).unwrap_or(false) {
                            crate::warn!("PART-004", "Bound '{}' not found; partition created without a physical region", b);
                        }
                    }
                    crate::info!("PART-100", "Partition '{}' -> hierarchy '{}' ({} cells){}", pname, inst, n_cells, x.get("-bound").map(|b| format!(", region bound '{}'", b)).unwrap_or_default());
                }
                self.partitions.push(part);
                Ok(pname)
            }
            "auto_partition" => {
                let x = args(a, &["-max_cells", "-min_cells", "-utilization"]);
                let maxc = x.num("-max_cells").unwrap_or(1e9) as usize;
                let minc = x.num("-min_cells").unwrap_or(50.0) as usize;
                let util = x.num("-utilization").unwrap_or(0.5);
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                let mut sizes: BTreeMap<String, (usize, f64)> = BTreeMap::new();
                for (inst, _) in &nl.hier {
                    sizes.insert(inst.clone(), (0, 0.0));
                }
                for c in nl.cell_ids() {
                    let cell = nl.cell(c);
                    let ar = cell.lib().and_then(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|x| x.area).unwrap_or(1.0);
                    for (inst, v) in sizes.iter_mut() {
                        if in_part(&cell.name, inst) {
                            v.0 += 1;
                            v.1 += ar;
                        }
                    }
                }
                // top-down: take the largest instances that fit, never nesting
                let mut cands: Vec<(String, usize, f64)> = sizes.into_iter().filter(|(_, v)| v.0 >= minc && v.0 <= maxc).map(|(k, v)| (k, v.0, v.1)).collect();
                cands.sort_by(|a, b| a.0.matches('/').count().cmp(&b.0.matches('/').count()).then(b.1.cmp(&a.1)));
                let mut chosen: Vec<(String, usize, f64)> = vec![];
                for c in cands {
                    if chosen.iter().any(|p| in_part(&c.0, &p.0) || in_part(&p.0, &c.0)) || self.partitions.iter().any(|p| p.insts().iter().any(|q| in_part(&c.0, q) || in_part(q, &c.0) || *q == c.0)) {
                        continue;
                    }
                    chosen.push(c);
                }
                let create_bounds = x.has("-create_bounds");
                let die = self.fp.as_ref().map(|f| f.die);
                let mut cursor = (die.map(|d| d.0).unwrap_or(0.0) + 2.0, die.map(|d| d.1).unwrap_or(0.0) + 2.0, 0.0f64);
                let mut made = vec![];
                for (inst, n, ar) in chosen {
                    let pname = sanitize(&inst);
                    let mut bname = None;
                    if create_bounds {
                        if let Some(d) = die {
                            let side = (ar / util).sqrt().max(4.0);
                            if cursor.0 + side > d.2 - 2.0 {
                                cursor = (d.0 + 2.0, cursor.1 + cursor.2 + 2.0, 0.0);
                            }
                            let r = (cursor.0, cursor.1, (cursor.0 + side).min(d.2), (cursor.1 + side).min(d.3));
                            cursor.0 += side + 2.0;
                            cursor.2 = cursor.2.max(side);
                            let bn = format!("{}_region", pname);
                            if let Some(fp) = self.fp.as_mut() {
                                fp.bounds.retain(|b| b.name != bn);
                                fp.bounds.push(Bound { name: bn.clone(), kind: BoundKind::Exclusive, rect: Some(r), dims: None, members: vec![inst.clone()], source: "user".into(), resolved: Some(r) });
                            }
                            bname = Some(bn);
                        }
                    }
                    crate::info!("PART-110", "auto_partition: '{}' <- '{}' ({} cells, area {:.1}){}", pname, inst, n, ar, bname.as_ref().map(|b| format!(", exclusive region '{}'", b)).unwrap_or_default());
                    self.partitions.push(Partition { name: pname.clone(), inst, bound: bname, ..Default::default() });
                    made.push(pname);
                }
                if made.is_empty() {
                    crate::warn!("PART-111", "auto_partition: no hierarchy between {} and {} cells", minc, maxc);
                }
                Ok(crate::tcl::to_list(&made))
            }
            "remove_partitions" => {
                let all = a.iter().any(|x| x == "-all") || a.is_empty();
                let ns: Vec<String> = a.iter().filter(|x| !x.starts_with('-')).flat_map(|x| split_list(x)).collect();
                let b = self.partitions.len();
                self.partitions.retain(|p| !(all || ns.iter().any(|n| glob(n, &p.name))));
                Ok((b - self.partitions.len()).to_string())
            }
            "report_partitions" => {
                if self.partitions.is_empty() {
                    crate::out!("No partitions.");
                    return Some(ok());
                }
                let nl = match self.nl() {
                    Ok(n) => n,
                    Err(e) => return Some(Err(e)),
                };
                crate::out!("\n{:<18} {:<26} {:>7} {:>10} {:>6} {:>6} {:>6} {:>5}  {}", "Partition", "Hierarchy", "Cells", "Area", "In", "Out", "Clock", "Feed", "Region");
                for p in &self.partitions {
                    let cells: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| in_part(&nl.cell(*c).name, &p.inst)).collect();
                    let ar: f64 = cells.iter().filter_map(|c| nl.cell(*c).lib()).filter_map(|l| self.libs.iter().find_map(|x| x.cells.get(l))).map(|c| c.area).sum();
                    let ports = self.part_ports(p);
                    crate::out!("{:<18} {:<26} {:>7} {:>10.2} {:>6} {:>6} {:>6} {:>5}  {}", p.name, p.inst, cells.len(), ar, ports.iter().filter(|x| x.input && !x.feed).count(), ports.iter().filter(|x| !x.input && !x.feed).count(), ports.iter().filter(|x| x.clock).count(), ports.iter().filter(|x| x.feed).count(), p.bound.clone().unwrap_or("-".into()));
                }
                ok()
            }
            "set_budget_options" => {
                let x = args(a, &["-mode", "-ratio", "-margin"]);
                if let Some(m) = x.get("-mode") {
                    self.app.insert("budget.mode".into(), m.clone());
                }
                if let Some(r) = x.get("-ratio") {
                    self.app.insert("budget.ratio".into(), r.clone());
                }
                if let Some(m) = x.get("-margin") {
                    self.app.insert("budget.margin".into(), m.clone());
                }
                ok()
            }
            "compute_budget_constraints" | "allocate_budgets" | "budget_partitions" => {
                if self.partitions.is_empty() {
                    return Some(err("No partitions (create_partition / auto_partition) (PART-001)"));
                }
                let mode = self.app.get("budget.mode").cloned().unwrap_or("proportional".into());
                let ratio = self.appf("budget.ratio");
                let margin = self.appf("budget.margin");
                let scen = self.active("setup");
                let mut parts = self.partitions.clone();
                for p in parts.iter_mut() {
                    let mut worst: HashMap<String, PortBudget> = HashMap::new();
                    // a MIM block must meet the budget of its tightest context: per port the
                    // budget from the worst instance and scenario is kept
                    let mut from_inst: HashMap<String, String> = HashMap::new();
                    for inst in p.insts() {
                        let ports = self.part_ports_of(p, &inst);
                        for &si in &scen {
                            let bs = match self.with_timing(si, |t| budget(t, &ports, &mode, ratio, margin)) {
                                Ok(b) => b,
                                Err(e) => return Some(Err(e)),
                            };
                            for b in bs {
                                let tighter = match worst.get(&b.port) {
                                    None => true,
                                    Some(w) => match (b.delay, w.delay) {
                                        (Some(d), Some(e)) => d > e + 1e-12 || ((d - e).abs() <= 1e-12 && b.slack < w.slack),
                                        (Some(_), None) => true,
                                        (None, Some(_)) => false,
                                        (None, None) => b.slack < w.slack,
                                    },
                                };
                                if tighter {
                                    from_inst.insert(b.port.clone(), inst.clone());
                                    worst.insert(b.port.clone(), b);
                                }
                            }
                        }
                    }
                    if p.is_mim() {
                        let mut per: BTreeMap<String, usize> = BTreeMap::new();
                        for i in from_inst.values() {
                            *per.entry(i.clone()).or_insert(0) += 1;
                        }
                        crate::info!("MIM-300", "Partition '{}': merged worst-case budgets of {} instances (ports set by {})", p.name, p.insts().len(), per.iter().map(|(i, n)| format!("{}: {}", i, n)).collect::<Vec<_>>().join(", "));
                    }
                    let mut v: Vec<PortBudget> = worst.into_values().collect();
                    v.sort_by(|a, b| (!a.input, &a.port).cmp(&(!b.input, &b.port)));
                    let n = v.iter().filter(|b| b.delay.is_some()).count();
                    let neg = v.iter().filter(|b| b.slack < 0.0).count();
                    crate::info!("BUD-100", "Budgeted partition '{}': {} constrained port(s) ({} on negative-slack paths), mode {}, margin {:.0}%", p.name, n, neg, mode, margin * 100.0);
                    p.budgets = v;
                }
                self.partitions = parts;
                ok()
            }
            "report_budget" | "report_budgets" => {
                let x = args(a, &["-partition", "-partitions"]);
                let sel = x.get("-partition").or(x.get("-partitions")).map(|s| split_list(s));
                for p in &self.partitions {
                    if sel.as_ref().map(|s| !s.contains(&p.name)).unwrap_or(false) {
                        continue;
                    }
                    crate::out!("\nBudget for partition '{}' ({})", p.name, p.inst);
                    crate::out!("  {:<30} {:<4} {:<6} {:>8} {:>8} {:>8} {:>8} {:>9}", "Port", "Dir", "Clock", "Period", "Ext", "Int", "Slack", "Budget");
                    for b in &p.budgets {
                        crate::out!("  {:<30} {:<4} {:<6} {:>8.3} {:>8.3} {:>8.3} {:>8} {:>9}", b.port, if b.input { "in" } else { "out" }, b.clock.clone().unwrap_or("-".into()), b.period, b.ext, b.int, if b.slack.is_finite() { format!("{:.3}", b.slack) } else { "uncons".into() }, b.delay.map(|d| format!("{:.3}", d)).unwrap_or(if b.is_clock { "clock".into() } else { "-".into() }));
                    }
                    if p.budgets.is_empty() {
                        crate::out!("  (no budgets: run compute_budget_constraints)");
                    }
                }
                ok()
            }
            "write_budgets" => {
                let x = args(a, &["-output", "-output_dir"]);
                let dir = x.get("-output").or(x.get("-output_dir")).cloned().unwrap_or("budgets".into());
                let _ = std::fs::create_dir_all(&dir);
                let mut files = vec![];
                for p in self.partitions.clone() {
                    let f = format!("{}/{}.budget.sdc", dir, p.name);
                    let s = self.block_sdc(&p);
                    if let Err(e) = std::fs::write(&f, s) {
                        return Some(err(e.to_string()));
                    }
                    files.push(f);
                }
                crate::info!("BUD-200", "Wrote {} budget SDC file(s) to '{}'", files.len(), dir);
                Ok(crate::tcl::to_list(&files))
            }
            "write_partitions" | "commit_partitions" | "split_partitions" => {
                let x = args(a, &["-output", "-output_dir", "-partitions"]);
                let dir = x.get("-output").or(x.get("-output_dir")).cloned().unwrap_or("partitions".into());
                match self.write_parts(&dir) {
                    Ok(f) => Ok(f),
                    Err(e) => Err(e),
                }
            }
            _ => return None,
        })
    }

    fn block_sdc(&self, p: &Partition) -> String {
        let mut s = String::new();
        let _ = writeln!(s, "# Block constraints for partition '{}' ({}) — generated by RSynth time budgeting", p.name, p.inst);
        let ports = self.part_ports(p);
        let cons = &self.modes[self.cur_mode].sdc;
        // clocks on clock ports: name follows the top-level clock that reaches the port
        let mut clocks_done = HashSet::new();
        let si = self.active("setup").first().copied().unwrap_or(0);
        let clk_of: HashMap<String, (String, f64, f64, f64)> = self
            .with_timing(si, |t| {
                let mut m = HashMap::new();
                for bp in ports.iter().filter(|b| b.clock) {
                    for pr in &bp.inside {
                        if let Some(&n) = t.idx.get(pr) {
                            if let Some(ct) = t.ctags[n as usize].first() {
                                let c = &t.cons.clocks[ct.clk as usize];
                                m.insert(bp.name.clone(), (c.name.clone(), t.clk_period[ct.clk as usize], t.clk_edges[ct.clk as usize].0, t.clk_edges[ct.clk as usize].1));
                            }
                        }
                    }
                }
                m
            })
            .unwrap_or_default();
        for (port, (cn, per, r, f)) in &clk_of {
            if clocks_done.insert(cn.clone()) {
                let _ = writeln!(s, "create_clock -name {} -period {:.4} -waveform {{{:.4} {:.4}}} [get_ports {}]", cn, per, r, f, port);
                if let Some(c) = cons.clocks.iter().find(|c| &c.name == cn) {
                    let _ = writeln!(s, "set_clock_uncertainty -setup {:.4} [get_clocks {}]", c.unc_setup, cn);
                    let _ = writeln!(s, "set_clock_uncertainty -hold {:.4} [get_clocks {}]", c.unc_hold, cn);
                    let _ = writeln!(s, "set_clock_transition {:.4} [get_clocks {}]", c.transition, cn);
                }
            }
        }
        // virtual clocks for budgets on clocks not entering the block
        let mut virt = HashSet::new();
        for b in &p.budgets {
            if let Some(c) = &b.clock {
                if !clocks_done.contains(c) && virt.insert(c.clone()) {
                    let _ = writeln!(s, "create_clock -name {} -period {:.4}   ;# virtual (clock does not enter the partition)", c, b.period);
                }
            }
        }
        for b in &p.budgets {
            match (b.delay, &b.clock) {
                (Some(d), Some(c)) => {
                    let _ = writeln!(s, "set_{}_delay {:.4} -clock {} [get_ports {}]   ;# ext {:.3} int {:.3} slack {:.3}", if b.input { "input" } else { "output" }, d, c, b.port, b.ext, b.int, b.slack);
                }
                _ if b.is_clock => {}
                _ => {
                    let _ = writeln!(s, "# {} {}: unconstrained at top level", if b.input { "input" } else { "output" }, b.port);
                }
            }
        }
        if p.budgets.is_empty() {
            let _ = writeln!(s, "# WARNING: no budgets computed (run compute_budget_constraints)");
        }
        if let Some(v) = cons.max_tran {
            let _ = writeln!(s, "set_max_transition {:.4} [current_design]", v);
        }
        if let Some(v) = cons.max_fanout {
            let _ = writeln!(s, "set_max_fanout {} [current_design]", v);
        }
        if let Some(v) = cons.max_cap {
            let _ = writeln!(s, "set_max_capacitance {:.4} [current_design]", v);
        }
        for bp in ports.iter().filter(|b| b.feed) {
            let _ = writeln!(s, "# feedthrough {} : {}_in -> {}_out", nl_name(self, bp.net), bp.name, bp.name);
        }
        s
    }

    fn write_parts(&mut self, dir: &str) -> R {
        if self.partitions.is_empty() {
            return err("No partitions (PART-001)");
        }
        let nl = self.nl()?.clone();
        std::fs::create_dir_all(dir).map_err(|e| Flow::Err(e.to_string()))?;
        let mut files = vec![];
        // ---- top netlist skeleton: copy everything not inside a partition
        let mut top = Netlist::new(&nl.name);
        let mut tnet: HashMap<NetId, NetId> = HashMap::new();
        for p in nl.port_ids() {
            let pid = top.add_port(&nl.ports[p].name, nl.ports[p].dir);
            if let Some(n) = nl.ports[p].net {
                let tn = top.ports[pid].net.unwrap();
                if let Some(&prev) = tnet.get(&n) {
                    top.merge_net(prev, tn);
                } else {
                    tnet.insert(n, tn);
                }
            }
        }
        let get_t = |top: &mut Netlist, tnet: &mut HashMap<NetId, NetId>, n: NetId| -> NetId {
            if let Some(&x) = tnet.get(&n) {
                return x;
            }
            let x = top.add_net(&nl.net(n).name);
            tnet.insert(n, x);
            x
        };
        let parts = self.partitions.clone();
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            if parts.iter().any(|p| p.insts().iter().any(|i| in_part(&cell.name, i))) {
                continue;
            }
            let pins: Vec<(&str, Dir)> = cell.pins.iter().map(|p| (p.name.as_str(), p.dir)).collect();
            let k = top.add_cell(&cell.name, cell.kind.clone(), &pins);
            top.cell_mut(k).attrs = cell.attrs.clone();
            top.cell_mut(k).loc = cell.loc;
            top.cell_mut(k).fixed = cell.fixed;
            for (i, p) in cell.pins.iter().enumerate() {
                if let Some(n) = p.net {
                    let tn = get_t(&mut top, &mut tnet, n);
                    top.connect(k, i, tn);
                }
            }
        }
        let mut assemble = String::new();
        let _ = writeln!(assemble, "# Re-assemble and verify the partitioned design.\n# 1) read_lib <same libraries>  2) optionally analyze + elaborate the RTL as reference\n# 3) source this file (paths relative to this directory)");
        let mut vfiles = vec![];
        for p in &parts {
            let ports = self.part_ports(p);
            let modname = sanitize(&p.name);
            let mut blk = Netlist::new(&modname);
            let mut bnet: HashMap<NetId, NetId> = HashMap::new();
            let pfx = format!("{}/", p.inst);
            let mut bb_pins: Vec<(String, Dir, NetId)> = vec![];
            for bp in &ports {
                if bp.feed {
                    let pi = blk.add_port(&format!("{}_in", bp.name), Dir::In);
                    let po = blk.add_port(&format!("{}_out", bp.name), Dir::Out);
                    let (ni, no) = (blk.ports[pi].net.unwrap(), blk.ports[po].net.unwrap());
                    blk.merge_net(ni, no);
                    // top: driver side -> _in ; new net from _out -> all loads
                    let tn = get_t(&mut top, &mut tnet, bp.net);
                    let loads: Vec<PinRef> = top.loads(tn);
                    let nn = top.add_net(&format!("{}_ft", top.net(tn).name.clone()));
                    for l in loads {
                        match l {
                            PinRef::Cell(c, i) => top.connect(c, i, nn),
                            PinRef::Port(q) => top.connect_port(q, nn),
                        }
                    }
                    bb_pins.push((format!("{}_in", bp.name), Dir::In, tn));
                    bb_pins.push((format!("{}_out", bp.name), Dir::Out, nn));
                    continue;
                }
                let pid = blk.add_port(&bp.name, if bp.input { Dir::In } else { Dir::Out });
                let pn = blk.ports[pid].net.unwrap();
                // a boundary pin of a preserved hierarchy: the block port is the inner net
                let hp_inner = match bp.inside.as_slice() {
                    [PinRef::Cell(hc, k)] if nl.cell(*hc).is_hport() => (0..nl.cell(*hc).pins.len()).find(|q| q != k).and_then(|q| nl.cell(*hc).pins[q].net),
                    _ => None,
                };
                match hp_inner {
                    Some(inner) => match bnet.get(&inner).copied() {
                        Some(prev) => blk.merge_net(prev, pn),
                        None => {
                            bnet.insert(inner, pn);
                        }
                    },
                    None => {
                        bnet.insert(bp.net, pn);
                    }
                }
                let tn = get_t(&mut top, &mut tnet, bp.net);
                bb_pins.push((bp.name.clone(), if bp.input { Dir::In } else { Dir::Out }, tn));
            }
            if p.is_mim() && ports.iter().any(|b| b.feed) {
                return err(format!("write_partitions: MIM partition '{}' has routing feedthroughs; feedthroughs are not supported for multiply instantiated blocks (MIM-009)", p.name));
            }
            for c in nl.cell_ids() {
                let cell = nl.cell(c);
                if !in_part(&cell.name, &p.inst) {
                    continue;
                }
                if nl.hier_pin_of(c).map(|(i, _)| i == p.inst).unwrap_or(false) {
                    continue; // boundary pin of the block itself: becomes the block port
                }
                let pins: Vec<(&str, Dir)> = cell.pins.iter().map(|q| (q.name.as_str(), q.dir)).collect();
                let k = blk.add_cell(cell.name.strip_prefix(&pfx).unwrap_or(&cell.name), cell.kind.clone(), &pins);
                blk.cell_mut(k).attrs = cell.attrs.clone();
                blk.cell_mut(k).loc = cell.loc;
                for (i, q) in cell.pins.iter().enumerate() {
                    if let Some(n) = q.net {
                        let bn = match bnet.get(&n) {
                            Some(x) => *x,
                            None => {
                                // constants are shared from the top: recreate locally
                                let nm = nl.net(n).name.strip_prefix(&pfx).unwrap_or(&nl.net(n).name).to_string();
                                let x = blk.add_net(&nm);
                                if let Some(v) = crate::genopt::const_of(&nl, n) {
                                    let z = crate::genopt::const_net(&mut blk, v);
                                    blk.merge_net(z, x);
                                    bnet.insert(n, z);
                                    z
                                } else {
                                    bnet.insert(n, x);
                                    x
                                }
                            }
                        };
                        blk.connect(k, i, bn);
                    }
                }
            }
            blk.mapped = nl.mapped;
            let vf = format!("{}/{}.v", dir, modname);
            crate::out::write_verilog(&blk, &vf, &|_| true).map_err(|e| Flow::Err(e.to_string()))?;
            files.push(vf.clone());
            vfiles.push(vf);
            // instance(s) in top: a MIM block is instantiated once per instance
            let mut tops: Vec<(String, Vec<(String, Dir, NetId)>)> = vec![(p.inst.clone(), bb_pins.clone())];
            for inst in p.insts().iter().skip(1) {
                let pk = self.part_ports_of(p, inst);
                let names: Vec<&str> = pk.iter().map(|b| b.name.as_str()).collect();
                let want: Vec<&str> = ports.iter().filter(|b| !b.feed).map(|b| b.name.as_str()).collect();
                if names != want {
                    return err(format!("write_partitions: boundary of '{}' differs from the master '{}' (MIM-010)", inst, p.inst));
                }
                let pins: Vec<(String, Dir, NetId)> = pk.iter().map(|b| (b.name.clone(), if b.input { Dir::In } else { Dir::Out }, get_t(&mut top, &mut tnet, b.net))).collect();
                tops.push((inst.clone(), pins));
            }
            for (k, (iname, pins)) in tops.iter().enumerate() {
                let pd: Vec<(&str, Dir)> = pins.iter().map(|(n, d, _)| (n.as_str(), *d)).collect();
                let ic = top.add_cell(iname, Kind::BlackBox(modname.clone()), &pd);
                for (i, (_, _, n)) in pins.iter().enumerate() {
                    top.connect(ic, i, *n);
                }
                top.cell_mut(ic).attrs.push("partition".into());
                if p.is_mim() {
                    top.cell_mut(ic).attrs.push(format!("orient:{}", p.orient_of(k)));
                    top.cell_mut(ic).attrs.push("mim".into());
                    if let (Some(fp), Some(bn)) = (&self.fp, p.bound_of(k)) {
                        if let Some(r) = fp.bounds.iter().find(|b| b.name == bn).and_then(|b| b.resolved.or(b.rect)) {
                            top.cell_mut(ic).loc = Some((r.0, r.1));
                            top.cell_mut(ic).fixed = true;
                        }
                    }
                }
            }
            // SDC (budgets)
            let sf = format!("{}/{}.sdc", dir, modname);
            std::fs::write(&sf, self.block_sdc(p)).map_err(|e| Flow::Err(e.to_string()))?;
            files.push(sf);
            // DEF: bound region as die, pins at boundary crossings
            if let (Some(fp), Some(bn)) = (&self.fp, &p.bound_of(0)) {
                if let Some(r) = fp.bounds.iter().find(|b| &b.name == bn).and_then(|b| b.resolved.or(b.rect)) {
                    let mut bfp = crate::phys::Floorplan { dbu: fp.dbu, die: (0.0, 0.0, r.2 - r.0, r.3 - r.1), row_h: fp.row_h, layers: fp.layers.clone(), design: modname.clone(), ..Default::default() };
                    let mut blk2 = blk.clone();
                    for c in blk2.cell_ids() {
                        if let Some((x, y)) = blk2.cell(c).loc {
                            blk2.cell_mut(c).loc = Some((x - r.0, y - r.1));
                        }
                    }
                    for q in blk2.port_ids() {
                        // locate an outside connection and project it to the region edge
                        let full = blk2.ports[q].name.clone();
                        let pn = full.trim_end_matches("_in").trim_end_matches("_out").to_string();
                        let out_loc = ports.iter().find(|b| b.name == pn || b.name == full).and_then(|b| {
                            if b.feed {
                                // feedthrough: _in faces the driver, _out faces the loads
                                let want_drv = full.ends_with("_in");
                                b.outside.iter().filter(|o| nl.is_driver(**o) == want_drv).find_map(|o| nl.pin_loc(*o))
                            } else {
                                b.outside.iter().find_map(|o| nl.pin_loc(*o))
                            }
                        });
                        let (x, y) = out_loc.unwrap_or(((r.0 + r.2) / 2.0, r.1));
                        let cands = [(r.0, y.clamp(r.1, r.3)), (r.2, y.clamp(r.1, r.3)), (x.clamp(r.0, r.2), r.1), (x.clamp(r.0, r.2), r.3)];
                        let best = cands.iter().min_by(|a, b| ((a.0 - x).abs() + (a.1 - y).abs()).partial_cmp(&((b.0 - x).abs() + (b.1 - y).abs())).unwrap()).unwrap();
                        blk2.ports[q].loc = Some((best.0 - r.0, best.1 - r.1));
                    }
                    let mut info = HashMap::new();
                    let fixed_names: HashSet<String> = blk2.port_ids().iter().map(|q| blk2.ports[*q].name.clone()).collect();
                    let st = place_pins(&mut blk2, bfp.die, &bfp.block_pins.clone(), &[], &[], &bfp.layers.clone(), &fixed_names, &mut info);
                    let _ = st;
                    bfp.pin_info = info;
                    bfp.fixed_ports = blk2.port_ids().iter().map(|q| blk2.ports[*q].name.clone()).collect();
                    let df = format!("{}/{}.def", dir, modname);
                    crate::phys::write_def(&df, &blk2, &bfp).map_err(|e| Flow::Err(e.to_string()))?;
                    files.push(df);
                    if let Some(tc) = top.cell_by_name(&p.inst) {
                        top.cell_mut(tc).loc = Some((r.0, r.1));
                        top.cell_mut(tc).fixed = true;
                    }
                }
            }
            crate::info!("PART-200", "Partition '{}': {} cells, {} ports ({} feedthrough) -> {}/{}.{{v,sdc{}}}{}", p.name, blk.num_cells(), blk.port_ids().len(), ports.iter().filter(|b| b.feed).count(), dir, modname, if p.bound_of(0).is_some() && self.fp.is_some() { ",def" } else { "" }, if p.is_mim() { format!(" — one block for {} instances ({})", p.insts().len(), p.insts().join(" ")) } else { String::new() });
        }
        top.mapped = nl.mapped;
        top.sweep_nets();
        let tf = format!("{}/{}.top.v", dir, nl.name);
        crate::out::write_verilog(&top, &tf, &|_| true).map_err(|e| Flow::Err(e.to_string()))?;
        files.push(tf.clone());
        let tsdc = format!("{}/{}.top.sdc", dir, nl.name);
        let m = &self.modes[self.cur_mode];
        std::fs::write(&tsdc, format!("# top-level constraints (mode {})\n{}\n", m.name, m.sdc.raw.join("\n"))).map_err(|e| Flow::Err(e.to_string()))?;
        files.push(tsdc);
        if let Some(fp) = &self.fp {
            let df = format!("{}/{}.top.def", dir, nl.name);
            crate::phys::write_def(&df, &top, fp).map_err(|e| Flow::Err(e.to_string()))?;
            files.push(df);
        }
        let mut all_v = vfiles.clone();
        all_v.push(tf.clone());
        let _ = writeln!(assemble, "analyze -format verilog {{{}}}\nelaborate {} -keep_reference\nverify_equivalence", all_v.iter().map(|f| f.trim_start_matches(&format!("{}/", dir)).to_string()).collect::<Vec<_>>().join(" "), nl.name);
        let af = format!("{}/assemble.tcl", dir);
        std::fs::write(&af, assemble).map_err(|e| Flow::Err(e.to_string()))?;
        files.push(af);
        crate::info!("PART-210", "Wrote {} partition(s) and top-level netlist to '{}' ({} files)", parts.len(), dir, files.len());
        Ok(crate::tcl::to_list(&files))
    }
}

fn nl_name(s: &Session, n: NetId) -> String {
    s.nl.as_ref().map(|nl| nl.net(n).name.clone()).unwrap_or_default()
}
