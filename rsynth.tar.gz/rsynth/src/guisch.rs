//! GUI data and commands: pin flylines of selected macros and standard cells (level-1 pin
//! connectivity) for the layout view
//! and the netlist cone shown in the schematic tab.
//!
//!  gui_show_flylines [-cells pats | -all_macros | -all_std_cells | -all_cells] [-macros_only | -std_cells_only]
//!                    [-add | -remove | -clear] [-exclude_nets pats]
//!                    [-max_fanout n] [-macro_to_macro] [-color_by net|macro]
//!  gui_show_schematic [-cells pats] [-depth n] [-max_cells n] [-all]
//!  gtk_gui / gui_start / gui_show / gui_open / win — open the GTK GUI (gui_stop inside it returns)
//!  gui_write_image file.png [-rect {x0 y0 x1 y1}] [-width w -height h], write_schematic file.svg|png [-cells pats] [-depth n]
//!  gui_deselect_all

use crate::netlist::*;
use crate::session::{args, Session};
use crate::tcl::{split_list, R};
use std::collections::{HashMap, HashSet, VecDeque};

#[derive(Clone, Debug)]
pub struct GuiState {
    pub fly_sel: Vec<String>,
    pub fly_exclude: Vec<String>,
    pub fly_max_fanout: usize,
    pub fly_m2m: bool,
    pub fly_color: String,
    pub sch_seed: Vec<String>,
    pub sch_depth: usize,
    pub sch_max: usize,
    pub sch_all: bool,
    /// cells added by signal tracing (shown as they are, not expanded)
    pub sch_extra: Vec<String>,
    /// rulers (x0, y0, x1, y1) in um
    pub rulers: Vec<(f64, f64, f64, f64)>,
    /// last queried object (kind, name) for the GUI query panel
    pub query: Option<(String, String)>,
    /// view request for both GUIs: (rect, sequence number)
    pub zoom: Option<((f64, f64, f64, f64), u64)>,
}
impl Default for GuiState {
    fn default() -> Self {
        GuiState { fly_sel: vec![], fly_exclude: vec![], fly_max_fanout: 0, fly_m2m: false, fly_color: "net".into(), sch_seed: vec![], sch_depth: 2, sch_max: 400, sch_all: false, sch_extra: vec![], rulers: vec![], query: None, zoom: None }
    }
}

fn js(s: &str) -> String {
    let mut o = String::from("\"");
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '<' => o.push_str("\\u003c"),
            c if (c as u32) < 0x20 => {}
            c => o.push(c),
        }
    }
    o.push('"');
    o
}

/// macro-like cell: LEF block / pad, or a black box
pub fn is_macro(s: &Session, c: &Cell) -> bool {
    matches!(c.kind, Kind::BlackBox(_)) || crate::lef::phys(&s.lef, c).map(|m| m.is_block() || m.is_pad()).unwrap_or(false)
}

impl Session {
    /// position of a leaf pin: its LEF pin shape centre, else the cell centre / location
    fn fly_pin_xy(&self, nl: &Netlist, c: CellId, pin: usize) -> Option<(f64, f64)> {
        let cl = nl.cell(c);
        let pn = &cl.pins[pin].name;
        if let Some((_, r)) = crate::lef::pin_shapes(&self.lef, cl, pn).first() {
            return Some(((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0));
        }
        if let Some(r) = crate::lef::cell_rect(&self.lef, cl) {
            return Some(((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0));
        }
        cl.loc
    }

    /// flylines of the selected macros: [x1,y1,x2,y2,net,macro]
    pub fn fly_json(&self) -> String {
        let g = &self.gui;
        let Some(nl) = self.nl.as_ref() else { return "null".into() };
        if g.fly_sel.is_empty() { return "null".into(); }
        let mut nets: Vec<String> = vec![];
        let mut nidx: HashMap<NetId, usize> = HashMap::new();
        let mut macros: Vec<String> = vec![];
        let mut lines: Vec<String> = vec![];
        let mut pins = 0usize;
        let selset: HashSet<&String> = g.fly_sel.iter().collect();
        for name in &g.fly_sel {
            let Some(c) = nl.cell_by_name(name) else { continue };
            let mi = macros.len();
            macros.push(name.clone());
            let cl = nl.cell(c);
            for (pi, p) in cl.pins.iter().enumerate() {
                let Some(n) = p.net else { continue };
                let nn = nl.net(n).name.clone();
                if g.fly_exclude.iter().any(|q| glob(q, &nn)) { continue; }
                let conns: Vec<PinRef> = Session::leaf_conns(nl, n).into_iter().filter(|q| !matches!(q, PinRef::Cell(o, i) if *o == c && *i == pi)).collect();
                if g.fly_max_fanout > 0 && conns.len() > g.fly_max_fanout { continue; }
                // constants and supplies are not flylines
                if conns.iter().any(|q| matches!(q, PinRef::Cell(o, _) if matches!(nl.cell(*o).kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)))) { continue; }
                let Some(a) = self.fly_pin_xy(nl, c, pi) else { continue };
                pins += 1;
                for q in conns {
                    let b = match q {
                        PinRef::Cell(o, i) => {
                            if nl.cell(o).is_hport() { continue; }
                            if g.fly_m2m && !is_macro(self, nl.cell(o)) { continue; }
                            // a line between two selected macros is drawn once
                            if selset.contains(&nl.cell(o).name) && nl.cell(o).name < *name { continue; }
                            self.fly_pin_xy(nl, o, i)
                        }
                        PinRef::Port(pt) => { if g.fly_m2m { continue; } nl.ports[pt].loc }
                        #[allow(unreachable_patterns)]
                        _ => None,
                    };
                    let Some(b) = b else { continue };
                    let ni = *nidx.entry(n).or_insert_with(|| { nets.push(nn.clone()); nets.len() - 1 });
                    lines.push(format!("[{:.3},{:.3},{:.3},{:.3},{},{}]", a.0, a.1, b.0, b.1, ni, mi));
                    if lines.len() >= 60000 { break; }
                }
            }
        }
        format!("{{\"l\":[{}],\"nets\":[{}],\"macros\":[{}],\"pins\":{},\"color\":{},\"m2m\":{},\"ex\":{},\"mf\":{}}}",
            lines.join(","), nets.iter().map(|n| js(n)).collect::<Vec<_>>().join(","), macros.iter().map(|n| js(n)).collect::<Vec<_>>().join(","),
            pins, js(&g.fly_color), g.fly_m2m, js(&g.fly_exclude.join(" ")), g.fly_max_fanout)
    }

    /// schematic cone: cells around the seeds (or the whole design when small)
    pub fn sch_json(&self) -> String {
        self.sch_json_n().0
    }

    /// (json, cells drawn)
    pub fn sch_json_n(&self) -> (String, usize) {
        let g = &self.gui;
        let Some(nl) = self.nl.as_ref() else { return ("null".into(), 0) };
        let leaf: Vec<CellId> = nl.cell_ids().into_iter().filter(|c| !nl.cell(*c).is_hport()).collect();
        let total = leaf.len();
        let mut seeds: Vec<CellId> = vec![];
        for p in &g.sch_seed {
            for c in &leaf { if glob(p, &nl.cell(*c).name) { seeds.push(*c); } }
            // a port seeds its connected cells
            if let Some(pt) = nl.port_by_name(p) {
                if let Some(n) = nl.ports[pt].net {
                    for q in Session::leaf_conns(nl, n) { if let PinRef::Cell(c, _) = q { if !nl.cell(c).is_hport() { seeds.push(c); } } }
                }
            }
        }
        let whole = g.sch_all || (seeds.is_empty() && g.sch_extra.is_empty() && total <= g.sch_max);
        let mut inc: Vec<CellId> = vec![];
        let mut seen: HashSet<CellId> = HashSet::new();
        let mut trunc = false;
        if whole {
            for c in leaf.iter().take(g.sch_max) { inc.push(*c); }
            trunc = total > g.sch_max;
        } else if !seeds.is_empty() {
            let mut q: VecDeque<(CellId, usize)> = VecDeque::new();
            for s in &seeds { if seen.insert(*s) { q.push_back((*s, 0)); inc.push(*s); } }
            while let Some((c, d)) = q.pop_front() {
                if d >= g.sch_depth { continue; }
                for p in &nl.cell(c).pins {
                    let Some(n) = p.net else { continue };
                    let cs = Session::leaf_conns(nl, n);
                    if cs.len() > 64 { continue; } // do not expand clock / reset trees
                    for r in cs {
                        if let PinRef::Cell(o, _) = r {
                            if nl.cell(o).is_hport() || !seen.insert(o) { continue; }
                            if inc.len() >= g.sch_max { trunc = true; continue; }
                            inc.push(o);
                            q.push_back((o, d + 1));
                        }
                    }
                }
            }
        }
        // traced cells
        for n in &g.sch_extra {
            if let Some(c) = nl.cell_by_name(n) { if !nl.cell(c).is_hport() && seen.insert(c) && !inc.contains(&c) { inc.push(c); } }
        }
        if inc.is_empty() {
            return (format!("{{\"cells\":[],\"nets\":[],\"ports\":[],\"total\":{},\"trunc\":false,\"seed\":[],\"hint\":{}}}", total,
                js(if total > g.sch_max { "Design too large to draw whole: select cells and use 'From layout selection' or gui_show_schematic -cells {..}" } else if total == 0 { "No cells" } else { "No cell matches the seed" })), 0);
        }
        let idx: HashMap<CellId, usize> = inc.iter().enumerate().map(|(i, c)| (*c, i)).collect();
        let mut cells = vec![];
        for c in &inc {
            let cl = nl.cell(*c);
            let (fam, master, seq) = match &cl.kind {
                Kind::Lib(l) => {
                    let seq = self.libs.iter().find_map(|x| x.cells.get(l)).map(|x| x.is_seq()).unwrap_or(false);
                    let fam = if crate::lef::phys(&self.lef, cl).map(|m| m.is_pad()).unwrap_or(false) { "PAD".to_string() } else { crate::ecomask::family(l) };
                    (fam, l.clone(), seq)
                }
                Kind::BlackBox(b) => ("MACRO".to_string(), b.clone(), false),
                Kind::Gen(op) => {
                    let f = format!("{:?}", op).to_uppercase();
                    let seq = f.contains("DFF") || f.contains("LATCH") || f.contains("REG");
                    (f.clone(), f, seq)
                }
                #[allow(unreachable_patterns)]
                _ => ("CELL".into(), String::new(), false),
            };
            let ins: Vec<String> = cl.pins.iter().filter(|p| p.dir != Dir::Out).map(|p| js(&p.name)).collect();
            let outs: Vec<String> = cl.pins.iter().filter(|p| p.dir == Dir::Out).map(|p| js(&p.name)).collect();
            cells.push(format!("[{},{},{},[{}],[{}],{}]", js(&cl.name), js(&fam), js(&master), ins.join(","), outs.join(","), if seq { 1 } else { 0 }));
        }
        // nets between included cells (logical, through hierarchy boundaries) + ports
        let mut ports: Vec<String> = vec![];
        let mut pidx: HashMap<PortId, usize> = HashMap::new();
        let mut nets = vec![];
        let mut done: HashSet<(CellId, usize)> = HashSet::new();
        let pin_in_list = |c: CellId, i: usize| -> usize {
            let cl = nl.cell(c);
            let d = cl.pins[i].dir;
            cl.pins[..i].iter().filter(|p| (p.dir == Dir::Out) == (d == Dir::Out)).count()
        };
        for c in &inc {
            for (i, p) in nl.cell(*c).pins.iter().enumerate() {
                let Some(n) = p.net else { continue };
                if done.contains(&(*c, i)) { continue; }
                let cs = Session::leaf_conns(nl, n);
                let mut ends: Vec<(String, bool)> = vec![]; // endpoint, is driver
                let mut off = 0usize;
                for r in &cs {
                    match r {
                        PinRef::Cell(o, j) => {
                            if nl.cell(*o).is_hport() { continue; }
                            done.insert((*o, *j));
                            match idx.get(o) {
                                Some(k) => ends.push((format!("[{},{}]", k, pin_in_list(*o, *j)), nl.cell(*o).pins[*j].dir == Dir::Out)),
                                None => off += 1,
                            }
                        }
                        PinRef::Port(pt) => {
                            let k = *pidx.entry(*pt).or_insert_with(|| { ports.push(format!("[{},{}]", js(&nl.ports[*pt].name), js(match nl.ports[*pt].dir { Dir::In => "in", Dir::Out => "out", Dir::InOut => "inout" }))); ports.len() - 1 });
                            ends.push((format!("[{},0]", -1 - k as i64), nl.ports[*pt].dir == Dir::In));
                        }
                        #[allow(unreachable_patterns)]
                        _ => {}
                    }
                }
                if ends.is_empty() { continue; }
                let drv: Vec<&String> = ends.iter().filter(|e| e.1).map(|e| &e.0).collect();
                let lds: Vec<&String> = ends.iter().filter(|e| !e.1).map(|e| &e.0).collect();
                nets.push(format!("[{},{},[{}],{}]", js(&nl.net(n).name), drv.first().map(|s| s.as_str()).unwrap_or("null"),
                    lds.iter().map(|s| s.as_str()).collect::<Vec<_>>().join(","), off));
            }
        }
        (format!("{{\"cells\":[{}],\"nets\":[{}],\"ports\":[{}],\"total\":{},\"trunc\":{},\"seed\":[{}],\"depth\":{},\"hint\":\"\"}}",
            cells.join(","), nets.join(","), ports.join(","), total, trunc, g.sch_seed.iter().map(|s| js(s)).collect::<Vec<_>>().join(","), g.sch_depth), cells.len())
    }

    pub fn guisch_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "gtk_gui" | "gui_start" | "start_gui" | "gui_show" | "gui_open" | "win" | "gui" | "gui_start_gtk" | "start_gtk_gui" => {
                #[cfg(feature = "gtk")]
                { let _ = a; self.gtk_gui_cmd() }
                #[cfg(not(feature = "gtk"))]
                { let _ = a; crate::tcl::err(&format!("{}: this rsynth was built without the GUI (cargo build --release --features gtk) (GUI-100)", name)) }
            }
            "gui_hide" | "gui_close" => {
                crate::info!("GUI-003", "gui_hide: the GUI is not running (inside the GUI it closes the window session)");
                Ok(String::new())
            }
            "gui_deselect_all" | "gui_clear_selection" => {
                // GUI ^D: empty the selection and the flyline cell set
                let n = self.selection.len() + self.gui.fly_sel.len();
                self.selection.clear();
                self.gui.fly_sel.clear();
                crate::info!("GUI-032", "Deselected all ({} object(s))", n);
                Ok(String::new())
            }
            "gui_show_flylines" | "show_flylines" | "gui_flylines" => {
                let x = args(a, &["-cells", "-exclude_nets", "-max_fanout", "-color_by"]);
                let mut pats: Vec<String> = x.get("-cells").map(|s| split_list(s)).unwrap_or_default();
                pats.extend(x.pos.iter().flat_map(|p| split_list(p)).map(|p| crate::cons::Obj::parse(&p).map(|o| o.name().to_string()).unwrap_or(p)));
                let Some(nl) = self.nl.as_ref() else { return Some(crate::tcl::err("gui_show_flylines: no design")) };
                if x.has("-clear") {
                    self.gui.fly_sel.clear();
                } else {
                    let mut names: Vec<String> = nl.cell_ids().into_iter().filter(|c| {
                        let cl = nl.cell(*c);
                        if cl.is_hport() || matches!(cl.kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) || cl.loc.is_none() { return false; }
                        let m = is_macro(self, cl);
                        let fill = cl.attrs.iter().any(|a| a == "ga_base" || a == "io_kind:filler") || cl.pins.iter().all(|p| p.net.is_none());
                        if x.has("-all_macros") && m { return true; }
                        if x.has("-all_std_cells") && !m && !fill { return true; }
                        if x.has("-all_cells") && !fill { return true; }
                        // patterns select macros and standard cells (-macros_only / -std_cells_only narrow it)
                        pats.iter().any(|p| glob(p, &cl.name)) && !(x.has("-macros_only") && !m) && !(x.has("-std_cells_only") && m)
                    }).map(|c| nl.cell(c).name.clone()).collect();
                    names.sort();
                    if names.is_empty() && !pats.is_empty() {
                        return Some(crate::tcl::err(&format!("gui_show_flylines: no cell matches {} (GUI-020)", pats.join(" "))));
                    }
                    if x.has("-remove") {
                        self.gui.fly_sel.retain(|n| !names.contains(n));
                    } else if x.has("-add") {
                        for n in names { if !self.gui.fly_sel.contains(&n) { self.gui.fly_sel.push(n); } }
                    } else if !names.is_empty() || x.has("-all_macros") || x.has("-all_std_cells") || x.has("-all_cells") {
                        self.gui.fly_sel = names;
                    }
                }
                if let Some(e) = x.get("-exclude_nets") { self.gui.fly_exclude = split_list(e); }
                if let Some(m) = x.num("-max_fanout") { self.gui.fly_max_fanout = m.max(0.0) as usize; }
                if x.has("-macro_to_macro") { self.gui.fly_m2m = true; }
                if x.has("-all_connections") { self.gui.fly_m2m = false; }
                if let Some(c) = x.get("-color_by") { self.gui.fly_color = if c == "macro" { "macro".into() } else { "net".into() }; }
                let j = self.fly_json();
                let n = j.matches("],[").count() + if j.contains("\"l\":[[") { 1 } else { 0 };
                let pins = j.split("\"pins\":").nth(1).and_then(|r| r.split(',').next()).unwrap_or("0").to_string();
                let nm = self.gui.fly_sel.iter().filter(|c| nl.cell_by_name(c).map(|id| is_macro(self, nl.cell(id))).unwrap_or(false)).count();
                crate::info!("GUI-021", "Flylines for {} selected cell(s) ({} macro(s), {} standard cell(s)): {} connected pin(s), {} flyline(s){}{}", self.gui.fly_sel.len(), nm, self.gui.fly_sel.len() - nm, pins, n,
                    if self.gui.fly_m2m { " (macro-to-macro only)" } else { "" }, if n >= 60000 { ", capped at 60000" } else { "" });
                Ok(n.to_string())
            }
            "gui_zoom" | "gui_zoom_to" | "zoom_to" => {
                let x = args(a, &["-rect", "-cells", "-margin"]);
                let fp = match self.fp.as_ref() { Some(f) => f, None => return Some(crate::tcl::err("gui_zoom: no floorplan (FP-001)")) };
                let mut r: Option<(f64, f64, f64, f64)> = None;
                if x.has("-fit") { r = Some(fp.die); }
                if let Some(v) = x.get("-rect") { let n = crate::chipfp::nums(v); if n.len() >= 4 { r = Some((n[0].min(n[2]), n[1].min(n[3]), n[0].max(n[2]), n[1].max(n[3]))); } }
                if let Some(c) = x.get("-cells") {
                    let pats = split_list(c);
                    if let Some(nl) = self.nl.as_ref() {
                        for id in nl.cell_ids() {
                            let cl = nl.cell(id);
                            if !pats.iter().any(|p| glob(p, &cl.name)) { continue; }
                            let b = crate::lef::cell_rect(&self.lef, cl).or_else(|| cl.loc.map(|l| (l.0 - 1.0, l.1 - 1.0, l.0 + 1.0, l.1 + 1.0)));
                            if let Some(b) = b { r = Some(match r { Some(q) => (q.0.min(b.0), q.1.min(b.1), q.2.max(b.2), q.3.max(b.3)), None => b }); }
                        }
                    }
                }
                let Some(mut r) = r else { return Some(crate::tcl::err("gui_zoom: give -fit, -rect {x0 y0 x1 y1} or -cells {..} (GUI-040)")) };
                let m = x.num("-margin").unwrap_or(0.0);
                r = (r.0 - m, r.1 - m, r.2 + m, r.3 + m);
                let k = self.gui.zoom.map(|z| z.1 + 1).unwrap_or(1);
                self.gui.zoom = Some((r, k));
                crate::info!("GUI-041", "GUI view: ({:.2}, {:.2}) - ({:.2}, {:.2})", r.0, r.1, r.2, r.3);
                Ok(String::new())
            }
            "gui_show_schematic" | "show_schematic" | "gui_schematic" => {
                let x = args(a, &["-cells", "-depth", "-max_cells"]);
                let mut pats: Vec<String> = x.get("-cells").map(|s| split_list(s)).unwrap_or_default();
                pats.extend(x.pos.iter().flat_map(|p| split_list(p)).map(|p| crate::cons::Obj::parse(&p).map(|o| o.name().to_string()).unwrap_or(p)));
                self.gui.sch_seed = pats;
                self.gui.sch_extra.clear();
                self.gui.sch_all = x.has("-all");
                if let Some(d) = x.num("-depth") { self.gui.sch_depth = d.max(0.0) as usize; }
                if let Some(m) = x.num("-max_cells") { self.gui.sch_max = (m as usize).clamp(1, 5000); }
                let (j, n) = self.sch_json_n();
                crate::info!("GUI-030", "Schematic: {} cell(s){} (open the Schematic tab of the GUI)", n, if j.contains("\"trunc\":true") { ", truncated at -max_cells" } else { "" });
                Ok(n.to_string())
            }
            "gui_trace_schematic" | "trace_schematic" | "gui_trace_signal" => {
                // trace from a pin through `-levels` levels of logic (or to the next flop / port)
                let x = args(a, &["-pin", "-levels", "-direction"]);
                let Some(pin) = x.get("-pin").cloned().or(x.pos.first().cloned()) else { return Some(crate::tcl::err("gui_trace_schematic: -pin inst/pin required (GUI-040)")) };
                let pin = crate::cons::Obj::parse(&pin).map(|o| o.name().to_string()).unwrap_or(pin);
                let to_end = x.has("-to_endpoint");
                let levels = if to_end { 64 } else { x.num("-levels").unwrap_or(2.0).max(1.0) as usize };
                let nl = match self.nl() { Ok(n) => n, Err(e) => return Some(Err(e)) };
                // start: an instance pin, or a top-level port
                let mut found: Vec<CellId> = vec![];
                let mut seen: HashSet<CellId> = HashSet::new();
                let (seed_net, fw, inst): (Option<NetId>, bool, String) = match pin.rsplit_once('/').filter(|(i, _)| nl.cell_by_name(i).is_some()) {
                    Some((i, pn)) => {
                        let c0 = nl.cell_by_name(i).unwrap();
                        let Some(pi) = nl.cell(c0).pin(pn) else { return Some(crate::tcl::err(&format!("gui_trace_schematic: no pin '{}' on {} (GUI-043)", pn, i))) };
                        let is_out = nl.cell(c0).pins[pi].dir == Dir::Out;
                        found.push(c0);
                        seen.insert(c0);
                        let fw = x.get("-direction").map(|d| d != "fanin").unwrap_or(is_out);
                        (nl.cell(c0).pins[pi].net, fw, i.to_string())
                    }
                    None => match nl.port_by_name(&pin) {
                        Some(p) => { let fw = x.get("-direction").map(|d| d != "fanin").unwrap_or(nl.ports[p].dir != Dir::Out); (nl.ports[p].net, fw, String::new()) }
                        None => return Some(crate::tcl::err(&format!("gui_trace_schematic: '{}' is neither inst/pin nor a port (GUI-041)", pin))),
                    },
                };
                let dir = if fw { "fanout" } else { "fanin" };
                let seq = |c: CellId| -> bool { match &nl.cell(c).kind { Kind::Lib(l) => self.libs.iter().find_map(|x| x.cells.get(l)).map(|x| x.is_seq()).unwrap_or(false), Kind::BlackBox(_) => true, Kind::Gen(o) => format!("{:?}", o).contains("DFF") } };
                let mut nets: Vec<NetId> = seed_net.into_iter().collect();
                let mut endpoints = 0;
                for _lv in 0..levels {
                    let mut next: Vec<CellId> = vec![];
                    for n in &nets {
                        let cs = Session::leaf_conns(nl, *n);
                        if cs.len() > 64 { continue; }
                        for r in cs {
                            let PinRef::Cell(o, j) = r else { continue };
                            if nl.cell(o).is_hport() { continue; }
                            let od = nl.cell(o).pins[j].dir;
                            if (fw && od == Dir::Out) || (!fw && od != Dir::Out) { continue; }
                            if seen.insert(o) {
                                found.push(o);
                                if seq(o) { endpoints += 1; } else { next.push(o); }
                            }
                        }
                    }
                    nets = next.iter().flat_map(|c| nl.cell(*c).pins.iter().filter(|p| if fw { p.dir == Dir::Out } else { p.dir != Dir::Out }).filter_map(|p| p.net).collect::<Vec<_>>()).collect();
                    if nets.is_empty() { break; }
                }
                let inst = inst.as_str();
                let names: Vec<String> = found.iter().map(|c| nl.cell(*c).name.clone()).collect();
                let n_new = names.iter().filter(|n| !self.gui.sch_extra.contains(n)).count();
                for n in names { if !self.gui.sch_extra.contains(&n) { self.gui.sch_extra.push(n); } }
                if self.gui.sch_seed.is_empty() && !self.gui.sch_all && !inst.is_empty() { self.gui.sch_seed.push(inst.to_string()); self.gui.sch_depth = 0; }
                crate::info!("GUI-044", "Traced {} of {} {}: {} cell(s) ({} new){}", dir, pin, if to_end { "to the endpoints".to_string() } else { format!("{} level(s)", levels) }, found.len(), n_new,
                    if endpoints > 0 { format!(", {} sequential endpoint(s)", endpoints) } else { String::new() });
                Ok(found.len().to_string())
            }
            "gui_write_image" | "write_layout_image" | "write_schematic" | "gui_write_schematic" => {
                // PNG / SVG through the GTK GUI's renderer (no window needed)
                let x = args(a, &["-cells", "-depth", "-width", "-height", "-rect", "-show", "-hide"]);
                let schem = name.contains("schematic");
                let Some(f) = x.pos.first().cloned() else { return Some(crate::tcl::err(&format!("{}: file name (.png{}) required (CMD-001)", name, if schem { " or .svg" } else { "" }))) };
                if schem {
                    if let Some(c) = x.get("-cells") { self.gui.sch_seed = split_list(c); self.gui.sch_all = false; }
                    if x.has("-all") { self.gui.sch_all = true; }
                    if let Some(d) = x.num("-depth") { self.gui.sch_depth = d as usize; }
                }
                let _size = (x.num("-width").unwrap_or(1600.0), x.num("-height").unwrap_or(1200.0));
                let _rect = x.get("-rect").map(|r| split_list(r).iter().filter_map(|v| v.parse::<f64>().ok()).collect::<Vec<f64>>()).filter(|v| v.len() == 4).map(|v| (v[0], v[1], v[2], v[3]));
                #[cfg(feature = "gtk")]
                {
                    let st = crate::gui::state_json(self);
                    let r = if schem { crate::gtkgui::export_schematic(&st, &f) } else { crate::gtkgui::export_layout(&st, &f, _size, _rect, &x.get("-show").map(|v| split_list(v)).unwrap_or_default(), &x.get("-hide").map(|v| split_list(v)).unwrap_or_default()) };
                    match r {
                        Ok(_) => { crate::info!("GUI-031", "Wrote {} image '{}'", if schem { "schematic" } else { "layout" }, f); Ok(f) }
                        Err(e) => crate::tcl::err(&format!("{}: {} (GUI-033)", name, e)),
                    }
                }
                #[cfg(not(feature = "gtk"))]
                { let _ = f; crate::tcl::err(&format!("{}: this rsynth was built without the GUI (cargo build --release --features gtk) (GUI-100)", name)) }
            }
            _ => return None,
        })
    }
}
