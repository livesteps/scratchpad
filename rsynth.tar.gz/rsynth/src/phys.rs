//! DEF floorplan reader/writer: DIEAREA, ROWS, COMPONENTS, PINS (+LAYER, PLACED/FIXED),
//! BLOCKAGES (placement hard/soft/partial, routing per layer), REGIONS (FENCE/GUIDE),
//! GROUPS (-> bounds), NETS. All floorplan objects (DEF-sourced or created by
//! commands) live in `Floorplan` and are honored by placement and global routing.

use crate::fplan::*;
use crate::netlist::*;
use std::collections::{HashMap, HashSet};

#[derive(Clone, Debug, Default)]
pub struct Floorplan {
    pub design: String,
    pub dbu: f64,
    pub die: (f64, f64, f64, f64),
    pub rows: usize,
    pub row_h: f64,
    pub placed: usize,
    pub fixed: usize,
    pub unmatched: Vec<String>,
    pub pins: usize,
    pub pblk: Vec<PBlockage>,
    pub rblk: Vec<RBlockage>,
    pub guides: Vec<RGuide>,
    pub bounds: Vec<Bound>,
    pub feeds: Vec<Feedthrough>,
    pub pin_cons: Vec<PinCons>,
    pub bundles: Vec<Bundle>,
    pub block_pins: BlockPins,
    pub layers: Vec<Layer>,
    pub pin_info: HashMap<String, (String, String, String)>,
    pub fixed_ports: HashSet<String>,
    pub groute: Option<GRoute>,
    pub uid: usize,
    /// voltage areas: physical regions of UPF power domains
    pub vas: Vec<VoltageArea>,
    /// core (row) area inside the die; None: rows cover the die
    pub core: Option<(f64, f64, f64, f64)>,
    /// per-port pin shape (width along the edge, depth into the die) from place_io_pins
    pub pin_shapes: HashMap<String, (f64, f64)>,
    /// special wiring: seal ring, RDL, manual wires (written to DEF SPECIALNETS and GDS)
    pub special: Vec<SpecialShape>,
    /// flip-chip bumps
    pub bumps: Vec<Bump>,
    /// pad ring (wire-bond / area IO)
    pub io: IoRing,
    /// explicit core rows (create_row / cut_row / delete_row, or RSROW_ rows read from DEF);
    /// empty or `rows_explicit == false`: rows tile the core implicitly
    pub row_list: Vec<RowRec>,
    pub rows_explicit: bool,
    /// explicit routing tracks (create_track / add_tracks, or TRACKS read from DEF)
    pub track_list: Vec<TrackRec>,
}

/// one core row: `nsites` sites of width `step` from (x, y), orientation N / FS / ...
#[derive(Clone, Debug, Default, PartialEq)]
pub struct RowRec {
    pub name: String,
    pub site: String,
    pub x: f64,
    pub y: f64,
    pub orient: String,
    pub nsites: usize,
    pub step: f64,
    pub height: f64,
}
impl RowRec {
    pub fn x1(&self) -> f64 { self.x + self.nsites as f64 * self.step }
    pub fn rect(&self) -> (f64, f64, f64, f64) { (self.x, self.y, self.x1(), self.y + self.height) }
}

/// one TRACKS statement: `num` tracks on `layer`, `dir` X (vertical lines at x positions) or Y
#[derive(Clone, Debug, Default, PartialEq)]
pub struct TrackRec {
    pub layer: String,
    pub dir: char,
    pub start: f64,
    pub num: usize,
    pub step: f64,
    pub mask: Option<u32>,
    pub same_mask: bool,
}

/// A special wire: centre-line path (any angle, 45-degree RDL included) of a given width, or a
/// rectangle when `pts` has two points and `rect` is set.
#[derive(Clone, Debug, Default)]
pub struct SpecialShape {
    pub name: String,
    pub net: String,
    pub layer: String,
    /// seal_ring | rdl | wire | stripe
    pub kind: String,
    pub width: f64,
    pub pts: Vec<(f64, f64)>,
    pub rect: Option<(f64, f64, f64, f64)>,
    /// via array (kind "pg_via"): `rect` is the overlap area, `layer` the cut layer
    pub via: Option<ViaArr>,
}

/// generated via array: rule, layers, cut grid
#[derive(Clone, Debug, Default, PartialEq)]
pub struct ViaArr {
    pub rule: String,
    pub lower: String,
    pub upper: String,
    pub cols: usize,
    pub rows: usize,
    pub cut_w: f64,
    pub cut_h: f64,
    pub sp_x: f64,
    pub sp_y: f64,
    /// enclosure: lower x, lower y, upper x, upper y
    pub enc: (f64, f64, f64, f64),
}
impl ViaArr {
    /// cut rectangles of the array centred in `r`
    pub fn cuts(&self, r: (f64, f64, f64, f64)) -> Vec<(f64, f64, f64, f64)> {
        let (cx, cy) = ((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0);
        let tw = self.cols as f64 * self.cut_w + (self.cols.max(1) - 1) as f64 * self.sp_x;
        let th = self.rows as f64 * self.cut_h + (self.rows.max(1) - 1) as f64 * self.sp_y;
        let mut v = vec![];
        for i in 0..self.cols { for j in 0..self.rows {
            let x0 = cx - tw / 2.0 + i as f64 * (self.cut_w + self.sp_x);
            let y0 = cy - th / 2.0 + j as f64 * (self.cut_h + self.sp_y);
            v.push((x0, y0, x0 + self.cut_w, y0 + self.cut_h));
        } }
        v
    }
}
impl SpecialShape {
    pub fn length(&self) -> f64 {
        self.pts.windows(2).map(|w| ((w[1].0 - w[0].0).powi(2) + (w[1].1 - w[0].1).powi(2)).sqrt()).sum()
    }
    /// bounding box
    pub fn bbox(&self) -> (f64, f64, f64, f64) {
        if let Some(r) = self.rect {
            return r;
        }
        let h = self.width / 2.0;
        let xs = self.pts.iter().map(|p| p.0);
        let ys = self.pts.iter().map(|p| p.1);
        (xs.clone().fold(f64::MAX, f64::min) - h, ys.clone().fold(f64::MAX, f64::min) - h, xs.fold(f64::MIN, f64::max) + h, ys.fold(f64::MIN, f64::max) + h)
    }
}

#[derive(Clone, Debug, Default)]
pub struct Bump {
    pub name: String,
    pub cell: String,
    /// centre
    pub x: f64,
    pub y: f64,
    pub layer: String,
    pub net: String,
    /// signal | power | ground | unassigned
    pub kind: String,
    /// pad / port served by the bump
    pub pad: String,
    pub fixed: bool,
}

#[derive(Clone, Debug, Default)]
pub struct IoPad {
    pub inst: String,
    pub side: String,
    pub order: usize,
    pub domain: String,
    /// signal | power | ground | io_power | io_ground | clamp | breaker | corner | filler | area
    pub kind: String,
}

#[derive(Clone, Debug, Default)]
pub struct BondPad {
    pub name: String,
    pub pad: String,
    pub cell: String,
    pub rect: (f64, f64, f64, f64),
    /// 0 = inner (inline) row, 1 = outer row (staggered)
    pub row: usize,
}

#[derive(Clone, Debug, Default)]
pub struct IoRing {
    /// inline | staggered | area (flip-chip)
    pub style: String,
    pub pads: Vec<IoPad>,
    pub bond_pads: Vec<BondPad>,
    pub ring: Option<(f64, f64, f64, f64)>,
    pub pad_depth: f64,
}

/// `create_voltage_area`: the physical region of one or more power domains. The placement
/// region is `rect` shrunk by `guard`; it is enforced as an exclusive bound of the same name.
#[derive(Clone, Debug, Default)]
pub struct VoltageArea {
    pub name: String,
    pub pds: Vec<String>,
    pub rect: (f64, f64, f64, f64),
    pub guard: (f64, f64),
}
impl VoltageArea {
    pub fn inner(&self) -> (f64, f64, f64, f64) {
        (self.rect.0 + self.guard.0, self.rect.1 + self.guard.1, self.rect.2 - self.guard.0, self.rect.3 - self.guard.1)
    }
}

impl Floorplan {
    /// standard-cell placement region (core, or the die when no core was defined)
    pub fn place_region(&self) -> (f64, f64, f64, f64) {
        self.core.unwrap_or(self.die)
    }
    pub fn fresh(&mut self, p: &str) -> String {
        self.uid += 1;
        format!("{}_{}", p, self.uid)
    }
    /// Carry over user-created (non-DEF) objects from a previous floorplan. Objects that the
    /// new DEF already contains (e.g. a DEF written by this tool) are de-duplicated: the
    /// command-created version wins because it carries the full semantics.
    pub fn merge_user(&mut self, old: &Floorplan) {
        let same = |a: &Rect, b: &Rect| (a.0 - b.0).abs() + (a.1 - b.1).abs() + (a.2 - b.2).abs() + (a.3 - b.3).abs() < 1e-3;
        for u in old.pblk.iter().filter(|x| x.source != "def") {
            self.pblk.retain(|d| !(d.source == "def" && same(&d.rect, &u.rect)));
            self.pblk.push(u.clone());
        }
        for u in old.rblk.iter().filter(|x| x.source != "def") {
            self.rblk.retain(|d| !(d.source == "def" && same(&d.rect, &u.rect) && (u.layers.is_empty() || d.layers.iter().all(|l| u.layers.contains(l)))));
            self.rblk.push(u.clone());
        }
        self.guides.extend(old.guides.iter().cloned());
        for u in old.bounds.iter().filter(|x| x.source != "def") {
            self.bounds.retain(|d| d.name != u.name);
            self.bounds.push(u.clone());
        }
        self.feeds.extend(old.feeds.iter().cloned());
        if self.core.is_none() { self.core = old.core; }
        for (k, v) in &old.pin_shapes { self.pin_shapes.entry(k.clone()).or_insert(*v); }
        if self.special.is_empty() { self.special = old.special.clone(); }
        if self.bumps.is_empty() { self.bumps = old.bumps.clone(); }
        if self.io.pads.is_empty() { self.io = old.io.clone(); }
        for v in &old.vas {
            self.vas.retain(|x| x.name != v.name);
            self.vas.push(v.clone());
        }
        self.pin_cons.extend(old.pin_cons.iter().cloned());
        self.bundles.extend(old.bundles.iter().cloned());
        self.block_pins = old.block_pins.clone();
        if old.rows_explicit && !self.rows_explicit { self.row_list = old.row_list.clone(); self.rows_explicit = true; }
        if self.track_list.is_empty() { self.track_list = old.track_list.clone(); }
        self.uid = old.uid;
    }
}

fn toks(s: &str) -> Vec<String> {
    let mut v = vec![];
    for line in s.lines() {
        let l = match line.find('#') {
            Some(i) => &line[..i],
            None => line,
        };
        for t in l.split_whitespace() {
            v.push(t.to_string());
        }
    }
    v
}

fn section_end(t: &[String], i: usize, name: &str) -> bool {
    t[i] == "END" && t.get(i + 1).map(|s| s == name).unwrap_or(false)
}

pub fn read_def(path: &str, nl: &mut Netlist) -> Result<Floorplan, String> {
    let src = std::fs::read_to_string(path).map_err(|e| format!("cannot read {}: {}", path, e))?;
    let t = toks(&src);
    let mut fp = Floorplan { dbu: 1000.0, layers: default_layers(), ..Default::default() };
    let mut i = 0;
    let num = |s: &str| s.parse::<f64>().unwrap_or(0.0);
    let mut regions: HashMap<String, (Rect, BoundKind)> = HashMap::new();
    let mut groups: Vec<(String, Vec<String>, Option<String>)> = vec![];
    let mut row_ys: Vec<f64> = vec![];
    let mut row_box: Vec<(f64, f64, f64)> = vec![];
    // read a "( x y ) ( x y )" rectangle starting at t[j]=="("
    let rect_at = |t: &[String], j: usize, dbu: f64| -> Option<Rect> {
        if t.get(j)? != "(" || t.get(j + 4)? != "(" {
            return None;
        }
        Some(rnorm((num(&t[j + 1]) / dbu, num(&t[j + 2]) / dbu, num(&t[j + 5]) / dbu, num(&t[j + 6]) / dbu)))
    };
    while i < t.len() {
        match t[i].as_str() {
            "DESIGN" if i == 0 || t[i - 1] != "END" => {
                fp.design = t.get(i + 1).cloned().unwrap_or_default();
                i += 2;
            }
            "UNITS" => {
                fp.dbu = num(t.get(i + 3).map(|s| s.as_str()).unwrap_or("1000"));
                i += 4;
            }
            "DIEAREA" => {
                let mut pts = vec![];
                let mut j = i + 1;
                while j < t.len() && t[j] != ";" {
                    if t[j] == "(" {
                        pts.push((num(&t[j + 1]) / fp.dbu, num(&t[j + 2]) / fp.dbu));
                        j += 3;
                    }
                    j += 1;
                }
                if pts.len() >= 2 {
                    let xs: Vec<f64> = pts.iter().map(|p| p.0).collect();
                    let ys: Vec<f64> = pts.iter().map(|p| p.1).collect();
                    fp.die = (xs.iter().cloned().fold(f64::MAX, f64::min), ys.iter().cloned().fold(f64::MAX, f64::min), xs.iter().cloned().fold(f64::MIN, f64::max), ys.iter().cloned().fold(f64::MIN, f64::max));
                }
                i = j + 1;
            }
            "TRACKS" => {
                // TRACKS X|Y start DO n STEP s [MASK m [SAMEMASK]] LAYER l [l2 ...] ;
                let mut j = i + 1;
                let mut stmt: Vec<String> = vec![];
                while j < t.len() && t[j] != ";" { stmt.push(t[j].clone()); j += 1; }
                let g = |k: &str| stmt.iter().position(|x| x == k).and_then(|p| stmt.get(p + 1)).cloned();
                let dir = stmt.first().and_then(|d| d.chars().next()).unwrap_or('X');
                let start = stmt.get(1).map(|v| num(v) / fp.dbu).unwrap_or(0.0);
                let n = g("DO").map(|v| num(&v) as usize).unwrap_or(0);
                let step = g("STEP").map(|v| num(&v) / fp.dbu).unwrap_or(0.0);
                let mask = g("MASK").and_then(|v| v.parse::<u32>().ok());
                let same = stmt.iter().any(|x| x == "SAMEMASK");
                if let Some(p) = stmt.iter().position(|x| x == "LAYER") {
                    for l in &stmt[p + 1..] { fp.track_list.push(TrackRec { layer: l.clone(), dir, start, num: n, step, mask, same_mask: same }); }
                }
                i = j + 1;
            }
            "ROW" => {
                fp.rows += 1;
                if let Some(y) = t.get(i + 4) {
                    row_ys.push(num(y) / fp.dbu);
                }
                // ROW name site x y orient DO n BY 1 STEP sx sy
                let x0 = t.get(i + 3).map(|v| num(v) / fp.dbu).unwrap_or(0.0);
                let y0 = t.get(i + 4).map(|v| num(v) / fp.dbu).unwrap_or(0.0);
                let n = t.get(i + 7).map(|v| num(v)).unwrap_or(0.0);
                let st = t.get(i + 11).map(|v| num(v) / fp.dbu).unwrap_or(0.0);
                row_box.push((x0, y0, x0 + n * st));
                let rname = t.get(i + 1).cloned().unwrap_or_default();
                if rname.starts_with("RSROW_") { fp.rows_explicit = true; }
                fp.row_list.push(RowRec { name: rname, site: t.get(i + 2).cloned().unwrap_or("coreSite".into()), x: x0, y: y0, orient: t.get(i + 5).cloned().unwrap_or("N".into()), nsites: n.max(0.0) as usize, step: st, height: 0.0 });
                while i < t.len() && t[i] != ";" {
                    i += 1
                }
                i += 1;
            }
            "COMPONENTS" => {
                i += 3;
                while i < t.len() && !section_end(&t, i, "COMPONENTS") {
                    if t[i] == "-" {
                        let name = t[i + 1].replace('\\', "");
                        let mut j = i + 3;
                        let mut loc = None;
                        let mut fixed = false;
                        let mut orient: Option<String> = None;
                        let mut cover = false;
                        let model = t.get(i + 2).cloned().unwrap_or_default();
                        while j < t.len() && t[j] != ";" {
                            if (t[j] == "PLACED" || t[j] == "FIXED" || t[j] == "COVER") && t.get(j + 1).map(|s| s == "(").unwrap_or(false) {
                                fixed = t[j] != "PLACED";
                                if t[j] == "COVER" { cover = true; }
                                loc = Some((num(&t[j + 2]) / fp.dbu, num(&t[j + 3]) / fp.dbu));
                                orient = t.get(j + 5).filter(|o| ["N", "S", "E", "W", "FN", "FS", "FE", "FW"].contains(&o.as_str())).cloned();
                            }
                            j += 1;
                        }
                        if let Some(l) = loc {
                            match nl.cell_by_name(&name) {
                                Some(c) => {
                                    nl.cell_mut(c).loc = Some(l);
                                    nl.cell_mut(c).fixed = fixed;
                                    if let Some(o) = &orient {
                                        nl.cell_mut(c).attrs.retain(|a| !a.starts_with("orient:"));
                                        if o != "N" {
                                            nl.cell_mut(c).attrs.push(format!("orient:{}", o));
                                        }
                                    }
                                    fp.placed += 1;
                                    if fixed {
                                        fp.fixed += 1
                                    }
                                }
                                None if cover => fp.bumps.push(Bump { name, cell: model.clone(), x: l.0, y: l.1, layer: "AP".into(), kind: "unassigned".into(), fixed: true, ..Default::default() }),
                                None => fp.unmatched.push(name),
                            }
                        }
                        i = j + 1;
                        continue;
                    }
                    i += 1;
                }
                i += 2;
            }
            "PINS" => {
                i += 3;
                while i < t.len() && !section_end(&t, i, "PINS") {
                    if t[i] == "-" {
                        let name = t[i + 1].clone();
                        let mut j = i + 2;
                        let mut loc = None;
                        let mut layer = None;
                        while j < t.len() && t[j] != ";" {
                            if (t[j] == "PLACED" || t[j] == "FIXED") && t.get(j + 1).map(|s| s == "(").unwrap_or(false) {
                                loc = Some((num(&t[j + 2]) / fp.dbu, num(&t[j + 3]) / fp.dbu));
                            }
                            if t[j] == "LAYER" {
                                layer = t.get(j + 1).cloned();
                            }
                            j += 1;
                        }
                        if let (Some(l), Some(p)) = (loc, nl.port_by_name(&name)) {
                            nl.ports[p].loc = Some(l);
                            fp.pins += 1;
                            fp.fixed_ports.insert(name.clone());
                            if let Some(ly) = layer {
                                fp.pin_info.insert(name.clone(), (String::new(), ly, "def".into()));
                            }
                        }
                        i = j + 1;
                        continue;
                    }
                    i += 1;
                }
                i += 2;
            }
            "SPECIALNETS" if i == 0 || t[i - 1] != "END" => {
                i += 3;
                while i < t.len() && !section_end(&t, i, "SPECIALNETS") {
                    if t[i] == "-" {
                        let net = t[i + 1].clone();
                        let mut j = i + 2;
                        let mut use_ = String::new();
                        let mut shape = String::new();
                        let mut cur: Option<SpecialShape> = None;
                        let mut shapes: Vec<SpecialShape> = vec![];
                        while j < t.len() && t[j] != ";" {
                            match t[j].as_str() {
                                "(" if cur.is_none() && t.get(j + 3).map(|x| x == ")").unwrap_or(false) => {
                                    // ( inst pin ) connection
                                    let inst = t[j + 1].clone();
                                    if let Some(b) = fp.bumps.iter_mut().find(|b| b.name == inst) { b.net = net.clone(); }
                                    j += 3;
                                }
                                "(" if cur.is_some() => {
                                    let x = if t[j + 1] == "*" { cur.as_ref().unwrap().pts.last().map(|p| p.0).unwrap_or(0.0) } else { num(&t[j + 1]) / fp.dbu };
                                    let y = if t[j + 2] == "*" { cur.as_ref().unwrap().pts.last().map(|p| p.1).unwrap_or(0.0) } else { num(&t[j + 2]) / fp.dbu };
                                    cur.as_mut().unwrap().pts.push((x, y));
                                    j += 3;
                                }
                                "ROUTED" | "NEW" | "FIXED" | "COVER" if t.get(j + 2).map(|w| w.parse::<f64>().is_ok()).unwrap_or(false) => {
                                    if let Some(c) = cur.take() { shapes.push(c); }
                                    cur = Some(SpecialShape { net: net.clone(), layer: t[j + 1].clone(), width: num(&t[j + 2]) / fp.dbu, ..Default::default() });
                                    j += 2;
                                }
                                "SHAPE" => { shape = t.get(j + 1).cloned().unwrap_or_default(); if let Some(c) = cur.as_mut() { c.kind = shape.clone(); } j += 1; }
                                "RECT" => {
                                    if let Some(c) = cur.take() { shapes.push(c); }
                                    let ly = t.get(j + 1).cloned().unwrap_or_default();
                                    if let Some(r) = rect_at(&t, j + 2, fp.dbu) {
                                        shapes.push(SpecialShape { net: net.clone(), layer: ly, kind: "RING".into(), pts: vec![(r.0, r.1), (r.2, r.3)], rect: Some(r), ..Default::default() });
                                        j += 8;
                                    } else { j += 1; }
                                }
                                "USE" => { use_ = t.get(j + 1).cloned().unwrap_or_default(); j += 1; }
                                _ => {}
                            }
                            j += 1;
                        }
                        if let Some(c) = cur.take() { shapes.push(c); }
                        let _ = (&use_, &shape);
                        for (k, mut sh) in shapes.into_iter().enumerate() {
                            sh.kind = match sh.kind.as_str() { "RING" => "seal_ring", "IOWIRE" => "rdl", "STRIPE" => "stripe", _ => "wire" }.into();
                            if sh.pts.len() >= 2 {
                                sh.name = format!("def_{}_{}", net, k);
                                fp.special.push(sh);
                            }
                        }
                        for b in fp.bumps.iter_mut().filter(|b| b.net == net) {
                            b.kind = match use_.as_str() { "POWER" => "power", "GROUND" => "ground", _ => "signal" }.into();
                        }
                        i = j + 1;
                        continue;
                    }
                    i += 1;
                }
                i += 2;
            }
            "BLOCKAGES" => {
                i += 3;
                while i < t.len() && !section_end(&t, i, "BLOCKAGES") {
                    if t[i] == "-" {
                        let kind = t[i + 1].clone();
                        let mut j = i + 2;
                        let mut layer = None;
                        let mut pk = PbKind::Hard;
                        let mut rects = vec![];
                        if kind == "LAYER" {
                            layer = t.get(j).cloned();
                            j += 1;
                        }
                        while j < t.len() && t[j] != ";" && t[j] != "-" {
                            match t[j].as_str() {
                                "SOFT" => pk = PbKind::Soft,
                                "PARTIAL" => pk = PbKind::Partial(t.get(j + 1).map(|x| num(x)).unwrap_or(50.0)),
                                "RECT" => {
                                    if let Some(r) = rect_at(&t, j + 1, fp.dbu) {
                                        rects.push(r);
                                        j += 7;
                                    }
                                }
                                _ => {}
                            }
                            j += 1;
                        }
                        for r in rects {
                            if kind == "PLACEMENT" {
                                let n = fp.fresh("def_pblk");
                                fp.pblk.push(PBlockage { name: n, rect: r, kind: pk.clone(), source: "def".into() });
                            } else {
                                let n = fp.fresh("def_rblk");
                                fp.rblk.push(RBlockage { name: n, rect: r, layers: layer.clone().into_iter().collect(), source: "def".into() });
                            }
                        }
                        i = j;
                        if i < t.len() && t[i] == ";" {
                            i += 1;
                        }
                        continue;
                    }
                    i += 1;
                }
                i += 2;
            }
            "REGIONS" => {
                i += 3;
                while i < t.len() && !section_end(&t, i, "REGIONS") {
                    if t[i] == "-" {
                        let name = t[i + 1].clone();
                        let mut j = i + 2;
                        let mut r = None;
                        let mut k = BoundKind::Hard;
                        while j < t.len() && t[j] != ";" {
                            if t[j] == "(" && r.is_none() {
                                r = rect_at(&t, j, fp.dbu);
                                j += 7;
                                continue;
                            }
                            if t[j] == "FENCE" {
                                k = BoundKind::Exclusive
                            }
                            if t[j] == "GUIDE" {
                                k = BoundKind::Soft
                            }
                            j += 1;
                        }
                        if let Some(r) = r {
                            regions.insert(name, (r, k));
                        }
                        i = j + 1;
                        continue;
                    }
                    i += 1;
                }
                i += 2;
            }
            "GROUPS" => {
                i += 3;
                while i < t.len() && !section_end(&t, i, "GROUPS") {
                    if t[i] == "-" {
                        let name = t[i + 1].clone();
                        let mut j = i + 2;
                        let mut mem = vec![];
                        let mut reg = None;
                        while j < t.len() && t[j] != ";" {
                            if t[j] == "+" {
                                if t.get(j + 1).map(|s| s == "REGION").unwrap_or(false) {
                                    reg = t.get(j + 2).cloned();
                                    j += 3;
                                    continue;
                                }
                                j += 2;
                                continue;
                            }
                            mem.push(t[j].replace('\\', ""));
                            j += 1;
                        }
                        groups.push((name, mem, reg));
                        i = j + 1;
                        continue;
                    }
                    i += 1;
                }
                i += 2;
            }
            _ => i += 1,
        }
    }
    if fp.die.2 <= fp.die.0 {
        return Err(format!("{}: DIEAREA missing or invalid (DEF-010)", path));
    }
    row_ys.sort_by(|a, b| a.partial_cmp(b).unwrap());
    fp.row_h = row_ys.windows(2).map(|w| w[1] - w[0]).filter(|d| *d > 0.0).fold(f64::MAX, f64::min);
    if !fp.row_h.is_finite() || fp.row_h == f64::MAX {
        fp.row_h = 1.6;
    }
    // DEF coordinates are integers: snap the row pitch to the database unit
    fp.row_h = (fp.row_h * fp.dbu).round() / fp.dbu;
    for r in &mut fp.row_list { r.height = fp.row_h; }
    // core = bounding box of the rows when it is smaller than the die
    if !row_box.is_empty() {
        let c = (row_box.iter().map(|r| r.0).fold(f64::MAX, f64::min), row_box.iter().map(|r| r.1).fold(f64::MAX, f64::min),
                 row_box.iter().map(|r| r.2).fold(f64::MIN, f64::max), row_box.iter().map(|r| r.1).fold(f64::MIN, f64::max) + fp.row_h);
        // only a complete row set (every row of the box present, a real share of the die) defines
        // a core; a margin within one row / one site of the die edge is a rows-over-die floorplan
        let complete = row_box.len() >= 4 && ((c.3 - c.1) / fp.row_h - row_box.len() as f64).abs() < 0.01
            && (c.2 - c.0) * (c.3 - c.1) >= 0.2 * (fp.die.2 - fp.die.0) * (fp.die.3 - fp.die.1);
        let inset = c.0 - fp.die.0 > 0.5 || c.1 - fp.die.1 > 0.5 || fp.die.2 - c.2 > 1.0 || fp.die.3 - c.3 > fp.row_h + 1e-3;
        if c.2 > c.0 && complete && inset {
            fp.core = Some(c);
        }
    }
    let mut used_regions = HashSet::new();
    for (g, mem, reg) in groups {
        let (r, k) = match reg.as_ref().and_then(|r| regions.get(r)) {
            Some(x) => {
                used_regions.insert(reg.clone().unwrap());
                (Some(x.0), x.1.clone())
            }
            None => (None, BoundKind::Soft),
        };
        fp.bounds.push(Bound { name: g, kind: k, rect: r, dims: None, members: mem, source: "def".into(), resolved: r });
    }
    for (rn, (r, k)) in regions {
        if !used_regions.contains(&rn) {
            fp.bounds.push(Bound { name: rn, kind: k, rect: Some(r), dims: None, members: vec![], source: "def".into(), resolved: Some(r) });
        }
    }
    Ok(fp)
}

pub fn write_def(path: &str, nl: &Netlist, fp: &Floorplan) -> std::io::Result<()> {
    write_def_routed(path, nl, fp, None)
}

/// DEF with optional detailed routes (NETS + ROUTED, VIAS section)
pub const DEF_SECTIONS: &[&str] = &["die_area", "rows", "tracks", "vias", "components", "pins", "blockages", "regions", "nets", "specialnets", "scanchains", "routing"];

#[derive(Clone, Debug)]
pub struct DefOpts {
    pub sections: HashSet<String>,
    /// COMPONENTS limited to fixed cells and macros (floorplan DEF)
    pub fixed_components_only: bool,
    pub version: String,
    pub site: f64,
    /// site name written on the implicit rows
    pub site_name: String,
    /// pre-rendered SCANCHAINS entries
    pub scanchains: Vec<String>,
    /// supply nets: (name, is_power)
    pub supplies: Vec<(String, bool)>,
    /// NONDEFAULTRULES entries and net -> rule
    pub ndr: Vec<String>,
    pub net_ndr: std::collections::HashMap<String, String>,
}

impl DefOpts {
    pub fn all() -> DefOpts {
        DefOpts { sections: DEF_SECTIONS.iter().map(|s| s.to_string()).collect(), fixed_components_only: false, version: "5.8".into(), site: 0.2, site_name: "coreSite".into(), scanchains: vec![], supplies: vec![], ndr: vec![], net_ndr: Default::default() }
    }
}

pub fn write_def_routed(path: &str, nl: &Netlist, fp: &Floorplan, routes: Option<&crate::droute::RouteDb>) -> std::io::Result<()> {
    write_def_sections(path, nl, fp, routes, &DefOpts::all()).map(|_| ())
}

/// DEF writer by section; returns the sections written
/// SPECIALNETS entries: supply nets, bump connections and special wiring (seal ring, RDL,
/// manual wires). Paths are written as ROUTED centre lines (45-degree RDL segments included),
/// rectangles as RECT.
pub fn special_nets_def(fp: &Floorplan, supplies: &[(String, bool)]) -> Vec<String> {
    use std::fmt::Write;
    let u = |v: f64| (v * fp.dbu).round() as i64;
    let mut names: Vec<String> = supplies.iter().map(|x| x.0.clone()).collect();
    for sh in &fp.special {
        if !names.contains(&sh.net) { names.push(sh.net.clone()); }
    }
    for b in &fp.bumps {
        if !b.net.is_empty() && !names.contains(&b.net) { names.push(b.net.clone()); }
    }
    let mut out = vec![];
    for n in names {
        let mut e = format!("  - {}", n);
        let bumps: Vec<&Bump> = fp.bumps.iter().filter(|b| b.net == n).collect();
        let mut conn = false;
        for b in &bumps {
            let _ = write!(e, " ( {} PAD )", b.name);
            conn = true;
        }
        if !conn && supplies.iter().any(|x| x.0 == n) {
            let _ = write!(e, " ( * {} )", n);
        }
        let mut first = true;
        for sh in fp.special.iter().filter(|x| x.net == n) {
            let shape = match sh.kind.as_str() { "seal_ring" | "ring" => "RING", "block_ring" => "BLOCKRING", "rdl" => "IOWIRE", "stripe" | "pg_wire" => "STRIPE", "followpin" => "FOLLOWPIN", "strap" => "BLOCKWIRE", _ => "" };
            if let (Some(v), Some(r)) = (&sh.via, sh.rect) {
                let _ = write!(e, "\n    {} {} 0 + SHAPE STRIPE ( {} {} ) {}", if first { "+ ROUTED" } else { "  NEW" }, v.lower, u((r.0 + r.2) / 2.0), u((r.1 + r.3) / 2.0), pg_via_name(v));
                first = false;
                continue;
            }
            if let (Some(r), false) = (sh.rect, ["ring", "block_ring", "stripe", "followpin", "strap", "pg_wire"].contains(&sh.kind.as_str())) {
                let _ = write!(e, "\n    + RECT {} ( {} {} ) ( {} {} )", sh.layer, u(r.0), u(r.1), u(r.2), u(r.3));
            } else if let Some(r) = sh.rect.filter(|_| crate::pg::is_pg_kind(&sh.kind)) {
                // power shape: centre line along its long side, width = the short side (ends extend by half the width)
                let (w, h) = (r.2 - r.0, r.3 - r.1);
                let (p0, p1, wd) = if w >= h { (((r.0 + h / 2.0), (r.1 + r.3) / 2.0), ((r.2 - h / 2.0), (r.1 + r.3) / 2.0), h) } else { (((r.0 + r.2) / 2.0, r.1 + w / 2.0), ((r.0 + r.2) / 2.0, r.3 - w / 2.0), w) };
                let _ = write!(e, "\n    {} {} {}{} ( {} {} ) ( {} {} )", if first { "+ ROUTED" } else { "  NEW" }, sh.layer, u(wd),
                    if shape.is_empty() { String::new() } else { format!(" + SHAPE {}", shape) }, u(p0.0), u(p0.1), u(p1.0), u(p1.1));
                first = false;
            } else if sh.pts.len() >= 2 {
                let pts: Vec<String> = sh.pts.iter().map(|p| format!("( {} {} )", u(p.0), u(p.1))).collect();
                let _ = write!(e, "\n    {} {} {}{} {}", if first { "+ ROUTED" } else { "  NEW" }, sh.layer, u(sh.width),
                    if shape.is_empty() { String::new() } else { format!(" + SHAPE {}", shape) }, pts.join(" "));
                first = false;
            }
        }
        let use_ = if let Some(x) = supplies.iter().find(|x| x.0 == n) { if x.1 { "POWER" } else { "GROUND" } }
            else if let Some(b) = bumps.first() { match b.kind.as_str() { "power" => "POWER", "ground" => "GROUND", _ => "SIGNAL" } }
            else if fp.special.iter().any(|x| x.net == n && x.kind == "seal_ring") { "GROUND" }
            else if fp.special.iter().any(|x| x.net == n && crate::pg::is_pg_kind(&x.kind)) { let up = n.to_uppercase(); if up.contains("VSS") || up.contains("GND") { "GROUND" } else { "POWER" } }
            else { "SIGNAL" };
        let _ = write!(e, "\n    + USE {} ;", use_);
        out.push(e);
    }
    out
}

/// DEF name of a generated via array
pub fn pg_via_name(v: &ViaArr) -> String { format!("{}_{}x{}", v.rule, v.cols, v.rows) }
fn pg_via_def(n: &str, v: &ViaArr, cut: &str, dbu: f64) -> String {
    let u = |x: f64| (x * dbu).round() as i64;
    format!("  - {} + VIARULE {} + CUTSIZE {} {} + LAYERS {} {} {} + CUTSPACING {} {} + ENCLOSURE {} {} {} {} + ROWCOL {} {} ;", n, v.rule, u(v.cut_w), u(v.cut_h), v.lower, cut, v.upper, u(v.sp_x), u(v.sp_y), u(v.enc.0), u(v.enc.1), u(v.enc.2), u(v.enc.3), v.rows, v.cols)
}

pub fn write_def_sections(path: &str, nl: &Netlist, fp: &Floorplan, routes: Option<&crate::droute::RouteDb>, o: &DefOpts) -> std::io::Result<Vec<String>> {
    use std::fmt::Write;
    let on = |k: &str| o.sections.contains(k);
    let mut wrote: Vec<String> = vec![];
    let mut s = String::new();
    let u = |v: f64| (v * fp.dbu).round() as i64;
    let _ = writeln!(s, "VERSION {} ;\nDIVIDERCHAR \"/\" ;\nBUSBITCHARS \"[]\" ;\nDESIGN {} ;\nUNITS DISTANCE MICRONS {} ;\n", o.version, nl.name, fp.dbu as i64);
    if on("die_area") {
        let _ = writeln!(s, "DIEAREA ( {} {} ) ( {} {} ) ;\n", u(fp.die.0), u(fp.die.1), u(fp.die.2), u(fp.die.3));
        wrote.push("die_area".into());
    }
    if on("rows") && fp.rows_explicit && !fp.row_list.is_empty() {
        for r in &fp.row_list {
            let _ = writeln!(s, "ROW {} {} {} {} {} DO {} BY 1 STEP {} 0 ;", r.name, r.site, u(r.x), u(r.y), r.orient, r.nsites, u(r.step));
        }
        let _ = writeln!(s);
        wrote.push("rows".into());
    } else if on("rows") && fp.row_h > 0.0 {
        let site = o.site;
        let reg = fp.place_region();
        let n = ((reg.2 - reg.0) / site).floor() as i64;
        let mut y = reg.1;
        let mut k = 0;
        while y + fp.row_h <= reg.3 + 1e-9 {
            let _ = writeln!(s, "ROW ROW_{} {} {} {} {} DO {} BY 1 STEP {} 0 ;", k, o.site_name, u(reg.0), u(y), if k % 2 == 0 { "N" } else { "FS" }, n, u(site));
            y += fp.row_h;
            k += 1;
        }
        let _ = writeln!(s);
        wrote.push("rows".into());
    }
    if on("tracks") && !fp.track_list.is_empty() {
        for t in &fp.track_list {
            let m = match (t.mask, t.same_mask) { (Some(m), true) => format!(" MASK {} SAMEMASK", m), (Some(m), false) => format!(" MASK {}", m), _ => String::new() };
            let _ = writeln!(s, "TRACKS {} {} DO {} STEP {}{} LAYER {} ;", t.dir, u(t.start), t.num, u(t.step), m, t.layer);
        }
        let _ = writeln!(s);
        wrote.push("tracks".into());
    } else if on("tracks") && !fp.layers.is_empty() {
        // tracks start one pitch inside the die origin (pin slots are on these tracks)
        for l in &fp.layers {
            let (lo, hi, axis) = if l.horiz { (fp.die.1, fp.die.3, "Y") } else { (fp.die.0, fp.die.2, "X") };
            let n = (((hi - lo) / l.pitch) - 1e-6).floor() as i64;
            if n > 0 {
                let _ = writeln!(s, "TRACKS {} {} DO {} STEP {} LAYER {} ;", axis, u(lo + l.pitch), n, u(l.pitch), l.name);
            }
        }
        let _ = writeln!(s);
        wrote.push("tracks".into());
    }
    if on("components") {
    let cells: Vec<CellId> = nl
        .cell_ids()
        .into_iter()
        .filter(|c| !matches!(nl.cell(*c).kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) && !nl.cell(*c).is_hport())
        .filter(|c| !o.fixed_components_only || nl.cell(*c).fixed || matches!(nl.cell(*c).kind, Kind::BlackBox(_)))
        .collect();
    let _ = writeln!(s, "COMPONENTS {} ;", cells.len() + fp.bumps.len());
    for c in &cells {
        let cell = nl.cell(*c);
        let model = match &cell.kind {
            Kind::Lib(l) => l.clone(),
            Kind::BlackBox(m) => m.clone(),
            Kind::Gen(g) => format!("GEN_{:?}", g),
        };
        match cell.loc {
            Some((x, y)) => {
                let o = cell.attrs.iter().find_map(|a| a.strip_prefix("orient:")).unwrap_or("N");
                let _ = writeln!(s, "  - {} {} + {} ( {} {} ) {} ;", cell.name, model, if cell.fixed { "FIXED" } else { "PLACED" }, u(x), u(y), o);
            }
            None => {
                let _ = writeln!(s, "  - {} {} ;", cell.name, model);
            }
        }
    }
    // flip-chip bumps: COVER components at the bump centre
    for b in &fp.bumps {
        let _ = writeln!(s, "  - {} {} + SOURCE DIST + COVER ( {} {} ) N ;", b.name, b.cell, u(b.x), u(b.y));
    }
    let _ = writeln!(s, "END COMPONENTS\n");
        wrote.push("components".into());
    }
    if on("pins") {
    let ports = nl.port_ids();
    let _ = writeln!(s, "PINS {} ;", ports.len());
    for p in &ports {
        let pt = &nl.ports[*p];
        let dir = match pt.dir {
            Dir::In => "INPUT",
            Dir::Out => "OUTPUT",
            Dir::InOut => "INOUT",
        };
        let net = pt.net.map(|n| nl.net(n).name.clone()).unwrap_or(pt.name.clone());
        let (side, layer) = fp.pin_info.get(&pt.name).map(|x| (x.0.clone(), x.1.clone())).unwrap_or_default();
        let orient = match side.as_str() {
            "left" => "E",
            "right" => "W",
            "top" => "S",
            _ => "N",
        };
        let lay = if layer.is_empty() {
            String::new()
        } else {
            // pin shape in the pin's own orientation frame: width along the edge, length into the die
            let (w, d) = fp.pin_shapes.get(&pt.name).copied().unwrap_or_else(|| crate::fplan::pin_shape(&fp.block_pins, &fp.layers, &layer));
            format!(" + LAYER {} ( {} 0 ) ( {} {} )", layer, -u(w / 2.0), u(w / 2.0), u(d))
        };
        match pt.loc {
            Some((x, y)) => {
                let st = if fp.fixed_ports.contains(&pt.name) { "FIXED" } else { "PLACED" };
                let _ = writeln!(s, "  - {} + NET {} + DIRECTION {} + USE SIGNAL{} + {} ( {} {} ) {} ;", pt.name, net, dir, lay, st, u(x), u(y), orient);
            }
            None => {
                let _ = writeln!(s, "  - {} + NET {} + DIRECTION {} + USE SIGNAL ;", pt.name, net, dir);
            }
        }
    }
    let _ = writeln!(s, "END PINS\n");
        wrote.push("pins".into());
    }
    let nb = fp.pblk.len() + fp.rblk.len();
    if on("blockages") && nb > 0 {
        wrote.push("blockages".into());
        let _ = writeln!(s, "BLOCKAGES {} ;", nb);
        for b in &fp.pblk {
            let k = match b.kind {
                PbKind::Soft => " + SOFT".to_string(),
                PbKind::Partial(p) => format!(" + PARTIAL {}", p),
                _ => String::new(),
            };
            let _ = writeln!(s, "  - PLACEMENT{} RECT ( {} {} ) ( {} {} ) ;", k, u(b.rect.0), u(b.rect.1), u(b.rect.2), u(b.rect.3));
        }
        for b in &fp.rblk {
            let lays: Vec<String> = if b.layers.is_empty() { fp.layers.iter().map(|l| l.name.clone()).collect() } else { b.layers.clone() };
            for l in lays {
                let _ = writeln!(s, "  - LAYER {} RECT ( {} {} ) ( {} {} ) ;", l, u(b.rect.0), u(b.rect.1), u(b.rect.2), u(b.rect.3));
            }
        }
        let _ = writeln!(s, "END BLOCKAGES\n");
    }
    let rb: Vec<&Bound> = fp.bounds.iter().filter(|b| b.resolved.is_some()).collect();
    if on("regions") && !rb.is_empty() {
        wrote.push("regions".into());
        let _ = writeln!(s, "REGIONS {} ;", rb.len());
        for b in &rb {
            let r = b.resolved.unwrap();
            let ty = match b.kind {
                BoundKind::Exclusive => " + TYPE FENCE",
                BoundKind::Soft => " + TYPE GUIDE",
                BoundKind::Hard => "",
            };
            let _ = writeln!(s, "  - {} ( {} {} ) ( {} {} ){} ;", b.name, u(r.0), u(r.1), u(r.2), u(r.3), ty);
        }
        let _ = writeln!(s, "END REGIONS\n");
        let _ = writeln!(s, "GROUPS {} ;", rb.len());
        for b in &rb {
            let mem: Vec<String> = b.members.iter().map(|m| if m.contains('*') { m.clone() } else { format!("{}/*", m) }).collect();
            let _ = writeln!(s, "  - {} {} + REGION {} ;", b.name, mem.join(" "), b.name);
        }
        let _ = writeln!(s, "END GROUPS\n");
    }
    let nets = nl.net_ids();
    let routes = if on("routing") { routes } else { None };
    // generated power vias: one VIARULE-based definition per (rule, cut array)
    let mut pgv: Vec<(String, &crate::phys::ViaArr, String)> = vec![];
    for sh in fp.special.iter().filter(|x| x.kind == "pg_via") {
        if let Some(v) = &sh.via {
            let n = pg_via_name(v);
            if !pgv.iter().any(|q| q.0 == n) { pgv.push((n, v, sh.layer.clone())); }
        }
    }
    let nrv = routes.filter(|_| on("vias")).map(|db| db.layers.len().saturating_sub(1)).unwrap_or(0);
    if on("vias") && nrv == 0 && !pgv.is_empty() {
        wrote.push("vias".into());
        let _ = writeln!(s, "VIAS {} ;", pgv.len());
        for (n, v, cut) in &pgv { let _ = writeln!(s, "{}", pg_via_def(n, v, cut, fp.dbu)); }
        let _ = writeln!(s, "END VIAS\n");
    }
    if !o.ndr.is_empty() {
        let _ = writeln!(s, "NONDEFAULTRULES {} ;\n{}\nEND NONDEFAULTRULES\n", o.ndr.len(), o.ndr.join("\n"));
        wrote.push("nondefaultrules".into());
    }
    if let Some(db) = routes.filter(|_| on("vias")) {
        wrote.push("vias".into());
        let half = (db.g * 0.35 * fp.dbu).round() as i64;
        let _ = writeln!(s, "VIAS {} ;", db.layers.len().saturating_sub(1) + pgv.len());
        for (n, v, cut) in &pgv { let _ = writeln!(s, "{}", pg_via_def(n, v, cut, fp.dbu)); }
        for i in 0..db.layers.len().saturating_sub(1) {
            let _ = writeln!(s, "  - VIA{}{} + RECT {} ( -{} -{} ) ( {} {} ) + RECT {} ( -{} -{} ) ( {} {} ) ;", i + 1, i + 2, db.layers[i].name, half, half, half, half, db.layers[i + 1].name, half, half, half, half);
        }
        let _ = writeln!(s, "END VIAS\n");
    }
    if on("specialnets") {
        let sn = special_nets_def(fp, &o.supplies);
        if !sn.is_empty() {
            let _ = writeln!(s, "SPECIALNETS {} ;", sn.len());
            for e in &sn {
                let _ = writeln!(s, "{}", e);
            }
            let _ = writeln!(s, "END SPECIALNETS\n");
            wrote.push("specialnets".into());
        }
    }
    if !on("nets") {
        if on("scanchains") && !o.scanchains.is_empty() {
            let _ = writeln!(s, "SCANCHAINS {} ;\n{}\nEND SCANCHAINS\n", o.scanchains.len(), o.scanchains.join("\n"));
            wrote.push("scanchains".into());
        }
        let _ = writeln!(s, "END DESIGN");
        std::fs::write(path, s)?;
        return Ok(wrote);
    }
    wrote.push("nets".into());
    if routes.is_some() {
        wrote.push("routing".into());
    }
    // one DEF net per logical net: segments behind hierarchy boundary pins are merged into the
    // segment that drives them (the root), which lists every leaf pin of the net
    let behind_boundary = |n: NetId| nl.driver(n).map(|d| nl.cell_is_hport(d)).unwrap_or(false);
    let nets: Vec<_> = nets.into_iter().filter(|n| !nl.net(*n).conns.is_empty() && !behind_boundary(*n)).collect();
    let _ = writeln!(s, "NETS {} ;", nets.len());
    for n in nets {
        let _ = write!(s, "  - {}", nl.net(n).name);
        let conns: Vec<PinRef> = if nl.net(n).conns.iter().any(|p| nl.cell_is_hport(*p)) { crate::session::Session::leaf_conns(nl, n) } else { nl.net(n).conns.clone() };
        for pr in &conns {
            match pr {
                PinRef::Cell(c, _) if nl.cell(*c).is_hport() => {}
                PinRef::Cell(c, p) => {
                    let _ = write!(s, " ( {} {} )", nl.cell(*c).name, nl.cell(*c).pins[*p].name);
                }
                PinRef::Port(p) => {
                    let _ = write!(s, " ( PIN {} )", nl.ports[*p].name);
                }
            }
        }
        if let Some(r) = o.net_ndr.get(&nl.net(n).name) {
            let _ = write!(s, " + NONDEFAULTRULE {}", r);
        }
        if let Some(rn) = routes.and_then(|db| db.nets.get(&n).map(|r| (db, r))) {
            let (db, r) = rn;
            let st = crate::droute::def_routes(db, r, fp.dbu);
            for (i, w) in st.iter().enumerate() {
                let _ = write!(s, "\n    {} {}", if i == 0 { "+ ROUTED" } else { "  NEW" }, w);
            }
        }
        let _ = writeln!(s, " ;");
    }
    let _ = writeln!(s, "END NETS\n");
    if on("scanchains") && !o.scanchains.is_empty() {
        let _ = writeln!(s, "SCANCHAINS {} ;\n{}\nEND SCANCHAINS\n", o.scanchains.len(), o.scanchains.join("\n"));
        wrote.push("scanchains".into());
    }
    let _ = writeln!(s, "END DESIGN");
    std::fs::write(path, s)?;
    Ok(wrote)
}

