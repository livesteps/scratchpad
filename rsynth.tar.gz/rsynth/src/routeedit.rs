//! Manual route editing on the detailed-route database.
//!
//!  add_wire  -net N -layer L -points {x0 y0 x1 y1 ...}      (orthogonal segments)
//!  delete_wire -net N [-layer L] [-area {x0 y0 x1 y1}]       (whole net when no area)
//!  cut_wire  -net N -at {x y} [-layer L] [-gap um]
//!  add_via   -net N -at {x y} -from L1 -to L2 [-type VIA23_2CUT]
//!  delete_via -net N -at {x y} [-from L1 -to L2]
//!  swap_via  [-net pats] -to_type T [-from_type pat] [-area {..}]   e.g. VIA12_2CUT (factor 1/2)
//!  report_route_edits
//!
//! Every edit rebuilds the net's tree from its remaining edges (breadth-first from the root);
//! pieces no longer connected are dropped and the net is flagged open when a pin is lost.
//! Routed parasitics are re-extracted after each edit.

use crate::droute::{RNet, RouteDb, NONE};
use crate::netlist::*;
use crate::session::{args, Session};
use crate::tcl::{err, split_list, Flow, R};
use std::collections::{HashMap, HashSet, VecDeque};

/// via resistance factor from the type name: *_<n>CUT -> 1/n, *_BAR -> 0.6
pub fn via_factor(t: &str) -> f64 {
    let u = t.to_uppercase();
    if let Some(i) = u.rfind('_') {
        let s = &u[i + 1..];
        if let Some(k) = s.strip_suffix("CUT").and_then(|k| k.parse::<f64>().ok()) {
            if k >= 1.0 { return 1.0 / k; }
        }
        if s == "BAR" { return 0.6; }
    }
    1.0
}

/// rebuild a net tree from undirected edges, keeping the component of `root`
fn rebuild(rn: &mut RNet, edges: &[(u32, u32)], root: u32) {
    let mut adj: HashMap<u32, Vec<u32>> = HashMap::new();
    for (a, b) in edges {
        adj.entry(*a).or_default().push(*b);
        adj.entry(*b).or_default().push(*a);
    }
    let mut tree = vec![(root, NONE)];
    let mut seen: HashSet<u32> = [root].into_iter().collect();
    let mut q: VecDeque<u32> = [root].into_iter().collect();
    while let Some(n) = q.pop_front() {
        if let Some(v) = adj.get(&n) {
            for m in v {
                if seen.insert(*m) {
                    tree.push((*m, n));
                    q.push_back(*m);
                }
            }
        }
    }
    rn.tree = tree;
    rn.open = rn.pins.iter().any(|(_, a)| !seen.contains(a));
}

fn edges_of(rn: &RNet) -> Vec<(u32, u32)> {
    rn.tree.iter().filter(|(_, p)| *p != NONE).copied().collect()
}

impl Session {
    pub fn routeedit_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "add_wire" | "create_wire" => self.c_add_wire(a),
            "delete_wire" | "delete_routes" => self.c_delete_wire(a, false),
            "cut_wire" => self.c_delete_wire(a, true),
            "add_via" | "create_via" => self.c_add_via(a),
            "delete_via" => self.c_delete_via(a),
            "swap_via" | "replace_via" => self.c_swap_via(a),
            "report_route_edits" => self.c_report_edits(a),
            "get_route_segments" => self.c_route_segs(a),
            _ => return self.ecomask_cmd(name, a),
        })
    }

    fn edit_ctx(&self, net: &str) -> Result<NetId, Flow> {
        let nl = self.nl()?;
        let n = nl.net_by_name(net).or_else(|| nl.port_by_name(net).and_then(|p| nl.ports[p].net)).ok_or_else(|| Flow::Err(format!("net '{}' not found (ROUTE-201)", net)))?;
        if self.routes.is_none() {
            return err("route edit: the design is not routed (route_detail) (ROUTE-200)");
        }
        Ok(n)
    }
    fn layer_idx(db: &RouteDb, l: &str) -> Result<usize, Flow> {
        db.layers.iter().position(|x| x.name == l).ok_or_else(|| Flow::Err(format!("routing layer '{}' unknown (ROUTE-202)", l)))
    }

    /// apply new tree edges to occupancy and the edit log; returns (opened, shorts)
    fn commit_edit(&mut self, n: NetId, old: Vec<u32>, what: String) -> (bool, usize) {
        let db = self.routes.as_mut().unwrap();
        for o in &old {
            let v = &mut db.occ[*o as usize];
            *v = v.saturating_sub(1);
        }
        let mut shorts = 0;
        let new: Vec<u32> = db.nets[&n].tree.iter().map(|x| x.0).collect();
        let oldset: HashSet<u32> = old.iter().copied().collect();
        for m in &new {
            let v = &mut db.occ[*m as usize];
            if *v > 0 && !oldset.contains(m) { shorts += 1; }
            *v += 1;
        }
        let open = db.nets[&n].open;
        self.route_edits.push(what);
        self.refresh_rc();
        self.gr_cache_clear();
        (open, shorts)
    }

    fn c_add_wire(&mut self, a: &[String]) -> R {
        let x = args(a, &["-net", "-layer", "-points"]);
        let net = x.get("-net").cloned().ok_or_else(|| Flow::Err("add_wire: -net required (CMD-001)".into()))?;
        let n = self.edit_ctx(&net)?;
        let pts = crate::chipfp::nums(x.get("-points").map(|s| s.as_str()).unwrap_or(""));
        if pts.len() < 4 || pts.len() % 2 != 0 {
            return err("add_wire: -points {x0 y0 x1 y1 ...} needs at least two points (CMD-001)");
        }
        let db = self.routes.as_mut().unwrap();
        let l = Session::layer_idx(db, x.get("-layer").map(|s| s.as_str()).unwrap_or("M2"))?;
        let mut new_edges = vec![];
        for k in (0..pts.len() - 2).step_by(2) {
            let (a0, a1) = (db.snap((pts[k], pts[k + 1])), db.snap((pts[k + 2], pts[k + 3])));
            if a0.0 != a1.0 && a0.1 != a1.1 {
                return err(&format!("add_wire: segment ({}, {}) - ({}, {}) is not orthogonal (ROUTE-204)", pts[k], pts[k + 1], pts[k + 2], pts[k + 3]));
            }
            let (mut cx, mut cy) = a0;
            while (cx, cy) != a1 {
                let (nx, ny) = (if cx < a1.0 { cx + 1 } else if cx > a1.0 { cx - 1 } else { cx }, if cy < a1.1 { cy + 1 } else if cy > a1.1 { cy - 1 } else { cy });
                let (p, q) = (db.node(cx, cy, l), db.node(nx, ny, l));
                if db.blocked[q as usize] {
                    crate::warn!("ROUTE-205", "add_wire: {} crosses a routing obstruction at ({:.2}, {:.2})", net, db.pos(q).0, db.pos(q).1);
                }
                new_edges.push((p, q));
                cx = nx; cy = ny;
            }
        }
        let rn = db.nets.entry(n).or_insert_with(|| RNet { net: n, ..Default::default() });
        let old: Vec<u32> = rn.tree.iter().map(|x| x.0).collect();
        let touch = old.iter().any(|o| new_edges.iter().any(|(a, b)| a == o || b == o)) || rn.pins.iter().any(|(_, p)| new_edges.iter().any(|(a, b)| a == p || b == p));
        if !touch {
            return err(&format!("add_wire: the wire does not touch net '{}' (its route or a pin access point) (ROUTE-203)", net));
        }
        let root = rn.tree.first().map(|r| r.0).or(rn.pins.first().map(|p| p.1)).unwrap_or(new_edges[0].0);
        let mut e = edges_of(rn);
        e.extend(new_edges.iter().copied());
        let was_open = rn.open;
        rebuild(rn, &e, root);
        let len = new_edges.len() as f64 * db.g;
        let (open, sh) = self.commit_edit(n, old, format!("add_wire {} {:.2} um", net, len));
        crate::info!("ROUTE-210", "add_wire: {} +{:.2} um{}{}", net, len, if was_open && !open { ", net now connected" } else if open { ", net still open" } else { "" },
            if sh > 0 { format!(", {} node(s) shared with other nets (short)", sh) } else { String::new() });
        Ok(format!("{}", if open { 1 } else { 0 }))
    }

    fn c_delete_wire(&mut self, a: &[String], cut: bool) -> R {
        let x = args(a, &["-net", "-layer", "-area", "-at", "-gap"]);
        let net = x.get("-net").cloned().ok_or_else(|| Flow::Err("delete_wire: -net required (CMD-001)".into()))?;
        let n = self.edit_ctx(&net)?;
        let db = self.routes.as_mut().unwrap();
        let lay = match x.get("-layer") { Some(l) => Some(Session::layer_idx(db, l)?), None => None };
        let area: Option<(f64, f64, f64, f64)> = if cut {
            let p = crate::chipfp::nums(x.get("-at").map(|s| s.as_str()).ok_or_else(|| Flow::Err("cut_wire: -at {x y} required (CMD-001)".into()))?);
            if p.len() < 2 { return err("cut_wire: -at {x y} (CMD-001)"); }
            let g = x.num("-gap").unwrap_or(db.g) / 2.0;
            Some((p[0] - g, p[1] - g, p[0] + g, p[1] + g))
        } else {
            x.get("-area").and_then(|s| crate::fpcmd::parse_rect(s))
        };
        let Some(mut rn) = db.nets.remove(&n) else { return err(&format!("delete_wire: net '{}' has no route (ROUTE-206)", net)) };
        let rn = &mut rn;
        let old: Vec<u32> = rn.tree.iter().map(|x| x.0).collect();
        let inside = |m: u32| -> bool {
            let (px, py, l) = db.pos(m);
            lay.map(|y| y == l).unwrap_or(true) && area.map(|r| px >= r.0 - 1e-9 && px <= r.2 + 1e-9 && py >= r.1 - 1e-9 && py <= r.3 + 1e-9).unwrap_or(true)
        };
        let pinset: HashSet<u32> = rn.pins.iter().map(|p| p.1).collect();
        let e0 = edges_of(rn);
        // an edge goes when an end is a removed node (pin access nodes stay)
        let removed: HashSet<u32> = old.iter().copied().filter(|m| inside(*m) && !pinset.contains(m)).collect();
        let mut e: Vec<(u32, u32)> = e0.iter().copied().filter(|(a, b)| !removed.contains(a) && !removed.contains(b)).collect();
        if cut && removed.is_empty() {
            // the cut falls between two nodes: drop the edge nearest the point
            if let Some(r) = area {
                let c = ((r.0 + r.2) / 2.0, (r.1 + r.3) / 2.0);
                if let Some((k, _)) = e.iter().enumerate().filter(|(_, (a, b))| { let (_, _, la) = db.pos(*a); let (_, _, lb) = db.pos(*b); la == lb && lay.map(|y| y == la).unwrap_or(true) })
                    .map(|(k, (a, b))| { let (ax, ay, _) = db.pos(*a); let (bx, by, _) = db.pos(*b); (k, ((ax + bx) / 2.0 - c.0).abs() + ((ay + by) / 2.0 - c.1).abs()) })
                    .min_by(|a, b| a.1.partial_cmp(&b.1).unwrap()) { e.remove(k); }
            }
        }
        let dropped = e0.len() - e.len();
        if dropped == 0 {
            db.nets.insert(n, rn.clone());
            return err(&format!("{}: nothing of net '{}' in the given area / layer (ROUTE-207)", if cut { "cut_wire" } else { "delete_wire" }, net));
        }
        let root = rn.tree.first().map(|r| r.0).unwrap_or(NONE);
        let root = if removed.contains(&root) { rn.pins.first().map(|p| p.1).unwrap_or(root) } else { root };
        rebuild(rn, &e, root);
        let kept = rn.tree.len().saturating_sub(1);
        db.nets.insert(n, rn.clone());
        let lost = e.len() - kept.min(e.len());
        let g = db.g;
        let (open, _) = self.commit_edit(n, old, format!("{} {} {} edge(s)", if cut { "cut_wire" } else { "delete_wire" }, net, dropped));
        crate::info!("ROUTE-211", "{}: {} removed {} unit edge(s) ({:.2} um){}; {}", if cut { "cut_wire" } else { "delete_wire" }, net, dropped + lost, (dropped + lost) as f64 * g,
            if lost > 0 { format!(" incl. {} disconnected", lost) } else { String::new() }, if open { "net is OPEN" } else { "net still connected" });
        Ok(format!("{}", if open { 1 } else { 0 }))
    }

    fn via_at(&self, a: &crate::session::A) -> Result<(NetId, String, (usize, usize), usize, usize), Flow> {
        let net = a.get("-net").cloned().ok_or_else(|| Flow::Err("via edit: -net required (CMD-001)".into()))?;
        let n = self.edit_ctx(&net)?;
        let db = self.routes.as_ref().unwrap();
        let p = crate::chipfp::nums(a.get("-at").map(|s| s.as_str()).ok_or_else(|| Flow::Err("via edit: -at {x y} required (CMD-001)".into()))?);
        if p.len() < 2 { return err("via edit: -at {x y} (CMD-001)"); }
        let xy = db.snap((p[0], p[1]));
        let l1 = match a.get("-from") { Some(l) => Session::layer_idx(db, l)?, None => 0 };
        let l2 = match a.get("-to") { Some(l) => Session::layer_idx(db, l)?, None => db.layers.len() - 1 };
        Ok((n, net, xy, l1.min(l2), l1.max(l2)))
    }

    fn c_add_via(&mut self, a: &[String]) -> R {
        let x = args(a, &["-net", "-at", "-from", "-to", "-type"]);
        if x.get("-from").is_none() || x.get("-to").is_none() {
            return err("add_via: -from and -to layers required (CMD-001)");
        }
        let (n, net, xy, lo, hi) = self.via_at(&x)?;
        if lo == hi { return err("add_via: -from and -to are the same layer (ROUTE-208)"); }
        let ty = x.get("-type").cloned();
        let db = self.routes.as_mut().unwrap();
        let stack: Vec<u32> = (lo..=hi).map(|l| db.node(xy.0, xy.1, l)).collect();
        let rn = db.nets.entry(n).or_insert_with(|| RNet { net: n, ..Default::default() });
        let old: Vec<u32> = rn.tree.iter().map(|x| x.0).collect();
        if !stack.iter().any(|s| old.contains(s) || rn.pins.iter().any(|p| p.1 == *s)) {
            return err(&format!("add_via: no route or pin of '{}' at that point on {}..{} (ROUTE-203)", net, db.layers[lo].name, db.layers[hi].name));
        }
        let mut e = edges_of(rn);
        for w in stack.windows(2) {
            if !e.iter().any(|(a, b)| (*a == w[0] && *b == w[1]) || (*a == w[1] && *b == w[0])) { e.push((w[0], w[1])); }
        }
        let root = rn.tree.first().map(|r| r.0).unwrap_or(stack[0]);
        rebuild(rn, &e, root);
        if let Some(t) = &ty {
            for s in &stack[..stack.len() - 1] { db.via_types.insert(*s, (t.clone(), via_factor(t))); }
        }
        let (open, sh) = self.commit_edit(n, old, format!("add_via {} {}", net, hi - lo));
        crate::info!("ROUTE-212", "add_via: {} {} cut(s) {}..{}{}{}{}", net, hi - lo, self.routes.as_ref().unwrap().layers[lo].name, self.routes.as_ref().unwrap().layers[hi].name,
            ty.map(|t| format!(" type {} (R x{:.2})", t, via_factor(&t))).unwrap_or_default(), if open { ", net open" } else { "" }, if sh > 0 { format!(", {} short node(s)", sh) } else { String::new() });
        Ok(String::new())
    }

    fn c_delete_via(&mut self, a: &[String]) -> R {
        let x = args(a, &["-net", "-at", "-from", "-to"]);
        let (n, net, xy, lo, hi) = self.via_at(&x)?;
        let db = self.routes.as_mut().unwrap();
        let Some(mut rn) = db.nets.remove(&n) else { return err("delete_via: net not routed (ROUTE-206)") };
        let rn = &mut rn;
        let old: Vec<u32> = rn.tree.iter().map(|x| x.0).collect();
        let e0 = edges_of(rn);
        let is_via = |a: u32, b: u32| { let (ax, ay, la) = db.xyl(a); let (bx, by, lb) = db.xyl(b); ax == xy.0 && ay == xy.1 && bx == xy.0 && by == xy.1 && la != lb && la.min(lb) >= lo && la.max(lb) <= hi };
        let e: Vec<(u32, u32)> = e0.iter().copied().filter(|(a, b)| !is_via(*a, *b)).collect();
        let k = e0.len() - e.len();
        if k == 0 { db.nets.insert(n, rn.clone()); return err(&format!("delete_via: no via of '{}' there (ROUTE-207)", net)); }
        for l in lo..hi { let nd = db.node(xy.0, xy.1, l); db.via_types.remove(&nd); }
        let root = rn.tree[0].0;
        rebuild(rn, &e, root);
        db.nets.insert(n, rn.clone());
        let (open, _) = self.commit_edit(n, old, format!("delete_via {} {}", net, k));
        crate::info!("ROUTE-213", "delete_via: {} removed {} cut(s); {}", net, k, if open { "net is OPEN" } else { "net still connected" });
        Ok(format!("{}", if open { 1 } else { 0 }))
    }

    fn c_swap_via(&mut self, a: &[String]) -> R {
        let x = args(a, &["-net", "-nets", "-to_type", "-from_type", "-area"]);
        let to = x.get("-to_type").cloned().ok_or_else(|| Flow::Err("swap_via: -to_type required (CMD-001)".into()))?;
        let from = x.get("-from_type").cloned();
        let pats: Vec<String> = x.get("-net").or(x.get("-nets")).map(|s| split_list(s)).unwrap_or_else(|| vec!["*".into()]);
        let area = x.get("-area").and_then(|s| crate::fpcmd::parse_rect(s));
        let nl = self.nl()?;
        // a net matches by its own name or by the name of a port on it
        let mut names: HashMap<NetId, Vec<String>> = nl.net_ids().into_iter().map(|n| (n, vec![nl.net(n).name.clone()])).collect();
        for p in nl.port_ids() {
            if let Some(n) = nl.ports[p].net { names.entry(n).or_default().push(nl.ports[p].name.clone()); }
        }
        let db = self.routes.as_mut().ok_or_else(|| Flow::Err("swap_via: not routed (ROUTE-200)".into()))?;
        // explicit layer pair in the target name: VIA12_* -> cut between layer 1 and 2
        let pair: Option<usize> = to.to_uppercase().strip_prefix("VIA").and_then(|s| s.chars().next()).and_then(|c| c.to_digit(10)).map(|d| d as usize - 1);
        let f = via_factor(&to);
        let mut k = 0;
        let mut ids: Vec<NetId> = db.nets.keys().copied().collect();
        ids.sort();
        for n in ids {
            if !pats.iter().any(|q| names.get(&n).map(|v| v.iter().any(|s| glob(q, s))).unwrap_or(false)) { continue; }
            let tree = db.nets[&n].tree.clone();
            for (c, p) in tree {
                if p == NONE { continue; }
                let (cx, cy, lc) = db.xyl(c);
                let (_, _, lp) = db.xyl(p);
                if lc == lp { continue; }
                let lo = if lc < lp { c } else { p };
                let ll = lc.min(lp);
                if let Some(pl) = pair { if pl != ll { continue; } }
                let cur = db.via_types.get(&lo).map(|v| v.0.clone()).unwrap_or(format!("VIA{}{}", ll + 1, ll + 2));
                if let Some(fp) = &from { if !glob(fp, &cur) { continue; } }
                if let Some(r) = area {
                    let px = db.x0 + cx as f64 * db.g; let py = db.y0 + cy as f64 * db.g;
                    if px < r.0 || px > r.2 || py < r.1 || py > r.3 { continue; }
                }
                db.via_types.insert(lo, (to.clone(), f));
                k += 1;
            }
        }
        self.route_edits.push(format!("swap_via {} -> {}", k, to));
        self.refresh_rc();
        self.gr_cache_clear();
        crate::info!("ROUTE-214", "swap_via: {} via(s) -> {} (resistance x{:.2})", k, to, f);
        Ok(k.to_string())
    }

    /// straight runs of a routed net: {layer x0 y0 x1 y1} ... (vias as {VIAij x y x y})
    fn c_route_segs(&mut self, a: &[String]) -> R {
        let x = args(a, &["-net", "-layer"]);
        let net = x.get("-net").cloned().or(x.pos.first().cloned()).ok_or_else(|| Flow::Err("get_route_segments: -net required (CMD-001)".into()))?;
        let n = self.edit_ctx(&net)?;
        let db = self.routes.as_ref().unwrap();
        let Some(rn) = db.nets.get(&n) else { return Ok(String::new()) };
        let mut segs: Vec<(usize, (f64, f64), (f64, f64))> = vec![];
        for (c, p) in &rn.tree {
            if *p == NONE { continue; }
            let (x1, y1, l1) = db.pos(*c);
            let (x2, y2, l2) = db.pos(*p);
            if l1 != l2 { segs.push((usize::MAX - l1.min(l2), (x1, y1), (x2, y2))); continue; }
            // merge collinear unit edges (parent-before-child order: runs grow at their end)
            let pp = (x2, y2);
            if let Some(s) = segs.iter_mut().find(|s| s.0 == l1 && s.2 == pp && ((s.1 .0 == s.2 .0 && x1 == x2) || (s.1 .1 == s.2 .1 && y1 == y2))) {
                s.2 = (x1, y1);
                continue;
            }
            segs.push((l1, (x2, y2), (x1, y1)));
        }
        // longest runs first (vias last)
        segs.sort_by(|a, b| { let l = |s: &(usize, (f64, f64), (f64, f64))| (s.1 .0 - s.2 .0).abs() + (s.1 .1 - s.2 .1).abs(); l(b).partial_cmp(&l(a)).unwrap() });
        let want = x.get("-layer").cloned();
        let out: Vec<String> = segs.iter().filter_map(|(l, a, b)| {
            let name = if *l > db.layers.len() { let k = usize::MAX - l; format!("VIA{}{}", k + 1, k + 2) } else { db.layers[*l].name.clone() };
            if want.as_ref().map(|w| *w != name).unwrap_or(false) { return None; }
            Some(format!("{{{} {:.2} {:.2} {:.2} {:.2}}}", name, a.0, a.1, b.0, b.1))
        }).collect();
        Ok(out.join(" "))
    }

    fn c_report_edits(&mut self, _a: &[String]) -> R {
        let db = self.routes.as_ref().ok_or_else(|| Flow::Err("not routed (ROUTE-200)".into()))?;
        let st = crate::droute::stats(db);
        crate::out!("Route edits ({}):", self.route_edits.len());
        for e in &self.route_edits {
            crate::out!("  {}", e);
        }
        let mut vt: HashMap<String, usize> = HashMap::new();
        for v in db.via_types.values() { *vt.entry(v.0.clone()).or_default() += 1; }
        let mut v: Vec<String> = vt.iter().map(|(k, n)| format!("{} {}", k, n)).collect();
        v.sort();
        crate::out!("  nets {}, opens {}, wirelength {:.1} um, vias {}, typed vias [{}]", st.nets, st.opens, st.wl, st.vias, v.join(", "));
        Ok(st.opens.to_string())
    }
}
