//! Physical-only cells (fillers, decaps, well taps, end caps) and un-placement, Innovus style
//! (legacy camelCase names are accepted as aliases):
//!
//!  add_endcaps / addEndCap      [-pre_cap|-preCap cell] [-post_cap|-postCap cell] [-prefix ENDCAP]
//!  add_well_taps / addWellTap   -cell cell [-cell_interval|-cellInterval um] [-checkerboard] [-prefix WELLTAP]
//!  add_decaps / addDeCap        [-cells {..}] [-count n] [-area {x1 y1 x2 y2}] [-prefix DECAP]
//!  add_fillers / addFiller      [-cells|-cell {..}] [-area {..}] [-prefix FILL]
//!  delete_fillers / deleteFiller [-prefix p] [-cells {..}] [-area {..}]   (also deleteDeCap,
//!                                deleteWellTap, deleteEndCap; delete_physical_cells [-type t])
//!  report_physical_cells
//!  unplace [-inst pats | pats] [-all_std_cells] [-macros] [-physical_cells] [-pads] [-all]
//!          [-area {..}] [-override_fixed]   (unplaceAllInsts = -all_std_cells, unplaceAllBlocks = -macros)
//!
//! Inserted cells are fixed and dont_touch (the legalizer treats them as obstacles); a cell is
//! physical-only when its LEF class is CORE SPACER / CORE WELLTAP / CORE ANTENNACELL / ENDCAP, or
//! its library cell has no signal pins.

use crate::netlist::*;
use crate::phys::RowRec;
use crate::session::{args, Session};
use crate::tcl::{err, split_list, Flow, R};

type Rect = (f64, f64, f64, f64);
const EPS: f64 = 1e-6;

fn parse_rect(s: &str) -> Option<Rect> {
    let v: Vec<f64> = s.replace(['{', '}'], " ").split_whitespace().filter_map(|x| x.parse().ok()).collect();
    if v.len() < 4 { return None; }
    Some((v[0].min(v[2]), v[1].min(v[3]), v[0].max(v[2]), v[1].max(v[3])))
}

impl Session {
    pub fn physcells_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "add_endcaps" | "addEndCap" | "add_endcap" | "add_end_caps" => self.c_add_endcaps(a),
            "add_well_taps" | "addWellTap" | "add_well_tap" | "add_tap_cells" => self.c_add_well_taps(a),
            "add_decaps" | "addDeCap" | "add_decap" => self.c_add_fill(a, "decap"),
            "add_fillers" | "addFiller" | "add_filler" | "add_filler_cells" | "place_filler" => self.c_add_fill(a, "filler"),
            "delete_fillers" | "deleteFiller" | "delete_filler" | "remove_fillers" => self.c_delete_phys(a, Some("filler")),
            "delete_decaps" | "deleteDeCap" | "delete_decap" => self.c_delete_phys(a, Some("decap")),
            "delete_well_taps" | "deleteWellTap" | "delete_well_tap" => self.c_delete_phys(a, Some("welltap")),
            "delete_endcaps" | "deleteEndCap" | "delete_endcap" => self.c_delete_phys(a, Some("endcap")),
            "delete_physical_cells" | "remove_physical_cells" => self.c_delete_phys(a, None),
            "report_physical_cells" => self.c_report_phys(),
            "unplace" | "unplace_obj" | "unplace_cells" | "unplace_instances" => self.c_unplace(a, ""),
            "unplaceAllInsts" | "unplace_all_insts" => self.c_unplace(a, "std"),
            "unplaceAllBlocks" | "unplace_all_blocks" => self.c_unplace(a, "macros"),
            _ => return None,
        })
    }

    /// filler | decap | welltap | endcap | antenna, for physical-only masters
    pub(crate) fn phys_kind_of(&self, master: &str) -> Option<&'static str> {
        let up = master.to_uppercase();
        if let Some(m) = self.lef.get(master) {
            let c = m.class.to_uppercase();
            if c.starts_with("ENDCAP") { return Some("endcap"); }
            if c.contains("WELLTAP") { return Some("welltap"); }
            if c.contains("ANTENNACELL") { return Some("antenna"); }
            if c.contains("SPACER") { return Some(if up.contains("DECAP") || up.contains("DCAP") { "decap" } else { "filler" }); }
        }
        let lc = self.libs.iter().find_map(|l| l.cells.get(master))?;
        if lc.pins.iter().any(|p| p.dir.is_some()) || lc.tie.is_some() { return None; }
        Some(if up.contains("DECAP") || up.contains("DCAP") { "decap" } else if up.contains("TAP") { "welltap" } else if up.contains("ENDCAP") || up.contains("BOUNDARY") { "endcap" } else { "filler" })
    }

    fn master_w(&self, m: &str) -> f64 {
        let (sw, rh) = (self.site_w(), self.row_h());
        if let Some(l) = self.lef.get(m) { if l.w > 0.0 { return l.w; } }
        let a = self.libs.iter().find_map(|l| l.cells.get(m)).map(|c| c.area).unwrap_or(rh * sw);
        ((a / rh / sw) - EPS).ceil().max(1.0) * sw
    }
    /// LEF-abstract (non-CORE) cells are placed by their lower-left corner, the others by the centre
    fn lowerleft(&self, m: &str) -> bool { self.lef.get(m).map(|l| !l.class.starts_with("CORE")).unwrap_or(false) }

    /// rows as segments (explicit rows, or the implicit tiling of the core)
    pub(crate) fn row_segments(&self) -> Result<Vec<RowRec>, Flow> {
        let fp = self.fp.as_ref().ok_or_else(|| Flow::Err("No floorplan: initialize_floorplan or read_def first (FP-001)".into()))?;
        if fp.rows_explicit { return Ok(fp.row_list.clone()); }
        let (sw, rh) = (self.site_w(), self.row_h());
        let site_name = self.core_site_name();
        let reg = fp.place_region();
        // the legalizer keeps one row of margin when no core is defined
        let core = if fp.core.is_some() { reg } else { (reg.0 + rh, reg.1 + rh, reg.2 - rh, reg.3 - rh) };
        let n = ((core.2 - core.0) / sw + EPS).floor() as usize;
        let mut v = vec![];
        let mut y = core.1;
        let mut k = 0;
        while y + rh <= core.3 + EPS {
            v.push(RowRec { name: format!("ROW_{}", k), site: site_name.clone(), x: core.0, y, orient: if k % 2 == 0 { "N".into() } else { "FS".into() }, nsites: n, step: sw, height: rh });
            y += rh;
            k += 1;
        }
        Ok(v)
    }

    /// occupied x-intervals per row y (placed cells, hard blockages)
    fn row_obstacles(&self, rows: &[RowRec]) -> Vec<Vec<(f64, f64)>> {
        let rh = self.row_h();
        let mut rects: Vec<Rect> = vec![];
        if let Some(nl) = self.nl.as_ref() {
            for c in nl.cell_ids() {
                let cl = nl.cell(c);
                if cl.is_hport() || matches!(cl.kind, Kind::Gen(_)) { continue; }
                if let Some(r) = crate::lef::cell_rect(&self.lef, cl) { rects.push(r); continue; }
                let Some(l) = cl.loc else { continue };
                if matches!(cl.kind, Kind::BlackBox(_)) { let s = 16.0; rects.push((l.0 - s / 2.0, l.1 - s / 2.0, l.0 + s / 2.0, l.1 + s / 2.0)); continue; }
                let w = cl.lib().map(|m| self.master_w(m)).unwrap_or(self.site_w());
                rects.push((l.0 - w / 2.0, l.1 - rh / 2.0, l.0 + w / 2.0, l.1 + rh / 2.0));
            }
        }
        if let Some(fp) = &self.fp {
            for b in &fp.pblk { if matches!(b.kind, crate::fplan::PbKind::Hard | crate::fplan::PbKind::HardMacro) { rects.push(b.rect); } }
        }
        rows.iter().map(|r| {
            let mut iv: Vec<(f64, f64)> = rects.iter().filter(|q| q.1 < r.y + r.height - 1e-3 && q.3 > r.y + 1e-3 && q.0 < r.x1() - 1e-3 && q.2 > r.x + 1e-3).map(|q| (q.0, q.2)).collect();
            iv.sort_by(|a, b| a.partial_cmp(b).unwrap());
            iv
        }).collect()
    }

    fn free_gaps(r: &RowRec, obs: &[(f64, f64)], area: Option<Rect>) -> Vec<(f64, f64)> {
        let (mut lo, mut hi) = (r.x, r.x1());
        if let Some(a) = area { if r.y < a.1 - EPS || r.y + r.height > a.3 + EPS { return vec![]; } lo = lo.max(a.0); hi = hi.min(a.2); }
        let mut gaps = vec![];
        let mut cur = lo;
        for &(a0, a1) in obs {
            if a1 <= cur + EPS { continue; }
            if a0 > cur + EPS { gaps.push((cur, a0.min(hi))); }
            cur = cur.max(a1);
            if cur >= hi { break; }
        }
        if cur < hi - EPS { gaps.push((cur, hi)); }
        // snap to the row's site grid
        gaps.into_iter().map(|(g0, g1)| (r.x + ((g0 - r.x) / r.step - EPS).ceil() * r.step, r.x + ((g1 - r.x) / r.step + EPS).floor() * r.step)).filter(|g| g.1 - g.0 > EPS).collect()
    }

    fn place_phys(&mut self, name: &str, master: &str, x0: f64, r: &RowRec, kind: &str) -> Result<(), Flow> {
        let w = self.master_w(master);
        let ll = self.lowerleft(master);
        let c = self.make_inst(name, master)?;
        let nl = self.nl.as_mut().unwrap();
        let cl = nl.cell_mut(c);
        cl.loc = Some(if ll { (x0, r.y) } else { (x0 + w / 2.0, r.y + r.height / 2.0) });
        if !r.orient.is_empty() && r.orient != "N" { cl.attrs.push(format!("orient:{}", r.orient)); }
        cl.fixed = true;
        cl.dont_touch = true;
        cl.attrs.push(format!("phys:{}", kind));
        Ok(())
    }

    fn uniq(&self, prefix: &str, k: &mut usize) -> String {
        let nl = self.nl.as_ref().unwrap();
        loop {
            *k += 1;
            let n = format!("{}_{}", prefix, k);
            if nl.cell_by_name(&n).is_none() { return n; }
        }
    }

    fn need_master(&self, m: &str, cmd: &str) -> Result<(), Flow> {
        if self.libs.iter().any(|l| l.cells.contains_key(m)) || self.lef.contains_key(m) { Ok(()) } else { Err(Flow::Err(format!("{}: cell '{}' is in no library or LEF (PHY-001)", cmd, m))) }
    }

    fn masters_of_kind(&self, kind: &str) -> Vec<String> {
        let mut v: Vec<String> = self.libs.iter().flat_map(|l| l.cells.keys().cloned()).chain(self.lef.keys().cloned()).filter(|m| self.phys_kind_of(m) == Some(kind)).collect();
        v.sort();
        v.dedup();
        v
    }

    fn c_add_endcaps(&mut self, a: &[String]) -> R {
        let x = args(a, &["-pre_cap", "-preCap", "-post_cap", "-postCap", "-prefix", "-cell"]);
        let eps_ = self.masters_of_kind("endcap");
        let pre = x.get("-pre_cap").or(x.get("-preCap")).or(x.get("-cell")).cloned().or_else(|| eps_.first().cloned()).ok_or_else(|| Flow::Err("add_endcaps: no end-cap cell (give -pre_cap) (PHY-010)".into()))?;
        let post = x.get("-post_cap").or(x.get("-postCap")).cloned().or_else(|| eps_.iter().find(|m| m.ends_with('R') || m.to_uppercase().contains("POST")).cloned()).unwrap_or(pre.clone());
        self.need_master(&pre, "add_endcaps")?;
        self.need_master(&post, "add_endcaps")?;
        let prefix = x.get("-prefix").cloned().unwrap_or("ENDCAP".into());
        let rows = self.row_segments()?;
        let obs = self.row_obstacles(&rows);
        let (wpre, wpost) = (self.master_w(&pre), self.master_w(&post));
        let (mut n, mut skipped, mut k) = (0, 0, 0usize);
        for (r, ob) in rows.iter().zip(obs.iter()) {
            // the two ends of the row segment
            let free = |x0: f64, x1: f64| !ob.iter().any(|o| o.0 < x1 - 1e-3 && o.1 > x0 + 1e-3);
            if r.x1() - r.x < wpre + wpost - EPS { skipped += 1; continue; }
            if free(r.x, r.x + wpre) { let nm = self.uniq(&prefix, &mut k); self.place_phys(&nm, &pre, r.x, r, "endcap")?; n += 1; } else { skipped += 1; }
            if free(r.x1() - wpost, r.x1()) { let nm = self.uniq(&prefix, &mut k); self.place_phys(&nm, &post, r.x1() - wpost, r, "endcap")?; n += 1; } else { skipped += 1; }
        }
        crate::info!("PHY-011", "add_endcaps: {} end cap(s) ({} / {}) on {} row segment(s){}", n, pre, post, rows.len(), if skipped > 0 { format!(", {} row end(s) occupied or too short", skipped) } else { String::new() });
        Ok(n.to_string())
    }

    fn c_add_well_taps(&mut self, a: &[String]) -> R {
        let x = args(a, &["-cell", "-cell_interval", "-cellInterval", "-prefix", "-max_gap", "-area"]);
        let cell = x.get("-cell").cloned().or_else(|| self.masters_of_kind("welltap").first().cloned()).ok_or_else(|| Flow::Err("add_well_taps: -cell <tap cell> required (PHY-020)".into()))?;
        self.need_master(&cell, "add_well_taps")?;
        let iv = x.num("-cell_interval").or(x.num("-cellInterval")).or(x.num("-max_gap").map(|g| g * 2.0)).unwrap_or(30.0);
        if iv <= 0.0 { return err("add_well_taps: -cell_interval must be > 0 (PHY-021)"); }
        let prefix = x.get("-prefix").cloned().unwrap_or("WELLTAP".into());
        let area = x.get("-area").and_then(|s| parse_rect(s));
        let cb = x.has("-checkerboard");
        let rows = self.row_segments()?;
        let obs = self.row_obstacles(&rows);
        let w = self.master_w(&cell);
        let (mut n, mut k, mut missed) = (0, 0usize, 0);
        for (ri, (r, ob)) in rows.iter().zip(obs.iter()).enumerate() {
            let gaps = Self::free_gaps(r, ob, area);
            let off = if cb && ((r.y / r.height).round() as usize + ri * 0) % 2 == 1 { iv / 2.0 } else { 0.0 };
            let mut t = r.x + off;
            while t < r.x1() - EPS {
                // the first free slot at or after t inside the interval
                let snapped = r.x + ((t - r.x) / r.step - EPS).ceil() * r.step;
                let slot = gaps.iter().find_map(|g| { let s = snapped.max(g.0); if s + w <= g.1 + EPS && s < t + iv { Some(s) } else { None } });
                match slot {
                    Some(s) => { let nm = self.uniq(&prefix, &mut k); self.place_phys(&nm, &cell, s, r, "welltap")?; n += 1; }
                    None => missed += 1,
                }
                t += iv;
            }
        }
        crate::info!("PHY-022", "add_well_taps: {} {} tap(s), interval {} um{}{}", n, cell, iv, if cb { " (checkerboard)" } else { "" }, if missed > 0 { format!(", {} interval(s) without a free slot", missed) } else { String::new() });
        Ok(n.to_string())
    }

    fn c_add_fill(&mut self, a: &[String], kind: &str) -> R {
        let x = args(a, &["-cells", "-cell", "-prefix", "-area", "-count"]);
        let cmd = if kind == "decap" { "add_decaps" } else { "add_fillers" };
        let mut cells: Vec<String> = x.get("-cells").or(x.get("-cell")).map(|s| split_list(s)).unwrap_or_else(|| self.masters_of_kind(kind));
        if cells.is_empty() { return err(&format!("{}: no {} cells (give -cells) (PHY-030)", cmd, kind)); }
        for c in &cells { self.need_master(c, cmd)?; }
        let mut cw: Vec<(String, f64)> = cells.drain(..).map(|m| { let w = self.master_w(&m); (m, w) }).collect();
        cw.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
        let prefix = x.get("-prefix").cloned().unwrap_or(if kind == "decap" { "DECAP".into() } else { "FILL".into() });
        let area = x.get("-area").and_then(|s| parse_rect(s));
        let maxn = x.num("-count").map(|v| v as usize).unwrap_or(usize::MAX);
        let rows = self.row_segments()?;
        let obs = self.row_obstacles(&rows);
        let (mut n, mut k, mut fa, mut left) = (0usize, 0usize, 0.0, 0.0);
        'rows: for (r, ob) in rows.iter().zip(obs.iter()) {
            for (g0, g1) in Self::free_gaps(r, ob, area) {
                let mut p = g0;
                for (m, w) in &cw {
                    while p + w <= g1 + EPS {
                        if n >= maxn { break 'rows; }
                        let nm = self.uniq(&prefix, &mut k);
                        self.place_phys(&nm, m, p, r, kind)?;
                        p += w;
                        fa += w * r.height;
                        n += 1;
                    }
                }
                left += g1 - p;
            }
        }
        crate::info!("PHY-031", "{}: {} {} cell(s) ({}), {:.1} um2{}", cmd, n, kind, cw.iter().map(|c| c.0.clone()).collect::<Vec<_>>().join(" "), fa,
            if left > EPS { format!("; {:.2} um of row left unfilled (no cell narrow enough)", left) } else { String::new() });
        Ok(n.to_string())
    }

    fn c_delete_phys(&mut self, a: &[String], kind: Option<&str>) -> R {
        let x = args(a, &["-prefix", "-cells", "-cell", "-area", "-type"]);
        let kind: Option<String> = kind.map(|s| s.to_string()).or(x.get("-type").cloned());
        let prefix = x.get("-prefix").cloned();
        let masters: Vec<String> = x.get("-cells").or(x.get("-cell")).map(|s| split_list(s)).unwrap_or_default();
        let area = x.get("-area").and_then(|s| parse_rect(s));
        let nl = self.nl.as_ref().ok_or_else(|| Flow::Err("no design".into()))?;
        let mut del = vec![];
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            let Some(m) = cl.lib().map(|s| s.to_string()).or_else(|| if let Kind::BlackBox(b) = &cl.kind { Some(b.clone()) } else { None }) else { continue };
            let Some(pk) = self.phys_kind_of(&m) else { continue };
            if let Some(k) = &kind { if k != "all" && k != pk { continue; } }
            if let Some(p) = &prefix { if !cl.name.starts_with(p.as_str()) { continue; } }
            if !masters.is_empty() && !masters.iter().any(|p| glob(p, &m)) { continue; }
            if let (Some(r), Some(l)) = (area, cl.loc) { if l.0 < r.0 || l.0 > r.2 || l.1 < r.1 || l.1 > r.3 { continue; } }
            del.push(c);
        }
        let nl = self.nl.as_mut().unwrap();
        for c in &del { nl.remove_cell(*c); }
        crate::info!("PHY-040", "Deleted {} physical-only {} cell(s)", del.len(), kind.unwrap_or("".into()));
        Ok(del.len().to_string())
    }

    fn c_report_phys(&mut self) -> R {
        let nl = self.nl.as_ref().ok_or_else(|| Flow::Err("no design".into()))?;
        let mut cnt: std::collections::BTreeMap<(String, String), (usize, f64)> = Default::default();
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            let Some(m) = cl.lib() else { continue };
            let Some(k) = self.phys_kind_of(m) else { continue };
            let e = cnt.entry((k.to_string(), m.to_string())).or_default();
            e.0 += 1;
            e.1 += self.master_w(m) * self.row_h();
        }
        crate::out!("****************************************\nReport : physical_cells\n****************************************\n  {:<9} {:<10} {:>7} {:>12}", "type", "cell", "count", "area (um2)");
        let mut tot = 0;
        for ((k, m), (n, a)) in &cnt { crate::out!("  {:<9} {:<10} {:>7} {:>12.2}", k, m, n, a); tot += n; }
        crate::out!("  total {} physical-only cell(s)", tot);
        Ok(tot.to_string())
    }

    fn c_unplace(&mut self, a: &[String], preset: &str) -> R {
        let x = args(a, &["-inst", "-insts", "-cells", "-area"]);
        let mut pats: Vec<String> = x.get("-inst").or(x.get("-insts")).or(x.get("-cells")).map(|s| split_list(s)).unwrap_or_default();
        pats.extend(x.pos.iter().flat_map(|p| split_list(p)).map(|p| crate::cons::Obj::parse(&p).map(|o| o.name().to_string()).unwrap_or(p)));
        let all = x.has("-all");
        let std = all || x.has("-all_std_cells") || x.has("-std_cells") || preset == "std";
        let macros = all || x.has("-macros") || x.has("-blocks") || preset == "macros";
        let physc = all || x.has("-physical_cells") || x.has("-physical_only");
        let pads = all || x.has("-pads") || x.has("-io_cells");
        let over = x.has("-override_fixed") || x.has("-force");
        let area = x.get("-area").and_then(|s| parse_rect(s));
        if pats.is_empty() && !(std || macros || physc || pads) { return err("unplace: give -inst {patterns}, -all_std_cells, -macros, -physical_cells, -pads or -all (PLC-300)"); }
        let nl = self.nl.as_ref().ok_or_else(|| Flow::Err("no design".into()))?;
        let mut pick = vec![];
        let (mut kept_fixed, mut counts) = (0, [0usize; 4]);
        for c in nl.cell_ids() {
            let cl = nl.cell(c);
            if cl.is_hport() || matches!(cl.kind, Kind::Gen(_)) || cl.loc.is_none() { continue; }
            let master = cl.lib().map(|s| s.to_string()).or_else(|| if let Kind::BlackBox(b) = &cl.kind { Some(b.clone()) } else { None }).unwrap_or_default();
            let lm = crate::lef::phys(&self.lef, cl);
            let cls = if self.phys_kind_of(&master).is_some() { 2 } else if lm.map(|m| m.is_pad() || m.is_corner()).unwrap_or(false) { 3 } else if lm.map(|m| m.is_block()).unwrap_or(false) || matches!(cl.kind, Kind::BlackBox(_)) { 1 } else { 0 };
            let by_class = match cls { 0 => std, 1 => macros, 2 => physc, _ => pads };
            let by_name = pats.iter().any(|p| glob(p, &cl.name));
            if !(by_class || by_name) { continue; }
            if let (Some(r), Some(l)) = (area, cl.loc) { if l.0 < r.0 || l.0 > r.2 || l.1 < r.1 || l.1 > r.3 { continue; } }
            if cl.fixed && !over { kept_fixed += 1; continue; }
            counts[cls] += 1;
            pick.push(c);
        }
        let nl = self.nl.as_mut().unwrap();
        for c in &pick { let cl = nl.cell_mut(*c); cl.loc = None; cl.fixed = false; }
        crate::info!("PLC-301", "Unplaced {} instance(s): {} standard cell(s), {} macro(s), {} physical-only cell(s), {} pad(s){}", pick.len(), counts[0], counts[1], counts[2], counts[3],
            if kept_fixed > 0 { format!("; {} fixed instance(s) kept (use -override_fixed)", kept_fixed) } else { String::new() });
        Ok(pick.len().to_string())
    }
}
