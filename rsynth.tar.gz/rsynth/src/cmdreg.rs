//! Complete command registry (generated at build time from the dispatchers by build.rs):
//! `help` lists every command, `help <cmd>` shows its aliases, options and syntax,
//! `list_commands` returns the names, `write_command_list` writes CSV / TSV / Markdown.

use crate::session::{args, Session};
use crate::tcl::{err, Flow, R};
use std::collections::{BTreeMap, HashMap};

include!(concat!(env!("OUT_DIR"), "/cmdreg.rs"));

#[derive(Clone, Debug)]
pub struct CmdInfo {
    pub name: &'static str,
    pub aliases: Vec<&'static str>,
    pub module: &'static str,
    pub area: String,
    pub options: Vec<&'static str>,
    pub flags: Vec<&'static str>,
    pub doc: &'static str,
}

fn module_area(m: &str) -> Option<&'static str> {
    Some(match m {
        "tcl" => "Tcl built-ins",
        "fpcmd" => "Floorplan / IO pins / GUI",
        "upf" => "UPF / low power",
        "timcmd" => "Timing analysis",
        "eco" => "ECO",
        "dbaccess" => "Database access (dbGet / properties)",
        "pnr" => "Place & route / CTS",
        "part" => "Partitioning / budgeting",
        "routeedit" => "Route edits",
        "flipchip" => "Flip-chip",
        "ecomask" => "Spare / gate-array / mask ECO",
        "chipfp" => "Chip floorplan / macros",
        "va" => "Power domains / voltage areas",
        "query" => "Query / collections",
        "models" => "Timing models",
        "dcalc" => "Delay calculation / extraction",
        "padring" => "Pad ring / ESD / seal ring",
        "hflow" => "Hierarchical implementation",
        "xout" => "Signoff export",
        "gds" => "GDS / stream out",
        "mim" => "Multiply-instantiated modules",
        "gui" | "guisch" => "GUI",
        "dftadv" => "DFT (OCC / compression / boundary scan / MBIST)",
        "rowtrack" => "Rows / tracks",
        "physcells" => "Physical cells / unplace",
        "atpg" => "ATPG / test patterns",
        "pg" => "Power grid / verification / NDR",
        "objquery" => "GUI / query & measure",
        "sitecheck" => "Placement",
        "ctspec" => "CTS",
        "tupdate" => "Timing / MMMC",
        "ioovl" => "IO / pad ring",
        "rtrules" => "Routing rules / metal fill / OPC / yield",
        "metrics" => "Logs / run metrics",
        "odb" => "Design database",
        "rtopt" => "Route options / antenna / net length / ties",
        _ => return None,
    })
}

/// area of a command of the core session module, from its name
fn name_area(n: &str) -> &'static str {
    let p = |s: &str| n.starts_with(s);
    if n.starts_with("gui_") { "GUI" }
    else if p("read_") || ["analyze", "elaborate", "link_block", "link", "set_top_module", "set_blackbox", "set_black_box", "uniquify", "remove_design", "remove_designs", "current_design"].contains(&n) { "Design input" }
    else if ["create_mode", "create_corner", "create_scenario", "current_scenario", "current_mode", "current_corner", "remove_scenarios", "set_scenario_status", "set_lib_corner"].contains(&n) { "MMMC" }
    else if p("compile") || p("insert_") || p("optimize_") || p("set_optimize") || p("pipeline") { "Optimization" }
    else if p("report_") { "Reports" }
    else if p("check_") || p("cleanup") { "Checks" }
    else if p("write_") || p("save_") { "Output" }
    else if p("get_") || p("all_") || n.contains("collection") || p("filter_") || p("sizeof") || p("index_") || p("select") || p("deselect") || p("remove_from_sel") || p("add_to_sel") { "Query / collections" }
    else if p("create_clock") || p("create_generated_clock") || p("set_") || p("remove_") || p("reset_") || p("group_path") { "Constraints / settings" }
    else { "General" }
}

pub fn all() -> &'static Vec<CmdInfo> {
    static REG: std::sync::OnceLock<Vec<CmdInfo>> = std::sync::OnceLock::new();
    REG.get_or_init(|| {
        CMD_REGISTRY.iter().map(|(names, module, opts, flags, doc)| {
            let name = names[0];
            let area = if name.starts_with("gui_") || ["write_schematic", "write_layout_image", "win"].contains(&name) { "GUI".to_string() } else if *module == "session" { name_area(name).to_string() } else { module_area(module).map(|s| s.to_string()).unwrap_or_else(|| name_area(name).to_string()) };
            CmdInfo { name, aliases: names[1..].to_vec(), module, area, options: opts.to_vec(), flags: flags.to_vec(), doc }
        }).collect()
    })
}

pub fn find(n: &str) -> Option<&'static CmdInfo> {
    all().iter().find(|c| c.name == n || c.aliases.contains(&n))
}

fn glob(p: &str, s: &str) -> bool {
    crate::netlist::glob(p, s)
}

/// Levenshtein distance (did-you-mean suggestions)
fn edit(a: &str, b: &str) -> usize {
    let (a, b): (Vec<char>, Vec<char>) = (a.chars().collect(), b.chars().collect());
    let mut prev: Vec<usize> = (0..=b.len()).collect();
    for i in 1..=a.len() {
        let mut cur = vec![i; b.len() + 1];
        for j in 1..=b.len() {
            cur[j] = (prev[j] + 1).min(cur[j - 1] + 1).min(prev[j - 1] + if a[i - 1] == b[j - 1] { 0 } else { 1 });
        }
        prev = cur;
    }
    prev[b.len()]
}

impl CmdInfo {
    pub fn usage(&self) -> String {
        let mut v = vec![self.name.to_string()];
        for o in &self.options { v.push(format!("[{} value]", o)); }
        for f in &self.flags { v.push(format!("[{}]", f)); }
        v.join(" ")
    }
}

impl Session {
    /// curated syntax line of a command (first help-group entry that starts with it)
    pub(crate) fn curated_syntax(&self, name: &str) -> Option<String> {
        for (_, cmds) in crate::session::HELP_GROUPS {
            for c in *cmds {
                let first = c.split_whitespace().next().unwrap_or("");
                if first == name || first.split('/').any(|x| x.trim() == name) {
                    return Some(c.to_string());
                }
            }
        }
        None
    }

    pub(crate) fn help_cmd(&self, topic: Option<&str>) {
        let reg = all();
        // names covered by the curated groups
        let mut covered: std::collections::HashSet<String> = std::collections::HashSet::new();
        for (_, cmds) in crate::session::HELP_GROUPS {
            for c in *cmds {
                for w in c.split(|ch: char| ch == ' ' || ch == ',' || ch == '/' || ch == '(' || ch == ')') {
                    if let Some(ci) = find(w.trim()) { covered.insert(ci.name.to_string()); }
                }
            }
        }
        match topic {
            None => {
                self.help_groups(None);
                let mut by: BTreeMap<String, Vec<&CmdInfo>> = BTreeMap::new();
                for c in reg.iter().filter(|c| !covered.contains(c.name)) { by.entry(c.area.clone()).or_default().push(c); }
                crate::out!("\nMore commands, by area (help <command> for options):");
                for (a, v) in &by {
                    crate::out!("{}:", a);
                    let names: Vec<String> = v.iter().map(|c| if c.aliases.is_empty() { c.name.to_string() } else { format!("{} ({})", c.name, c.aliases.join(", ")) }).collect();
                    // wrap at ~110 columns
                    let mut line = String::from("   ");
                    for n in names {
                        if line.len() + n.len() + 2 > 110 { crate::out!("{}", line.trim_end_matches(", ")); line = String::from("   "); }
                        line.push(' ');
                        line.push_str(&n);
                        line.push(',');
                    }
                    if line.trim().len() > 0 { crate::out!("{}", line.trim_end_matches(',')); }
                }
                let n_names: usize = reg.iter().map(|c| 1 + c.aliases.len()).sum();
                crate::out!("\n{} commands ({} names with aliases). 'help <command>', 'help <pattern>' (e.g. help *gds*, help report_t*), 'help -search <text>' (apropos), 'help -regexp <re>', 'help -area <area> <pattern>', 'help -h' for all search options; 'help -all', 'list_commands', 'write_command_list file.csv'.", reg.len(), n_names);
            }
            Some("-all") => {
                let mut by: BTreeMap<String, Vec<&CmdInfo>> = BTreeMap::new();
                for c in reg { by.entry(c.area.clone()).or_default().push(c); }
                for (a, v) in &by {
                    crate::out!("{}:", a);
                    for c in v {
                        crate::out!("    {}", self.curated_syntax(c.name).unwrap_or_else(|| c.usage()));
                        if !c.aliases.is_empty() { crate::out!("        aliases: {}", c.aliases.join(", ")); }
                    }
                }
                crate::out!("{} commands", reg.len());
            }
            Some(t) => {
                if let Some(c) = find(t) {
                    crate::out!("{}", c.name);
                    if c.name != t { crate::out!("  ('{}' is an alias of {})", t, c.name); }
                    crate::out!("  area     : {}  (module {})", c.area, c.module);
                    if !c.aliases.is_empty() { crate::out!("  aliases  : {}", c.aliases.join(", ")); }
                    crate::out!("  syntax   : {}", self.curated_syntax(c.name).or_else(|| c.aliases.iter().find_map(|a| self.curated_syntax(a))).unwrap_or_else(|| c.usage()));
                    if !c.options.is_empty() { crate::out!("  options  : {}", c.options.join(" ")); }
                    if !c.flags.is_empty() { crate::out!("  flags    : {}", c.flags.join(" ")); }
                    if !c.doc.is_empty() { crate::out!("  about    : {}", c.doc); }
                    return;
                }
                let pat = if t.contains('*') || t.contains('?') { t.to_string() } else { format!("*{}*", t) };
                let hits: Vec<&CmdInfo> = reg.iter().filter(|c| glob(&pat, c.name) || c.aliases.iter().any(|a| glob(&pat, a)) || c.area.to_lowercase().contains(&t.to_lowercase())).collect();
                self.help_groups(Some(t));
                if hits.is_empty() {
                    crate::out!("No command matches '{}'.", t);
                    return;
                }
                crate::out!("Commands matching '{}':", t);
                for c in hits {
                    crate::out!("    {:<34} {}", c.name, self.curated_syntax(c.name).map(|s| s[c.name.len().min(s.len())..].trim().to_string()).unwrap_or_else(|| c.usage()[c.name.len()..].trim().to_string()));
                }
            }
        }
    }

    /// `help` with arguments:
    ///   help <command>                      details of one command (or alias)
    ///   help <pattern> [<pattern> ...]      commands, aliases, Tcl built-ins and procs whose name
    ///                                       matches the glob (* ? [..], case-insensitive); a word
    ///                                       without wildcards matches anywhere in the name
    ///   -regexp                             patterns are regular expressions
    ///   -search | -desc | apropos           also match the syntax, options and description
    ///   -area <area>                        only commands of that area (substring)
    ///   -verbose                            full details of every match
    ///   -names                              return the matching names (no listing)
    ///   -areas                              list the areas with their command counts
    pub(crate) fn help_args(&mut self, a: &[String], cmd: &str) -> R {
        let mut pats: Vec<String> = vec![];
        let (mut re, mut desc, mut verbose, mut names_only) = (false, cmd == "apropos", false, false);
        let mut area: Option<String> = None;
        let mut i = 0;
        while i < a.len() {
            match a[i].as_str() {
                "-regexp" | "-regex" | "-re" => re = true,
                "-search" | "-desc" | "-description" | "-apropos" | "-k" => desc = true,
                "-verbose" | "-v" | "-long" => verbose = true,
                "-names" | "-list" | "-quiet" => names_only = true,
                "-area" => { area = a.get(i + 1).cloned(); i += 1; }
                "-areas" => {
                    let mut by: BTreeMap<String, usize> = BTreeMap::new();
                    for c in all() { *by.entry(c.area.clone()).or_default() += 1; }
                    crate::out!("Command areas (help -area <area> <pattern>):");
                    for (ar, n) in &by { crate::out!("    {:<48} {:>4}", ar, n); }
                    return Ok(by.len().to_string());
                }
                "-all" if pats.is_empty() && !desc && !re && area.is_none() => { self.help_cmd(Some("-all")); return Ok(String::new()); }
                "-h" | "-help" | "--help" => {
                    crate::out!("help                          overview of all commands, by area");
                    crate::out!("help <command>                options, syntax, aliases of one command");
                    crate::out!("help <pattern> ...            commands / aliases / Tcl built-ins / procs matching the glob (* ? [..], case-insensitive);");
                    crate::out!("                              a word without wildcards matches anywhere in the name (help timing == help *timing*)");
                    crate::out!("help -regexp <re> ...         regular-expression match on the names");
                    crate::out!("help -search <text>           also search syntax, options and descriptions (apropos <text>)");
                    crate::out!("help -area <area> [pattern]   only that area; help -areas lists the areas");
                    crate::out!("help -verbose <pattern>       full details of every match");
                    crate::out!("help -names <pattern>         return the matching names (for scripts), no listing");
                    crate::out!("help -all                     every command with its syntax");
                    return Ok(String::new());
                }
                o if o.starts_with('-') && o.len() > 1 && !o.contains('*') => return err(format!("help: unknown option '{}' (help -h) (CMD-020)", o)),
                p => pats.push(p.to_string()),
            }
            i += 1;
        }
        // one exact command name: the detail view
        if pats.len() == 1 && !re && !desc && area.is_none() && !names_only && find(&pats[0]).is_some() {
            self.help_cmd(Some(&pats[0]));
            return Ok(String::new());
        }
        if pats.is_empty() && area.is_none() { self.help_cmd(None); return Ok(String::new()); }
        if pats.is_empty() { pats.push("*".into()); }
        // matchers
        let mut rxs = vec![];
        if re {
            for p in &pats {
                match crate::regex::Regex::new(&format!("(?i){}", p)).or_else(|_| crate::regex::Regex::new(p)) {
                    Ok(r) => rxs.push(r),
                    Err(e) => return err(format!("help -regexp: bad expression '{}': {} (CMD-021)", p, e)),
                }
            }
        }
        let globs: Vec<String> = pats.iter().map(|p| {
            let l = p.to_lowercase();
            if l.contains('*') || l.contains('?') || l.contains('[') { l } else { format!("*{}*", l) }
        }).collect();
        let name_hit = |n: &str| -> bool {
            if re { rxs.iter().any(|r| r.is_match(n) || r.is_match(&n.to_lowercase())) } else { globs.iter().any(|g| glob(g, &n.to_lowercase())) }
        };
        let text_hit = |t: &str| -> bool {
            let tl = t.to_lowercase();
            if re { rxs.iter().any(|r| r.is_match(t) || r.is_match(&tl)) } else { pats.iter().any(|p| { let pl = p.to_lowercase(); if pl.contains('*') || pl.contains('?') { glob(&format!("*{}*", pl.trim_matches('*')), &tl) || glob(&pl, &tl) } else { tl.contains(&pl) } }) }
        };
        // (area, name, matched alias, syntax)
        let mut hits: Vec<(String, String, Option<String>, String, &'static str)> = vec![];
        for c in all() {
            if let Some(ar) = &area { if !c.area.to_lowercase().contains(&ar.to_lowercase()) { continue; } }
            let syn = self.curated_syntax(c.name).or_else(|| c.aliases.iter().find_map(|x| self.curated_syntax(x))).unwrap_or_else(|| c.usage());
            let via = if name_hit(c.name) { Some(None) } else { c.aliases.iter().find(|x| name_hit(x)).map(|x| Some(x.to_string())) };
            let via = match via {
                Some(v) => Some(v),
                None if desc && (text_hit(&syn) || text_hit(c.doc) || c.options.iter().chain(c.flags.iter()).any(|o| text_hit(o)) || text_hit(&c.area)) => Some(Some("description".to_string())),
                None => None,
            };
            if let Some(v) = via { hits.push((c.area.clone(), c.name.to_string(), v, syn, c.doc)); }
        }
        // user procs
        if area.as_ref().map(|ar| "procs".contains(&ar.to_lowercase()) || "tcl procs".contains(&ar.to_lowercase())).unwrap_or(true) {
            let mut ps: Vec<(&String, &(Vec<(String, Option<String>)>, String))> = self.interp.procs.iter().collect();
            ps.sort_by(|x, y| x.0.cmp(y.0));
            for (n, (params, body)) in ps {
                if find(n).is_some() { continue; }
                if name_hit(n) || (desc && text_hit(body)) {
                    let sig = params.iter().map(|(p, d)| match d { Some(d) => format!("{{{} {}}}", p, d), None => p.clone() }).collect::<Vec<_>>().join(" ");
                    hits.push(("Tcl procs (user)".into(), n.clone(), None, format!("{} {}", n, sig), ""));
                }
            }
        }
        hits.sort_by(|x, y| x.0.cmp(&y.0).then(x.1.cmp(&y.1)));
        hits.dedup_by(|x, y| x.1 == y.1);
        let what = pats.join(" ");
        if names_only { return Ok(hits.iter().map(|h| h.1.clone()).collect::<Vec<_>>().join(" ")); }
        // a curated group whose title matches (help dft, help "power planning")
        if !re && pats.iter().all(|p| !p.contains('*') && !p.contains('?')) && area.is_none() {
            for (g, cmds) in crate::session::HELP_GROUPS {
                if pats.iter().any(|p| g.to_lowercase().contains(&p.to_lowercase())) {
                    crate::out!("{}:", g);
                    for c in *cmds { crate::out!("    {}", c); }
                }
            }
        }
        if hits.is_empty() {
            // nearest names
            let q = pats[0].to_lowercase().replace(['*', '?'], "");
            // names holding the query as a subsequence first (rpt_timng -> report_timing), then the
            // closest by edit distance
            let subseq = |q: &str, n: &str| { let mut it = n.chars(); q.chars().all(|c| it.any(|x| x == c)) };
            let mut near: Vec<(usize, usize, &str)> = all().iter().flat_map(|c| std::iter::once(c.name).chain(c.aliases.iter().copied()))
                .map(|n| { let nl = n.to_lowercase(); (if subseq(&q, &nl) { 0 } else { 1 }, edit(&q, &nl), n) })
                .filter(|x| x.0 == 0 || x.1 <= (q.len() / 2).max(2))
                .collect();
            near.sort();
            near.dedup_by(|a, b| a.2 == b.2);
            near.truncate(5);
            let near: Vec<(usize, &str)> = near.into_iter().map(|x| (x.1, x.2)).collect();
            crate::out!("No command matches '{}'{}.", what, if desc { "" } else { " (help -search to look in the descriptions too)" });
            if !q.is_empty() && !near.is_empty() { crate::out!("Did you mean: {}", near.iter().map(|x| x.1).collect::<Vec<_>>().join(", ")); }
            return Ok(String::new());
        }
        crate::out!("Commands matching '{}'{}{}:", what, if re { " (regexp)" } else { "" }, area.as_ref().map(|ar| format!(" in area '{}'", ar)).unwrap_or_default());
        let mut cur = String::new();
        for (ar, n, via, syn, doc) in &hits {
            if *ar != cur { crate::out!("  {}:", ar); cur = ar.clone(); }
            if verbose {
                crate::out!("    {}", n);
                if let Some(v) = via { crate::out!("      matched  : {}", if v == "description" { "syntax / description".to_string() } else { format!("alias {}", v) }); }
                if let Some(c) = find(n) {
                    if !c.aliases.is_empty() { crate::out!("      aliases  : {}", c.aliases.join(", ")); }
                    crate::out!("      syntax   : {}", syn);
                    if !doc.is_empty() { crate::out!("      about    : {}", doc); }
                } else {
                    crate::out!("      syntax   : {}", syn);
                }
            } else {
                let rest = if syn.starts_with(n.as_str()) { syn[n.len()..].trim().to_string() } else { syn.clone() };
                let tag = match via { Some(v) if v == "description" => "  [description]".to_string(), Some(v) => format!("  [alias {}]", v), None => String::new() };
                let rest = if rest.chars().count() > 150 { format!("{}...", rest.chars().take(147).collect::<String>()) } else { rest };
                crate::out!("    {:<34} {}{}", n, rest, tag);
            }
        }
        crate::out!("{} command(s) match '{}'.  help <command> for details; help -h for the search options.", hits.len(), what);
        Ok(String::new())
    }

    pub fn cmdreg_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "list_commands" | "get_commands" => {
                let x = args(a, &["-area"]);
                let pat = x.pos.first().cloned().unwrap_or("*".into());
                let area = x.get("-area").cloned();
                let mut v: Vec<String> = vec![];
                for c in all() {
                    if area.as_ref().map(|ar| !c.area.to_lowercase().contains(&ar.to_lowercase())).unwrap_or(false) { continue; }
                    for n in std::iter::once(&c.name).chain(c.aliases.iter()) {
                        if glob(&pat, n) && (x.has("-aliases") || *n == c.name) { v.push(n.to_string()); }
                    }
                }
                v.sort();
                Ok(v.join(" "))
            }
            "write_command_list" => {
                let x = args(a, &["-format"]);
                let f = match x.pos.first() { Some(f) => f.clone(), None => return Some(err("write_command_list: file name required (CMD-001)")) };
                let fmt = x.get("-format").cloned().unwrap_or_else(|| if f.ends_with(".md") { "md".into() } else if f.ends_with(".tsv") { "tsv".into() } else { "csv".into() });
                let mut rows: Vec<Vec<String>> = vec![vec!["Command".into(), "Aliases".into(), "Area".into(), "Module".into(), "Syntax".into(), "Value options".into(), "Flags".into(), "Description".into()]];
                let mut v: Vec<&CmdInfo> = all().iter().collect();
                v.sort_by(|a, b| (a.area.as_str(), a.name).cmp(&(b.area.as_str(), b.name)));
                for c in v {
                    rows.push(vec![c.name.into(), c.aliases.join(" "), c.area.clone(), c.module.into(), self.curated_syntax(c.name).unwrap_or_else(|| c.usage()), c.options.join(" "), c.flags.join(" "), c.doc.into()]);
                }
                let txt = match fmt.as_str() {
                    "tsv" => rows.iter().map(|r| r.iter().map(|c| c.replace(['\t', '\n'], " ")).collect::<Vec<_>>().join("\t")).collect::<Vec<_>>().join("\n"),
                    "md" => {
                        let mut s = String::new();
                        for (i, r) in rows.iter().enumerate() {
                            s += &format!("| {} |\n", r.iter().map(|c| c.replace('|', "\\|")).collect::<Vec<_>>().join(" | "));
                            if i == 0 { s += &format!("|{}\n", "---|".repeat(r.len())); }
                        }
                        s
                    }
                    _ => rows.iter().map(|r| r.iter().map(|c| format!("\"{}\"", c.replace('"', "\"\""))).collect::<Vec<_>>().join(",")).collect::<Vec<_>>().join("\n"),
                };
                if let Err(e) = std::fs::write(&f, txt + "\n") { return Some(Err(Flow::Err(format!("write_command_list: {}: {}", f, e)))); }
                crate::info!("CMD-200", "Wrote {} commands to '{}' ({})", rows.len() - 1, f, fmt);
                Ok((rows.len() - 1).to_string())
            }
            _ => return None,
        })
    }
}

#[allow(dead_code)]
fn _area_counts() -> HashMap<String, usize> {
    let mut m = HashMap::new();
    for c in all() { *m.entry(c.area.clone()).or_default() += 1; }
    m
}
