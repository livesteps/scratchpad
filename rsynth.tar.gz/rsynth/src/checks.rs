//! Timing-constraint and design sanity checks (Tempus/PrimeTime-style check_timing,
//! Fusion-Compiler-style check_design / netlist lint).


use crate::netlist::*;
use crate::sta::{Timing, NOCLK};
use std::collections::{BTreeMap, HashSet};

pub struct CheckOpts {
    pub snake_levels: usize,
    pub snake_hier: usize,
    pub hfn: usize,
    pub verbose: bool,
}

fn section(title: &str, items: &[String], verbose: bool, id: &str) -> usize {
    if items.is_empty() {
        crate::out!("  {:<48} : PASS", title);
        return 0;
    }
    crate::out!("  {:<48} : {} issue(s)  [{}]", title, items.len(), id);
    let lim = if verbose { items.len() } else { items.len().min(10) };
    for i in &items[..lim] {
        crate::out!("      {}", i);
    }
    if lim < items.len() {
        crate::out!("      ... {} more (use -verbose)", items.len() - lim);
    }
    items.len()
}

pub fn check_timing(t: &Timing, o: &CheckOpts, include: &dyn Fn(&str) -> bool) -> usize {
    let nl = t.nl;
    let cons = t.cons;
    let mut total = 0;
    crate::out!("\n****************************************\nReport : check_timing\nDesign : {}\n****************************************", nl.name);
    // 1 unconstrained endpoints
    if include("unconstrained_endpoints") {
        total += section("Unconstrained endpoints", &t.unconstrained, o.verbose, "TIM-001");
    }
    // 2 no clock reaching registers/latches
    if include("no_clock") {
        let mut v = vec![];
        let mut seen = HashSet::new();
        for &ck in &t.clk_pins {
            if seen.insert(ck) && t.ctags[ck as usize].is_empty() && t.consts[ck as usize].is_none() {
                let cn = match t.nodes[ck as usize] {
                    PinRef::Cell(c, _) => nl.cell(c).name.clone(),
                    _ => t.node_name(ck),
                };
                let kind = t.cell_type_of(ck);
                v.push(format!("{} ({}): no clock reaches clock pin {}", cn, kind, t.node_name(ck)));
            }
        }
        // generic flops on unmapped netlists
        total += section("Registers/latches with no clock", &v, o.verbose, "TIM-002");
        let mut mc = vec![];
        let mut seen = HashSet::new();
        for &ck in &t.clk_pins {
            if seen.insert(ck) {
                let clks: HashSet<u16> = t.ctags[ck as usize].iter().map(|x| x.clk).collect();
                if clks.len() > 1 {
                    mc.push(format!("{} clocked by {} clocks: {}", t.node_name(ck), clks.len(), clks.iter().map(|c| cons.clocks[*c as usize].name.clone()).collect::<Vec<_>>().join(", ")));
                }
            }
        }
        total += section("Multiple clocks reaching register clock pin", &mc, o.verbose, "TIM-003");
    }
    // 3 min pulse width / min period
    if include("pulse_width") || include("min_period") {
        let mut pw = vec![];
        let mut mp = vec![];
        for (i, pr) in t.nodes.iter().enumerate() {
            let PinRef::Cell(c, p) = *pr else { continue };
            let cell = nl.cell(c);
            let Some(lp) = cell.lib().and_then(|l| t.libs.cell(l)).and_then(|lc| lc.pin(&cell.pins[p].name)) else { continue };
            for ct in &t.ctags[i] {
                let per = t.clk_period[ct.clk as usize];
                let (r, f) = t.clk_edges[ct.clk as usize];
                let (mut hi, mut lo) = ((f - r).rem_euclid(per), per - (f - r).rem_euclid(per));
                if ct.inv {
                    std::mem::swap(&mut hi, &mut lo);
                }
                let cn = &cons.clocks[ct.clk as usize].name;
                if let Some(m) = lp.min_pw_high {
                    if hi < m {
                        pw.push(format!("{}: high pulse {:.4} < min_pulse_width_high {:.4} (clock {}) slack {:.4}", t.node_name(i as u32), hi, m, cn, hi - m));
                    }
                }
                if let Some(m) = lp.min_pw_low {
                    if lo < m {
                        pw.push(format!("{}: low pulse {:.4} < min_pulse_width_low {:.4} (clock {}) slack {:.4}", t.node_name(i as u32), lo, m, cn, lo - m));
                    }
                }
                for (ob, m) in &cons.min_pulse_width {
                    let applies = ob.as_ref().map(|x| x.name() == cn || t.resolve(x).contains(&(i as u32))).unwrap_or(true);
                    if applies && hi.min(lo) < *m {
                        pw.push(format!("{}: pulse {:.4} < set_min_pulse_width {:.4} (clock {})", t.node_name(i as u32), hi.min(lo), m, cn));
                    }
                }
                if let Some(m) = lp.min_period {
                    if per < m {
                        mp.push(format!("{}: clock '{}' period {:.4} < library min_period {:.4} slack {:.4}", t.node_name(i as u32), cn, per, m, per - m));
                    }
                }
            }
        }
        pw.sort();
        pw.dedup();
        mp.sort();
        mp.dedup();
        if include("pulse_width") {
            total += section("Minimum pulse width", &pw, o.verbose, "TIM-010");
        }
        if include("min_period") {
            total += section("Minimum clock period", &mp, o.verbose, "TIM-011");
        }
    }
    // 4 data-to-data checks
    if include("data_check") {
        let mut v = vec![];
        for (a, b, m) in &cons.data_checks {
            v.push(format!("set_data_check from {} to {} setup {:.4} (verify both pins are timed)", a.name(), b.name(), m));
        }
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            if let Some(lc) = cell.lib().and_then(|l| t.libs.cell(l)) {
                for p in &lc.pins {
                    for a in &p.arcs {
                        if matches!(a.ttype, crate::liberty::TType::NonSeqSetup | crate::liberty::TType::NonSeqHold) {
                            v.push(format!("{}: library data-to-data (non_seq) check {} -> {}", cell.name, a.related, p.name));
                        }
                    }
                }
            }
        }
        total += section("Data-to-data checks", &v, o.verbose, "TIM-020");
    }
    // 5 clock/data mixing
    if include("clock_data_mixing") {
        total += section("Clock used as data", &t.clock_as_data, o.verbose, "TIM-030");
        let mut d = t.data_as_clock.clone();
        d.sort();
        d.dedup();
        total += section("Data signal gating clock (no ICG)", &d, o.verbose, "TIM-031");
    }
    // 6 snake / huge datapaths
    if include("snake_paths") {
        let mut v = vec![];
        for ep in &t.endpoints {
            let path = t.path(ep, false);
            let mut levels = 0;
            let mut hier_x = 0;
            let mut last_h: Option<String> = None;
            for (n, _, _) in &path {
                if let PinRef::Cell(c, p) = t.nodes[*n as usize] {
                    if nl.cell(c).pins[p].dir == Dir::Out {
                        levels += 1;
                    }
                    let h = nl.cell(c).hier_prefix().to_string();
                    if last_h.as_ref().map(|x| *x != h).unwrap_or(false) {
                        hier_x += 1;
                    }
                    last_h = Some(h);
                }
            }
            if levels > o.snake_levels || hier_x > o.snake_hier {
                v.push(format!("{}: {} logic levels, {} hierarchy crossings, slack {:.4}", ep.name, levels, hier_x, ep.setup_slack));
            }
        }
        total += section(&format!("Snake/long paths (>{} levels or >{} hier crossings)", o.snake_levels, o.snake_hier), &v, o.verbose, "TIM-040");
    }
    // 7 combinational loops (verbose)
    if include("loops") {
        let mut v = vec![];
        for (k, lp) in t.loops.iter().enumerate() {
            v.push(format!("Loop {} ({} pins):", k + 1, lp.len()));
            for p in lp {
                v.push(format!("    -> {}", p));
            }
            if let Some(b) = t.broken_arcs.iter().filter(|b| b.contains("loop breaker")).nth(k) {
                v.push(format!("    broken at: {}", b));
            }
        }
        let n = t.loops.len();
        if n == 0 {
            crate::out!("  {:<48} : PASS", "Combinational timing loops");
        } else {
            crate::out!("  {:<48} : {} loop(s)  [TIM-050]", "Combinational timing loops", n);
            for l in &v {
                crate::out!("      {}", l);
            }
            total += n;
        }
    }
    // 8 missing IO delays
    if include("io_delays") {
        let clock_ports: HashSet<String> = cons.clocks.iter().flat_map(|c| c.sources.iter().map(|o| o.name().to_string())).collect();
        let mut vi = vec![];
        let mut vo = vec![];
        for p in nl.port_ids() {
            let pt = &nl.ports[p];
            if clock_ports.contains(&pt.name) {
                continue;
            }
            let has = cons.io.iter().any(|x| x.obj.name() == pt.name && x.is_input == (pt.dir == Dir::In));
            let constant = t.idx.get(&PinRef::Port(p)).map(|n| t.consts[*n as usize].is_some()).unwrap_or(false);
            if has || constant {
                continue;
            }
            match pt.dir {
                Dir::In => vi.push(format!("{} (no set_input_delay)", pt.name)),
                Dir::Out => vo.push(format!("{} (no set_output_delay)", pt.name)),
                _ => {
                    vi.push(format!("{} (inout: no set_input_delay)", pt.name));
                }
            }
        }
        total += section("Input ports missing set_input_delay", &vi, o.verbose, "TIM-060");
        total += section("Output ports missing set_output_delay", &vo, o.verbose, "TIM-061");
    }
    // 9 latches
    if include("latches") {
        let mut v = vec![];
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            let is_latch = match &cell.kind {
                Kind::Gen(GOp::Latch) => true,
                Kind::Lib(l) => t.libs.cell(l).and_then(|x| x.seq.as_ref()).map(|s| s.is_latch).unwrap_or(false),
                _ => false,
            };
            if is_latch {
                v.push(format!("{} ({})", cell.name, t.cell_type_of(t.idx.get(&PinRef::Cell(c, 0)).copied().unwrap_or(0))));
            }
        }
        total += section("Latches (check for unintentional inference)", &v, o.verbose, "TIM-070");
    }
    // 10 multi-driven / undriven
    if include("drivers") {
        let mut md = vec![];
        let mut ud = vec![];
        for n in nl.net_ids() {
            let d = nl.drivers(n);
            if d.len() > 1 {
                md.push(format!("{}: {}", nl.net(n).name, d.iter().map(|x| nl.pin_name(*x)).collect::<Vec<_>>().join(", ")));
            }
            if d.is_empty() {
                for l in nl.loads(n) {
                    if let PinRef::Cell(..) = l {
                        ud.push(format!("{} (net '{}' has no driver)", nl.pin_name(l), nl.net(n).name));
                    }
                }
            }
        }
        for c in nl.cell_ids() {
            for p in &nl.cell(c).pins {
                if p.dir == Dir::In && p.net.is_none() && !matches!(nl.cell(c).kind, Kind::BlackBox(_)) {
                    ud.push(format!("{}/{} (unconnected input)", nl.cell(c).name, p.name));
                }
            }
        }
        total += section("Multi-driven nets", &md, o.verbose, "TIM-080");
        total += section("Undriven logic inputs", &ud, o.verbose, "TIM-081");
    }
    // 11 global DRV limits
    if include("drv_limits") {
        let mut v = vec![];
        if cons.max_tran.is_none() && t.libs.default_max_tran().is_none() {
            v.push("No global max_transition (set_max_transition on design / library default_max_transition)".into());
        }
        if cons.max_fanout.is_none() && t.libs.default_max_fanout().is_none() {
            v.push("No global max_fanout (set_max_fanout / library default_max_fanout)".into());
        }
        if cons.max_cap.is_none() && t.libs.default_max_cap().is_none() {
            v.push("No global max_capacitance (set_max_capacitance / library default_max_capacitance)".into());
        }
        total += section("Missing global DRV limits", &v, o.verbose, "TIM-090");
    }
    // 12 clocks
    if include("clocks") {
        let mut v = vec![];
        if cons.clocks.is_empty() {
            v.push("No clocks defined (create_clock)".into());
        }
        for (i, c) in cons.clocks.iter().enumerate() {
            if c.is_virtual() {
                continue;
            }
            let reaches = t.clk_pins.iter().any(|ck| t.ctags[*ck as usize].iter().any(|x| x.clk as usize == i));
            if !reaches {
                v.push(format!("Clock '{}' does not reach any register clock pin", c.name));
            }
            if c.gen.is_some() && t.ctags.iter().all(|x| !x.iter().any(|y| y.clk as usize == i)) {
                v.push(format!("Generated clock '{}' has no source path", c.name));
            }
        }
        for b in &t.broken_arcs {
            if b.contains("set_disable_timing") {
                v.push(format!("disabled arc: {}", b));
            }
        }
        total += section("Clock definition issues", &v, o.verbose, "TIM-100");
    }
    // 13 high fanout nets
    if include("high_fanout") {
        let mut v: Vec<(usize, String)> = vec![];
        for n in nl.net_ids() {
            let f = nl.loads(n).len();
            if f > o.hfn {
                v.push((f, format!("{}: fanout {}", nl.net(n).name, f)));
            }
        }
        v.sort_by(|a, b| b.0.cmp(&a.0));
        total += section(&format!("High-fanout nets (> {})", o.hfn), &v.into_iter().map(|x| x.1).collect::<Vec<_>>(), o.verbose, "TIM-110");
    }
    let _ = NOCLK;
    crate::out!("\n  check_timing: {} issue(s) found\n", total);
    total
}

pub struct DesignIssues {
    pub unused_inputs: Vec<String>,
    pub undriven_outputs: Vec<String>,
    pub multidriven: Vec<String>,
    pub undriven_inputs: Vec<String>,
    pub comb_loops: Vec<Vec<String>>,
    pub feedthroughs: Vec<String>,
    pub const_outputs: Vec<String>,
    pub unloaded_outputs: Vec<String>,
}

pub fn design_issues(nl: &Netlist) -> DesignIssues {
    let mut d = DesignIssues { unused_inputs: vec![], undriven_outputs: vec![], multidriven: vec![], undriven_inputs: vec![], comb_loops: vec![], feedthroughs: vec![], const_outputs: vec![], unloaded_outputs: vec![] };
    for p in nl.port_ids() {
        let pt = &nl.ports[p];
        let Some(n) = pt.net else { continue };
        match pt.dir {
            Dir::In => {
                if nl.loads(n).is_empty() {
                    d.unused_inputs.push(pt.name.clone());
                }
                if nl.net(n).conns.iter().any(|x| matches!(x, PinRef::Port(q) if nl.ports[*q].dir == Dir::Out)) {
                    d.feedthroughs.push(pt.name.clone());
                }
            }
            Dir::Out => {
                let dr = nl.drivers(n);
                if dr.is_empty() {
                    d.undriven_outputs.push(pt.name.clone());
                } else if let Some(PinRef::Cell(c, _)) = dr.first() {
                    if matches!(nl.cell(*c).kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) {
                        d.const_outputs.push(pt.name.clone());
                    }
                }
            }
            _ => {}
        }
    }
    for n in nl.net_ids() {
        let dr = nl.drivers(n);
        if dr.len() > 1 {
            d.multidriven.push(format!("{} <- {}", nl.net(n).name, dr.iter().map(|x| nl.pin_name(*x)).collect::<Vec<_>>().join(", ")));
        }
        if dr.is_empty() {
            for l in nl.loads(n) {
                if let PinRef::Cell(..) = l {
                    d.undriven_inputs.push(nl.pin_name(l));
                }
            }
        }
    }
    for c in nl.cell_ids() {
        for p in &nl.cell(c).pins {
            if p.dir == Dir::Out {
                if let Some(n) = p.net {
                    if nl.loads(n).is_empty() && !matches!(nl.cell(c).kind, Kind::BlackBox(_) | Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) {
                        d.unloaded_outputs.push(format!("{}/{}", nl.cell(c).name, p.name));
                    }
                }
            } else if p.net.is_none() && !matches!(nl.cell(c).kind, Kind::BlackBox(_)) {
                d.undriven_inputs.push(format!("{}/{} (unconnected)", nl.cell(c).name, p.name));
            }
        }
    }
    d.comb_loops = structural_loops(nl);
    d
}

/// Structural combinational loop detection (independent of timing arcs): SCCs over
/// combinational cells only (sequential cells / black boxes break the graph).
pub fn structural_loops(nl: &Netlist) -> Vec<Vec<String>> {
    let is_seq = |c: &Cell| matches!(c.kind, Kind::Gen(GOp::Dff) | Kind::Gen(GOp::Latch) | Kind::BlackBox(_)) || c.name.ends_with("_reg") || c.name.contains("_reg[") || c.has_attr("clock_gate");
    let cells = nl.cell_ids();
    let idx: BTreeMap<CellId, usize> = cells.iter().enumerate().map(|(i, c)| (*c, i)).collect();
    let mut adj = vec![vec![]; cells.len()];
    for (i, &c) in cells.iter().enumerate() {
        if is_seq(nl.cell(c)) {
            continue;
        }
        for p in &nl.cell(c).pins {
            if p.dir != Dir::Out {
                continue;
            }
            let Some(n) = p.net else { continue };
            for l in nl.loads(n) {
                if let PinRef::Cell(lc, _) = l {
                    if !is_seq(nl.cell(lc)) {
                        adj[i].push(idx[&lc]);
                    }
                }
            }
        }
    }
    // Tarjan
    let n = cells.len();
    let mut index = vec![usize::MAX; n];
    let mut low = vec![0; n];
    let mut on = vec![false; n];
    let mut st = vec![];
    let mut out = vec![];
    let mut k = 0;
    for s in 0..n {
        if index[s] != usize::MAX {
            continue;
        }
        let mut cs = vec![(s, 0usize)];
        index[s] = k;
        low[s] = k;
        k += 1;
        st.push(s);
        on[s] = true;
        while let Some(&mut (v, ref mut e)) = cs.last_mut() {
            if *e < adj[v].len() {
                let w = adj[v][*e];
                *e += 1;
                if index[w] == usize::MAX {
                    index[w] = k;
                    low[w] = k;
                    k += 1;
                    st.push(w);
                    on[w] = true;
                    cs.push((w, 0));
                } else if on[w] {
                    low[v] = low[v].min(index[w]);
                }
            } else {
                cs.pop();
                if let Some(&(p, _)) = cs.last() {
                    low[p] = low[p].min(low[v]);
                }
                if low[v] == index[v] {
                    let mut comp = vec![];
                    loop {
                        let w = st.pop().unwrap();
                        on[w] = false;
                        comp.push(nl.cell(cells[w]).name.clone());
                        if w == v {
                            break;
                        }
                    }
                    let self_loop = comp.len() == 1 && adj[v].contains(&v);
                    if comp.len() > 1 || self_loop {
                        comp.reverse();
                        out.push(comp);
                    }
                }
            }
        }
    }
    out
}

pub fn print_issues(title: &str, v: &[String], verbose: bool, id: &str) -> usize {
    section(title, v, verbose, id)
}
