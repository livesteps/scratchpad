//! Static timing engine.
//!   * graph of pins with cell (NLDM table) and net (Elmore) arcs
//!   * rise/fall, max/min (setup/hold) arrival + slew propagation, OCV derates
//!   * clock propagation (ideal or propagated, inversion tracking, generated clocks)
//!   * tag-based exception handling (false / multicycle / max-min delay, -from/-through/-to)
//!   * clock groups, case analysis (3-valued constant propagation), disable_timing
//!   * loop detection (Tarjan SCC) with automatic loop breaking + verbose report
//!   * required-time back-propagation for per-pin slack (drives the optimizer)
//!   * DRV (max transition / capacitance / fanout) evaluation
//!   * wire model: DEF placement HPWL -> RC, else wire-load model, else zero-wire

use crate::cons::*;
use crate::liberty::{BExpr, LibCell, Library, Sense, TArc, TType};
use crate::netlist::*;
use std::collections::{HashMap, HashSet};

pub const NOCLK: u16 = u16::MAX;
pub(crate) const NONE: u32 = u32::MAX;

pub struct LibSet<'a> {
    pub libs: Vec<&'a Library>,
}
impl<'a> LibSet<'a> {
    pub fn cell(&self, n: &str) -> Option<&'a LibCell> {
        self.libs.iter().find_map(|l| l.cells.get(n))
    }
    pub fn lib0(&self) -> Option<&'a Library> {
        self.libs.first().copied()
    }
    pub fn default_max_tran(&self) -> Option<f64> {
        self.libs.iter().find_map(|l| l.default_max_tran)
    }
    pub fn default_max_fanout(&self) -> Option<f64> {
        self.libs.iter().find_map(|l| l.default_max_fanout)
    }
    pub fn default_max_cap(&self) -> Option<f64> {
        self.libs.iter().find_map(|l| l.default_max_cap)
    }
}

#[derive(Clone, Debug)]
pub struct StaOpts {
    pub c_per_um: f64,
    pub r_per_um: f64,
    pub gen_delay: f64,
    pub max_tags: usize,
    pub use_placement: bool,
    pub zero_wire: bool,
    pub preset_clear: bool,
    /// global-route lengths (um) per net, used instead of HPWL when present
    pub route_len: Option<std::sync::Arc<HashMap<NetId, f64>>>,
    /// detailed-route extraction: wire caps and per-load Elmore delays (override estimates)
    pub routed: Option<std::sync::Arc<crate::droute::RoutedRc>>,
    /// AOCV / POCV models
    pub ocv: Option<std::sync::Arc<Ocv>>,
    pub aocv_on: bool,
    /// POCV corner sigma multiplier k (0 = POCV off)
    pub pocv_k: f64,
    /// clock reconvergence pessimism removal
    pub crpr: bool,
    /// annotated parasitics per corner name (read_parasitics); used as-is, without RC scaling
    pub spef: Option<std::sync::Arc<HashMap<String, std::sync::Arc<crate::droute::RoutedRc>>>>,
    /// annotated delays (set_annotated_delay)
    pub ann: Option<std::sync::Arc<Vec<AnnDelay>>>,
    /// set_analysis_type -single_corner: no early/late derating
    pub ignore_derates: bool,
    /// interconnect delay model on nets with RC trees (set_delay_calculation -model)
    pub dmodel: crate::rcnet::Model,
    /// effective-capacitance driver delay (pi model of the RC tree)
    pub ceff: bool,
    /// Miller factor applied to coupling capacitance
    pub miller: f64,
}

/// one set_annotated_delay entry, resolved to pins
#[derive(Clone, Debug)]
pub struct AnnDelay {
    pub from: PinRef,
    pub to: PinRef,
    pub rise: bool,
    pub fall: bool,
    pub max: bool,
    pub min: bool,
    pub incr: bool,
    pub value: f64,
    /// empty: every corner
    pub corners: Vec<String>,
}
impl Default for StaOpts {
    fn default() -> Self {
        StaOpts { c_per_um: 0.0002, r_per_um: 0.002, gen_delay: 0.05, max_tags: 24, use_placement: true, zero_wire: false, preset_clear: false, route_len: None, routed: None, ocv: None, aocv_on: false, pocv_k: 0.0, crpr: true, spef: None, ann: None, ignore_derates: false, dmodel: crate::rcnet::Model::Elmore, ceff: false, miller: 1.0 }
    }
}

#[derive(Clone, Copy)]
pub(crate) enum AK<'a> {
    Net,
    #[allow(dead_code)]
    Cell(&'a TArc, CellId),
    Gen(f64, Sense),
    #[allow(dead_code)]
    Launch(&'a TArc, CellId),
    GenLaunch(f64),
}
#[derive(Clone, Copy)]
pub(crate) struct Arc<'a> {
    pub(crate) from: u32,
    pub(crate) to: u32,
    pub(crate) k: AK<'a>,
}

#[derive(Clone, Copy, Debug)]
pub struct CTag {
    pub clk: u16,
    pub inv: bool,
    pub lmax: f64,
    pub lmin: f64,
    pub slew: f64,
    /// POCV variance of the late / early latency
    pub vmax: f64,
    pub vmin: f64,
}

/// AOCV derate table (Synopsys AOCV format): rows = distance, columns = depth
#[derive(Clone, Debug)]
pub struct AocvTable {
    pub pattern: String,
    pub late: bool,
    pub early: bool,
    pub clock: bool,
    pub data: bool,
    pub depths: Vec<f64>,
    pub dists: Vec<f64>,
    pub tbl: Vec<Vec<f64>>,
}

impl AocvTable {
    pub fn lookup(&self, depth: f64, dist: f64) -> f64 {
        fn interp(xs: &[f64], x: f64) -> (usize, usize, f64) {
            if xs.len() <= 1 || x <= xs[0] {
                return (0, 0, 0.0);
            }
            for i in 1..xs.len() {
                if x <= xs[i] {
                    return (i - 1, i, (x - xs[i - 1]) / (xs[i] - xs[i - 1]).max(1e-12));
                }
            }
            (xs.len() - 1, xs.len() - 1, 0.0)
        }
        let (d0, d1, fd) = interp(&self.depths, depth);
        let (r0, r1, fr) = interp(&self.dists, dist);
        let g = |r: usize, d: usize| self.tbl.get(r).and_then(|row| row.get(d)).copied().unwrap_or(1.0);
        let a = g(r0, d0) * (1.0 - fd) + g(r0, d1) * fd;
        let b = g(r1, d0) * (1.0 - fd) + g(r1, d1) * fd;
        a * (1.0 - fr) + b * fr
    }
}

/// on-chip-variation models: AOCV tables and POCV (SOCV) sigma coefficients
#[derive(Clone, Debug, Default)]
pub struct Ocv {
    pub aocv: Vec<AocvTable>,
    pub pocv: Vec<(String, f64)>,
    pub pocv_default: f64,
    pub pocv_net: f64,
}

#[derive(Clone, Debug)]
pub struct Tag {
    pub clk: u16,
    pub ledge: u8,
    pub exc: u16,
    pub done: bool,
    pub at: [f64; 2],
    pub atn: [f64; 2],
    pub sl: [f64; 2],
    pub sln: [f64; 2],
    pub prev: [(u32, u8); 2],
    pub prevn: [(u32, u8); 2],
    pub start: u32,
    /// -from membership of the launch point: bit i (<48) = path group i, bit 48+j = path margin j.
    /// Part of the tag key so paths from different startpoint sets are never merged.
    pub pgm: u64,
    /// POCV variance of the late / early arrival
    pub vr: [f64; 2],
    pub vrn: [f64; 2],
    /// startpoint of the early (min) arrival (CRPR for hold)
    pub startn: u32,
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum Chk {
    Setup,
    Hold,
}
#[derive(Clone)]
pub struct Check<'a> {
    pub d: u32,
    pub ck: u32,
    arc: Option<&'a TArc>,
    kind: Chk,
    rising: bool,
    recovery: bool,
    pub gating: bool,
}

pub type ObjSets = (HashSet<u16>, HashSet<u32>, HashSet<CellId>);

/// clock-domain crossing statistics for one (launch, capture) clock pair
#[derive(Clone, Debug, Default)]
pub struct XStat {
    pub timed: HashSet<u32>,
    pub worst: f64,
    pub false_path: HashSet<u32>,
    pub asynch: HashSet<u32>,
}

/// an untimed (false-path or asynchronous) crossing endpoint
#[derive(Clone, Debug)]
pub struct XEp {
    pub node: u32,
    pub launch: u16,
    pub capture: u16,
    pub asynch: bool,
    /// 'D' data, 'R' async reset (recovery/removal), 'G' clock-gating enable, 'O' output port
    pub kind: char,
    pub start: u32,
}

/// required time of one (launch tag, endpoint transition, check type) at an endpoint, without CRPR
#[derive(Clone, Debug)]
pub struct ReqRec {
    pub clk: u16,
    pub ledge: u8,
    pub rf: u8,
    pub hold: bool,
    pub req: f64,
    /// capture clock pin (CRPR is computed per path from the launch clock pin), NONE for ports
    pub ck: u32,
    pub crpr_ok: bool,
    pub cap_clk: u16,
    pub group: String,
    pub detail: Vec<(String, f64)>,
}

#[derive(Clone, Debug)]
pub struct EndPoint {
    pub node: u32,
    pub name: String,
    pub setup_slack: f64,
    pub hold_slack: f64,
    pub setup_req: f64,
    pub arrival: f64,
    pub tag: Option<(u16, u8, u16)>,
    pub rf: u8,
    pub cap_clock: Option<u16>,
    pub group: String,
    /// worst setup slack of this endpoint per path group (a path to one endpoint can be in several groups)
    pub groups: Vec<(String, f64)>,
    pub hold_tag: Option<(u16, u8, u16)>,
    pub hold_rf: u8,
    pub hold_req: f64,
    pub setup_detail: Vec<(String, f64)>,
    pub hold_detail: Vec<(String, f64)>,
    pub is_port: bool,
    pub reqs: Vec<ReqRec>,
}

#[derive(Clone, Debug)]
pub struct DrvViol {
    pub kind: &'static str,
    pub net: NetId,
    pub obj: String,
    pub actual: f64,
    pub limit: f64,
}

/// derates of one timing point (see `Timing::point_derates`)
#[derive(Clone, Copy, Debug, Default)]
pub struct PointDerate {
    pub cell_arc: bool,
    pub user: Option<f64>,
    pub ocv: f64,
    pub aocv: Option<(f64, u32)>,
    pub pocv_coef: Option<f64>,
    pub pocv_k: f64,
    pub applied: f64,
}

pub struct Timing<'a> {
    pub nl: &'a Netlist,
    pub libs: &'a LibSet<'a>,
    pub cons: &'a Constraints,
    pub corner: &'a Corner,
    pub opts: StaOpts,
    pub nodes: Vec<PinRef>,
    pub idx: HashMap<PinRef, u32>,
    pub(crate) arcs: Vec<Arc<'a>>,
    pub(crate) fan_out: Vec<Vec<u32>>,
    pub(crate) fan_in: Vec<Vec<u32>>,
    pub topo: Vec<u32>,
    pub net_c: Vec<f64>,
    pub net_wc: Vec<f64>,
    pub net_wr: Vec<f64>,
    pub ctags: Vec<Vec<CTag>>,
    pub tags: Vec<Vec<Tag>>,
    pub arc_d: Vec<[[f64; 2]; 2]>,
    /// early (min) arc delays, for hold path enumeration
    pub arc_dn: Vec<[[f64; 2]; 2]>,
    pub req: Vec<[f64; 2]>,
    pub reqn: Vec<[f64; 2]>,
    pub endpoints: Vec<EndPoint>,
    pub unconstrained: Vec<String>,
    pub loops: Vec<Vec<String>>,
    pub broken_arcs: Vec<String>,
    pub drv: Vec<DrvViol>,
    pub consts: Vec<Option<bool>>,
    pub clk_reached: HashSet<u32>,
    pub clk_pins: Vec<u32>,
    pub clock_as_data: Vec<String>,
    pub data_as_clock: Vec<String>,
    exc_from: Vec<(HashSet<u16>, HashSet<u32>, HashSet<CellId>)>,
    grp_sets: Vec<(ObjSets, ObjSets)>,
    mar_sets: Vec<(ObjSets, ObjSets)>,
    /// clock crossings by (launch, capture)
    pub xing: HashMap<(u16, u16), XStat>,
    /// fanout of a net group joined through boundary pins (root net -> real loads)
    pub hp_fanout: HashMap<NetId, usize>,
    /// true while clock latencies are propagated (clock-path derates)
    in_clock: std::cell::Cell<bool>,
    /// annotated (SPEF) parasitics: no corner RC scaling
    pub routed_raw: bool,
    /// RC-tree moments per load pin (corner scaled), when the model needs them
    pub pin_mom: HashMap<PinRef, crate::rcnet::NodeMoments>,
    /// driver pin -> (pi model of its net, Miller-adjusted coupling delta), corner scaled
    pub drv_pi: HashMap<PinRef, (crate::rcnet::PiModel, f64)>,
    /// (from, to) -> [max, min][rise, fall] -> (value, increment)
    pub ann_map: HashMap<(PinRef, PinRef), [[Option<(f64, bool)>; 2]; 2]>,
    /// object derates: [late data, early data, late clock, early clock]
    pub cell_der: HashMap<CellId, [f64; 4]>,
    pub net_der: HashMap<NetId, [f64; 4]>,
    /// AOCV derates per cell: [late data, early data, late clock, early clock] and its depth
    pub aocv_der: HashMap<CellId, [f64; 4]>,
    pub aocv_depth: HashMap<CellId, u32>,
    /// POCV sigma coefficient per cell
    pocv_coef: HashMap<CellId, f64>,
    /// clock-network parent per node (for CRPR)
    pub cpar: Vec<u32>,
    pub xing_eps: Vec<XEp>,
    exc_to: Vec<(HashSet<u16>, HashSet<u32>, HashSet<CellId>)>,
    exc_thr: Vec<HashSet<u32>>,
    pub(crate) disabled_arcs: HashSet<(u32, u32)>,
    checks_store: Vec<Check<'a>>,
    pub clk_period: Vec<f64>,
    pub clk_edges: Vec<(f64, f64)>,
    pub wns: f64,
    pub tns: f64,
    pub whs: f64,
    pub ths: f64,
    pub nvp: usize,
    pub nvh: usize,
}

fn inf() -> f64 {
    f64::INFINITY
}

impl<'a> Timing<'a> {
    pub fn lib_pin_cap(&self, pr: PinRef) -> f64 {
        match pr {
            PinRef::Cell(c, p) => {
                let cell = self.nl.cell(c);
                match &cell.kind {
                    Kind::Lib(l) => self.libs.cell(l).and_then(|lc| lc.pin(&cell.pins[p].name)).map(|x| x.cap).unwrap_or(0.001),
                    Kind::Gen(_) if cell.is_hport() => 0.0,
                    Kind::Gen(_) => 0.001,
                    Kind::BlackBox(_) => 0.002,
                }
            }
            PinRef::Port(p) => {
                let n = &self.nl.ports[p].name;
                self.cons.loads.iter().rev().find(|(o, _)| o.name() == n).map(|x| x.1).unwrap_or(0.0)
            }
        }
    }

    pub fn new(nl: &'a Netlist, libs: &'a LibSet<'a>, cons: &'a Constraints, corner: &'a Corner, mut opts: StaOpts) -> Timing<'a> {
        // annotated parasitics of this corner replace extraction / estimation
        let mut routed_raw = false;
        if let Some(rc) = opts.spef.as_ref().and_then(|m| m.get(&corner.name)).cloned() {
            opts.routed = Some(rc);
            routed_raw = true;
        }
        let mut t = Timing {
            nl,
            libs,
            cons,
            corner,
            opts,
            nodes: vec![],
            idx: HashMap::new(),
            arcs: vec![],
            fan_out: vec![],
            fan_in: vec![],
            topo: vec![],
            net_c: vec![],
            net_wc: vec![],
            net_wr: vec![],
            ctags: vec![],
            tags: vec![],
            arc_d: vec![],
            arc_dn: vec![],
            req: vec![],
            reqn: vec![],
            endpoints: vec![],
            unconstrained: vec![],
            loops: vec![],
            broken_arcs: vec![],
            drv: vec![],
            consts: vec![],
            clk_reached: HashSet::new(),
            clk_pins: vec![],
            clock_as_data: vec![],
            data_as_clock: vec![],
            exc_from: vec![],
            grp_sets: vec![],
            mar_sets: vec![],
            xing: HashMap::new(),
            hp_fanout: HashMap::new(),
            in_clock: std::cell::Cell::new(false),
            routed_raw,
            pin_mom: HashMap::new(),
            drv_pi: HashMap::new(),
            ann_map: HashMap::new(),
            cell_der: HashMap::new(),
            net_der: HashMap::new(),
            aocv_der: HashMap::new(),
            aocv_depth: HashMap::new(),
            pocv_coef: HashMap::new(),
            cpar: vec![],
            xing_eps: vec![],
            exc_to: vec![],
            exc_thr: vec![],
            disabled_arcs: HashSet::new(),
            checks_store: vec![],
            clk_period: vec![],
            clk_edges: vec![],
            wns: 0.0,
            tns: 0.0,
            whs: 0.0,
            ths: 0.0,
            nvp: 0,
            nvh: 0,
        };
        t.prepare_overrides();
        t.prepare_rc();
        t.build();
        t
    }

    /// moments and pi models of the RC trees (only when a non-legacy setting needs them)
    fn prepare_rc(&mut self) {
        let need_mom = self.opts.dmodel != crate::rcnet::Model::Elmore || (self.opts.miller - 1.0).abs() > 1e-12;
        if !(need_mom || self.opts.ceff) {
            return;
        }
        let Some(rc) = self.opts.routed.clone() else { return };
        let (kr, kc) = if self.routed_raw { (1.0, 1.0) } else { (self.corner.r_scale, self.corner.c_scale) };
        let k = kr * kc;
        for t in rc.trees.values() {
            let mom = t.moments(self.opts.miller);
            if need_mom {
                for (pr, nd) in &t.pins {
                    if *nd != 0 || !self.nl.is_driver(*pr) {
                        let m = mom[*nd as usize];
                        self.pin_mom.insert(*pr, crate::rcnet::NodeMoments { m1: m.m1 * k, m2: m.m2 * k * k, m3: m.m3 * k * k * k });
                    }
                }
            }
            if let Some((drv, _)) = t.pins.iter().find(|(p, n)| *n == 0 && self.nl.is_driver(*p)) {
                let pi = t.pi_model(&mom, self.opts.miller);
                let dcc = (self.opts.miller - 1.0) * t.coupling_cap() * kc;
                self.drv_pi.insert(*drv, (crate::rcnet::PiModel { c1: pi.c1 * kc, r: pi.r * kr, c2: pi.c2 * kc }, dcc));
            }
        }
    }

    /// resolve annotated delays and object derates for this corner
    fn prepare_overrides(&mut self) {
        if let Some(v) = self.opts.ann.clone() {
            for a in v.iter() {
                if !a.corners.is_empty() && !a.corners.contains(&self.corner.name) {
                    continue;
                }
                let e = self.ann_map.entry((a.from, a.to)).or_insert([[None; 2]; 2]);
                for (mi, on) in [(0, a.max), (1, a.min)] {
                    for (ri, ron) in [(0, a.rise), (1, a.fall)] {
                        if on && ron {
                            e[mi][ri] = Some((a.value, a.incr));
                        }
                    }
                }
            }
        }
        if self.corner.obj_derates.is_empty() {
            return;
        }
        let nl = self.nl;
        let base_c = [self.corner.derate(true, false, false), self.corner.derate(true, true, false), self.corner.derate(true, false, true), self.corner.derate(true, true, true)];
        let base_n = [self.corner.derate(false, false, false), self.corner.derate(false, true, false), self.corner.derate(false, false, true), self.corner.derate(false, true, true)];
        let slots = |d: &crate::cons::ObjDerate| -> Vec<usize> {
            let mut v = vec![];
            for (i, (late, clk)) in [(true, false), (false, false), (true, true), (false, true)].iter().enumerate() {
                if (if *late { d.late } else { d.early }) && (if *clk { d.clock } else { d.data }) {
                    v.push(i);
                }
            }
            v
        };
        for d in &self.corner.obj_derates {
            let sl = slots(d);
            let cells: Vec<CellId> = match &d.obj {
                Obj::Cell(n) => match nl.cell_by_name(n) {
                    Some(c) => vec![c],
                    None => {
                        let pre = format!("{}/", n);
                        nl.cell_ids().into_iter().filter(|c| nl.cell(*c).name.starts_with(&pre)).collect()
                    }
                },
                Obj::LibCell(l) => {
                    let ln = l.rsplit('/').next().unwrap_or(l);
                    nl.cell_ids().into_iter().filter(|c| nl.cell(*c).lib().map(|x| crate::netlist::glob(ln, x)).unwrap_or(false)).collect()
                }
                _ => vec![],
            };
            if d.cell {
                for c in &cells {
                    let e = self.cell_der.entry(*c).or_insert(base_c);
                    for &i in &sl {
                        e[i] = d.value;
                    }
                }
            }
            if d.net {
                let nets: Vec<NetId> = match &d.obj {
                    Obj::Net(n) => nl.net_by_name(n).into_iter().collect(),
                    // net derate on cells: the nets they drive
                    _ => cells.iter().flat_map(|c| nl.cell(*c).pins.iter().filter(|p| p.dir == Dir::Out).filter_map(|p| p.net).collect::<Vec<_>>()).collect(),
                };
                for n in nets {
                    let e = self.net_der.entry(n).or_insert(base_n);
                    for &i in &sl {
                        e[i] = d.value;
                    }
                }
            }
        }
    }

    /// derate of a cell or net delay: object derate, else the corner's (1.0 for -single_corner)
    fn der(&self, cell: bool, early: bool, clk: bool, c: Option<CellId>, n: Option<NetId>) -> f64 {
        if self.opts.ignore_derates {
            return 1.0;
        }
        let i = (early as usize) + 2 * (clk as usize);
        if cell {
            if let Some(m) = c.and_then(|c| self.cell_der.get(&c)) {
                return m[i];
            }
        } else if let Some(m) = n.and_then(|n| self.net_der.get(&n)) {
            return m[i];
        }
        self.corner.derate(cell, early, clk)
    }

    /// derate breakdown of the arc ending at node `n` (cell arc at a driver pin, net arc at a
    /// load pin): (user / object derate, corner OCV derate, AOCV derate and depth, POCV sigma
    /// coefficient, derate actually applied) as the delay calculation uses them
    pub fn point_derates(&self, n: u32, early: bool, clk: bool) -> PointDerate {
        let pr = self.nodes[n as usize];
        let cell_arc = self.nl.is_driver(pr) && matches!(pr, PinRef::Cell(..));
        let i = (early as usize) + 2 * (clk as usize);
        let ign = self.opts.ignore_derates;
        let ocv = if ign { 1.0 } else { self.corner.derate(cell_arc, early, clk) };
        let (cid, nid) = match pr { PinRef::Cell(c, _) => (Some(c), self.nl.pin_net(pr)), _ => (None, self.nl.pin_net(pr)) };
        let user = if ign { None } else if cell_arc { cid.and_then(|c| self.cell_der.get(&c)).map(|m| m[i]) } else { nid.and_then(|n| self.net_der.get(&n)).map(|m| m[i]) };
        let aocv = if cell_arc && self.opts.aocv_on && !ign && user.is_none() {
            cid.and_then(|c| self.aocv_der.get(&c).map(|f| (f[i], self.aocv_depth.get(&c).copied().unwrap_or(0))))
        } else { None };
        let pocv = if self.opts.pocv_k > 0.0 {
            Some(if cell_arc { cid.and_then(|c| self.pocv_coef.get(&c).copied()).unwrap_or(0.0) } else { self.opts.ocv.as_ref().map(|o| o.pocv_net).unwrap_or(0.0) })
        } else { None };
        let applied = aocv.map(|a| a.0).or(user).unwrap_or(ocv);
        PointDerate { cell_arc, user, ocv, aocv, pocv_coef: pocv, pocv_k: self.opts.pocv_k, applied }
    }

    /// set_annotated_delay on an arc
    fn ann_adj(&self, from: u32, to: u32, rf: usize, early: bool, d: f64) -> f64 {
        if self.ann_map.is_empty() {
            return d;
        }
        match self.ann_map.get(&(self.nodes[from as usize], self.nodes[to as usize])).and_then(|m| m[early as usize][rf]) {
            Some((v, true)) => d + v,
            Some((v, false)) => v,
            None => d,
        }
    }

    fn node(&mut self, pr: PinRef) -> u32 {
        if let Some(&i) = self.idx.get(&pr) {
            return i;
        }
        let i = self.nodes.len() as u32;
        self.nodes.push(pr);
        self.idx.insert(pr, i);
        i
    }
    pub fn node_name(&self, n: u32) -> String {
        self.nl.pin_name(self.nodes[n as usize])
    }
    fn add_arc(&mut self, from: u32, to: u32, k: AK<'a>) {
        self.arcs.push(Arc { from, to, k });
    }

    /// Resolve an SDC object to graph nodes.
    pub fn resolve(&self, o: &Obj) -> Vec<u32> {
        let nl = self.nl;
        match o {
            Obj::Port(n) => nl.port_by_name(n).and_then(|p| self.idx.get(&PinRef::Port(p)).copied()).into_iter().collect(),
            Obj::Pin(n) => {
                if let Some(pr) = nl.find_pin(n) {
                    return self.idx.get(&pr).copied().into_iter().collect();
                }
                // role-based fallback (generic -> mapped pin names)
                if let Some(i) = n.rfind('/') {
                    if let Some(c) = nl.cell_by_name(&n[..i]) {
                        let role = &n[i + 1..];
                        let cell = nl.cell(c);
                        let want = role.to_uppercase();
                        for (pi, p) in cell.pins.iter().enumerate() {
                            let pn = p.name.to_uppercase();
                            let hit = match want.as_str() {
                                "CK" | "CLK" | "CP" | "C" | "G" | "GN" | "EN" => self.is_clock_pin(c, pi),
                                "D" => pn == "D" || pn == "DIN",
                                "Q" => p.dir == Dir::Out && !pn.contains('N'),
                                "QN" => p.dir == Dir::Out && pn.contains('N'),
                                _ => false,
                            };
                            if hit {
                                return self.idx.get(&PinRef::Cell(c, pi)).copied().into_iter().collect();
                            }
                        }
                    }
                }
                vec![]
            }
            Obj::Cell(n) => match nl.cell_by_name(n) {
                Some(c) => (0..nl.cell(c).pins.len()).filter_map(|p| self.idx.get(&PinRef::Cell(c, p)).copied()).collect(),
                None => vec![],
            },
            Obj::Net(n) => match nl.net_by_name(n) {
                Some(net) => nl.net(net).conns.iter().filter_map(|pr| self.idx.get(pr).copied()).collect(),
                None => vec![],
            },
            _ => vec![],
        }
    }
    pub fn is_clock_pin(&self, c: CellId, p: usize) -> bool {
        let cell = self.nl.cell(c);
        match &cell.kind {
            Kind::Lib(l) => self.libs.cell(l).and_then(|lc| lc.pin(&cell.pins[p].name)).map(|lp| lp.is_clock || lp.cg_role.as_deref() == Some("clock")).unwrap_or(false),
            Kind::Gen(GOp::Dff) => cell.pins[p].name == "CK",
            Kind::Gen(GOp::Latch) => cell.pins[p].name == "G",
            _ => false,
        }
    }

    fn build(&mut self) {
        let nl = self.nl;
        // nodes
        for p in nl.port_ids() {
            self.node(PinRef::Port(p));
        }
        for c in nl.cell_ids() {
            for p in 0..nl.cell(c).pins.len() {
                if nl.cell(c).pins[p].net.is_some() {
                    self.node(PinRef::Cell(c, p));
                }
            }
        }
        // disabled arcs from SDC
        let mut dis_cells: HashMap<CellId, Vec<(Option<String>, Option<String>)>> = HashMap::new();
        let mut dis_lib: Vec<(String, Option<String>, Option<String>)> = vec![];
        let mut dis_pins: HashSet<PinRef> = HashSet::new();
        for (o, f, t) in &self.cons.disabled {
            match o {
                Obj::Cell(n) => {
                    if let Some(c) = nl.cell_by_name(n) {
                        dis_cells.entry(c).or_default().push((f.clone(), t.clone()));
                    }
                }
                Obj::LibCell(n) => dis_lib.push((n.rsplit('/').next().unwrap_or(n).to_string(), f.clone(), t.clone())),
                Obj::Pin(n) | Obj::Port(n) => {
                    if let Some(pr) = nl.find_pin(n) {
                        dis_pins.insert(pr);
                    }
                }
                _ => {}
            }
        }
        // cell arcs
        let mut checks: Vec<Check<'a>> = vec![];
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            match &cell.kind {
                Kind::Lib(ln) => {
                    let Some(lc) = self.libs.cell(ln) else { continue };
                    for (pi, pin) in cell.pins.iter().enumerate() {
                        if pin.net.is_none() {
                            continue;
                        }
                        let Some(lp) = lc.pin(&pin.name) else { continue };
                        for a in &lp.arcs {
                            let Some(ri) = cell.pin(&a.related) else { continue };
                            if cell.pins[ri].net.is_none() {
                                continue;
                            }
                            let from = self.idx[&PinRef::Cell(c, ri)];
                            let to = self.idx[&PinRef::Cell(c, pi)];
                            let disabled = dis_pins.contains(&PinRef::Cell(c, ri))
                                || dis_cells.get(&c).map(|v| v.iter().any(|(f, t)| f.as_ref().map(|f| f == &a.related).unwrap_or(true) && t.as_ref().map(|t| t == &pin.name).unwrap_or(true))).unwrap_or(false)
                                || dis_lib.iter().any(|(l, f, t)| l == ln && f.as_ref().map(|f| f == &a.related).unwrap_or(true) && t.as_ref().map(|t| t == &pin.name).unwrap_or(true));
                            match a.ttype {
                                TType::Comb | TType::Clear | TType::Preset => {
                                    if matches!(a.ttype, TType::Clear | TType::Preset) && !self.opts.preset_clear {
                                        continue;
                                    }
                                    if disabled {
                                        self.broken_arcs.push(format!("{}/{} -> {}/{} (set_disable_timing)", cell.name, a.related, cell.name, pin.name));
                                        continue;
                                    }
                                    self.add_arc(from, to, AK::Cell(a, c))
                                }
                                TType::RisingEdge | TType::FallingEdge => self.add_arc(from, to, AK::Launch(a, c)),
                                TType::SetupRising | TType::SetupFalling | TType::RecoveryRising => checks.push(Check { d: to, ck: from, arc: Some(a), kind: Chk::Setup, rising: a.ttype != TType::SetupFalling, recovery: a.ttype == TType::RecoveryRising, gating: lc.icg.is_some() }),
                                TType::HoldRising | TType::HoldFalling | TType::RemovalRising => checks.push(Check { d: to, ck: from, arc: Some(a), kind: Chk::Hold, rising: a.ttype != TType::HoldFalling, recovery: a.ttype == TType::RemovalRising, gating: lc.icg.is_some() }),
                                TType::NonSeqSetup => checks.push(Check { d: to, ck: from, arc: Some(a), kind: Chk::Setup, rising: true, recovery: false, gating: false }),
                                TType::NonSeqHold => checks.push(Check { d: to, ck: from, arc: Some(a), kind: Chk::Hold, rising: true, recovery: false, gating: false }),
                                TType::Other => {}
                            }
                        }
                    }
                }
                Kind::Gen(op) => {
                    let d = if cell.is_hport() { -1.0 } else { self.opts.gen_delay };
                    let outs: Vec<usize> = (0..cell.pins.len()).filter(|&p| cell.pins[p].dir == Dir::Out && cell.pins[p].net.is_some()).collect();
                    match op {
                        GOp::Dff => {
                            if let (Some(ck), Some(q), Some(dd)) = (cell.pin("CK"), cell.pin("Q"), cell.pin("D")) {
                                if cell.pins[ck].net.is_some() && cell.pins[q].net.is_some() {
                                    let (f, t) = (self.idx[&PinRef::Cell(c, ck)], self.idx[&PinRef::Cell(c, q)]);
                                    self.add_arc(f, t, AK::GenLaunch(d));
                                    if cell.pins[dd].net.is_some() {
                                        let dn = self.idx[&PinRef::Cell(c, dd)];
                                        checks.push(Check { d: dn, ck: f, arc: None, kind: Chk::Setup, rising: true, recovery: false, gating: false });
                                        checks.push(Check { d: dn, ck: f, arc: None, kind: Chk::Hold, rising: true, recovery: false, gating: false });
                                    }
                                }
                            }
                        }
                        GOp::C0 | GOp::C1 => {}
                        _ => {
                            let sense = match op {
                                GOp::Not | GOp::Nand | GOp::Nor => Sense::Neg,
                                GOp::Xor | GOp::Xnor | GOp::Mux => Sense::Non,
                                _ => Sense::Pos,
                            };
                            for (pi, pin) in cell.pins.iter().enumerate() {
                                if pin.dir == Dir::In && pin.net.is_some() {
                                    for &o in &outs {
                                        let (f, t) = (self.idx[&PinRef::Cell(c, pi)], self.idx[&PinRef::Cell(c, o)]);
                                        let s = if *op == GOp::Mux && pin.name != "S" { Sense::Pos } else { sense };
                                        self.add_arc(f, t, AK::Gen(d, s));
                                    }
                                }
                            }
                        }
                    }
                }
                Kind::BlackBox(_) => {}
            }
        }
        // net arcs + loads
        self.net_c = vec![0.0; nl.nets.len()];
        self.net_wc = vec![0.0; nl.nets.len()];
        self.net_wr = vec![0.0; nl.nets.len()];
        let wlm = self.cons.wire_load_model.clone().or_else(|| self.libs.lib0().and_then(|l| l.default_wire_load.clone()));
        let wl = wlm.and_then(|w| self.libs.libs.iter().find_map(|l| l.wire_loads.get(&w)));
        // hierarchical boundary pins join net segments into one physical wire: parasitics and
        // load capacitance are computed on the whole group and charged to the real driver's net
        let is_hp = |p: &PinRef| matches!(p, PinRef::Cell(c, _) if nl.cell(*c).is_hport());
        let mut hp_member: HashMap<NetId, NetId> = HashMap::new();
        let mut hp_groups: HashMap<NetId, Vec<NetId>> = HashMap::new();
        for n in nl.net_ids() {
            if nl.driver(n).map(|d| is_hp(&d)).unwrap_or(false) || !nl.loads(n).iter().any(|l| is_hp(l)) {
                continue;
            }
            let mut grp = vec![n];
            let mut k = 0;
            while k < grp.len() {
                let m = grp[k];
                k += 1;
                for l in nl.loads(m) {
                    if let PinRef::Cell(c, _) = l {
                        if nl.cell(c).is_hport() {
                            if let Some(y) = nl.cell(c).pin_net("Y") {
                                if !grp.contains(&y) {
                                    grp.push(y);
                                }
                            }
                        }
                    }
                }
            }
            for &m in &grp[1..] {
                hp_member.insert(m, n);
            }
            hp_groups.insert(n, grp);
        }
        for n in nl.net_ids() {
            if hp_member.contains_key(&n) {
                continue; // filled from its group root below
            }
            let grp: Vec<NetId> = hp_groups.get(&n).cloned().unwrap_or_else(|| vec![n]);
            let loads: Vec<PinRef> = grp.iter().flat_map(|m| nl.loads(*m)).filter(|l| !is_hp(l)).collect();
            let mut c = 0.0;
            for l in &loads {
                c += self.lib_pin_cap(*l);
            }
            // wire parasitics
            let (mut wc, mut wr) = (0.0, 0.0);
            if !self.opts.zero_wire {
                let conns: Vec<PinRef> = grp.iter().flat_map(|m| nl.net(*m).conns.clone()).filter(|p| !is_hp(p)).collect();
                let locs: Vec<(f64, f64)> = conns.iter().filter_map(|p| nl.pin_loc(*p)).collect();
                let rl: Option<f64> = self.opts.route_len.as_ref().and_then(|m| {
                    let v: Vec<f64> = grp.iter().filter_map(|g| m.get(g).copied()).collect();
                    if v.is_empty() { None } else { Some(v.iter().sum()) }
                });
                if let (Some(len), true) = (rl, self.opts.use_placement) {
                    wc = len * self.opts.c_per_um;
                    wr = len * self.opts.r_per_um;
                } else if self.opts.use_placement && locs.len() >= 2 && locs.len() == conns.len() {
                    let (mut x0, mut x1, mut y0, mut y1) = (f64::MAX, f64::MIN, f64::MAX, f64::MIN);
                    for (x, y) in &locs {
                        x0 = x0.min(*x);
                        x1 = x1.max(*x);
                        y0 = y0.min(*y);
                        y1 = y1.max(*y);
                    }
                    let hpwl = (x1 - x0) + (y1 - y0);
                    let k = if loads.len() > 3 { 1.0 + 0.1 * (loads.len() as f64 - 3.0).sqrt() } else { 1.0 };
                    wc = hpwl * k * self.opts.c_per_um;
                    wr = hpwl * k * self.opts.r_per_um;
                } else if let Some(w) = wl {
                    let len = w.length(loads.len().max(1));
                    wc = len * w.cap * self.libs.lib0().map(|l| l.cap_scale).unwrap_or(1.0);
                    wr = len * w.res;
                }
            }
            // annotated wire cap: the sum over the annotated segments of the (hierarchy-joined)
            // net; segments without parasitics keep their share of the estimate
            let mut annotated: Option<f64> = None;
            let mut un_frac = 1.0;
            if let Some(rc) = self.opts.routed.as_ref() {
                let ann: Vec<f64> = grp.iter().filter_map(|m| rc.wire_c.get(m).copied()).collect();
                if !ann.is_empty() {
                    annotated = Some(ann.iter().sum());
                    un_frac = (grp.len() - ann.len()) as f64 / grp.len() as f64;
                }
            }
            match annotated {
                Some(a) => {
                    let est = wc * un_frac * self.corner.c_scale;
                    wc = if self.routed_raw { a + est } else { a * self.corner.c_scale + est };
                }
                None => wc *= self.corner.c_scale,
            }
            wr *= self.corner.r_scale;
            for &m in &grp {
                self.net_wc[m] = wc;
                self.net_wr[m] = wr;
                self.net_c[m] = if m == n { c + wc } else { 0.0 };
            }
            if grp.len() > 1 {
                self.hp_fanout.insert(n, loads.len());
            }
        }
        for n in nl.net_ids() {
            let drv = nl.drivers(n);
            let loads = nl.loads(n);
            for d in &drv {
                let Some(&f) = self.idx.get(d) else { continue };
                for l in &loads {
                    if l == d {
                        continue;
                    }
                    let Some(&t) = self.idx.get(l) else { continue };
                    if dis_pins.contains(l) {
                        continue;
                    }
                    self.add_arc(f, t, AK::Net);
                }
            }
        }
        // case analysis / constants
        self.consts = vec![None; self.nodes.len()];
        // fan-in/out lists
        self.fan_out = vec![vec![]; self.nodes.len()];
        self.fan_in = vec![vec![]; self.nodes.len()];
        for (i, a) in self.arcs.iter().enumerate() {
            self.fan_out[a.from as usize].push(i as u32);
            self.fan_in[a.to as usize].push(i as u32);
        }
        self.levelize();
        self.case_analysis();
        // exceptions
        for e in &self.cons.exceptions {
            let mut f = (HashSet::new(), HashSet::new(), HashSet::new());
            let mut t = (HashSet::new(), HashSet::new(), HashSet::new());
            let mut th = HashSet::new();
            for o in &e.from {
                self.fill_obj(o, &mut f);
            }
            for o in &e.to {
                self.fill_obj(o, &mut t);
            }
            for o in &e.through {
                let mut tmp = (HashSet::new(), HashSet::new(), HashSet::new());
                self.fill_obj(o, &mut tmp);
                th.extend(tmp.1);
                for c in tmp.2 {
                    for p in 0..nl.cell(c).pins.len() {
                        if let Some(&n) = self.idx.get(&PinRef::Cell(c, p)) {
                            th.insert(n);
                        }
                    }
                }
            }
            self.exc_from.push(f);
            self.exc_to.push(t);
            self.exc_thr.push(th);
        }
        // path groups and path margins (from/to only)
        let fill2 = |me: &Self, from: &[Obj], to: &[Obj]| -> (ObjSets, ObjSets) {
            let mut f = (HashSet::new(), HashSet::new(), HashSet::new());
            let mut t = (HashSet::new(), HashSet::new(), HashSet::new());
            for o in from {
                me.fill_obj(o, &mut f);
            }
            for o in to {
                me.fill_obj(o, &mut t);
            }
            (f, t)
        };
        self.grp_sets = self.cons.path_groups.iter().map(|g| fill2(self, &g.from, &g.to)).collect();
        self.mar_sets = self.cons.path_margins.iter().map(|m| fill2(self, &m.from, &m.to)).collect();
        self.checks_store = checks;
        // clocks
        for c in &self.cons.clocks {
            let (p, r, f) = self.clock_shape(c);
            self.clk_period.push(p);
            self.clk_edges.push((r, f));
        }
    }

    fn fill_obj(&self, o: &Obj, s: &mut (HashSet<u16>, HashSet<u32>, HashSet<CellId>)) {
        match o {
            Obj::Clock(n) => {
                if let Some(i) = self.cons.clock(n) {
                    s.0.insert(i as u16);
                }
            }
            Obj::Cell(n) => {
                if let Some(c) = self.nl.cell_by_name(n) {
                    s.2.insert(c);
                }
            }
            _ => {
                for x in self.resolve(o) {
                    s.1.insert(x);
                }
            }
        }
    }

    fn clock_shape(&self, c: &Clock) -> (f64, f64, f64) {
        if let Some(g) = &c.gen {
            if let Some(mi) = self.cons.clock(&g.master) {
                let m = &self.cons.clocks[mi];
                let (mp, mr, mf) = self.clock_shape(m);
                if let Some(ed) = &g.edges {
                    let et = |k: i32| -> f64 {
                        let k = k - 1;
                        let cyc = (k / 2) as f64;
                        if k % 2 == 0 { mr + cyc * mp } else { mf + cyc * mp }
                    };
                    let (r, f, e) = (et(ed[0]), et(*ed.get(1).unwrap_or(&2)), et(*ed.get(2).unwrap_or(&3)));
                    return (e - r, r, f);
                }
                let p = mp * g.divide / g.multiply.max(1e-9);
                let (r, f) = if g.invert { (mr + p / 2.0, mr + p) } else { (mr, mr + p / 2.0) };
                return (p, r, f);
            }
        }
        (c.period, c.rise, c.fall)
    }

    fn levelize(&mut self) {
        loop {
            let n = self.nodes.len();
            let mut indeg = vec![0u32; n];
            for a in &self.arcs_active() {
                indeg[a.to as usize] += 1;
            }
            let mut q: Vec<u32> = (0..n as u32).filter(|&i| indeg[i as usize] == 0).collect();
            let mut order = Vec::with_capacity(n);
            let mut h = 0;
            while h < q.len() {
                let u = q[h];
                h += 1;
                order.push(u);
                for &ai in &self.fan_out[u as usize] {
                    let a = self.arcs[ai as usize];
                    if self.disabled_arcs.contains(&(a.from, a.to)) {
                        continue;
                    }
                    indeg[a.to as usize] -= 1;
                    if indeg[a.to as usize] == 0 {
                        q.push(a.to);
                    }
                }
            }
            if order.len() == n {
                self.topo = order;
                return;
            }
            // loops: Tarjan SCC on remaining nodes
            let rem: HashSet<u32> = (0..n as u32).filter(|i| indeg[*i as usize] > 0).collect();
            let sccs = self.tarjan(&rem);
            let mut broke = false;
            for scc in sccs {
                if scc.len() < 2 {
                    continue;
                }
                let set: HashSet<u32> = scc.iter().copied().collect();
                // order the loop for reporting: walk arcs inside the scc
                let mut path = vec![scc[0]];
                let mut cur = scc[0];
                let mut seen = HashSet::new();
                seen.insert(cur);
                'w: loop {
                    for &ai in &self.fan_out[cur as usize] {
                        let a = self.arcs[ai as usize];
                        if set.contains(&a.to) && !self.disabled_arcs.contains(&(a.from, a.to)) {
                            if a.to == scc[0] {
                                break 'w;
                            }
                            if seen.insert(a.to) {
                                path.push(a.to);
                                cur = a.to;
                                continue 'w;
                            }
                        }
                    }
                    break;
                }
                let names: Vec<String> = path.iter().map(|x| self.node_name(*x)).collect();
                // break: disable a cell arc into the loop (prefer cell arc whose 'to' is in scc)
                let mut br = None;
                for &u in &path {
                    for &ai in &self.fan_in[u as usize] {
                        let a = self.arcs[ai as usize];
                        if set.contains(&a.from) && matches!(a.k, AK::Cell(..) | AK::Gen(..)) && !self.disabled_arcs.contains(&(a.from, a.to)) {
                            br = Some((a.from, a.to));
                            break;
                        }
                    }
                    if br.is_some() {
                        break;
                    }
                }
                let br = br.unwrap_or_else(|| {
                    let a = self.fan_in[scc[0] as usize].iter().map(|ai| self.arcs[*ai as usize]).find(|a| set.contains(&a.from)).unwrap();
                    (a.from, a.to)
                });
                self.disabled_arcs.insert(br);
                self.broken_arcs.push(format!("{} -> {} (loop breaker)", self.node_name(br.0), self.node_name(br.1)));
                self.loops.push(names);
                broke = true;
            }
            if !broke {
                // fallback: disable every arc into remaining nodes
                for &u in &rem {
                    for &ai in &self.fan_in[u as usize].clone() {
                        let a = self.arcs[ai as usize];
                        self.disabled_arcs.insert((a.from, a.to));
                    }
                }
            }
        }
    }
    fn arcs_active(&self) -> Vec<Arc<'a>> {
        self.arcs.iter().filter(|a| !self.disabled_arcs.contains(&(a.from, a.to))).copied().collect()
    }
    fn tarjan(&self, rem: &HashSet<u32>) -> Vec<Vec<u32>> {
        let n = self.nodes.len();
        let mut index = vec![u32::MAX; n];
        let mut low = vec![0u32; n];
        let mut on = vec![false; n];
        let mut st: Vec<u32> = vec![];
        let mut out = vec![];
        let mut idx = 0u32;
        let mut nodes: Vec<u32> = rem.iter().copied().collect();
        nodes.sort();
        for &s in &nodes {
            if index[s as usize] != u32::MAX {
                continue;
            }
            // iterative DFS
            let mut cs: Vec<(u32, usize)> = vec![(s, 0)];
            index[s as usize] = idx;
            low[s as usize] = idx;
            idx += 1;
            st.push(s);
            on[s as usize] = true;
            while let Some(&mut (v, ref mut k)) = cs.last_mut() {
                let fo = &self.fan_out[v as usize];
                if *k < fo.len() {
                    let a = self.arcs[fo[*k] as usize];
                    *k += 1;
                    let w = a.to;
                    if !rem.contains(&w) || self.disabled_arcs.contains(&(a.from, a.to)) {
                        continue;
                    }
                    if index[w as usize] == u32::MAX {
                        index[w as usize] = idx;
                        low[w as usize] = idx;
                        idx += 1;
                        st.push(w);
                        on[w as usize] = true;
                        cs.push((w, 0));
                    } else if on[w as usize] {
                        low[v as usize] = low[v as usize].min(index[w as usize]);
                    }
                } else {
                    cs.pop();
                    if let Some(&(p, _)) = cs.last() {
                        low[p as usize] = low[p as usize].min(low[v as usize]);
                    }
                    if low[v as usize] == index[v as usize] {
                        let mut comp = vec![];
                        loop {
                            let w = st.pop().unwrap();
                            on[w as usize] = false;
                            comp.push(w);
                            if w == v {
                                break;
                            }
                        }
                        out.push(comp);
                    }
                }
            }
        }
        out
    }

    fn case_analysis(&mut self) {
        let nl = self.nl;
        for (i, &pr) in self.nodes.iter().enumerate() {
            if let Some(n) = nl.pin_net(pr) {
                if let Some(PinRef::Cell(c, _)) = nl.driver(n) {
                    match &nl.cell(c).kind {
                        Kind::Gen(GOp::C0) => self.consts[i] = Some(false),
                        Kind::Gen(GOp::C1) => self.consts[i] = Some(true),
                        Kind::Lib(l) => {
                            if let Some(t) = self.libs.cell(l).and_then(|x| x.tie) {
                                self.consts[i] = Some(t)
                            }
                        }
                        _ => {}
                    }
                }
            }
        }
        for (o, v) in &self.cons.case {
            for n in self.resolve(o) {
                self.consts[n as usize] = Some(*v);
            }
        }
        if !self.consts.iter().any(|c| c.is_some()) {
            return;
        }
        // forward 3-valued propagation in topo order
        let topo = self.topo.clone();
        for &u in &topo {
            let pr = self.nodes[u as usize];
            if self.consts[u as usize].is_some() {
                continue;
            }
            match pr {
                PinRef::Cell(c, p) => {
                    let cell = nl.cell(c);
                    if cell.pins[p].dir == Dir::In {
                        // load pin: copy from driver via net arc
                        let v = self.fan_in[u as usize].iter().find_map(|ai| {
                            let a = self.arcs[*ai as usize];
                            if matches!(a.k, AK::Net) { self.consts[a.from as usize] } else { None }
                        });
                        self.consts[u as usize] = v;
                    } else if cell.is_hport() {
                        // constants propagate through hierarchical boundary pins (as through hierarchical pins in STA)
                        let v = cell.pin("A").and_then(|pi| self.idx.get(&PinRef::Cell(c, pi))).and_then(|x| self.consts[*x as usize]);
                        self.consts[u as usize] = v;
                    } else if let Kind::Lib(l) = &cell.kind {
                        if let Some(lc) = self.libs.cell(l) {
                            if lc.seq.is_some() {
                                continue;
                            }
                            if let Some(f) = lc.pin(&cell.pins[p].name).and_then(|x| x.function.clone()) {
                                if let Some(e) = crate::liberty::parse_func(&f) {
                                    let get = |n: &str| -> Option<bool> { cell.pin(n).and_then(|pi| self.idx.get(&PinRef::Cell(c, pi))).and_then(|x| self.consts[*x as usize]) };
                                    self.consts[u as usize] = eval3(&e, &get);
                                }
                            }
                        }
                    }
                }
                PinRef::Port(_) => {
                    let v = self.fan_in[u as usize].iter().find_map(|ai| self.consts[self.arcs[*ai as usize].from as usize]);
                    self.consts[u as usize] = v;
                }
            }
        }
    }

    // ------------------------------------------------------------ delay calc
    fn delay(&self, a: &Arc<'a>, in_rf: usize, out_rf: usize, slew: f64, early: bool) -> Option<(f64, f64)> {
        let to_pr = self.nodes[a.to as usize];
        let load = self.nl.pin_net(to_pr).map(|n| self.net_c[n]).unwrap_or(0.0);
        match a.k {
            AK::Net => {
                if in_rf != out_rf {
                    return None;
                }
                if let PinRef::Cell(c, _) = to_pr {
                    if self.nl.cell(c).is_hport() {
                        return Some((0.0, slew)); // wire delay is taken on the far side of the boundary pin
                    }
                }
                let n = self.nl.pin_net(to_pr)?;
                let cl = self.lib_pin_cap(to_pr);
                let k = if self.routed_raw { 1.0 } else { self.corner.r_scale * self.corner.c_scale };
                let der = self.der(false, early, self.in_clock.get(), None, Some(n));
                let (d, sl) = match self.pin_mom.get(&to_pr) {
                    Some(m) => crate::rcnet::wire_delay(self.opts.dmodel, m, slew),
                    None => {
                        let routed = self.opts.routed.as_ref().and_then(|rc| rc.elmore.get(&to_pr)).map(|e| e * k);
                        let d = routed.unwrap_or_else(|| self.net_wr[n] * (self.net_wc[n] / 2.0 + cl));
                        (d, (slew * slew + (2.2 * d) * (2.2 * d)).sqrt())
                    }
                };
                Some((self.ann_adj(a.from, a.to, out_rf, early, d * der), sl))
            }
            AK::Gen(d, _) if d < 0.0 => {
                // hierarchical boundary pin: transparent
                if in_rf != out_rf {
                    return None;
                }
                Some((0.0, slew))
            }
            AK::Gen(d, s) => {
                let ok = match s {
                    Sense::Pos => in_rf == out_rf,
                    Sense::Neg => in_rf != out_rf,
                    Sense::Non => true,
                };
                if !ok {
                    return None;
                }
                Some((d + 0.5 * load, slew.max(0.02)))
            }
            AK::GenLaunch(d) => Some((d, 0.03)),
            AK::Cell(t, _) | AK::Launch(t, _) => {
                let ok = match t.sense {
                    Sense::Pos => in_rf == out_rf,
                    Sense::Neg => in_rf != out_rf,
                    Sense::Non => true,
                };
                if !ok && matches!(a.k, AK::Cell(..)) {
                    return None;
                }
                let (dt, st) = if out_rf == 0 { (&t.cell_rise, &t.rise_tran) } else { (&t.cell_fall, &t.fall_tran) };
                let load = self.eff_load(to_pr, load, slew, st.as_ref());
                let d = dt.as_ref().or(if out_rf == 0 { t.cell_fall.as_ref() } else { t.cell_rise.as_ref() })?.delay(slew, load);
                let s = st.as_ref().map(|x| x.delay(slew, load)).unwrap_or(d * 0.5);
                let clk = self.in_clock.get();
                let cid = match self.nodes[a.to as usize] {
                    PinRef::Cell(c, _) => Some(c),
                    _ => None,
                };
                let der = match (self.opts.aocv_on && !self.opts.ignore_derates, cid) {
                    (true, Some(c)) if !self.cell_der.contains_key(&c) => match self.aocv_der.get(&c) {
                        Some(f) => f[(if early { 1 } else { 0 }) + if clk { 2 } else { 0 }],
                        None => self.der(true, early, clk, cid, None),
                    },
                    _ => self.der(true, early, clk, cid, None),
                };
                Some((self.ann_adj(a.from, a.to, out_rf, early, d.max(0.0) * der), s.max(0.0)))
            }
        }
    }

    /// load seen by a driver: effective capacitance of its RC tree (Ceff on), or the total with
    /// the coupling capacitance scaled by the Miller factor
    pub(crate) fn eff_load(&self, drv: PinRef, load: f64, slew: f64, tran: Option<&crate::liberty::Table>) -> f64 {
        let Some((pi, dcc)) = self.drv_pi.get(&drv) else { return load };
        let tot = pi.c1 + pi.c2;
        let extra = (load + dcc - tot).max(0.0);           // load outside the tree (estimates)
        if !self.opts.ceff {
            return load + dcc;
        }
        match tran {
            Some(tb) => crate::rcnet::ceff_iterate(pi, &|c| tb.delay(slew, c + extra)).0 + extra,
            None => load + dcc,
        }
    }

    /// POCV sigma of an arc delay `d` (0 when POCV is off)
    fn sigma(&self, a: &Arc<'a>, d: f64) -> f64 {
        if self.opts.pocv_k <= 0.0 {
            return 0.0;
        }
        match (a.k, self.nodes[a.to as usize]) {
            (AK::Cell(..) | AK::Launch(..), PinRef::Cell(c, _)) => self.pocv_coef.get(&c).copied().unwrap_or(0.0) * d.abs(),
            (AK::Net, _) => self.opts.ocv.as_ref().map(|o| o.pocv_net).unwrap_or(0.0) * d.abs(),
            _ => 0.0,
        }
    }
    #[inline]
    fn eff_late(&self, m: f64, v: f64) -> f64 {
        if self.opts.pocv_k > 0.0 { m + self.opts.pocv_k * v.max(0.0).sqrt() } else { m }
    }
    #[inline]
    fn eff_early(&self, m: f64, v: f64) -> f64 {
        if self.opts.pocv_k > 0.0 { m - self.opts.pocv_k * v.max(0.0).sqrt() } else { m }
    }

    /// Graph-based AOCV depth: per cell, the smallest stage count of any timing path through it
    /// (launch arcs excluded, so register clock pins end clock paths and Q pins start data paths).
    /// Distance: diagonal of the bounding box of the cell and its drivers / loads.
    fn ocv_prepare(&mut self) {
        self.aocv_der.clear();
        self.aocv_depth.clear();
        self.pocv_coef.clear();
        let Some(ocv) = self.opts.ocv.clone() else { return };
        let n = self.nodes.len();
        let is_cell = |k: &AK| matches!(k, AK::Cell(..));
        if self.opts.aocv_on && !ocv.aocv.is_empty() {
            let inf_d = u32::MAX / 4;
            let mut fwd = vec![inf_d; n];
            let mut has_in = vec![false; n];
            for a in &self.arcs {
                if !matches!(a.k, AK::Launch(..) | AK::GenLaunch(_)) {
                    has_in[a.to as usize] = true;
                }
            }
            for u in 0..n {
                if !has_in[u] {
                    fwd[u] = 0;
                }
            }
            for &u in &self.topo {
                if fwd[u as usize] >= inf_d {
                    continue;
                }
                for &ai in &self.fan_out[u as usize] {
                    let a = &self.arcs[ai as usize];
                    if matches!(a.k, AK::Launch(..) | AK::GenLaunch(_)) {
                        continue;
                    }
                    let v = fwd[u as usize] + if is_cell(&a.k) { 1 } else { 0 };
                    if v < fwd[a.to as usize] {
                        fwd[a.to as usize] = v;
                    }
                }
            }
            let mut bwd = vec![inf_d; n];
            for &u in self.topo.iter().rev() {
                let mut best = inf_d;
                let mut any = false;
                for &ai in &self.fan_out[u as usize] {
                    let a = &self.arcs[ai as usize];
                    if matches!(a.k, AK::Launch(..) | AK::GenLaunch(_)) {
                        continue;
                    }
                    any = true;
                    let b = bwd[a.to as usize];
                    if b < inf_d {
                        best = best.min(b + if is_cell(&a.k) { 1 } else { 0 });
                    }
                }
                bwd[u as usize] = if any { best } else { 0 };
            }
            let mut depth: HashMap<CellId, u32> = HashMap::new();
            for a in &self.arcs {
                if let (AK::Cell(..), PinRef::Cell(c, _)) = (a.k, self.nodes[a.to as usize]) {
                    let f = fwd[a.from as usize];
                    let b = bwd[a.to as usize];
                    if f < inf_d && b < inf_d {
                        let d = f + 1 + b;
                        let e = depth.entry(c).or_insert(d);
                        *e = (*e).min(d);
                    }
                }
            }
            for (c, d) in depth {
                let cl = self.nl.cell(c);
                let lname = cl.lib().unwrap_or("").to_string();
                // distance: bbox of the cell and its directly connected cells
                let mut pts: Vec<(f64, f64)> = vec![];
                for p in &cl.pins {
                    if let Some(net) = p.net {
                        if self.nl.net(net).conns.len() <= 64 {
                            pts.extend(self.nl.net(net).conns.iter().filter_map(|q| self.nl.pin_loc(*q)));
                        }
                    }
                }
                let dist = if pts.len() >= 2 {
                    let (x0, x1) = pts.iter().fold((f64::MAX, f64::MIN), |a, p| (a.0.min(p.0), a.1.max(p.0)));
                    let (y0, y1) = pts.iter().fold((f64::MAX, f64::MIN), |a, p| (a.0.min(p.1), a.1.max(p.1)));
                    ((x1 - x0).powi(2) + (y1 - y0).powi(2)).sqrt()
                } else {
                    0.0
                };
                let mut f = [self.corner.derate(true, false, false), self.corner.derate(true, true, false), self.corner.derate(true, false, true), self.corner.derate(true, true, true)];
                let mut hit = false;
                for t in &ocv.aocv {
                    if !crate::netlist::glob(&t.pattern, &lname) && !crate::netlist::glob(&t.pattern, &format!("*/{}", lname)) {
                        continue;
                    }
                    let v = t.lookup(d as f64, dist);
                    for (k, slot) in f.iter_mut().enumerate() {
                        let early = k % 2 == 1;
                        let clock = k >= 2;
                        if (if early { t.early } else { t.late }) && (if clock { t.clock } else { t.data }) {
                            *slot = v;
                            hit = true;
                        }
                    }
                }
                if hit {
                    self.aocv_der.insert(c, f);
                }
                self.aocv_depth.insert(c, d);
            }
        }
        if self.opts.pocv_k > 0.0 {
            for c in self.nl.cell_ids() {
                let lname = self.nl.cell(c).lib().unwrap_or("").to_string();
                if lname.is_empty() {
                    continue;
                }
                let mut k = ocv.pocv_default;
                for (pat, v) in &ocv.pocv {
                    if crate::netlist::glob(pat, &lname) || crate::netlist::glob(pat, &format!("*/{}", lname)) {
                        k = *v;
                    }
                }
                if k > 0.0 {
                    self.pocv_coef.insert(c, k);
                }
            }
        }
    }

    /// CRPR: common clock path of a launch and a capture clock pin -> (pessimism credit, common
    /// late variance, common early variance)
    pub(crate) fn crpr(&self, launch: u32, capture: u32, clk: u16) -> (f64, f64, f64) {
        if !self.opts.crpr || self.cpar.is_empty() || !self.cons.clocks.get(clk as usize).map(|c| c.propagated).unwrap_or(false) {
            return (0.0, 0.0, 0.0);
        }
        let mut anc: HashSet<u32> = HashSet::new();
        let mut u = launch;
        for _ in 0..100000 {
            anc.insert(u);
            let p = self.cpar[u as usize];
            if p == NONE || p == u {
                break;
            }
            u = p;
        }
        let mut v = capture;
        for _ in 0..100000 {
            if anc.contains(&v) {
                if let Some(t) = self.ctags[v as usize].iter().filter(|t| t.clk == clk).max_by(|a, b| (a.lmax - a.lmin).partial_cmp(&(b.lmax - b.lmin)).unwrap()) {
                    return ((t.lmax - t.lmin).max(0.0), t.vmax, t.vmin);
                }
                return (0.0, 0.0, 0.0);
            }
            let p = self.cpar[v as usize];
            if p == NONE || p == v {
                break;
            }
            v = p;
        }
        (0.0, 0.0, 0.0)
    }

    // ------------------------------------------------------------ clock propagation
    fn propagate_clocks(&mut self) {
        self.ctags = vec![vec![]; self.nodes.len()];
        self.cpar = vec![NONE; self.nodes.len()];
        self.in_clock.set(true);
        // per-clock sense overrides: (node set for stop, positive, negative)
        let sense_sets = |me: &Self, ci: usize, kind: u8| -> HashSet<u32> {
            let nm = &me.cons.clocks[ci].name;
            me.cons.clock_sense.iter().filter(|(_, k, cl)| *k == kind && (cl.is_empty() || cl.iter().any(|c| crate::netlist::glob(c, nm)))).flat_map(|(o, _, _)| me.resolve(o)).collect()
        };
        let order: Vec<usize> = {
            let mut v: Vec<usize> = (0..self.cons.clocks.len()).filter(|&i| self.cons.clocks[i].gen.is_none()).collect();
            v.extend((0..self.cons.clocks.len()).filter(|&i| self.cons.clocks[i].gen.is_some()));
            v
        };
        for ci in order {
            let stops = sense_sets(self, ci, 0);
            let pos_only = sense_sets(self, ci, 1);
            let neg_only = sense_sets(self, ci, 2);
            let c = &self.cons.clocks[ci];
            let mut base = (c.src_lat.0, c.src_lat.1);
            if let Some(g) = &c.gen {
                for n in self.resolve(&g.source) {
                    if let Some(t) = self.ctags[n as usize].iter().find(|t| self.cons.clocks[t.clk as usize].name == g.master) {
                        base = (base.0 + t.lmax, base.1 + t.lmin);
                    }
                }
            }
            let srcs: Vec<u32> = c.sources.iter().flat_map(|o| self.resolve(o)).collect();
            let ideal = !c.propagated;
            for s in &srcs {
                let t = CTag { clk: ci as u16, inv: false, lmax: base.0 + if ideal { c.net_lat.0 } else { 0.0 }, lmin: base.1 + if ideal { c.net_lat.1 } else { 0.0 }, slew: c.transition, vmax: 0.0, vmin: 0.0 };
                self.ctags[*s as usize].retain(|x| x.clk != ci as u16 || c.gen.is_none());
                self.ctags[*s as usize].push(t);
            }
            // forward in topo order
            let topo = self.topo.clone();
            let srcset: HashSet<u32> = srcs.iter().copied().collect();
            for &u in &topo {
                // set_clock_sense -positive/-negative: keep only the requested unateness at this pin
                if pos_only.contains(&u) || neg_only.contains(&u) {
                    let want_inv = neg_only.contains(&u);
                    self.ctags[u as usize].retain(|t| t.clk != ci as u16 || t.inv == want_inv);
                }
                let tags: Vec<CTag> = self.ctags[u as usize].iter().filter(|t| t.clk == ci as u16).copied().collect();
                if tags.is_empty() || (stops.contains(&u) && !srcset.contains(&u)) {
                    continue;
                }
                for &ai in &self.fan_out[u as usize].clone() {
                    let a = self.arcs[ai as usize];
                    if self.disabled_arcs.contains(&(a.from, a.to)) || matches!(a.k, AK::Launch(..) | AK::GenLaunch(_)) {
                        continue;
                    }
                    if self.consts[a.to as usize].is_some() {
                        continue;
                    }
                    // other generated clock source overrides
                    let non_unate = matches!(a.k, AK::Cell(arc, _) if arc.sense == Sense::Non);
                    let mut tl: Vec<(CTag, bool)> = tags.iter().map(|t| (*t, false)).collect();
                    if non_unate {
                        // non-unate arc (XOR/MUX select): the clock reaches the output in both senses
                        tl.extend(tags.iter().map(|t| (*t, true)));
                    }
                    for (t, flip) in &tl {
                        let (inv2, d) = match a.k {
                            AK::Net => (t.inv, self.delay(&a, 0, 0, t.slew, false)),
                            AK::Cell(arc, _) => match arc.sense {
                                Sense::Neg => (!t.inv, self.delay(&a, 0, 1, t.slew, false)),
                                Sense::Non if *flip => (!t.inv, self.delay(&a, 0, 1, t.slew, false)),
                                _ => (t.inv, self.delay(&a, 0, 0, t.slew, false)),
                            },
                            AK::Gen(_, s) => (if s == Sense::Neg { !t.inv } else { t.inv }, self.delay(&a, 0, if s == Sense::Neg { 1 } else { 0 }, t.slew, false)),
                            _ => continue,
                        };
                        let Some((dl, sl)) = d else { continue };
                        let dmin = self.delay(&a, 0, 0, t.slew, true).map(|x| x.0).unwrap_or(dl);
                        let (sgl, sge) = if ideal { (0.0, 0.0) } else { (self.sigma(&a, dl), self.sigma(&a, dmin)) };
                        let nt = CTag {
                            clk: t.clk,
                            inv: inv2,
                            lmax: t.lmax + if ideal { 0.0 } else { dl },
                            lmin: t.lmin + if ideal { 0.0 } else { dmin },
                            slew: if ideal { c.transition } else { sl },
                            vmax: t.vmax + sgl * sgl,
                            vmin: t.vmin + sge * sge,
                        };
                        let (k_on, kk) = (self.opts.pocv_k > 0.0, self.opts.pocv_k);
                        let effl = |m: f64, v: f64| if k_on { m + kk * v.sqrt() } else { m };
                        let effe = |m: f64, v: f64| if k_on { m - kk * v.sqrt() } else { m };
                        let mut first = false;
                        let v = &mut self.ctags[a.to as usize];
                        if let Some(e) = v.iter_mut().find(|x| x.clk == nt.clk && x.inv == nt.inv) {
                            if effl(nt.lmax, nt.vmax) > effl(e.lmax, e.vmax) {
                                e.lmax = nt.lmax;
                                e.vmax = nt.vmax;
                                first = true;
                            }
                            if effe(nt.lmin, nt.vmin) < effe(e.lmin, e.vmin) {
                                e.lmin = nt.lmin;
                                e.vmin = nt.vmin;
                            }
                            e.slew = e.slew.max(nt.slew);
                        } else {
                            v.push(nt);
                            first = true;
                        }
                        if first {
                            self.cpar[a.to as usize] = u;
                        }
                    }
                }
            }
        }
    }

    fn end_clock_prop(&mut self) {
        self.in_clock.set(false);
    }

    fn edge_time(&self, clk: u16, ledge: u8) -> f64 {
        let (r, f) = self.clk_edges[clk as usize];
        if ledge == 0 { r } else { f }
    }

    // ------------------------------------------------------------ exception helpers
    fn exc_from_match(&self, k: usize, clk: u16, node: u32) -> bool {
        let (c, n, cells) = &self.exc_from[k];
        if c.is_empty() && n.is_empty() && cells.is_empty() {
            return false;
        }
        let cell_hit = match self.nodes[node as usize] {
            PinRef::Cell(cc, _) => cells.contains(&cc),
            _ => false,
        };
        c.contains(&clk) || n.contains(&node) || cell_hit
    }
    fn exc_to_match(&self, k: usize, cap: Option<u16>, node: u32) -> bool {
        let (c, n, cells) = &self.exc_to[k];
        if c.is_empty() && n.is_empty() && cells.is_empty() {
            return true;
        }
        let cell_hit = match self.nodes[node as usize] {
            PinRef::Cell(cc, _) => cells.contains(&cc),
            _ => false,
        };
        cap.map(|x| c.contains(&x)).unwrap_or(false) || n.contains(&node) || cell_hit
    }
    fn tag_based(&self, k: usize) -> bool {
        !self.exc_from[k].1.is_empty() || !self.exc_from[k].2.is_empty() || !self.exc_thr[k].is_empty()
    }
    fn start_exc(&self, clk: u16, node: u32) -> (u16, bool) {
        for k in self.exc_priority() {
            if !self.tag_based(k) {
                continue;
            }
            let fe = self.exc_from[k].0.is_empty() && self.exc_from[k].1.is_empty() && self.exc_from[k].2.is_empty();
            if fe {
                continue;
            }
            if self.exc_from_match(k, clk, node) {
                return ((k + 1) as u16, self.exc_thr[k].is_empty());
            }
        }
        (0, false)
    }
    fn sets_from(&self, s: &ObjSets, clk: u16, start: u32) -> bool {
        if s.0.is_empty() && s.1.is_empty() && s.2.is_empty() {
            return true;
        }
        let cell_hit = matches!(self.nodes.get(start as usize), Some(PinRef::Cell(c, _)) if s.2.contains(c));
        s.0.contains(&clk) || s.1.contains(&start) || cell_hit
    }
    fn sets_to(&self, s: &ObjSets, cap: u16, d: u32) -> bool {
        if s.0.is_empty() && s.1.is_empty() && s.2.is_empty() {
            return true;
        }
        let cell_hit = matches!(self.nodes.get(d as usize), Some(PinRef::Cell(c, _)) if s.2.contains(c));
        s.0.contains(&cap) || s.1.contains(&d) || cell_hit
    }
    fn from_mask(&self, clk: u16, start: u32) -> u64 {
        let mut m = 0u64;
        for (i, (f, _)) in self.grp_sets.iter().enumerate().take(48) {
            if self.sets_from(f, clk, start) {
                m |= 1 << i;
            }
        }
        for (j, (f, _)) in self.mar_sets.iter().enumerate().take(16) {
            if self.sets_from(f, clk, start) {
                m |= 1 << (48 + j);
            }
        }
        m
    }
    /// path group of a path (last matching user group wins, else the capture clock's group)
    fn path_group(&self, t: &Tag, cap: u16, d: u32) -> String {
        for (i, (f, to)) in self.grp_sets.iter().enumerate().rev() {
            let from_ok = if i < 48 { t.pgm & (1 << i) != 0 } else { self.sets_from(f, t.clk, t.start) };
            if from_ok && self.sets_to(to, cap, d) {
                return self.cons.path_groups[i].name.clone();
            }
        }
        self.cons.clocks.get(cap as usize).map(|c| c.name.clone()).unwrap_or_else(|| "**default**".into())
    }
    /// most restrictive set_path_margin on a path
    fn path_margin(&self, t: &Tag, cap: u16, d: u32, setup: bool) -> f64 {
        let mut m: Option<f64> = None;
        for (i, (f, to)) in self.mar_sets.iter().enumerate() {
            let pm = &self.cons.path_margins[i];
            let from_ok = if i < 16 { t.pgm & (1 << (48 + i)) != 0 } else { self.sets_from(f, t.clk, t.start) };
            if (if setup { pm.setup } else { pm.hold }) && from_ok && self.sets_to(to, cap, d) {
                m = Some(m.map_or(pm.value, |x: f64| x.max(pm.value)));
            }
        }
        m.unwrap_or(0.0)
    }
    fn note_group(ep: &mut EndPoint, g: &str, slack: f64) {
        if let Some(e) = ep.groups.iter_mut().find(|x| x.0 == g) {
            e.1 = e.1.min(slack);
        } else {
            ep.groups.push((g.to_string(), slack));
        }
    }
    /// per path group: (name, WNS, TNS, violating endpoints, endpoints), user groups first
    pub fn group_summary(&self) -> Vec<(String, f64, f64, usize, usize, f64)> {
        let mut order: Vec<String> = self.cons.path_groups.iter().map(|g| g.name.clone()).collect();
        let mut m: HashMap<String, (f64, f64, usize, usize, f64)> = HashMap::new();
        for ep in &self.endpoints {
            for (g, s) in &ep.groups {
                if !order.contains(g) {
                    order.push(g.clone());
                }
                let e = m.entry(g.clone()).or_insert((0.0, 0.0, 0, 0, f64::INFINITY));
                e.3 += 1;
                e.4 = e.4.min(*s);
                if *s < 0.0 {
                    e.0 = e.0.min(*s);
                    e.1 += *s;
                    e.2 += 1;
                }
            }
        }
        order.into_iter().map(|g| {
            let v = m.get(&g).copied().unwrap_or((0.0, 0.0, 0, 0, f64::INFINITY));
            (g, v.0, v.1, v.2, v.3, v.4)
        }).collect()
    }
    fn exc_priority(&self) -> Vec<usize> {
        let mut v: Vec<usize> = (0..self.cons.exceptions.len()).collect();
        v.sort_by_key(|&k| match self.cons.exceptions[k].kind {
            ExKind::False => 0,
            ExKind::MaxDelay(_) | ExKind::MinDelay(_) => 1,
            ExKind::Multicycle(..) => 2,
        });
        v
    }

    // ------------------------------------------------------------ data propagation
    fn add_tag(&mut self, n: u32, t: Tag) {
        let max = self.opts.max_tags;
        let v = &mut self.tags[n as usize];
        let _ = &v;
        if let Some(e) = v.iter_mut().find(|x| x.clk == t.clk && x.ledge == t.ledge && x.exc == t.exc && x.done == t.done && x.pgm == t.pgm) {
            let k = self.opts.pocv_k;
            let el = |m: f64, v: f64| if k > 0.0 { m + k * v.max(0.0).sqrt() } else { m };
            let ee = |m: f64, v: f64| if k > 0.0 { m - k * v.max(0.0).sqrt() } else { m };
            for rf in 0..2 {
                if el(t.at[rf], t.vr[rf]) > el(e.at[rf], e.vr[rf]) {
                    e.at[rf] = t.at[rf];
                    e.vr[rf] = t.vr[rf];
                    e.prev[rf] = t.prev[rf];
                    e.start = t.start;
                }
                if ee(t.atn[rf], t.vrn[rf]) < ee(e.atn[rf], e.vrn[rf]) {
                    e.atn[rf] = t.atn[rf];
                    e.vrn[rf] = t.vrn[rf];
                    e.prevn[rf] = t.prevn[rf];
                    e.startn = t.startn;
                }
                e.sl[rf] = e.sl[rf].max(t.sl[rf]);
                e.sln[rf] = e.sln[rf].min(t.sln[rf]);
            }
            return;
        }
        if v.len() >= max {
            // merge into the same-clock tag (conservative: drop exception state)
            if let Some(e) = v.iter_mut().find(|x| x.clk == t.clk) {
                for rf in 0..2 {
                    if t.at[rf] > e.at[rf] {
                        e.at[rf] = t.at[rf];
                        e.prev[rf] = t.prev[rf];
                    }
                    e.atn[rf] = e.atn[rf].min(t.atn[rf]);
                }
                return;
            }
        }
        v.push(t);
    }

    pub fn run(&mut self) {
        self.ocv_prepare();
        self.propagate_clocks();
        self.end_clock_prop();
        let n = self.nodes.len();
        self.tags = vec![vec![]; n];
        self.arc_d = vec![[[f64::NAN; 2]; 2]; self.arcs.len()];
        self.arc_dn = vec![[[f64::NAN; 2]; 2]; self.arcs.len()];
        self.clk_reached.clear();
        self.clk_pins.clear();
        // input port startpoints
        let nl = self.nl;
        for p in nl.port_ids() {
            if nl.ports[p].dir == Dir::Out {
                continue;
            }
            let Some(&u) = self.idx.get(&PinRef::Port(p)) else { continue };
            let pname = &nl.ports[p].name;
            let tran = self.cons.input_tran.iter().rev().find(|(o, _)| o.name() == pname).map(|x| x.1).unwrap_or(0.0);
            let mut any = false;
            for io in self.cons.io.iter().filter(|x| x.is_input && x.obj.name() == pname) {
                let clk = io.clock.as_ref().and_then(|c| self.cons.clock(c)).map(|x| x as u16).unwrap_or(NOCLK);
                let ledge = if io.clock_fall { 1 } else { 0 };
                let base = if clk != NOCLK { self.edge_time(clk, ledge) + self.cons.clocks[clk as usize].src_lat.0 } else { 0.0 };
                let (mx, mn) = (io.max.or(io.min).unwrap_or(0.0), io.min.or(io.max).unwrap_or(0.0));
                let (exc, done) = self.start_exc(clk, u);
                let pgm = self.from_mask(clk, u);
                self.add_tag(u, Tag { clk, ledge, exc, done, at: [base + mx; 2], atn: [base + mn; 2], sl: [tran; 2], sln: [tran; 2], prev: [(NONE, 0); 2], prevn: [(NONE, 0); 2], start: u, pgm, vr: [0.0; 2], vrn: [0.0; 2], startn: u });
                any = true;
            }
            if !any {
                self.add_tag(u, Tag { clk: NOCLK, ledge: 0, exc: 0, done: false, at: [0.0; 2], atn: [0.0; 2], sl: [tran; 2], sln: [tran; 2], prev: [(NONE, 0); 2], prevn: [(NONE, 0); 2], start: u, pgm: 0, vr: [0.0; 2], vrn: [0.0; 2], startn: u });
            }
            // clock-as-data: clock sources propagate data too
        }
        // black-box outputs and undriven inputs as unclocked starts
        for c in nl.cell_ids() {
            if let Kind::BlackBox(_) = nl.cell(c).kind {
                for (pi, p) in nl.cell(c).pins.iter().enumerate() {
                    if p.dir == Dir::Out {
                        if let Some(&u) = self.idx.get(&PinRef::Cell(c, pi)) {
                            self.add_tag(u, Tag { clk: NOCLK, ledge: 0, exc: 0, done: false, at: [0.0; 2], atn: [0.0; 2], sl: [0.05; 2], sln: [0.05; 2], prev: [(NONE, 0); 2], prevn: [(NONE, 0); 2], start: u, pgm: 0, vr: [0.0; 2], vrn: [0.0; 2], startn: u });
                        }
                    }
                }
            }
        }
        let topo = self.topo.clone();
        for &u in &topo {
            if self.consts[u as usize].is_some() {
                continue;
            }
            // launch arcs: clock tags at CK -> data tags at Q
            for &ai in &self.fan_out[u as usize].clone() {
                let a = self.arcs[ai as usize];
                if self.disabled_arcs.contains(&(a.from, a.to)) {
                    continue;
                }
                match a.k {
                    AK::Launch(t, _) => {
                        let rising = t.ttype == TType::RisingEdge;
                        let cts = self.ctags[u as usize].clone();
                        if !cts.is_empty() {
                            self.clk_reached.insert(u);
                        }
                        for ct in cts {
                            let clk_rise = rising != ct.inv;
                            let ledge = if clk_rise { 0 } else { 1 };
                            let et = self.edge_time(ct.clk, ledge);
                            let (exc, done) = self.start_exc(ct.clk, u);
                            let pgm = self.from_mask(ct.clk, u);
                            let mut tg = Tag { clk: ct.clk, ledge, exc, done, at: [f64::NEG_INFINITY; 2], atn: [inf(); 2], sl: [0.0; 2], sln: [inf(); 2], prev: [(u, 0); 2], prevn: [(u, 0); 2], start: u, pgm, vr: [0.0; 2], vrn: [0.0; 2], startn: u };
                            for orf in 0..2 {
                                if let Some((d, s)) = self.delay(&a, 0, orf, ct.slew, false) {
                                    let sg = self.sigma(&a, d);
                                    tg.vr[orf] = ct.vmax + sg * sg;
                                    tg.at[orf] = et + ct.lmax + d;
                                    tg.sl[orf] = s;
                                    self.arc_d[ai as usize][0][orf] = d;
                                    self.arc_d[ai as usize][1][orf] = d;
                                }
                                if let Some((d, s)) = self.delay(&a, 0, orf, ct.slew, true) {
                                    let sg = self.sigma(&a, d);
                                    tg.vrn[orf] = ct.vmin + sg * sg;
                                    tg.atn[orf] = et + ct.lmin + d;
                                    self.arc_dn[ai as usize][0][orf] = d;
                                    self.arc_dn[ai as usize][1][orf] = d;
                                    tg.sln[orf] = s;
                                }
                            }
                            self.add_tag(a.to, tg);
                        }
                    }
                    AK::GenLaunch(d) => {
                        let cts = self.ctags[u as usize].clone();
                        if !cts.is_empty() {
                            self.clk_reached.insert(u);
                        }
                        for ct in cts {
                            let ledge = if ct.inv { 1 } else { 0 };
                            let et = self.edge_time(ct.clk, ledge);
                            let (exc, done) = self.start_exc(ct.clk, u);
                            let pgm = self.from_mask(ct.clk, u);
                            self.add_tag(a.to, Tag { clk: ct.clk, ledge, exc, done, at: [et + ct.lmax + d; 2], atn: [et + ct.lmin + d; 2], sl: [0.03; 2], sln: [0.03; 2], prev: [(u, 0); 2], prevn: [(u, 0); 2], start: u, pgm, vr: [0.0; 2], vrn: [0.0; 2], startn: u });
                        }
                    }
                    _ => {}
                }
            }
            let tags = self.tags[u as usize].clone();
            if tags.is_empty() {
                continue;
            }
            for &ai in &self.fan_out[u as usize].clone() {
                let a = self.arcs[ai as usize];
                if self.disabled_arcs.contains(&(a.from, a.to)) || matches!(a.k, AK::Launch(..) | AK::GenLaunch(_)) {
                    continue;
                }
                if self.consts[a.to as usize].is_some() {
                    continue;
                }
                let thr: Vec<usize> = (0..self.exc_thr.len()).filter(|&k| self.exc_thr[k].contains(&a.to)).collect();
                for t in &tags {
                    let mut nt = Tag { clk: t.clk, ledge: t.ledge, exc: t.exc, done: t.done, at: [f64::NEG_INFINITY; 2], atn: [inf(); 2], sl: [0.0; 2], sln: [inf(); 2], prev: [(NONE, 0); 2], prevn: [(NONE, 0); 2], start: t.start, pgm: t.pgm, vr: [0.0; 2], vrn: [0.0; 2], startn: t.startn };
                    let mut any = false;
                    for irf in 0..2 {
                        if !t.at[irf].is_finite() {
                            continue;
                        }
                        for orf in 0..2 {
                            if let Some((d, s)) = self.delay(&a, irf, orf, t.sl[irf], false) {
                                let v = t.at[irf] + d;
                                let sg = self.sigma(&a, d);
                                let var = t.vr[irf] + sg * sg;
                                self.arc_d[ai as usize][irf][orf] = d;
                                if !nt.at[orf].is_finite() || self.eff_late(v, var) > self.eff_late(nt.at[orf], nt.vr[orf]) {
                                    nt.at[orf] = v;
                                    nt.vr[orf] = var;
                                    nt.prev[orf] = (u, irf as u8);
                                }
                                nt.sl[orf] = nt.sl[orf].max(s);
                                any = true;
                            }
                            if t.atn[irf].is_finite() {
                                if let Some((d, s)) = self.delay(&a, irf, orf, t.sln[irf], true) {
                                    let v = t.atn[irf] + d;
                                    let sg = self.sigma(&a, d);
                                    let var = t.vrn[irf] + sg * sg;
                                    self.arc_dn[ai as usize][irf][orf] = d;
                                    if !nt.atn[orf].is_finite() || self.eff_early(v, var) < self.eff_early(nt.atn[orf], nt.vrn[orf]) {
                                        nt.atn[orf] = v;
                                        nt.vrn[orf] = var;
                                        nt.prevn[orf] = (u, irf as u8);
                                    }
                                    nt.sln[orf] = nt.sln[orf].min(s);
                                }
                            }
                        }
                    }
                    if !any {
                        continue;
                    }
                    for &k in &thr {
                        if nt.exc == (k + 1) as u16 && !nt.done {
                            nt.done = true;
                        } else if nt.exc == 0 && self.exc_from[k].0.is_empty() && self.exc_from[k].1.is_empty() && self.exc_from[k].2.is_empty() {
                            nt.exc = (k + 1) as u16;
                            nt.done = true;
                        } else if nt.exc == 0 && !self.exc_from[k].0.is_empty() && self.exc_from[k].0.contains(&nt.clk) && self.exc_from[k].1.is_empty() {
                            nt.exc = (k + 1) as u16;
                            nt.done = true;
                        }
                    }
                    self.add_tag(a.to, nt);
                }
            }
        }
        self.check_endpoints();
        self.backprop();
        self.compute_drv();
        self.data_clock_mixing();
        self.summarize();
    }

    pub fn checks(&self) -> &Vec<Check<'a>> {
        &self.checks_store
    }

    fn relation(&self, lclk: u16, ledge: u8, cclk: u16, cedge: u8) -> (f64, f64) {
        let tl = self.clk_period[lclk as usize].max(1e-6);
        let tc = self.clk_period[cclk as usize].max(1e-6);
        let le = self.edge_time(lclk, ledge);
        let ce = self.edge_time(cclk, cedge);
        // common period
        let mut nl = 1;
        while nl < 64 {
            let m = nl as f64 * tl / tc;
            if (m - m.round()).abs() < 1e-6 {
                break;
            }
            nl += 1;
        }
        let mut best_s = f64::INFINITY;
        for j in 0..nl {
            let l = le + j as f64 * tl;
            let k = ((l - ce) / tc).floor() + 1.0;
            let mut e = ce + k * tc;
            if e <= l + 1e-9 {
                e += tc;
            }
            best_s = best_s.min(e - l);
        }
        (best_s, best_s - tc)
    }

    fn applicable_exc(&self, t: &Tag, cap: Option<u16>, node: u32, setup: bool) -> Option<&'a Exception> {
        let excs: &'a Vec<Exception> = &self.cons.exceptions;
        for k in self.exc_priority() {
            let e = &excs[k];
            if (setup && !e.setup) || (!setup && !e.hold) {
                continue;
            }
            if self.tag_based(k) {
                if t.exc == (k + 1) as u16 && t.done && self.exc_to_match(k, cap, node) {
                    return Some(e);
                }
                continue;
            }
            let from_empty = self.exc_from[k].0.is_empty();
            let to_empty = self.exc_to[k].0.is_empty() && self.exc_to[k].1.is_empty() && self.exc_to[k].2.is_empty();
            if from_empty && to_empty {
                continue;
            }
            if (from_empty || self.exc_from[k].0.contains(&t.clk)) && self.exc_to_match(k, cap, node) {
                return Some(e);
            }
        }
        None
    }
    fn unclocked_false(&self, start: u32) -> bool {
        (0..self.cons.exceptions.len()).any(|k| self.cons.exceptions[k].kind == ExKind::False && self.exc_from[k].1.contains(&start))
    }
    fn async_groups(&self, a: u16, b: u16) -> bool {
        if a == b {
            return false;
        }
        let an = &self.cons.clocks[a as usize].name;
        let bn = &self.cons.clocks[b as usize].name;
        for (_, gs) in &self.cons.clock_groups {
            let ga = gs.iter().position(|g| g.contains(an));
            let gb = gs.iter().position(|g| g.contains(bn));
            match (ga, gb) {
                (Some(x), Some(y)) if x != y => return true,
                (Some(_), None) | (None, Some(_)) if gs.len() == 1 => return true,
                _ => {}
            }
        }
        false
    }

    fn note_xing(&mut self, l: u16, c: u16, d: u32, status: u8, slack: f64, kind: char, start: u32) {
        if l == c || l == NOCLK {
            return;
        }
        let e = self.xing.entry((l, c)).or_insert_with(|| XStat { worst: f64::INFINITY, ..Default::default() });
        match status {
            0 => {
                e.timed.insert(d);
                e.worst = e.worst.min(slack);
            }
            1 | 2 => {
                let new = if status == 1 { e.false_path.insert(d) } else { e.asynch.insert(d) };
                if new {
                    self.xing_eps.push(XEp { node: d, launch: l, capture: c, asynch: status == 2, kind, start });
                }
            }
            _ => {}
        }
    }

    fn check_endpoints(&mut self) {
        self.xing.clear();
        self.xing_eps.clear();
        self.endpoints.clear();
        self.unconstrained.clear();
        let checks = self.checks_store.clone();
        let mut by_d: HashMap<u32, Vec<Check<'a>>> = HashMap::new();
        for c in checks {
            by_d.entry(c.d).or_default().push(c);
        }
        let mut keys: Vec<u32> = by_d.keys().copied().collect();
        keys.sort();
        for d in keys {
            let cs = &by_d[&d];
            let ck = cs[0].ck;
            self.clk_pins.push(ck);
            let ctags = self.ctags[ck as usize].clone();
            if !ctags.is_empty() {
                self.clk_reached.insert(ck);
            }
            let mut ep = EndPoint { node: d, name: self.node_name(d), setup_slack: inf(), hold_slack: inf(), setup_req: inf(), arrival: 0.0, tag: None, rf: 0, cap_clock: None, group: String::new(), groups: vec![], hold_tag: None, hold_rf: 0, hold_req: f64::NEG_INFINITY, setup_detail: vec![], hold_detail: vec![], is_port: false, reqs: vec![] };
            let mut constrained = false;
            if self.consts[d as usize].is_some() {
                continue;
            }
            for ct in &ctags {
                for chk in cs {
                    let clk_rise = chk.rising != ct.inv;
                    let cedge = if clk_rise { 0 } else { 1 };
                    let ckslew = ct.slew;
                    for t in self.tags[d as usize].clone() {
                        if t.clk == NOCLK {
                            if self.unclocked_false(t.start) {
                                constrained = true;
                            }
                            continue;
                        }
                        let setup = chk.kind == Chk::Setup;
                        let xk = if chk.recovery { 'R' } else if chk.gating { 'G' } else { 'D' };
                        if self.async_groups(t.clk, ct.clk) {
                            if setup {
                                self.note_xing(t.clk, ct.clk, d, 2, 0.0, xk, t.start);
                            }
                            continue;
                        }
                        let exc = self.applicable_exc(&t, Some(ct.clk), d, setup);
                        if matches!(exc.map(|e| &e.kind), Some(ExKind::False)) {
                            if setup {
                                self.note_xing(t.clk, ct.clk, d, 1, 0.0, xk, t.start);
                            }
                            constrained = true;
                            continue;
                        }
                        constrained = true;
                        let (mut rs, mut rh) = self.relation(t.clk, t.ledge, ct.clk, cedge);
                        let tc = self.clk_period[ct.clk as usize];
                        let le = self.edge_time(t.clk, t.ledge);
                        let clk = &self.cons.clocks[ct.clk as usize];
                        if let Some(e) = exc {
                            if let ExKind::Multicycle(m, start) = e.kind {
                                let per = if start { self.clk_period[t.clk as usize] } else { tc };
                                if setup {
                                    rs += (m - 1.0) * per;
                                } else {
                                    rh -= m * per;
                                }
                            }
                        }
                        // setup MCP shifts default hold
                        if !setup {
                            if let Some(se) = self.applicable_exc(&t, Some(ct.clk), d, true) {
                                if let ExKind::Multicycle(m, start) = se.kind {
                                    let per = if start { self.clk_period[t.clk as usize] } else { tc };
                                    rh += (m - 1.0) * per;
                                }
                            }
                        }
                        for rf in 0..2 {
                            if setup {
                                if !t.at[rf].is_finite() {
                                    continue;
                                }
                                let st = chk.arc.and_then(|a| if rf == 0 { a.rise_con.as_ref() } else { a.fall_con.as_ref() }).map(|tb| tb.constraint(ckslew, t.sl[rf])).unwrap_or(0.0);
                                let mut req = le + rs + ct.lmin - st - clk.unc_setup - if chk.gating { self.cons.cg_setup } else { 0.0 };
                                if let Some(e) = exc {
                                    if let ExKind::MaxDelay(v) = e.kind {
                                        req = le + v + ct.lmin - st;
                                    }
                                }
                                let pm = self.path_margin(&t, ct.clk, d, true);
                                req -= pm;
                                let (crpr, cvl, cve) = if t.clk == ct.clk { self.crpr(t.start, chk.ck, t.clk) } else { (0.0, 0.0, 0.0) };
                                req += crpr;
                                let socv = if self.opts.pocv_k > 0.0 { self.opts.pocv_k * (t.vr[rf] + ct.vmin - cvl - cve).max(0.0).sqrt() } else { 0.0 };
                                req -= socv;
                                let slack = req - t.at[rf];
                                let gname = self.path_group(&t, ct.clk, d);
                                {
                                    let mut det = vec![
                                        (format!("clock {} ({} edge)", clk.name, if cedge == 0 { "rise" } else { "fall" }), le + rs),
                                        (format!("clock network delay ({})", if clk.propagated { "propagated" } else { "ideal" }), ct.lmin),
                                        ("clock uncertainty".to_string(), -clk.unc_setup),
                                        (format!("library {} time", if chk.recovery { "recovery" } else if chk.gating { "clock gating setup" } else { "setup" }), -st),
                                    ];
                                    if pm != 0.0 {
                                        det.push(("path margin".into(), -pm));
                                    }
                                    if socv != 0.0 {
                                        det.push((format!("statistical adjustment ({:.1} sigma)", self.opts.pocv_k), -socv));
                                    }
                                    Self::note_req(&mut ep, ReqRec { clk: t.clk, ledge: t.ledge, rf: rf as u8, hold: false, req: req - crpr, ck: chk.ck, crpr_ok: t.clk == ct.clk, cap_clk: ct.clk, group: gname.clone(), detail: det });
                                }
                                Self::note_group(&mut ep, &gname, slack);
                                self.note_xing(t.clk, ct.clk, d, 0, slack, xk, t.start);
                                if slack < ep.setup_slack {
                                    ep.setup_slack = slack;
                                    ep.setup_req = req;
                                    ep.arrival = t.at[rf];
                                    ep.tag = Some((t.clk, t.ledge, t.exc));
                                    ep.rf = rf as u8;
                                    ep.cap_clock = Some(ct.clk);
                                    ep.group = gname.clone();
                                    ep.setup_detail = vec![
                                        (format!("clock {} ({} edge)", clk.name, if cedge == 0 { "rise" } else { "fall" }), le + rs),
                                        (format!("clock network delay ({})", if clk.propagated { "propagated" } else { "ideal" }), ct.lmin),
                                        ("clock uncertainty".into(), -clk.unc_setup),
                                        (format!("library {} time", if chk.recovery { "recovery" } else if chk.gating { "clock gating setup" } else { "setup" }), -st),
                                    ];
                                    if pm != 0.0 {
                                        ep.setup_detail.push(("path margin".into(), -pm));
                                    }
                                    if crpr != 0.0 {
                                        ep.setup_detail.push(("clock reconvergence pessimism".into(), crpr));
                                    }
                                    if socv != 0.0 {
                                        ep.setup_detail.push((format!("statistical adjustment ({:.1} sigma)", self.opts.pocv_k), -socv));
                                    }
                                }
                            } else {
                                if !t.atn[rf].is_finite() {
                                    continue;
                                }
                                let ht = chk.arc.and_then(|a| if rf == 0 { a.rise_con.as_ref() } else { a.fall_con.as_ref() }).map(|tb| tb.constraint(ckslew, t.sln[rf])).unwrap_or(0.0);
                                let mut req = le + rh + ct.lmax + ht + clk.unc_hold + if chk.gating { self.cons.cg_hold } else { 0.0 };
                                if let Some(e) = exc {
                                    if let ExKind::MinDelay(v) = e.kind {
                                        req = le + v + ct.lmax + ht;
                                    }
                                }
                                let hm = self.path_margin(&t, ct.clk, d, false);
                                req += hm;
                                let (crpr, cvl, cve) = if t.clk == ct.clk { self.crpr(t.startn, chk.ck, t.clk) } else { (0.0, 0.0, 0.0) };
                                req -= crpr;
                                let socv = if self.opts.pocv_k > 0.0 { self.opts.pocv_k * (t.vrn[rf] + ct.vmax - cvl - cve).max(0.0).sqrt() } else { 0.0 };
                                req += socv;
                                let slack = t.atn[rf] - req;
                                {
                                    let mut det = vec![
                                        (format!("clock {} ({} edge)", clk.name, if cedge == 0 { "rise" } else { "fall" }), le + rh),
                                        (format!("clock network delay ({})", if clk.propagated { "propagated" } else { "ideal" }), ct.lmax),
                                        ("clock uncertainty".to_string(), clk.unc_hold),
                                        (format!("library {} time", if chk.recovery { "removal" } else { "hold" }), ht),
                                    ];
                                    if hm != 0.0 {
                                        det.push(("path margin".into(), hm));
                                    }
                                    if socv != 0.0 {
                                        det.push((format!("statistical adjustment ({:.1} sigma)", self.opts.pocv_k), socv));
                                    }
                                    let gname = self.path_group(&t, ct.clk, d);
                                    Self::note_req(&mut ep, ReqRec { clk: t.clk, ledge: t.ledge, rf: rf as u8, hold: true, req: req + crpr, ck: chk.ck, crpr_ok: t.clk == ct.clk, cap_clk: ct.clk, group: gname, detail: det });
                                }
                                if slack < ep.hold_slack {
                                    ep.hold_slack = slack;
                                    ep.hold_req = req;
                                    ep.hold_tag = Some((t.clk, t.ledge, t.exc));
                                    ep.hold_rf = rf as u8;
                                    ep.hold_detail = vec![
                                        (format!("clock {} ({} edge)", clk.name, if cedge == 0 { "rise" } else { "fall" }), le + rh),
                                        (format!("clock network delay ({})", if clk.propagated { "propagated" } else { "ideal" }), ct.lmax),
                                        ("clock uncertainty".into(), clk.unc_hold),
                                        (format!("library {} time", if chk.recovery { "removal" } else { "hold" }), ht),
                                    ];
                                    if hm != 0.0 {
                                        ep.hold_detail.push(("path margin".into(), hm));
                                    }
                                    if crpr != 0.0 {
                                        ep.hold_detail.push(("clock reconvergence pessimism".into(), -crpr));
                                    }
                                    if socv != 0.0 {
                                        ep.hold_detail.push((format!("statistical adjustment ({:.1} sigma)", self.opts.pocv_k), socv));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if !constrained {
                if !self.tags[d as usize].is_empty() {
                    self.unconstrained.push(format!("{} ({})", ep.name, if ctags.is_empty() { "no clock at capture pin" } else { "no constrained startpoint" }));
                }
                continue;
            }
            self.endpoints.push(ep);
        }
        // output ports
        let nl = self.nl;
        for p in nl.port_ids() {
            if nl.ports[p].dir == Dir::In {
                continue;
            }
            let Some(&u) = self.idx.get(&PinRef::Port(p)) else { continue };
            let pname = nl.ports[p].name.clone();
            let ios: Vec<IoDelay> = self.cons.io.iter().filter(|x| !x.is_input && x.obj.name() == pname).cloned().collect();
            let mut ep = EndPoint { node: u, name: pname.clone(), setup_slack: inf(), hold_slack: inf(), setup_req: inf(), arrival: 0.0, tag: None, rf: 0, cap_clock: None, group: String::new(), groups: vec![], hold_tag: None, hold_rf: 0, hold_req: f64::NEG_INFINITY, setup_detail: vec![], hold_detail: vec![], is_port: true, reqs: vec![] };
            let mut constrained = false;
            let tags = self.tags[u as usize].clone();
            for io in &ios {
                let Some(ci) = io.clock.as_ref().and_then(|c| self.cons.clock(c)) else { continue };
                let ci = ci as u16;
                let cedge = if io.clock_fall { 1 } else { 0 };
                let clk = &self.cons.clocks[ci as usize];
                for t in &tags {
                    if t.clk == NOCLK {
                        if self.unclocked_false(t.start) {
                            constrained = true;
                        }
                        continue;
                    }
                    if self.async_groups(t.clk, ci) {
                        self.note_xing(t.clk, ci, u, 2, 0.0, 'O', t.start);
                        continue;
                    }
                    let exc_s = self.applicable_exc(t, Some(ci), u, true);
                    constrained = true;
                    if matches!(exc_s.map(|e| &e.kind), Some(ExKind::False)) {
                        self.note_xing(t.clk, ci, u, 1, 0.0, 'O', t.start);
                        continue;
                    }
                    let (mut rs, mut rh) = self.relation(t.clk, t.ledge, ci, cedge);
                    if let Some(ExKind::Multicycle(m, _)) = exc_s.map(|e| e.kind.clone()) {
                        rs += (m - 1.0) * self.clk_period[ci as usize];
                        rh += (m - 1.0) * self.clk_period[ci as usize];
                    }
                    if let Some(eh) = self.applicable_exc(t, Some(ci), u, false) {
                        if let ExKind::Multicycle(m, _) = eh.kind {
                            rh -= m * self.clk_period[ci as usize];
                        }
                    }
                    let le = self.edge_time(t.clk, t.ledge);
                    let (omax, omin) = (io.max.or(io.min).unwrap_or(0.0), io.min.or(io.max).unwrap_or(0.0));
                    let pm = self.path_margin(t, ci, u, true);
                    let hm = self.path_margin(t, ci, u, false);
                    let gname = self.path_group(t, ci, u);
                    for rf in 0..2 {
                        let mut req = le + rs + clk.src_lat.1 + if clk.propagated { 0.0 } else { clk.net_lat.1 } - omax - clk.unc_setup;
                        if let Some(ExKind::MaxDelay(v)) = exc_s.map(|e| e.kind.clone()) {
                            req = le + v - omax;
                        }
                        req -= pm;
                        if t.at[rf].is_finite() {
                            Self::note_group(&mut ep, &gname, req - t.at[rf]);
                            self.note_xing(t.clk, ci, u, 0, req - t.at[rf], 'O', t.start);
                        }
                        if t.at[rf].is_finite() {
                            let mut det = vec![(format!("clock {} ({} edge)", clk.name, if cedge == 0 { "rise" } else { "fall" }), le + rs), ("clock network delay (ideal)".into(), clk.src_lat.1 + clk.net_lat.1), ("clock uncertainty".into(), -clk.unc_setup), ("output external delay".into(), -omax)];
                            if pm != 0.0 {
                                det.push(("path margin".into(), -pm));
                            }
                            Self::note_req(&mut ep, ReqRec { clk: t.clk, ledge: t.ledge, rf: rf as u8, hold: false, req, ck: NONE, crpr_ok: false, cap_clk: ci, group: gname.clone(), detail: det });
                        }
                        let hreq0 = le + rh + clk.src_lat.0 - omin + clk.unc_hold + hm;
                        if t.atn[rf].is_finite() {
                            let det = vec![(format!("clock {} ({} edge)", clk.name, if cedge == 0 { "rise" } else { "fall" }), le + rh), ("clock uncertainty".into(), clk.unc_hold), ("output external delay".into(), -omin)];
                            Self::note_req(&mut ep, ReqRec { clk: t.clk, ledge: t.ledge, rf: rf as u8, hold: true, req: hreq0, ck: NONE, crpr_ok: false, cap_clk: ci, group: gname.clone(), detail: det });
                        }
                        if t.at[rf].is_finite() && req - t.at[rf] < ep.setup_slack {
                            ep.setup_slack = req - t.at[rf];
                            ep.setup_req = req;
                            ep.arrival = t.at[rf];
                            ep.tag = Some((t.clk, t.ledge, t.exc));
                            ep.rf = rf as u8;
                            ep.cap_clock = Some(ci);
                            ep.group = gname.clone();
                            ep.setup_detail = vec![(format!("clock {} ({} edge)", clk.name, if cedge == 0 { "rise" } else { "fall" }), le + rs), ("clock network delay (ideal)".into(), clk.src_lat.1 + clk.net_lat.1), ("clock uncertainty".into(), -clk.unc_setup), ("output external delay".into(), -omax)];
                            if pm != 0.0 {
                                ep.setup_detail.push(("path margin".into(), -pm));
                            }
                        }
                        let hreq = le + rh + clk.src_lat.0 - omin + clk.unc_hold + hm;
                        if t.atn[rf].is_finite() && t.atn[rf] - hreq < ep.hold_slack {
                            ep.hold_slack = t.atn[rf] - hreq;
                            ep.hold_req = hreq;
                            ep.hold_tag = Some((t.clk, t.ledge, t.exc));
                            ep.hold_rf = rf as u8;
                            ep.hold_detail = vec![(format!("clock {} ({} edge)", clk.name, if cedge == 0 { "rise" } else { "fall" }), le + rh), ("clock uncertainty".into(), clk.unc_hold), ("output external delay".into(), -omin)];
                        }
                    }
                }
            }
            // max_delay to port without output delay
            if ios.is_empty() {
                for t in &tags {
                    for k in self.exc_priority() {
                        let e = &self.cons.exceptions[k];
                        if let ExKind::MaxDelay(v) = e.kind {
                            if self.exc_to_match(k, None, u) && !(self.exc_to[k].1.is_empty() && self.exc_to[k].2.is_empty()) {
                                let le = if t.clk == NOCLK { 0.0 } else { self.edge_time(t.clk, t.ledge) };
                                for rf in 0..2 {
                                    let req = le + v;
                                    if t.at[rf].is_finite() && req - t.at[rf] < ep.setup_slack {
                                        ep.setup_slack = req - t.at[rf];
                                        ep.setup_req = req;
                                        ep.arrival = t.at[rf];
                                        ep.tag = Some((t.clk, t.ledge, t.exc));
                                        ep.rf = rf as u8;
                                        ep.group = "**default**".into();
                                        ep.setup_detail = vec![("max_delay".into(), v)];
                                        Self::note_group(&mut ep, "**default**", req - t.at[rf]);
                                    }
                                }
                                constrained = true;
                            }
                        }
                    }
                }
            }
            if !constrained {
                if !tags.is_empty() {
                    self.unconstrained.push(format!("{} ({})", pname, if ios.is_empty() { "output port without set_output_delay" } else { "no constrained startpoint: driven by unclocked logic/black box" }));
                }
                continue;
            }
            self.endpoints.push(ep);
        }
        // black-box inputs are unconstrained endpoints
        for c in nl.cell_ids() {
            if let Kind::BlackBox(m) = &nl.cell(c).kind {
                for (pi, p) in nl.cell(c).pins.iter().enumerate() {
                    if p.dir == Dir::In {
                        if let Some(&u) = self.idx.get(&PinRef::Cell(c, pi)) {
                            if !self.tags[u as usize].is_empty() && self.consts[u as usize].is_none() {
                                self.unconstrained.push(format!("{} (black-box '{}' input)", self.node_name(u), m));
                            }
                        }
                    }
                }
            }
        }
    }

    fn backprop(&mut self) {
        let n = self.nodes.len();
        self.req = vec![[inf(); 2]; n];
        self.reqn = vec![[f64::NEG_INFINITY; 2]; n];
        for ep in &self.endpoints {
            if ep.setup_slack.is_finite() {
                for rf in 0..2 {
                    let at = self.max_at(ep.node, rf);
                    if at.is_finite() {
                        let r = at + ep.setup_slack;
                        self.req[ep.node as usize][rf] = self.req[ep.node as usize][rf].min(r);
                    }
                }
            }
        }
        for &u in self.topo.iter().rev() {
            for &ai in &self.fan_out[u as usize] {
                let a = self.arcs[ai as usize];
                for irf in 0..2 {
                    for orf in 0..2 {
                        let d = self.arc_d[ai as usize][irf][orf];
                        if d.is_nan() {
                            continue;
                        }
                        let r = self.req[a.to as usize][orf] - d;
                        if r < self.req[u as usize][irf] {
                            self.req[u as usize][irf] = r;
                        }
                    }
                }
            }
        }
    }
    fn note_req(ep: &mut EndPoint, r: ReqRec) {
        if let Some(e) = ep.reqs.iter_mut().find(|e| e.clk == r.clk && e.ledge == r.ledge && e.rf == r.rf && e.hold == r.hold) {
            let tighter = if r.hold { r.req > e.req } else { r.req < e.req };
            if tighter {
                *e = r;
            }
        } else {
            ep.reqs.push(r);
        }
    }
    pub fn max_at(&self, n: u32, rf: usize) -> f64 {
        self.tags[n as usize].iter().filter(|t| t.clk != NOCLK).map(|t| t.at[rf]).fold(f64::NEG_INFINITY, f64::max)
    }
    pub fn slack(&self, n: u32) -> f64 {
        let mut s = inf();
        for rf in 0..2 {
            let a = self.max_at(n, rf);
            if a.is_finite() && self.req[n as usize][rf].is_finite() {
                s = s.min(self.req[n as usize][rf] - a);
            }
        }
        s
    }
    pub fn pin_slack(&self, pr: PinRef) -> f64 {
        self.idx.get(&pr).map(|n| self.slack(*n)).unwrap_or(inf())
    }
    pub fn pin_arrival(&self, pr: PinRef) -> f64 {
        self.idx.get(&pr).map(|n| self.max_at(*n, 0).max(self.max_at(*n, 1))).unwrap_or(0.0)
    }
    /// slew seen by timed paths: clock slew on clock-network pins, clocked data tags elsewhere
    pub fn pin_slew_timed(&self, pr: PinRef) -> f64 {
        let Some(&n) = self.idx.get(&pr) else { return 0.0 };
        let c = self.ctags[n as usize].iter().map(|t| t.slew).fold(f64::NAN, f64::max);
        let d = self.tags[n as usize].iter().filter(|t| t.clk != NOCLK).map(|t| t.sl[0].max(t.sl[1])).fold(f64::NAN, f64::max);
        match (c.is_nan(), d.is_nan()) {
            (false, true) => c,
            (true, false) => d,
            (false, false) => c.max(d),
            _ => self.pin_slew(pr),
        }
    }
    pub fn pin_slew(&self, pr: PinRef) -> f64 {
        self.idx.get(&pr).map(|n| self.tags[*n as usize].iter().map(|t| t.sl[0].max(t.sl[1])).fold(0.0, f64::max)).unwrap_or(0.0)
    }

    fn compute_drv(&mut self) {
        self.drv.clear();
        let nl = self.nl;
        let gmt = self.cons.max_tran.or(self.libs.default_max_tran());
        let gmf = self.cons.max_fanout.or(self.libs.default_max_fanout());
        let gmc = self.cons.max_cap.or(self.libs.default_max_cap());
        for n in nl.net_ids() {
            let Some(d) = nl.driver(n) else { continue };
            if matches!(d, PinRef::Cell(c, _) if nl.cell(c).is_hport()) {
                continue; // segment behind a boundary pin: checked on the driver's net
            }
            let loads = nl.loads(n);
            if loads.is_empty() {
                continue;
            }
            if let Some(&dn) = self.idx.get(&d) {
                if self.consts[dn as usize].is_some() {
                    continue;
                }
            }
            let nname = nl.net(n).name.clone();
            if let Some(&dn) = self.idx.get(&d) {
                if self.ctags[dn as usize].iter().any(|t| !self.cons.clocks[t.clk as usize].propagated) {
                    continue; // ideal clock network: excluded from DRV until CTS
                }
            }
            if self.cons.ideal_nets.iter().any(|o| o.name() == nname) {
                continue;
            }
            // fanout
            let lim_f = self.cons.obj_max_fanout.iter().find(|(o, _)| o.name() == nname).map(|x| x.1).or(gmf);
            if let Some(l) = lim_f {
                let fo = self.hp_fanout.get(&n).copied().unwrap_or(loads.len()) as f64;
                if fo > l {
                    self.drv.push(DrvViol { kind: "max_fanout", net: n, obj: nl.pin_name(d), actual: fo, limit: l });
                }
            }
            // capacitance at driver
            let pin_lim = match d {
                PinRef::Cell(c, p) => match &nl.cell(c).kind {
                    Kind::Lib(l) => self.libs.cell(l).and_then(|lc| lc.pin(&nl.cell(c).pins[p].name)).and_then(|lp| lp.max_cap),
                    _ => None,
                },
                _ => None,
            };
            let lim_c = match (pin_lim, gmc) {
                (Some(a), Some(b)) => Some(a.min(b)),
                (a, b) => a.or(b),
            };
            if let Some(l) = lim_c {
                if self.net_c[n] > l + 1e-9 {
                    self.drv.push(DrvViol { kind: "max_capacitance", net: n, obj: nl.pin_name(d), actual: self.net_c[n], limit: l });
                }
            }
            // transition at loads
            for l in &loads {
                let Some(&ln) = self.idx.get(l) else { continue };
                let s = self.tags[ln as usize].iter().map(|t| t.sl[0].max(t.sl[1])).fold(0.0, f64::max);
                let mut lim = gmt;
                if let PinRef::Cell(c, p) = l {
                    if let Kind::Lib(lc) = &nl.cell(*c).kind {
                        if let Some(x) = self.libs.cell(lc).and_then(|x| x.pin(&nl.cell(*c).pins[*p].name)).and_then(|x| x.max_tran) {
                            lim = Some(lim.map(|y| y.min(x)).unwrap_or(x));
                        }
                    }
                }
                if self.ctags[ln as usize].iter().any(|t| !self.cons.clocks[t.clk as usize].propagated) {
                    continue; // ideal clock network: transition is ideal
                }
                if self.clk_reached.contains(&ln) || !self.ctags[ln as usize].is_empty() {
                    for c in &self.cons.clocks {
                        if let Some(m) = c.max_tran {
                            lim = Some(lim.map(|y| y.min(m)).unwrap_or(m));
                        }
                    }
                }
                if let Some(lv) = lim {
                    if s > lv + 1e-9 {
                        self.drv.push(DrvViol { kind: "max_transition", net: n, obj: nl.pin_name(*l), actual: s, limit: lv });
                    }
                }
            }
        }
    }

    fn data_clock_mixing(&mut self) {
        self.clock_as_data.clear();
        self.data_as_clock.clear();
        let nl = self.nl;
        // clock reaching a data input of sequential cells (not clock pins)
        let checks = self.checks_store.clone();
        let dpins: HashSet<u32> = checks.iter().map(|c| c.d).collect();
        for &d in &dpins {
            if !self.ctags[d as usize].is_empty() {
                let gating = checks.iter().any(|c| c.d == d && c.gating);
                if !gating {
                    self.clock_as_data.push(format!("{} (clock '{}' used as data)", self.node_name(d), self.cons.clocks[self.ctags[d as usize][0].clk as usize].name));
                }
            }
        }
        // data (non-clock) logic gating a clock without an ICG: comb cell on clock path with a data input that is not a clock
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            let is_icg = cell.lib().and_then(|l| self.libs.cell(l)).map(|x| x.icg.is_some()).unwrap_or(false);
            if is_icg {
                continue;
            }
            let outs: Vec<u32> = (0..cell.pins.len()).filter(|&p| cell.pins[p].dir == Dir::Out).filter_map(|p| self.idx.get(&PinRef::Cell(c, p)).copied()).collect();
            if !outs.iter().any(|o| !self.ctags[*o as usize].is_empty()) {
                continue;
            }
            let ins: Vec<u32> = (0..cell.pins.len()).filter(|&p| cell.pins[p].dir == Dir::In).filter_map(|p| self.idx.get(&PinRef::Cell(c, p)).copied()).collect();
            if ins.len() >= 2 {
                for i in ins {
                    if self.ctags[i as usize].is_empty() && self.consts[i as usize].is_none() && !self.tags[i as usize].is_empty() {
                        self.data_as_clock.push(format!("{} (data signal gates clock without integrated clock-gating cell)", self.node_name(i)));
                    }
                }
            }
        }
    }

    fn summarize(&mut self) {
        self.wns = 0.0;
        self.tns = 0.0;
        self.whs = 0.0;
        self.ths = 0.0;
        self.nvp = 0;
        self.nvh = 0;
        for e in &self.endpoints {
            if e.setup_slack.is_finite() && e.setup_slack < 0.0 {
                self.wns = self.wns.min(e.setup_slack);
                self.tns += e.setup_slack;
                self.nvp += 1;
            }
            if e.hold_slack.is_finite() && e.hold_slack < 0.0 {
                self.whs = self.whs.min(e.hold_slack);
                self.ths += e.hold_slack;
                self.nvh += 1;
            }
        }
    }

    pub fn worst_setup(&self) -> f64 {
        self.endpoints.iter().map(|e| e.setup_slack).fold(inf(), f64::min)
    }

    /// Reconstruct the max (setup) or min (hold) path ending at endpoint.
    pub fn path(&self, ep: &EndPoint, hold: bool) -> Vec<(u32, u8, f64)> {
        let mut out = vec![];
        let (tagk, mut rf) = if hold { (ep.hold_tag, ep.hold_rf) } else { (ep.tag, ep.rf) };
        let Some((clk, ledge, exc)) = tagk else { return out };
        let mut n = ep.node;
        let mut guard = 0;
        loop {
            guard += 1;
            if guard > 100000 {
                break;
            }
            let t = self.tags[n as usize].iter().find(|t| t.clk == clk && t.ledge == ledge && t.exc == exc).or_else(|| self.tags[n as usize].iter().find(|t| t.clk == clk && t.ledge == ledge));
            let Some(t) = t else { break };
            let at = if hold { t.atn[rf as usize] } else { t.at[rf as usize] };
            out.push((n, rf, at));
            let (p, prf) = if hold { t.prevn[rf as usize] } else { t.prev[rf as usize] };
            if p == NONE {
                break;
            }
            if p == n {
                break;
            }
            // launch arc: predecessor is a clock pin (no data tag)
            if self.tags[p as usize].iter().all(|x| x.clk != clk || x.ledge != ledge) {
                out.push((p, prf, f64::NAN));
                break;
            }
            n = p;
            rf = prf;
        }
        out.reverse();
        out
    }

    pub fn cell_type_of(&self, n: u32) -> String {
        match self.nodes[n as usize] {
            PinRef::Cell(c, _) => match &self.nl.cell(c).kind {
                Kind::Lib(l) => l.clone(),
                Kind::Gen(g) => format!("**{:?}**", g),
                Kind::BlackBox(m) => format!("{} (black box)", m),
            },
            PinRef::Port(p) => if self.nl.ports[p].dir == Dir::In { "in".into() } else { "out".into() },
        }
    }
    pub fn launch_clock_lat(&self, ck_node: u32, clk: u16) -> f64 {
        self.ctags[ck_node as usize].iter().filter(|t| t.clk == clk).map(|t| t.lmax).fold(0.0, f64::max)
    }
    /// early (min) launch clock latency, for hold paths
    pub fn launch_clock_lat_early(&self, ck_node: u32, clk: u16) -> f64 {
        self.ctags[ck_node as usize].iter().filter(|t| t.clk == clk).map(|t| t.lmin).fold(f64::MAX, f64::min).min(1e9)
    }
}

/// 3-valued boolean evaluation
pub fn eval3(e: &BExpr, f: &dyn Fn(&str) -> Option<bool>) -> Option<bool> {
    match e {
        BExpr::Var(v) => f(v),
        BExpr::Const(b) => Some(*b),
        BExpr::Not(a) => eval3(a, f).map(|x| !x),
        BExpr::And(a, b) => match (eval3(a, f), eval3(b, f)) {
            (Some(false), _) | (_, Some(false)) => Some(false),
            (Some(true), Some(true)) => Some(true),
            _ => None,
        },
        BExpr::Or(a, b) => match (eval3(a, f), eval3(b, f)) {
            (Some(true), _) | (_, Some(true)) => Some(true),
            (Some(false), Some(false)) => Some(false),
            _ => None,
        },
        BExpr::Xor(a, b) => match (eval3(a, f), eval3(b, f)) {
            (Some(x), Some(y)) => Some(x ^ y),
            _ => None,
        },
    }
}

// ------------------------------------------------------------------ SDF data export

/// one delay arc for SDF: d[min|max][out rise|fall] (NaN = no such transition)
#[derive(Clone, Debug)]
pub struct SdfArc {
    pub from: PinRef,
    pub to: PinRef,
    pub cell: Option<CellId>,
    /// IOPATH from a clock pin: Some(true) posedge, Some(false) negedge
    pub edge: Option<bool>,
    pub d: [[f64; 2]; 2],
}
/// one timing check: v[min|max][data rise|fall]
#[derive(Clone, Debug)]
pub struct SdfCheck {
    pub cell: CellId,
    pub data: PinRef,
    pub clock: PinRef,
    pub kind: &'static str,
    pub clk_rise: bool,
    pub v: [[f64; 2]; 2],
}

impl<'a> Timing<'a> {
    fn sdf_delay(&self, ai: usize, early: bool) -> [f64; 2] {
        let a = &self.arcs[ai];
        let store = if early { &self.arc_dn } else { &self.arc_d };
        let mut out = [f64::NAN; 2];
        // clock-network arcs: evaluated at the propagated clock slew, with clock derates
        let ck: Vec<f64> = self.ctags[a.from as usize].iter().map(|t| t.slew).collect();
        if !ck.is_empty() && !matches!(a.k, AK::Launch(..)) {
            let prev = self.in_clock.get();
            self.in_clock.set(true);
            for orf in 0..2 {
                let mut v = f64::NAN;
                for irf in 0..2 {
                    for &sl in &ck {
                        if let Some((d, _)) = self.delay(a, irf, orf, sl, early) {
                            v = if v.is_nan() { d } else if early { v.min(d) } else { v.max(d) };
                        }
                    }
                }
                out[orf] = v;
            }
            self.in_clock.set(prev);
            return out;
        }
        for orf in 0..2 {
            let mut v = f64::NAN;
            for irf in 0..2 {
                let mut d = store.get(ai).map(|x| x[irf][orf]).unwrap_or(f64::NAN);
                if !d.is_finite() {
                    // not reached by propagation (constant / unclocked): evaluate at a nominal slew
                    let sl = self.pin_slew_timed(self.nodes[a.from as usize]).max(0.02);
                    d = self.delay(a, irf, orf, sl, early).map(|x| x.0).unwrap_or(f64::NAN);
                }
                if d.is_finite() {
                    v = if v.is_nan() { d } else if early { v.min(d) } else { v.max(d) };
                }
            }
            out[orf] = v;
        }
        out
    }
    fn is_hp_node(&self, n: u32) -> bool {
        matches!(self.nodes[n as usize], PinRef::Cell(c, _) if self.nl.cell(c).is_hport())
    }
    /// cell IOPATH arcs and INTERCONNECT arcs (hierarchy-boundary pins are walked through)
    pub fn sdf_arcs(&self) -> Vec<SdfArc> {
        let mut v = vec![];
        for (ai, a) in self.arcs.iter().enumerate() {
            let (cell, edge) = match a.k {
                AK::Cell(_, c) => (Some(c), None),
                AK::Launch(ta, c) => (Some(c), Some(!matches!(ta.ttype, crate::liberty::TType::FallingEdge))),
                AK::Net => (None, None),
                _ => continue,
            };
            if let Some(c) = cell {
                if self.nl.cell(c).is_hport() {
                    continue;
                }
            }
            if cell.is_none() && self.is_hp_node(a.to) {
                continue;
            }
            let (mn, mx) = (self.sdf_delay(ai, true), self.sdf_delay(ai, false));
            let mut from = a.from;
            let (mut amn, mut amx) = (mn, mx);
            if cell.is_none() {
                // walk back through boundary pins to the real driver
                let mut guard = 0;
                while self.is_hp_node(from) && guard < 64 {
                    guard += 1;
                    let Some(&pa) = self.fan_in[from as usize].first() else { break };
                    let pai = pa as usize;
                    let (pmn, pmx) = (self.sdf_delay(pai, true), self.sdf_delay(pai, false));
                    for r in 0..2 {
                        if pmn[r].is_finite() {
                            amn[r] += pmn[r];
                        }
                        if pmx[r].is_finite() {
                            amx[r] += pmx[r];
                        }
                    }
                    from = self.arcs[pai].from;
                }
            }
            v.push(SdfArc { from: self.nodes[from as usize], to: self.nodes[a.to as usize], cell, edge, d: [amn, amx] });
        }
        v
    }
    /// SETUP / HOLD / RECOVERY / REMOVAL checks, evaluated at the propagated slews
    pub fn sdf_checks(&self) -> Vec<SdfCheck> {
        let mut v = vec![];
        for c in &self.checks_store {
            let Some(arc) = c.arc else { continue };
            let PinRef::Cell(cell, _) = self.nodes[c.d as usize] else { continue };
            let ckslew = self.ctags[c.ck as usize].iter().map(|t| t.slew).fold(f64::NAN, f64::max);
            let ckslew = if ckslew.is_finite() { ckslew } else { 0.02 };
            let tg = &self.tags[c.d as usize];
            let mut val = [[f64::NAN; 2]; 2];
            for rf in 0..2 {
                let smax = tg.iter().map(|t| t.sl[rf]).filter(|x| x.is_finite()).fold(f64::NAN, f64::max);
                let smin = tg.iter().map(|t| t.sln[rf]).filter(|x| x.is_finite()).fold(f64::NAN, f64::min);
                let smax = if smax.is_finite() { smax } else { 0.02 };
                let smin = if smin.is_finite() { smin } else { smax };
                let tb = if rf == 0 { arc.rise_con.as_ref() } else { arc.fall_con.as_ref() };
                if let Some(tb) = tb {
                    val[0][rf] = tb.constraint(ckslew, smin);
                    val[1][rf] = tb.constraint(ckslew, smax);
                }
            }
            let kind = match (c.kind, c.recovery) {
                (Chk::Setup, false) => "SETUP",
                (Chk::Hold, false) => "HOLD",
                (Chk::Setup, true) => "RECOVERY",
                (Chk::Hold, true) => "REMOVAL",
            };
            if c.gating {
                continue;
            }
            v.push(SdfCheck { cell, data: self.nodes[c.d as usize], clock: self.nodes[c.ck as usize], kind, clk_rise: c.rising, v: val });
        }
        v
    }
}
