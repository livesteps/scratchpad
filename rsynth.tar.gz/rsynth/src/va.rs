//! Voltage areas (physical regions of UPF power domains) and power-domain selection /
//! highlighting for the floorplan GUI.
//!
//!  * `create_voltage_area -power_domains {PD..} -region {{x0 y0} {x1 y1}} [-name VA] [-guard_band {gx gy}]`
//!  * `remove_voltage_areas [-all] [names]`, `report_voltage_areas [-verbose]`, `get_voltage_areas [pattern]`
//!  * `get_power_domains [pattern] [-of_objects cells]`
//!  * `gui_highlight_power_domain [-add|-remove|-clear] [-color_by power_domain|hierarchy] [PD..]`
//!    (aliases `gui_select_power_domain`, `highlight_power_domain`), `gui_get_highlighted_power_domains`

use crate::fplan::*;
use crate::netlist::*;
use crate::phys::VoltageArea;
use crate::session::{args, ok, Session};
use crate::tcl::{err, split_list, to_list, Flow, R};

fn rect_of(s: &str) -> Option<Rect> {
    crate::fpcmd::parse_rect(s)
}
fn fr(r: &Rect) -> String {
    format!("({:.2},{:.2})-({:.2},{:.2})", r.0, r.1, r.2, r.3)
}
fn strip_obj(s: &str) -> String {
    crate::cons::Obj::parse(s).map(|o| o.name().to_string()).unwrap_or_else(|| s.trim_start_matches("power_domain:").to_string())
}

/// Per-domain cell statistics for the current netlist.
pub struct PdStats {
    pub cells: usize,
    pub placed: usize,
    pub inside: usize,
    pub outside: usize,
    pub iso: usize,
    pub ls: usize,
    pub ret: usize,
    pub area: f64,
}

impl Session {
    /// Domain of a leaf cell (None without UPF).
    pub(crate) fn cell_domain(&self, name: &str) -> Option<String> {
        if self.upf.domains.is_empty() {
            return None;
        }
        self.upf.domain_of(name)
    }
    pub(crate) fn va_of_domain(&self, pd: &str) -> Option<&VoltageArea> {
        self.fp.as_ref()?.vas.iter().find(|v| v.pds.iter().any(|p| p == pd))
    }
    pub(crate) fn pd_stats(&self, pd: &str) -> PdStats {
        let mut st = PdStats { cells: 0, placed: 0, inside: 0, outside: 0, iso: 0, ls: 0, ret: 0, area: 0.0 };
        let Some(nl) = self.nl.as_ref() else { return st };
        let va = self.va_of_domain(pd).map(|v| v.inner());
        for c in nl.cell_ids() {
            let cell = nl.cell(c);
            if matches!(cell.kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) {
                continue;
            }
            if self.cell_domain(&cell.name).as_deref() != Some(pd) {
                continue;
            }
            st.cells += 1;
            if let Kind::Lib(l) = &cell.kind {
                st.area += self.libs.iter().find_map(|x| x.cells.get(l)).map(|x| x.area).unwrap_or(0.0);
            }
            if cell.has_attr("iso") {
                st.iso += 1;
            }
            if cell.has_attr("ls") {
                st.ls += 1;
            }
            if cell.has_attr("ret") || cell.has_attr("retention") {
                st.ret += 1;
            }
            if let Some((x, y)) = cell.loc {
                st.placed += 1;
                if let Some(r) = va {
                    if x >= r.0 - 1e-6 && x <= r.2 + 1e-6 && y >= r.1 - 1e-6 && y <= r.3 + 1e-6 {
                        st.inside += 1;
                    } else {
                        st.outside += 1;
                    }
                }
            }
        }
        st
    }

    fn pd_names(&self, pats: &[String]) -> Result<Vec<String>, Flow> {
        if self.upf.domains.is_empty() {
            return err("No power domains: load_upf first (UPF-001)");
        }
        let mut v = vec![];
        for p in pats {
            let p = strip_obj(p);
            let m: Vec<String> = self.upf.domains.iter().filter(|d| glob(&p, &d.name)).map(|d| d.name.clone()).collect();
            if m.is_empty() {
                return err(&format!("Power domain '{}' not found (VA-001)", p));
            }
            for x in m {
                if !v.contains(&x) {
                    v.push(x);
                }
            }
        }
        Ok(v)
    }

    pub fn va_cmd(&mut self, name: &str, a: &[String]) -> Option<R> {
        Some(match name {
            "create_voltage_area" => self.c_create_va(a),
            "remove_voltage_areas" | "remove_voltage_area" => {
                let x = args(a, &[]);
                let Some(fp) = self.fp.as_mut() else { return Some(err("No floorplan (FP-001)")) };
                let pats: Vec<String> = x.pos.iter().flat_map(|p| split_list(p)).collect();
                let gone: Vec<String> = fp.vas.iter().filter(|v| x.has("-all") || pats.iter().any(|p| glob(p, &v.name))).map(|v| v.name.clone()).collect();
                fp.vas.retain(|v| !gone.contains(&v.name));
                fp.bounds.retain(|b| !(b.source == "voltage_area" && gone.contains(&b.name)));
                fp.pblk.retain(|b| !(b.source == "voltage_area" && gone.iter().any(|g| b.name.starts_with(&format!("{}__guard_", g)))));
                crate::info!("VA-110", "Removed {} voltage area(s)", gone.len());
                Ok(gone.len().to_string())
            }
            "get_voltage_areas" => {
                let x = args(a, &["-of_objects"]);
                let Some(fp) = self.fp.as_ref() else { return Some(Ok(String::new())) };
                let pat = x.pos.first().cloned().unwrap_or("*".into());
                let of: Vec<String> = x.get("-of_objects").map(|s| split_list(s).iter().map(|p| strip_obj(p)).collect()).unwrap_or_default();
                let v: Vec<String> = fp.vas.iter().filter(|v| glob(&pat, &v.name)).filter(|v| of.is_empty() || v.pds.iter().any(|p| of.contains(p))).map(|v| v.name.clone()).collect();
                Ok(to_list(&v))
            }
            "report_voltage_areas" | "report_voltage_area" => self.c_report_va(a),
            "get_power_domains" => {
                let x = args(a, &["-of_objects"]);
                if self.upf.domains.is_empty() {
                    return Some(Ok(String::new()));
                }
                if let Some(of) = x.get("-of_objects") {
                    let mut v: Vec<String> = vec![];
                    for o in split_list(of) {
                        if let Some(d) = self.cell_domain(&strip_obj(&o)) {
                            if !v.contains(&d) {
                                v.push(d);
                            }
                        }
                    }
                    return Some(Ok(to_list(&v)));
                }
                let pat = x.pos.first().cloned().unwrap_or("*".into());
                Ok(to_list(&self.upf.domains.iter().filter(|d| glob(&pat, &d.name)).map(|d| d.name.clone()).collect::<Vec<_>>()))
            }
            "gui_highlight_power_domain" | "gui_select_power_domain" | "highlight_power_domain" => {
                let x = args(a, &["-color_by"]);
                if let Some(cb) = x.get("-color_by") {
                    match cb.as_str() {
                        "power_domain" | "pd" | "domain" => self.gui_color_by = "pd".into(),
                        "hierarchy" | "hier" => self.gui_color_by = "hier".into(),
                        o => return Some(err(&format!("-color_by '{}': expected power_domain or hierarchy (GUI-101)", o))),
                    }
                }
                let pats: Vec<String> = x.pos.iter().flat_map(|p| split_list(p)).collect();
                if x.has("-clear") {
                    self.pd_hl.clear();
                }
                if !pats.is_empty() {
                    let v = match self.pd_names(&pats) {
                        Ok(v) => v,
                        Err(e) => return Some(Err(e)),
                    };
                    if x.has("-remove") {
                        self.pd_hl.retain(|d| !v.contains(d));
                    } else {
                        if !x.has("-add") {
                            self.pd_hl.clear();
                        }
                        for d in v {
                            if !self.pd_hl.contains(&d) {
                                self.pd_hl.push(d);
                            }
                        }
                    }
                    // select the cells of the highlighted domains too, so get_selection / report_selection agree
                    if let Some(nl) = self.nl.as_ref() {
                        let hl = self.pd_hl.clone();
                        let mut sel: Vec<String> = vec![];
                        for c in nl.cell_ids() {
                            let n = &nl.cell(c).name;
                            if matches!(nl.cell(c).kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) {
                                continue;
                            }
                            if self.cell_domain(n).map(|d| hl.contains(&d)).unwrap_or(false) {
                                sel.push(crate::cons::Obj::Cell(n.clone()).handle());
                            }
                        }
                        self.selection = sel;
                    }
                } else if x.has("-clear") {
                    self.selection.clear();
                }
                for d in &self.pd_hl {
                    let s = self.pd_stats(d);
                    let va = self.va_of_domain(d).map(|v| format!("voltage area {} {}", v.name, fr(&v.rect))).unwrap_or("no voltage area".into());
                    crate::info!("GUI-100", "Highlight power domain {}: {} cell(s), {} placed{}; {}", d, s.cells, s.placed, if s.outside > 0 { format!(", {} OUTSIDE its voltage area", s.outside) } else { String::new() }, va);
                }
                if self.pd_hl.is_empty() {
                    crate::info!("GUI-102", "No power domain highlighted");
                }
                Ok(to_list(&self.pd_hl))
            }
            "gui_get_highlighted_power_domains" => Ok(to_list(&self.pd_hl)),
            _ => return self.dcalc_cmd(name, a),
        })
    }

    fn c_create_va(&mut self, a: &[String]) -> R {
        let x = args(a, &["-power_domains", "-region", "-name", "-guard_band", "-boundary"]);
        let pds = match x.get("-power_domains") {
            Some(p) => self.pd_names(&split_list(p))?,
            None => return err("create_voltage_area: -power_domains required (CMD-001)"),
        };
        for d in &pds {
            let dm = self.upf.domains.iter().find(|x| x.name == *d).unwrap();
            if dm.include_scope || dm.elements.is_empty() || Some(d.clone()) == self.upf.top_domain() {
                return err(&format!("create_voltage_area: '{}' is the top-level domain; its voltage area is the default (die) area (VA-002)", d));
            }
        }
        let Some(r) = x.get("-region").or(x.get("-boundary")).and_then(|s| rect_of(s)) else {
            return err("create_voltage_area: -region {{x0 y0} {x1 y1}} required (CMD-001)");
        };
        let g = x.get("-guard_band").map(|s| s.split(|c: char| c.is_whitespace() || c == '{' || c == '}').filter_map(|v| v.parse::<f64>().ok()).collect::<Vec<_>>()).unwrap_or_default();
        let guard = match g.len() {
            0 => (0.0, 0.0),
            1 => (g[0], g[0]),
            _ => (g[0], g[1]),
        };
        if 2.0 * guard.0 >= r.2 - r.0 || 2.0 * guard.1 >= r.3 - r.1 {
            return err("create_voltage_area: guard band leaves no placeable area (VA-005)");
        }
        let members: Vec<String> = pds.iter().flat_map(|d| self.upf.domains.iter().find(|x| x.name == *d).unwrap().elements.clone()).collect();
        let fp = self.fp.as_mut().ok_or_else(|| Flow::Err("No floorplan: run read_def or initialize_floorplan first (FP-001)".into()))?;
        let n = x.get("-name").cloned().unwrap_or_else(|| format!("VA_{}", pds.join("_")));
        if overlap(&r, &fp.die) < area(&r) * 0.999 {
            crate::warn!("VA-003", "Voltage area '{}' extends outside the die", n);
        }
        for v in fp.vas.iter().filter(|v| v.name != n) {
            if overlap(&v.rect, &r) > 1e-9 {
                return err(&format!("Voltage area '{}' overlaps voltage area '{}' {} (VA-004)", n, v.name, fr(&v.rect)));
            }
            if let Some(p) = v.pds.iter().find(|p| pds.contains(p)) {
                return err(&format!("Power domain '{}' already has voltage area '{}' (VA-006)", p, v.name));
            }
        }
        let va = VoltageArea { name: n.clone(), pds: pds.clone(), rect: r, guard };
        let inner = va.inner();
        fp.vas.retain(|v| v.name != n);
        fp.vas.push(va);
        // the whole voltage area excludes other domains; the guard band is a hard keep-out ring
        fp.bounds.retain(|b| b.name != n);
        fp.bounds.push(Bound { name: n.clone(), kind: BoundKind::Exclusive, rect: Some(r), dims: None, members, source: "voltage_area".into(), resolved: Some(r) });
        let pre = format!("{}__guard_", n);
        fp.pblk.retain(|b| !b.name.starts_with(&pre));
        let ring = [(r.0, r.1, r.2, inner.1), (r.0, inner.3, r.2, r.3), (r.0, inner.1, inner.0, inner.3), (inner.2, inner.1, r.2, inner.3)];
        for (k, q) in ring.iter().enumerate() {
            if q.2 - q.0 > 1e-9 && q.3 - q.1 > 1e-9 {
                fp.pblk.push(PBlockage { name: format!("{}{}", pre, k), rect: *q, kind: PbKind::Hard, source: "voltage_area".into() });
            }
        }
        let cells: usize = pds.iter().map(|d| self.pd_stats(d).cells).sum();
        let need: f64 = pds.iter().map(|d| self.pd_stats(d).area).sum();
        let avail = area(&inner);
        crate::info!("VA-100", "Voltage area '{}' for {} {} (guard band {:.2} x {:.2}): {} cell(s), cell area {:.1} / {:.1} um^2 ({:.0}%)", n, pds.join(" "), fr(&r), guard.0, guard.1, cells, need, avail, 100.0 * need / avail.max(1e-9));
        if need > avail * 0.95 {
            crate::warn!("VA-007", "Voltage area '{}' is too small for its cells ({:.0}% utilization)", n, 100.0 * need / avail.max(1e-9));
        }
        Ok(n)
    }

    fn c_report_va(&mut self, a: &[String]) -> R {
        let x = args(a, &[]);
        let Some(fp) = self.fp.as_ref() else { return err("No floorplan (FP-001)") };
        crate::out!("****************************************\nReport : voltage_areas\nDesign : {}\n****************************************", fp.design);
        crate::out!("{:<16} {:<18} {:<30} {:>10} {:>7} {:>7} {:>8} {:>8} {:>6}", "Voltage area", "Power domains", "Region", "Guard", "Cells", "Placed", "Outside", "Foreign", "Util");
        let die = fp.die;
        let vas = fp.vas.clone();
        let mut bad = 0;
        for v in &vas {
            let (mut c, mut p, mut o, mut ar) = (0, 0, 0, 0.0);
            for d in &v.pds {
                let s = self.pd_stats(d);
                c += s.cells;
                p += s.placed;
                o += s.outside;
                ar += s.area;
            }
            // cells of other domains placed inside this voltage area
            let mut foreign = 0;
            if let Some(nl) = self.nl.as_ref() {
                for id in nl.cell_ids() {
                    let cell = nl.cell(id);
                    if matches!(cell.kind, Kind::Gen(GOp::C0) | Kind::Gen(GOp::C1)) {
                        continue;
                    }
                    if let Some((px, py)) = cell.loc {
                        let r = v.rect;
                        if px > r.0 + 1e-6 && px < r.2 - 1e-6 && py > r.1 + 1e-6 && py < r.3 - 1e-6 && !self.cell_domain(&cell.name).map(|d| v.pds.contains(&d)).unwrap_or(false) && !cell.fixed {
                            foreign += 1;
                        }
                    }
                }
            }
            bad += o + foreign;
            crate::out!("{:<16} {:<18} {:<30} {:>10} {:>7} {:>7} {:>8} {:>8} {:>5.0}%", v.name, v.pds.join(" "), fr(&v.rect), format!("{:.1}x{:.1}", v.guard.0, v.guard.1), c, p, o, foreign, 100.0 * ar / area(&v.inner()).max(1e-9));
        }
        if let Some(t) = self.upf.top_domain() {
            let s = self.pd_stats(&t);
            crate::out!("{:<16} {:<18} {:<30} {:>10} {:>7} {:>7} {:>8} {:>8} {:>6}", "DEFAULT_VA", t, fr(&die), "-", s.cells, s.placed, "-", "-", "-");
        }
        if x.has("-verbose") {
            for d in &self.upf.domains {
                let v = self.upf.domain_voltage(&d.name).map(|v| format!("{:.2}V", v)).unwrap_or("-".into());
                crate::out!("  {:<12} {:>6} {:<11} elements {}", d.name, v, if self.upf.switchable(&d.name) { "switchable" } else { "always-on" }, if d.elements.is_empty() { "(scope)".into() } else { d.elements.join(" ") });
            }
        }
        if bad > 0 {
            crate::warn!("VA-200", "{} cell(s) violate voltage areas (outside their own, or inside another domain's)", bad);
        }
        Ok(bad.to_string())
    }
}

#[allow(dead_code)]
fn _ok() -> R {
    ok()
}
