# Changelog

All notable changes to RSynth. The release version is in `Cargo.toml`. It is printed by
`rsynth -version` and by the Tcl `version` command (aliases `rsynth_version`, `getVersion`), and it
is shown in the README.

Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). Versioning: semantic, 0.x
while the command set is still growing.

> **Release history.** Release numbers were introduced in 0.11.0. Releases 0.1.0–0.10.0 were
> reconstructed from the project history (one release per development round, in order). Their
> dates were not recorded. Every entry below matches a row of the README status matrix.

---

## [0.14.0] — 2026-11-26

### Added
- **`help` pattern search in the shell.**
  - **Matching:** `help <pattern> [<pattern> ...]` lists every command, alias, Tcl built-in and user
    `proc` whose name matches.
    - Patterns are globs (`*`, `?`, `[..]`) and are case-insensitive; `help report_t*`,
      `help *gds*`.
    - A word without wildcards matches anywhere in the name (`help timing` = `help *timing*`).
    - An exact command name still shows that command's details.
  - **Output:** matches are grouped by area, each with its syntax. A match through an alias is
    marked `[alias name]`, and a description match `[description]`. A count line ends the list.
  - **Options:**
    - `-regexp <re>`: regular-expression match on names.
    - `-search <text>` (also `apropos <text>`): searches syntax, options and descriptions too.
    - `-area <area>`: restricts to one area; `-areas` lists the areas with their command counts.
    - `-verbose`: full details of every match.
    - `-names`: returns the matching names as a Tcl list for scripts, with no listing.
    - `-h`: lists the search options.
  - **Other behaviour:** a word matching a curated help group (`help dft`) also prints that group.
    No match gives "Did you mean: ..." suggestions (for example `help rpt_timng` suggests
    `report_timing`). An unknown option is an error (CMD-020).

### Changed
- Command descriptions in `help <command>` / `write_command_list` can come from a `//` comment
  directly above the command's dispatcher arm (section headers such as `// ---- routing` are
  ignored). This fixes the wrong descriptions of `save_db` / `restore_db`, and the logging and
  run-metrics commands now have proper ones.

## [0.13.1] — 2026-11-26

### Changed
- Tool messages name RSynth instead of other vendors' tools:
  - the startup banner reads "RSynth command set";
  - SDC-231 now says RSynth maps a dont_touch / preserved unmapped hierarchy rather than leaving it
    unmapped;
  - the `help` groups "Timing update & MMMC edits" and "Power planning" are labelled "RSynth style";
  - the package description reads "RSynth command set".
- Command names, options and aliases are unchanged (for example `compile_fusion`, camelCase
  aliases), so existing scripts keep working.

## [0.13.0] — 2026-11-26

### Added
- **Default run and command logs (Innovus style).** Every run writes `rsynth.run.log` (full session
  output, commands echoed as `<CMD> ...`) and `rsynth.cmd.log` (the user-level commands only,
  replayable with `source`) in the current directory, with no option.
  - **Numbering:** an earlier run's pair is kept; the next free `rsynth.run.logN` /
    `rsynth.cmd.logN` pair is used.
  - **Naming:** `set_log_filename <file.log>` / `set_cmd_filename <file.cmd>` (`setLogFileName`,
    `setCmdFileName`) move the files, keeping everything logged so far. `get_log_filename` /
    `get_cmd_filename` report them.
  - **Environment:** `RSYNTH_LOG_FILE` / `RSYNTH_CMD_FILE` preset the names; `-nolog` (or
    `RSYNTH_NOLOG=1`) turns both off.
  - **What is logged:** commands run by another command (SDC inside `read_sdc`, UPF inside
    `load_upf`) are not logged as user commands; `foreach_in_collection` / `redirect` bodies are.
- **Run metrics in the log.**
  - **Header:** version, host, user, PID, OS, CPUs, directory, command line and log files.
  - **Per command:** flow commands print `*** <cmd> #N [begin]` and
    `[finish] : cpu/real = ... (ratio), totSession cpu/real = ..., mem = ...M (peak ...M, +...M)`.
    Other commands print the `[finish]` line when they take at least `run_metrics.min_time`
    seconds (1.0).
  - **Stage QoR:** a `[metrics]` line after each implementation stage (cells, area, utilization,
    setup / hold WNS / TNS, DRVs, wirelength, opens / shorts).
  - **Excluded from reports:** metrics lines go to the terminal and the log, never into `redirect`
    files.
  - **End of run:** a per-command cpu / real / memory table, the stage QoR history, and
    `--- Ending "RSynth" (totcpu=..., real=..., mem=..., peak=...) ---`.
  - **Commands:** `report_run_metrics [-top n] [-file f]`, `get_run_metric`, `reset_run_metrics`.
  - **App options:** `run_metrics.enable`, `run_metrics.min_time`, `run_metrics.qor`.
- **Design database: `save_db design.odb`** (`write_db`, `saveDesign`, `save_design`) and
  **`restore_db design.odb`** (`read_design_db`, `restoreDesign`, `restore_design`, `open_db`).
  - **Format:** a single gzip file; a dependency-free DEFLATE / gzip codec is built in, readable by
    `zcat` / `gzip -t`. Compression is 6–7× for synthesized designs and 30–74× for routed designs.
  - **Contents:** a versioned binary image of the design:
    - netlist, hierarchy and names;
    - all parsed libraries and LEF;
    - **timing setup:** MMMC modes with every constraint, corners (libraries, derates, OCV / AOCV,
      parasitic scaling), scenarios with their analysis status, current mode / corner, SDF
      annotations;
    - **extraction:** routed RC networks and SPEF annotation per corner;
    - floorplan, placement, PG, blockages, fill and the detailed routing database;
    - CTS spec, route options, UPF, DFT setup, markers, app options, dont_use and stage history;
    - a timing snapshot (WNS / TNS / WHS / THS per scenario and overall).
  - **Restore check:** `restore_db` restores everything in a new session and compares the timing
    with the snapshot (DB-112 when all scenarios match). A damaged file leaves the session
    untouched (CRC and full decode before anything is replaced).
  - **`report_db`** shows a database's header.
- `route_opt -opc <opc_fill.rules>`.

### Changed
- The `-l` / `-log` command-line option was removed (warning CMD-006, the value is ignored); use
  `set_log_filename` / `set_cmd_filename`.
- The `-opc` command-line option was removed (warning CMD-007); give the OPC / litho rules to
  `route_auto` / `route_detail` / `route_opt -opc <rules>` (or `read_opc_rules`).
- The detailed router and the post-route repair are deterministic:
  - nets are routed in net-id order within each priority;
  - node ownership and minimum-area pieces are walked in sorted order;
  - before this change, hash-map order could change results between identical runs.
- Minimum-area repair reroutes each failing net alone and keeps the new route only when that net's
  own pieces improve.
- The regression test suite runs `rsynth` with `RSYNTH_NOLOG=1`.

## [0.12.0] — 2026-11-25

### Added
- **LEF-rule driven routing.** The detailed router follows the technology LEF:
  - **When it applies:** app option `route.detail.honor_tracks` (`auto` by default). In `auto`,
    track and spacing adherence is on when the tech LEF defines routing rules (OFFSET, AREA,
    SPACINGTABLE / RANGE, MINWIDTH, density, fill or antenna rules) or the design has explicit
    tracks; a plain LEF layer stack or the built-in layers keep the previous free grid. `true`
    forces it on and `false` turns it off. RT-110 and `check_route_rules` report the mode.
  - **Tracks:** wiring only on each layer's tracks (DEF TRACKS, else LEF PITCH / OFFSET).
    - Vias may stack through off-track points, and a one-step jog onto a track is allowed.
    - Wiring may run off-track within two grid steps of a pin.
    - When shorts remain at the end of negotiation, the conflicting nets get eight more rounds with
      off-track wiring allowed; `check_route_rules` then reports that wiring.
  - **Spacing:** LEF SPACING / SPACINGTABLE PARALLELRUNLENGTH / SPACING RANGE, converted to a grid
    halo and negotiated like shorts (RT-100 reports the remaining "LEF spacing conflicts").
  - **Minimum area:** LEF AREA patches along the preferred direction; pieces without room are
    rerouted (up to 5 rounds, never adding opens, shorts or spacing conflicts).
  - **RC:** RPERSQ / CPERSQDIST / EDGECAPACITANCE are parsed, together with MINWIDTH, MAXWIDTH,
    THICKNESS, density, FILLACTIVESPACING and antenna rules.
  - `report_layer_rules` lists the rules. `check_route_rules` (`verify_route_rules`) checks
    off-track wiring, width, spacing, shorts, minimum area, cut spacing and fill spacing, with
    markers.
- **Metal fill** (`add_metal_fill` / `addMetalFill` / `create_metal_fill`):
  - **Placement:** track-aligned fill per density window up to the target, keeping
    FILLACTIVESPACING from routing, PG, pins and obstructions, and never exceeding the maximum
    density.
  - **Trimming:** fill is trimmed automatically when routing changes.
  - **Related commands:** `delete_metal_fill`, `trim_metal_fill`, and `report_metal_density`
    (stepped LEF DENSITYCHECKWINDOW / STEP windows).
  - **Output:** fill is written to the DEF `FILLS` section (also read back), to GDS (datatype 1)
    and drawn in the GUI.
- **OPC / litho fill flow.** Rules files are loaded with `read_opc_rules` or `-opc` on route_* /
  `add_metal_fill` (the `rsynth -opc` command-line option of this release was removed in 0.13.0).
  - **Fill rules per layer:** fill size and spacing, active spacing, and min / target / max density.
  - **Litho routing:** assist fill next to isolated lines and line-end extension; forbidden
    parallel pitches cost extra in the router; `wrong_way off` adds a wrong-way penalty.
  - **Reporting:** `report_opc_rules`; `check_litho` reports forbidden-pitch pairs, isolated lines
    and wrong-way runs.
- **Route command options** on `route_auto` / `route_detail` / `route_global` / `route_eco`. They
  persist for later route calls.
  - `-timing_driven`: nets are routed in slack order (RT-130).
  - `-effort_level low|medium|high`.
  - `-min_layer` / `-max_layer`: global and detailed routing.
  - `-layer_jogs`: antenna repair by layer jumpers.
  - `-antenna_diode <cell>`: antenna repair by diodes after routing.
  - `-max_buffering_distance <um>`: net-length buffering after routing.
  - `-opc <rules>`.
- **Antenna:**
  - `check_antenna` (`verifyProcessAntenna`): partial-area ratio per gate and layer, LEF
    ANTENNAAREARATIO / ANTENNAGATEAREA; a driver, port or diode protects the gate.
  - `fix_antenna [-layer_jogs] [-diode cell]`.
  - New library cell `ANTENNA_X1_SVT` in the rs28 tt / ss / ff libraries.
- **Net-length buffering.**
  - **Commands:** `route_opt -max_net_length <um>` (app `route_opt.flow.max_net_length`),
    `fix_net_length` and `report_net_length`.
  - **Method:** bottom-up subtree clustering on the routed trees, so each driven net carries at
    most the limit of wire, followed by ECO legalization and routing. Up to three passes; it stops
    when the longest net no longer improves. Clock and dont_touch nets are skipped.
- **`route_opt -yield`** runs two steps in order:
  1. **Wire spreading:** a legal-only reroute with a cost for other-net wires on neighbouring tracks;
     nets without a legal spread route keep their route. It is kept only if opens, shorts, spacing
     and minimum-area violations do not increase.
  2. **Via swapping:** single-cut to double-cut vias (`VIAij_2CUT_H/V`) where the second cut keeps
     the LEF spacing plus one grid step; it is rolled back if route DRCs would increase.
  - Both steps are also available standalone: `optimize_wire_spreading` and `insert_redundant_vias`.
- **`add_tie_hi_lo`** (`addTieHiLo`, `add_tie_high`, `add_tie_low`) with `-cell {hi lo}`,
  `-max_fanout`, `-max_distance` and `-prefix`. Loads are clustered by location, existing tie cells
  over the limits are split, and constant output ports are included.
- **Port diodes:** `add_port_diodes` (`place_port_diodes`, `attachDiode`) `-cell <diode>
  [-ports] [-direction input|output|all]` puts a diode under each I/O port, connected and fixed.
- **Placement options** on `place_opt` / `place_detail`:
  - `-timing_driven`: critical cells are pulled toward their critical nets.
  - `-effort low|medium|high`: global iterations and detail passes.
  - `-congestion_effort low|medium|high`: maximum density and routing-blockage density.
  - `-preroute_as_blockages [{layers}]`: PG stripes, excluding followpins, become temporary hard
    placement blockages.
- **Example** `examples/route_rules/`: a rules tech LEF (`rs28_rules_tech.lef`), `opc_fill.rules`,
  a full flow (`route_rules_flow.tcl`) and a small regression flow (`route_rules_small.tcl`,
  `route_rules_test.tcl`).

### Changed
- `add_repeater` / `eco_add_repeater`: `-lib_cell` is replaced by `-buff_cell <buffer>` or
  `-inv_cell <inverter>`; with `-inv_cell`, `-stage_count` counts inverter pairs. `-lib_cell` now
  gives an error (ECO-241) naming the new options.
- `delete_repeater` is now an alias of `eco_delete_repeater` (with `-inv_pairs`).
- The router keeps a routing-order hint, so timing-driven order survives the negotiation sort.

## [0.11.0] — 2026-11-24

### Added
- **GUI selection model.**
  - **Click:** a layout click selects the instance, pin, port or routed wire under the cursor; Shift+click toggles.
  - **Box select:** left-drag selects the instances and ports inside the box; Ctrl+drag or middle-drag pans.
  - **Clearing:** Esc or ^D clears the selection.
  - **Shared selection:** the GUI selection is the session selection (`get_selection`, `report_selection`).
- **Flylines for pins and ports** as well as instances:
  - `gui_show_flylines -pins {inst/pin ..} -ports {..}` (with `-add`, `-remove` and `-clear`).
  - Clicking or box-selecting shows the flylines of everything selected, for up to 200 instances.
- **Pin picking.** When zoomed in, pin markers are drawn on the selected instances and a pin can
  be clicked. Cells without LEF pin shapes get their pins on the cell edges (inputs left, outputs
  right); flyline endpoints use the same positions.
- **Layout → schematic highlighting.** Selected instances, and the owners of selected pins, are
  highlighted in the schematic. The schematic is rebuilt around the selection (depth 1, up to 40
  instances) when the selection is not drawn.
- **Paginated QUERY pane.** `Q` lists the properties of the selected objects, one object per page,
  with ◀ / ▶ buttons, PgUp / PgDn and `[` / `]`. A box selection, or a click in the schematic, fills
  it right away.
- **Release versioning:** `rsynth -version`, the Tcl `version` command, a release line in the
  README, and this changelog.
- A GUI test hook, `RSYNTH_GTK_ACTIONS` (click, shift-click, box, key, zoom on named objects), for
  scripted GUI checks.

### Changed
- A layout click no longer queries properties; `Q` does. The query was what stopped flylines from
  showing on click.
- When an instance lies under routed wires, the instance wins the pick, so clicking an instance in
  a routed design selects the instance rather than a wire above it.
- When several ports are within reach of a click, the nearest one is picked rather than the first
  in the list.
- The GUI starts with an empty log pane; the key-binding banner was removed (key reference:
  `help` ▸ GUI).

## [0.10.0] — 2026-11-24

### Added
- **SystemVerilog stress suite** (`examples/svstress`):
  - 47 tests, each simulated against RSynth's netlist (Icarus / Verilator).
  - `--compile` maps the same tests to rs28 and checks them with `verify_equivalence`.
  - `check_errors.sh`: 15 malformed-input cases.
  - `fuzz.py`: mutation fuzzer, no panics or hangs over 1000+ mutants.
  - A simulator-free regression of 26 constant expressions.
- SV language features:
  - `**` with a variable exponent.
  - `repeat`, `while`, `do-while`, `foreach`, `break` and `continue`.
  - Tasks and void functions with output / inout arguments.
  - Packed unions and signed structs.
  - Assignment patterns typed by their target, and `type'{..}`.
  - Streaming operators.
  - Interfaces with ports, internal `assign` / `always` logic and method calls.
  - Hierarchical references into generate scopes and instances.
  - Constant functions in parameters, parameter arrays (lookup tables), struct-typed parameters,
    and parameters wider than 127 bits.
  - `$size`, `$left`, `$right`, `$high`, `$low`, `$countones`, `$onehot` and `$onehot0`.
  - `->` and `<->`.
- Preprocessor:
  - Macro default arguments.
  - Token pasting (``` `` ```).
  - Macro calls that span lines.
  - Commas inside `()` / `[]` / `{}` in macro arguments.

### Fixed
- **Signedness.** Operands are now extended by the type of the whole expression, not their own type,
  so `sa * 3'd3` is unsigned. Signed `/` and `%` are now computed signed.
- **Parameter width and signedness.** Parameters now take the declared type, or for an untyped
  parameter the type of its final value; before, every parameter was a 32-bit signed integer.
- **Variable-index array writes.** A narrow index no longer aliases higher elements, and nested
  variable indices are supported.
- **Partial reset.** A register missing from an asynchronous reset branch now holds its value
  during reset.
- **Variable initializers.** These are initial values now, not a second continuous driver.
- **Narrow outputs.** An output on a wider net now drives the extra bits with zero or sign extension.
- **Plain `case` items with `x` / `z`.** These now never match (ELAB-155).
- **Function / task inputs.** Writing to an input argument no longer corrupts the shared constant nets.
- **Body parameters.** These now stay in source order, so they can use body functions and types.
- **Macro arguments.** These are now substituted simultaneously.
- **`**` precedence.** It is now left-associative.
- **Netlist writer: unused reset / set pins.** These are now tied inactive on the generic flops, so
  the netlist simulates the same in 2-state simulators.
- **Netlist writer: escaped names.** Escaped scalar port names such as `\out[0] ` are preserved, and
  escaped bus bits are written `\bus [0]`.

## [0.9.0]

### Added
- **`update_timing [-full]`**: re-times only the scenarios whose constraints, corners, derates, OCV
  settings, netlist or parasitics changed. It is supported by `update_constraint_mode`,
  `update_delay_corner`, `update_analysis_view`, `set_analysis_view` and
  `report_timing_update_status`.
- **`free_design`** (`freeDesign`, `reset_session`), so the same session can load a design again;
  DC-style `reset_design`.
- **Clock tree specification.**
  - `write_clock_tree_spec` writes the spec file (`clocktree.cfg`): transition, buffer and inverter
    lists, skew and latency targets, dont_touch / dont_use, balance groups, and ignore / leaf /
    through / float pins.
  - Related commands: `read_clock_tree_spec`, `set_clock_tree_exceptions`,
    `create_clock_balance_group` and `report_clock_tree_spec`.
  - `clock_opt -spec / -write_spec / -trace`.
- **`trace_clock_tree`**: per-clock gates, buffers, sinks, macro / float pins and clock-as-data pins.
- **GUI Clock Tree Browser** tab: latency, levels, clock gates and sinks.

### Fixed
- Part-selects (reported as `i[3:9]`):
  - The netlist writer no longer reverses ascending port ranges.
  - Variable part-selects on ascending vectors are now correct.
  - Reversed selects are warned (ELAB-148).
  - Variable-start lvalue part-selects are supported.
  - Constant output bits are now assigned.

## [0.8.0]

### Added
- `report_timing_format` derate columns (`-derate -user_derate -ocv -aocv -pocv`).
- Placement pre-checks: `place_detail` and `legalize_placement` abort on ROW / SITE mismatches and
  IO-pad overlaps, with warnings (`check_row_site`, `check_io_overlaps`).
- Layout ruler (key `K`) and object query (`query_objects`, the QUERY pane).
- Nangate45 companion libraries (IO, gate-array, bump) with wire-bond and flip-chip examples.
- Concise command-line help (`rsynth -help`, `-gui`).

## [0.7.0]

### Added
- **Power planning**, Innovus-style:
  - `connect_global_net`, rings, stripes, followpins and `sroute`.
  - Via arrays.
- **Physical verification:**
  - `check_missing_vias`, DRC and LVS.
  - Calibre marker export / import.
  - Interactive fixing.
- **Non-default routing rules** (`create_route_rule`, presets `1w1s` to `3w3s`).
- GUI PG objects and markers; GUI schematic with pin tracing.
- **Multiply instantiated modules (MIM):** one block implementation reused by every instance.

## [0.6.0]

### Added
- `set_annotated_delay`, derates, `path_adjust` and the analysis type; `report_timing_format`;
  `change_names -rules`; Synopsys pragmas.
- **Timing models:**
  - ETM, QTM and ILM.
  - NDM-style and stub libraries.
- **Outputs:**
  - `write_spef` / `write_dspf` and `write_sdf` / `read_sdf`.
  - `export_gds` (GDSII stream out, with merge).
- Hierarchical block implementation with abstract timing; optimization controls in `place_opt`,
  `clock_opt` and `route_opt`.
- **Advanced DFT:**
  - On-chip clock control (OCC), scan compression and boundary scan.
  - Memory BIST and ATPG.
  - Test-mode timing.

## [0.5.0]

### Added
- **Native GTK 4 GUI** (`--features gtk`, `rsynth -gui`): layout with flylines, schematic, and
  navigation and layer panels. The HTML GUI was later removed; GTK is the only GUI.
- **Row / track commands:** core rows and routing tracks, Innovus-style with camelCase aliases.
- **Physical-only cells:** physical-only cells (end caps, well taps, fillers) and un-placement.
- **Shell and help:**
  - Command-line GUI options (`-gui`, `-no_gui`).
  - Complete generated command help.
  - Interactive line editing in the shell.

## [0.4.0]

### Added
- **Floorplanning:**
  - Chip and block floorplan creation.
  - IO pins by command.
  - Macro placement.
- **Chip IO:**
  - Pad ring / wire bond.
  - ESD / IO-ring checks.
  - Seal ring.
  - Flip-chip area IO with bumps and RDL.
- **Route editing:** add / delete / cut wires and vias.
- **ECO:**
  - Spare cells, gate-array and post-mask metal-only ECO.
  - Pre-mask netlist ECO (`eco_netlist -by_verilog_file`).

## [0.3.0]

### Added
- IO pin placement with layer assignment, and `check_pin_assignment`.
- `write_def` sections; `set_property -user` dont_touch / dont_use.
- Global DRV limits; `report_constraint`.
- Multi-corner SPEF and `report_annotated_parasitics`.
- Delay-calculation engines, including global-route parasitics.

## [0.2.0]

### Added
- **Place and route:**
  - Placement legalization and clock tree synthesis, with clock-tree display and analysis.
  - Detailed routing and route-based optimization (OCV / AOCV / POCV).
- **ECO and scripting:**
  - Timing path collections.
  - Collection-driven ECO.
  - Innovus / Tempus-style property scripting.
  - Per-pin timing and load properties.
  - Hierarchical pins and pin geometry.
- **Constraints:**
  - Object constraints (`set_dont_touch`, `set_size_only`, `set_dont_use`).
  - Clock sense, path groups, `set_path_margin`, `report_clocks` and `report_clock_crossing`.
  - Tolerant handling of unsupported SDC commands.
- **Hierarchy:**
  - Boundary optimization control and ungroup / flatten.
  - Hierarchical netlist output and netlist ECO.
- **Physical:**
  - `optimize_scan_chain`.
  - Voltage areas.
  - Floorplan GUI.
- **Queries:** queries and selection.

## [0.1.0]

### Added
- **Front-ends and linking:**
  - SystemVerilog (synthesizable subset with interfaces), Verilog-2001/2005 and VHDL.
  - Empty-module and black-box handling.
- **Shell and MMMC:**
  - Fusion-Compiler-style Tcl shell.
  - MMMC modes, corners and scenarios with concurrent PVT optimization.
  - Tempus-like timing checks and timing pessimism controls.
- **Optimization:**
  - Redundancy removal and sharing.
  - High-fanout synthesis and buffer-tree removal.
  - Pin swapping, restructuring and retiming.
  - Multi-Vt swapping.
  - Clock-gating insertion and clone / declone.
  - DRV fixing and tie cells.
- **Power intent:** UPF isolation, level shifters, AON and retention (UPF 1.0 / 1.1 / 2.x).
- **Physical:**
  - Floorplan editing after `read_def`.
  - IO pin planning.
  - Coarse placement and global-route estimation.
- **Hierarchy and test:**
  - Partitioning and time budgeting.
  - Scan insertion.
- **Outputs:**
  - Mapped Verilog and per-corner SPEF.
  - Liberty NLDM with power; CCS / ECSM parsed.
- **Built-in sequential co-simulation equivalence checker** (`verify_equivalence`).
