//! End-to-end regression tests: run the example flows with the built binary and
//! check QoR / verification markers in the transcript.
use std::process::Command;

/// flows that source flow.tcl write the same out/ files: run them one at a time
static FLOW_LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());

fn run(dir: &str, script: &str) -> String {
    let bin = env!("CARGO_BIN_EXE_rsynth");
    let out = Command::new(bin).env("RSYNTH_NOLOG", "1").current_dir(dir).args(["-f", script]).output().expect("run rsynth");
    String::from_utf8_lossy(&out.stdout).to_string() + &String::from_utf8_lossy(&out.stderr)
}

#[test]
fn full_mmmc_upf_dft_flow_is_equivalent() {
    let _g = FLOW_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let log = run("examples", "flow.tcl");
    assert!(log.contains("Verification SUCCEEDED: 41 outputs"), "equivalence failed:\n{}", &log[log.len().saturating_sub(4000)..]);
    assert!(log.contains("0 multi-voltage violation(s)"), "MV violations present");
    assert!(log.contains("Scan chain 3"), "scan insertion missing");
    assert!(log.contains("PWR-730"), "clock gating not inserted");
    assert!(!log.contains("Error: "), "errors in flow");
    // round-trip: re-import the written gate-level netlist and verify against RTL
    let log = run("examples", "roundtrip.tcl");
    assert!(log.contains("LINK-200"), "gate-level netlist not linked");
    assert!(log.contains("Verification SUCCEEDED: 41 outputs"), "round-trip mismatch:\n{}", log);
}

#[test]
fn legacy_verilog_vhdl_lint_and_eco() {
    let log = run("examples/legacy", "legacy.tcl");
    assert!(log.contains("Combinational feedback loops") && log.contains("loop 1 (3 cells)"));
    assert!(log.contains("MULTI-DRIVEN"));
    assert!(log.contains("non-uniquified"));
    assert!(log.contains("[BLACKBOX]"));
    assert!(log.contains("hold-fixing delay cell"));
    assert_eq!(log.matches("Verification SUCCEEDED").count(), 2, "{}", log);
}

#[test]
fn floorplan_place_opt_partition_budget_and_reassembly() {
    let log = run("examples", "fp_flow.tcl");
    assert!(log.contains("0 pin placement violation(s)"), "pin violations");
    assert!(log.contains("bound violations 0") && log.contains("blockage violations 0"), "placement violates floorplan constraints");
    assert!(log.contains("Verification SUCCEEDED: 41 outputs"), "place_opt broke function");
    assert!(log.contains("Re-read DEF: kept"), "DEF re-read did not merge user objects");
    let log = run("examples", "part_flow.tcl");
    assert!(log.contains("Budgeted partition 'lane0'"), "budgeting failed");
    // every feedthrough the final global route uses through an exclusive partition region is
    // realized as feedthrough ports of that partition
    let ctx = || log.lines().filter(|l| l.contains("PART-") || l.contains("Error") || l.contains("GR-100")).collect::<Vec<_>>().join("\n");
    let gr = log.lines().filter(|l| l.contains("GR-100")).last().and_then(|l| l.split(" feedthrough use").next()).and_then(|l| l.rsplit(", ").next()).and_then(|v| v.trim().parse::<usize>().ok()).unwrap_or_else(|| panic!("no GR-100:\n{}", ctx()));
    let realized: usize = log.lines().filter(|l| l.contains("PART-200")).filter_map(|l| l.split(" feedthrough)").next()).filter_map(|l| l.rsplit('(').next()).filter_map(|v| v.trim().parse::<usize>().ok()).sum();
    assert!(gr > 0 && realized == gr, "feedthrough not realized ({} routed, {} realized):\n{}", gr, realized, ctx());
    let log = run("examples", "part_verify.tcl");
    assert!(log.contains("Verification SUCCEEDED: 41 outputs"), "reassembled partitions not equivalent:\n{}", log);
}

#[test]
fn sdc_object_constraints_are_honored() {
    let log = run("examples", "sdc_semantics.tcl");
    for c in ["ICG_X1_SVT", "DLY4_X1_SVT", "ISO_AND_X1_SVT", "SDFFR_X1_SVT", "NAND2_X1_SVT"] {
        assert!(log.contains(&format!("PROBE {} 0", c)), "set_dont_use ignored for {}", c);
    }
    assert!(log.contains("DT_PRESERVED 1"), "dont_touch hierarchy was modified:\n{}", log.lines().filter(|l| l.starts_with("ADDED") || l.starts_with("GONE")).collect::<Vec<_>>().join("\n"));
    assert!(log.contains("SENSE 15"), "set_sense did not match the clock pins");
    assert!(log.contains("SDC-210") && log.contains("SDC-900"), "unsupported SDC not reported");
    assert!(log.contains("Verification SUCCEEDED: 41 outputs"), "equivalence failed");
}

#[test]
fn path_groups_margin_scan_reorder_and_cdc() {
    let log = run("examples", "pg_scan.tcl");
    assert!(log.contains("Report : path_groups") && log.contains("in2reg") && log.contains("lane0"), "path groups missing");
    assert!(log.contains("Path Group: reg2out"), "report_timing -groups");
    assert!(log.contains("path margin"), "set_path_margin not applied");
    assert!(log.contains("TIM-304"), "delete_path_groups");
    assert_eq!(log.matches(" OK (").count(), 4, "scan chains broken after reordering");
    assert!(log.contains("DFT-300"), "optimize_scan_chain did not run");
    assert!(log.contains("Verification SUCCEEDED: 41 outputs"), "equivalence failed after scan reorder");
    let log = run("examples/cdc", "cdc.tcl");
    assert!(log.contains("2-FF synchronizer") && log.contains("UNSYNCHRONIZED") && log.contains("glitch risk"), "CDC classification");
    assert!(log.contains("synchronous (timed)"), "timed crossing");
    assert!(log.contains("clka_div2") && log.contains("divide_by 2"), "report_clocks generated clock");
}

#[test]
fn boundary_optimization_ungroup_flatten_and_hier_netlist() {
    let log = run("examples/hier", "hier_flow.tcl");
    let cells = |tag: &str| -> usize {
        let l = log.lines().find(|l| l.starts_with(&format!("RESULT {} ", tag))).unwrap_or_else(|| panic!("no RESULT {}", tag));
        l.rsplit('=').next().unwrap().trim().parse().unwrap()
    };
    assert!(cells("bopt_on") < cells("bopt_off"), "boundary optimization should remove cross-boundary logic");
    assert!(cells("inst_off") < cells("bopt_off") && cells("inst_off") > cells("bopt_on"), "per-instance boundary control");
    assert_eq!(cells("flatten"), cells("bopt_on"), "flatten must open all boundaries");
    assert!(log.contains("ELAB-411"), "re-elaboration for boundary preservation");
    assert!(log.contains("Auto-ungroup (area)"), "auto ungroup");
    assert!(log.contains("Ungrouped 2 hierarchies: u_p0, u_p1"), "ungroup by collection");
    assert_eq!(log.matches("Verification SUCCEEDED: 11 outputs").count(), 9, "equivalence (8 runs + hierarchical read-back)");
}

#[test]
fn eco_commands_queries_selection_and_replay() {
    let log = run("examples/hier", "eco_query.tcl");
    for k in ["INPUTS: clk a[0]", "REGS: q_reg[0]", "CLOCKS: clk", "NET_OF_D: y[0]", "LEAF_PINS: ", "RX_NETS: q[0] q[1] q[2] q[3]", "RX_PINS: 16", "NOCASE: p0_reg", "SCOPE: u_alu", "SEL: 11", "SEL_AFTER: 0"] {
        assert!(log.contains(k), "query output missing: {}", k);
    }
    let rx: usize = log.lines().find(|l| l.starts_with("RX_CELLS:")).unwrap()[9..].trim().parse().unwrap();
    let gl: usize = log.lines().find(|l| l.starts_with("GLOB_CELLS:")).unwrap()[11..].trim().parse().unwrap();
    assert!(rx > 0 && rx == gl, "regexp vs glob cell query");
    assert!(log.contains("Report : transitive_fanout") && log.contains("Report : transitive_fanin"));
    assert!(log.contains("ODD_INV: eco_add_repeater: inverter"), "odd inverter chain must be refused");
    assert!(log.contains("SIZE_WRONG_FUNC: eco_sizecell: no instance was sized"));
    assert!(log.contains("AFTER_UP: XOR2_X2") && log.contains("AFTER_DOWN: XOR2_X1"), "auto up/down sizing");
    assert!(log.contains("NOPUNCH_HIER: connect: net 'eco_obs' and the pin(s) are in different hierarchies"));
    assert!(log.contains("Removed 0 buffer(s) and 1 inverter pair(s)") && log.contains("Removed 2 buffer(s)"));
    assert_eq!(log.matches("Verification SUCCEEDED: 11 outputs").count(), 3, "function-preserving ECOs must verify");
    assert!(log.contains("Verification FAILED"), "functional ECO must be detected");
    assert!(log.contains("Wrote 18 ECO change(s)"), "ECO log");
}

#[test]
fn place_cts_route_route_opt_with_ocv_aocv_pocv_crpr() {
    let log = run("examples", "pnr_flow.tcl");
    assert!(!log.contains("Error: "), "errors in flow:\n{}", &log[log.len().saturating_sub(4000)..]);
    // legal placement before and after route_opt ECOs
    assert_eq!(log.matches("Violations             : 0").count(), 2, "illegal placement");
    // CTS built, clocks propagated, skew reported
    assert!(log.contains("clocks are now propagated (CTS-300)"));
    assert!(log.contains("Global skew (late latency spread)"));
    // detailed routing is clean before and after route_opt
    assert_eq!(log.matches("check_routes: no opens, no shorts").count(), 2, "routing DRC");
    assert!(log.contains("[route_opt 1   ]") && log.contains("opens 0 shorts 0"));
    // margins: AOCV and POCV loaded and applied
    assert!(log.contains("2 AOCV table(s), 0 POCV") && log.contains("Cells with AOCV derates"));
    assert!(log.contains("statistical adjustment (3.0 sigma)"));
    assert!(log.contains("extracted from detailed routes"));
    assert_eq!(log.matches("Verification SUCCEEDED: 41 outputs").count(), 2, "equivalence after PnR");
    // clock-tree analysis
    assert!(log.contains("Report : clock_qor -type level") && log.contains("8xBUF_X4_SVT"), "level report");
    assert!(log.contains("[buffer,cts]") && log.contains("direct sink(s)"), "structure report");
    assert!(log.contains("Latency late max"), "latency report");
    assert!(log.contains("sink latency histogram (125 sinks)"), "histogram");
    assert!(log.contains("Wrote clock tree data 'out/clock_tree.json'"));
    let h = std::fs::read_to_string("examples/out/clock_tree.json").unwrap();
    assert!(h.contains("\"clocks\":[{\"name\":\"clk\""));
}

#[test]
fn cts_balances_icg_gated_clock_trees() {
    let script = "examples/out_cts_icg.tcl";
    let base = std::fs::read_to_string("examples/flow.tcl").unwrap();
    let v: String = base.lines().filter(|l| l.starts_with("verify_equivalence")).collect::<Vec<_>>().join("\n");
    let body: String = base.lines().filter(|l| !l.starts_with("verify_equivalence")).collect::<Vec<_>>().join("\n");
    std::fs::write(script, format!("{}\nclock_opt\n{}\nroute_auto\nroute_opt -iterations 1\n{}\nreport_clock_qor -type structure\nreport_clock_qor -type level\n", body, v, v)).unwrap();
    let log = run("examples", "out_cts_icg.tcl");
    let _ = std::fs::remove_file(script);
    assert!(log.contains("7 tree(s)"), "ICG trees not built");
    let l = log.lines().find(|l| l.contains("build_clock:") && l.contains("global skew")).expect("CTS summary");
    let skew: f64 = l.split("global skew ").nth(1).unwrap().split("ns").next().unwrap().parse().unwrap();
    assert!(skew < 0.15, "skew not balanced: {}", l);
    // the tree model sees the ICGs, the UPF level shifter and multiple levels
    assert!(log.contains("[level_shifter]") && log.contains("[icg]"), "clock tree structure misses LS/ICG");
    assert!(log.contains("Report : clock_qor -type level"), "level report");
    assert_eq!(log.matches("Verification SUCCEEDED: 41 outputs").count(), 2, "equivalence lost in PnR");
    assert!(!log.contains("Verification FAILED"));
}

#[test]
fn timing_path_collections_are_exact() {
    let log = run("examples", "timing_paths.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    let wns: f64 = log.lines().filter(|l| l.contains("Design WNS")).last().unwrap().split_whitespace().nth(2).unwrap().parse().unwrap();
    let worst: f64 = log.lines().find(|l| l.starts_with("WORST ")).unwrap().split_whitespace().nth(1).unwrap().parse().unwrap();
    assert!((wns - worst).abs() < 1e-4, "worst path {} != WNS {}", worst, wns);
    // increments + launch edge + launch latency = arrival
    let l = log.lines().find(|l| l.starts_with("SUMINCR")).unwrap();
    let v: Vec<f64> = l.split_whitespace().filter_map(|w| w.parse().ok()).collect();
    assert!((v[0] + v[2] + v[3] - v[1]).abs() < 1e-5, "{}", l);
    assert!(log.contains("N 40") && log.contains("SORTED 1"));
    assert_eq!(log.matches("  EPW ").count(), 5, "-nworst per endpoint");
    assert!(log.contains("ALL_THROUGH 1") && log.contains("EXCLUDED 1"));
    assert!(log.contains("  HOLD ") && log.contains(" min crpr "));
    assert!(log.contains("GROUP clk CLK clk -> clk"));
}

#[test]
fn collection_driven_timing_eco_replays_exactly() {
    let log = run("examples", "timing_eco.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    assert!(log.contains("ECO pass 1:") && log.contains("hold pad at"));
    let q = |l: &str| l.lines().filter(|x| x.contains("Design WNS")).last().unwrap().to_string();
    let first = log.lines().find(|x| x.contains("Design WNS")).unwrap().to_string();
    let after = q(&log);
    let w = |s: &str| -> f64 { s.split_whitespace().nth(2).unwrap().parse().unwrap() };
    assert!(w(&after) > w(&first) + 0.1, "ECO did not improve WNS: {} -> {}", first, after);
    assert!(log.contains("Verification SUCCEEDED: 41 outputs"));
    assert!(log.contains("# fix_eco_timing") || std::fs::read_to_string("examples/out/timing_eco.tcl").unwrap().contains("# fix_eco_timing"));
    let rep = run("examples", "timing_eco_replay.tcl");
    assert!(!rep.contains("Error: "), "{}", &rep[rep.len().saturating_sub(3000)..]);
    assert_eq!(q(&rep), after, "replayed ECO must reproduce the QoR");
    let cells = |s: &str| s.lines().filter(|x| x.contains("Cell count")).last().unwrap().to_string();
    assert_eq!(cells(&rep), cells(&log));
    assert!(rep.contains("Verification SUCCEEDED: 41 outputs"));
}

#[test]
fn innovus_tempus_style_eco_automation() {
    // the user's Tempus/Innovus script verbatim, plus Tcl regexp/regsub checks
    let script = "examples/out_verbatim_eco.tcl";
    std::fs::write(script, r#"source fp_flow_setup.tcl
set collection [report_timing -collection]
set timing_points [get_property $collection timing_point]
set instNameList {}
foreach_in_collection timing_point $timing_points {
  set pin_name [get_property [get_property $timing_point pin] hierarchical_name]
  set inst_name [file dirname $pin_name]
  if {[lsearch $instNameList $inst_name] == -1} {
      lappend instNameList $inst_name
  }
}
foreach instName $instNameList {
  set inst [dbGetInstByName $instName]
  set cellName [dbGet $inst.cell.name]
  if {[string match *X1 $cellName]} {
    regsub {X1$} $cellName {X2} newCellName
    ecoChangeCell -inst $instName -cell $newCellName
  }
}
puts "VERBATIM [llength $instNameList] [dbGet [dbGetInstByName [lindex $instNameList 1]].cell.name]"
regsub -all {_X(\d)_} "AND2_X1_SVT OR2_X1_LVT" {_X2_} r1
puts "RS1 $r1"
puts "RS2 [regsub {(\w+)_X1_(\w+)} AND2_X1_SVT {\2:\1}]"
puts "RX [regexp {_X(\d)_([HSL])VT} NAND2_X4_LVT all d v] $all $d $v"
puts "DIR [file dirname din0] [file dirname a/b/c]"
puts "LS [lsearch -exact {a* b} a*] [lsearch -all -inline {x1 y2 x3} x*]"
"#).unwrap();
    let log = run("examples", "out_verbatim_eco.tcl");
    let _ = std::fs::remove_file(script);
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    let l = log.lines().find(|l| l.starts_with("VERBATIM ")).expect("verbatim script ran");
    assert!(l.split_whitespace().nth(1).unwrap().parse::<usize>().unwrap() > 5 && l.contains("_X"), "{}", l);
    assert!(log.contains("RS1 AND2_X2_SVT OR2_X2_LVT"));
    assert!(log.contains("RS2 SVT:AND2"));
    assert!(log.contains("RX 1 _X4_LVT 4 L"));
    assert!(log.contains("DIR . a/b"));
    assert!(log.contains("LS 0 x1 x3"));

    let log = run("examples", "innovus_eco.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    for k in ["pass 1:", "clock clk, view func_ss", "design soc_top:", "distinct X1 SVT masters:", "stage1_reg[0] instances: 4", "highest fanout net on worst path"] {
        assert!(log.contains(k), "missing: {}", k);
    }
    let wns = |s: &str, last: bool| -> f64 {
        let mut it = s.lines().filter(|x| x.contains("Design WNS"));
        let l = if last { it.last() } else { it.next() };
        l.unwrap().split_whitespace().nth(2).unwrap().parse().unwrap()
    };
    assert!(wns(&log, true) > wns(&log, false) + 0.05, "ECO did not improve WNS");
    let f = std::fs::read_to_string("examples/out/innovus_eco.tcl").unwrap();
    assert!(f.contains("# ecoChangeCell -inst") && f.contains("# ecoAddRepeater") && f.contains("set_dont_touch"));
    let rep = run("examples", "innovus_eco_replay.tcl");
    assert!(!rep.contains("Error: "));
    assert_eq!(wns(&rep, true), wns(&log, true), "replay must reproduce QoR");
    assert!(rep.contains("Verification SUCCEEDED: 41 outputs") && log.contains("Verification SUCCEEDED: 41 outputs"));
}

#[test]
fn pin_timing_properties_match_paths() {
    let log = run("examples", "pin_properties.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    let l = log.lines().find(|l| l.starts_with("EP ")).unwrap();
    let v: Vec<&str> = l.split_whitespace().collect();
    assert_eq!(v[3], v[5], "endpoint pin slack_max == worst path slack: {}", l);
    assert!(log.contains("BAD 0") && log.contains("HOLDPATH BAD 0"), "pin slack/slew/load vs path points");
    let h = log.lines().find(|l| l.starts_with("HOLD ")).unwrap();
    let hv: Vec<&str> = h.split_whitespace().collect();
    assert_eq!(hv[3], hv[5], "hold pin slack_min == worst hold path: {}", h);
    let a = log.lines().find(|l| l.starts_with("ALLPINS")).unwrap();
    let n: Vec<&str> = a.split_whitespace().collect();
    assert!(n[1] == n[3] && n[3] == n[4] && n[4] == n[5] && n[5] == n[6], "one value per pin: {}", a);
    let e = log.lines().find(|l| l.starts_with("ECO ")).unwrap();
    let ev: Vec<&str> = e.split_whitespace().collect();
    assert_ne!(ev[3], ev[5], "cache must refresh after size_cell: {}", e);
    assert!(!log.contains("DB 0x0"));
}

#[test]
fn hierarchical_pins_and_net_leafpins() {
    let log = run("examples/hier", "hier_pin_props.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    assert!(log.contains("HPINS 34: {u_alu/a[0]}"), "hierarchical pins by inst/port name");
    assert!(log.contains("HPIN {u_alu/a[0]} dir in hier true net {a[0]} loc '' layer ''"));
    let l = log.lines().find(|l| l.starts_with("LEAF_OF_HIER_NET")).unwrap();
    assert!(l.contains("u_p0/") && l.contains("u_p1/") && l.contains("u_alu/U8/A2") && !l.contains("__hp_"), "leafpins cross the hierarchy: {}", l);
    assert!(log.contains("HIER_Y {u_alu/y[3]} dir out leaf_drv u_alu/"));
    assert!(log.contains("LEAFPIN false M1"));
}

#[test]
fn pin_locations_are_on_the_routed_wires() {
    let log = run("examples", "pin_location.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    let def = std::fs::read_to_string("examples/out/pin_location.def").unwrap();
    let dbu: f64 = def.split("UNITS DISTANCE MICRONS ").nth(1).unwrap().split_whitespace().next().unwrap().parse().unwrap();
    let nets = &def[def.find("\nNETS").unwrap()..def.find("END NETS").unwrap()];
    // net -> set of (layer, x, y) wired points (segment points and via landings)
    let mut wired: std::collections::HashMap<String, std::collections::HashSet<(String, i64, i64)>> = Default::default();
    for blk in nets.split(';') {
        let toks: Vec<&str> = blk.split_whitespace().collect();
        let Some(i) = toks.iter().position(|t| *t == "-") else { continue };
        let name = toks[i + 1].replace('\\', "");
        let set = wired.entry(name).or_default();
        let (mut lay, mut prev) = (String::new(), (0i64, 0i64));
        let mut k = i + 2;
        while k < toks.len() {
            match toks[k] {
                "ROUTED" | "NEW" => {
                    lay = toks[k + 1].to_string();
                    k += 2;
                }
                "(" => {
                    let x = if toks[k + 1] == "*" { prev.0 } else { toks[k + 1].parse().unwrap_or(prev.0) };
                    let y = if toks[k + 2] == "*" { prev.1 } else { toks[k + 2].parse().unwrap_or(prev.1) };
                    prev = (x, y);
                    set.insert((lay.clone(), x, y));
                    k += 3;
                }
                t if t.starts_with("VIA") && t.len() >= 5 => {
                    set.insert((format!("M{}", &t[3..4]), prev.0, prev.1));
                    set.insert((format!("M{}", &t[4..5]), prev.0, prev.1));
                    k += 1;
                }
                _ => k += 1,
            }
        }
    }
    let (mut ok, mut bad) = (0, 0);
    for l in log.lines().filter(|l| l.starts_with("PIN ")) {
        let f: Vec<&str> = l.split_whitespace().collect();
        let (x, y): (f64, f64) = (f[3].parse().unwrap(), f[4].parse().unwrap());
        let key = (f[5].to_string(), (x * dbu).round() as i64, (y * dbu).round() as i64);
        if wired.get(f[1]).map(|s| s.contains(&key)).unwrap_or(false) {
            ok += 1;
        } else {
            bad += 1;
        }
    }
    assert!(ok > 500 && bad == 0, "pin locations on routed wires: {} ok, {} off", ok, bad);
    assert!(log.contains("layer M3") && log.contains("layer M1"));
}

fn marker<'a>(log: &'a str, key: &str) -> &'a str {
    log.lines().find(|l| l.starts_with(key)).unwrap_or_else(|| panic!("marker {} missing:\n{}", key, &log[log.len().saturating_sub(3000)..]))
}
fn num_after(l: &str, key: &str) -> f64 {
    l.split(key).nth(1).and_then(|r| r.split_whitespace().next()).and_then(|v| v.parse().ok()).unwrap_or_else(|| panic!("no number after '{}' in '{}'", key, l))
}

#[test]
fn io_pins_layer_assignment_check_and_def_sections() {
    let log = run("examples", "io_pins.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    let viol = &log[log.find("=== IO VIOL").unwrap()..];
    let count = |cat: &str| -> usize { viol.lines().find(|l| l.trim_start().starts_with(&format!("{} ", cat))).and_then(|l| l.split_whitespace().nth(1)).and_then(|v| v.parse().ok()).unwrap_or(99) };
    assert_eq!(count("direction"), 1, "vertical layer on the left side must be flagged");
    assert_eq!(count("off_track"), 1, "off-track location must be flagged");
    assert_eq!(count("short"), 0);
    assert!(viol.contains("Total: 2 violation(s)"));
    assert!(log.contains("DEF-010"), "unknown DEF section not rejected");
    let pins = std::fs::read_to_string("examples/out/batch_pins.def").unwrap();
    assert!(pins.contains("TRACKS") && pins.contains("\nPINS") && !pins.contains("COMPONENTS") && !pins.contains("\nNETS"));
    let net = std::fs::read_to_string("examples/out/batch_netlist.def").unwrap();
    assert!(net.contains("COMPONENTS") && net.contains("\nNETS") && !net.contains("TRACKS"));
    let fp = std::fs::read_to_string("examples/out/batch_fp.def").unwrap();
    assert!(fp.contains("ROWS") || fp.contains("ROW "), "floorplan DEF without rows");
    // balanced layer assignment uses both allowed layers of a side
    let bal = &log[log.find("=== IO BALANCED").unwrap()..log.find("=== IO VIOL").unwrap()];
    assert!(bal.contains("M3") && bal.contains("M5"), "balanced assignment did not use both layers");
}

#[test]
fn dont_touch_dont_use_user_properties() {
    let log = run("examples", "dont_props.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    assert!(log.contains("NET_DT true") && log.contains("LC_DU true") && log.contains("CELL_DU true -> true"));
    assert!(log.contains("ATTR-006"), "bad boolean not rejected");
    let a = marker(&log, "AFTER:");
    assert!(a.contains("net pins 6 (was 6)") && a.contains("cell XOR2_X1_SVT") && a.contains("XOR2_X2_LVT_used 0"), "{}", a);
    assert!(log.contains("LC_DU_OFF false"));
}

#[test]
fn multi_corner_spef_annotations_derates_and_analysis_types() {
    let log = run("examples", "parasitics_derates.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    let ex = marker(&log, "EXTRACTED");
    let sp = marker(&log, "SPEF wns");
    let (w0, w1) = (num_after(ex, "wns"), num_after(sp, "wns"));
    assert!((w0 - w1).abs() < 0.003, "SPEF annotation changed WNS {} -> {}", w0, w1);
    assert!(log.contains("1052 annotated") || log.contains("100.0%"), "SPEF not fully annotated");
    assert!(marker(&log, "ANN incr").contains("ANN incr 0.5 "), "annotated cell delay not exact");
    let before = num_after(marker(&log, "ARC"), "incr_before");
    let der = num_after(marker(&log, "DERATED"), "incr");
    assert!((der - 1.5 * before).abs() < 1e-3, "object derate {} vs 1.5x {}", der, before);
    let rem = num_after(marker(&log, "ANN_REMOVED"), "ANN_REMOVED");
    assert!((num_after(marker(&log, "ADJUST"), "ADJUST") - (rem - 0.1)).abs() < 1e-6, "path_adjust not 0.1");
    assert!((num_after(marker(&log, "SINGLE"), "SINGLE") - rem).abs() < 1e-9, "single_corner must ignore derates");
    assert!(num_after(marker(&log, "OCV"), "OCV") < rem, "1.1 late derate must reduce slack");
    assert!(log.contains("max_transition") && log.contains("max_fanout") && log.contains("CMD-010"));
}

#[test]
fn report_timing_format_columns() {
    let log = run("examples", "timing_format.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    assert!(log.contains("Instance") && log.contains("Location") && log.contains("Fanout"));
    assert!(log.lines().any(|l| l.contains("Point") && l.contains("Required") && l.contains("Slack")));
    assert!(log.contains("unknown column 'bogus'"));
    // report_timing_format -transition -capacitance -fanout
    assert!(log.contains("report_timing columns: point cell trans cap fanout incr path edge"), "{}", log);
    let tcf = log.split("=== TCF\n").nth(1).unwrap().split("=== TCF2").next().unwrap();
    let hdr = tcf.lines().find(|l| l.contains("Point") && l.contains("Incr")).expect("header");
    assert!(hdr.contains("Fanout") && hdr.contains("Cap") && hdr.contains("Trans"), "{}", hdr);
    // output pins carry fanout + load capacitance, input pins only the transition
    let rows: Vec<&str> = tcf.lines().filter(|l| l.contains("/Y (") || l.contains("/Q (")).collect();
    assert!(!rows.is_empty() && rows.iter().all(|l| l.split_whitespace().count() >= 6), "{}", tcf);
    let tcf2 = log.split("=== TCF2").nth(1).unwrap();
    let hdr2 = tcf2.lines().find(|l| l.contains("Point") && l.contains("Incr")).expect("header");
    assert!(!hdr2.contains("Fanout") && hdr2.contains("Cap") && hdr2.contains("Trans"), "{}", hdr2);
}

#[test]
fn change_names_rules_keep_equivalence_and_reimport() {
    let _g = FLOW_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let log = run("examples", "change_names.tcl");
    assert_eq!(log.matches("Verification SUCCEEDED: 41 outputs").count(), 3, "{}", &log[log.len().saturating_sub(4000)..]);
    assert!(marker(&log, "ALIAS").contains("u_core/g_lane_0__u_lane/m_valid_reg"), "old names must resolve after renaming");
    // (soc_top.names_flat.v is a flat dump of the kept hierarchy: its names carry '/' and stay escaped)
    for f in ["examples/out/soc_top.names.v", "examples/out/soc_top.flat_names.v"] {
        let v = std::fs::read_to_string(f).unwrap();
        assert!(!v.contains('\\'), "escaped identifier left in {}", f);
    }
    let log = run("examples", "change_names_reimport.tcl");
    assert!(log.contains("LINK-200") && log.contains("Verification SUCCEEDED: 41 outputs"), "{}", &log[log.len().saturating_sub(3000)..]);
    let log = run("examples/names", "angle.tcl");
    let cells = marker(&log, "CELLS");
    assert!(cells.contains("gen_1__u_sub!U9") && cells.contains("u_blk_0_!U1"), "{}", cells);
    assert!(!marker(&log, "NETS").contains('<'), "angle brackets not converted");
}

#[test]
fn synopsys_pragmas_in_rtl() {
    let log = run("examples/pragmas", "prag.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    assert!(log.contains("DC_TCL_RAN ports=16"), "embedded dc_tcl script not executed");
    assert!(log.contains("LATCHES 0") && log.contains("KEEP true"));
    assert!(log.contains("Verification SUCCEEDED: 5 outputs"));
    assert!(log.contains("PV_CELLS 1"), "VHDL translate_off region not skipped");
}

#[test]
fn timing_models_etm_ilm_qtm_ndm_stub_lib() {
    let log = run("examples", "models.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    assert!(log.contains("interface timing matches"), "ILM interface timing differs");
    assert!(log.contains("NDM-100") && log.contains("QTM-200") && log.contains("LIB-300"));
    for (lib, arcs) in [("soc_top_ss_etm", "NLDM arcs=103"), ("blk_qtm_lib", "NLDM arcs=7"), ("pll_ip_lib", "NLDM arcs=40")] {
        assert!(log.lines().any(|l| l.contains("LIB-001") && l.contains(lib) && l.contains(arcs)), "{} not read back", lib);
    }
    for f in ["manifest.txt", "soc_top.lef", "soc_top.lib", "soc_top_ilm.v"] {
        assert!(std::path::Path::new(&format!("examples/out/models/soc_top.ndm/{}", f)).exists(), "{} missing", f);
    }
    // ETM setup time of din1[3] is consistent with the full-design slack: T - slack - input delay
    let etm = std::fs::read_to_string("examples/out/models/soc_top_etm.lib").unwrap();
    assert!(etm.contains("timing_type : setup_rising") && etm.contains("timing_type : rising_edge") && etm.contains("timing_model_type : \"extracted\""));
}

#[test]
fn signoff_spef_dspf_sdf_and_merged_gds() {
    let log = run("examples", "signoff_export.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    let base = marker(&log, "BASE");
    let (s0, h0) = (num_after(base, "setup"), num_after(base, "hold"));
    let sp = num_after(marker(&log, "SPEF_RT"), "setup");
    assert!((sp - s0).abs() < 0.002, "SPEF round trip {} vs {}", sp, s0);
    let sd = marker(&log, "SDF_RT");
    assert!((num_after(sd, "setup") - s0).abs() < 0.002, "SDF setup round trip: {}", sd);
    assert!((num_after(sd, "hold") - h0).abs() < 0.0005, "SDF hold round trip: {}", sd);
    let spef = std::fs::read_to_string("examples/out/xo/top.ss.spef").unwrap();
    assert!(spef.contains("*DESIGN_FLOW \"DETAILED_ROUTE\"") && spef.contains("*NAME_MAP") && spef.contains("*PORTS"));
    let ps = std::fs::read_to_string("examples/out/xo/top_ps_ff.spef").unwrap();
    assert!(ps.contains("*C_UNIT 1 FF") && ps.contains("*R_UNIT 1 OHM") && ps.contains(" *C ") && !ps.contains("*NAME_MAP"));
    let dspf = std::fs::read_to_string("examples/out/xo/top.ff.dspf").unwrap();
    assert!(dspf.starts_with("*|DSPF") && dspf.contains(".SUBCKT soc_top") && dspf.contains("*|I (") && dspf.contains("* Instance Section") && dspf.trim_end().ends_with(".ENDS"));
    let mtm = std::fs::read_to_string("examples/out/xo/top_mtm.sdf").unwrap();
    assert!(mtm.contains("(SETUPHOLD (posedge D) (posedge CK)") && mtm.contains("(RECREM") && mtm.contains("(IOPATH (posedge CK) Q"));
    let mn = std::fs::read_to_string("examples/out/xo/top_min.sdf").unwrap();
    assert!(!mn.contains("::"), "single-value min SDF must not contain triplets");
    let v21 = std::fs::read_to_string("examples/out/xo/top_v21.ss.sdf").unwrap();
    assert!(v21.contains("(SDFVERSION \"2.1\")") && v21.contains("(TIMESCALE 1ps)"));
    let tc = &v21[v21.find("(TIMINGCHECK").unwrap()..];
    assert!(!tc.contains("(-"), "-no_negative_values timing_checks");
    // GDS: merged std cells + SRAM (rescaled from 2000 dbu) + PLL; duplicate detected; pruned has one top
    assert!(log.contains("GDS-105") && log.contains("GDS-120") && log.contains("GDS-110"));
    let pr = &log[log.find("GDS file      : out/gds/soc_top_pruned.gds").unwrap()..];
    assert!(pr.contains("top cell(s)   : 1  (SOC_TOP)") && pr.contains("unresolved    : 1  (spare_cells)"));
    let g = std::fs::read("examples/out/gds/soc_top.gds").unwrap();
    assert_eq!(&g[0..6], &[0, 6, 0, 2, 2, 0x58], "GDSII HEADER record (version 600)");
}

#[test]
fn hierarchical_block_implementation_and_abstract_timing() {
    let log = run("examples", "hier_impl_flow.tcl");
    let tail = || log[log.len().saturating_sub(4000)..].to_string();
    assert!(log.contains("Implemented 4 block(s), 0 failed"), "{}", tail());
    for b in ["lane0", "lane1", "u_core_u_csum", "u_core_u_arb"] {
        for f in [format!("{}.v", b), format!("{}.def", b), format!("{}.lef", b), format!("{}.ss.spef", b), format!("{}.ff.spef", b), format!("{}_func_ss.lib", b)] {
            assert!(std::path::Path::new(&format!("examples/out/impl/{}", f)).exists(), "{} missing", f);
        }
        let row = log.lines().find(|l| l.trim_start().starts_with(&format!("{} ", b)) && l.contains(" ok")).unwrap_or_else(|| panic!("block {} not ok:\n{}", b, tail()));
        assert!(row.contains(" 0 "), "{}", row);
    }
    let etm = std::fs::read_to_string("examples/out/impl/lane0_func_ss.lib").unwrap();
    assert!(etm.contains("cell (lane0)") && etm.contains("(max delays)"));
    // the abstract (ETM) top-level timing matches flat timing of the assembled blocks
    let ver = &log[log.find("=== HIER VERIFY").unwrap()..log.find("=== HIER NEGATIVE").unwrap()];
    assert!(ver.contains("HIER-200"), "{}", ver);
    let mut rows = 0;
    for l in ver.lines().filter(|l| l.trim_start().starts_with("func_") && (l.contains(" block inputs ") || l.contains(" top endpoints "))) {
        let t: Vec<&str> = l.split_whitespace().collect();
        let maxd: f64 = t[t.len() - 4].parse().unwrap();
        let lim = if t[1] == "setup" { 0.015 } else { 0.010 };
        assert!(maxd <= lim, "abstract vs flat beyond tolerance: {}", l);
        rows += 1;
    }
    assert_eq!(rows, 4, "setup (func_ss) and hold (func_ff) for block inputs and top endpoints:\n{}", ver);
    // a wrong model (setup delays used for hold) is caught
    let neg = &log[log.find("=== HIER NEGATIVE").unwrap()..];
    assert!(neg.contains("HIER-210"), "{}", neg);
}

/// SREF placements of one structure in a GDSII file: (x, y, reflected, angle)
fn gds_srefs(path: &str, sname: &str) -> Vec<(i32, i32, bool, f64)> {
    let b = std::fs::read(path).unwrap();
    let (mut i, mut out) = (0usize, vec![]);
    let (mut in_sref, mut name, mut refl, mut ang, mut xy) = (false, String::new(), false, 0.0f64, (0i32, 0i32));
    while i + 4 <= b.len() {
        let len = u16::from_be_bytes([b[i], b[i + 1]]) as usize;
        if len < 4 {
            break;
        }
        let (rt, d) = (b[i + 2], &b[i + 4..i + len]);
        match rt {
            0x0A => {
                in_sref = true;
                name.clear();
                refl = false;
                ang = 0.0;
            }
            0x12 if in_sref => name = String::from_utf8_lossy(d).trim_end_matches('\0').to_string(),
            0x1A if in_sref => refl = d[0] & 0x80 != 0,
            0x1C if in_sref => {
                let e = (d[0] & 0x7f) as i32 - 64;
                let mut m: u64 = 0;
                for &x in &d[1..8] {
                    m = (m << 8) | x as u64;
                }
                ang = m as f64 / (1u64 << 56) as f64 * 16f64.powi(e);
            }
            0x10 if in_sref => xy = (i32::from_be_bytes([d[0], d[1], d[2], d[3]]), i32::from_be_bytes([d[4], d[5], d[6], d[7]])),
            0x11 if in_sref => {
                if name == sname {
                    out.push((xy.0, xy.1, refl, ang));
                }
                in_sref = false;
            }
            _ => {}
        }
        i += len;
    }
    out
}

#[test]
fn mim_multiply_instantiated_cores() {
    let log = run("examples/mim", "mim_flow.tcl");
    let tail = || log[log.len().saturating_sub(5000)..].to_string();
    assert!(!log.contains("Error: "), "{}", tail());
    assert!(log.contains("MIM-100") && log.contains("4 instances, master g_cpu[0].u_core"), "{}", tail());
    let sect = |a: &str, b: &str| -> String { log[log.find(a).unwrap()..log.find(b).unwrap()].to_string() };
    // context-specific optimization made the copies differ before the commit
    let before = sect("=== MIM BEFORE COMMIT", "=== MIM COMMIT");
    assert_eq!(before.matches("differs (").count(), 3, "{}", before);
    assert_eq!(before.matches("equal(13)").count(), 3, "{}", before);
    let after = sect("=== MIM AFTER COMMIT", "=== MIM ECO");
    assert_eq!(after.matches(" identical ").count(), 3, "{}", after);
    assert!(after.contains("Placement is legal"));
    assert_eq!(log.matches("Verification SUCCEEDED: 27 outputs").count(), 2, "equivalence after commit and after the forced re-commit");
    // copies are mapped into their regions with the orientation (exactly, cell by cell)
    let def = std::fs::read_to_string("examples/mim/out/mim_flat.def").unwrap();
    let mut loc: std::collections::HashMap<String, (f64, f64)> = Default::default();
    for l in def.lines().filter(|l| l.contains(" + PLACED ( ") || l.contains(" + FIXED ( ")) {
        let t: Vec<&str> = l.split_whitespace().collect();
        let k = t.iter().position(|x| *x == "(").unwrap();
        loc.insert(t[1].replace('\\', ""), (t[k + 1].parse::<f64>().unwrap() / 1000.0, t[k + 2].parse::<f64>().unwrap() / 1000.0));
    }
    let (w, h) = (50.0, 48.0);
    for (k, o, ox, oy) in [(1, "FN", 75.0, 4.8), (2, "FS", 5.0, 67.2), (3, "S", 75.0, 67.2)] {
        let mut n = 0;
        for (name, (x, y)) in &loc {
            let Some(rel) = name.strip_prefix("g_cpu[0].u_core/") else { continue };
            let (u, v) = (x - 5.0, y - 4.8);
            let (a, b) = match o {
                "FN" => (w - u, v),
                "FS" => (u, h - v),
                _ => (w - u, h - v),
            };
            let c = loc.get(&format!("g_cpu[{}].u_core/{}", k, rel)).unwrap_or_else(|| panic!("copy of {} missing", rel));
            assert!((c.0 - ox - a).abs() < 1e-6 && (c.1 - oy - b).abs() < 1e-6, "{} {}: {:?} vs expected ({}, {})", o, rel, c, ox + a, oy + b);
            n += 1;
        }
        assert!(n > 400, "{} cells compared", n);
    }
    // an ECO on the master reaches every instance; a functional change in one copy is refused
    assert!(log.contains("ECO_REF BUF_X4_SVT BUF_X4_SVT"), "{}", tail());
    let eco = sect("=== MIM ECO", "=== MIM BUDGET");
    assert!(eco.contains("DIFFERENT") && eco.contains("REFUSED 1") && eco.contains("MIM-023") && eco.contains("MIM-120"));
    // one block, worst-case budgets over the four contexts, implemented once
    assert!(log.contains("MIM-300") && log.contains("merged worst-case budgets of 4 instances"));
    assert!(log.contains("one block for 4 instances"));
    assert!(log.contains("Implemented 1 block(s), 0 failed"), "{}", tail());
    let ver = sect("=== MIM VERIFY", "=== MIM GDS");
    assert!(ver.contains("HIER-200"), "{}", ver);
    for i in 0..4 {
        assert!(ver.contains(&format!("    g_cpu[{}].u_core ", i)), "per-instance context row {}", i);
    }
    for l in ver.lines().filter(|l| l.trim_start().starts_with("func_") && (l.contains(" block inputs ") || l.contains(" top endpoints "))) {
        let t: Vec<&str> = l.split_whitespace().collect();
        assert!(t[t.len() - 4].parse::<f64>().unwrap() <= 0.005, "abstract vs flat: {}", l);
    }
    // GDS: one cpu_blk structure referenced four times with the instance orientations
    let gds = sect("=== MIM GDS", "Diagnostics summary");
    assert!(gds.contains("top cell(s)   : 1  (mc_top)") && gds.contains("unresolved    : 0"), "{}", gds);
    let mut refs = gds_srefs("examples/mim/out/mim_impl/mc_top.gds", "cpu_blk");
    refs.sort_by_key(|r| (r.1, r.0));
    assert_eq!(refs, vec![(5000, 4800, false, 0.0), (125000, 4800, true, 180.0), (5000, 115200, true, 0.0), (125000, 115200, false, 180.0)]);
    // the assembled design (four instances of the one implemented netlist) matches the RTL
    let log = run("examples/mim", "mim_assemble.tcl");
    assert!(log.contains("cpu_blk#()' instantiated 4 times") && log.contains("Verification SUCCEEDED: 27 outputs"), "{}", &log[log.len().saturating_sub(3000)..]);
    // preconditions
    let log = run("examples/mim", "mim_negative.tcl");
    assert!(log.contains("R2 1") && log.contains("MIM-008"));
    assert!(log.contains("R3 1") && log.contains("MIM-006"));
    assert!(log.contains("R4 1") && log.contains("MIM-004"));
    assert!(log.contains("R6 1"));
    let log = run("examples/mim", "mim_negative_nobound.tcl");
    assert!(log.contains("R1 1") && log.contains("MIM-002"));
    let log = run("examples", "mim_negative_lanes.tcl");
    assert!(log.contains("R5 1") && log.contains("MIM-001"), "{}", &log[log.len().saturating_sub(2000)..]);
}

#[test]
fn multicycle_start_end_and_false_path_setup_hold() {
    // ca (1 ns) launches, cb (3 ns) captures: default setup relation 1 ns
    let get = |case: &str, key: &str| -> f64 {
        let log = run("examples/sdc_mcp", &format!("case_{}.tcl", case));
        let l = log.lines().find(|l| l.starts_with(&format!("{} {}", case, key))).unwrap_or_else(|| panic!("{} {}:\n{}", case, key, log));
        l.split_whitespace().nth(2).and_then(|v| v.parse().ok()).unwrap_or(f64::NAN)
    };
    let (end, start) = (get("end", "setup_req"), get("start", "setup_req"));
    assert!((end - start - 2.0).abs() < 1e-6, "-end moves the capture edge by a cb period (3), -start the launch edge by a ca period (1): {} {}", end, start);
    // a hold multicycle counts launch-clock cycles by default (-start), capture cycles with -end
    let (hs, hd, he) = (get("holdstart", "hold_req"), get("holddefault", "hold_req"), get("holdend", "hold_req"));
    assert!((hs - hd).abs() < 1e-9, "hold MCP default must be -start: {} vs {}", hd, hs);
    assert!((hs - he - 2.0).abs() < 1e-6, "-hold -end moves by a cb period: {} {}", hs, he);
    assert!(get("fp", "setup_req").is_nan() && get("fp", "hold_req").is_nan(), "false path removes setup and hold");
    assert!(get("fpsetup", "setup_req").is_nan() && get("fpsetup", "hold_req").is_finite(), "-setup false path keeps the hold check");
    let log = run("examples/sdc_mcp", "case_fpstart.tcl");
    assert!(log.contains("SDC-041"), "-start on set_false_path is warned");
}

#[test]
fn optimization_controls_in_place_clock_route_opt() {
    let log = run("examples", "opt_controls.tcl");
    let tail = || log[log.len().saturating_sub(4000)..].to_string();
    assert!(!log.contains("Error: "), "{}", tail());
    assert!(log.contains("E1 1") && log.contains("OPT-930"), "place_opt -incremental needs a placement");
    assert!(log.contains("E5 1") && log.contains("OPT-932"), "route_opt -incremental needs routes");
    assert!(log.contains("E4 1") && log.contains("OPT-933"), "clock_opt -incremental needs clock trees");
    assert!(log.contains("E2 1") && log.contains("OPT-901"), "unknown endpoint names are rejected");
    assert!(log.contains("E3 1") && log.contains("OPT-905"), "bad -effort is rejected");
    // every endpoint-limited run: only cells on the focus cones change, other endpoints not worse
    assert_eq!(log.matches("OPT-911").count(), 4, "{}", tail());
    assert!(!log.contains("OPT-910"));
    let blocks: Vec<&str> = log.split("-endpoints out/").skip(1).collect();
    assert_eq!(blocks.len(), 4);
    let row = |b: &str, k: &str| -> (f64, f64) {
        let l = b.lines().find(|l| l.trim_start().starts_with(k)).unwrap();
        let t: Vec<f64> = l.split_whitespace().rev().take(2).map(|v| v.parse().unwrap()).collect();
        (t[1], t[0])
    };
    for b in &blocks {
        let (o0, o1) = row(b, "other endpoints WNS");
        assert!(o1 >= o0 - 1e-6 || o1 >= 0.0, "other WNS got worse: {} -> {}", o0, o1);
        let (t0, t1) = row(b, "other endpoints TNS");
        assert!(t1 >= t0 - 1e-6, "other TNS got worse: {} -> {}", t0, t1);
        let (h0, h1) = row(b, "other endpoints WHS");
        assert!(h1 >= h0 - 1e-6 || h1 >= 0.0, "other WHS got worse: {} -> {}", h0, h1);
        assert!(b.contains("outside the focus cones 0"));
    }
    // place_opt -setup -endpoints improves the focus setup; clock_opt -hold -endpoints fixes the focus hold
    let (f0, f1) = row(blocks[0], "focus WNS");
    assert!(f1 > f0 + 1e-4, "focus WNS {} -> {}", f0, f1);
    let (h0, h1) = row(blocks[2], "focus WHS");
    assert!(h0 < 0.0 && h1 >= 0.0, "focus hold {} -> {}", h0, h1);
    // -drv alone: DRV count drops, no setup / hold step runs
    let drv = &log[log.find("=== PLACE_OPT DRV").unwrap()..log.find("=== CLOCK_OPT").unwrap()];
    let l = drv.lines().find(|l| l.contains("place_opt controls:")).unwrap();
    let d: Vec<&str> = l.split("DRV ").nth(1).unwrap().split(" -> ").collect();
    assert!(d[1].trim().parse::<usize>().unwrap() < d[0].trim().parse::<usize>().unwrap(), "{}", l);
    assert!(!drv.contains("OPT-500") && !drv.contains("OPT-600"), "-drv must not run setup or hold fixing");
    assert!(log.contains("Placement is legal") && log.contains("no opens, no shorts"));
    assert!(log.contains("Verification SUCCEEDED: 41 outputs"));
}

#[test]
fn mmmc_configuration_template() {
    let log = run("examples", "mmmc/mmmc_example.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    assert!(log.contains("MMMC: 3 corner(s), 2 mode(s), 5 scenario(s)"));
    for (sc, row) in [("func_ss", "func       ss         true    true   false true"), ("func_ff", "func       ff         true    false  true  false"), ("test_ff", "test       ff         true    false  true")] {
        assert!(log.lines().any(|l| l.starts_with(sc) && l.contains(row)), "scenario {} status", sc);
    }
    assert!(log.contains("ss / 0.72V / 125C") && log.contains("ff / 0.88V / -40C"), "corner PVT (set_voltage on a corner)");
    assert!(log.contains("R1.1 C1.1") && log.contains("1.030/0.970"), "RC scaling and derates per corner");
    assert!(log.contains("Reading SDC 'func.sdc' into mode 'func'") && log.contains("Reading SDC 'test.sdc' into mode 'test'"));
}

#[test]
fn voltage_areas_and_gui_power_domain_highlight() {
    let log = run("examples", "va/va_gui.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(3000)..]);
    assert!(log.contains("Voltage area 'VA_LANES' for PD_LANES") && log.contains("Voltage area 'VA_CSUM' for PD_CSUM"));
    // placement honors the voltage areas: no domain cell outside its VA (or in the guard band), no foreign cell inside
    let rows: Vec<&str> = log.lines().filter(|l| l.starts_with("VA_LANES ") || l.starts_with("VA_CSUM ")).collect();
    assert_eq!(rows.len(), 4, "report_voltage_areas before and after the DEF round trip");
    for r in &rows {
        let f: Vec<&str> = r.split_whitespace().collect();
        let n = f.len();
        assert!(f[n - 5].parse::<usize>().unwrap() > 0, "cells: {}", r);
        assert_eq!(f[n - 4], f[n - 5], "all placed: {}", r);
        assert_eq!((f[n - 3], f[n - 2]), ("0", "0"), "outside / foreign: {}", r);
    }
    assert!(!log.contains("VA-200"));
    assert!(log.contains("Placement is legal"));
    assert!(log.contains("Verification SUCCEEDED"), "equivalence after VA-constrained placement");
    // GUI highlight: two domains highlighted, colouring by domain, snapshot carries the domain data
    assert!(log.contains("Highlight power domain PD_CSUM: 96 cell(s)") || log.contains("Highlight power domain PD_CSUM:"));
    let st = std::fs::read_to_string("examples/va/out/va_floorplan.json").unwrap();
    assert!(st.contains("\"pdhl\":[\"PD_LANES\",\"PD_CSUM\"]") && st.contains("\"colorby\":\"pd\""));
    assert!(st.contains("\"n\":\"PD_LANES\",\"top\":false") && st.contains("\"van\":\"VA_LANES\"") && st.contains("\"sw\":true"));
    // error checks
    let neg = run("examples", "va/va_negative.tcl");
    for (k, code) in [("NOUPF 1", "UPF-001"), ("T1 1", "VA-001"), ("T2 1", "VA-002"), ("T3 1", "VA-005"), ("T5 1", "VA-004"), ("T6 1", "VA-006"), ("T7 1", "GUI-101")] {
        assert!(neg.lines().any(|l| l.starts_with(k) && l.contains(code)), "{} {}\n{}", k, code, neg);
    }
    assert!(neg.contains("T4 0 VA_A") && neg.contains("T9 VA_A") && neg.contains("T10 1 0"));
}

#[test]
fn delay_calculation_engines() {
    let log = run("examples", "dcalc_flow.tcl");
    let tail = || log[log.len().saturating_sub(5000)..].to_string();
    assert!(!log.lines().any(|l| l.starts_with("Error:")), "{}", tail());
    // global-route timing engine built RC trees for the placed design
    assert!(log.contains("Global-route timing engine:") && log.contains("Steiner point(s)"), "{}", tail());
    // the four model checks (GR step, GR ramp, extracted step, extracted ramp): mean |error| %
    let checks: Vec<(f64, f64, f64)> = log.lines().filter(|l| l.contains("(DC-200)")).map(|l| {
        let v: Vec<f64> = l.split(|c: char| c == ',' || c == ' ').filter_map(|t| t.trim_end_matches(',').parse().ok()).collect();
        let n = v.len();
        (v[n - 3], v[n - 2], v[n - 1])
    }).collect();
    assert_eq!(checks.len(), 4, "{}", tail());
    for (i, (e, d, a)) in checks.iter().enumerate() {
        assert!(*a < 3.0, "AWE mean |delay error| {} % (check {})", a, i);
        assert!(a <= d && a <= e, "AWE is the most accurate model (check {}: {} {} {})", i, e, d, a);
    }
    assert!(checks[0].0 > 20.0 && checks[2].0 > 20.0, "Elmore overestimates step delays");
    // extraction: detailed mode finds coupling, fast mode none
    let ext: Vec<&str> = log.lines().filter(|l| l.contains("(DC-120)")).collect();
    assert!(ext.len() == 2 && ext[0].contains("coupling 0.0000 pF") && !ext[1].contains("coupling 0.0000"), "{:?}", ext);
    // Miller factor 2 makes timing worse than Miller 1
    let wns: Vec<f64> = log.lines().filter(|l| l.trim_start().starts_with("Design WNS")).map(|l| l.split_whitespace().nth(2).unwrap().parse().unwrap()).collect();
    let n = wns.len();
    assert!(n >= 7, "{:?}", wns);
    let (det, miller2, spef) = (wns[n - 3], wns[n - 2], wns[n - 1]);
    assert!(miller2 < det - 0.01, "Miller 2 {} vs 1 {}", miller2, det);
    // SPEF with coupling: written, read back as RC trees, timing within 5 ps
    assert!(log.contains("read_parasitics (SPEF): 1052 RC tree(s)"), "{}", tail());
    assert!((spef - det).abs() < 0.005, "SPEF round trip {} vs extracted {}", spef, det);
    let spf = std::fs::read_to_string("examples/out/dcalc.ss.spef").unwrap();
    assert!(spf.lines().filter(|l| l.split_whitespace().count() == 4 && l.contains(':') && l.split_whitespace().nth(2).map(|x| x.contains(':') || x.contains('/')).unwrap_or(false)).count() > 1000);
    // GR vs extraction correlation
    let corr = log.lines().find(|l| l.contains("(DC-300)")).unwrap();
    let r2: f64 = corr.split("R^2 ").nth(1).unwrap().split_whitespace().next().unwrap().parse().unwrap();
    assert!(r2 > 0.7, "{}", corr);
    // single-net report: AWE equals the transient reference, Ceff within 1 % of the Thevenin reference
    for l in log.lines().filter(|l| l.trim_start().starts_with("AWE 2-pole ramp response")) {
        let e: f64 = l.split('%').next().unwrap().split_whitespace().last().unwrap().parse().unwrap();
        assert!(e.abs() < 1.0, "{}", l);
    }
    let th: Vec<&str> = log.lines().filter(|l| l.contains("lumped Ceff")).collect();
    assert_eq!(th.len(), 2);
    for l in th {
        let e: f64 = l.split("lumped Ceff").nth(1).unwrap().split('(').nth(1).unwrap().split('%').next().unwrap().parse().unwrap();
        assert!(e.abs() < 1.0, "{}", l);
    }
    for (k, code) in [("NEG1 1", "DC-001"), ("NEG2 1", "DC-003"), ("NEG3 1", "DC-030")] {
        assert!(log.lines().any(|l| l.starts_with(k) && l.contains(code)), "{} {}", k, code);
    }
}

#[test]
fn chip_floorplan_padring_esd_sealring() {
    let log = run("examples/chipfp", "wirebond_chip.tcl");
    assert!(log.contains("core (130.00,130.00)-(570.00,570.00)"), "core from die + spacing:\n{}", log);
    assert!(log.contains("Seal ring on 6 layer(s)"), "seal ring");
    assert!(log.contains("45 pad(s) (23 port(s) padded"), "pad insertion:\n{}", log);
    assert!(log.contains("39 inline bond pad(s)") && log.contains("39 staggered bond pad(s)"), "bond pads");
    assert!(log.contains("IO ring checks: 200 object(s), 2 domain segment(s), 0 violation(s)"), "ESD clean ring:\n{}", log);
    assert!(log.contains("Wire-bond check (staggered)") && log.contains("min same-row pitch [bottom r0 60.0"), "staggered pitch");
    assert!(log.contains("DEF special wiring: 48 shape(s) [seal_ring 48]"), "seal ring DEF read-back");
    assert!(log.contains("Pin placement: 23 fixed"), "chip ports on pad pins");
    assert!(log.contains("ESD-003 IO domains IOA / IOB adjoin without a breaker"), "ESD negative: breaker");
    assert!(log.contains("ESD-006 signal pad io_dout"), "ESD negative: clamp distance");
    assert!(!log.contains("Error: "), "errors in flow");
}

#[test]
fn macro_floorplan_io_pins_spares() {
    let log = run("examples/chipfp", "macro_fp.tcl");
    assert!(log.contains("core (12.00,12.00)-(312.00,252.00) (300.0 x 240.0 um"), "core size + spacing:\n{}", log);
    assert!(log.contains("Placed 19 IO pin(s) in 2 group(s) [left 19], buses grouped"), "bus-grouped pins");
    assert!(log.contains("random;"), "random pin placement");
    assert!(log.contains("refined; pin-to-logic wirelength"), "pin refinement");
    assert!(log.contains("Placed 4 macro(s) in 2 group(s)"), "macro placement:\n{}", log);
    assert!(log.contains("of 4 macro(s) to the 0.200 x 1.600 um placement grid") && log.contains("0 overlap(s)"), "macro snap");
    assert!(log.contains("Snapped IO pins to routing tracks: 1 moved"), "pin snap");
    assert!(log.contains("28 spare cell(s) in 4 spare group(s) over 2 module(s)"), "spares per module");
    assert!(log.contains("Placement is legal"), "legal with fixed macros + spares");
    assert!(!log.contains("Error: "), "errors in flow");
}

#[test]
fn flipchip_bumps_rdl() {
    let log = run("examples/chipfp", "flipchip_chip.tcl");
    assert!(log.contains("Created 49 BUMP60 bump(s) (full pattern"), "bump array:\n{}", log);
    assert!(log.contains("BUMP-005"), "bump overlap check");
    assert!(log.contains("on the bump-channel crossings"), "area IO");
    assert!(log.contains("Assigned 23 signal bump(s)") && log.contains("13 power (VDD) and 13 ground (VSS)"), "assignment");
    assert!(log.contains("flyline crossings") && log.contains("-> 0,"), "re-optimization removes crossings");
    assert!(log.contains("45-degree allowed): length") && log.contains("0 conflict(s) (RDL-100)"), "RDL:\n{}", log);
    assert!(log.contains("DEF special wiring: 79 shape(s) [rdl 23, seal_ring 56], 49 bump(s) (49 assigned)"), "bump / RDL DEF read-back");
    assert!(!log.contains("Error: "), "errors in flow");
    let txt = std::fs::read_to_string("examples/chipfp/out/flipchip_bumps.txt").unwrap();
    assert_eq!(txt.lines().filter(|l| l.contains(" signal ")).count(), 23);
}

#[test]
fn route_edits_and_via_swap() {
    let log = run("examples/chipfp", "route_edit.tcl");
    assert!(log.contains("cut_wire:") && log.contains("net is OPEN"), "cut:\n{}", log);
    assert!(log.contains("add_wire:") && log.contains("net now connected"), "add_wire reconnects");
    assert!(log.contains("add_via:") && log.contains("type VIA34_2CUT (R x0.50)"), "add_via");
    assert!(log.contains("delete_via:") && log.contains("net still connected"), "delete_via");
    assert!(log.contains("swap_via:") && log.contains("-> VIA12_2CUT"), "swap_via");
    assert!(log.matches("check_routes: no opens, no shorts").count() >= 3, "route_eco repairs the deleted wire");
    assert!(!log.contains("Error: "), "errors in flow");
}

#[test]
fn eco_premask_and_postmask() {
    let _g = FLOW_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let log = run("examples/chipfp", "eco_prep.tcl");
    assert!(log.contains("Inserted 1 buffer(s) (BUF_X1_SVT)"), "ECO target:\n{}", log);
    let log = run("examples/chipfp", "eco_premask.tcl");
    assert!(log.contains("3 instance(s) added, 0 deleted, 0 master change(s)"), "diff:\n{}", log);
    assert!(log.contains("eco_netlist: 0 change(s) found"), "second diff clean");
    assert!(log.contains("Verification SUCCEEDED: 10 outputs"), "pre-mask ECO equivalence:\n{}", log);
    let log = run("examples/chipfp", "eco_postmask.tcl");
    assert!(log.contains("Inserted 24 spare cell(s)"), "spares");
    assert!(log.contains("gate-array base filler(s)"), "GA fill");
    assert!(log.contains("-> 2 spare cell(s), 0 gate-array cell(s); 1 unmapped"), "spare remap:\n{}", log);
    assert!(log.contains("-> gate array GBUF_X1"), "gate-array remap");
    assert!(log.contains("ECO mask check: PASS (0 base-layer change(s)"), "metal-only ECO passes");
    assert!(log.contains("ECO mask check: FAIL"), "frozen M1 detected");
    assert!(log.contains("Verification SUCCEEDED: 10 outputs"), "post-mask ECO equivalence:\n{}", log);
}

#[test]
fn gui_flylines_schematic_and_complete_help() {
    let _g = FLOW_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let log = run("examples/chipfp", "gui_flylines.tcl");
    assert!(log.contains("Flylines for 1 selected cell(s) (1 macro(s), 0 standard cell(s)): 30 connected pin(s), 125 flyline(s)"), "flylines of one macro:\n{}", log);
    assert!(log.contains("standard cell(s)): ") && log.contains("Flylines for 28 selected cell(s) (1 macro(s), 27 standard cell(s)): 130 connected pin(s), 1801 flyline(s)") && log.contains("(0 macro(s), 157 standard cell(s))"), "flylines of standard cells:\n{}", log);
    assert!(log.contains("GUI view: (10.00, 10.00) - (90.00, 70.00)"), "gui_zoom");
    assert!(log.contains("Flylines for 4 selected cell(s)"), "all macros");
    assert!(log.contains("(macro-to-macro only)"), "macro-to-macro filter");
    assert!(log.contains("Schematic: 163 cell(s)"), "whole-design schematic");
    assert!(log.contains("('write_gds' is an alias of export_gds)"), "help for an alias:\n{}", log);
    assert!(log.contains("('gui_show' is an alias of gtk_gui)") && log.contains("gui_start, start_gui, gui_show, gui_open, win"), "gui_show in help:\n{}", log);
    assert!(log.contains("commands to 'out/commands.csv'"), "command list");
    let st = std::fs::read_to_string("examples/chipfp/out/gui_flylines.json").unwrap();
    assert!(st.contains("\"fly\":{\"l\":[[") && st.contains("\"sch\":{\"cells\":[["), "GUI state carries flylines + schematic");
    assert!(st.contains("\"lef_layers\":[{\"n\":\"NWELL\"") && st.contains("\"n\":\"VIA12\",\"k\":\"CUT\""), "GUI state carries the LEF layer stack");
    if cfg!(feature = "gtk") {
        assert!(log.contains("Wrote schematic image 'out/schematic.svg'") && log.contains("Wrote layout image 'out/layout.png'"), "headless images:\n{}", log);
    } else {
        assert!(log.contains("schematic image: write_schematic: this rsynth was built without the GUI"), "{}", log);
    }
    assert!(log.contains("Deselected all (") && log.contains("GUI-032"), "gui_deselect_all");
    let csv = std::fs::read_to_string("examples/chipfp/out/commands.csv").unwrap();
    for c in ["export_gds", "gtk_gui", "gui_show_flylines", "gui_show_schematic", "create_pad_ring", "puts", "report_timing"] {
        assert!(csv.contains(&format!("\"{}\"", c)), "{} missing from the command list", c);
    }
    assert!(csv.contains("write_gds"), "alias in the command list");
}

#[test]
fn shell_tab_completion_and_emacs_keys() {
    // drives the interactive shell through a pseudo-terminal (needs python3; skipped without it)
    let py = std::process::Command::new("python3").env("RSYNTH_NOLOG", "1").arg("--version").output();
    if py.map(|o| !o.status.success()).unwrap_or(true) {
        eprintln!("python3 not available: skipped");
        return;
    }
    let exe = env!("CARGO_BIN_EXE_rsynth");
    let o = std::process::Command::new("python3").env("RSYNTH_NOLOG", "1").arg("examples/lineedit_pty_test.py").arg(exe).output().unwrap();
    let out = String::from_utf8_lossy(&o.stdout);
    assert!(out.contains("ALL OK"), "line editor:\n{}\n{}", out, String::from_utf8_lossy(&o.stderr));
}

#[test]
fn no_gui_option_keeps_the_shell() {
    use std::io::Write;
    let exe = env!("CARGO_BIN_EXE_rsynth");
    let mut ch = std::process::Command::new(exe).env("RSYNTH_NOLOG", "1").args(["-x", "set v 42", "-no_gui"]).stdin(std::process::Stdio::piped()).stdout(std::process::Stdio::piped()).spawn().unwrap();
    ch.stdin.as_mut().unwrap().write_all(b"puts \"shell v=$v\"\nexit\n").unwrap();
    let o = ch.wait_with_output().unwrap();
    let out = String::from_utf8_lossy(&o.stdout);
    assert!(out.contains("shell v=42"), "-no_gui stays interactive after -x:\n{}", out);
    let o = std::process::Command::new(exe).env("RSYNTH_NOLOG", "1").arg("-help").output().unwrap();
    let h = String::from_utf8_lossy(&o.stdout);
    assert!(h.contains("-no_gui") && h.contains("-gui      Open GUI") && !h.contains("-gtk_gui") && !h.contains("Emacs") && !h.contains("html") && !h.contains("browser"), "concise usage:\n{}", h);
    let o = std::process::Command::new(exe).env("RSYNTH_NOLOG", "1").args(["-x", "puts ok", "-html_gui"]).output().unwrap();
    let t = String::from_utf8_lossy(&o.stdout);
    assert!(t.contains("Option -html_gui was removed") && t.contains("ok"), "removed option:\n{}", t);
    let o = std::process::Command::new(exe).env("RSYNTH_NOLOG", "1").args(["-x", "puts [catch {gui_write_html x.html} m]"]).output().unwrap();
    assert!(String::from_utf8_lossy(&o.stdout).contains("1\n") || String::from_utf8_lossy(&o.stdout).contains("Unknown command"), "gui_write_html is gone");
}

#[cfg(feature = "gtk")]
#[test]
fn gtk_gui_renders_layout_and_schematic() {
    // needs an X server: runs under xvfb-run when available, otherwise skipped
    if std::process::Command::new("xvfb-run").env("RSYNTH_NOLOG", "1").arg("--help").output().is_err() {
        eprintln!("xvfb-run not available: skipped");
        return;
    }
    let _g = FLOW_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let exe = env!("CARGO_BIN_EXE_rsynth");
    let dir = std::env::temp_dir().join("rsynth_gtk_test");
    let _ = std::fs::create_dir_all(&dir);
    let prefix = dir.join("shot").to_string_lossy().to_string();
    for f in ["_layout.png", "_schematic.png", "_after.png", "_layout_view.png"] { let _ = std::fs::remove_file(format!("{}{}", prefix, f)); }
    let o = std::process::Command::new("xvfb-run").env("RSYNTH_NOLOG", "1").args(["-a", "-s", "-screen 0 1600x1000x24", exe, "-f", "macro_fp.tcl", "-gui"]).current_dir("examples/chipfp")
        .env("RSYNTH_GTK_SCREENSHOT", &prefix).env("RSYNTH_GTK_CMDS", "gui_show_flylines -cells {u_bank0/u_ram0};gui_show_flylines -add -cells {u_bank0/*reg*}").output().unwrap();
    let log = String::from_utf8_lossy(&o.stdout);
    assert!(log.contains("GTK GUI opened") && log.contains("GTK GUI closed"), "GTK GUI run:\n{}", log);
    for f in ["_layout.png", "_schematic.png", "_after.png", "_layout_view.png"] {
        let m = std::fs::metadata(format!("{}{}", prefix, f)).map(|m| m.len()).unwrap_or(0);
        assert!(m > 10_000, "{}{} missing or empty", prefix, f);
    }
}

fn have_iverilog() -> bool {
    Command::new("iverilog").env("RSYNTH_NOLOG", "1").arg("-V").output().map(|o| o.status.success() || !o.stdout.is_empty()).unwrap_or(false)
}

fn vsim(dir: &str, files: &[&str], defines: &[&str]) -> String {
    let _ = dir; let exe = format!("out/sim_{}.vvp", files[0].replace(['/', '.'], "_"));
    let mut c = Command::new("iverilog");
    c.current_dir(dir).args(["-o", &exe]);
    for d in defines { c.arg(format!("-D{}", d)); }
    let o = c.args(files).output().expect("iverilog");
    assert!(o.status.success(), "iverilog failed: {}", String::from_utf8_lossy(&o.stderr));
    let o = Command::new("vvp").env("RSYNTH_NOLOG", "1").current_dir(dir).arg(&exe).output().expect("vvp");
    String::from_utf8_lossy(&o.stdout).to_string()
}

#[test]
fn advanced_dft_occ_compression_bscan_mbist_atpg() {
    let log = run("examples/dft", "dft_flow.tcl");
    assert!(!log.contains("Error: "), "errors in DFT flow:\n{}", log);
    for m in ["DFT-410", "DFT-425", "DFT-432", "DFT-445", "DFT-434", "DFT-463", "DFT-447", "DFT-437", "ATPG-030", "ATPG-040"] {
        assert!(log.contains(m), "missing {}", m);
    }
    assert!(log.contains("DFT sanity: 13 check(s), 0 failure(s)"), "check_dft failures:\n{}", log);
    assert!(log.contains("Verification SUCCEEDED"), "functional mode not equivalent:\n{}", log);
    let cov = |model: &str| -> f64 {
        let l = log.lines().find(|l| l.contains("ATPG-100") && l.contains(model)).expect("atpg line");
        l.split("fault coverage ").nth(1).unwrap().split('%').next().unwrap().parse().unwrap()
    };
    assert!(cov("stuck_at") > 95.0, "stuck-at coverage {}", cov("stuck_at"));
    assert!(cov("transition") > 60.0, "transition coverage {}", cov("transition"));
    let bsdl = std::fs::read_to_string("examples/dft/out/mem_sys.bsdl").unwrap();
    assert!(bsdl.contains("BOUNDARY_LENGTH") && bsdl.contains("IDCODE_REGISTER"));
    let stil = std::fs::read_to_string("examples/dft/out/sa.stil").unwrap();
    assert!(stil.starts_with("STIL 1.0;") && stil.contains("\"load_unload\"") && stil.contains("ScanChain"));
    if !have_iverilog() { eprintln!("iverilog not found: gate-level DFT simulations skipped"); return; }
    let d = "examples/dft";
    let nl = ["out/mem_sys_dft.v", "out/models.v"];
    for (tb, pass) in [("out/tb_sa.v", "SCAN PATTERNS PASSED"), ("out/tb_tr.v", "SCAN PATTERNS PASSED"), ("out/tb_bscan.v", "BOUNDARY SCAN PASSED"), ("out/tb_mbist.v", "MBIST PASSED")] {
        let o = vsim(d, &[tb, nl[0], nl[1]], &[]);
        assert!(o.contains(pass), "{}:\n{}", tb, o);
    }
    let o = vsim(d, &["out/tb_mbist.v", nl[0], nl[1]], &["RSYNTH_INJECT_FAULT"]);
    assert!(o.contains("MBIST FAILED"), "injected memory defect not detected:\n{}", o);
}

#[test]
fn lockup_latches_between_clock_domains() {
    let log = run("examples/dft", "lockup_flow.tcl");
    assert!(!log.contains("Error: "), "{}", log);
    assert!(log.contains("1 lockup latch(es) inserted"), "{}", log);
    assert!(log.contains("fault coverage 100.00%"), "{}", log);
    if have_iverilog() {
        let o = vsim("examples/dft", &["out/tb_two_clock.v", "out/two_clock_dft.v", "out/two_clock_models.v"], &[]);
        assert!(o.contains("SCAN PATTERNS PASSED"), "{}", o);
    }
}

#[test]
fn rows_tracks_physical_cells_and_unplace() {
    let log = run("examples/chipfp", "rows_phys.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(4000)..]);
    let m = |k: &str| -> usize { log.lines().find_map(|l| l.strip_prefix(&format!("{} ", k))).and_then(|v| v.trim().parse().ok()).unwrap_or_else(|| panic!("{} missing:\n{}", k, log)) };
    assert!(m("CUT") > 0 && m("CUTA") > 0 && m("CR") == 4 && m("DEL") > 0);
    assert!(log.contains("site coreSite       214 row(s)"), "rows after edits:\n{}", log);
    assert!(log.contains("create_track: layer M2 X (vertical) tracks: start 12.1 step 0.2"));
    assert!(m("ENDCAP") == 2 * 214 && m("TAP") > 100);
    assert!(log.contains("Placement is legal"), "placement inside the edited rows");
    assert!(m("DECAP") == 40 && m("FILL") > 1000);
    assert_eq!(m("DELI"), m("FILL"), "delete_instance -inst *FILL* removes the fillers");
    assert_eq!(m("DELD"), 40);
    assert!(m("UNP1") > 0 && log.contains("fixed instance(s) kept (use -override_fixed)"));
    assert_eq!(m("UNP3"), 0);
    assert_eq!(m("UNP4"), 4, "macros unplaced with -override_fixed");
    assert_eq!(m("UNP5"), 2 * 214 + m("TAP"));
    let def = std::fs::read_to_string("examples/chipfp/out/rows_phys.def").unwrap();
    assert!(def.contains("ROW RSROW_") && def.contains("TRACKS X 12100 DO 1560 STEP 200 LAYER M2 ;"), "DEF rows / tracks");
    assert!(def.contains("FILL16") && def.contains("TAPCELL") && def.contains("ENDCAPR"));
    // re-read: the edited rows are kept
    assert_eq!(log.matches("site coreSite       214 row(s)").count(), 2, "rows survive write_def / read_def");
    let st = std::fs::read_to_string("examples/chipfp/out/rows_phys.json").unwrap();
    assert!(st.contains("\"rowl\":[[") && st.contains("\"tracks\":[[\"M1\",\"Y\""));
}

#[test]
fn power_grid_vias_drc_lvs_markers_and_ndr() {
    let log = run("examples/chipfp", "pg_flow.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(4000)..]);
    let m = |k: &str| -> usize { log.lines().find_map(|l| l.strip_prefix(&format!("{} ", k))).and_then(|v| v.trim().split_whitespace().next().and_then(|x| x.parse().ok())).unwrap_or_else(|| panic!("{} missing:\n{}", k, log)) };
    assert!(m("MV0") > 0 && m("VIA") > 0, "missing vias before generate_vias");
    assert_eq!((m("MV1"), m("LVS0"), m("DRC0")), (0, 0, 0), "clean power grid after generate_vias");
    assert!(m("MV2") > 0 && m("DRC1") >= 1 && m("LVS1") >= 2, "injected short / opens / missing vias detected");
    assert!(m("RM") >= m("MV2"), "Calibre markers read back");
    assert_eq!((m("MV3"), m("DRC2"), m("LVS2")), (0, 0, 0), "fixed and re-verified");
    assert!(m("TR1") >= 2 && m("TR2") >= 1 && m("TR3") >= 2, "schematic tracing");
    let rdb = std::fs::read_to_string("examples/chipfp/out/pg_markers.rdb").unwrap();
    assert!(rdb.lines().next().unwrap_or("").starts_with("mem_sys "), "Calibre RDB header");
    assert!(rdb.contains("p 1 4") || rdb.contains("p 1 4\n"), "Calibre polygons");
    let def = std::fs::read_to_string("examples/chipfp/out/pg.def").unwrap();
    assert!(def.contains("NONDEFAULTRULES") && def.contains("+ NONDEFAULTRULE NDR_2W2S"), "NDR in DEF");
    assert!(def.contains("+ SHAPE RING") && def.contains("+ SHAPE STRIPE") && def.contains("+ SHAPE FOLLOWPIN"), "special nets in DEF");
    let st = std::fs::read_to_string("examples/chipfp/out/pg.json").unwrap();
    assert!(st.contains("\"markers\":[[") && st.contains("\"ndrs\":[") && st.contains("\"nets\":["), "GUI state: markers / NDRs / net names");
}

#[test]
fn nangate45_io_ring_gate_array_and_flip_chip_libraries() {
    let log = run("examples/nangate45", "n45_wirebond.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(4000)..]);
    for lib in ["n45_ga_tt_1p10v_25c", "n45_ga_ss_0p95v_125c", "n45_ga_ff_1p25v_m40c"] { assert!(log.contains(&format!("Loaded Library '{}'", lib)) && log.contains(&format!("{}.lib): 36 cells", lib)), "GA library {}", lib); }
    for lib in ["n45_io_tt_1p10v_25c", "n45_io_ss_0p95v_125c", "n45_io_ff_1p25v_m40c"] { assert!(log.contains(&format!("Loaded Library '{}'", lib)), "IO library {}", lib); }
    assert!(log.contains("0 gap(s) (IO-220)"), "abutted pad ring: no gaps");
    assert!(log.contains("used as input: tied OE=0 IE=1") && log.contains("used as output: tied OE=1 IE=0"), "GPIO enables tied per direction");
    let num = |k: &str| -> i64 { log.lines().find_map(|l| l.strip_prefix(&format!("{} ", k))).and_then(|v| v.trim().parse().ok()).unwrap_or_else(|| panic!("{} missing", k)) };
    assert_eq!((num("ESD"), num("BOND"), num("MV"), num("PGLVS")), (0, 0, 0, 0), "ESD / bond / missing vias / PG LVS clean");
    assert!(log.contains("pin 'IO_VDD' of instances '*' -> net VDDIO") && log.contains("Placement is legal"), "pad PG pins connected, legal");
    let def = std::fs::read_to_string("examples/nangate45/out/n45_wirebond.def").unwrap();
    assert_eq!(def.matches(" N45IO_GPIO + FIXED").count(), 10, "every GPIO pad survives optimization (pads are never merged)");
    assert!(def.contains("N45IO_CORNER") && def.contains("N45IO_BRK_IO") && def.contains("N45IO_FILL") && def.contains("GFILLER_X"), "ring + GA fillers in DEF");
    let log = run("examples/nangate45", "n45_flipchip.tcl");
    assert!(!log.contains("Error: "), "{}", &log[log.len().saturating_sub(4000)..]);
    assert!(log.contains("Created 36 N45_BUMP_C4_80 bump(s)") && log.contains("Inserted 23 area-IO pad(s) (N45IO_AIO_IN / N45IO_AIO_OUT)"), "bumps + area IO");
    assert!(log.contains("45-degree allowed): length") && log.contains("0 conflict(s) (RDL-100)"), "RDL routed");
}

#[test]
fn query_objects_and_rulers() {
    let dir = "examples/nangate45";
    std::fs::write(format!("{}/out_query_test.tcl", dir), "source n45_wirebond.tcl\nputs \"Q1 [query_objects -name io_din0]\"\nputs \"Q2 [query_objects -type net -name clk]\"\nputs \"Q3 [query_objects -name {din[3]}]\"\nputs \"Q4 [query_objects -name io_vdd0/CORE_VDD]\"\nputs \"Q5 [query_objects -name nosuch]\"\nputs \"R1 [gui_add_ruler -from {0 0} -to {3 4}]\"\nputs \"R2 [measure_distance -from {0 0} -to {120 120}]\"\nputs \"RR [report_rulers]\"\nputs \"RC [gui_clear_rulers]\"\n").unwrap();
    let log = run(dir, "out_query_test.tcl");
    let _ = std::fs::remove_file(format!("{}/out_query_test.tcl", dir));
    for k in ["Q1 1", "Q2 1", "Q3 1", "Q4 1", "Q5 0", "R1 5.0000", "R2 169.7056", "RR 1", "RC 1"] { assert!(log.contains(k), "{} missing:\n{}", k, &log[log.len().saturating_sub(3000)..]); }
    assert!(log.contains("Type                 IO pad") && log.contains("Master               N45IO_GPIO") && log.contains("Orientation          N"), "instance tabs");
    assert!(log.contains("PAD (inout)          din[0]"), "pad PAD pin stays on the port net (never buffered)");
    assert!(log.contains("IO_VDD (power)       VDDIO") && log.contains("Global net           VDD"), "PG pins with global nets");
    assert!(log.contains("[Connections]") && log.contains("load                 io_clk/PAD") && log.contains("Pad                  io_din3"), "net / port tabs");
    assert!(log.contains("Manhattan 7.0000, angle 53.13 deg"), "ruler measures diagonals");
}

#[test]
fn placement_prechecks_row_site_and_io_overlaps() {
    let log = run("examples/nangate45", "n45_place_checks.tcl");
    let v = |k: &str| -> String { log.lines().find_map(|l| l.strip_prefix(&format!("{} ", k))).map(|s| s.to_string()).unwrap_or_else(|| panic!("{} missing:\n{}", k, &log[log.len().saturating_sub(3000)..])) };
    // clean design: checks pass, placement runs
    assert_eq!((v("SITE0"), v("IO0"), v("LEG0"), v("LP0"), v("SITE3")), ("0".into(), "0".into(), "0".into(), "0".into(), "0".into()));
    assert!(log.contains("place_detail: ROW / SITE pre-check passed"), "pre-check reported");
    // placement grid 0.2 um vs LEF SITE 0.19 um: both commands abort, nothing moved
    assert!(v("SITE1").parse::<usize>().unwrap() > 0);
    assert!(v("PD1").starts_with("1 place_detail: aborted") && v("LP1").starts_with("1 legalize_placement: aborted"), "abort on site mismatch");
    assert!(log.contains("(PLC-402)") && log.contains("(PLC-404)") && log.contains("(PLC-406)"), "site size / width / grid mismatches reported");
    assert_eq!(v("LP1S"), "0", "-skip_site_check bypasses");
    // DEF rows on an undefined site
    assert!(v("PD2").starts_with("1 place_detail: aborted") && log.contains("which no LEF SITE defines (LEF sites:") && log.contains("but no row uses it (rows: coreSite) (PLC-401)"), "DEF ROW site mismatch");
    // IO pad overlaps: neighbours, a pad across fillers, a pad outside the die
    assert_eq!(v("IO1"), "5", "4 overlaps + 1 outside the die");
    assert!(log.contains("IO pad io_din0 overlaps IO pad io_din1") && log.contains("io_dout0 extends outside the die"), "overlaps listed");
    assert_eq!(v("LEG1"), "5", "check_legality counts IO overlaps");
    assert!(log.contains("ESD-009 iofill_right_16 and io_dout0 overlap"), "non-adjacent overlaps in check_esd");
    assert!(v("PD3").contains("5 IO pad / macro overlap(s)"), "placement aborts on IO overlaps");
    assert!(log.contains("drc   io_overlap           4"), "markers");
}

#[test]
fn report_timing_derate_columns() {
    let log = run("examples", "derate_report.tcl");
    assert!(log.contains("UserDer      OCV      AOCV(d)    POCVsig   Derate"), "derate column headers");
    assert!(log.contains("report_timing columns: point cell user_derate ocv_derate aocv_derate pocv_sigma derate incr path edge"), "format flags");
    // corner OCV: 1.08 cell / 1.05 net
    assert!(log.contains("-    1.080            -          -    1.080") && log.contains("-    1.050            -          -    1.050"), "OCV cell / net derates");
    // object derate on one cell wins over the corner derate
    assert!(log.contains("1.200    1.080            -          -    1.200"), "user derate column");
    // AOCV: depth-based derate replaces the flat cell derate
    assert!(log.lines().any(|l| l.contains("/d") && l.contains("1.080     1.0")), "AOCV derate with depth");
    // POCV sigma column (-format) and attributes
    assert!(log.contains("POCVsig   Derate") && log.contains("ATTR derate 1.0500 ocv 1.0500"), "POCV column + attributes");
}

#[test]
fn part_selects_ascending_reversed_indexed() {
    let log = run("examples/partselect", "partselect.tcl");
    for t in ["DONE ps", "DONE ps3", "DONE ps4", "DONE ps2"] { assert!(log.contains(t), "{} missing:\n{}", t, log); }
    assert!(!log.contains("ELAB-208"), "variable indexed part-select lvalues are supported");
    assert!(log.contains("reversed part-select i[3:9] on a [15:0] vector") && log.contains("synthesized as i[9:3] (ELAB-148)"), "reversed select warned");
    let ps = std::fs::read_to_string("examples/partselect/out/ps_gen.v").unwrap();
    assert!(ps.contains("input [0:15] j;") && ps.contains("input [15:0] i;"), "declared bus direction kept:\n{}", ps);
    assert!(ps.contains("assign b[6] = j[3];") && ps.contains("assign b[0] = j[9];") && ps.contains("assign a[0] = i[3];"), "j[3:9] / i[9:3] bit order");
    let p3 = std::fs::read_to_string("examples/partselect/out/ps3_gen.v").unwrap();
    assert!(p3.contains("input [6:0] x;") && p3.contains("output [0:15] o;"), "hierarchical port keeps its full declared range");
    assert!(p3.contains("assign p[0] = 1'b0;"), "constant output bits assigned");
    // RTL vs netlist simulation when iverilog is installed
    if std::process::Command::new("iverilog").env("RSYNTH_NOLOG", "1").arg("-V").output().is_ok() {
        for (f, t) in [("ps_basic.sv", "ps"), ("ps_ascending.sv", "ps3"), ("ps_indexed.sv", "ps4")] {
            let o = std::process::Command::new("python3").env("RSYNTH_NOLOG", "1").current_dir("examples/partselect").args(["eqv.py", f, t, &format!("out/{}_gen.v", t)]).output().unwrap();
            let s = String::from_utf8_lossy(&o.stdout);
            assert!(s.contains("RESULT 0 mismatches"), "{} vs netlist: {}{}", f, s, String::from_utf8_lossy(&o.stderr));
        }
    }
}

#[test]
fn clock_tree_spec_trace_update_timing_free_design() {
    let log = run("examples/cts", "cts_flow.tcl");
    let v = |k: &str| -> String { log.lines().find_map(|l| l.strip_prefix(&format!("{} ", k))).map(|s| s.to_string()).unwrap_or_else(|| panic!("{} missing:\n{}", k, &log[log.len().saturating_sub(4000)..])) };
    // tracing: gates, macro / float pins, divider, clock as data
    assert_eq!(v("TR0"), "34");
    assert!(log.contains("clock gates          clk_gate_r0 clk_gate_r1") && log.contains("float pins           u_ram/CLK (0.080ns)"), "trace details");
    assert!(log.contains("clock 'clk_div' reaches 1 data pin(s)"), "clock as data");
    // spec dump / read / honoured by clock_opt
    let cfg = std::fs::read_to_string("examples/cts/out/clocktree.cfg").unwrap();
    for k in ["clock_transition", "clock_tree_buffer_list", "clock_tree_inv_list", "clock_target_skew", "honor_dont_use", "honor_dont_touch", "balance_clock_group     clk_a_group {clk_a clk_div}", "ignore_pins", "leaf_pins", "through_pins", "float_pins"] { assert!(cfg.contains(k), "{} in clocktree.cfg", k); }
    assert!(log.contains("ignore 1 / leaf 0 / through 0 / float 1 pin(s) (CTS-404)") && log.contains("Balancing 2 skew group(s): clk_a_group"), "spec honoured");
    assert!(log.contains("Latency target 0.6000ns (clk_b)"), "per-clock latency target");
    assert_eq!(v("CO"), "0 ");
    // update_timing: incremental, reasons, -full, MMMC edits
    assert_eq!((v("UT0"), v("UT1"), v("UT2"), v("UTF"), v("UT3"), v("UT4")), ("2".into(), "0".into(), "2".into(), "2".into(), "1".into(), "2".into()));
    assert!(log.contains("stale         constraints, corner / derates") && log.contains("up to date") && log.contains("(forced)"), "update_timing status");
    assert!(log.contains("Delay corner 'ss' updated: late cell derate") && log.contains("Constraint mode 'func' reloaded from 1 SDC file(s)"), "MMMC edits");
    // free_design and reload in the same session
    assert!(log.contains("Freed design 'cts_demo'") && v("FD") == "1" && v("RELOAD").parse::<usize>().unwrap() > 50 && v("UT5") == "1", "free_design + reload");
}

fn have(tool: &str) -> bool {
    std::process::Command::new(tool).env("RSYNTH_NOLOG", "1").arg("--version").output().map(|o| o.status.success()).unwrap_or(false) || std::process::Command::new(tool).env("RSYNTH_NOLOG", "1").arg("-V").output().is_ok()
}

#[test]
fn sv_constant_expression_semantics() {
    // IEEE 1800 width / signedness rules, reference values from Verilator; no simulator needed
    let log = run("examples/svstress", "constexpr.tcl");
    assert!(log.contains("CONSTEXPR_DONE") && !log.contains("Error"), "{}", log);
    let net = std::fs::read_to_string("examples/svstress/out/t_constexpr_gen.v").unwrap();
    let expect: [u16; 26] = [0xfffd, 0x00f0, 0xff0f, 0x00fe, 0xfffe, 0x00aa, 0x002c, 0xff80, 0xfffd, 0xffff, 0xfffe, 0x007e, 0x0400, 0xffe5, 0x0010, 0xdcba, 0xfffe, 0x009e, 0x02d0, 0x0002, 0x0001, 0x0002, 0x0001, 0x000f, 0xfffd, 0x0100];
    for (i, e) in expect.iter().enumerate() {
        let mut v: u16 = 0;
        for b in 0..16 {
            let one = net.contains(&format!("assign c{}[{}] = 1'b1;", i, b));
            let zero = net.contains(&format!("assign c{}[{}] = 1'b0;", i, b));
            assert!(one ^ zero, "c{}[{}] is not a constant in the netlist", i, b);
            if one {
                v |= 1 << b;
            }
        }
        assert_eq!(v, *e, "c{} = {:04x}, expected {:04x}", i, v, e);
    }
}

#[test]
fn sv_stress_rtl_vs_netlist_simulation() {
    // every stress test: RTL simulated against the elaborated netlist (Icarus / Verilator)
    if !have("iverilog") || !have("verilator") {
        eprintln!("skipped: iverilog / verilator not installed");
        return;
    }
    let o = std::process::Command::new("python3").env("RSYNTH_NOLOG", "1").current_dir("examples/svstress").arg("svcheck.py").output().unwrap();
    let s = String::from_utf8_lossy(&o.stdout);
    let n = std::fs::read_dir("examples/svstress").unwrap().filter(|e| e.as_ref().map(|e| { let f = e.file_name().to_string_lossy().to_string(); f.starts_with("t_") && f.ends_with(".sv") }).unwrap_or(false)).count();
    assert!(s.contains(&format!("SUMMARY {} passed, 0 failed", n)), "{}", s);
}

#[test]
fn sv_stress_mapped_netlists_equivalent() {
    // a representative subset compiled to rs28 and verified against the elaborated RTL
    let o = std::process::Command::new("python3").env("RSYNTH_NOLOG", "1").current_dir("examples/svstress").args(["svcheck.py", "--compile", "--elab-only", "t_arith.sv", "t_seq2.sv", "t_memory2.sv", "t_struct2.sv", "t_tasks.sv", "t_loops.sv", "t_iface2.sv", "t_params2.sv"]).output().unwrap();
    let s = String::from_utf8_lossy(&o.stdout);
    assert!(s.contains("SUMMARY 8 passed, 0 failed"), "{}", s);
}

#[test]
fn sv_malformed_input_errors_and_fuzz() {
    // malformed RTL gives a clear error; mutated RTL never panics or hangs
    let o = std::process::Command::new("sh").env("RSYNTH_NOLOG", "1").arg("examples/svstress/check_errors.sh").output().unwrap();
    let s = String::from_utf8_lossy(&o.stdout);
    assert!(o.status.success() && s.lines().count() >= 15, "{}", s);
    assert!(s.contains("e_while_var.sv: ok -> e_while_var.sv:2: 'while' loop condition is not constant"), "{}", s);
    let o = std::process::Command::new("python3").env("RSYNTH_NOLOG", "1").current_dir("examples/svstress").args(["fuzz.py", "2", "3"]).output().unwrap();
    let s = String::from_utf8_lossy(&o.stdout);
    assert!(s.contains(", 0 failures"), "{}", s);
}

#[test]
fn version_flag_and_command() {
    let exe = env!("CARGO_BIN_EXE_rsynth");
    let o = std::process::Command::new(exe).env("RSYNTH_NOLOG", "1").arg("-version").output().unwrap();
    assert_eq!(String::from_utf8_lossy(&o.stdout).trim(), format!("RSynth {}", env!("CARGO_PKG_VERSION")));
    let cl = std::fs::read_to_string("CHANGELOG.md").unwrap();
    assert!(cl.contains(&format!("## [{}]", env!("CARGO_PKG_VERSION"))), "CHANGELOG has no entry for the current release");
    let rd = std::fs::read_to_string("README.md").unwrap();
    assert!(rd.contains(&format!("**Release {}**", env!("CARGO_PKG_VERSION"))), "README release line out of date");
}

#[test]
fn flylines_of_instances_pins_and_ports() {
    let log = run("examples", "fly_pins.tcl");
    let v = |k: &str| -> usize { log.lines().find_map(|l| l.strip_prefix(&format!("{} ", k))).and_then(|s| s.trim().parse().ok()).unwrap_or_else(|| panic!("{} missing", k)) };
    assert!(v("FLYCELL") > 0 && v("FLYPIN") > 0 && v("FLYPORT") > 0, "{}", log);
    assert!(v("FLYADD") > v("FLYPORT"), "-add keeps the port flylines and adds the cell's");
    assert_eq!(v("FLYBAD"), 1);
    assert!(log.contains(&format!("VERSION {}", env!("CARGO_PKG_VERSION"))));
}

#[cfg(feature = "gtk")]
#[test]
fn gtk_gui_selection_flylines_schematic_and_query_pages() {
    if std::process::Command::new("xvfb-run").env("RSYNTH_NOLOG", "1").arg("--help").output().is_err() {
        eprintln!("xvfb-run not available: skipped");
        return;
    }
    let _g = FLOW_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let exe = env!("CARGO_BIN_EXE_rsynth");
    let prefix = std::env::temp_dir().join("rsynth_gtk_sel").to_string_lossy().to_string();
    let go = |acts: &str| -> String {
        let o = std::process::Command::new("xvfb-run").env("RSYNTH_NOLOG", "1").args(["-a", "-s", "-screen 0 1600x1000x24", exe, "-f", "pnr_flow.tcl", "-gui"]).current_dir("examples")
            .env("RSYNTH_GTK_SCREENSHOT", &prefix).env("RSYNTH_GTK_ACTIONS", acts).output().unwrap();
        let s = String::from_utf8_lossy(&o.stdout).to_string();
        s.lines().find(|l| l.starts_with("GUI_ACTIONS selected")).unwrap_or_else(|| panic!("no GUI_ACTIONS line:\n{}", s)).to_string()
    };
    let num = |l: &str, k: &str| -> usize { l.split_whitespace().skip_while(|w| *w != k).nth(1).and_then(|x| x.parse().ok()).unwrap() };
    // click an instance: selected, flylines, schematic highlight, no automatic query
    let l = go("cell:u_core/g_lane[0].u_lane/U379");
    assert!(num(&l, "selected") == 1 && num(&l, "flylines") > 0 && num(&l, "schematic_highlighted") == 1 && num(&l, "query_pages") == 0, "{}", l);
    // shift-click ports, Q, page forward
    let l = go("cell:u_core/g_lane[0].u_lane/U379;shiftport:din0[1];shiftport:din0[0];key:q;key:next;key:next");
    assert!(num(&l, "selected") == 3 && num(&l, "query_pages") == 3 && num(&l, "page") == 3, "{}", l);
    // box selection: instances highlighted in the schematic, properties paginated
    let l = go("box:20,20,45,45;key:next");
    assert!(num(&l, "selected") > 5 && num(&l, "flylines") > 0 && num(&l, "schematic_highlighted") == num(&l, "selected") && num(&l, "page") == 2, "{}", l);
    // pin pick when zoomed in
    let l = go("zoomcell:u_core/g_lane[0].u_lane/U379;pin:u_core/g_lane[0].u_lane/U379/A1");
    assert!(num(&l, "selected") == 1 && num(&l, "flylines") > 0, "{}", l);
}

#[test]
fn lef_rule_routing_opc_fill_yield_antenna_and_net_length() {
    let bin = env!("CARGO_BIN_EXE_rsynth");
    let out = Command::new(bin).env("RSYNTH_NOLOG", "1").current_dir("examples/route_rules").args(["-nolog", "-f", "route_rules_test.tcl"]).output().expect("run rsynth");
    let log = String::from_utf8_lossy(&out.stdout).to_string() + &String::from_utf8_lossy(&out.stderr);
    let tail = &log[log.len().saturating_sub(6000)..];
    let v = |k: &str| -> Vec<f64> { log.lines().find_map(|l| l.strip_prefix(&format!("{} ", k))).unwrap_or_else(|| panic!("{} missing\n{}", k, tail)).split_whitespace().filter_map(|t| t.parse().ok()).collect() };
    assert!(!log.contains("Error: "), "errors in flow\n{}", tail);
    // route_auto -opc read the OPC rules; tech LEF rules in use
    assert!(log.contains("OPC-010") && log.contains("Read OPC / litho rules 'opc_fill.rules'"));
    assert_eq!(v("OPC")[0], 5.0, "5 layer sections in opc_fill.rules");
    assert!(log.contains("Rules              : LEF") && log.contains("RT-110") && log.contains("Track / spacing    : enforced by the router"), "routing rules from the tech LEF");
    // routing honours the LEF rules at every stage, including after fill and ECO
    // no shorts / spacing / off-track / width / cut / fill violations at any stage; at most a few
    // minimum-area pieces without room for a patch or a legal reroute
    for k in ["RULES", "RULES2", "RULES3", "TRIM"] { assert!(v(k)[0] <= 4.0, "{} route-rule violations\n{}", k, tail); }
    for key in ["  Off-track wiring   : ", "  Width              : ", "  Spacing            : ", "  Shorts             : ", "  Cut spacing        : ", "  Fill spacing       : "] {
        let vals: Vec<usize> = log.lines().filter_map(|l| l.strip_prefix(key)).filter_map(|x| x.trim().parse().ok()).collect();
        assert!(!vals.is_empty() && vals.iter().all(|x| *x == 0), "{} {:?}", key.trim(), vals);
    }
    assert!(log.contains("minimum-area patch(es) (LEF AREA)"));
    // antenna clean, ties within the fanout limit, port diodes
    assert_eq!(v("ANT")[0], 0.0);
    assert!(v("TIE")[0] >= 2.0 && log.contains("max fanout 3, max distance 20um"));
    assert!(v("PD")[0] >= 10.0, "a diode per input port");
    // place_opt / place_detail options
    assert!(log.contains("congestion effort medium") && log.contains("pre-routed PG stripe(s) on M4 as placement blockages") && log.contains("timing-driven"));
    // route options
    assert!(log.contains("RT-130"), "timing-driven routing order");
    assert!(log.contains("min layer M2, max layer M6"));
    // net-length buffering during route / route_opt
    assert!(log.contains("route_opt: net-length buffering (max 20.0um"));
    assert!(log.contains("route_auto: net-length buffering (max 25.0um"), "-max_buffering_distance");
    // route_opt -yield: wire spreading first, then multi-cut vias, no new route DRCs
    let ws = log.find("RT-510").or(log.find("RT-511")).expect("wire spreading ran");
    let vs = log.find("RT-520").expect("via swapping ran");
    assert!(ws < vs, "wire spreading before via swapping");
    assert!(log.contains("spacing violations 0 -> 0, shorts 0 -> 0"), "{}", tail);
    // OPC metal fill, density report, DEF FILLS section
    assert!(v("FILL")[0] > 100.0);
    assert!(v("DENS2")[0] <= 2.0, "M2/M3 density windows within the LEF limits after fill");
    let d = v("DEFFILL");
    assert!(d[0] > 0.0 && d[1] > d[0], "DEF FILLS section");
    assert!(v("DELFILL")[0] > 0.0);
    // repeaters: -buff_cell / -inv_cell, -lib_cell replaced, delete_repeater -inv_pairs
    assert!(log.contains("LIBCELL 1 add_repeater: -lib_cell is replaced by -buff_cell"));
    assert_eq!(v("BOTH")[0], 1.0);
    assert_eq!(v("NOTBUF")[0], 1.0);
    assert_eq!(v("BUF")[0], 1.0);
    assert_eq!(v("INV")[0], 2.0, "-inv_cell -stage_count 1 = one inverter pair");
    assert_eq!(v("DELINV")[0], 1.0);
}

#[test]
fn default_logs_run_metrics_and_save_restore_db() {
    let bin = env!("CARGO_BIN_EXE_rsynth");
    let ex = std::fs::canonicalize("examples/route_rules").unwrap();
    let lib = std::fs::canonicalize("examples/lib").unwrap();
    let dir = std::env::temp_dir().join(format!("rsynth_logdb_{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).unwrap();
    let flow = format!(
        "create_mode func ; create_corner ss ; create_corner ff\nread_lib -corner ss {l}/rs28_ss_0p72v_125c.lib\nread_lib -corner ff {l}/rs28_ff_0p88v_m40c.lib\ncreate_scenario -name func_ss -mode func -corner ss\ncreate_scenario -name func_ff -mode func -corner ff\nset_scenario_status func_ff -setup false -hold true\nread_lef {e}/rs28_rules_tech.lef\nanalyze -format sverilog {e}/rr_top.sv\nelaborate rr_small\ncurrent_mode func ; read_sdc {e}/rr.sdc\ncompile_fusion -to logic_opto\ninitialize_floorplan -core_utilization 0.35 -core2die_spacing 4\nplace_pins -self\nplace_opt\nroute_auto -opc {e}/opc_fill.rules\nextract_rc\nputs \"SAVE [save_db design.odb]\"\nputs \"LOGF [get_log_filename] [get_cmd_filename]\"\n",
        l = lib.display(), e = ex.display()
    );
    std::fs::write(dir.join("flow.tcl"), flow).unwrap();
    std::fs::write(dir.join("restore.tcl"), "puts \"REST [restore_db design.odb]\"\nputs \"RULES [check_route_rules]\"\nset_log_filename logs/my.log\nset_cmd_filename logs/my.cmd\nputs \"LOGF [get_log_filename] [get_cmd_filename]\"\nreport_run_metrics\n").unwrap();
    let run = |args: &[&str]| -> String {
        let o = Command::new(bin).env("RSYNTH_NOLOG", "1").current_dir(&dir).args(args).env_remove("RSYNTH_NOLOG").env_remove("RSYNTH_LOG_FILE").env_remove("RSYNTH_CMD_FILE").output().expect("run rsynth");
        String::from_utf8_lossy(&o.stdout).to_string() + &String::from_utf8_lossy(&o.stderr)
    };
    // 1) default rsynth.run.log / rsynth.cmd.log without any option; -l and -opc are gone
    let log1 = run(&["-l", "x.log", "-opc", "r.rules", "-f", "flow.tcl"]);
    assert!(log1.contains("Option -l was removed") && log1.contains("set_log_filename"), "{}", log1);
    assert!(log1.contains("Option -opc was removed from the rsynth command line"));
    assert!(!dir.join("x.log").exists());
    assert!(log1.contains("LOGF rsynth.run.log rsynth.cmd.log"));
    let runlog = std::fs::read_to_string(dir.join("rsynth.run.log")).unwrap();
    let cmdlog = std::fs::read_to_string(dir.join("rsynth.cmd.log")).unwrap();
    assert!(runlog.contains("@(#)RSynth") && runlog.contains("@ Run log: rsynth.run.log"));
    assert!(runlog.contains("<CMD> compile_fusion -to logic_opto"));
    assert!(cmdlog.lines().any(|l| l == "place_opt") && cmdlog.contains("route_auto -opc ") && !cmdlog.contains("<CMD>"));
    assert!(!cmdlog.contains("create_clock"), "SDC commands run by read_sdc are not user commands");
    // run metrics, Innovus style
    assert!(runlog.contains("*** place_opt #1 [begin] : totSession cpu/real = "));
    assert!(runlog.contains("*** route_auto #1 [finish] : cpu/real = ") && runlog.contains("mem = "));
    assert!(runlog.contains("*** route_auto #1 [metrics] : cells ") && runlog.contains("opens 0 shorts 0"));
    assert!(runlog.contains("Report : run_metrics") && runlog.contains("--- Ending \"RSynth\" (totcpu="));
    assert!(runlog.contains("Read OPC / litho rules"), "route_auto -opc");
    // save_db: gzip with timing, extraction, scenarios
    assert!(log1.contains("SAVE design.odb") && log1.contains("extraction") && log1.contains("2 scenario(s)"));
    let gz = std::fs::read(dir.join("design.odb")).unwrap();
    assert_eq!(&gz[..2], &[0x1f, 0x8b], "gzip");
    // 2) restore in a new process: timing matches, routing rules hold; logs go to the next free pair
    let log2 = run(&["-f", "restore.tcl"]);
    assert!(log2.contains("REST rr_small") && log2.contains("Restored timing matches the saved database in all 3 scenario(s)"), "{}", log2);
    assert!(log2.lines().any(|l| l.starts_with("RULES ") && l[6..].trim().parse::<usize>().map(|n| n <= 4).unwrap_or(false)), "{}", log2);
    assert!(log2.contains("LOGF logs/my.log logs/my.cmd"));
    assert!(!dir.join("rsynth.run.log1").exists(), "set_log_filename moved rsynth.run.log1");
    let my = std::fs::read_to_string(dir.join("logs/my.log")).unwrap();
    assert!(my.contains("@(#)RSynth") && my.contains("<CMD> restore_db design.odb") && my.contains("--- Ending"));
    assert!(std::fs::read_to_string(dir.join("logs/my.cmd")).unwrap().starts_with("restore_db design.odb"));
    // 3) the next run takes rsynth.run.log1 / rsynth.cmd.log1; -nolog writes none
    run(&["-x", "puts hi; exit"]);
    assert!(dir.join("rsynth.run.log1").exists() && dir.join("rsynth.cmd.log1").exists());
    run(&["-nolog", "-x", "exit"]);
    assert!(!dir.join("rsynth.run.log2").exists());
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn help_pattern_search() {
    let bin = env!("CARGO_BIN_EXE_rsynth");
    let script = "proc my_timing_check {{n 5}} {puts $n}\n\
        puts \"== glob\"; help report_t*\n\
        puts \"== word\"; help TIMING_D\n\
        puts \"== re\"; help -regexp {^route_(auto|opt)$}\n\
        puts \"== area\"; help -area metrics *file*\n\
        puts \"NAMES [help -names *_db]\"\n\
        puts \"== search\"; apropos {timing snapshot}\n\
        puts \"== proc\"; help *timing_check*\n\
        puts \"== builtin\"; help *each*\n\
        puts \"== none\"; help rpt_timng\n\
        puts \"== exact\"; help save_db\n\
        puts \"== bad\"; catch {help -bogus} m; puts \"BAD $m\"\n\
        puts \"== areas\"; help -areas\n\
        puts \"== usage\"; help -h\n";
    let o = Command::new(bin).env("RSYNTH_NOLOG", "1").args(["-x", &format!("{}exit", script)]).output().unwrap();
    let log = String::from_utf8_lossy(&o.stdout).to_string();
    let sec = |k: &str| -> String { let s = log.rfind(&format!("\n== {}\n", k)).map(|p| p + 1).unwrap_or_else(|| panic!("{} missing\n{}", k, log)); let r = &log[s + 3..]; r[..r.find("\n== ").unwrap_or(r.len())].to_string() };
    // glob: anchored, case-insensitive, aliases shown
    let g = sec("glob");
    assert!(g.contains("report_timing ") && g.contains("report_timing_derate") && g.contains("[alias report_test_coverage]"), "{}", g);
    assert!(!g.contains("report_area") && g.contains("command(s) match 'report_t*'"));
    // a word without wildcards matches anywhere, case-insensitive
    let w = sec("word");
    assert!(w.contains("report_timing_derate") && w.contains("set_timing_derate"), "{}", w);
    // regexp
    let r = sec("re");
    assert!(r.contains("route_auto") && r.contains("route_opt") && r.contains("2 command(s)"), "{}", r);
    // area filter
    let a = sec("area");
    assert!(a.contains("set_log_filename") && a.contains("get_cmd_filename") && !a.contains("report_run_metrics"), "{}", a);
    // names for scripts (aliases too: read_db)
    let n: Vec<&str> = log.lines().find_map(|l| l.strip_prefix("NAMES ")).unwrap().split_whitespace().collect();
    assert!(n.contains(&"save_db") && n.contains(&"restore_db") && n.contains(&"report_db"), "{:?}", n);
    // description search
    assert!(sec("search").contains("save_db") && sec("search").contains("[description]"));
    // user procs and Tcl built-ins
    assert!(sec("proc").contains("Tcl procs (user)") && sec("proc").contains("my_timing_check"));
    let b = sec("builtin");
    assert!(b.contains("foreach ") && b.contains("foreach_in_collection"));
    // no match: suggestions
    let x = sec("none");
    assert!(x.contains("No command matches 'rpt_timng'") && x.contains("Did you mean: report_timing"), "{}", x);
    // exact name: the detail view
    let e = sec("exact");
    assert!(e.contains("aliases  : write_db") && e.contains("about    : save the design database"), "{}", e);
    assert!(log.lines().any(|l| l.starts_with("BAD help: unknown option '-bogus'")));
    assert!(sec("areas").contains("Design database") && sec("usage").contains("help -regexp <re>"));
}
