//! Build-time command registry: every command name the dispatchers accept, with aliases,
//! source module, options and the doc comment of the implementing function. Scans
//! `match name {` arms inside functions taking `a: &[String]` (the command dispatchers).
use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::fmt::Write as _;

/// per line: brace depth at the start of the line, ignoring strings, chars and comments
fn depths(src: &str) -> Vec<i64> {
    let b: Vec<char> = src.chars().collect();
    let mut d = 0i64;
    let mut out = vec![0i64];
    let mut i = 0;
    let mut in_block = 0;
    while i < b.len() {
        let c = b[i];
        if c == '\n' {
            out.push(d);
            i += 1;
            continue;
        }
        if in_block > 0 {
            if c == '*' && b.get(i + 1) == Some(&'/') { in_block -= 1; i += 2; continue; }
            if c == '/' && b.get(i + 1) == Some(&'*') { in_block += 1; i += 2; continue; }
            i += 1;
            continue;
        }
        if c == '/' && b.get(i + 1) == Some(&'/') {
            while i < b.len() && b[i] != '\n' { i += 1; }
            continue;
        }
        if c == '/' && b.get(i + 1) == Some(&'*') { in_block = 1; i += 2; continue; }
        // raw strings r"..", r#".."#
        if c == 'r' && (b.get(i + 1) == Some(&'"') || b.get(i + 1) == Some(&'#')) && (i == 0 || !(b[i - 1].is_alphanumeric() || b[i - 1] == '_')) {
            let mut j = i + 1;
            let mut h = 0;
            while b.get(j) == Some(&'#') { h += 1; j += 1; }
            if b.get(j) == Some(&'"') {
                j += 1;
                loop {
                    if j >= b.len() { break; }
                    if b[j] == '\n' { out.push(d); }
                    if b[j] == '"' && (0..h).all(|k| b.get(j + 1 + k) == Some(&'#')) { j += 1 + h; break; }
                    j += 1;
                }
                i = j;
                continue;
            }
        }
        if c == '"' {
            let mut j = i + 1;
            while j < b.len() && b[j] != '"' {
                if b[j] == '\\' { j += 1; }
                if j < b.len() && b[j] == '\n' { out.push(d); }
                j += 1;
            }
            i = j + 1;
            continue;
        }
        if c == '\'' {
            // char literal ('x', '\n', '\u{..}') vs lifetime
            if b.get(i + 2) == Some(&'\'') { i += 3; continue; }
            if b.get(i + 1) == Some(&'\\') {
                let mut j = i + 2;
                while j < b.len() && b[j] != '\'' { j += 1; }
                i = j + 1;
                continue;
            }
            i += 1;
            continue;
        }
        if c == '{' { d += 1; }
        if c == '}' { d -= 1; }
        i += 1;
    }
    out
}

fn lits(s: &str) -> Vec<String> {
    let mut v = vec![];
    let b: Vec<char> = s.chars().collect();
    let mut i = 0;
    while i < b.len() {
        if b[i] == '"' {
            let mut j = i + 1;
            let mut t = String::new();
            while j < b.len() && b[j] != '"' {
                if b[j] == '\\' { j += 1; }
                if j < b.len() { t.push(b[j]); }
                j += 1;
            }
            v.push(t);
            i = j + 1;
        } else {
            i += 1;
        }
    }
    v
}

fn is_cmd(n: &str) -> bool {
    !n.is_empty() && n.len() <= 64 && n.chars().next().map(|c| c.is_ascii_alphabetic() || c == '_').unwrap_or(false)
        && n.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == ':') && n != "_"
}

/// option names used in a body: args(a, &["-x", ..]) values and .has/.get/.num("-x")
fn options(body: &str) -> (BTreeSet<String>, BTreeSet<String>) {
    let mut vals = BTreeSet::new();
    let mut flags = BTreeSet::new();
    let mut k = 0;
    while let Some(p) = body[k..].find("args(") {
        let s = k + p;
        if let Some(q) = body[s..].find("&[") {
            if q < 24 {
                let st = s + q + 2;
                if let Some(e) = body[st..].find(']') {
                    for l in lits(&body[st..st + e]) {
                        if l.starts_with('-') { vals.insert(l); }
                    }
                }
            }
        }
        k = s + 5;
    }
    for pat in [".has(\"", ".get(\"", ".num(\"", "== \"-", "\"-"] {
        let mut k = 0;
        while let Some(p) = body[k..].find(pat) {
            let s = k + p + pat.len();
            let st = if pat == "== \"-" || pat == "\"-" { s - 1 } else { s };
            if let Some(e) = body[st..].find('"') {
                let o = &body[st..st + e];
                if o.starts_with('-') && o.len() > 1 && o.len() < 40 && o[1..].chars().all(|c| c.is_ascii_alphanumeric() || c == '_') && o[1..].chars().next().map(|c| c.is_ascii_alphabetic()).unwrap_or(false) {
                    if pat == ".has(\"" { flags.insert(o.to_string()); }
                    else if pat == ".get(\"" || pat == ".num(\"" { vals.insert(o.to_string()); }
                    else if !vals.contains(o) { flags.insert(o.to_string()); }
                }
            }
            k = s;
        }
    }
    for v in &vals { flags.remove(v); }
    (vals, flags)
}

struct Arm {
    names: Vec<String>,
    module: String,
    body: String,
}

fn main() {
    println!("cargo:rerun-if-changed=src");
    let mut files: Vec<_> = std::fs::read_dir("src").unwrap().filter_map(|e| e.ok()).map(|e| e.path()).filter(|p| p.extension().map(|x| x == "rs").unwrap_or(false)).collect();
    files.sort();
    let mut fns: HashMap<String, (String, String)> = HashMap::new(); // name -> (body, doc)
    let mut arms: Vec<Arm> = vec![];
    for f in &files {
        let src = std::fs::read_to_string(f).unwrap();
        let module = f.file_stem().unwrap().to_string_lossy().to_string();
        let lines: Vec<&str> = src.lines().collect();
        let dep = depths(&src);
        // functions: name -> body text + doc comment
        let mut cur_sig: Option<(usize, i64, bool)> = None; // (start line, depth, takes args)
        let mut stack: Vec<(usize, i64, bool)> = vec![];
        for (i, l) in lines.iter().enumerate() {
            let d = dep[i];
            while let Some(&(_, sd, _)) = stack.last() {
                if d <= sd && i > stack.last().unwrap().0 { stack.pop(); } else { break; }
            }
            let t = l.trim_start();
            if let Some(p) = t.find("fn ") {
                let pre = &t[..p];
                if pre.is_empty() || pre.ends_with(' ') && ["pub ", "pub(crate) ", "async ", "unsafe ", "const "].iter().any(|k| pre.ends_with(k) || pre == *k) {
                    let name: String = t[p + 3..].chars().take_while(|c| c.is_alphanumeric() || *c == '_').collect();
                    if !name.is_empty() {
                        // body: until the depth returns to d
                        let mut j = i + 1;
                        while j < lines.len() && dep[j] > d { j += 1; }
                        let body = lines[i..j.min(lines.len())].join("\n");
                        let mut doc = vec![];
                        let mut k = i;
                        while k > 0 {
                            let pl = lines[k - 1].trim();
                            if let Some(c) = pl.strip_prefix("///") { doc.push(c.trim().to_string()); k -= 1; }
                            else if pl.starts_with("#[") { k -= 1; } else { break; }
                        }
                        doc.reverse();
                        let takes = body.lines().take(3).collect::<String>().contains("a: &[String]") || name == "invoke_inner";
                        fns.entry(name).or_insert((body, doc.join(" ")));
                        stack.push((i, d, takes));
                    }
                }
            }
            cur_sig = stack.last().copied();
            if !(l.contains("match name {") && cur_sig.map(|s| s.2).unwrap_or(false)) {
                continue;
            }
            let md = dep[i + 1];
            let mut j = i + 1;
            let mut arm_start: Option<(usize, Vec<String>)> = None;
            let flush = |s: &mut Option<(usize, Vec<String>)>, end: usize, arms: &mut Vec<Arm>| {
                if let Some((st, ns)) = s.take() {
                    arms.push(Arm { names: ns, module: module.clone(), body: lines[st..end].join("\n") });
                }
            };
            while j < lines.len() && dep[j] >= md {
                if dep[j] == md {
                    let tl = lines[j].trim_start();
                    if tl.starts_with('"') {
                        if let Some(p) = tl.find("=>") {
                            let head = &tl[..p];
                            let head = head.split(" if ").next().unwrap_or(head);
                            let ns: Vec<String> = lits(head).into_iter().filter(|n| is_cmd(n)).collect();
                            flush(&mut arm_start, j, &mut arms);
                            if !ns.is_empty() { arm_start = Some((j, ns)); }
                        }
                    } else if tl.starts_with('_') || tl.starts_with("x if") {
                        flush(&mut arm_start, j, &mut arms);
                    }
                }
                j += 1;
            }
            flush(&mut arm_start, j, &mut arms);
        }
        let _ = cur_sig;
    }
    // merge arms sharing a name
    let mut groups: Vec<(BTreeSet<String>, Vec<String>, String, BTreeSet<String>, BTreeSet<String>, String)> = vec![];
    let mut idx: HashMap<String, usize> = HashMap::new();
    for a in &arms {
        let (mut vals, mut flags) = options(&a.body);
        // one level into the implementing function(s)
        let mut doc = String::new();
        let mut k = 0;
        while let Some(p) = a.body[k..].find("self.") {
            let s = k + p + 5;
            let nm: String = a.body[s..].chars().take_while(|c| c.is_alphanumeric() || *c == '_').collect();
            if a.body[s + nm.len()..].starts_with('(') {
                if let Some((b, d)) = fns.get(&nm) {
                    if !nm.ends_with("_cmd") && nm != "cmd" && nm != "eval" {
                        let (v2, f2) = options(b);
                        vals.extend(v2);
                        flags.extend(f2);
                        if doc.is_empty() && !d.is_empty() { doc = d.clone(); }
                    }
                }
            }
            k = s;
        }
        for v in &vals { flags.remove(v); }
        let hit = a.names.iter().find_map(|n| idx.get(n).copied());
        match hit {
            Some(g) => {
                for n in &a.names { if groups[g].0.insert(n.clone()) { groups[g].1.push(n.clone()); } idx.insert(n.clone(), g); }
                groups[g].3.extend(vals);
                groups[g].4.extend(flags);
                if groups[g].5.is_empty() { groups[g].5 = doc; }
            }
            None => {
                let g = groups.len();
                for n in &a.names { idx.insert(n.clone(), g); }
                groups.push((a.names.iter().cloned().collect(), a.names.clone(), a.module.clone(), vals, flags, doc));
            }
        }
    }
    // stable order by primary name
    let mut by: BTreeMap<String, usize> = BTreeMap::new();
    for (i, g) in groups.iter().enumerate() { by.insert(g.1[0].clone(), i); }
    let q = |s: &str| format!("{:?}", s);
    let mut o = String::from("pub static CMD_REGISTRY: &[(&[&str], &str, &[&str], &[&str], &str)] = &[\n");
    for (_, i) in by {
        let g = &groups[i];
        let _ = writeln!(o, "    (&[{}], {}, &[{}], &[{}], {}),",
            g.1.iter().map(|s| q(s)).collect::<Vec<_>>().join(", "), q(&g.2),
            g.3.iter().map(|s| q(s)).collect::<Vec<_>>().join(", "),
            g.4.iter().map(|s| q(s)).collect::<Vec<_>>().join(", "), q(&g.5));
    }
    o.push_str("];\n");
    let out = std::path::Path::new(&std::env::var("OUT_DIR").unwrap()).join("cmdreg.rs");
    std::fs::write(out, o).unwrap();
}
