# R14N7 9-track PDK  (synthetic 7nm-class FinFET, predictive, NOT for manufacturing)

Library prefix: `r14n7t9` -- source `flows/setup/r14n7_env.sh $PWD` to start.

Start with: `doc/r14n7t9_databook.pdf` (cells, characterization, tech & P&R grid spec, DFT, sizing, verification),
`doc/technology_and_grid.md`, `doc/methodology.md`, `dft/README.md`, `doc/verify_report.txt`.

Views: Verilog, Liberty (NLDM+LVF / CCS / ECSM x 12 corners x 4 Vt), AOCV/POCV, SPICE+CDL (BSIM-CMG lib),
LEF + techLEF, GDS, Calibre DRC/LVS/ERC/density/antenna SVRF, Tessent/TestMAX ATPG models, MBIST/LBIST RTL,
IO BSDL fragments, mask-ROM programmer (flows/rom/rom_program.sh).
Regenerate everything: `R14_TRACKS=9 python3 gen/build.py --out <dir>`.
Device cards derived from ASAP7 (BSD-3, see models/spice/LICENSE.ASAP7).
