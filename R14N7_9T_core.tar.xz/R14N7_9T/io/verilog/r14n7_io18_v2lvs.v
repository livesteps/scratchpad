// R14N7 synthetic 7nm-class FinFET PDK v1.0.0 (9-track variant) -- PREDICTIVE, NOT SILICON-CALIBRATED, NOT FOR MANUFACTURING
module PBIDIR18 (PAD, I, OEN, IE, PU, PD, DS0, DS1, ST, C, VDD, VSS, IOVDD, IOVSS);
  inout PAD;
  input I;
  input OEN;
  input IE;
  input PU;
  input PD;
  input DS0;
  input DS1;
  input ST;
  output C;
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PIN18 (PAD, IE, PU, PD, ST, C, VDD, VSS, IOVDD, IOVSS);
  input PAD;
  input IE;
  input PU;
  input PD;
  input ST;
  output C;
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module POUT18 (PAD, I, OEN, DS0, DS1, VDD, VSS, IOVDD, IOVSS);
  output PAD;
  input I;
  input OEN;
  input DS0;
  input DS1;
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PANA18 (PAD, ANA, VDD, VSS, IOVDD, IOVSS);
  inout PAD;
  inout ANA;
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PADVDD (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PADVSS (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PADIOVDD (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PADIOVSS (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PGPIO18MUX4BS (PAD, I0, I1, I2, I3, OEN0, OEN1, OEN2, OEN3, SEL0, SEL1, DS0, DS1, IE, PU, PD, ST, C, BSI, SHIFTDR, CLOCKDR, UPDATEDR, MODE, BSO, VDD, VSS, IOVDD, IOVSS);
  inout PAD;
  input I0;
  input I1;
  input I2;
  input I3;
  input OEN0;
  input OEN1;
  input OEN2;
  input OEN3;
  input SEL0;
  input SEL1;
  input DS0;
  input DS1;
  input IE;
  input PU;
  input PD;
  input ST;
  output C;
  input BSI;
  input SHIFTDR;
  input CLOCKDR;
  input UPDATEDR;
  input MODE;
  output BSO;
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PBIDIR18BS (PAD, I0, OEN0, DS0, DS1, IE, PU, PD, ST, C, BSI, SHIFTDR, CLOCKDR, UPDATEDR, MODE, BSO, VDD, VSS, IOVDD, IOVSS);
  inout PAD;
  input I0;
  input OEN0;
  input DS0;
  input DS1;
  input IE;
  input PU;
  input PD;
  input ST;
  output C;
  input BSI;
  input SHIFTDR;
  input CLOCKDR;
  input UPDATEDR;
  input MODE;
  output BSO;
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PIN18BS (PAD, IE, PU, PD, ST, C, BSI, SHIFTDR, CLOCKDR, UPDATEDR, MODE, BSO, VDD, VSS, IOVDD, IOVSS);
  input PAD;
  input IE;
  input PU;
  input PD;
  input ST;
  output C;
  input BSI;
  input SHIFTDR;
  input CLOCKDR;
  input UPDATEDR;
  input MODE;
  output BSO;
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PCLAMPVDD (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PCLAMPIOVDD (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PPOC (POC, VDD, VSS, IOVDD, IOVSS);
  output POC;
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PFILL1 (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PFILL2 (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PFILL5 (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PFILL10 (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PFILL20 (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PBRK (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module PCORNER (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module BONDPAD60 (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
module BONDPAD60STG (VDD, VSS, IOVDD, IOVSS);
  inout VDD, VSS, IOVDD, IOVSS;
endmodule
