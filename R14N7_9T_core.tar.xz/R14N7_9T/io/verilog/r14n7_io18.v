// R14N7 synthetic 7nm-class FinFET PDK v1.0.0 (9-track variant) -- PREDICTIVE, NOT SILICON-CALIBRATED, NOT FOR MANUFACTURING
`timescale 1ps/1fs
`celldefine
module PBIDIR18 (PAD, I, OEN, IE, PU, PD, DS0, DS1, ST, C
`ifdef R14_PG_PINS
  , VDD, VSS, IOVDD, IOVSS
`endif
);
  inout PAD;
  input I;
  input OEN;
  input IE;
  input PU;
  input PD;
  input DS0;
  input DS1;
  input ST;
  output C;
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
  bufif0 (PAD, I, OEN);
  assign (pull1, pull0) PAD = (PU & ~PD) ? 1'b1 : ((PD & ~PU) ? 1'b0 : 1'bz);
  assign C = IE ? PAD : 1'b0;
  specify
    (I => PAD) = (0, 0);
    (OEN => PAD) = (0, 0);
    (OEN => PAD) = (0, 0);
    (PAD => C) = (0, 0);
    (IE => C) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module PIN18 (PAD, IE, PU, PD, ST, C
`ifdef R14_PG_PINS
  , VDD, VSS, IOVDD, IOVSS
`endif
);
  input PAD;
  input IE;
  input PU;
  input PD;
  input ST;
  output C;
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
  assign C = IE ? PAD : 1'b0;
  specify
    (PAD => C) = (0, 0);
    (IE => C) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module POUT18 (PAD, I, OEN, DS0, DS1
`ifdef R14_PG_PINS
  , VDD, VSS, IOVDD, IOVSS
`endif
);
  output PAD;
  input I;
  input OEN;
  input DS0;
  input DS1;
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
  bufif0 (PAD, I, OEN);
  specify
    (I => PAD) = (0, 0);
    (OEN => PAD) = (0, 0);
    (OEN => PAD) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module PANA18 (PAD, ANA
`ifdef R14_PG_PINS
  , VDD, VSS, IOVDD, IOVSS
`endif
);
  inout PAD;
  inout ANA;
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
  tran (PAD, ANA);
endmodule
`endcelldefine

`celldefine
module PADVDD (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PADVSS (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PADIOVDD (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PADIOVSS (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PGPIO18MUX4BS (PAD, I0, I1, I2, I3, OEN0, OEN1, OEN2, OEN3, SEL0, SEL1, DS0, DS1, IE, PU, PD, ST, C, BSI, SHIFTDR, CLOCKDR, UPDATEDR, MODE, BSO
`ifdef R14_PG_PINS
  , VDD, VSS, IOVDD, IOVSS
`endif
);
  inout PAD;
  input I0;
  input I1;
  input I2;
  input I3;
  input OEN0;
  input OEN1;
  input OEN2;
  input OEN3;
  input SEL0;
  input SEL1;
  input DS0;
  input DS1;
  input IE;
  input PU;
  input PD;
  input ST;
  output C;
  input BSI;
  input SHIFTDR;
  input CLOCKDR;
  input UPDATEDR;
  input MODE;
  output BSO;
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
  bufif0 (PAD, I, OEN);
  assign (pull1, pull0) PAD = (PU & ~PD) ? 1'b1 : ((PD & ~PU) ? 1'b0 : 1'bz);
  assign C = IE ? PAD : 1'b0;
  reg BS_IN, BS_OE, BS_OUT, UP_OE, UP_OUT;
  wire [1:0] sel = {SEL1, SEL0};
  wire im = sel == 2'd0 ? I0 : sel == 2'd1 ? I1 : sel == 2'd2 ? I2 : I3;
  wire om = sel == 2'd0 ? OEN0 : sel == 2'd1 ? OEN1 : sel == 2'd2 ? OEN2 : OEN3;
  wire pi = MODE ? UP_OUT : im;
  wire po = MODE ? UP_OE : om;
  bufif0 (PAD, pi, po);
  assign (pull1, pull0) PAD = (PU & ~PD) ? 1'b1 : ((PD & ~PU) ? 1'b0 : 1'bz);
  always @(posedge CLOCKDR) begin BS_IN <= SHIFTDR ? BSI : PAD; BS_OE <= SHIFTDR ? BS_IN : om; BS_OUT <= SHIFTDR ? BS_OE : im; end
  always @(posedge UPDATEDR) begin UP_OE <= BS_OE; UP_OUT <= BS_OUT; end
  assign BSO = BS_OUT;
  assign C = IE ? PAD : 1'b0;
endmodule
`endcelldefine

`celldefine
module PBIDIR18BS (PAD, I0, OEN0, DS0, DS1, IE, PU, PD, ST, C, BSI, SHIFTDR, CLOCKDR, UPDATEDR, MODE, BSO
`ifdef R14_PG_PINS
  , VDD, VSS, IOVDD, IOVSS
`endif
);
  inout PAD;
  input I0;
  input OEN0;
  input DS0;
  input DS1;
  input IE;
  input PU;
  input PD;
  input ST;
  output C;
  input BSI;
  input SHIFTDR;
  input CLOCKDR;
  input UPDATEDR;
  input MODE;
  output BSO;
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
  bufif0 (PAD, I, OEN);
  assign (pull1, pull0) PAD = (PU & ~PD) ? 1'b1 : ((PD & ~PU) ? 1'b0 : 1'bz);
  assign C = IE ? PAD : 1'b0;
  reg BS_IN, BS_OE, BS_OUT, UP_OE, UP_OUT;
  wire im = I0;
  wire om = OEN0;
  wire pi = MODE ? UP_OUT : im;
  wire po = MODE ? UP_OE : om;
  bufif0 (PAD, pi, po);
  assign (pull1, pull0) PAD = (PU & ~PD) ? 1'b1 : ((PD & ~PU) ? 1'b0 : 1'bz);
  always @(posedge CLOCKDR) begin BS_IN <= SHIFTDR ? BSI : PAD; BS_OE <= SHIFTDR ? BS_IN : om; BS_OUT <= SHIFTDR ? BS_OE : im; end
  always @(posedge UPDATEDR) begin UP_OE <= BS_OE; UP_OUT <= BS_OUT; end
  assign BSO = BS_OUT;
  assign C = IE ? PAD : 1'b0;
endmodule
`endcelldefine

`celldefine
module PIN18BS (PAD, IE, PU, PD, ST, C, BSI, SHIFTDR, CLOCKDR, UPDATEDR, MODE, BSO
`ifdef R14_PG_PINS
  , VDD, VSS, IOVDD, IOVSS
`endif
);
  input PAD;
  input IE;
  input PU;
  input PD;
  input ST;
  output C;
  input BSI;
  input SHIFTDR;
  input CLOCKDR;
  input UPDATEDR;
  input MODE;
  output BSO;
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
  assign C = IE ? PAD : 1'b0;
  reg BS_IN, BS_OE, BS_OUT, UP_OE, UP_OUT;
  always @(posedge CLOCKDR) BS_IN <= SHIFTDR ? BSI : PAD;
  assign BSO = BS_IN;
  assign C = IE ? PAD : 1'b0;
endmodule
`endcelldefine

`celldefine
module PCLAMPVDD (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PCLAMPIOVDD (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PPOC (POC
`ifdef R14_PG_PINS
  , VDD, VSS, IOVDD, IOVSS
`endif
);
  output POC;
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
  assign POC = 1'b0;
endmodule
`endcelldefine

`celldefine
module PFILL1 (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PFILL2 (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PFILL5 (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PFILL10 (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PFILL20 (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PBRK (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module PCORNER (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module BONDPAD60 (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine

`celldefine
module BONDPAD60STG (
`ifdef R14_PG_PINS
  VDD, VSS, IOVDD, IOVSS
`endif
);
`ifdef R14_PG_PINS
  inout VDD, VSS, IOVDD, IOVSS;
`endif
endmodule
`endcelldefine
