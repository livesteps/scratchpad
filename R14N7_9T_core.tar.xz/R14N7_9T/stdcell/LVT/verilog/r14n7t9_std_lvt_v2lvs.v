// R14N7 synthetic 7nm-class FinFET PDK v1.0.0 (9-track variant) -- PREDICTIVE, NOT SILICON-CALIBRATED, NOT FOR MANUFACTURING
// Calibre v2lvs interface library: port order == CDL .SUBCKT order (buses expand to <i>),
// power/ground pins explicit.  Use with:  v2lvs -v top.v -l <this> -lsp <cells>.cdl -o top.sp

module INV_X0P5_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module INV_X1_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module INV_X2_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module INV_X3_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module INV_X4_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module INV_X6_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module INV_X8_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module INV_X12_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module INV_X16_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module BUF_X1_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module BUF_X2_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module BUF_X3_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module BUF_X4_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module BUF_X6_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module BUF_X8_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module BUF_X12_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module BUF_X16_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module NAND2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module NOR2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AND2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OR2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module NAND2_X2_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module NOR2_X2_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AND2_X2_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OR2_X2_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module NAND2_X4_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module NOR2_X4_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AND2_X4_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OR2_X4_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module NAND3_X1_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module NOR3_X1_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AND3_X1_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OR3_X1_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module NAND3_X2_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module NOR3_X2_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AND3_X2_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OR3_X2_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module NAND3_X4_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module NOR3_X4_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AND3_X4_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OR3_X4_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module NAND4_X1_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module NOR4_X1_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module AND4_X1_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module OR4_X1_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module NAND4_X2_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module NOR4_X2_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module AND4_X2_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module OR4_X2_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module NAND4_X4_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module NOR4_X4_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module AND4_X4_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module OR4_X4_LVT (A, B, C, D, Y, VDD, VSS);
  input A;
  input B;
  input C;
  input D;
  output Y;
  inout VDD, VSS;
endmodule
module NAND2B_X1_LVT (AN, B, Y, VDD, VSS);
  input AN;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module NOR2B_X1_LVT (AN, B, Y, VDD, VSS);
  input AN;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module NAND2B_X2_LVT (AN, B, Y, VDD, VSS);
  input AN;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module NOR2B_X2_LVT (AN, B, Y, VDD, VSS);
  input AN;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module NAND2B_X4_LVT (AN, B, Y, VDD, VSS);
  input AN;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module NOR2B_X4_LVT (AN, B, Y, VDD, VSS);
  input AN;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module XOR2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module XNOR2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module XOR2_X2_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module XNOR2_X2_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module XOR2_X4_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module XNOR2_X4_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module XOR3_X1_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module XNOR3_X1_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module XOR3_X2_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module XNOR3_X2_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AOI21_X1_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AO21_X1_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OAI21_X1_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OA21_X1_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AOI21_X2_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AO21_X2_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OAI21_X2_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OA21_X2_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AOI21_X4_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AO21_X4_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OAI21_X4_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OA21_X4_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AOI211_X1_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AO211_X1_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OAI211_X1_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OA211_X1_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AOI211_X2_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AO211_X2_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OAI211_X2_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OA211_X2_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AOI211_X4_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AO211_X4_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OAI211_X4_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OA211_X4_LVT (A1, A2, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AOI22_X1_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AO22_X1_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OAI22_X1_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OA22_X1_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AOI22_X2_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AO22_X2_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OAI22_X2_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OA22_X2_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AOI22_X4_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AO22_X4_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OAI22_X4_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OA22_X4_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AOI221_X1_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AO221_X1_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OAI221_X1_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OA221_X1_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AOI221_X2_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AO221_X2_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OAI221_X2_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OA221_X2_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AOI221_X4_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AO221_X4_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OAI221_X4_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OA221_X4_LVT (A1, A2, B1, B2, C, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AOI222_X1_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module AO222_X1_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module OAI222_X1_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module OA222_X1_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module AOI222_X2_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module AO222_X2_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module OAI222_X2_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module OA222_X2_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module AOI222_X4_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module AO222_X4_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module OAI222_X4_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module OA222_X4_LVT (A1, A2, B1, B2, C1, C2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  inout VDD, VSS;
endmodule
module AOI31_X1_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AO31_X1_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OAI31_X1_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OA31_X1_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AOI31_X2_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AO31_X2_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OAI31_X2_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OA31_X2_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AOI31_X4_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AO31_X4_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OAI31_X4_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OA31_X4_LVT (A1, A2, A3, B, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AOI311_X1_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AO311_X1_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OAI311_X1_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OA311_X1_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AOI311_X2_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AO311_X2_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OAI311_X2_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OA311_X2_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AOI311_X4_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AO311_X4_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OAI311_X4_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module OA311_X4_LVT (A1, A2, A3, B, C, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module AOI32_X1_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AO32_X1_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OAI32_X1_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OA32_X1_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AOI32_X2_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AO32_X2_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OAI32_X2_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OA32_X2_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AOI32_X4_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AO32_X4_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OAI32_X4_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OA32_X4_LVT (A1, A2, A3, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AOI33_X1_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module AO33_X1_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module OAI33_X1_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module OA33_X1_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module AOI33_X2_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module AO33_X2_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module OAI33_X2_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module OA33_X2_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module AOI33_X4_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module AO33_X4_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module OAI33_X4_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module OA33_X4_LVT (A1, A2, A3, B1, B2, B3, Y, VDD, VSS);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  inout VDD, VSS;
endmodule
module AOI2BB1_X1_LVT (A1N, A2N, B, Y, VDD, VSS);
  input A1N;
  input A2N;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AOI2BB2_X1_LVT (A1N, A2N, B1, B2, Y, VDD, VSS);
  input A1N;
  input A2N;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OAI2BB1_X1_LVT (A1N, A2N, B, Y, VDD, VSS);
  input A1N;
  input A2N;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OAI2BB2_X1_LVT (A1N, A2N, B1, B2, Y, VDD, VSS);
  input A1N;
  input A2N;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module AOI2BB1_X2_LVT (A1N, A2N, B, Y, VDD, VSS);
  input A1N;
  input A2N;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module AOI2BB2_X2_LVT (A1N, A2N, B1, B2, Y, VDD, VSS);
  input A1N;
  input A2N;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module OAI2BB1_X2_LVT (A1N, A2N, B, Y, VDD, VSS);
  input A1N;
  input A2N;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module OAI2BB2_X2_LVT (A1N, A2N, B1, B2, Y, VDD, VSS);
  input A1N;
  input A2N;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module MUX2_X1_LVT (I0, I1, S, Y, VDD, VSS);
  input I0;
  input I1;
  input S;
  output Y;
  inout VDD, VSS;
endmodule
module MUX2_X2_LVT (I0, I1, S, Y, VDD, VSS);
  input I0;
  input I1;
  input S;
  output Y;
  inout VDD, VSS;
endmodule
module MUX2_X4_LVT (I0, I1, S, Y, VDD, VSS);
  input I0;
  input I1;
  input S;
  output Y;
  inout VDD, VSS;
endmodule
module MXI2_X1_LVT (I0, I1, S, Y, VDD, VSS);
  input I0;
  input I1;
  input S;
  output Y;
  inout VDD, VSS;
endmodule
module MUX4_X1_LVT (I0, I1, I2, I3, S0, S1, Y, VDD, VSS);
  input I0;
  input I1;
  input I2;
  input I3;
  input S0;
  input S1;
  output Y;
  inout VDD, VSS;
endmodule
module MXI2_X2_LVT (I0, I1, S, Y, VDD, VSS);
  input I0;
  input I1;
  input S;
  output Y;
  inout VDD, VSS;
endmodule
module MUX4_X2_LVT (I0, I1, I2, I3, S0, S1, Y, VDD, VSS);
  input I0;
  input I1;
  input I2;
  input I3;
  input S0;
  input S1;
  output Y;
  inout VDD, VSS;
endmodule
module HADD_X1_LVT (A, B, CO, S, VDD, VSS);
  input A;
  input B;
  output CO;
  output S;
  inout VDD, VSS;
endmodule
module FADD_X1_LVT (A, B, CI, CO, S, VDD, VSS);
  input A;
  input B;
  input CI;
  output CO;
  output S;
  inout VDD, VSS;
endmodule
module HADD_X2_LVT (A, B, CO, S, VDD, VSS);
  input A;
  input B;
  output CO;
  output S;
  inout VDD, VSS;
endmodule
module FADD_X2_LVT (A, B, CI, CO, S, VDD, VSS);
  input A;
  input B;
  input CI;
  output CO;
  output S;
  inout VDD, VSS;
endmodule
module HADD_X4_LVT (A, B, CO, S, VDD, VSS);
  input A;
  input B;
  output CO;
  output S;
  inout VDD, VSS;
endmodule
module FADD_X4_LVT (A, B, CI, CO, S, VDD, VSS);
  input A;
  input B;
  input CI;
  output CO;
  output S;
  inout VDD, VSS;
endmodule
module TIEHI_X1_LVT (Y, VDD, VSS);
  output Y;
  inout VDD, VSS;
endmodule
module TIELO_X1_LVT (Y, VDD, VSS);
  output Y;
  inout VDD, VSS;
endmodule
module DLY1_X1_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module DLY2_X1_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module DLY3_X1_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module DLY4_X1_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKINV_X1_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKBUF_X1_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKINV_X2_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKBUF_X2_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKINV_X3_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKBUF_X3_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKINV_X4_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKBUF_X4_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKINV_X6_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKBUF_X6_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKINV_X8_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKBUF_X8_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKINV_X12_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKBUF_X12_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKINV_X16_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKBUF_X16_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKMUX2_X1_LVT (I0, I1, S, Y, VDD, VSS);
  input I0;
  input I1;
  input S;
  output Y;
  inout VDD, VSS;
endmodule
module CKMUX2_X2_LVT (I0, I1, S, Y, VDD, VSS);
  input I0;
  input I1;
  input S;
  output Y;
  inout VDD, VSS;
endmodule
module CKMUX2_X4_LVT (I0, I1, S, Y, VDD, VSS);
  input I0;
  input I1;
  input S;
  output Y;
  inout VDD, VSS;
endmodule
module CKAND2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKNAND2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKOR2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKNOR2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKXOR2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKAND2_X2_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKNAND2_X2_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKOR2_X2_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKNOR2_X2_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKXOR2_X2_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKAND2_X4_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKNAND2_X4_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKOR2_X4_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKNOR2_X4_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKXOR2_X4_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module CKD1_X2_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKD2_X2_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKD3_X2_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKD4_X2_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module CKD5_X2_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module ICGPRE_X1_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGPRE_X2_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGPRE_X4_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGPRE_X8_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGPRE_X16_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGPOST_X1_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGPOST_X2_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGPOST_X4_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGPOST_X8_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGPOST_X16_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGPREOBS_X1_LVT (CK, E, SE, GCK, Q, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
  inout VDD, VSS;
endmodule
module ICGPREOBS_X2_LVT (CK, E, SE, GCK, Q, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
  inout VDD, VSS;
endmodule
module ICGPREOBS_X4_LVT (CK, E, SE, GCK, Q, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
  inout VDD, VSS;
endmodule
module ICGPOSTOBS_X1_LVT (CK, E, SE, GCK, Q, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
  inout VDD, VSS;
endmodule
module ICGPOSTOBS_X2_LVT (CK, E, SE, GCK, Q, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
  inout VDD, VSS;
endmodule
module ICGPOSTOBS_X4_LVT (CK, E, SE, GCK, Q, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
  inout VDD, VSS;
endmodule
module ICGNPRE_X1_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGNPRE_X2_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGNPRE_X4_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGNPOST_X1_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGNPOST_X2_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module ICGNPOST_X4_LVT (CK, E, SE, GCK, VDD, VSS);
  input CK;
  input E;
  input SE;
  output GCK;
  inout VDD, VSS;
endmodule
module DFF_X1_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module DFF_X2_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module DFF_X4_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module DFFQN_X1_LVT (D, CK, Q, QN, VDD, VSS);
  input D;
  input CK;
  output Q;
  output QN;
  inout VDD, VSS;
endmodule
module DFFQN_X2_LVT (D, CK, Q, QN, VDD, VSS);
  input D;
  input CK;
  output Q;
  output QN;
  inout VDD, VSS;
endmodule
module DFFQN_X4_LVT (D, CK, Q, QN, VDD, VSS);
  input D;
  input CK;
  output Q;
  output QN;
  inout VDD, VSS;
endmodule
module DFFN_X1_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module DFFN_X2_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module DFFN_X4_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module DFFR_X1_LVT (D, CK, RN, Q, VDD, VSS);
  input D;
  input CK;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFR_X2_LVT (D, CK, RN, Q, VDD, VSS);
  input D;
  input CK;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFR_X4_LVT (D, CK, RN, Q, VDD, VSS);
  input D;
  input CK;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFRQN_X1_LVT (D, CK, RN, Q, QN, VDD, VSS);
  input D;
  input CK;
  input RN;
  output Q;
  output QN;
  inout VDD, VSS;
endmodule
module DFFRQN_X2_LVT (D, CK, RN, Q, QN, VDD, VSS);
  input D;
  input CK;
  input RN;
  output Q;
  output QN;
  inout VDD, VSS;
endmodule
module DFFRQN_X4_LVT (D, CK, RN, Q, QN, VDD, VSS);
  input D;
  input CK;
  input RN;
  output Q;
  output QN;
  inout VDD, VSS;
endmodule
module DFFS_X1_LVT (D, CK, SN, Q, VDD, VSS);
  input D;
  input CK;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFS_X2_LVT (D, CK, SN, Q, VDD, VSS);
  input D;
  input CK;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFS_X4_LVT (D, CK, SN, Q, VDD, VSS);
  input D;
  input CK;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFRS_X1_LVT (D, CK, RN, SN, Q, VDD, VSS);
  input D;
  input CK;
  input RN;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFRS_X2_LVT (D, CK, RN, SN, Q, VDD, VSS);
  input D;
  input CK;
  input RN;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFRS_X4_LVT (D, CK, RN, SN, Q, VDD, VSS);
  input D;
  input CK;
  input RN;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFNR_X1_LVT (D, CK, RN, Q, VDD, VSS);
  input D;
  input CK;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFNR_X2_LVT (D, CK, RN, Q, VDD, VSS);
  input D;
  input CK;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFNR_X4_LVT (D, CK, RN, Q, VDD, VSS);
  input D;
  input CK;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module DFFSYNR_X1_LVT (D, RN, CK, Q, VDD, VSS);
  input D;
  input RN;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module DFFSYNR_X2_LVT (D, RN, CK, Q, VDD, VSS);
  input D;
  input RN;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module DFFSYNR_X4_LVT (D, RN, CK, Q, VDD, VSS);
  input D;
  input RN;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module EDFF_X1_LVT (D, E, CK, Q, VDD, VSS);
  input D;
  input E;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module EDFF_X2_LVT (D, E, CK, Q, VDD, VSS);
  input D;
  input E;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module EDFF_X4_LVT (D, E, CK, Q, VDD, VSS);
  input D;
  input E;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SDFF_X1_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SDFF_X2_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SDFF_X4_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFQN_X1_LVT (D, SI, SE, CK, Q, QN, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  output QN;
  inout VDD, VSS;
endmodule
module SDFFQN_X2_LVT (D, SI, SE, CK, Q, QN, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  output QN;
  inout VDD, VSS;
endmodule
module SDFFQN_X4_LVT (D, SI, SE, CK, Q, QN, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  output QN;
  inout VDD, VSS;
endmodule
module SDFFN_X1_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFN_X2_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFN_X4_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFR_X1_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFR_X2_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFR_X4_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFS_X1_LVT (D, SI, SE, CK, SN, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFS_X2_LVT (D, SI, SE, CK, SN, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFS_X4_LVT (D, SI, SE, CK, SN, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFRS_X1_LVT (D, SI, SE, CK, RN, SN, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFRS_X2_LVT (D, SI, SE, CK, RN, SN, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFRS_X4_LVT (D, SI, SE, CK, RN, SN, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFSYNR_X1_LVT (D, RN, SI, SE, CK, Q, VDD, VSS);
  input D;
  input RN;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFSYNR_X2_LVT (D, RN, SI, SE, CK, Q, VDD, VSS);
  input D;
  input RN;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SDFFSYNR_X4_LVT (D, RN, SI, SE, CK, Q, VDD, VSS);
  input D;
  input RN;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SEDFF_X1_LVT (D, E, SI, SE, CK, Q, VDD, VSS);
  input D;
  input E;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SEDFF_X2_LVT (D, E, SI, SE, CK, Q, VDD, VSS);
  input D;
  input E;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module SEDFF_X4_LVT (D, E, SI, SE, CK, Q, VDD, VSS);
  input D;
  input E;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module LATCH_X1_LVT (D, E, Q, VDD, VSS);
  input D;
  input E;
  output Q;
  inout VDD, VSS;
endmodule
module LATCH_X2_LVT (D, E, Q, VDD, VSS);
  input D;
  input E;
  output Q;
  inout VDD, VSS;
endmodule
module LATCH_X4_LVT (D, E, Q, VDD, VSS);
  input D;
  input E;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHN_X1_LVT (D, EN, Q, VDD, VSS);
  input D;
  input EN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHN_X2_LVT (D, EN, Q, VDD, VSS);
  input D;
  input EN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHN_X4_LVT (D, EN, Q, VDD, VSS);
  input D;
  input EN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHR_X1_LVT (D, E, RN, Q, VDD, VSS);
  input D;
  input E;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHR_X2_LVT (D, E, RN, Q, VDD, VSS);
  input D;
  input E;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHR_X4_LVT (D, E, RN, Q, VDD, VSS);
  input D;
  input E;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHS_X1_LVT (D, E, SN, Q, VDD, VSS);
  input D;
  input E;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHS_X2_LVT (D, E, SN, Q, VDD, VSS);
  input D;
  input E;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHS_X4_LVT (D, E, SN, Q, VDD, VSS);
  input D;
  input E;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHRS_X1_LVT (D, E, RN, SN, Q, VDD, VSS);
  input D;
  input E;
  input RN;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHRS_X2_LVT (D, E, RN, SN, Q, VDD, VSS);
  input D;
  input E;
  input RN;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHRS_X4_LVT (D, E, RN, SN, Q, VDD, VSS);
  input D;
  input E;
  input RN;
  input SN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHNR_X1_LVT (D, EN, RN, Q, VDD, VSS);
  input D;
  input EN;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHNR_X2_LVT (D, EN, RN, Q, VDD, VSS);
  input D;
  input EN;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module LATCHNR_X4_LVT (D, EN, RN, Q, VDD, VSS);
  input D;
  input EN;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module MBDFF2_X1_LVT (D, CK, Q, VDD, VSS);
  input [1:0] D;
  input CK;
  output [1:0] Q;
  inout VDD, VSS;
endmodule
module MBDFF2_X2_LVT (D, CK, Q, VDD, VSS);
  input [1:0] D;
  input CK;
  output [1:0] Q;
  inout VDD, VSS;
endmodule
module MBDFF4_X1_LVT (D, CK, Q, VDD, VSS);
  input [3:0] D;
  input CK;
  output [3:0] Q;
  inout VDD, VSS;
endmodule
module MBDFF4_X2_LVT (D, CK, Q, VDD, VSS);
  input [3:0] D;
  input CK;
  output [3:0] Q;
  inout VDD, VSS;
endmodule
module MBDFF8_X1_LVT (D, CK, Q, VDD, VSS);
  input [7:0] D;
  input CK;
  output [7:0] Q;
  inout VDD, VSS;
endmodule
module MBDFF8_X2_LVT (D, CK, Q, VDD, VSS);
  input [7:0] D;
  input CK;
  output [7:0] Q;
  inout VDD, VSS;
endmodule
module MBDFF16_X1_LVT (D, CK, Q, VDD, VSS);
  input [15:0] D;
  input CK;
  output [15:0] Q;
  inout VDD, VSS;
endmodule
module MBDFF16_X2_LVT (D, CK, Q, VDD, VSS);
  input [15:0] D;
  input CK;
  output [15:0] Q;
  inout VDD, VSS;
endmodule
module MBDFF32_X1_LVT (D, CK, Q, VDD, VSS);
  input [31:0] D;
  input CK;
  output [31:0] Q;
  inout VDD, VSS;
endmodule
module MBDFF32_X2_LVT (D, CK, Q, VDD, VSS);
  input [31:0] D;
  input CK;
  output [31:0] Q;
  inout VDD, VSS;
endmodule
module MBDFFR2_X1_LVT (D, CK, RN, Q, VDD, VSS);
  input [1:0] D;
  input CK;
  input RN;
  output [1:0] Q;
  inout VDD, VSS;
endmodule
module MBDFFR2_X2_LVT (D, CK, RN, Q, VDD, VSS);
  input [1:0] D;
  input CK;
  input RN;
  output [1:0] Q;
  inout VDD, VSS;
endmodule
module MBDFFR4_X1_LVT (D, CK, RN, Q, VDD, VSS);
  input [3:0] D;
  input CK;
  input RN;
  output [3:0] Q;
  inout VDD, VSS;
endmodule
module MBDFFR4_X2_LVT (D, CK, RN, Q, VDD, VSS);
  input [3:0] D;
  input CK;
  input RN;
  output [3:0] Q;
  inout VDD, VSS;
endmodule
module MBDFFR8_X1_LVT (D, CK, RN, Q, VDD, VSS);
  input [7:0] D;
  input CK;
  input RN;
  output [7:0] Q;
  inout VDD, VSS;
endmodule
module MBDFFR8_X2_LVT (D, CK, RN, Q, VDD, VSS);
  input [7:0] D;
  input CK;
  input RN;
  output [7:0] Q;
  inout VDD, VSS;
endmodule
module MBDFFR16_X1_LVT (D, CK, RN, Q, VDD, VSS);
  input [15:0] D;
  input CK;
  input RN;
  output [15:0] Q;
  inout VDD, VSS;
endmodule
module MBDFFR16_X2_LVT (D, CK, RN, Q, VDD, VSS);
  input [15:0] D;
  input CK;
  input RN;
  output [15:0] Q;
  inout VDD, VSS;
endmodule
module MBDFFR32_X1_LVT (D, CK, RN, Q, VDD, VSS);
  input [31:0] D;
  input CK;
  input RN;
  output [31:0] Q;
  inout VDD, VSS;
endmodule
module MBDFFR32_X2_LVT (D, CK, RN, Q, VDD, VSS);
  input [31:0] D;
  input CK;
  input RN;
  output [31:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFF2_X1_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input [1:0] D;
  input [1:0] SI;
  input SE;
  input CK;
  output [1:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFF2_X2_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input [1:0] D;
  input [1:0] SI;
  input SE;
  input CK;
  output [1:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFF4_X1_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input [3:0] D;
  input [3:0] SI;
  input SE;
  input CK;
  output [3:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFF4_X2_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input [3:0] D;
  input [3:0] SI;
  input SE;
  input CK;
  output [3:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFF8_X1_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input [7:0] D;
  input [7:0] SI;
  input SE;
  input CK;
  output [7:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFF8_X2_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input [7:0] D;
  input [7:0] SI;
  input SE;
  input CK;
  output [7:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFF16_X1_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input [15:0] D;
  input [15:0] SI;
  input SE;
  input CK;
  output [15:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFF16_X2_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input [15:0] D;
  input [15:0] SI;
  input SE;
  input CK;
  output [15:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFF32_X1_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input [31:0] D;
  input [31:0] SI;
  input SE;
  input CK;
  output [31:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFF32_X2_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input [31:0] D;
  input [31:0] SI;
  input SE;
  input CK;
  output [31:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFFR2_X1_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input [1:0] D;
  input [1:0] SI;
  input SE;
  input CK;
  input RN;
  output [1:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFFR2_X2_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input [1:0] D;
  input [1:0] SI;
  input SE;
  input CK;
  input RN;
  output [1:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFFR4_X1_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input [3:0] D;
  input [3:0] SI;
  input SE;
  input CK;
  input RN;
  output [3:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFFR4_X2_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input [3:0] D;
  input [3:0] SI;
  input SE;
  input CK;
  input RN;
  output [3:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFFR8_X1_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input [7:0] D;
  input [7:0] SI;
  input SE;
  input CK;
  input RN;
  output [7:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFFR8_X2_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input [7:0] D;
  input [7:0] SI;
  input SE;
  input CK;
  input RN;
  output [7:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFFR16_X1_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input [15:0] D;
  input [15:0] SI;
  input SE;
  input CK;
  input RN;
  output [15:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFFR16_X2_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input [15:0] D;
  input [15:0] SI;
  input SE;
  input CK;
  input RN;
  output [15:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFFR32_X1_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input [31:0] D;
  input [31:0] SI;
  input SE;
  input CK;
  input RN;
  output [31:0] Q;
  inout VDD, VSS;
endmodule
module MBSDFFR32_X2_LVT (D, SI, SE, CK, RN, Q, VDD, VSS);
  input [31:0] D;
  input [31:0] SI;
  input SE;
  input CK;
  input RN;
  output [31:0] Q;
  inout VDD, VSS;
endmodule
module LOCKUP_X1_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module LOCKUPP_X1_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module LOCKUP_X2_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module LOCKUPP_X2_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module LOCKUP_X4_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module LOCKUPP_X4_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module TPOBS_X1_LVT (A, SI, SE, CK, SO, VDD, VSS);
  input A;
  input SI;
  input SE;
  input CK;
  output SO;
  inout VDD, VSS;
endmodule
module TPCTL0_X1_LVT (A, TE, SI, SE, CK, Y, SO, VDD, VSS);
  input A;
  input TE;
  input SI;
  input SE;
  input CK;
  output Y;
  output SO;
  inout VDD, VSS;
endmodule
module TPCTL1_X1_LVT (A, TE, SI, SE, CK, Y, SO, VDD, VSS);
  input A;
  input TE;
  input SI;
  input SE;
  input CK;
  output Y;
  output SO;
  inout VDD, VSS;
endmodule
module WBRCELL_X1_LVT (CFI, WSI, SHIFTWR, CAPTUREWR, WRCK, UPDATEWR, WMODE, CFO, WSO, VDD, VSS);
  input CFI;
  input WSI;
  input SHIFTWR;
  input CAPTUREWR;
  input WRCK;
  input UPDATEWR;
  input WMODE;
  output CFO;
  output WSO;
  inout VDD, VSS;
endmodule
module BSCELL_X1_LVT (PI, TDI, SHIFTDR, CLOCKDR, UPDATEDR, MODE, PO, TDO, VDD, VSS);
  input PI;
  input TDI;
  input SHIFTDR;
  input CLOCKDR;
  input UPDATEDR;
  input MODE;
  output PO;
  output TDO;
  inout VDD, VSS;
endmodule
module TPOBS_X2_LVT (A, SI, SE, CK, SO, VDD, VSS);
  input A;
  input SI;
  input SE;
  input CK;
  output SO;
  inout VDD, VSS;
endmodule
module TPCTL0_X2_LVT (A, TE, SI, SE, CK, Y, SO, VDD, VSS);
  input A;
  input TE;
  input SI;
  input SE;
  input CK;
  output Y;
  output SO;
  inout VDD, VSS;
endmodule
module TPCTL1_X2_LVT (A, TE, SI, SE, CK, Y, SO, VDD, VSS);
  input A;
  input TE;
  input SI;
  input SE;
  input CK;
  output Y;
  output SO;
  inout VDD, VSS;
endmodule
module WBRCELL_X2_LVT (CFI, WSI, SHIFTWR, CAPTUREWR, WRCK, UPDATEWR, WMODE, CFO, WSO, VDD, VSS);
  input CFI;
  input WSI;
  input SHIFTWR;
  input CAPTUREWR;
  input WRCK;
  input UPDATEWR;
  input WMODE;
  output CFO;
  output WSO;
  inout VDD, VSS;
endmodule
module BSCELL_X2_LVT (PI, TDI, SHIFTDR, CLOCKDR, UPDATEDR, MODE, PO, TDO, VDD, VSS);
  input PI;
  input TDI;
  input SHIFTDR;
  input CLOCKDR;
  input UPDATEDR;
  input MODE;
  output PO;
  output TDO;
  inout VDD, VSS;
endmodule
module GFILL1_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module GFILL2_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module GFILL4_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module GFILL8_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module GFILL16_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module GDCAP1_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module GDCAP2_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module GDCAP4_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module GINV_X1_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module GBUF_X1_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module GNAND2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module GNOR2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module GAND2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module GOR2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module GXOR2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module GXNOR2_X1_LVT (A, B, Y, VDD, VSS);
  input A;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module GMUX2_X1_LVT (I0, I1, S, Y, VDD, VSS);
  input I0;
  input I1;
  input S;
  output Y;
  inout VDD, VSS;
endmodule
module GAOI21_X1_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module GOAI21_X1_LVT (A1, A2, B, Y, VDD, VSS);
  input A1;
  input A2;
  input B;
  output Y;
  inout VDD, VSS;
endmodule
module GAOI22_X1_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module GOAI22_X1_LVT (A1, A2, B1, B2, Y, VDD, VSS);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  inout VDD, VSS;
endmodule
module GNAND3_X1_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module GNOR3_X1_LVT (A, B, C, Y, VDD, VSS);
  input A;
  input B;
  input C;
  output Y;
  inout VDD, VSS;
endmodule
module GHADD_X1_LVT (A, B, CO, S, VDD, VSS);
  input A;
  input B;
  output CO;
  output S;
  inout VDD, VSS;
endmodule
module GFADD_X1_LVT (A, B, CI, CO, S, VDD, VSS);
  input A;
  input B;
  input CI;
  output CO;
  output S;
  inout VDD, VSS;
endmodule
module GDFF_X1_LVT (D, CK, Q, VDD, VSS);
  input D;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module GDFFR_X1_LVT (D, CK, RN, Q, VDD, VSS);
  input D;
  input CK;
  input RN;
  output Q;
  inout VDD, VSS;
endmodule
module GSDFF_X1_LVT (D, SI, SE, CK, Q, VDD, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  inout VDD, VSS;
endmodule
module GLATCH_X1_LVT (D, E, Q, VDD, VSS);
  input D;
  input E;
  output Q;
  inout VDD, VSS;
endmodule
module GTIEHI_X1_LVT (Y, VDD, VSS);
  output Y;
  inout VDD, VSS;
endmodule
module GTIELO_X1_LVT (Y, VDD, VSS);
  output Y;
  inout VDD, VSS;
endmodule
module GDLY_X1_LVT (A, Y, VDD, VSS);
  input A;
  output Y;
  inout VDD, VSS;
endmodule
module FILL1_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module FILL2_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module FILL4_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module FILL8_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module FILL16_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module FILL32_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module FILL64_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module DCAP4_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module DCAP8_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module DCAP16_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module DCAP32_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module DCAP64_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module WELLTAP_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module WELLTAPDH_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPLEFT_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPRIGHT_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPTOP1_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPBOTTOM1_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPTOP2_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPBOTTOM2_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPTOP4_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPBOTTOM4_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPTL_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPTR_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPBL_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ENDCAPBR_X1_LVT (VDD, VSS);
  inout VDD, VSS;
endmodule
module ANTENNA_X1_LVT (A, VDD, VSS);
  input A;
  inout VDD, VSS;
endmodule
