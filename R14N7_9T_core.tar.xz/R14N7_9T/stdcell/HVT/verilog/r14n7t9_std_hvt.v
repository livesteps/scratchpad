// R14N7 synthetic 7nm-class FinFET PDK v1.0.0 (9-track variant) -- PREDICTIVE, NOT SILICON-CALIBRATED, NOT FOR MANUFACTURING
// std HVT library
`timescale 1ps/1fs

`celldefine
module INV_X0P5_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module INV_X1_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module INV_X2_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module INV_X3_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module INV_X4_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module INV_X6_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module INV_X8_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module INV_X12_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module INV_X16_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module BUF_X1_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module BUF_X2_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module BUF_X3_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module BUF_X4_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module BUF_X6_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module BUF_X8_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module BUF_X12_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module BUF_X16_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AND2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OR2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND2_X2_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR2_X2_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AND2_X2_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OR2_X2_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND2_X4_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR2_X4_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AND2_X4_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OR2_X4_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND3_X1_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A & B) & C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR3_X1_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A | B) | C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AND3_X1_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A & B) & C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OR3_X1_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A | B) | C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND3_X2_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A & B) & C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR3_X2_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A | B) | C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AND3_X2_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A & B) & C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OR3_X2_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A | B) | C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND3_X4_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A & B) & C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR3_X4_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A | B) | C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AND3_X4_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A & B) & C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OR3_X4_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A | B) | C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND4_X1_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A & B) & C) & D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR4_X1_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A | B) | C) | D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AND4_X1_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A & B) & C) & D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OR4_X1_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A | B) | C) | D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND4_X2_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A & B) & C) & D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR4_X2_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A | B) | C) | D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AND4_X2_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A & B) & C) & D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OR4_X2_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A | B) | C) | D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND4_X4_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A & B) & C) & D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR4_X4_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A | B) | C) | D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AND4_X4_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A & B) & C) & D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OR4_X4_HVT (A, B, C, D, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  input D;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A | B) | C) | D);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
    (D => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND2B_X1_HVT (AN, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input AN;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(~AN & B);
  specify
    (AN => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR2B_X1_HVT (AN, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input AN;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(~AN | B);
  specify
    (AN => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND2B_X2_HVT (AN, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input AN;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(~AN & B);
  specify
    (AN => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR2B_X2_HVT (AN, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input AN;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(~AN | B);
  specify
    (AN => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NAND2B_X4_HVT (AN, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input AN;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(~AN & B);
  specify
    (AN => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module NOR2B_X4_HVT (AN, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input AN;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(~AN | B);
  specify
    (AN => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module XOR2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A ^ B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module XNOR2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A ^ B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module XOR2_X2_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A ^ B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module XNOR2_X2_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A ^ B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module XOR2_X4_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A ^ B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module XNOR2_X4_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A ^ B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module XOR3_X1_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A ^ B) ^ C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module XNOR3_X1_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A ^ B) ^ C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module XOR3_X2_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A ^ B) ^ C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module XNOR3_X2_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A ^ B) ^ C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI21_X1_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 & A2) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO21_X1_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 & A2) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI21_X1_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 | A2) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA21_X1_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 | A2) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI21_X2_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 & A2) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO21_X2_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 & A2) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI21_X2_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 | A2) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA21_X2_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 | A2) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI21_X4_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 & A2) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO21_X4_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 & A2) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI21_X4_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 | A2) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA21_X4_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 | A2) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI211_X1_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO211_X1_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI211_X1_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA211_X1_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI211_X2_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO211_X2_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI211_X2_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA211_X2_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI211_X4_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO211_X4_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI211_X4_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA211_X4_HVT (A1, A2, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI22_X1_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 & A2) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO22_X1_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 & A2) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI22_X1_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 | A2) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA22_X1_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 | A2) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI22_X2_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 & A2) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO22_X2_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 & A2) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI22_X2_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 | A2) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA22_X2_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 | A2) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI22_X4_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 & A2) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO22_X4_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 & A2) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI22_X4_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 | A2) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA22_X4_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((A1 | A2) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI221_X1_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) | (B1 & B2)) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO221_X1_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) | (B1 & B2)) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI221_X1_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) & (B1 | B2)) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA221_X1_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) & (B1 | B2)) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI221_X2_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) | (B1 & B2)) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO221_X2_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) | (B1 & B2)) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI221_X2_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) & (B1 | B2)) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA221_X2_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) & (B1 | B2)) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI221_X4_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) | (B1 & B2)) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO221_X4_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) | (B1 & B2)) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI221_X4_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) & (B1 | B2)) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA221_X4_HVT (A1, A2, B1, B2, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) & (B1 | B2)) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI222_X1_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) | (B1 & B2)) | (C1 & C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO222_X1_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) | (B1 & B2)) | (C1 & C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI222_X1_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) & (B1 | B2)) & (C1 | C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA222_X1_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) & (B1 | B2)) & (C1 | C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI222_X2_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) | (B1 & B2)) | (C1 & C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO222_X2_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) | (B1 & B2)) | (C1 & C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI222_X2_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) & (B1 | B2)) & (C1 | C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA222_X2_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) & (B1 | B2)) & (C1 | C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI222_X4_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) | (B1 & B2)) | (C1 & C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO222_X4_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) | (B1 & B2)) | (C1 & C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI222_X4_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) & (B1 | B2)) & (C1 | C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA222_X4_HVT (A1, A2, B1, B2, C1, C2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) & (B1 | B2)) & (C1 | C2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (C1 => Y) = (0, 0);
    (C2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI31_X1_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) & A3) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO31_X1_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) & A3) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI31_X1_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) | A3) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA31_X1_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) | A3) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI31_X2_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) & A3) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO31_X2_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) & A3) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI31_X2_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) | A3) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA31_X2_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) | A3) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI31_X4_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) & A3) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO31_X4_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) & A3) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI31_X4_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) | A3) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA31_X4_HVT (A1, A2, A3, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) | A3) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI311_X1_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((((A1 & A2) & A3) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO311_X1_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((((A1 & A2) & A3) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI311_X1_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((((A1 | A2) | A3) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA311_X1_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((((A1 | A2) | A3) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI311_X2_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((((A1 & A2) & A3) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO311_X2_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((((A1 & A2) & A3) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI311_X2_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((((A1 | A2) | A3) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA311_X2_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((((A1 | A2) | A3) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI311_X4_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((((A1 & A2) & A3) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO311_X4_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((((A1 & A2) & A3) | B) | C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI311_X4_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((((A1 | A2) | A3) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA311_X4_HVT (A1, A2, A3, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((((A1 | A2) | A3) & B) & C);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI32_X1_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) & A3) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO32_X1_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) & A3) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI32_X1_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) | A3) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA32_X1_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) | A3) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI32_X2_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) & A3) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO32_X2_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) & A3) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI32_X2_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) | A3) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA32_X2_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) | A3) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI32_X4_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) & A3) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO32_X4_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) & A3) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI32_X4_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) | A3) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA32_X4_HVT (A1, A2, A3, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) | A3) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI33_X1_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) & A3) | ((B1 & B2) & B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO33_X1_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) & A3) | ((B1 & B2) & B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI33_X1_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) | A3) & ((B1 | B2) | B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA33_X1_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) | A3) & ((B1 | B2) | B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI33_X2_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) & A3) | ((B1 & B2) & B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO33_X2_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) & A3) | ((B1 & B2) & B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI33_X2_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) | A3) & ((B1 | B2) | B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA33_X2_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) | A3) & ((B1 | B2) | B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI33_X4_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 & A2) & A3) | ((B1 & B2) & B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AO33_X4_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 & A2) & A3) | ((B1 & B2) & B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI33_X4_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(((A1 | A2) | A3) & ((B1 | B2) | B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OA33_X4_HVT (A1, A2, A3, B1, B2, B3, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((A1 | A2) | A3) & ((B1 | B2) | B3));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (A3 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
    (B3 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI2BB1_X1_HVT (A1N, A2N, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1N;
  input A2N;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((~A1N & ~A2N) | B);
  specify
    (A1N => Y) = (0, 0);
    (A2N => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI2BB2_X1_HVT (A1N, A2N, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1N;
  input A2N;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((~A1N & ~A2N) | (B1 & B2));
  specify
    (A1N => Y) = (0, 0);
    (A2N => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI2BB1_X1_HVT (A1N, A2N, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1N;
  input A2N;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((~A1N | ~A2N) & B);
  specify
    (A1N => Y) = (0, 0);
    (A2N => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI2BB2_X1_HVT (A1N, A2N, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1N;
  input A2N;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((~A1N | ~A2N) & (B1 | B2));
  specify
    (A1N => Y) = (0, 0);
    (A2N => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI2BB1_X2_HVT (A1N, A2N, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1N;
  input A2N;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((~A1N & ~A2N) | B);
  specify
    (A1N => Y) = (0, 0);
    (A2N => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AOI2BB2_X2_HVT (A1N, A2N, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1N;
  input A2N;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((~A1N & ~A2N) | (B1 & B2));
  specify
    (A1N => Y) = (0, 0);
    (A2N => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI2BB1_X2_HVT (A1N, A2N, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1N;
  input A2N;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((~A1N | ~A2N) & B);
  specify
    (A1N => Y) = (0, 0);
    (A2N => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module OAI2BB2_X2_HVT (A1N, A2N, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1N;
  input A2N;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((~A1N | ~A2N) & (B1 | B2));
  specify
    (A1N => Y) = (0, 0);
    (A2N => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module MUX2_X1_HVT (I0, I1, S, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input I0;
  input I1;
  input S;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((I0 & ~S) | (I1 & S));
  specify
    (I0 => Y) = (0, 0);
    (I1 => Y) = (0, 0);
    (S => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module MUX2_X2_HVT (I0, I1, S, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input I0;
  input I1;
  input S;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((I0 & ~S) | (I1 & S));
  specify
    (I0 => Y) = (0, 0);
    (I1 => Y) = (0, 0);
    (S => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module MUX2_X4_HVT (I0, I1, S, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input I0;
  input I1;
  input S;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((I0 & ~S) | (I1 & S));
  specify
    (I0 => Y) = (0, 0);
    (I1 => Y) = (0, 0);
    (S => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module MXI2_X1_HVT (I0, I1, S, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input I0;
  input I1;
  input S;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((I0 & ~S) | (I1 & S));
  specify
    (I0 => Y) = (0, 0);
    (I1 => Y) = (0, 0);
    (S => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module MUX4_X1_HVT (I0, I1, I2, I3, S0, S1, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input I0;
  input I1;
  input I2;
  input I3;
  input S0;
  input S1;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((((I0 & ~S0) & ~S1) | ((I1 & S0) & ~S1)) | ((I2 & ~S0) & S1)) | ((I3 & S0) & S1));
  specify
    (I0 => Y) = (0, 0);
    (I1 => Y) = (0, 0);
    (I2 => Y) = (0, 0);
    (I3 => Y) = (0, 0);
    (S0 => Y) = (0, 0);
    (S1 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module MXI2_X2_HVT (I0, I1, S, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input I0;
  input I1;
  input S;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((I0 & ~S) | (I1 & S));
  specify
    (I0 => Y) = (0, 0);
    (I1 => Y) = (0, 0);
    (S => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module MUX4_X2_HVT (I0, I1, I2, I3, S0, S1, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input I0;
  input I1;
  input I2;
  input I3;
  input S0;
  input S1;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (((((I0 & ~S0) & ~S1) | ((I1 & S0) & ~S1)) | ((I2 & ~S0) & S1)) | ((I3 & S0) & S1));
  specify
    (I0 => Y) = (0, 0);
    (I1 => Y) = (0, 0);
    (I2 => Y) = (0, 0);
    (I3 => Y) = (0, 0);
    (S0 => Y) = (0, 0);
    (S1 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HADD_X1_HVT (A, B, CO, S
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output CO;
  output S;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign S = (A ^ B);
  assign CO = (A & B);
  specify
    (A => S) = (0, 0);
    (B => S) = (0, 0);
    (A => CO) = (0, 0);
    (B => CO) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FADD_X1_HVT (A, B, CI, CO, S
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input CI;
  output CO;
  output S;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign S = ((A ^ B) ^ CI);
  assign CO = (((A & B) | (A & CI)) | (B & CI));
  specify
    (A => S) = (0, 0);
    (B => S) = (0, 0);
    (CI => S) = (0, 0);
    (A => CO) = (0, 0);
    (B => CO) = (0, 0);
    (CI => CO) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HADD_X2_HVT (A, B, CO, S
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output CO;
  output S;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign S = (A ^ B);
  assign CO = (A & B);
  specify
    (A => S) = (0, 0);
    (B => S) = (0, 0);
    (A => CO) = (0, 0);
    (B => CO) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FADD_X2_HVT (A, B, CI, CO, S
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input CI;
  output CO;
  output S;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign S = ((A ^ B) ^ CI);
  assign CO = (((A & B) | (A & CI)) | (B & CI));
  specify
    (A => S) = (0, 0);
    (B => S) = (0, 0);
    (CI => S) = (0, 0);
    (A => CO) = (0, 0);
    (B => CO) = (0, 0);
    (CI => CO) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HADD_X4_HVT (A, B, CO, S
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output CO;
  output S;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign S = (A ^ B);
  assign CO = (A & B);
  specify
    (A => S) = (0, 0);
    (B => S) = (0, 0);
    (A => CO) = (0, 0);
    (B => CO) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FADD_X4_HVT (A, B, CI, CO, S
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input CI;
  output CO;
  output S;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign S = ((A ^ B) ^ CI);
  assign CO = (((A & B) | (A & CI)) | (B & CI));
  specify
    (A => S) = (0, 0);
    (B => S) = (0, 0);
    (CI => S) = (0, 0);
    (A => CO) = (0, 0);
    (B => CO) = (0, 0);
    (CI => CO) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module TIEHI_X1_HVT (Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = 1'b1;
endmodule
`endcelldefine

`celldefine
module TIELO_X1_HVT (Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = 1'b0;
endmodule
`endcelldefine

`celldefine
module DLY1_X1_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module DLY2_X1_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module DLY3_X1_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module DLY4_X1_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKINV_X1_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKBUF_X1_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKINV_X2_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKBUF_X2_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKINV_X3_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKBUF_X3_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKINV_X4_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKBUF_X4_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKINV_X6_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKBUF_X6_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKINV_X8_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKBUF_X8_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKINV_X12_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKBUF_X12_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKINV_X16_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKBUF_X16_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKMUX2_X1_HVT (I0, I1, S, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input I0;
  input I1;
  input S;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((I0 & ~S) | (I1 & S));
  specify
    (I0 => Y) = (0, 0);
    (I1 => Y) = (0, 0);
    (S => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKMUX2_X2_HVT (I0, I1, S, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input I0;
  input I1;
  input S;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((I0 & ~S) | (I1 & S));
  specify
    (I0 => Y) = (0, 0);
    (I1 => Y) = (0, 0);
    (S => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKMUX2_X4_HVT (I0, I1, S, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input I0;
  input I1;
  input S;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((I0 & ~S) | (I1 & S));
  specify
    (I0 => Y) = (0, 0);
    (I1 => Y) = (0, 0);
    (S => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKAND2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKNAND2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKOR2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKNOR2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKXOR2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A ^ B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKAND2_X2_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKNAND2_X2_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKOR2_X2_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKNOR2_X2_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKXOR2_X2_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A ^ B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKAND2_X4_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKNAND2_X4_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKOR2_X4_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKNOR2_X4_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKXOR2_X4_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A ^ B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKD1_X2_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKD2_X2_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKD3_X2_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKD4_X2_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module CKD5_X2_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPRE_X1_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, (E | SE), ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & IQ;
  specify
    (CK => GCK) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPRE_X2_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, (E | SE), ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & IQ;
  specify
    (CK => GCK) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPRE_X4_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, (E | SE), ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & IQ;
  specify
    (CK => GCK) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPRE_X8_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, (E | SE), ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & IQ;
  specify
    (CK => GCK) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPRE_X16_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, (E | SE), ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & IQ;
  specify
    (CK => GCK) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPOST_X1_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, E, ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & (IQ | SE);
  specify
    (CK => GCK) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPOST_X2_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, E, ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & (IQ | SE);
  specify
    (CK => GCK) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPOST_X4_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, E, ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & (IQ | SE);
  specify
    (CK => GCK) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPOST_X8_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, E, ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & (IQ | SE);
  specify
    (CK => GCK) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPOST_X16_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, E, ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & (IQ | SE);
  specify
    (CK => GCK) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPREOBS_X1_HVT (CK, E, SE, GCK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, (E | SE), ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & IQ;
  buf (Q, IQ);
  specify
    (CK => GCK) = (0, 0);
    (negedge CK => (Q +: E)) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPREOBS_X2_HVT (CK, E, SE, GCK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, (E | SE), ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & IQ;
  buf (Q, IQ);
  specify
    (CK => GCK) = (0, 0);
    (negedge CK => (Q +: E)) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPREOBS_X4_HVT (CK, E, SE, GCK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, (E | SE), ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & IQ;
  buf (Q, IQ);
  specify
    (CK => GCK) = (0, 0);
    (negedge CK => (Q +: E)) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPOSTOBS_X1_HVT (CK, E, SE, GCK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, E, ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & (IQ | SE);
  buf (Q, IQ);
  specify
    (CK => GCK) = (0, 0);
    (negedge CK => (Q +: E)) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPOSTOBS_X2_HVT (CK, E, SE, GCK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, E, ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & (IQ | SE);
  buf (Q, IQ);
  specify
    (CK => GCK) = (0, 0);
    (negedge CK => (Q +: E)) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGPOSTOBS_X4_HVT (CK, E, SE, GCK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, E, ~CK, 1'b1, 1'b1, notifier);
  assign GCK = CK & (IQ | SE);
  buf (Q, IQ);
  specify
    (CK => GCK) = (0, 0);
    (negedge CK => (Q +: E)) = (0, 0);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGNPRE_X1_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, (E | SE), CK, 1'b1, 1'b1, notifier);
  assign GCK = CK | ~IQ;
  specify
    (CK => GCK) = (0, 0);
    $setuphold(negedge CK, E, 0, 0, notifier);
    $setuphold(negedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGNPRE_X2_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, (E | SE), CK, 1'b1, 1'b1, notifier);
  assign GCK = CK | ~IQ;
  specify
    (CK => GCK) = (0, 0);
    $setuphold(negedge CK, E, 0, 0, notifier);
    $setuphold(negedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGNPRE_X4_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, (E | SE), CK, 1'b1, 1'b1, notifier);
  assign GCK = CK | ~IQ;
  specify
    (CK => GCK) = (0, 0);
    $setuphold(negedge CK, E, 0, 0, notifier);
    $setuphold(negedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGNPOST_X1_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, E, CK, 1'b1, 1'b1, notifier);
  assign GCK = CK | ~(IQ | SE);
  specify
    (CK => GCK) = (0, 0);
    $setuphold(negedge CK, E, 0, 0, notifier);
    $setuphold(negedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGNPOST_X2_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, E, CK, 1'b1, 1'b1, notifier);
  assign GCK = CK | ~(IQ | SE);
  specify
    (CK => GCK) = (0, 0);
    $setuphold(negedge CK, E, 0, 0, notifier);
    $setuphold(negedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module ICGNPOST_X4_HVT (CK, E, SE, GCK
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CK;
  input E;
  input SE;
  output GCK;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, E, CK, 1'b1, 1'b1, notifier);
  assign GCK = CK | ~(IQ | SE);
  specify
    (CK => GCK) = (0, 0);
    $setuphold(negedge CK, E, 0, 0, notifier);
    $setuphold(negedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFF_X1_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFF_X2_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFF_X4_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFQN_X1_HVT (D, CK, Q, QN
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
  output QN;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  not (QN, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (posedge CK => (QN +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFQN_X2_HVT (D, CK, Q, QN
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
  output QN;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  not (QN, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (posedge CK => (QN +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFQN_X4_HVT (D, CK, Q, QN
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
  output QN;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  not (QN, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (posedge CK => (QN +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFN_X1_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire ck_i = ~CK;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    $setuphold(negedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFN_X2_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire ck_i = ~CK;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    $setuphold(negedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFN_X4_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire ck_i = ~CK;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    $setuphold(negedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFR_X1_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFR_X2_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFR_X4_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFRQN_X1_HVT (D, CK, RN, Q, QN
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  output Q;
  output QN;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  not (QN, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    (posedge CK => (QN +: D)) = (0, 0);
    (RN => QN) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFRQN_X2_HVT (D, CK, RN, Q, QN
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  output Q;
  output QN;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  not (QN, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    (posedge CK => (QN +: D)) = (0, 0);
    (RN => QN) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFRQN_X4_HVT (D, CK, RN, Q, QN
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  output Q;
  output QN;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  not (QN, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    (posedge CK => (QN +: D)) = (0, 0);
    (RN => QN) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFS_X1_HVT (D, CK, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, 1'b1, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFS_X2_HVT (D, CK, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, 1'b1, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFS_X4_HVT (D, CK, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, 1'b1, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFRS_X1_HVT (D, CK, RN, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, RN, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFRS_X2_HVT (D, CK, RN, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, RN, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFRS_X4_HVT (D, CK, RN, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, RN, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFNR_X1_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire ck_i = ~CK;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(negedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, negedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFNR_X2_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire ck_i = ~CK;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(negedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, negedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFNR_X4_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire ck_i = ~CK;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(negedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, negedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFSYNR_X1_HVT (D, RN, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input RN;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sr = D & RN;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sr, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFSYNR_X2_HVT (D, RN, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input RN;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sr = D & RN;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sr, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module DFFSYNR_X4_HVT (D, RN, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input RN;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sr = D & RN;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sr, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module EDFF_X1_HVT (D, E, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_en = E ? D : IQ;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_en, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module EDFF_X2_HVT (D, E, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_en = E ? D : IQ;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_en, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module EDFF_X4_HVT (D, E, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_en = E ? D : IQ;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_en, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFF_X1_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFF_X2_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFF_X4_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFQN_X1_HVT (D, SI, SE, CK, Q, QN
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  output QN;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  not (QN, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (posedge CK => (QN +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFQN_X2_HVT (D, SI, SE, CK, Q, QN
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  output QN;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  not (QN, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (posedge CK => (QN +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFQN_X4_HVT (D, SI, SE, CK, Q, QN
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
  output QN;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  not (QN, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (posedge CK => (QN +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFN_X1_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire ck_i = ~CK;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, ck_i, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    $setuphold(negedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(negedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(negedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFN_X2_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire ck_i = ~CK;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, ck_i, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    $setuphold(negedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(negedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(negedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFN_X4_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire ck_i = ~CK;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, ck_i, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    $setuphold(negedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(negedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(negedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFR_X1_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFR_X2_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFR_X4_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFS_X1_HVT (D, SI, SE, CK, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFS_X2_HVT (D, SI, SE, CK, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFS_X4_HVT (D, SI, SE, CK, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFRS_X1_HVT (D, SI, SE, CK, RN, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, RN, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFRS_X2_HVT (D, SI, SE, CK, RN, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, RN, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFRS_X4_HVT (D, SI, SE, CK, RN, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, RN, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $recrem(posedge SN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(negedge SN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFSYNR_X1_HVT (D, RN, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input RN;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sr = D & RN;
  wire d_sc = SE ? SI : d_sr;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), RN, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFSYNR_X2_HVT (D, RN, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input RN;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sr = D & RN;
  wire d_sc = SE ? SI : d_sr;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), RN, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SDFFSYNR_X4_HVT (D, RN, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input RN;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sr = D & RN;
  wire d_sc = SE ? SI : d_sr;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), RN, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SEDFF_X1_HVT (D, E, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_en = E ? D : IQ;
  wire d_sc = SE ? SI : d_en;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), E, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SEDFF_X2_HVT (D, E, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_en = E ? D : IQ;
  wire d_sc = SE ? SI : d_en;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), E, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module SEDFF_X4_HVT (D, E, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_en = E ? D : IQ;
  wire d_sc = SE ? SI : d_en;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), E, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCH_X1_HVT (D, E, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCH_X2_HVT (D, E, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCH_X4_HVT (D, E, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHN_X1_HVT (D, EN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input EN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, ~EN, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge EN => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(posedge EN, D, 0, 0, notifier);
    $width(posedge EN, 0, 0, notifier);
    $width(negedge EN, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHN_X2_HVT (D, EN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input EN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, ~EN, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge EN => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(posedge EN, D, 0, 0, notifier);
    $width(posedge EN, 0, 0, notifier);
    $width(negedge EN, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHN_X4_HVT (D, EN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input EN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, ~EN, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge EN => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(posedge EN, D, 0, 0, notifier);
    $width(posedge EN, 0, 0, notifier);
    $width(negedge EN, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHR_X1_HVT (D, E, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHR_X2_HVT (D, E, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHR_X4_HVT (D, E, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHS_X1_HVT (D, E, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, 1'b1, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHS_X2_HVT (D, E, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, 1'b1, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHS_X4_HVT (D, E, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, 1'b1, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHRS_X1_HVT (D, E, RN, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input RN;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, RN, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (RN => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHRS_X2_HVT (D, E, RN, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input RN;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, RN, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (RN => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHRS_X4_HVT (D, E, RN, SN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  input RN;
  input SN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, RN, SN, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (RN => Q) = (0, 0);
    (SN => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHNR_X1_HVT (D, EN, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input EN;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, ~EN, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge EN => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge EN, D, 0, 0, notifier);
    $width(posedge EN, 0, 0, notifier);
    $width(negedge EN, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHNR_X2_HVT (D, EN, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input EN;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, ~EN, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge EN => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge EN, D, 0, 0, notifier);
    $width(posedge EN, 0, 0, notifier);
    $width(negedge EN, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LATCHNR_X4_HVT (D, EN, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input EN;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, ~EN, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge EN => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge EN, D, 0, 0, notifier);
    $width(posedge EN, 0, 0, notifier);
    $width(negedge EN, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFF2_X1_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [1:0] D;
  input CK;
  output [1:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [1:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 2; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFF2_X2_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [1:0] D;
  input CK;
  output [1:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [1:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 2; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFF4_X1_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [3:0] D;
  input CK;
  output [3:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [3:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 4; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFF4_X2_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [3:0] D;
  input CK;
  output [3:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [3:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 4; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFF8_X1_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [7:0] D;
  input CK;
  output [7:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [7:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 8; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFF8_X2_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [7:0] D;
  input CK;
  output [7:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [7:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 8; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFF16_X1_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [15:0] D;
  input CK;
  output [15:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [15:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 16; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $setuphold(posedge CK, D[8], 0, 0, notifier);
    $setuphold(posedge CK, D[9], 0, 0, notifier);
    $setuphold(posedge CK, D[10], 0, 0, notifier);
    $setuphold(posedge CK, D[11], 0, 0, notifier);
    $setuphold(posedge CK, D[12], 0, 0, notifier);
    $setuphold(posedge CK, D[13], 0, 0, notifier);
    $setuphold(posedge CK, D[14], 0, 0, notifier);
    $setuphold(posedge CK, D[15], 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFF16_X2_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [15:0] D;
  input CK;
  output [15:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [15:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 16; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $setuphold(posedge CK, D[8], 0, 0, notifier);
    $setuphold(posedge CK, D[9], 0, 0, notifier);
    $setuphold(posedge CK, D[10], 0, 0, notifier);
    $setuphold(posedge CK, D[11], 0, 0, notifier);
    $setuphold(posedge CK, D[12], 0, 0, notifier);
    $setuphold(posedge CK, D[13], 0, 0, notifier);
    $setuphold(posedge CK, D[14], 0, 0, notifier);
    $setuphold(posedge CK, D[15], 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFF32_X1_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [31:0] D;
  input CK;
  output [31:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [31:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 32; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $setuphold(posedge CK, D[8], 0, 0, notifier);
    $setuphold(posedge CK, D[9], 0, 0, notifier);
    $setuphold(posedge CK, D[10], 0, 0, notifier);
    $setuphold(posedge CK, D[11], 0, 0, notifier);
    $setuphold(posedge CK, D[12], 0, 0, notifier);
    $setuphold(posedge CK, D[13], 0, 0, notifier);
    $setuphold(posedge CK, D[14], 0, 0, notifier);
    $setuphold(posedge CK, D[15], 0, 0, notifier);
    $setuphold(posedge CK, D[16], 0, 0, notifier);
    $setuphold(posedge CK, D[17], 0, 0, notifier);
    $setuphold(posedge CK, D[18], 0, 0, notifier);
    $setuphold(posedge CK, D[19], 0, 0, notifier);
    $setuphold(posedge CK, D[20], 0, 0, notifier);
    $setuphold(posedge CK, D[21], 0, 0, notifier);
    $setuphold(posedge CK, D[22], 0, 0, notifier);
    $setuphold(posedge CK, D[23], 0, 0, notifier);
    $setuphold(posedge CK, D[24], 0, 0, notifier);
    $setuphold(posedge CK, D[25], 0, 0, notifier);
    $setuphold(posedge CK, D[26], 0, 0, notifier);
    $setuphold(posedge CK, D[27], 0, 0, notifier);
    $setuphold(posedge CK, D[28], 0, 0, notifier);
    $setuphold(posedge CK, D[29], 0, 0, notifier);
    $setuphold(posedge CK, D[30], 0, 0, notifier);
    $setuphold(posedge CK, D[31], 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFF32_X2_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [31:0] D;
  input CK;
  output [31:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [31:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 32; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $setuphold(posedge CK, D[8], 0, 0, notifier);
    $setuphold(posedge CK, D[9], 0, 0, notifier);
    $setuphold(posedge CK, D[10], 0, 0, notifier);
    $setuphold(posedge CK, D[11], 0, 0, notifier);
    $setuphold(posedge CK, D[12], 0, 0, notifier);
    $setuphold(posedge CK, D[13], 0, 0, notifier);
    $setuphold(posedge CK, D[14], 0, 0, notifier);
    $setuphold(posedge CK, D[15], 0, 0, notifier);
    $setuphold(posedge CK, D[16], 0, 0, notifier);
    $setuphold(posedge CK, D[17], 0, 0, notifier);
    $setuphold(posedge CK, D[18], 0, 0, notifier);
    $setuphold(posedge CK, D[19], 0, 0, notifier);
    $setuphold(posedge CK, D[20], 0, 0, notifier);
    $setuphold(posedge CK, D[21], 0, 0, notifier);
    $setuphold(posedge CK, D[22], 0, 0, notifier);
    $setuphold(posedge CK, D[23], 0, 0, notifier);
    $setuphold(posedge CK, D[24], 0, 0, notifier);
    $setuphold(posedge CK, D[25], 0, 0, notifier);
    $setuphold(posedge CK, D[26], 0, 0, notifier);
    $setuphold(posedge CK, D[27], 0, 0, notifier);
    $setuphold(posedge CK, D[28], 0, 0, notifier);
    $setuphold(posedge CK, D[29], 0, 0, notifier);
    $setuphold(posedge CK, D[30], 0, 0, notifier);
    $setuphold(posedge CK, D[31], 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFFR2_X1_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [1:0] D;
  input CK;
  input RN;
  output [1:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [1:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 2; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFFR2_X2_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [1:0] D;
  input CK;
  input RN;
  output [1:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [1:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 2; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFFR4_X1_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [3:0] D;
  input CK;
  input RN;
  output [3:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [3:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 4; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFFR4_X2_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [3:0] D;
  input CK;
  input RN;
  output [3:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [3:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 4; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFFR8_X1_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [7:0] D;
  input CK;
  input RN;
  output [7:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [7:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 8; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFFR8_X2_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [7:0] D;
  input CK;
  input RN;
  output [7:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [7:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 8; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFFR16_X1_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [15:0] D;
  input CK;
  input RN;
  output [15:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [15:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 16; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $setuphold(posedge CK, D[8], 0, 0, notifier);
    $setuphold(posedge CK, D[9], 0, 0, notifier);
    $setuphold(posedge CK, D[10], 0, 0, notifier);
    $setuphold(posedge CK, D[11], 0, 0, notifier);
    $setuphold(posedge CK, D[12], 0, 0, notifier);
    $setuphold(posedge CK, D[13], 0, 0, notifier);
    $setuphold(posedge CK, D[14], 0, 0, notifier);
    $setuphold(posedge CK, D[15], 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFFR16_X2_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [15:0] D;
  input CK;
  input RN;
  output [15:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [15:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 16; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $setuphold(posedge CK, D[8], 0, 0, notifier);
    $setuphold(posedge CK, D[9], 0, 0, notifier);
    $setuphold(posedge CK, D[10], 0, 0, notifier);
    $setuphold(posedge CK, D[11], 0, 0, notifier);
    $setuphold(posedge CK, D[12], 0, 0, notifier);
    $setuphold(posedge CK, D[13], 0, 0, notifier);
    $setuphold(posedge CK, D[14], 0, 0, notifier);
    $setuphold(posedge CK, D[15], 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFFR32_X1_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [31:0] D;
  input CK;
  input RN;
  output [31:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [31:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 32; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $setuphold(posedge CK, D[8], 0, 0, notifier);
    $setuphold(posedge CK, D[9], 0, 0, notifier);
    $setuphold(posedge CK, D[10], 0, 0, notifier);
    $setuphold(posedge CK, D[11], 0, 0, notifier);
    $setuphold(posedge CK, D[12], 0, 0, notifier);
    $setuphold(posedge CK, D[13], 0, 0, notifier);
    $setuphold(posedge CK, D[14], 0, 0, notifier);
    $setuphold(posedge CK, D[15], 0, 0, notifier);
    $setuphold(posedge CK, D[16], 0, 0, notifier);
    $setuphold(posedge CK, D[17], 0, 0, notifier);
    $setuphold(posedge CK, D[18], 0, 0, notifier);
    $setuphold(posedge CK, D[19], 0, 0, notifier);
    $setuphold(posedge CK, D[20], 0, 0, notifier);
    $setuphold(posedge CK, D[21], 0, 0, notifier);
    $setuphold(posedge CK, D[22], 0, 0, notifier);
    $setuphold(posedge CK, D[23], 0, 0, notifier);
    $setuphold(posedge CK, D[24], 0, 0, notifier);
    $setuphold(posedge CK, D[25], 0, 0, notifier);
    $setuphold(posedge CK, D[26], 0, 0, notifier);
    $setuphold(posedge CK, D[27], 0, 0, notifier);
    $setuphold(posedge CK, D[28], 0, 0, notifier);
    $setuphold(posedge CK, D[29], 0, 0, notifier);
    $setuphold(posedge CK, D[30], 0, 0, notifier);
    $setuphold(posedge CK, D[31], 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBDFFR32_X2_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [31:0] D;
  input CK;
  input RN;
  output [31:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [31:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 32; i = i + 1) begin : g_bit
    assign din[i] = D[i];
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK, D[0], 0, 0, notifier);
    $setuphold(posedge CK, D[1], 0, 0, notifier);
    $setuphold(posedge CK, D[2], 0, 0, notifier);
    $setuphold(posedge CK, D[3], 0, 0, notifier);
    $setuphold(posedge CK, D[4], 0, 0, notifier);
    $setuphold(posedge CK, D[5], 0, 0, notifier);
    $setuphold(posedge CK, D[6], 0, 0, notifier);
    $setuphold(posedge CK, D[7], 0, 0, notifier);
    $setuphold(posedge CK, D[8], 0, 0, notifier);
    $setuphold(posedge CK, D[9], 0, 0, notifier);
    $setuphold(posedge CK, D[10], 0, 0, notifier);
    $setuphold(posedge CK, D[11], 0, 0, notifier);
    $setuphold(posedge CK, D[12], 0, 0, notifier);
    $setuphold(posedge CK, D[13], 0, 0, notifier);
    $setuphold(posedge CK, D[14], 0, 0, notifier);
    $setuphold(posedge CK, D[15], 0, 0, notifier);
    $setuphold(posedge CK, D[16], 0, 0, notifier);
    $setuphold(posedge CK, D[17], 0, 0, notifier);
    $setuphold(posedge CK, D[18], 0, 0, notifier);
    $setuphold(posedge CK, D[19], 0, 0, notifier);
    $setuphold(posedge CK, D[20], 0, 0, notifier);
    $setuphold(posedge CK, D[21], 0, 0, notifier);
    $setuphold(posedge CK, D[22], 0, 0, notifier);
    $setuphold(posedge CK, D[23], 0, 0, notifier);
    $setuphold(posedge CK, D[24], 0, 0, notifier);
    $setuphold(posedge CK, D[25], 0, 0, notifier);
    $setuphold(posedge CK, D[26], 0, 0, notifier);
    $setuphold(posedge CK, D[27], 0, 0, notifier);
    $setuphold(posedge CK, D[28], 0, 0, notifier);
    $setuphold(posedge CK, D[29], 0, 0, notifier);
    $setuphold(posedge CK, D[30], 0, 0, notifier);
    $setuphold(posedge CK, D[31], 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFF2_X1_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [1:0] D;
  input [1:0] SI;
  input SE;
  input CK;
  output [1:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [1:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 2; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFF2_X2_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [1:0] D;
  input [1:0] SI;
  input SE;
  input CK;
  output [1:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [1:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 2; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFF4_X1_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [3:0] D;
  input [3:0] SI;
  input SE;
  input CK;
  output [3:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [3:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 4; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFF4_X2_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [3:0] D;
  input [3:0] SI;
  input SE;
  input CK;
  output [3:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [3:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 4; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFF8_X1_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [7:0] D;
  input [7:0] SI;
  input SE;
  input CK;
  output [7:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [7:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 8; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFF8_X2_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [7:0] D;
  input [7:0] SI;
  input SE;
  input CK;
  output [7:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [7:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 8; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFF16_X1_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [15:0] D;
  input [15:0] SI;
  input SE;
  input CK;
  output [15:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [15:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 16; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[15], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFF16_X2_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [15:0] D;
  input [15:0] SI;
  input SE;
  input CK;
  output [15:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [15:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 16; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[15], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFF32_X1_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [31:0] D;
  input [31:0] SI;
  input SE;
  input CK;
  output [31:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [31:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 32; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[16], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[17], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[18], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[19], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[20], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[21], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[22], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[23], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[24], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[25], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[26], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[27], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[28], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[29], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[30], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[31], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[16], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[17], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[18], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[19], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[20], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[21], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[22], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[23], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[24], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[25], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[26], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[27], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[28], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[29], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[30], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[31], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFF32_X2_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [31:0] D;
  input [31:0] SI;
  input SE;
  input CK;
  output [31:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [31:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 32; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, 1'b1, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[16], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[17], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[18], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[19], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[20], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[21], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[22], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[23], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[24], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[25], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[26], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[27], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[28], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[29], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[30], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[31], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[16], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[17], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[18], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[19], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[20], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[21], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[22], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[23], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[24], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[25], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[26], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[27], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[28], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[29], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[30], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[31], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFFR2_X1_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [1:0] D;
  input [1:0] SI;
  input SE;
  input CK;
  input RN;
  output [1:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [1:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 2; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFFR2_X2_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [1:0] D;
  input [1:0] SI;
  input SE;
  input CK;
  input RN;
  output [1:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [1:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 2; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFFR4_X1_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [3:0] D;
  input [3:0] SI;
  input SE;
  input CK;
  input RN;
  output [3:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [3:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 4; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFFR4_X2_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [3:0] D;
  input [3:0] SI;
  input SE;
  input CK;
  input RN;
  output [3:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [3:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 4; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFFR8_X1_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [7:0] D;
  input [7:0] SI;
  input SE;
  input CK;
  input RN;
  output [7:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [7:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 8; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFFR8_X2_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [7:0] D;
  input [7:0] SI;
  input SE;
  input CK;
  input RN;
  output [7:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [7:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 8; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFFR16_X1_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [15:0] D;
  input [15:0] SI;
  input SE;
  input CK;
  input RN;
  output [15:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [15:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 16; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[15], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFFR16_X2_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [15:0] D;
  input [15:0] SI;
  input SE;
  input CK;
  input RN;
  output [15:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [15:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 16; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[15], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFFR32_X1_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [31:0] D;
  input [31:0] SI;
  input SE;
  input CK;
  input RN;
  output [31:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [31:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 32; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[16], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[17], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[18], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[19], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[20], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[21], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[22], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[23], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[24], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[25], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[26], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[27], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[28], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[29], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[30], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[31], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[16], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[17], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[18], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[19], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[20], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[21], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[22], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[23], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[24], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[25], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[26], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[27], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[28], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[29], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[30], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[31], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module MBSDFFR32_X2_HVT (D, SI, SE, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input [31:0] D;
  input [31:0] SI;
  input SE;
  input CK;
  input RN;
  output [31:0] Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire [31:0] IQ, din;
  genvar i;
  generate for (i = 0; i < 32; i = i + 1) begin : g_bit
    assign din[i] = (SE ? SI[i] : D[i]);
    r14_udp_ff u_ff (IQ[i], din[i], CK, RN, 1'b1, notifier);
  end endgenerate
  assign Q = IQ;
  specify
    (CK *> Q) = (0, 0);
    (RN *> Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[16], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[17], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[18], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[19], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[20], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[21], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[22], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[23], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[24], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[25], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[26], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[27], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[28], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[29], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[30], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b0), D[31], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[0], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[1], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[2], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[3], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[4], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[5], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[6], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[7], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[8], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[9], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[10], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[11], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[12], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[13], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[14], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[15], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[16], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[17], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[18], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[19], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[20], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[21], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[22], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[23], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[24], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[25], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[26], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[27], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[28], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[29], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[30], 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI[31], 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LOCKUP_X1_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, ~CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LOCKUPP_X1_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(negedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LOCKUP_X2_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, ~CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LOCKUPP_X2_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(negedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LOCKUP_X4_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, ~CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (negedge CK => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module LOCKUPP_X4_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(negedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module TPOBS_X1_HVT (A, SI, SE, CK, SO
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input SI;
  input SE;
  input CK;
  output SO;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : A;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (SO, IQ);
  specify
    (posedge CK => (SO +: A)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), A, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module TPCTL0_X1_HVT (A, TE, SI, SE, CK, Y, SO
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input TE;
  input SI;
  input SE;
  input CK;
  output Y;
  output SO;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  wire ds = SE ? SI : IQ;
  r14_udp_ff u_ff (IQ, ds, CK, 1'b1, 1'b1, notifier);
  buf (SO, IQ);
  assign Y = (A & ~(TE & IQ));
  specify
    (A => Y) = (0, 0);
    (TE => Y) = (0, 0);
    (posedge CK => (Y +: A)) = (0, 0);
    (posedge CK => (SO +: A)) = (0, 0);
    $setuphold(posedge CK, SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module TPCTL1_X1_HVT (A, TE, SI, SE, CK, Y, SO
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input TE;
  input SI;
  input SE;
  input CK;
  output Y;
  output SO;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  wire ds = SE ? SI : IQ;
  r14_udp_ff u_ff (IQ, ds, CK, 1'b1, 1'b1, notifier);
  buf (SO, IQ);
  assign Y = (A | (TE & IQ));
  specify
    (A => Y) = (0, 0);
    (TE => Y) = (0, 0);
    (posedge CK => (Y +: A)) = (0, 0);
    (posedge CK => (SO +: A)) = (0, 0);
    $setuphold(posedge CK, SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module WBRCELL_X1_HVT (CFI, WSI, SHIFTWR, CAPTUREWR, WRCK, UPDATEWR, WMODE, CFO, WSO
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CFI;
  input WSI;
  input SHIFTWR;
  input CAPTUREWR;
  input WRCK;
  input UPDATEWR;
  input WMODE;
  output CFO;
  output WSO;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ1, IQ2;
  wire d1 = SHIFTWR ? WSI : (CAPTUREWR ? CFI : IQ1);
  r14_udp_ff u_sc (IQ1, d1, WRCK, 1'b1, 1'b1, notifier);   // shift/capture stage
  r14_udp_ff u_up (IQ2, IQ1, UPDATEWR, 1'b1, 1'b1, notifier);  // update stage
  buf (WSO, IQ1);
  assign CFO = WMODE ? IQ2 : CFI;
  specify
    (CFI => CFO) = (0, 0);
    (WMODE => CFO) = (0, 0);
    (posedge WRCK => (WSO +: CFI)) = (0, 0);
    (posedge UPDATEWR => (CFO +: CFI)) = (0, 0);
    $setuphold(posedge WRCK, CFI, 0, 0, notifier);
    $setuphold(posedge WRCK, WSI, 0, 0, notifier);
    $setuphold(posedge WRCK, SHIFTWR, 0, 0, notifier);
    $setuphold(posedge WRCK, CAPTUREWR, 0, 0, notifier);
    $width(posedge WRCK, 0, 0, notifier);
    $width(negedge WRCK, 0, 0, notifier);
    $width(posedge UPDATEWR, 0, 0, notifier);
    $width(negedge UPDATEWR, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module BSCELL_X1_HVT (PI, TDI, SHIFTDR, CLOCKDR, UPDATEDR, MODE, PO, TDO
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input PI;
  input TDI;
  input SHIFTDR;
  input CLOCKDR;
  input UPDATEDR;
  input MODE;
  output PO;
  output TDO;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ1, IQ2;
  wire d1 = SHIFTDR ? TDI : PI;
  r14_udp_ff u_sc (IQ1, d1, CLOCKDR, 1'b1, 1'b1, notifier);   // shift/capture stage
  r14_udp_ff u_up (IQ2, IQ1, UPDATEDR, 1'b1, 1'b1, notifier);  // update stage
  buf (TDO, IQ1);
  assign PO = MODE ? IQ2 : PI;
  specify
    (PI => PO) = (0, 0);
    (MODE => PO) = (0, 0);
    (posedge CLOCKDR => (TDO +: PI)) = (0, 0);
    (posedge UPDATEDR => (PO +: PI)) = (0, 0);
    $setuphold(posedge CLOCKDR, PI, 0, 0, notifier);
    $setuphold(posedge CLOCKDR, TDI, 0, 0, notifier);
    $setuphold(posedge CLOCKDR, SHIFTDR, 0, 0, notifier);
    $width(posedge CLOCKDR, 0, 0, notifier);
    $width(negedge CLOCKDR, 0, 0, notifier);
    $width(posedge UPDATEDR, 0, 0, notifier);
    $width(negedge UPDATEDR, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module TPOBS_X2_HVT (A, SI, SE, CK, SO
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input SI;
  input SE;
  input CK;
  output SO;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : A;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (SO, IQ);
  specify
    (posedge CK => (SO +: A)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), A, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module TPCTL0_X2_HVT (A, TE, SI, SE, CK, Y, SO
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input TE;
  input SI;
  input SE;
  input CK;
  output Y;
  output SO;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  wire ds = SE ? SI : IQ;
  r14_udp_ff u_ff (IQ, ds, CK, 1'b1, 1'b1, notifier);
  buf (SO, IQ);
  assign Y = (A & ~(TE & IQ));
  specify
    (A => Y) = (0, 0);
    (TE => Y) = (0, 0);
    (posedge CK => (Y +: A)) = (0, 0);
    (posedge CK => (SO +: A)) = (0, 0);
    $setuphold(posedge CK, SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module TPCTL1_X2_HVT (A, TE, SI, SE, CK, Y, SO
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input TE;
  input SI;
  input SE;
  input CK;
  output Y;
  output SO;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  wire ds = SE ? SI : IQ;
  r14_udp_ff u_ff (IQ, ds, CK, 1'b1, 1'b1, notifier);
  buf (SO, IQ);
  assign Y = (A | (TE & IQ));
  specify
    (A => Y) = (0, 0);
    (TE => Y) = (0, 0);
    (posedge CK => (Y +: A)) = (0, 0);
    (posedge CK => (SO +: A)) = (0, 0);
    $setuphold(posedge CK, SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module WBRCELL_X2_HVT (CFI, WSI, SHIFTWR, CAPTUREWR, WRCK, UPDATEWR, WMODE, CFO, WSO
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input CFI;
  input WSI;
  input SHIFTWR;
  input CAPTUREWR;
  input WRCK;
  input UPDATEWR;
  input WMODE;
  output CFO;
  output WSO;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ1, IQ2;
  wire d1 = SHIFTWR ? WSI : (CAPTUREWR ? CFI : IQ1);
  r14_udp_ff u_sc (IQ1, d1, WRCK, 1'b1, 1'b1, notifier);   // shift/capture stage
  r14_udp_ff u_up (IQ2, IQ1, UPDATEWR, 1'b1, 1'b1, notifier);  // update stage
  buf (WSO, IQ1);
  assign CFO = WMODE ? IQ2 : CFI;
  specify
    (CFI => CFO) = (0, 0);
    (WMODE => CFO) = (0, 0);
    (posedge WRCK => (WSO +: CFI)) = (0, 0);
    (posedge UPDATEWR => (CFO +: CFI)) = (0, 0);
    $setuphold(posedge WRCK, CFI, 0, 0, notifier);
    $setuphold(posedge WRCK, WSI, 0, 0, notifier);
    $setuphold(posedge WRCK, SHIFTWR, 0, 0, notifier);
    $setuphold(posedge WRCK, CAPTUREWR, 0, 0, notifier);
    $width(posedge WRCK, 0, 0, notifier);
    $width(negedge WRCK, 0, 0, notifier);
    $width(posedge UPDATEWR, 0, 0, notifier);
    $width(negedge UPDATEWR, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module BSCELL_X2_HVT (PI, TDI, SHIFTDR, CLOCKDR, UPDATEDR, MODE, PO, TDO
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input PI;
  input TDI;
  input SHIFTDR;
  input CLOCKDR;
  input UPDATEDR;
  input MODE;
  output PO;
  output TDO;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ1, IQ2;
  wire d1 = SHIFTDR ? TDI : PI;
  r14_udp_ff u_sc (IQ1, d1, CLOCKDR, 1'b1, 1'b1, notifier);   // shift/capture stage
  r14_udp_ff u_up (IQ2, IQ1, UPDATEDR, 1'b1, 1'b1, notifier);  // update stage
  buf (TDO, IQ1);
  assign PO = MODE ? IQ2 : PI;
  specify
    (PI => PO) = (0, 0);
    (MODE => PO) = (0, 0);
    (posedge CLOCKDR => (TDO +: PI)) = (0, 0);
    (posedge UPDATEDR => (PO +: PI)) = (0, 0);
    $setuphold(posedge CLOCKDR, PI, 0, 0, notifier);
    $setuphold(posedge CLOCKDR, TDI, 0, 0, notifier);
    $setuphold(posedge CLOCKDR, SHIFTDR, 0, 0, notifier);
    $width(posedge CLOCKDR, 0, 0, notifier);
    $width(negedge CLOCKDR, 0, 0, notifier);
    $width(posedge UPDATEDR, 0, 0, notifier);
    $width(negedge UPDATEDR, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module GFILL1_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module GFILL2_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module GFILL4_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module GFILL8_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module GFILL16_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module GDCAP1_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module GDCAP2_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module GDCAP4_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module GINV_X1_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GBUF_X1_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GNAND2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GNOR2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GAND2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GOR2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GXOR2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A ^ B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GXNOR2_X1_HVT (A, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~(A ^ B);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GMUX2_X1_HVT (I0, I1, S, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input I0;
  input I1;
  input S;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ((I0 & ~S) | (I1 & S));
  specify
    (I0 => Y) = (0, 0);
    (I1 => Y) = (0, 0);
    (S => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GAOI21_X1_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 & A2) | B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GOAI21_X1_HVT (A1, A2, B, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 | A2) & B);
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GAOI22_X1_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 & A2) | (B1 & B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GOAI22_X1_HVT (A1, A2, B1, B2, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A1 | A2) & (B1 | B2));
  specify
    (A1 => Y) = (0, 0);
    (A2 => Y) = (0, 0);
    (B1 => Y) = (0, 0);
    (B2 => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GNAND3_X1_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A & B) & C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GNOR3_X1_HVT (A, B, C, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input C;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = ~((A | B) | C);
  specify
    (A => Y) = (0, 0);
    (B => Y) = (0, 0);
    (C => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GHADD_X1_HVT (A, B, CO, S
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  output CO;
  output S;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign S = (A ^ B);
  assign CO = (A & B);
  specify
    (A => S) = (0, 0);
    (B => S) = (0, 0);
    (A => CO) = (0, 0);
    (B => CO) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GFADD_X1_HVT (A, B, CI, CO, S
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input B;
  input CI;
  output CO;
  output S;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign S = ((A ^ B) ^ CI);
  assign CO = (((A & B) | (A & CI)) | (B & CI));
  specify
    (A => S) = (0, 0);
    (B => S) = (0, 0);
    (CI => S) = (0, 0);
    (A => CO) = (0, 0);
    (B => CO) = (0, 0);
    (CI => CO) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module GDFF_X1_HVT (D, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module GDFFR_X1_HVT (D, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire IQ;
  r14_udp_ff u_ff (IQ, D, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module GSDFF_X1_HVT (D, SI, SE, CK, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, CK, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module GLATCH_X1_HVT (D, E, Q
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input D;
  input E;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, D, E, 1'b1, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge E => (Q +: D)) = (0, 0);
    (D => Q) = (0, 0);
    $setuphold(negedge E, D, 0, 0, notifier);
    $width(posedge E, 0, 0, notifier);
    $width(negedge E, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module GTIEHI_X1_HVT (Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = 1'b1;
endmodule
`endcelldefine

`celldefine
module GTIELO_X1_HVT (Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = 1'b0;
endmodule
`endcelldefine

`celldefine
module GDLY_X1_HVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FILL1_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module FILL2_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module FILL4_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module FILL8_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module FILL16_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module FILL32_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module FILL64_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module DCAP4_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module DCAP8_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module DCAP16_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module DCAP32_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module DCAP64_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module WELLTAP_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module WELLTAPDH_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPLEFT_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPRIGHT_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPTOP1_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPBOTTOM1_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPTOP2_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPBOTTOM2_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPTOP4_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPBOTTOM4_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPTL_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPTR_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPBL_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ENDCAPBR_X1_HVT (
`ifdef R14_PG_PINS
  VDD, VSS
`endif
  );
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

`celldefine
module ANTENNA_X1_HVT (A
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
endmodule
`endcelldefine

