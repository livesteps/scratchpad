# Synopsys PrimeTime signoff for R14N7 (one corner per run; loop CORNER over the 12 corners)
#   env: R14N7_HOME, CORNER, NETLIST, TOP, SDC, SPEF, OCV=pocv|aocv
source $::env(R14N7_HOME)/flows/synth/r14n7_common.tcl
set CORNER $::env(CORNER)
set OCV [expr {[info exists ::env(OCV)] ? $::env(OCV) : "pocv"}]
set_app_var link_path [concat * [r14n7_libs $CORNER ccs]]
read_verilog $::env(NETLIST); link_design $::env(TOP)
read_parasitics -format spef $::env(SPEF)
if {$OCV eq "pocv"} {
  # LVF tables in the .lib are used directly
  set_app_var timing_pocvm_enable_analysis true
  set_app_var timing_pocvm_corner_sigma 3
  set_app_var timing_pocvm_report_sigma 3
  set_app_var timing_enable_slew_variation true
  set_app_var timing_enable_constraint_variation true
  # fallback coefficients for cells without LVF:
  foreach f [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_${CORNER}.pocv $R14N7_HOME/pmk/*/ocv/*_${CORNER}.pocv] { read_ocvm $f }
} else {
  set_app_var timing_aocvm_enable_analysis true
  foreach f [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_${CORNER}.aocv $R14N7_HOME/pmk/*/ocv/*_${CORNER}.aocv] { read_ocvm $f }
}
read_sdc $::env(SDC)
set_app_var timing_remove_clock_reconvergence_pessimism true
update_timing -full
report_global_timing > rpt/${CORNER}_global.rpt
report_timing -delay_type max -max_paths 50 -significant_digits 2 > rpt/${CORNER}_max.rpt
report_timing -delay_type min -max_paths 50 -significant_digits 2 > rpt/${CORNER}_min.rpt
report_constraint -all_violators > rpt/${CORNER}_viol.rpt
report_power > rpt/${CORNER}_power.rpt
