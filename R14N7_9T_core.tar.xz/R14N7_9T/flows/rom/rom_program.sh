#!/bin/bash
# R14N7 mask-ROM programming wrapper.
#   rom_program.sh -i <boot image: .hex(ihex)|.srec|.bin|.mem(readmemh)> -c <WORDSxBITSmMUX> [-n NAME] [-f fmt] [--fill HH] -o <out_dir>
# Produces a pre-programmed, code-specific ROM macro (all views) + self-check report.  Requires $R14N7_HOME.
set -e
: ${R14N7_HOME:?source flows/setup/r14n7_env.sh first}
export R14_TRACKS=$(sed 's/r14n7t//' $R14N7_HOME/tech/libprefix)
exec python3 $R14N7_HOME/gen/rom_program.py "$@"
