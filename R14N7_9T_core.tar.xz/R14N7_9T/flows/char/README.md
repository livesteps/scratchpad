# Re-characterization

- `liberate_recharacterize.tcl` is a template for re-characterizing the generated SPICE netlists against silicon-calibrated BSIM-CMG cards. It writes CCS, ECSM and LVF libraries per corner and Vt.
- To keep every view consistent, prefer re-fitting the analytic model instead. Adjust `R_N1`, `R_P1`, `CG_FIN` and `CD_FIN` in `gen/netlist.py`, and `ALPHA`, `KVT`, `ILEAK0` and `SIGMA0` in `gen/charmodel.py`, to match your SPICE results. Then re-run `gen/build.py`.
- ngspice-42 has no built-in BSIM-CMG. To use the BSIM-CMG cards in `models/spice/r14n7.l` with ngspice, compile the BSIM-CMG Verilog-A to OSDI with OpenVAF. Commercial simulators (HSPICE, Spectre, FineSim) read the cards directly.
