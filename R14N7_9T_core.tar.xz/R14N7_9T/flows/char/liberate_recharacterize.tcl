# Template: re-characterize R14N7 netlists with real foundry BSIM-CMG cards (Cadence Liberate).
# The cell list, pins, functions and arcs come straight from the generated .lib (used as template).
set CORNER $::env(CORNER)          ;# e.g. ss_0p63v_m40c
set VT     $::env(VT)              ;# HVT SVT LVT ULVT
set_var slew_lower_rise 0.1 ; set_var slew_upper_rise 0.9 ; set_var slew_lower_fall 0.1 ; set_var slew_upper_fall 0.9
set_var measure_slew_lower_rise 0.1 ; set_var measure_slew_upper_rise 0.9
set_var delay_inp_rise 0.5 ; set_var delay_out_rise 0.5 ; set_var delay_inp_fall 0.5 ; set_var delay_out_fall 0.5
set_var ccs_enable 1 ; set_var ecsm_enable 1 ; set_var lvf_enable 1 ; set_var noise_enable 0
set_operating_condition -voltage [lindex [split $CORNER _] 1] -temp [lindex [split $CORNER _] 2]
include foundry_models.sp                                       ;# <- your silicon-calibrated cards
read_spice "$::env(R14N7_HOME)/stdcell/$VT/spice/$::env(R14N7_LIBPFX)_std_[string tolower $VT].sp"
read_library -template "$::env(R14N7_HOME)/stdcell/$VT/liberty/nldm/$::env(R14N7_LIBPFX)_std_[string tolower $VT]_${CORNER}_nldm.lib"
char_library -auto_index -cells [get_cells *]
write_library -overwrite $::env(R14N7_LIBPFX)_std_[string tolower $VT]_${CORNER}_ccs.lib -ccs
write_library -overwrite $::env(R14N7_LIBPFX)_std_[string tolower $VT]_${CORNER}_ecsm.lib -ecsm
write_library -overwrite $::env(R14N7_LIBPFX)_std_[string tolower $VT]_${CORNER}_nldm.lib -lvf
