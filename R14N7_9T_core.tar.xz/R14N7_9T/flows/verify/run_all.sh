#!/bin/bash
# Full R14N7 self-verification.  run_all.sh <pdk_root>   (needs python3, ngspice, iverilog, klayout+gdstk+liberty-parser pip pkgs)
set -u; ROOT=$(readlink -f ${1:-$R14N7_HOME}); V=$ROOT/verify; LOG=${2:-verify_report.txt}; : > $LOG
export R14_TRACKS=$(sed "s/r14n7t//" $ROOT/tech/libprefix)
say(){ echo "$@" | tee -a $LOG; }
say "== R14N7 verification $(date -u +%F)"
for vt in HVT SVT LVT ULVT; do
  say "-- [$vt] transistor-level truth tables (ngspice) vs Liberty functions"; python3 $V/spice_truth.py $vt | tail -1 | tee -a $LOG
  say "-- [$vt] sequential co-simulation (ngspice netlist vs Verilog UDP model)"; python3 $V/seq_check.py $vt | tail -1 | tee -a $LOG
done
say "-- Verilog compile (iverilog, with/without R14_PG_PINS)"; bash $V/verilog_check.sh $ROOT | tail -1 | tee -a $LOG
say "-- Liberty parse"; python3 $V/lib_check.py $ROOT | tee -a $LOG
say "-- DRC (rule table, standalone + abutment)"
for g in $ROOT/stdcell/*/gds/*.gds $ROOT/pmk/*/gds/*.gds $ROOT/io/gds/*.gds; do echo "$(basename $g): $(python3 $V/drc_check.py $g | tail -1)" | tee -a $LOG; done
say "-- Memory BIST / ROM BIST (fault-free + fault-injected)"; bash $V/run_bist.sh $ROOT | tail -1 | tee -a $LOG
say "-- Cell size check (derived minimum width, grids, LEF/GDS/Liberty agreement, Vt footprints)"; python3 $V/size_check.py $ROOT | tee -a $LOG
say "-- Mask-ROM programming flow (example boot image -> pre-programmed macro, self-checks)"; python3 $ROOT/gen/rom_program.py -i $ROOT/flows/rom/examples/boot_rv32_2KB.hex -c 512x32m8 -n BOOTROM --corners tt_0p70v_25c --models nldm -o $(mktemp -d) | grep -E "\"status\"|macro" | tee -a $LOG
say "-- Placement/routing grid"; python3 $V/grid_check.py $ROOT | tee -a $LOG
