# Cadence Innovus floorplan/init for R14N7.  env: R14N7_HOME, NETLIST, TOP, SDC, [UPF]
source $::env(R14N7_HOME)/flows/synth/r14n7_common.tcl
set_db init_power_nets  {VDD VDDL VDDB VDDR VDDM IOVDD}
set_db init_ground_nets {VSS IOVSS}
read_mmmc $::env(R14N7_HOME)/flows/pnr/innovus_mmmc.tcl
read_physical -lef [r14n7_lefs]
read_netlist $::env(NETLIST) -top $::env(TOP)
init_design
if {[info exists ::env(UPF)]} { read_power_intent -1801 $::env(UPF); commit_power_intent }
# --- floorplan: core origin on 0.216 um (lcm of vertical pitches) and 0.270 um rows
set util 0.70
create_floorplan -site coreSite -core_density_size 1.0 $util 2.160 2.160 2.160 2.160
source $::env(R14N7_HOME)/flows/pnr/r14n7_tracks_innovus.tcl
set_db place_detail_honor_inst_pad true
# --- macros on the 0.108 x 0.270 grid
foreach m [get_db insts -if {.base_cell.name == R14SRAM* || .base_cell.name == R14RF* || .base_cell.name == R14ROM*}] {
  set_db $m .place_status fixed
}
set_db finish_floorplan_active_objs {core macro}
# --- endcaps + well taps (<= 25 um)
set_db add_endcaps_left_edge ENDCAPLEFT_X1_SVT
set_db add_endcaps_right_edge ENDCAPRIGHT_X1_SVT
add_endcaps
add_well_taps -cell WELLTAP_X1_SVT -cell_interval 25.0 -checker_board
# --- power grid: M1 followpins, M5/M6 mesh on-track, M7-M9 global
route_special -connect core_pin -nets {VDD VSS}
add_stripes -layer M5 -direction vertical   -nets {VDD VSS} -width 0.048 -spacing 0.060 -set_to_set_distance 5.400 -start_offset 0.054
add_stripes -layer M6 -direction horizontal -nets {VDD VSS} -width 0.088 -spacing 0.092 -set_to_set_distance 5.400 -start_offset 0.0
add_stripes -layer M7 -direction vertical   -nets {VDD VSS} -width 0.048 -spacing 0.060 -set_to_set_distance 10.800 -start_offset 0.054
add_stripes -layer M8 -direction horizontal -nets {VDD VSS} -width 0.128 -spacing 0.142 -set_to_set_distance 21.600
add_stripes -layer M9 -direction vertical   -nets {VDD VSS} -width 0.200 -spacing 0.232 -set_to_set_distance 43.200 -start_offset 0.108
# --- power switches for switched domains (UPF): simple header columns, mother-daughter chain
# add_power_switches -power_domain PD_SW -column -checker_board -horizontal_pitch 30.24 \
#     -switch_module_instance -enable_pin_input SLEEP -enable_pin_output SLEEPOUT -global_switch_cell_name HDRSW_X2_SVT
# --- dont-use
foreach p $R14N7_DONT_USE { set_db [get_db lib_cells $p] .dont_use true }
set_db opt_leakage_to_dynamic_ratio 0.5
set_db cts_buffer_cells   {CKBUF_X4_SVT CKBUF_X8_SVT CKBUF_X12_SVT CKBUF_X16_SVT}
set_db cts_inverter_cells {CKINV_X4_SVT CKINV_X8_SVT CKINV_X12_SVT CKINV_X16_SVT}
set_db cts_clock_gating_cells {ICGPRE_X2_SVT ICGPRE_X4_SVT ICGPRE_X8_SVT}
set_db cts_logic_cells {CKMUX2_X2_SVT CKAND2_X2_SVT CKOR2_X2_SVT CKXOR2_X2_SVT}
set_db add_fillers_cells {FILL64_X1_SVT FILL32_X1_SVT FILL16_X1_SVT FILL8_X1_SVT FILL4_X1_SVT FILL2_X1_SVT FILL1_X1_SVT}
set_db add_fillers_with_drc false
# decaps before fillers:  add_decaps -cells {DCAP64_X1_SVT DCAP32_X1_SVT DCAP16_X1_SVT} -total_cap 2000
# gate-array ECO: fill spare area with GFILL tiles before final fill to enable metal-only ECO
# add_fillers -base_cells {GFILL16_X1_SVT GFILL8_X1_SVT GFILL4_X1_SVT GFILL2_X1_SVT GFILL1_X1_SVT} -prefix GAFILL
