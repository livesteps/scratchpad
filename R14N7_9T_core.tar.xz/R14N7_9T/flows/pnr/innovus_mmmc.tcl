# Cadence MMMC for R14N7 -- 12 signoff corners (generated from gen/tech.py)
source $::env(R14N7_HOME)/flows/synth/r14n7_common.tcl
set MODEL [expr {[info exists ::env(R14N7_MODEL)] ? $::env(R14N7_MODEL) : "ccs"}]
create_library_set -name ls_ss_0p63v_m40c -timing [r14n7_libs ss_0p63v_m40c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_ss_0p63v_m40c.aocv]
create_opcond -name oc_ss_0p63v_m40c -process 1 -voltage 0.630 -temperature -40
create_timing_condition -name tc_ss_0p63v_m40c -library_sets ls_ss_0p63v_m40c -opcond oc_ss_0p63v_m40c
create_library_set -name ls_ss_0p63v_0c -timing [r14n7_libs ss_0p63v_0c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_ss_0p63v_0c.aocv]
create_opcond -name oc_ss_0p63v_0c -process 1 -voltage 0.630 -temperature 0
create_timing_condition -name tc_ss_0p63v_0c -library_sets ls_ss_0p63v_0c -opcond oc_ss_0p63v_0c
create_library_set -name ls_ss_0p63v_125c -timing [r14n7_libs ss_0p63v_125c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_ss_0p63v_125c.aocv]
create_opcond -name oc_ss_0p63v_125c -process 1 -voltage 0.630 -temperature 125
create_timing_condition -name tc_ss_0p63v_125c -library_sets ls_ss_0p63v_125c -opcond oc_ss_0p63v_125c
create_library_set -name ls_ss_0p54v_m40c -timing [r14n7_libs ss_0p54v_m40c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_ss_0p54v_m40c.aocv]
create_opcond -name oc_ss_0p54v_m40c -process 1 -voltage 0.540 -temperature -40
create_timing_condition -name tc_ss_0p54v_m40c -library_sets ls_ss_0p54v_m40c -opcond oc_ss_0p54v_m40c
create_library_set -name ls_tt_0p70v_25c -timing [r14n7_libs tt_0p70v_25c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_tt_0p70v_25c.aocv]
create_opcond -name oc_tt_0p70v_25c -process 1 -voltage 0.700 -temperature 25
create_timing_condition -name tc_tt_0p70v_25c -library_sets ls_tt_0p70v_25c -opcond oc_tt_0p70v_25c
create_library_set -name ls_tt_0p70v_85c -timing [r14n7_libs tt_0p70v_85c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_tt_0p70v_85c.aocv]
create_opcond -name oc_tt_0p70v_85c -process 1 -voltage 0.700 -temperature 85
create_timing_condition -name tc_tt_0p70v_85c -library_sets ls_tt_0p70v_85c -opcond oc_tt_0p70v_85c
create_library_set -name ls_tt_0p60v_25c -timing [r14n7_libs tt_0p60v_25c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_tt_0p60v_25c.aocv]
create_opcond -name oc_tt_0p60v_25c -process 1 -voltage 0.600 -temperature 25
create_timing_condition -name tc_tt_0p60v_25c -library_sets ls_tt_0p60v_25c -opcond oc_tt_0p60v_25c
create_library_set -name ls_ff_0p77v_m40c -timing [r14n7_libs ff_0p77v_m40c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_ff_0p77v_m40c.aocv]
create_opcond -name oc_ff_0p77v_m40c -process 1 -voltage 0.770 -temperature -40
create_timing_condition -name tc_ff_0p77v_m40c -library_sets ls_ff_0p77v_m40c -opcond oc_ff_0p77v_m40c
create_library_set -name ls_ff_0p77v_0c -timing [r14n7_libs ff_0p77v_0c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_ff_0p77v_0c.aocv]
create_opcond -name oc_ff_0p77v_0c -process 1 -voltage 0.770 -temperature 0
create_timing_condition -name tc_ff_0p77v_0c -library_sets ls_ff_0p77v_0c -opcond oc_ff_0p77v_0c
create_library_set -name ls_ff_0p77v_125c -timing [r14n7_libs ff_0p77v_125c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_ff_0p77v_125c.aocv]
create_opcond -name oc_ff_0p77v_125c -process 1 -voltage 0.770 -temperature 125
create_timing_condition -name tc_ff_0p77v_125c -library_sets ls_ff_0p77v_125c -opcond oc_ff_0p77v_125c
create_library_set -name ls_sf_0p70v_25c -timing [r14n7_libs sf_0p70v_25c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_sf_0p70v_25c.aocv]
create_opcond -name oc_sf_0p70v_25c -process 1 -voltage 0.700 -temperature 25
create_timing_condition -name tc_sf_0p70v_25c -library_sets ls_sf_0p70v_25c -opcond oc_sf_0p70v_25c
create_library_set -name ls_fs_0p70v_25c -timing [r14n7_libs fs_0p70v_25c $MODEL] -aocv [glob -nocomplain $R14N7_HOME/stdcell/*/ocv/*_fs_0p70v_25c.aocv]
create_opcond -name oc_fs_0p70v_25c -process 1 -voltage 0.700 -temperature 25
create_timing_condition -name tc_fs_0p70v_25c -library_sets ls_fs_0p70v_25c -opcond oc_fs_0p70v_25c
create_rc_corner -name rc_typical -temperature 25
create_rc_corner -name rc_cworst_t -temperature 125
create_rc_corner -name rc_cbest -temperature -40
create_delay_corner -name dc_ss_0p63v_m40c -timing_condition tc_ss_0p63v_m40c -rc_corner rc_cworst_t
create_delay_corner -name dc_ss_0p63v_0c -timing_condition tc_ss_0p63v_0c -rc_corner rc_cworst_t
create_delay_corner -name dc_ss_0p63v_125c -timing_condition tc_ss_0p63v_125c -rc_corner rc_cworst_t
create_delay_corner -name dc_ss_0p54v_m40c -timing_condition tc_ss_0p54v_m40c -rc_corner rc_cworst_t
create_delay_corner -name dc_tt_0p70v_25c -timing_condition tc_tt_0p70v_25c -rc_corner rc_typical
create_delay_corner -name dc_tt_0p70v_85c -timing_condition tc_tt_0p70v_85c -rc_corner rc_typical
create_delay_corner -name dc_tt_0p60v_25c -timing_condition tc_tt_0p60v_25c -rc_corner rc_typical
create_delay_corner -name dc_ff_0p77v_m40c -timing_condition tc_ff_0p77v_m40c -rc_corner rc_cbest
create_delay_corner -name dc_ff_0p77v_0c -timing_condition tc_ff_0p77v_0c -rc_corner rc_cbest
create_delay_corner -name dc_ff_0p77v_125c -timing_condition tc_ff_0p77v_125c -rc_corner rc_cbest
create_delay_corner -name dc_sf_0p70v_25c -timing_condition tc_sf_0p70v_25c -rc_corner rc_typical
create_delay_corner -name dc_fs_0p70v_25c -timing_condition tc_fs_0p70v_25c -rc_corner rc_typical
create_constraint_mode -name func -sdc_files [list $::env(SDC)]
create_analysis_view -name av_ss_0p63v_m40c -constraint_mode func -delay_corner dc_ss_0p63v_m40c
create_analysis_view -name av_ss_0p63v_0c -constraint_mode func -delay_corner dc_ss_0p63v_0c
create_analysis_view -name av_ss_0p63v_125c -constraint_mode func -delay_corner dc_ss_0p63v_125c
create_analysis_view -name av_ss_0p54v_m40c -constraint_mode func -delay_corner dc_ss_0p54v_m40c
create_analysis_view -name av_tt_0p70v_25c -constraint_mode func -delay_corner dc_tt_0p70v_25c
create_analysis_view -name av_tt_0p70v_85c -constraint_mode func -delay_corner dc_tt_0p70v_85c
create_analysis_view -name av_tt_0p60v_25c -constraint_mode func -delay_corner dc_tt_0p60v_25c
create_analysis_view -name av_ff_0p77v_m40c -constraint_mode func -delay_corner dc_ff_0p77v_m40c
create_analysis_view -name av_ff_0p77v_0c -constraint_mode func -delay_corner dc_ff_0p77v_0c
create_analysis_view -name av_ff_0p77v_125c -constraint_mode func -delay_corner dc_ff_0p77v_125c
create_analysis_view -name av_sf_0p70v_25c -constraint_mode func -delay_corner dc_sf_0p70v_25c
create_analysis_view -name av_fs_0p70v_25c -constraint_mode func -delay_corner dc_fs_0p70v_25c
set_analysis_view -setup [list av_ss_0p63v_m40c av_ss_0p63v_0c av_ss_0p63v_125c av_ss_0p54v_m40c av_tt_0p70v_25c] -hold [list av_ff_0p77v_m40c av_ff_0p77v_0c av_ff_0p77v_125c av_tt_0p70v_25c av_sf_0p70v_25c av_fs_0p70v_25c] -leakage av_ff_0p77v_125c -dynamic av_tt_0p70v_85c
