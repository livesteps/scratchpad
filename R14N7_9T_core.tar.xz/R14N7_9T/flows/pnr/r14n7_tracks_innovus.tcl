# R14N7 routing tracks (Innovus) -- generated from gen/tech.py
deleteTracks
add_tracks -layer M1 -direction vertical -pitch 0.054 -offset 0.027
add_tracks -layer M2 -direction horizontal -pitch 0.036 -offset 0.000 -mask_pattern {1 2}
add_tracks -layer M3 -direction vertical -pitch 0.054 -offset 0.027 -mask_pattern {1 2}
add_tracks -layer M4 -direction horizontal -pitch 0.081 -offset 0.000
add_tracks -layer M5 -direction vertical -pitch 0.108 -offset 0.054
add_tracks -layer M6 -direction horizontal -pitch 0.081 -offset 0.000
add_tracks -layer M7 -direction vertical -pitch 0.108 -offset 0.054
add_tracks -layer M8 -direction horizontal -pitch 0.162 -offset 0.000
add_tracks -layer M9 -direction vertical -pitch 0.216 -offset 0.108
