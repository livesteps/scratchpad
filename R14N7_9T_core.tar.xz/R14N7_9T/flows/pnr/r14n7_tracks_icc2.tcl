# R14N7 routing tracks (ICC2) -- generated from gen/tech.py
remove_tracks -all
create_track -layer M1 -dir Y -space 0.054 -coord 0.027
create_track -layer M2 -dir X -space 0.036 -coord 0.000 -mask_pattern {mask_one mask_two}
create_track -layer M3 -dir Y -space 0.054 -coord 0.027 -mask_pattern {mask_one mask_two}
create_track -layer M4 -dir X -space 0.081 -coord 0.000
create_track -layer M5 -dir Y -space 0.108 -coord 0.054
create_track -layer M6 -dir X -space 0.081 -coord 0.000
create_track -layer M7 -dir Y -space 0.108 -coord 0.054
create_track -layer M8 -dir X -space 0.162 -coord 0.000
create_track -layer M9 -dir Y -space 0.216 -coord 0.108
set_attribute [get_site_defs coreSite] symmetry {Y}
set_attribute [get_layers {M1 M3 M5 M7 M9}] routing_direction vertical
set_attribute [get_layers {M2 M4 M6 M8}] routing_direction horizontal
