# Synopsys ICC2 / Fusion Compiler setup for R14N7
source $::env(R14N7_HOME)/flows/synth/r14n7_common.tcl
create_lib r14n7_nlib -technology $::env(R14N7_HOME)/tech/r14n7_tech.lef -ref_libs [r14n7_lefs]
# (build NDM frames/timing with lm_shell from the LEF + CCS libs:  read_lef ; read_db/read_lib ; write_lib)
source $::env(R14N7_HOME)/flows/pnr/r14n7_tracks_icc2.tcl
set_attribute [get_site_defs coreSite] is_default true
set_app_options -name place.legalize.enable_advanced_legalizer -value true
set_app_options -name route.common.global_min_layer_mode -value hard
set_app_options -name route.common.net_min_layer_mode -value soft
set_ignored_layers -min_routing_layer M2 -max_routing_layer M7
create_tap_cells -lib_cell */WELLTAP_X1_SVT -distance 25.0 -pattern stagger
create_boundary_cells -left_boundary_cell */ENDCAPLEFT_X1_SVT -right_boundary_cell */ENDCAPRIGHT_X1_SVT
set_lib_cell_purpose -include cts [get_lib_cells {*/CKBUF_X* */CKINV_X* */ICG*}]
foreach p $R14N7_DONT_USE { set_lib_cell_purpose -exclude optimization [get_lib_cells $p] }
