#!/bin/bash
# Gate-level / RTL simulation with R14N7 models (iverilog shown; VCS/Xcelium use the same file list)
#   run_rtl_sim.sh <tb.v> <netlist.v> [-DR14_PG_PINS]
VT_FILES=""
for vt in HVT SVT LVT ULVT; do v=${vt,,}; VT_FILES="$VT_FILES $R14N7_HOME/stdcell/$vt/verilog/${R14N7_LIBPFX}_std_$v.v $R14N7_HOME/pmk/$vt/verilog/${R14N7_LIBPFX}_pmk_$v.v"; done
iverilog -g2005 $3 -o sim.out $R14N7_HOME/stdcell/SVT/verilog/r14n7_udp.v $VT_FILES \
   $R14N7_HOME/memory/verilog/r14n7_mem.v $R14N7_HOME/io/verilog/r14n7_io18.v "$2" "$1" && vvp -n sim.out
# ROM instances load <name>.hex from the run directory: cp $R14N7_HOME/memory/rom_code/*.hex .
