#!/bin/bash
# usage: run_lvs.sh <gds> <top> <cdl>
exec $R14N7_HOME/flows/calibre/r14n7_calibre_run.sh lvs "$@"
