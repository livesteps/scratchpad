#!/bin/bash
# Verilog gate-level netlist -> SPICE for Calibre LVS (source side).
#   run_v2lvs.sh <top.v> <top_cell> [VT list, default "HVT SVT LVT ULVT"]
# Uses the port-only interface libraries (*_v2lvs.v, port order == CDL) and the CDL cell netlists.
set -e
: ${R14N7_HOME:?source flows/setup/r14n7_env.sh}
NET=$1; TOP=$2; VTS=${3:-"HVT SVT LVT ULVT"}; P=$R14N7_LIBPFX
LIBS=""; CDLS=""
for vt in $VTS; do v=${vt,,}
  LIBS="$LIBS -l $R14N7_HOME/stdcell/$vt/verilog/${P}_std_${v}_v2lvs.v -l $R14N7_HOME/pmk/$vt/verilog/${P}_pmk_${v}_v2lvs.v"
  CDLS="$CDLS $R14N7_HOME/stdcell/$vt/spice/${P}_std_${v}.cdl $R14N7_HOME/pmk/$vt/spice/${P}_pmk_${v}.cdl"
done
LIBS="$LIBS -l $R14N7_HOME/memory/verilog/r14n7_mem_v2lvs.v -l $R14N7_HOME/io/verilog/r14n7_io18_v2lvs.v"
CDLS="$CDLS $R14N7_HOME/memory/spice/r14n7_mem.cdl $R14N7_HOME/io/spice/r14n7_io18.cdl"
cat $CDLS > ${TOP}_cells.cdl
# -s0/-s1: nets for constant 1'b0/1'b1;  -i: infer power pins (VDD/VSS) on cell instances without explicit PG connections
v2lvs -v $NET $LIBS -lsp ${TOP}_cells.cdl -s ${TOP}_cells.cdl -o ${TOP}.sp -s0 VSS -s1 VDD -i -n
echo "wrote ${TOP}.sp (includes ${TOP}_cells.cdl);  LVS: R14_CDL=${TOP}.sp run_lvs.sh <gds> ${TOP}"
