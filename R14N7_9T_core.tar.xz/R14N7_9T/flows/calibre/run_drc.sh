#!/bin/bash
# usage: run_drc.sh <gds> <top>
exec $R14N7_HOME/flows/calibre/r14n7_calibre_run.sh drc "$@"
