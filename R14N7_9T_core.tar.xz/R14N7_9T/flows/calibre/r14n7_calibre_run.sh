#!/bin/bash
# Run any R14N7 Calibre deck.   r14n7_calibre_run.sh <drc|lvs|erc|density|antenna> <gds> <top> [cdl] [cpus]
set -e
CHK=$1; export R14_GDS=$(readlink -f $2); export R14_TOP=$3; [ -n "$4" ] && export R14_CDL=$(readlink -f $4)
CPUS=${5:-8}; DECK=$R14N7_HOME/calibre/r14n7_${CHK}.svrf
mkdir -p calibre_${CHK}_${R14_TOP} && cd calibre_${CHK}_${R14_TOP}
case $CHK in
  lvs) calibre -lvs -hier -spice ${R14_TOP}.sp -turbo $CPUS -hyper $DECK | tee lvs.log ;;
  erc) calibre -lvs -hier -turbo $CPUS $DECK | tee erc.log ;;
  *)   calibre -drc -hier -turbo $CPUS -hyper $DECK | tee ${CHK}.log ;;
esac
