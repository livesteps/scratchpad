#!/bin/bash
# usage: run_antenna.sh <gds> <top>
exec $R14N7_HOME/flows/calibre/r14n7_calibre_run.sh antenna "$@"
