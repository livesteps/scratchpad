#!/bin/bash
# R14N7 PDK environment.  source flows/setup/r14n7_env.sh [<pdk_root>]
export R14N7_HOME=${1:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}
export R14N7_LIBPFX=$(cat $R14N7_HOME/tech/libprefix 2>/dev/null || echo r14n7t6)
export R14N7_VTS="HVT SVT LVT ULVT"
export R14N7_CORNERS="ss_0p63v_m40c ss_0p63v_0c ss_0p63v_125c ss_0p54v_m40c tt_0p70v_25c tt_0p70v_85c tt_0p60v_25c ff_0p77v_m40c ff_0p77v_0c ff_0p77v_125c sf_0p70v_25c fs_0p70v_25c"
export R14N7_TECHLEF=$R14N7_HOME/tech/r14n7_tech.lef
export R14N7_SPICE_LIB=$R14N7_HOME/models/spice/r14n7.l
r14n7_lib() {  # r14n7_lib <std|pmk|mem|io18> <VT|-> <corner> <nldm|ccs|ecsm>
  case $1 in
    std) echo $R14N7_HOME/stdcell/$2/liberty/$4/${R14N7_LIBPFX}_std_${2,,}_$3_$4.lib ;;
    pmk) echo $R14N7_HOME/pmk/$2/liberty/$4/${R14N7_LIBPFX}_pmk_${2,,}_$3_$4.lib ;;
    mem) echo $R14N7_HOME/memory/liberty/$4/${R14N7_LIBPFX}_mem_$3_$4.lib ;;
    io18) echo $R14N7_HOME/io/liberty/$4/${R14N7_LIBPFX}_io18_$3_$4.lib ;;
  esac
}
export -f r14n7_lib
echo "R14N7_HOME=$R14N7_HOME"
