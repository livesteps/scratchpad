# Cadence Genus setup for R14N7
source $::env(R14N7_HOME)/flows/synth/r14n7_common.tcl
set CORNER [expr {[info exists ::env(CORNER)] ? $::env(CORNER) : "ss_0p63v_m40c"}]
read_mmmc $::env(R14N7_HOME)/flows/pnr/innovus_mmmc.tcl
read_physical -lef [r14n7_lefs]
set_db library_domain_by_mode 0
foreach p $R14N7_DONT_USE { set_db [get_db lib_cells $p] .dont_use true }
set_db [get_db lib_cells */*_ULVT] .dont_use true
set_db lp_insert_clock_gating true
set_db lp_clock_gating_style latch
set_db lp_clock_gating_control_point precontrol
set_db lp_clock_gating_min_flops 4
set_db use_multibit_cells true
set_db multibit_allow_unused_bits false
set_db dft_scan_style muxed_scan
set_db leakage_power_effort medium
