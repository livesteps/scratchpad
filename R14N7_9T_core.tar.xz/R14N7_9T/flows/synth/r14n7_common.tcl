# R14N7 common synthesis/P&R settings (tool-neutral Tcl data)
set R14N7_HOME $::env(R14N7_HOME)
set R14N7_VTS {HVT SVT LVT ULVT}
set P [expr {[info exists ::env(R14N7_LIBPFX)] ? $::env(R14N7_LIBPFX) : [string trim [read [open $R14N7_HOME/tech/libprefix]]]}]
proc r14n7_lib {grp vt corner model} {
  global R14N7_HOME P
  switch $grp {
    std  { return "$R14N7_HOME/stdcell/$vt/liberty/$model/${P}_std_[string tolower $vt]_${corner}_${model}.lib" }
    pmk  { return "$R14N7_HOME/pmk/$vt/liberty/$model/${P}_pmk_[string tolower $vt]_${corner}_${model}.lib" }
    mem  { return "$R14N7_HOME/memory/liberty/$model/${P}_mem_${corner}_${model}.lib" }
    io18 { return "$R14N7_HOME/io/liberty/$model/${P}_io18_${corner}_${model}.lib" }
  }
}
proc r14n7_libs {corner {model nldm} {vts {HVT SVT LVT ULVT}}} {
  set l {}
  foreach vt $vts { lappend l [r14n7_lib std $vt $corner $model] [r14n7_lib pmk $vt $corner $model] }
  lappend l [r14n7_lib mem - $corner $model] [r14n7_lib io18 - $corner $model]
  return $l
}
proc r14n7_lefs {{vts {HVT SVT LVT ULVT}}} {
  global R14N7_HOME P
  set l [list $R14N7_HOME/tech/r14n7_tech.lef]
  foreach vt $vts { lappend l $R14N7_HOME/stdcell/$vt/lef/${P}_std_[string tolower $vt].lef $R14N7_HOME/pmk/$vt/lef/${P}_pmk_[string tolower $vt].lef }
  lappend l $R14N7_HOME/memory/lef/r14n7_mem.lef $R14N7_HOME/io/lef/r14n7_io18.lef
  return $l
}
# cells never to be used by synthesis/optimization (physical-only, ECO, PMK placed by UPF/insertion)
set R14N7_DONT_USE {*/FILL* */DCAP* */WELLTAP* */ENDCAP* */ANTENNA* */G* */DLY* */CKD* */HDRSW* */FTRSW*
                    */ISO* */LVL* */RET* */AON* */TIE* */R14SRAM* */R14RF* */R14ROM* */P*18 */PAD* */PCLAMP* */PFILL* */PBRK* */PCORNER* */BONDPAD*}
set R14N7_CLOCK_CELLS {*/CKINV* */CKBUF* */CKMUX2* */CKAND2* */CKNAND2* */CKOR2* */CKNOR2* */CKXOR2* */ICG*}
set R14N7_ICG_CELL ICGPRE_X1_SVT
set R14N7_TIEHI TIEHI_X1_SVT
set R14N7_TIELO TIELO_X1_SVT
