# Synopsys Design Compiler / Fusion Compiler setup for R14N7 (multi-Vt, MBIT, ICG, UPF)
source $::env(R14N7_HOME)/flows/synth/r14n7_common.tcl
set CORNER  [expr {[info exists ::env(CORNER)] ? $::env(CORNER) : "ss_0p63v_m40c"}]
set MODEL   ccs
set_app_var target_library [r14n7_libs $CORNER $MODEL {SVT LVT HVT}]
set_app_var link_library   [concat * [r14n7_libs $CORNER $MODEL]]
foreach p $R14N7_DONT_USE { set_dont_use [get_lib_cells $p] }
# ULVT only for critical paths: start with ULVT dont_use, release in incremental compile
set_dont_use [get_lib_cells */*_ULVT]
# multi-Vt leakage recovery
set_multi_vth_constraint -lvth_groups {lvt ulvt} -lvth_percentage 15 -type soft
# clock gating with integrated pre-control ICG (DFT test pin SE)
set_clock_gating_style -sequential_cell latch -positive_edge_logic integrated -control_point before \
                       -control_signal scan_enable -minimum_bitwidth 4 -max_fanout 32
# multi-bit banking (ff_bank cells MBDFF/MBSDFF/MBDFFR/MBSDFFR 2..32)
set_app_var hdlin_infer_multibit default_all
set_multibit_options -mode timing_driven
# scan style
set_scan_configuration -style multiplexed_flip_flop
# tie cells
set_attribute [get_lib_cells */TIE*] dont_use false
set_app_var compile_seqmap_propagate_constants true
# UPF (optional)
if {[info exists ::env(UPF)]} { load_upf $::env(UPF) }
