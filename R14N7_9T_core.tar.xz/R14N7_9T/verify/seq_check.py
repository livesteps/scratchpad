"""Co-simulation check of sequential / state-holding cells: identical random stimulus is
applied to (a) the transistor netlist in ngspice (level-1 stand-in MOS models) and (b) the
Verilog UDP model in iverilog; sampled outputs must agree wherever Verilog is not X."""
import sys, os, re, random, subprocess
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "gen"))
import cells as C, spice, verilog
VT = sys.argv[1] if len(sys.argv) > 1 else "SVT"
std, pmk = C.catalog(VT)
sel = [c for c in std + pmk if c.drive in ("X1",) and c.vkind in ("ff", "latch", "icg", "ret", "isolat", "mbff", "tpctl", "bsc")
       and c.bits() <= 4 and not c.base.startswith("G")]
T = 4000; N = 40; VDD = 0.7
random.seed(7)
def bitnames(p):
    return ["%s<%d>" % (p.name, b) for b in range(p.width)] if p.width > 1 else [p.name]
def vbit(n):
    m = re.match(r"(\w+)<(\d+)>", n); return "%s[%s]" % m.groups() if m else n
import tempfile
TMP = tempfile.mkdtemp(prefix="r14seq_")
verilog.write_udp(TMP + "/udp.v"); verilog.write(TMP + "/cells.v", sel, "check")
tot_bad = 0; tot = 0
for c in sel:
    ins = [n for p in c.inputs() for n in bitnames(p)]
    outs = [n for p in c.outputs() for n in bitnames(p)]
    clk = [p.name for p in c.inputs() if p.role == "clock"]
    ev = {n: [] for n in ins}
    for n in ins:
        if n in clk:
            continue
        v = 1 if (n.startswith(("RN", "SN", "NRET"))) else random.randint(0, 1)
        for k in range(N):
            if n == "ISO":
                ev[n].append((k * T + 500, random.randint(0, 1))); continue
            if n.startswith(("RN", "SN")):
                nv = 0 if (k == 0 and n.startswith("RN")) else (1 if random.random() > 0.12 else 0)
            elif n.startswith("NRET"):
                nv = 0 if 18 <= k < 22 else 1
            else:
                nv = random.randint(0, 1)
            ev[n].append((k * T + 1000, nv))
    # spice
    L = ["* seq check", ".model nch nmos level=1 vto=0.22 kp=3e-4 lambda=0.05 tox=2e-9 cgso=2e-10 cgdo=2e-10", ".model pch pmos level=1 vto=-0.22 kp=2e-4 lambda=0.05 tox=2e-9 cgso=2e-10 cgdo=2e-10",
         "VDD vdd 0 %g" % VDD]
    for ln in spice.subckt(c):
        m = re.match(r"(M\S+) (\S+) (\S+) (\S+) (\S+) (\S+) L=(\d+)n NFIN=(\d+) NF=(\d+)", ln)
        if m:
            nm, d, g, s, b, mod, l, nfin, nf = m.groups()
            ln = "%s %s %s %s %s %s W=%.2fu L=%.2fu" % (nm, d, g, s, b, "nch" if mod.startswith("n") else "pch", int(nfin) * int(nf) * 0.1, 0.05 * int(l) / 20)
        L.append(ln)
    def node(n): return "n_" + re.sub(r"[<>]", "_", n)
    for n in ins:
        if n in clk:
            pts = ["0 0"]
            for k in range(N):
                pts += ["%dp 0" % (k * T + 1950), "%dp %g" % (k * T + 2000, VDD), "%dp %g" % (k * T + 3950, VDD), "%dp 0" % (k * T + 4000)]
        else:
            pts = []; cur = None
            for (t, v) in ev[n]:
                if cur is None: pts.append("0 %g" % (v * VDD))
                else: pts += ["%dp %g" % (t - 50, cur * VDD), "%dp %g" % (t, v * VDD)]
                cur = v
        L.append("V%s %s 0 PWL(%s)" % (node(n), node(n), " ".join(pts)))
    conn = [node(n) for p in c.pins for n in bitnames(p)] + ["vdd" if "VDD" in n or "VV" == n[:2] and "S" not in n else "0" for n, t, v in c.pg]
    conn = [node(n) for p in c.pins for n in bitnames(p)] + [("0" if t.endswith("ground") else "vdd") for n, t, v in c.pg]
    L.append("XDUT %s %s" % (" ".join(conn), c.name))
    samples = [k * T + o for k in range(N) for o in (900, 2900)]
    L += [".tran 5p %dp" % (N * T), ".control", "run", "set width=400"]
    for s in samples:
        L.append("meas tran s%d FIND %s AT=%dp" % (s, " ".join("v(%s)" % node(o) for o in outs[:1]), s))
    for o in outs[1:]:
        for s in samples:
            L.append("meas tran s%d_%s FIND v(%s) AT=%dp" % (s, node(o), node(o), s))
    L += ["quit", ".endc", ".end"]
    open(TMP + "/%s.cir" % c.name, "w").write("\n".join(L) + "\n")
    r = subprocess.run(["ngspice", "-b", TMP + "/%s.cir" % c.name], capture_output=True, text=True)
    sv = {}
    for m in re.finditer(r"^(s\d+(?:_\S+)?)\s*=\s*([-+0-9.eE]+)", r.stdout, re.M):
        sv[m.group(1).lower()] = float(m.group(2))
    # verilog tb
    V = ["`timescale 1ps/1fs", "module tb;"]
    for p in c.pins:
        rng = "[%d:0] " % (p.width - 1) if p.width > 1 else ""
        V.append("  %s %s%s;" % ("reg" if p.dir == "input" else "wire", rng, p.name))
    V.append("  %s dut (%s);" % (c.name, ", ".join(".%s(%s)" % (p.name, p.name) for p in c.pins)))
    V.append("  initial begin")
    for n in ins:
        if n in clk: V.append("    %s = 0;" % vbit(n))
    for n in ins:
        if n not in clk: V.append("    %s = %d;" % (vbit(n), ev[n][0][1]))
    V.append("  end")
    for n in clk:
        V.append("  initial begin #1975; forever begin %s = 1; #2000; %s = 0; #2000; end end" % (n, n))
    for n in ins:
        if n in clk: continue
        V.append("  initial begin")
        last = 0
        for (t, v) in ev[n][1:]:
            V.append("    #%d %s = %d;" % (t - 25 - last, vbit(n), v)); last = t - 25
        V.append("  end")
    V.append("  initial begin")
    last = 0
    for s in samples:
        V.append('    #%d $display("S %d %%b", {%s});' % (s - last, s, ", ".join(vbit(o) for o in outs))); last = s
    V += ["    $finish;", "  end", "endmodule"]
    open(TMP + "/tb.v", "w").write("\n".join(V) + "\n")
    rr = subprocess.run("iverilog -g2005 -o " + TMP + "/a.out " + TMP + "/udp.v " + TMP + "/cells.v " + TMP + "/tb.v && vvp -n " + TMP + "/a.out",
                        shell=True, capture_output=True, text=True)
    vv = {}
    for m in re.finditer(r"^S (\d+) (\S+)", rr.stdout, re.M): vv[int(m.group(1))] = m.group(2)
    bad = 0; cmpd = 0; dbg = os.environ.get("DBG") == c.name; dl = []
    for s in samples:
        vs = vv.get(s, "")
        for i, o in enumerate(outs):
            vb = vs[i] if i < len(vs) else "x"
            if vb not in "01": continue
            key = ("s%d" % s) if i == 0 else ("s%d_%s" % (s, node(o))).lower()
            sp = sv.get(key)
            if sp is None: continue
            cmpd += 1
            spb = 1 if sp > 0.6 * VDD else (0 if sp < 0.1 * VDD else None)
            if dbg: dl.append("%d v=%s s=%s" % (s, vb, spb))
            if spb != int(vb):
                bad += 1
    if dbg: print(" ".join(dl))
    tot += 1; tot_bad += (bad > 0)
    print("%-22s compared %4d  mismatches %3d %s" % (c.name, cmpd, bad, "" if cmpd else ("NO DATA " + rr.stderr[-200:] + r.stderr[-200:])))
print("cells %d, failing %d" % (tot, tot_bad))
