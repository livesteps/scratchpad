"""Transistor-level functional check: every combinational/PMK-comb SPICE subckt is
DC-solved for every input vector (ngspice, level-1 stand-in MOS models) and compared
with the Liberty function.  Usage: spice_truth.py <netlist.sp> [<netlist2.sp>...]"""
import sys, re, itertools, subprocess, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "gen"))
import cells as C, boolexpr as bx
VT = sys.argv[1] if len(sys.argv) > 1 else "SVT"
std, pmk = C.catalog(VT)
todo = [c for c in std + pmk if c.vkind == "comb" and c.funcs and c.bits() == 1
        and all(v in ("0", "1") or True for v in c.funcs.values())]
nets = {}
import spice
L = ["* truth table check", ".model nch nmos level=1 vto=0.22 kp=3e-4 lambda=0.05",
     ".model pch pmos level=1 vto=-0.22 kp=2e-4 lambda=0.05",
     ".model dio_n d", ".model dio_p d",
     "VDD vdd 0 0.7", "VDDL vddl 0 0.6", "VDDB vddb 0 0.7"]
for c in todo:
    for ln in spice.subckt(c):
        m = re.match(r"(M\S+) (\S+) (\S+) (\S+) (\S+) (\S+) L=(\d+)n NFIN=(\d+) NF=(\d+)", ln)
        if m:
            nm, d, g, s, b, mod, l, nfin, nf = m.groups()
            w = int(nfin) * int(nf) * 0.1
            ln = "%s %s %s %s %s %s W=%.2fu L=%.2fu" % (nm, d, g, s, b, "nch" if mod.startswith("n") else "pch", w, 0.05 * int(l) / 20)
        L.append(ln)
chk = []
k = 0
for c in todo:
    ins = [p.name for p in c.inputs()]; outs = [p.name for p in c.outputs()]
    if len(ins) > 6: continue
    for vals in itertools.product((0, 1), repeat=len(ins)):
        env = dict(zip(ins, vals)); k += 1
        conn = []
        for p in c.pins:
            if p.dir == "input":
                hi = {"VDDL": "vddl", "VDDB": "vddb"}.get(p.pwr, "vdd")
                conn.append(hi if env[p.name] else "0")
            else:
                conn.append("o%d_%s" % (k, p.name))
        for n, t, v in c.pg:
            conn.append({"VDD": "vdd", "VSS": "0", "VDDL": "vddl", "VDDB": "vddb", "VDDR": "vdd", "VVDD": "vdd", "VVSS": "0"}[n])
        L.append("X%d %s %s" % (k, " ".join(conn), c.name))
        for o in outs:
            exp = bx.ev(bx.parse(c.funcs[o]), env)
            sup = {"VDDL": 0.6, "VDDB": 0.7}.get(c.pin(o).pwr, 0.7)
            chk.append((c.name, o, env, exp, "o%d_%s" % (k, o), sup))
L += [".control", "op", "set width=300"]
nodes = [x[4] for x in chk]
L += ["print " + " ".join("v(%s)" % n for n in nodes[i:i + 40]) for i in range(0, len(nodes), 40)]
L += ["quit", ".endc", ".end"]
import tempfile; _tf = tempfile.mkstemp(suffix=".cir")[1]
open(_tf, "w").write("\n".join(L) + "\n")
r = subprocess.run(["ngspice", "-b", _tf], capture_output=True, text=True)
vals = dict((m.group(1).lower(), float(m.group(2))) for m in re.finditer(r"v\((\S+)\)\s*=\s*([-+0-9.eE]+)", r.stdout))
bad = 0
for (cn, o, env, exp, node, sup) in chk:
    v = vals.get(node.lower())
    ok = v is not None and ((exp == 1 and v > 0.8 * sup) or (exp == 0 and v < 0.2 * sup))
    if not ok:
        bad += 1
        if bad < 25: print("FAIL", cn, o, env, "exp", exp, "got", v)
print("cells checked: %d, vectors: %d, failures: %d" % (len(set(x[0] for x in chk)), len(chk), bad))
if not vals: print(r.stdout[-3000:], r.stderr[-2000:])
