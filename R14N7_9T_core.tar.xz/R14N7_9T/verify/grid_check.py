"""Placement / routing grid checks on LEF (+ GDS cross-check).
 - macro SIZE is an integer number of sites (W) and rows (H)  [std/pmk: coreSite 0.054x0.270;
   memories: 0.108 x 0.270 placement grid; IO: ioSite 1.0 x 120 / cornerSite]
 - every pin rectangle is centred on its layer's routing track (pitch/offset from tech LEF)
 - every M1 std-cell pin has >= 2 on-grid M2 access points (M2 track crossing with full V1 landing)
 - all coordinates on the 0.001 um manufacturing grid and the LEF database grid (1/4000 um)
 - GDS pin shapes (pin datatype) match the LEF ports exactly (std/pmk)
Usage: grid_check.py <pdk_root>"""
import sys, os, re, glob
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "gen"))
from tech import METALS, LAYERS, PIN_DT, ROW_H
root = sys.argv[1]
TR = {m[0]: (m[1], m[2] / 1000.0, m[6] / 1000.0, m[3] / 1000.0) for m in METALS}
def on(v, g, off=0.0, tol=1e-6):
    k = (v - off) / g; return abs(k - round(k)) < tol / g
def parse(path):
    macros = {}; cur = None; pin = None; lay = None; inprop = False
    for ln in open(path):
        t = ln.split()
        if not t: continue
        if t[0] == "PROPERTYDEFINITIONS": inprop = True; continue
        if inprop:
            if t[:2] == ["END", "PROPERTYDEFINITIONS"]: inprop = False
            continue
        if t[0] == "MACRO": cur = {"pins": {}, "cls": ""}; macros[t[1]] = cur
        elif cur is None: continue
        elif t[0] == "CLASS": cur["cls"] = " ".join(t[1:-1])
        elif t[0] == "SIZE": cur["w"], cur["h"] = float(t[1]), float(t[3])
        elif t[0] == "PIN": pin = t[1]; cur["pins"][pin] = []
        elif t[0] == "LAYER": lay = t[1]
        elif t[0] == "RECT" and pin: cur["pins"][pin].append((lay, *map(float, t[1:5])))
        elif t[0] == "END" and len(t) > 1 and t[1] == pin: pin = None
        elif t[0] == "OBS": pin = None
    return macros
errs = {}; nchk = 0
def err(k, m): errs.setdefault(k, []).append(m)
groups = [("std", glob.glob(os.path.join(root, "stdcell", "*", "lef", "*.lef")) + glob.glob(os.path.join(root, "pmk", "*", "lef", "*.lef")), 0.054, ROW_H / 1000.0),
          ("mem", glob.glob(os.path.join(root, "memory", "lef", "*.lef")), 0.108, ROW_H / 1000.0),
          ("io", glob.glob(os.path.join(root, "io", "lef", "*.lef")), None, None)]
for g, files, sw, sh in groups:
    for f in files:
        for name, m in parse(f).items():
            nchk += 1
            if sw:
                if not on(m["w"], sw): err("SIZE.W off placement grid", name)
                if not on(m["h"], sh): err("SIZE.H off row grid", name)
            elif "CORNER" not in name and "BONDPAD" not in name:
                if not on(m["w"], 1.0) or not on(m["h"], 120.0): err("IO SIZE off ioSite", name)
            for pn, rects in m["pins"].items():
                for (lay, x0, y0, x1, y1) in rects:
                    for v in (x0, y0, x1, y1):
                        if not on(v, 0.001) or not on(v, 0.00025): err("OFFGRID mfg/DBU", "%s/%s" % (name, pn))
                    if lay not in TR: continue
                    d, p, off, w = TR[lay]
                    if pn in ("VDD", "VSS", "VDDM", "IOVDD", "IOVSS") and lay in ("M1", "M8"):
                        # rails / rings: centred on a horizontal track
                        if lay == "M1" and not on((y0 + y1) / 2, TR["M2"][1], TR["M2"][2]): err("RAIL off M2 track", "%s/%s" % (name, pn))
                        continue
                    if g == "io": continue      # pad pins align to the pad-ring placement grid, not the core grid
                    if d == "VERTICAL":
                        if not on((x0 + x1) / 2, p, off): err("PIN off %s track" % lay, "%s/%s" % (name, pn))
                    else:
                        if not on((y0 + y1) / 2, p, off): err("PIN off %s track" % lay, "%s/%s" % (name, pn))
                    if lay == "M1" and g == "std":
                        p2, o2, w2 = TR["M2"][1], TR["M2"][2], TR["M2"][3]
                        k0 = int((y0 - o2) // p2) - 1; ap = 0
                        for k in range(k0, k0 + 40):
                            y = o2 + k * p2
                            if y - w2 / 2 >= y0 - 1e-9 and y + w2 / 2 <= y1 + 1e-9: ap += 1
                        if ap < 2: err("PIN access points < 2", "%s/%s (%d)" % (name, pn, ap))
# GDS cross-check for std/pmk
try:
    import klayout.db as kdb
    for f in glob.glob(os.path.join(root, "stdcell", "*", "gds", "*.gds")) + glob.glob(os.path.join(root, "pmk", "*", "gds", "*.gds")):
        lef = parse(f.replace("/gds/", "/lef/").replace(".gds", ".lef"))
        ly = kdb.Layout(); ly.read(f); dbu = ly.dbu
        li = ly.find_layer(LAYERS["M1"][0][0], PIN_DT); lt = ly.find_layer(LAYERS["M1"][0][0], 10)
        for c in ly.each_cell():
            m = lef.get(c.name)
            if m is None: err("GDS cell missing in LEF", c.name); continue
            labels = {}
            for s in c.shapes(lt).each():
                if s.is_text(): labels.setdefault(s.text_string, []).append(s.text_pos)
            for pn, rects in m["pins"].items():
                for (lay, x0, y0, x1, y1) in rects:
                    if lay != "M1": continue
                    box = kdb.Box(int(round(x0 / dbu)), int(round(y0 / dbu)), int(round(x1 / dbu)), int(round(y1 / dbu)))
                    found = any(s.box == box for s in c.shapes(li).each() if s.is_box())
                    if not found: err("LEF pin not in GDS", "%s/%s" % (c.name, pn))
                if pn not in labels: err("GDS pin label missing", "%s/%s" % (c.name, pn))
except ImportError:
    print("klayout not available: GDS cross-check skipped")
print("macros checked: %d" % nchk)
if not errs: print("GRID CHECK PASS: sizes, pin tracks, access points, mfg/DBU grid, LEF<->GDS pins")
for k, v in sorted(errs.items()):
    print("FAIL %-28s %5d  e.g. %s" % (k, len(v), ", ".join(v[:4])))
