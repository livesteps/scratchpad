#!/bin/bash
# compile every Verilog model set with iverilog, with and without R14_PG_PINS
ROOT=$1; UDP=$(ls $ROOT/stdcell/SVT/verilog/r14n7_udp.v)
ok=0; bad=0
for vt in HVT SVT LVT ULVT; do
  for f in $ROOT/stdcell/$vt/verilog/*_std_*.v $ROOT/pmk/$vt/verilog/*_pmk_*.v; do
    for d in "" "-DR14_PG_PINS"; do
      if iverilog -g2005 $d -o /dev/null $UDP $f 2>/tmp/vc.err; then ok=$((ok+1)); else bad=$((bad+1)); echo "FAIL $f $d"; head -3 /tmp/vc.err; fi
    done
  done
done
for f in $ROOT/memory/verilog/*.v $ROOT/io/verilog/*.v; do
  for d in "" "-DR14_PG_PINS"; do iverilog -g2005 $d -o /dev/null $f && ok=$((ok+1)) || { bad=$((bad+1)); echo "FAIL $f"; }; done
done
for f in $ROOT/dft/atpg/verilog/*.v; do iverilog -g2005 -o /dev/null $UDP $f && ok=$((ok+1)) || { bad=$((bad+1)); echo "FAIL $f"; }; done
iverilog -g2005 -o /dev/null $ROOT/dft/rtl/*.v && ok=$((ok+1)) || bad=$((bad+1))
echo "verilog compile: $ok passed, $bad failed"
