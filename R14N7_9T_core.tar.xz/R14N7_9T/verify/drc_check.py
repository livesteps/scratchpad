"""Rule-table-driven DRC of generated GDS with KLayout's region engine (same rule table
that generates the Calibre SVRF deck).  Each cell is checked standalone and in an
abutment context (cell | cell, plus a flipped copy of the row above).
Usage: drc_check.py <gds> [maxcells]"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "gen"))
import klayout.db as kdb
from tech import RULES, LAYERS, ROW_H
gds = sys.argv[1]
ly = kdb.Layout(); ly.read(gds)
dbu = ly.dbu
idx = {n: ly.find_layer(l, d) for n, ((l, d), _) in LAYERS.items()}
def reg(cell, name, ctx):
    if name == "VT_*":
        r = kdb.Region()
        for n in ("VT_HVT", "VT_LVT", "VT_ULVT"): r += reg(cell, n, ctx)
        return r
    if name in ("NACT", "PACT"):
        return reg(cell, "ACTIVE", ctx) & reg(cell, "NSELECT" if name == "NACT" else "PSELECT", ctx)
    li = idx.get(name)
    if li is None: return kdb.Region()
    r = kdb.Region()
    for (c, t) in ctx:
        r.insert(kdb.Region(c.begin_shapes_rec(li)).transformed(t))
    if name not in ("SRAMMK", "PRBNDRY") and idx.get("SRAMMK") is not None:
        sm = kdb.Region()
        for (c, t) in ctx: sm.insert(kdb.Region(c.begin_shapes_rec(idx["SRAMMK"])).transformed(t))
        if not sm.is_empty(): r = r - sm.sized(30)   # bitcell arrays use SRAM.* rules (see SVRF deck)
    return r.merged()
nm = lambda v: int(round(v * 1e-3 / dbu))
skip_kinds = {"samemask", "fin_keep", "pitch", "area", "eol", "density_min", "density_max", "antenna", "grid", "extension"}
cells = [c for c in ly.each_cell() if c.is_top()]
if len(sys.argv) > 2: cells = cells[: int(sys.argv[2])]
viol = {}
for c in cells:
    bb = c.bbox_per_layer(idx["PRBNDRY"]) if idx.get("PRBNDRY") is not None else c.bbox(); W = bb.width()
    H = int(round(ROW_H * 1e-3 / dbu)) * max(1, int(round(bb.height() / (ROW_H * 1e-3 / dbu))))
    rowcell = abs(bb.height() / (ROW_H * 1e-3 / dbu) - round(bb.height() / (ROW_H * 1e-3 / dbu))) < 1e-6
    contexts = {"alone": [(c, kdb.ICplxTrans())],
                "abut": [(c, kdb.ICplxTrans()), (c, kdb.ICplxTrans(1, 0, False, W, 0)),
                         (c, kdb.ICplxTrans(1, 0, True, 0, 2 * H)), (c, kdb.ICplxTrans(1, 0, True, W, 2 * H))]}
    if not rowcell:   # pad-ring / macro cells abut only side by side (no row stacking)
        contexts["abut"] = contexts["abut"][:2]
    for cname, ctx in contexts.items():
        for r in RULES:
            if r.kind in skip_kinds or r.layer in ("*", "M*"): continue
            if r.rid.startswith(("TOX", "PAS", "AP.", "V9", "SEL.O")) and False: continue
            a = reg(c, r.layer, ctx)
            if a.is_empty(): continue
            v = 0
            if r.kind in ("width", "exact_width"):
                if r.other == "THICKOX": continue
                v = a.width_check(nm(r.value)).count()
            elif r.kind == "space":
                if r.other:
                    b = reg(c, r.other, ctx)
                    v = a.separation_check(b, nm(r.value)).count() if not b.is_empty() else 0
                else:
                    v = a.space_check(nm(r.value)).count()
            elif r.kind == "enclosure":
                b = reg(c, r.other, ctx)
                if b.is_empty(): continue
                v = a.enclosing_check(b, nm(r.value)).count() if r.value > 0 else (b - a).count()
            elif r.kind == "overlap_forbid":
                if r.layer == "VT_*":
                    hv, lv, uv = (reg(c, n, ctx) for n in ("VT_HVT", "VT_LVT", "VT_ULVT"))
                    v = (hv & lv).count() + (hv & uv).count() + (lv & uv).count()
                else:
                    v = (a & reg(c, r.other, ctx)).count()
            if v:
                viol.setdefault((r.rid, cname), []).append(c.name)
WAIVERS = {("NW.W.1", "alone"): ("FILL1_", "ENDCAPTOP1_", "ENDCAPBOTTOM1_")}   # 1-site filler: N-well legal only when abutted (abut context is clean)
for k, pre in WAIVERS.items():
    if k in viol:
        viol[k] = [n for n in viol[k] if not n.startswith(pre)]
        if not viol[k]: del viol[k]
print("cells checked:", len(cells))
if not viol: print("DRC CLEAN (all checked rules, standalone + abutment)")
for (rid, cx), cl in sorted(viol.items()):
    print("%-10s %-6s %5d cells e.g. %s" % (rid, cx, len(cl), ", ".join(cl[:4])))
