"""Render GDS cells to PNG (matplotlib) and check gate-array base-layer identity.
usage: render_cells.py <gds> <out.png> <title> <row1 cells comma-sep> [<row2 cells comma-sep> ...]"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "gen"))
import gdstk, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Patch
from tech import LAYERS, PIN_DT, CPP, ROW_H
STYLE = [  # name, face, alpha, edge, hatch, z
    ("NWELL", "#C9E7C0", 0.55, "#6AA84F", "", 0), ("NSELECT", "none", 1, "#4A86E8", "", 1), ("PSELECT", "none", 1, "#E06666", "", 1),
    ("VT_HVT", "#FFF2CC", 0.35, "none", "", 0), ("VT_LVT", "#D9D2E9", 0.35, "none", "", 0), ("VT_ULVT", "#F4CCCC", 0.35, "none", "", 0),
    ("ACTIVE", "#B6D7A8", 0.85, "#38761D", "", 2), ("FIN", "#7F7F7F", 0.9, "none", "", 3), ("GATE", "#CC0000", 0.85, "none", "", 4),
    ("GCUT", "#FFFFFF", 1.0, "#000000", "////", 5), ("LISD", "#F6B26B", 0.95, "#B45F06", "", 6), ("LIG", "#FFD966", 1.0, "#7F6000", "", 7),
    ("M1", "#3D85C6", 0.45, "#0B5394", "", 8), ("PRBNDRY", "none", 1, "#000000", "", 10)]
BASE = ["NWELL", "FIN", "ACTIVE", "NSELECT", "PSELECT", "GATE", "GCUT", "VT_HVT", "VT_LVT", "VT_ULVT"]
PROG = ["LISD", "LIG", "V0", "M1"]
gds, out, title = sys.argv[1], sys.argv[2], sys.argv[3]
rows = [r.split(",") for r in sys.argv[4:]]
lib = gdstk.read_gds(gds); cells = {c.name: c for c in lib.cells}
def polys(c, name, dt=0):
    l, d = LAYERS[name][0]
    return [p for p in c.get_polygons(layer=l, datatype=d)]
def base_sig(c):
    sig = []
    for n in BASE:
        for p in polys(c, n):
            bb = p.bounding_box(); sig.append((n, round(bb[0][0], 4), round(bb[0][1], 4), round(bb[1][0], 4), round(bb[1][1], 4)))
    return sorted(sig)
fig_w = max(sum(cells[n].bounding_box()[1][0] for n in r) for r in rows)
fig, axes = plt.subplots(len(rows), 1, figsize=(max(9, fig_w * 14), 3.2 * len(rows) + 1.2), squeeze=False)
for ax, r in zip(axes[:, 0], rows):
    x0 = 0.0
    for n in r:
        c = cells[n]
        for (lay, fc, al, ec, hat, z) in STYLE:
            for p in polys(c, lay):
                pts = p.points.copy(); pts[:, 0] += x0
                ax.add_patch(Polygon(pts, closed=True, facecolor=fc, alpha=al, edgecolor=ec, hatch=hat, lw=0.6, zorder=z))
        for lb in c.labels:
            if lb.layer == LAYERS["M1"][0][0]:
                ax.text(lb.origin[0] + x0, lb.origin[1], lb.text, fontsize=7, ha="center", va="center", zorder=20,
                        bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="#0B5394", lw=0.4))
        w = c.bounding_box()[1][0] if not polys(c, "PRBNDRY") else polys(c, "PRBNDRY")[0].bounding_box()[1][0]
        h = polys(c, "PRBNDRY")[0].bounding_box()[1][1]
        ax.text(x0 + w / 2, h + 0.045, "%s\n%d sites = %.3f um" % (n, round(w * 1000 / CPP), w), ha="center", va="bottom", fontsize=8, weight="bold")
        x0 += w
    ax.set_xlim(-0.03, x0 + 0.03); ax.set_ylim(-0.06, ROW_H / 1000.0 + 0.11); ax.set_aspect("equal")
    for i in range(int(round(x0 * 1000 / CPP)) + 1):
        ax.axvline(i * CPP / 1000.0, color="#BBBBBB", lw=0.3, ls=":", zorder=-1)
    ax.set_xlabel("um"); ax.tick_params(labelsize=7)
fig.legend(handles=[Patch(facecolor=fc if fc != "none" else "white", edgecolor=ec if ec != "none" else fc, hatch=hat, alpha=min(1, al + 0.2), label=lay)
                    for (lay, fc, al, ec, hat, z) in STYLE], loc="lower center", ncol=8, fontsize=7, frameon=False)
# base-layer identity report (each row: all cells of equal width vs first; composed rows vs single wide cell)
def row_sig(r):
    sig = set(); x0 = 0.0
    for n in r:
        c = cells[n]
        for s_ in base_sig(c):
            sig.add((s_[0], round(s_[1] + x0, 4), s_[2], round(s_[3] + x0, 4), s_[4]))
        x0 += polys(c, "PRBNDRY")[0].bounding_box()[1][0]
    return sig, x0
rep = []
if len(rows) > 1:
    s0, w0 = row_sig(rows[0])
    for r in rows[1:]:
        s1, w1 = row_sig(r)
        if abs(w0 - w1) < 1e-6:
            # merge fins/selects/wells that abut (compare geometry as unioned regions)
            import gdstk as _g
            def reg(sig, lay):
                return _g.boolean([_g.rectangle((a, b), (c_, d)) for (n_, a, b, c_, d) in sig if n_ == lay], [], "or")
            same = all(not _g.boolean(reg(s0, ly_), reg(s1, ly_), "xor") for ly_ in BASE)
            rep.append("%s vs %s: base layers %s" % ("+".join(r), "+".join(rows[0]), "IDENTICAL" if same else "DIFFER"))
ref = rows[0][0]
for r in rows:
    for n in r:
        if n == ref: continue
        same_w = abs(cells[n].bounding_box()[1][0] - cells[ref].bounding_box()[1][0]) < 1e-6
        if same_w:
            rep.append("%s vs %s: base layers %s" % (n, ref, "IDENTICAL" if base_sig(cells[n]) == base_sig(cells[ref]) else "DIFFER"))
fig.suptitle(title + ("\n" + "; ".join(rep) if rep else ""), fontsize=10)
plt.tight_layout(rect=(0, 0.06, 1, 0.93))
plt.savefig(out, dpi=170)
print("\n".join(rep))
