"""Parse Liberty files with liberty-parser and cross-check cell counts per file.
Usage: lib_check.py <pdk_root> [full]   (default: every nldm file + ccs/ecsm at tt_0p70v_25c; 'full' = all files)"""
import sys, glob, os, collections
os.chdir("/")   # avoid shadowing by gen/liberty.py
from liberty.parser import parse_liberty
root = sys.argv[1]; full = len(sys.argv) > 2
files = sorted(glob.glob(os.path.join(root, "**", "*.lib"), recursive=True))
if not full:   # every model at tt_0p70v_25c for all Vt + all 12 corners (NLDM) for SVT, memories and IO
    files = [f for f in files if "tt_0p70v_25c" in f or ("_nldm.lib" in f and ("_svt_" in f or "_mem_" in f or "_io18_" in f))]
cnt = collections.Counter(); bad = 0
for f in files:
    try:
        n = len(parse_liberty(open(f).read()).get_groups("cell"))
        key = os.path.basename(f).split("_")[1] + "/" + ("pmk" if "_pmk_" in f else "std" if "_std_" in f else "mem" if "_mem_" in f else "io")
        cnt[(key, n)] += 1
    except Exception as e:
        bad += 1; print("PARSE FAIL", f, str(e)[:200])
print("liberty files parsed: %d, failures: %d" % (len(files), bad))
for (k, n), c in sorted(cnt.items()): print("  %-12s %4d cells  x %d files" % (k, n, c))
