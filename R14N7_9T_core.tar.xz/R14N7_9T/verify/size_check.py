"""Cell size check for every cell of a built R14N7 PDK variant.
For each std/PMK/DFT/GA/physical cell (all Vt): re-derive the minimum legal width from the netlist
and pin count (rule recorded in gen/cells.py) and compare with the delivered LEF/GDS/Liberty view.
Also: site/row grid, LEF SIZE == GDS PRBNDRY == Liberty area, Vt footprint identity, drive-monotonic area,
memory (0.108 x row grid, pins fit on M3 tracks) and IO (ioSite) sizes.
Usage: size_check.py <pdk_root> [csv_out]     (env R14_TRACKS must match the variant)"""
import sys, os, re, glob, math, csv, collections
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "gen"))
import cells as C, memory, iolib
from tech import CPP, ROW_H, LAYERS, VT_FLAVORS, LIBPFX, VARIANT
root = sys.argv[1]; out_csv = sys.argv[2] if len(sys.argv) > 2 else os.path.join(root, "doc", "%s_cell_sizes.csv" % LIBPFX)
SW, RH = CPP / 1000.0, ROW_H / 1000.0
def on(v, g): return abs(v / g - round(v / g)) < 1e-6

def lef_sizes(path):
    d = {}; cur = None
    for ln in open(path):
        t = ln.split()
        if t[:1] == ["MACRO"]: cur = t[1]
        elif t[:1] == ["SIZE"] and cur: d[cur] = (float(t[1]), float(t[3]))
    return d
def lib_areas(path):
    d = {}; txt = open(path).read()
    for m in re.finditer(r"cell \((\S+)\) \{\s*area : ([0-9.eE+-]+);", txt): d[m.group(1)] = float(m.group(2))
    return d
def gds_bounds(path):
    import gdstk
    l, dt = LAYERS["PRBNDRY"][0]; d = {}
    for c in gdstk.read_gds(path).cells:
        ps = c.get_polygons(layer=l, datatype=dt, depth=0)
        if ps:
            (x0, y0), (x1, y1) = ps[0].bounding_box(); d[c.name] = (round(x1 - x0, 4), round(y1 - y0, 4))
    return d

rows = []; fails = collections.Counter(); fail_ex = collections.defaultdict(list)
def fail(k, n): fails[k] += 1; fail_ex[k].append(n)
foot = collections.defaultdict(set)
for vt in VT_FLAVORS:
    std, pmk = C.catalog(vt); v = vt.lower()
    for grp, cl, base in (("std", std, "stdcell"), ("pmk", pmk, "pmk")):
        nm = "%s_%s_%s" % (LIBPFX, grp, v)
        lef = lef_sizes(os.path.join(root, base, vt, "lef", nm + ".lef"))
        gds = gds_bounds(os.path.join(root, base, vt, "gds", nm + ".gds"))
        libf = os.path.join(root, base, vt, "liberty", "nldm", "%s_%s_%s_tt_0p70v_25c_nldm.lib" % (LIBPFX, grp, v))
        lib = lib_areas(libf) if os.path.exists(libf) else {}
        for c in cl:
            sz = c.sizing
            req = max(sz["dev"], sz["pin"], sz["fixed"], 2 if sz["rule"] != "fixed" else 1)
            if sz["rule"] == "ga" and c.base not in ("GFILL1",) and not c.base.startswith(("GFILL", "GDCAP")):
                req = max(sz["dev"], sz["pin"], C.GA_UNIT)
            bind = "fixed" if sz["rule"] == "fixed" else max((("devices", sz["dev"]), ("pins", sz["pin"]), ("fixed", sz["fixed"])), key=lambda x: x[1])[0]
            if sz["rule"] == "ga":
                avail = (c.sites // C.GA_UNIT) * (C.GA_UNIT - 1)
            else:
                avail = (c.sites - 2) * c.rows if sz["rule"] == "std" else 0
            util = (sz["cols"] / float(avail)) if avail else 0.0
            W, H = c.width_um, c.height_um
            st = "PASS"
            if c.sites != req: fail("width != derived minimum", c.name); st = "FAIL"
            if sz["rule"] == "ga" and c.sites % C.GA_UNIT: fail("GA width not whole tiles", c.name); st = "FAIL"
            if not (on(W, SW) and on(H, RH)): fail("off site/row grid", c.name); st = "FAIL"
            if c.name not in lef or abs(lef[c.name][0] - W) > 1e-6 or abs(lef[c.name][1] - H) > 1e-6: fail("LEF SIZE mismatch", c.name); st = "FAIL"
            if c.name not in gds or abs(gds[c.name][0] - W) > 1e-6 or abs(gds[c.name][1] - H) > 1e-6: fail("GDS boundary mismatch", c.name); st = "FAIL"
            if lib and (c.name not in lib or abs(lib[c.name] - c.area) > 1e-6): fail("Liberty area mismatch", c.name); st = "FAIL"
            foot[(c.base, c.drive)].add((c.sites, c.rows))
            rows.append([c.name, c.family, c.base, c.drive, vt, c.sites, c.rows, "%.3f" % W, "%.3f" % H, "%.5f" % c.area,
                         sz["rule"], sz["dev"], sz["pin"], sz["fixed"], req, bind, sz["cols"], avail, "%.2f" % util, st])
for (b, d), s in foot.items():
    if len(s) > 1: fail("Vt footprints differ", "%s_%s" % (b, d))
# drive monotonic
byb = collections.defaultdict(dict)
for r in rows:
    if r[4] == "SVT": byb[r[2]][r[3]] = float(r[9])
for b, dd in byb.items():
    ks = sorted(dd, key=C.dnum)
    for a, b2 in zip(ks, ks[1:]):
        if dd[b2] + 1e-9 < dd[a]: fail("area decreases with drive", "%s %s>%s" % (b, a, b2))
# memories
mlef = lef_sizes(os.path.join(root, "memory", "lef", "r14n7_mem.lef"))
for m in memory.all_mems():
    W, H = m.w / 1000.0, m.h / 1000.0; npins = sum(p[2] for p in m.pins())
    st = "PASS"
    if not (on(W, 2 * SW) and on(H, RH)): fail("memory off 0.108 x row grid", m.name); st = "FAIL"
    if (m.w - 2 * memory.MARGIN) // 54 < npins + 2: fail("memory pins exceed M3 tracks", m.name); st = "FAIL"
    if m.name not in mlef or abs(mlef[m.name][0] - W) > 1e-6: fail("memory LEF mismatch", m.name); st = "FAIL"
    rows.append([m.name, "memory", m.kind, "-", "-", m.w // CPP, m.h // ROW_H, "%.3f" % W, "%.3f" % H, "%.3f" % m.area,
                 "mem", "", npins, "", "", "pins/array", "", "", "", st])
ilef = lef_sizes(os.path.join(root, "io", "lef", "r14n7_io18.lef"))
for c in iolib.cells():
    W, H = c.w / 1000.0, c.h / 1000.0; st = "PASS"
    if c.kind not in ("corner", "bondpad") and not (on(W, 1.0) and on(H, 120.0)): fail("IO off ioSite", c.name); st = "FAIL"
    if c.name not in ilef or abs(ilef[c.name][0] - W) > 1e-6: fail("IO LEF mismatch", c.name); st = "FAIL"
    rows.append([c.name, "io", c.kind, "-", "-", "", "", "%.3f" % W, "%.3f" % H, "%.2f" % c.area, "io", "", len(c.pins), "", "", "ioSite", "", "", "", st])
os.makedirs(os.path.dirname(out_csv), exist_ok=True)
with open(out_csv, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["cell", "family", "base", "drive", "vt", "sites", "rows", "width_um", "height_um", "area_um2", "rule",
                "min_sites_devices", "min_sites_pins", "min_sites_fixed", "derived_min_sites", "binding", "device_columns",
                "columns_available", "column_utilisation", "status"])
    w.writerows(rows)
n = len(rows); nf = sum(1 for r in rows if r[-1] != "PASS")
bind = collections.Counter(r[15] for r in rows if r[1] not in ("memory", "io"))
print("%s size check: %d cells (std/pmk x4 Vt + %d memories + %d IO); %d failing rows; extra failures: %d" % (
    VARIANT, n, len(memory.all_mems()), len(iolib.cells()), nf, sum(fails.values())))
print("  binding constraint (std/pmk/ga): " + ", ".join("%s %d" % kv for kv in bind.most_common()))
for k, v in fails.items(): print("  FAIL %-32s %4d e.g. %s" % (k, v, ", ".join(fail_ex[k][:4])))
if not fails: print("SIZE CHECK PASS -> %s" % out_csv)
