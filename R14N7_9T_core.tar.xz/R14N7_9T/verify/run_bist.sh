#!/bin/bash
# run all MBIST / ROM-BIST testbenches (fault-free must pass, fault-injected must be detected)
ROOT=$1; W=$(mktemp -d); cp $ROOT/memory/rom_code/*.hex $W/; cd $W; p=0; f=0
for tb in $ROOT/dft/tb/*.v; do
  iverilog -g2005 -o t.out $ROOT/dft/rtl/r14n7_mbist.v $ROOT/memory/verilog/r14n7_mem.v $tb && r=$(vvp -n t.out | grep -E "BIST")
  echo "$r"; echo "$r" | grep -q -- "-> PASS" && p=$((p+1)) || f=$((f+1))
done
echo "BIST testbenches: $p passed, $f failed"
