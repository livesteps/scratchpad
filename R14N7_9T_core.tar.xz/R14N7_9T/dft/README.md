# R14N7 DFT kit

## ATPG models

- `atpg/tessent/*.atpglib` are Tessent-style cell-library models for every std, PMK, DFT, memory and IO cell. They are built from primitives: `_and _or _xor _inv _buf _mux _dff _dlat _tsh _cram _tie0/1`.
- Scan cells carry a `scan_definition` block (mux_scan, SI/SE/Q, `non_scan_model` mapping SDFF*->DFF*).
- ICGs, retention cells (clock = CK&NRET), multi-bit cells (per-bit `_dff`) and the two-stage WBR/BSC cells are modelled at primitive level.
- `atpg/verilog/*.v` holds structural/UDP simulation models without specify blocks or notifiers. Use them for TestMAX/TetraMAX `read_netlist -library` and for fault simulation.
- Memories use `_cram` read/write ports behind the built-in BIST mux (TEN). ROMs are read-only and initialised from `memory/rom_code/<inst>.hex`.

## DFT library cells (all Vt, all views)

| Cell | Purpose |
|---|---|
| LOCKUP_X1/2/4 (low-transparent), LOCKUPP_X1/2/4 (high-transparent) | Scan lock-up latches between clock domains or edges |
| TPCTL0 / TPCTL1 | Control test points: force-0/force-1 when TE=1 and the cell's own scan flop holds 1. The flop holds in capture and loads SI in shift. |
| TPOBS | Observe test point: dedicated scan flop capturing net A |
| WBRCELL | IEEE 1500 wrapper boundary cell: CFI/CFO, WSI/WSO, SHIFTWR/CAPTUREWR on WRCK, UPDATEWR update stage, WMODE |
| BSCELL | IEEE 1149.1 BC_1 boundary-scan cell: PI/PO, TDI/TDO, SHIFTDR on CLOCKDR, UPDATEDR, MODE |
| SDFF*, MBSDFF* (2-32 bit, per-bit SI), RETSDFF*, ICGPRE/POST (+OBS) | Scan flops and DFT-aware clock gating (test-enable pre/post latch, observability pin Q) |

## Memory BIST

- Every SRAM/RF macro has a built-in BIST port: `TEN` selects TCEB/TWEB/TA/TD/TBWEB (RF: TCEBA/TAA/TCEBB/TAB/TD/TBWEB).
- Every ROM has TEN/TCEB/TA.
- `rtl/r14n7_mbist.v`:
  - `r14n7_mbist_sp` runs March C- with solid and checkerboard backgrounds and reports `fail_addr`/`fail_elem`.
  - `r14n7_rombist` compacts every ROM word into a MISR and compares it with the golden signature in `r14n7_rom_signatures.txt`. The generator computes those signatures with the same polynomial.
- `rtl/r14n7_lbist.v`: PRPG (LFSR), MISR and a STUMPS shift/capture controller for logic BIST.
- `tb/`: self-checking testbenches. Each memory is run once fault-free (must pass) and once with an injected stuck-at or ROM-code fault (must fail). Run them with `flows/verify/run_bist.sh`.

## IO boundary scan

`PGPIO18MUX4BS` (4-way pin-mux GPIO), `PBIDIR18BS` and `PIN18BS` contain IEEE 1149.1 BSR cells, chained BSI -> BC_4 input -> BC_1 control -> BC_1 output -> BSO. `io/bsdl/r14n7_io18_bsr.bsdl` has the BOUNDARY_REGISTER fragments to paste into a chip BSDL. Chain the pads' BSI/BSO through the ring and drive SHIFTDR/CLOCKDR/UPDATEDR/MODE from the TAP controller.
