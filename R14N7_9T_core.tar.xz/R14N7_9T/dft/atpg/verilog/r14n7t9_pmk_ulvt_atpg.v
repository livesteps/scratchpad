// R14N7 synthetic 7nm-class FinFET PDK v1.0.0 (9-track variant) -- PREDICTIVE, NOT SILICON-CALIBRATED, NOT FOR MANUFACTURING
// ATPG/structural models (no timing)
`timescale 1ps/1fs
`celldefine
module HDRSW_X1_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module FTRSW_X1_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module HDRSW_X2_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module FTRSW_X2_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module HDRSW_X4_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module FTRSW_X4_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module HDRSWMR_X4_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module FTRSWMR_X4_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module HDRSWMR_X8_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module FTRSWMR_X8_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module HDRSWMR_X16_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module FTRSWMR_X16_ULVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module HDRSW2S_X1_ULVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VDD : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module FTRSW2S_X1_ULVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VSS : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module HDRSW2S_X2_ULVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VDD : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module FTRSW2S_X2_ULVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VSS : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module HDRSW2S_X4_ULVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VDD : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module FTRSW2S_X4_ULVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VSS : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module HDRSW2S_X8_ULVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VDD : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module FTRSW2S_X8_ULVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VSS : 1'bz;
`endif
endmodule
`endcelldefine
`celldefine
module ISOLO_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module ISOLOUB_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module ISOHI_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module ISOHIUB_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module ISOLON_X1_ULVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
endmodule
`endcelldefine
`celldefine
module ISOLONUB_X1_ULVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
endmodule
`endcelldefine
`celldefine
module ISOLAT_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  supply0 notifier; wire IQ;
  r14_udp_latch u_l (IQ, A, ~ISO, 1'b1, 1'b1, notifier);
  buf (Y, IQ);
endmodule
`endcelldefine
`celldefine
module ISOLO_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module ISOLOUB_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module ISOHI_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module ISOHIUB_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module ISOLON_X2_ULVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
endmodule
`endcelldefine
`celldefine
module ISOLONUB_X2_ULVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
endmodule
`endcelldefine
`celldefine
module ISOLAT_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  supply0 notifier; wire IQ;
  r14_udp_latch u_l (IQ, A, ~ISO, 1'b1, 1'b1, notifier);
  buf (Y, IQ);
endmodule
`endcelldefine
`celldefine
module ISOLO_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module ISOLOUB_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module ISOHI_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module ISOHIUB_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module ISOLON_X4_ULVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
endmodule
`endcelldefine
`celldefine
module ISOLONUB_X4_ULVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
endmodule
`endcelldefine
`celldefine
module ISOLAT_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  supply0 notifier; wire IQ;
  r14_udp_latch u_l (IQ, A, ~ISO, 1'b1, 1'b1, notifier);
  buf (Y, IQ);
endmodule
`endcelldefine
`celldefine
module ISOLO_X8_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module ISOHI_X8_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module ISOLON_X8_ULVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
endmodule
`endcelldefine
`celldefine
module LVLLH_X1_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module LVLHL_X1_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module LVLLHUB_X1_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module LVLLHISOLO_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOLO_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLLHISOLOUB_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOLOUB_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLLHISOHI_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOHI_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module LVLLHISOHIUB_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOHIUB_X1_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module LVLLH_X2_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module LVLHL_X2_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module LVLLHUB_X2_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module LVLLHISOLO_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOLO_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLLHISOLOUB_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOLOUB_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLLHISOHI_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOHI_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module LVLLHISOHIUB_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOHIUB_X2_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module LVLLH_X4_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module LVLHL_X4_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module LVLLHUB_X4_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module LVLLHISOLO_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOLO_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLLHISOLOUB_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOLOUB_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
endmodule
`endcelldefine
`celldefine
module LVLLHISOHI_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOHI_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module LVLLHISOHIUB_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module LVLHLISOHIUB_X4_ULVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
endmodule
`endcelldefine
`celldefine
module RETDFF_X1_ULVT (D, CK, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input CK;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  supply0 notifier;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, 1'b1, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
endmodule
`endcelldefine
`celldefine
module RETDFF_X2_ULVT (D, CK, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input CK;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  supply0 notifier;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, 1'b1, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
endmodule
`endcelldefine
`celldefine
module RETDFFR_X1_ULVT (D, CK, RN, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  supply0 notifier;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, RN, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
endmodule
`endcelldefine
`celldefine
module RETDFFR_X2_ULVT (D, CK, RN, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  supply0 notifier;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, RN, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
endmodule
`endcelldefine
`celldefine
module RETSDFF_X1_ULVT (D, SI, SE, CK, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  supply0 notifier;
  wire d_sc = SE ? SI : D;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, ck_i, 1'b1, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
endmodule
`endcelldefine
`celldefine
module RETSDFF_X2_ULVT (D, SI, SE, CK, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  supply0 notifier;
  wire d_sc = SE ? SI : D;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, ck_i, 1'b1, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
endmodule
`endcelldefine
`celldefine
module RETSDFFR_X1_ULVT (D, SI, SE, CK, RN, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  supply0 notifier;
  wire d_sc = SE ? SI : D;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, ck_i, RN, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
endmodule
`endcelldefine
`celldefine
module RETSDFFR_X2_ULVT (D, SI, SE, CK, RN, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  supply0 notifier;
  wire d_sc = SE ? SI : D;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, ck_i, RN, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
endmodule
`endcelldefine
`celldefine
module AONBUF_X1_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module AONBUF_X2_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module AONBUF_X4_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module AONBUF_X8_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module AONINV_X1_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = ~A;
endmodule
`endcelldefine
`celldefine
module AONINV_X2_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = ~A;
endmodule
`endcelldefine
`celldefine
module AONINV_X4_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = ~A;
endmodule
`endcelldefine
`celldefine
module AONINV_X8_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = ~A;
endmodule
`endcelldefine
`celldefine
module AONCKBUF_X1_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module AONCKBUF_X2_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module AONCKBUF_X4_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module AONCKBUF_X8_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module AONDLY_X1_ULVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
endmodule
`endcelldefine
`celldefine
module AONDFFR_X1_ULVT (D, E, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input D;
  input E;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  supply0 notifier;
  wire d_en = E ? D : IQ;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_en, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
endmodule
`endcelldefine
`celldefine
module AONDFFR_X2_ULVT (D, E, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input D;
  input E;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  supply0 notifier;
  wire d_en = E ? D : IQ;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_en, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
endmodule
`endcelldefine
