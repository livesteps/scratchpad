// R14N7 logic-BIST building blocks: Fibonacci PRPG (LFSR) with phase shifter tap-out and a MISR.
`timescale 1ps/1fs
module r14n7_prpg #(parameter W = 32, parameter [W-1:0] POLY = 32'h80200003, parameter [W-1:0] SEED = 32'h1) (
  input wire clk, rst_n, en, output reg [W-1:0] lfsr);
  always @(posedge clk or negedge rst_n)
    if (!rst_n) lfsr <= SEED;
    else if (en) lfsr <= {lfsr[W-2:0], ^(lfsr & POLY)};
endmodule

module r14n7_misr #(parameter W = 32, parameter [W-1:0] POLY = 32'h04C11DB7) (
  input wire clk, rst_n, en, input wire [W-1:0] d, output reg [W-1:0] sig);
  always @(posedge clk or negedge rst_n)
    if (!rst_n) sig <= 0;
    else if (en) sig <= ({sig[W-2:0], 1'b0} ^ (sig[W-1] ? POLY : {W{1'b0}})) ^ d;
endmodule

// STUMPS-style controller: N patterns, each shifted for CHAIN_LEN cycles (SE=1) then 1 capture (SE=0)
module r14n7_lbist_ctrl #(parameter CHAIN_LEN = 16, parameter NPAT = 1024) (
  input wire clk, rst_n, start, output reg se, output reg running, output reg done);
  reg [15:0] sh; reg [31:0] pat;
  always @(posedge clk or negedge rst_n)
    if (!rst_n) begin se <= 0; running <= 0; done <= 0; sh <= 0; pat <= 0; end
    else if (start && !running && !done) begin running <= 1; se <= 1; sh <= 0; pat <= 0; end
    else if (running) begin
      if (se) begin if (sh == CHAIN_LEN - 1) begin se <= 0; sh <= 0; end else sh <= sh + 1; end
      else begin pat <= pat + 1; if (pat == NPAT - 1) begin running <= 0; done <= 1; end else se <= 1; end
    end
endmodule
