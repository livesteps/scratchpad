// R14N7 memory BIST controller: March C- on the built-in T* port of R14SRAM_SP_* macros.
// Elements: up(w0); up(r0,w1); up(r1,w0); down(r0,w1); down(r1,w0); up(r0)  -- run for each data background.
// Backgrounds: solid (0/1) and checkerboard-by-bit (0101.. / 1010..).  Read data is compared one cycle later.
`timescale 1ps/1fs
module r14n7_mbist_sp #(parameter AW = 8, DW = 32, WORDS = 256) (
  input  wire          clk, rst_n, start,
  output reg           done, fail,
  output reg  [AW-1:0] fail_addr,
  output reg  [3:0]    fail_elem,
  // to memory BIST port
  output reg           ten, tceb, tweb,
  output reg  [AW-1:0] ta,
  output reg  [DW-1:0] td, tbweb,
  input  wire [DW-1:0] q
);
  localparam IDLE = 0, RUN = 1, FIN = 2;
  reg [1:0]    st;
  reg [2:0]    elem;            // 0..5 March elements
  reg          bg;              // background 0 = solid, 1 = checkerboard
  reg          ph;              // phase inside a 2-op element (0 = first op, 1 = second op)
  reg [AW-1:0] addr;
  reg          chk; reg [DW-1:0] exp_d; reg [AW-1:0] chk_a;
  wire [DW-1:0] B = bg ? {(DW/2){2'b01}} : {DW{1'b0}};
  wire          down = (elem == 3) || (elem == 4);
  // op table: elem: 0 w0 | 1 r0 w1 | 2 r1 w0 | 3 r0 w1 | 4 r1 w0 | 5 r0
  wire two = (elem >= 1) && (elem <= 4);
  wire       op_rd  = (elem == 5) || (two && !ph);
  wire       op_val = (elem == 0) ? 1'b0 : (elem == 5) ? 1'b0 : (ph ? ((elem == 1 || elem == 3) ? 1'b1 : 1'b0)
                                                              : ((elem == 1 || elem == 3) ? 1'b0 : 1'b1));
  wire last_a = down ? (addr == 0) : (addr == WORDS - 1);
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= IDLE; done <= 0; fail <= 0; fail_addr <= 0; fail_elem <= 0; ten <= 0; tceb <= 1; tweb <= 1;
      ta <= 0; td <= 0; tbweb <= {DW{1'b1}}; elem <= 0; bg <= 0; ph <= 0; addr <= 0; chk <= 0;
    end else begin
      // compare read data issued in the previous cycle
      if (chk && (q !== exp_d) && !fail) begin fail <= 1; fail_addr <= chk_a; fail_elem <= {bg, elem}; end
      chk <= 0;
      case (st)
        IDLE: if (start) begin st <= RUN; ten <= 1; elem <= 0; bg <= 0; ph <= 0; addr <= 0; done <= 0; fail <= 0; end
        RUN: begin
          tceb <= 0; ta <= addr; tbweb <= {DW{1'b0}};
          if (op_rd) begin tweb <= 1; chk <= 1; exp_d <= op_val ? ~B : B; chk_a <= addr; end
          else       begin tweb <= 0; td <= op_val ? ~B : B; end
          if (two && !ph) ph <= 1;
          else begin
            ph <= 0;
            if (last_a) begin
              if (elem == 5) begin
                if (bg) st <= FIN; else begin bg <= 1; elem <= 0; addr <= 0; end
              end else begin
                elem <= elem + 1;
                addr <= ((elem + 1) == 3 || (elem + 1) == 4) ? WORDS - 1 : 0;
              end
            end else addr <= down ? addr - 1 : addr + 1;
          end
        end
        FIN: begin tceb <= 1; tweb <= 1; if (!chk) begin done <= 1; ten <= 0; st <= IDLE; end end
      endcase
    end
  end
endmodule

// ROM BIST: reads every address through the T* port and compacts Q into a MISR; compare with golden.
module r14n7_rombist #(parameter AW = 9, DW = 32, WORDS = 512, parameter [DW-1:0] POLY = 32'h04C11DB7,
                       parameter [DW-1:0] GOLDEN = 0) (
  input  wire          clk, rst_n, start,
  output reg           done, fail,
  output reg  [DW-1:0] sig,
  output reg           ten, tceb,
  output reg  [AW-1:0] ta,
  input  wire [DW-1:0] q
);
  reg run, cap; reg [AW:0] n;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin done <= 0; fail <= 0; sig <= 0; ten <= 0; tceb <= 1; ta <= 0; run <= 0; cap <= 0; n <= 0; end
    else begin
      if (cap) sig <= ({sig[DW-2:0], 1'b0} ^ (sig[DW-1] ? POLY : {DW{1'b0}})) ^ q;
      cap <= 0;
      if (start && !run && !done) begin run <= 1; ten <= 1; n <= 0; sig <= 0; end
      else if (run) begin
        if (n < WORDS) begin tceb <= 0; ta <= n[AW-1:0]; cap <= 1; n <= n + 1; end
        else begin tceb <= 1; run <= 0; end
      end else if (ten && !cap && !done && n == WORDS) begin done <= 1; ten <= 0; end
      if (done) fail <= (sig !== GOLDEN);
    end
  end
endmodule
