`timescale 1ps/1fs
module tb_rombist_R14ROM_4096x32m16;
  reg clk = 0, rst_n = 0, start = 0; always #500 clk = ~clk;
  wire done, fail, ten, tceb; wire [11:0] ta; wire [31:0] q, sig;
  r14n7_rombist #(.AW(12), .DW(32), .WORDS(4096), .POLY(32'h4C11DB7), .GOLDEN(32'hE6394785)) u_bist (
      .clk(clk), .rst_n(rst_n), .start(start), .done(done), .fail(fail), .sig(sig), .ten(ten), .tceb(tceb), .ta(ta), .q(q));
  R14ROM_4096x32m16 u_rom (.CLK(clk), .CEB(1'b1), .A({12{1'b0}}), .Q(q), .TEN(ten), .TCEB(tceb), .TA(ta));
  initial begin
    #2200  rst_n = 1; #1000 start = 1; #1000 start = 0;
    wait (done); #2000;
    $display("ROMBIST R14ROM_4096x32m16 golden code: signature=%h golden=E6394785 fail=%b -> %s", sig, fail, (fail == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #(12788 * 1000); $display("ROMBIST R14ROM_4096x32m16 TIMEOUT"); $finish; end
endmodule
