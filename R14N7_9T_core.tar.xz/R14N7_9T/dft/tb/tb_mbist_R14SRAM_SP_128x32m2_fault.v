`timescale 1ps/1fs
module tb_mbist_R14SRAM_SP_128x32m2_fault;
  reg clk = 0, rst_n = 0, start = 0; always #500 clk = ~clk;
  wire done, fail, ten, tceb, tweb; wire [6:0] ta, fa; wire [3:0] fe; wire [31:0] td, tbweb, q;
  r14n7_mbist_sp #(.AW(7), .DW(32), .WORDS(128)) u_bist (.clk(clk), .rst_n(rst_n), .start(start), .done(done), .fail(fail),
      .fail_addr(fa), .fail_elem(fe), .ten(ten), .tceb(tceb), .tweb(tweb), .ta(ta), .td(td), .tbweb(tbweb), .q(q));
  R14SRAM_SP_128x32m2 u_mem (.CLK(clk), .CEB(1'b1), .WEB(1'b1), .A({7{1'b0}}), .D({32{1'b0}}), .BWEB({32{1'b1}}), .Q(q),
      .TEN(ten), .TCEB(tceb), .TWEB(tweb), .TA(ta), .TD(td), .TBWEB(tbweb));
  always @(negedge clk) if (rst_n) u_mem.mem[5][3] = 1'b1;
  initial begin
    #2200 rst_n = 1; #1000 start = 1; #1000 start = 0;
    wait (done);
    $display("MBIST R14SRAM_SP_128x32m2 stuck-at-1 injected at addr 5 bit 3: done=%b fail=%b fail_addr=%0d elem=%0d -> %s", done, fail, fa, fe,
             (fail == 1) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #(3572 * 1000); $display("MBIST R14SRAM_SP_128x32m2 TIMEOUT"); $finish; end
endmodule
