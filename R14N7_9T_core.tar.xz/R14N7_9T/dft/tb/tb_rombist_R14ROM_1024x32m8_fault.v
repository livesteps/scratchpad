`timescale 1ps/1fs
module tb_rombist_R14ROM_1024x32m8_fault;
  reg clk = 0, rst_n = 0, start = 0; always #500 clk = ~clk;
  wire done, fail, ten, tceb; wire [9:0] ta; wire [31:0] q, sig;
  r14n7_rombist #(.AW(10), .DW(32), .WORDS(1024), .POLY(32'h4C11DB7), .GOLDEN(32'h69DA9DF7)) u_bist (
      .clk(clk), .rst_n(rst_n), .start(start), .done(done), .fail(fail), .sig(sig), .ten(ten), .tceb(tceb), .ta(ta), .q(q));
  R14ROM_1024x32m8 u_rom (.CLK(clk), .CEB(1'b1), .A({10{1'b0}}), .Q(q), .TEN(ten), .TCEB(tceb), .TA(ta));
  initial begin
    #2200 u_rom.mem[7][0] = ~u_rom.mem[7][0]; rst_n = 1; #1000 start = 1; #1000 start = 0;
    wait (done); #2000;
    $display("ROMBIST R14ROM_1024x32m8 code bit flipped at addr 7: signature=%h golden=69DA9DF7 fail=%b -> %s", sig, fail, (fail == 1) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #(3572 * 1000); $display("ROMBIST R14ROM_1024x32m8 TIMEOUT"); $finish; end
endmodule
