`timescale 1ps/1fs
module tb_mbist_R14SRAM_SP_64x32m2;
  reg clk = 0, rst_n = 0, start = 0; always #500 clk = ~clk;
  wire done, fail, ten, tceb, tweb; wire [5:0] ta, fa; wire [3:0] fe; wire [31:0] td, tbweb, q;
  r14n7_mbist_sp #(.AW(6), .DW(32), .WORDS(64)) u_bist (.clk(clk), .rst_n(rst_n), .start(start), .done(done), .fail(fail),
      .fail_addr(fa), .fail_elem(fe), .ten(ten), .tceb(tceb), .tweb(tweb), .ta(ta), .td(td), .tbweb(tbweb), .q(q));
  R14SRAM_SP_64x32m2 u_mem (.CLK(clk), .CEB(1'b1), .WEB(1'b1), .A({6{1'b0}}), .D({32{1'b0}}), .BWEB({32{1'b1}}), .Q(q),
      .TEN(ten), .TCEB(tceb), .TWEB(tweb), .TA(ta), .TD(td), .TBWEB(tbweb));
  
  initial begin
    #2200 rst_n = 1; #1000 start = 1; #1000 start = 0;
    wait (done);
    $display("MBIST R14SRAM_SP_64x32m2 fault-free: done=%b fail=%b fail_addr=%0d elem=%0d -> %s", done, fail, fa, fe,
             (fail == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #(2036 * 1000); $display("MBIST R14SRAM_SP_64x32m2 TIMEOUT"); $finish; end
endmodule
