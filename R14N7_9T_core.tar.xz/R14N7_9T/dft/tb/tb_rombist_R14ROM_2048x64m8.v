`timescale 1ps/1fs
module tb_rombist_R14ROM_2048x64m8;
  reg clk = 0, rst_n = 0, start = 0; always #500 clk = ~clk;
  wire done, fail, ten, tceb; wire [10:0] ta; wire [63:0] q, sig;
  r14n7_rombist #(.AW(11), .DW(64), .WORDS(2048), .POLY(64'h42F0E1EBA9EA3693), .GOLDEN(64'h129DF956195347A1)) u_bist (
      .clk(clk), .rst_n(rst_n), .start(start), .done(done), .fail(fail), .sig(sig), .ten(ten), .tceb(tceb), .ta(ta), .q(q));
  R14ROM_2048x64m8 u_rom (.CLK(clk), .CEB(1'b1), .A({11{1'b0}}), .Q(q), .TEN(ten), .TCEB(tceb), .TA(ta));
  initial begin
    #2200  rst_n = 1; #1000 start = 1; #1000 start = 0;
    wait (done); #2000;
    $display("ROMBIST R14ROM_2048x64m8 golden code: signature=%h golden=129DF956195347A1 fail=%b -> %s", sig, fail, (fail == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #(6644 * 1000); $display("ROMBIST R14ROM_2048x64m8 TIMEOUT"); $finish; end
endmodule
