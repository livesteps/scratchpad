# R14N7 PDK generation methodology and flows

## 1. Scope and status

R14N7 is a synthetic 7nm-class FinFET PDK. It is built from public ASAP7 predictive device cards (BSD-3) and an analytic characterization model. One Python generator (`gen/`) produces every view from a single cell catalog, so cell names, pins, functions, area, timing arcs and power/ground pins agree in Verilog, Liberty, SPICE/CDL, LEF, GDS, AOCV/POCV and the databook.

It is meant for flow bring-up, methodology and CAD development, architecture and HDL modelling, teaching and benchmarking. It is **not** silicon-calibrated and must not be used for tape-out.

## 2. Directory layout

```
R14N7_PDK/
  doc/        databook (PDF), this methodology, verification report
  tech/       r14n7_tech.lef, layer map, rules.csv, corners.csv
  models/     spice/r14n7.l (BSIM-CMG lib: TT SS FF SF FS), LICENSE.ASAP7
  stdcell/<VT>/{verilog,liberty/{nldm,ccs,ecsm},ocv,spice,lef,gds}
  pmk/<VT>/   same structure (power-management kit)
  memory/     verilog, liberty, lef, gds, spice, rom_code, r14n7_mem_list.csv
  io/         verilog, liberty, lef, gds, spice
  calibre/    r14n7_{drc,lvs,erc,density,antenna}.svrf
  flows/      setup, synth, pnr, sta, upf, calibre, sim, char, verify scripts
  gen/        generator source (re-generate everything with one command)
  verify/     self-check scripts (truth tables, co-simulation, DRC, grid)
```

## 3. Generation pipeline

- **tech.py** holds the single technology database: geometry (CPP 54 nm, fin pitch 27 nm, row 270 nm), the grid-aligned metal stack, the GDS layer map, the 4 Vt flavours, the 12 PVT corners and the design-rule table. The Calibre decks, techLEF, the DRC self-check and the databook all read this table.
- **netlist.py** is a transistor-network builder: series-parallel complementary gates, transmission gates and clocked keepers. Every cell is defined as a netlist first. Pin capacitance (gate fins x L), output drive resistance (fingers, fins, stack depth), internal capacitance, leakage stacks, cell width (gate columns) and GDS device columns are all derived from that netlist.
- **cells.py** is the catalog. It builds 425 standard cells and 100 PMK cells per Vt flavour (2100 cells in total): combinational and complex gates (AOI/OAI/AO/OA 21-33, inverted-input variants), HADD/FADD, MUX2/4, clock cells, CKD delays, 6 ICG styles (pre/post-control, observability, negative-edge), 18 flip-flop styles including scan, latches, multi-bit registers (2-32 bit, multi-row), gate-array ECO cells, physical cells and the full PMK.
- **charmodel.py** is the analytic FinFET model. It uses an alpha-power drive law with temperature-dependent Vt and mobility, which reproduces FinFET temperature inversion (slow corner is cold at low VDD). It also covers subthreshold leakage with DIBL and temperature, and Pelgrom-style local variation for LVF/POCV/AOCV. It produces NLDM tables, CCS current vectors, ECSM waveforms, constraints and energy.
- **liberty.py / verilog.py / spice.py / layout.py / ocv.py** are the view writers. **memory.py** is the memory compiler, **iolib.py** the IO library, **calibre.py** the SVRF decks and **databook.py** writes the PDF.
- **build.py** orchestrates everything in parallel. A full build (4 Vt x 12 corners x 3 model types plus memories and IO) takes about one minute on 2 cores and produces about 2.9 GB of uncompressed data.

```
python3 gen/build.py --out R14N7_PDK --jobs 8                 # everything
python3 gen/build.py --out R14N7_PDK --vt SVT --corners tt_0p70v_25c --models nldm
python3 gen/databook.py R14N7_PDK/doc/R14N7_databook.pdf doc/methodology.md verify_report.txt
```

## 4. Electrical model and characterization

Drive current is modelled as `I = mu(T) * (VDD - Vt(T))^1.3`, with `Vt(T) = Vt0 + dVt_proc - 1.0 mV/K * (T - 25)` and `mu ~ T^-0.8`. Gate delay is `d = d_int * s + 0.69 * R * s * (C_load + C_par) + k * slew`, where `s` is the corner/Vt scale `V/I` normalised to TT SVT. Output transition uses a 10-90 % RC ramp plus slew feed-through. Leakage per fin is `I0 * (T/T0)^2 * exp(-(Vt_eff)/(n kT/q))` with DIBL 80 mV/V, plus gate leakage. Local variation is `sigma/mu = 3 % * sqrt(3/fins) * (Vov_nom/Vov)^1.1 / sqrt(stages)`.

Leakage ratios relative to SVT at TT 25C: HVT 0.2x, LVT 5x, ULVT 29x. Delay ratios relative to SVT: HVT 1.2x, LVT 0.9x, ULVT 0.8x.

**Recalibrating to real silicon.** `flows/char/` contains a Liberate-style template and a ngspice characterization harness. Re-characterize the same SPICE netlists (`stdcell/<VT>/spice/*.sp`) with foundry BSIM-CMG cards, then either replace the `.lib` files directly or fit `R_N1/R_P1/CG_FIN/CD_FIN` (netlist.py) and the constants in charmodel.py and re-run build.py. Every downstream view follows automatically.

## 5. Library features

- **Multi-Vt:** every std/PMK cell exists in HVT, SVT, LVT and ULVT, with the same footprint (`cell_footprint`), so Vt swaps are in-place.
- **Multi-bit:** MBDFF/MBDFFR/MBSDFF/MBSDFFR in 2/4/8 (1 row), 16 (2 rows) and 32 (4 rows) bits. They use a shared clock/SE/RN buffer and per-bit SI. Liberty uses `ff_bank`, bus pins and `single_bit_degenerate` for banking/debanking.
- **ICG:** `latch_posedge_precontrol`, `latch_posedge_postcontrol`, `*_obs` with an observe pin Q (DFT observability of the enable latch), and `latch_negedge_*`.
- **PMK:**
  - header/footer switches: simple type X1-X16 (single and multi-row) and mother-daughter 2S type X1-X8, with daisy-chained SLEEPOUT
  - ISO cells: ISOLO/ISOHI/ISOLON, buffered and unbuffered (UB), plus ISOLAT
  - level shifters: LVLLH (DCVS, double-row, dual-rail VDDL/VDD) and LVLHL (single rail), each plain or combined with ISO clamp-0/1, buffered and UB
  - retention flops RET* (live slave on VDDR, single NRET pin)
  - AON buffer/inverter/clock-buffer/delay/DFF cells on VDDB
- **Gate-array ECO:** GFILL tiles (4-site grid) and GDCAP, plus 24 functional G* cells on the same tile grid for metal-only ECO.
- **Memories:** SP SRAM 64x32 to 4096x64, 2P RF, V0-programmed ROM. 6T HD bitcell with VDDM array supply, bit-write mask, LVS-ready hierarchical CDL.
- **IO:** 1.8 V GPIO (BIDIR/IN/OUT/ANA), VDD/VSS/IOVDD/IOVSS pads with clamps, stand-alone RC rail clamps, POC, fillers, breaker, corner and bond pads.

## 6. Placement and routing grid

Vertical routing layers have pitches that are multiples of the 54 nm site (M1/M3 54, M5/M7 108, M9 216), with tracks at site centres. Horizontal layers divide the 270 nm row (M2 45, M4/M6 90, M8 135). Track grids are therefore identical for every placement site and row (flipped or not).

Every std-cell signal pin is an M1 stub centred on an M1 track and spans 3 M2 tracks, so it has at least 2 on-grid V1 access points. Rails sit on M2 tracks. Memory macros use a 0.108 x 0.270 placement grid with M3 pins and M5 straps on-track. `verify/grid_check.py` checks all of this, plus LEF-vs-GDS pin equality.

## 7. Verification (verify/, run with flows/verify/run_all.sh)

- `spice_truth.py`: DC solves every combinational and PMK-combinational transistor netlist for every input vector in ngspice and compares against the Liberty function. It uses level-1 stand-in models, because ngspice has no built-in BSIM-CMG.
- `seq_check.py`: co-simulates each sequential, ICG, retention, latch-isolation and multi-bit cell. The same random stimulus drives the transistor netlist (ngspice) and the Verilog UDP model (iverilog), and sampled outputs are compared.
- `drc_check.py`: rule-table-driven DRC of every GDS cell, checked stand-alone and in abutment, including the flipped row above.
- `grid_check.py`: placement and routing grid checks, as described in section 6.
- Liberty syntax parse (liberty-parser), Verilog compile (iverilog, with and without `R14_PG_PINS`) and a memory functional test.

## 8. Using the PDK in a flow

The `flows/` scripts are templates with `R14N7_HOME` as the only required variable:

- `setup/r14n7_env.sh`
- `synth/dc_setup.tcl`, `synth/genus_setup.tcl`: multi-Vt target libraries, dont_use lists, MBIT banking, ICG style
- `pnr/innovus_mmmc.tcl`, `pnr/innovus_init.tcl`, `pnr/icc2_setup.tcl`: MMMC from the 12 corners, LEF, PG rails, power-switch rows, tap/endcap rules
- `sta/pt_signoff.tcl`: POCV with LVF, or AOCV fallback
- `upf/r14n7_lowpower_example.upf`: switched domain, isolation, level shifters, retention
- `calibre/run_*.sh`: DRC, LVS, ERC, density, antenna
- `sim/run_rtl_sim.sh`

## 9. Known limitations

- Intra-cell M0/M1 wiring is not drawn in std-cell GDS. FEOL devices, pins and rails are drawn, so the GDS is DRC-checkable and P&R-ready, but full-cell layout-vs-schematic needs routed cell layouts.
- Memory and IO periphery GDS are abstract blocks around bitcell-accurate arrays.
- The Calibre SVRF was generated, not run against Calibre, in this environment. Validate the syntax on your Calibre release. The same rules are exercised by `drc_check.py` in KLayout.
- ECSM syntax follows the Cadence ECSM Liberty extension conventions. Confirm the group names with your tool version.
- Timing and power numbers come from the analytic model and are predictive only.

## 10. Track-height variants

`R14_TRACKS=6|7|9|12 python3 gen/build.py ...` (or `build_all.sh`) generates complete, independent PDKs:

| Variant | Row | M2 pitch | Fin pitch | Fins/row | Fins/device |
|---|---|---|---|---|---|
| 6T | 270 nm | 45 nm | 27 nm | 10 | 3 |
| 7T | 252 nm | 36 nm | 28 nm | 9 | 3 |
| 9T | 324 nm | 36 nm | 27 nm | 12 | 4 |
| 12T | 432 nm | 36 nm | 27 nm | 16 | 6 |

Library names carry the variant prefix (`r14n7t6_`, `r14n7t7_`, ...). Cell names are identical across variants, so the variants are meant to be used one per block, not mixed in a single row structure.

## 11. Cell sizing rule and size check

- **Standard cells:** sites = max(ceil(gate columns / rows) + 2, ceil(pins / rows) + 1, fixed minimum).
- **Gate-array cells:** use whole 4-site tiles, with 3 device columns per tile; tiles = max(ceil(max(N, P fingers) / 3), ceil((pins + 1) / 4)).
- **Physical cells and switch arrays:** widths are fixed by definition.

`verify/size_check.py` re-derives every width and also checks:
- the site/row grid
- LEF = GDS = Liberty size agreement
- identical footprints across the Vt flavours
- non-decreasing area with drive
- memory and IO grids

It writes `doc/<prefix>_cell_sizes.csv`.

## 12. Mask-ROM programming

`flows/rom/rom_program.sh -i boot.hex -c 1024x32m8 -n BOOTROM -o out/` turns a boot image into a pre-programmed, code-specific ROM macro (`R14ROM_<cfg>_<NAME>_<CRC32>`). Supported inputs are Intel HEX, S-record, binary and readmemh.

Outputs:
- GDS with the V0/ROMPGM code layer, plus a code-layer-only GDS for the mask shop
- CDL
- Verilog with the image embedded
- Liberty for all corners
- LEF
- ATPG model
- golden MISR signature and BIST testbenches

Encoding: a V0 contact present means bit 0 (the precharged bitline is discharged). The wrapper verifies:
- Verilog read-back against the image
- GDS shape count = CDL programmed-cell count = number of 0-bits
- BIST signature pass and fault detection
