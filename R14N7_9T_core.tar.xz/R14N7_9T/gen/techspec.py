"""Generates doc/technology_and_grid.md (and P&R track scripts) from tech.py so the
specification can never drift from the views."""
from tech import (CPP, GATE_L, FIN_P, FIN_W, ROW_H, M1_W, RAIL_W, METALS, VIAS, LAYERS, VT_FLAVORS, CORNERS, BANNER, PDK_VERSION)

HFIN, TFIN = 32.0, 6.5          # from the BSIM-CMG cards (hfin, tfin)
WEFF = 2 * HFIN + TFIN

def md():
    o = ["# R14N7 technology and place-and-route grid specification", "",
         "All values below are generated from `gen/tech.py`, the same database that drives the LEF, GDS, Calibre decks and DRC/grid checkers.", ""]
    o += ["## 1. FinFET front end (FEOL)", "",
          "| Parameter | Value | Explanation |", "|---|---|---|",
          "| Fin pitch | %d nm | Spacing of the fin mandrel grid (self-aligned double patterning). Every active region and the row height are integer multiples of it, so fins line up across abutting cells and rows. |" % FIN_P,
          "| Fin width (drawn) / fin height | %g nm / %g nm | Taken from the BSIM-CMG cards (TFIN, HFIN). The gate wraps three sides of the fin. |" % (FIN_W, HFIN),
          "| Effective width per fin | %.1f nm | Weff = 2*Hfin + Tfin. Drive current and gate capacitance scale with the fin count (NFIN), not a drawn W. This is why device sizing is quantized. |" % WEFF,
          "| Contacted poly pitch (CPP) | %d nm | Gate-to-gate pitch including the S/D trench contact. It equals the placement site width, so every cell is an integer number of gates wide. |" % CPP,
          "| Gate length (logic / IO) | %d nm / 150 nm | One fixed Lg for logic (Vt is set by work-function implants, not L). Thick-oxide 1.8 V IO devices use Lg >= 150 nm under THICKOX. Keeper devices in sequential cells use 40 nm for weak feedback. |" % GATE_L,
          "| Fins per device finger | 3 (X0P5: 2) | A 270 nm row holds 10 fin tracks: 1 under each rail (dummy), 3 N-fins, 3 P-fins and 2 for N/P separation and the gate cut. Drive strength scales by fingers (NF): Xn = n fingers. |",
          "| Diffusion break | shared dummy gate on the cell boundary | Each cell edge is a dummy gate centred on the boundary. Abutting cells share it, giving a single-pitch break without a dedicated SDB mask in cells. |",
          "| Gate cut (GCUT) | >= 24 nm wide, merged across adjacent columns | Separates N and P gates where they carry different signals (transmission gates, keepers). |",
          "| Trench contact (LISD) / gate contact (LIG) / V0 | 24 nm / 16 nm / 18x18 nm | Self-aligned local interconnect at 4 nm from the gate edge. V0 lands LISD/LIG on M1. |",
          "| Vt options | %s | Work-function implant layers (VT_HVT / none / VT_LVT / VT_ULVT) cover the whole cell boundary, so every Vt variant has an identical footprint and pins. |" % ", ".join(VT_FLAVORS),
          ""]
    o += ["## 2. Standard-cell architecture", "",
          "| Parameter | Value | Explanation |", "|---|---|---|",
          "| Placement site (coreSite) | %.3f x %.3f um | 1 CPP wide x 1 row high, CLASS CORE, SYMMETRY Y. |" % (CPP / 1e3, ROW_H / 1e3),
          "| Row height | %d nm = 10 fin pitches = 6 M2 tracks | Integer in both the fin grid (FEOL) and the M2 grid (BEOL). Rows can therefore flip and stack with no fin or track misalignment. |" % ROW_H,
          "| Power rails | M1, %d nm wide, centred on row boundaries | Rails are shared by abutting rows (VSS-VDD-VSS...) and sit on an M2 track, so followpin/M2 shadow rails and via stacks land on-grid. |" % RAIL_W,
          "| Row orientation | alternate R0 / MX | N-well (upper half) merges across VDD rails. Selects never overlap. |",
          "| Multi-row cells | 2 rows (MB16, LVLLH*, HDRSW*MR 4-8, *SW2S), 4 rows (MB32, HDRSW/FTRSW*MR16) | Heights are integer rows. Internal rails follow the same VSS/VDD alternation, so multi-row cells drop into ordinary rows. |",
          "| Signal pins | M1 vertical stubs, %d nm wide, y = 72-198 nm in-row | Centred on M1 tracks (site centres). Each stub spans the M2 tracks at 90/135/180 nm, giving 3 V1 access points per pin. |" % M1_W,
          "| Secondary PG pins | VDDL, VDDB, VDDR, VVDD, VVSS as M1 pin stubs | For PMK cells. Connect with M2+ straps or special nets. |",
          "| Physical cells | WELLTAP, WELLTAPDH, ENDCAPLEFT/RIGHT, ENDCAPTOP/BOTTOM 1/2/4, ENDCAPTL/TR/BL/BR, FILL1-64, DCAP4-64, ANTENNA, TIEHI/TIELO | Well taps every <= 25 um. Left/right endcaps at every row end, top/bottom boundary cells along the first/last row and corner cells at core corners terminate the fins, gates and implants so the core edge is DRC-clean. |",
          ""]
    o += ["## 3. Back end of line (BEOL) stack and gear ratios", "",
          "| Layer | Dir | Pitch nm | Width nm | Space nm | Track offset nm | Gear ratio | Explanation |", "|---|---|---|---|---|---|---|---|"]
    expl = {"M1": "1 track per site, at site centres. Pins and in-cell routes.",
            "M2": "6 tracks per row, track 0 on the rail. Local routing and V1 pin access.",
            "M3": "Same grid as M1. Memory/IO pins on M3.",
            "M4": "2 x M2 pitch, 3 tracks per row.", "M5": "2 sites. Memory power straps.", "M6": "Power mesh / semi-global.",
            "M7": "Power mesh / semi-global.", "M8": "IO rings, global power.", "M9": "4 sites. Global power and bumps."}
    for (m, d, p, w, s, t, off) in METALS:
        gr = ("%.3g x CPP" % (p / float(CPP))) if d == "VERTICAL" else ("row / %d" % (ROW_H // p))
        o.append("| %s | %s | %d | %d | %d | %d | %s | %s |" % (m, d[0], p, w, s, off, gr, expl[m]))
    o += ["", "Vias: " + ", ".join("%s %dx%d nm (%s-%s)" % (v[0], v[3], v[3], v[1], v[2]) for v in VIAS) + ".", "",
          "**Why gear ratios matter.** The ASAP7-style 36 nm M1/M2 pitch against a 54 nm CPP and 270 nm row (7.5 tracks) puts a pin on a track only when the cell sits on an even site or row. R14N7 sets vertical pitches to integer multiples of CPP and horizontal pitches to integer divisors of the row height. Every legal placement therefore yields on-grid pins, and routers need no off-track pin access.", ""]
    o += ["## 4. Place-and-route grid settings", "",
          "| Setting | Value | Explanation |", "|---|---|---|",
          "| Manufacturing grid | 0.001 um | All GDS/LEF coordinates snap to 1 nm (OFFGRID check in DRC). |",
          "| LEF DATABASE MICRONS | 4000 | 0.25 nm DBU. Exact for every coordinate (all are integer nm). |",
          "| GDS units | 1 um user / 1e-10 m database | 0.1 nm resolution, so half-nm centred features stay exact. |",
          "| Std-cell placement grid | x 0.054 um, y 0.270 um | Site grid. Cells snap to sites, rows alternate orientation. |",
          "| Macro placement grid (memories) | x 0.108 um, y 0.270 um | 2 sites. Keeps M3 pins on M3 tracks and M5 straps on M5 tracks. Macro sizes are multiples of this grid. |",
          "| IO site / corner site | 1.0 x 120 um / 120 x 120 um | Pad-ring grid. Fillers in 1, 2, 5, 10, 20 um. |",
          "| Die/core origin | multiple of 0.216 um (lcm of all vertical pitches) in x, of 0.270 um in y | Puts every layer's track grid on the core origin. |",
          "| Routing layers (signal) | M1-M7 | M8-M9 reserved for power/IO rings. M1 limited to pin access + short jogs. |",
          "| Default vias | V*_1x1 (techLEF) + VIARULE GENERATE | Enclosure 0/5 nm (side/end). |",
          "| Power grid (recommended) | M1 rails (cells) + M2 followpins; M5 vertical straps 0.048 um @ 5.4 um pitch; M6 horizontal 0.088 um @ 5.4 um; M7/M8/M9 mesh @ 10.8/21.6/43.2 um | Straps on track; pitches are multiples of both the site and row grids. |",
          "| Power-switch rows | HDRSW/FTRSW (simple) every 20-40 um in checker-board; *SW2S mother-daughter chains for in-rush control | Ron and IR-drop scale with the drive (see databook). |",
          "| Well-tap spacing | <= 25 um between WELLTAPs in a row (checker-board) | Latch-up rule. |",
          "| Boundary cells | ENDCAPLEFT/ENDCAPRIGHT at row ends; ENDCAPTOP*/ENDCAPBOTTOM* along top/bottom rows; ENDCAPTL/TR/BL/BR at corners; also around macros | Terminate diffusion, fins, gates and Vt implants at the core boundary (LEF classes ENDCAP PRE/POST/TOPLEFT/... and CORE SPACER). |",
          ""]
    o += ["## 4b. Double patterning, sites and LEF rule content", "",
          "| Item | Value | Explanation |", "|---|---|---|",
          "| Multi-patterned layers | M2, M3 (LELE, 2 masks), V1 (2 masks) | Same-mask spacing = 2 x pitch - width. Tracks are pre-coloured alternately (mask 1/2) by the track commands below, so the router keeps neighbouring wires on opposite masks. |",
          "| M1 | single mask at 54 nm pitch | Cell pins are colour-agnostic, so a cell is legal at any (odd or even) site. Same-mask spacing is already met by the 54 nm pitch. |",
          "| Sites | coreSite, coreSite2R, coreSite4R, gaSite (4 CPP), memSite (2 CPP), ioSite, cornerSite | Multi-row cells sit on stacked coreSite rows; gaSite is the gate-array ECO tile; memSite is the macro grid. |",
          "| LEF layer content | PITCH, OFFSET, WIDTH, MINWIDTH, MAXWIDTH, default SPACING, EOL spacing, PRL/width SPACINGTABLE, AREA, MINENCLOSEDAREA, LEF58 corner/EOL-keepout/min-step/rect-only/right-way-on-grid, density windows, DC/AC(RMS, peak) current density, antenna ratios, RC | One block per layer in tech/r14n7_tech.lef. |",
          "| FinFET properties | R14_FINGRID (fin pitch/width/offset, fins per row/device, CPP, Lg), FIN/GATE masterslice layers | Lets placement and legality checkers know the fin grid. Vt implant islands must be >= 1 CPP (LEF58_CELLEDGESPACINGTABLE, macro LEF58_EDGETYPE). |",
          "| Current density (DC avg, 105C) | M1-M3 1.6, M4/M5 2.2, M6/M7 3.0, M8/M9 4.2 mA/um; RMS 3x, peak 12x | Used for EM signoff of signal and power nets. Via limits are given per cut area. |",
          "| Non-default rule | NDR_2W2S (2x width, 2x space on M2-M7) | For clock trees. |", ""]
    o += ["## 5. Track definition commands", "", "Cadence Innovus (flows/pnr/r14n7_tracks_innovus.tcl):", "", "```", tracks_innovus().strip(), "```", "",
          "Synopsys ICC2 (flows/pnr/r14n7_tracks_icc2.tcl):", "", "```", tracks_icc2().strip(), "```", ""]
    return "\n".join(o) + "\n"

def tracks_innovus():
    o = ["# R14N7 routing tracks (Innovus) -- generated from gen/tech.py", "deleteTracks"]
    for (m, d, p, w, s, t, off) in METALS:
        dr = "x" if d == "VERTICAL" else "y"
        mp = " -mask_pattern {1 2}" if m in ("M2", "M3") else ""
        o.append("add_tracks -layer %s -direction %s -pitch %.3f -offset %.3f%s" % (m, "vertical" if d == "VERTICAL" else "horizontal", p / 1e3, off / 1e3, mp))
    return "\n".join(o) + "\n"

def tracks_icc2():
    o = ["# R14N7 routing tracks (ICC2) -- generated from gen/tech.py", "remove_tracks -all"]
    for (m, d, p, w, s, t, off) in METALS:
        mp = " -mask_pattern {mask_one mask_two}" if m in ("M2", "M3") else ""
        o.append("create_track -layer %s -dir %s -space %.3f -coord %.3f%s" % (m, "Y" if d == "VERTICAL" else "X", p / 1e3, off / 1e3, mp))
    o.append("set_attribute [get_site_defs coreSite] symmetry {Y}")
    o.append("set_attribute [get_layers {M1 M3 M5 M7 M9}] routing_direction vertical")
    o.append("set_attribute [get_layers {M2 M4 M6 M8}] routing_direction horizontal")
    return "\n".join(o) + "\n"

if __name__ == "__main__":
    import sys
    open(sys.argv[1], "w").write(md())
