"""AOCV derate tables and POCV (sigma coefficient) side files (Synopsys PrimeTime formats)."""
import math
import charmodel as cm
from tech import BANNER
from cells import dnum

DEPTHS = [1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 30, 50]
DISTS = [0, 100, 500, 1000, 2000, 5000]     # um, bounding-box diagonal

def cell_sigma(c, cname):
    nfin = 3 if dnum(c.drive) >= 1 else 2
    fins = nfin * max(1, int(dnum(c.drive)))
    stages = 1.0 + (max([a.d0 for a in c.arcs] + [0]) / 6.0)
    return cm.sigma_rel(cname, c.vt, fins, stages)

def write_aocv(path, cells, lib, corner, nsig=3.0):
    o = ["# " + BANNER, "# AOCV derate tables, library %s, corner %s (%.1f-sigma random + systematic distance term)" % (lib, corner.name, nsig)]
    seen = {}
    for c in cells:
        if c.physical_only or not c.arcs: continue
        key = (c.base, c.drive)
        s = cell_sigma(c, corner.name)
        for dtype, sign in (("late", 1), ("early", -1)):
            for ptype in ("clock data",):
                o += ["", "version: 1.0", "object_type: lib_cell", "rf_type: rise fall", "delay_type: cell net" if False else "delay_type: cell",
                      "derate_type: %s" % dtype, "path_type: %s" % ptype, "object_spec: %s/%s" % (lib, c.name),
                      "depth: " + " ".join(str(d) for d in DEPTHS), "distance: " + " ".join(str(d) for d in DISTS), "table: \\"]
                rows = []
                for di in DISTS:
                    sysv = 0.004 * math.log10(1 + di / 10.0)
                    rows.append(" ".join("%.4f" % (1 + sign * (nsig * s / math.sqrt(d) + sysv)) for d in DEPTHS))
                o.append(" \\\n".join(rows))
    open(path, "w").write("\n".join(o) + "\n")

def write_pocv(path, cells, lib, corner):
    o = ["# " + BANNER, "# POCV single-coefficient side file (sigma/mean), library %s corner %s" % (lib, corner.name),
         "# LVF tables inside the .lib take precedence when both are loaded.", "version: 4.0", "ocvm_type: pocvm"]
    for c in cells:
        if c.physical_only or not c.arcs: continue
        s = cell_sigma(c, corner.name)
        o += ["", "object_type: lib_cell", "rf_type: rise fall", "delay_type: cell", "derate_type: early late",
              "object_spec: %s/%s" % (lib, c.name), "coefficient: %.5f" % s]
    o += ["", "object_type: design", "rf_type: rise fall", "delay_type: net", "derate_type: early late",
          "object_spec: *", "coefficient: 0.02000"]
    open(path, "w").write("\n".join(o) + "\n")
