"""R14N7 standard-cell / clock / sequential / multi-bit / gate-array / physical / PMK
catalog.  Every cell is built from a transistor netlist (netlist.NB); all other views
derive from the Cell objects produced here."""
import math
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from netlist import NB
from tech import VT_FLAVORS, CPP, ROW_H, M1_P
import boolexpr as bx

# ------------------------------------------------------------------ data model
@dataclass
class Pin:
    name: str
    dir: str                    # input / output / inout / internal
    role: str = "data"          # data clock reset set scan_in scan_enable enable test iso sleep retain
    width: int = 1
    pwr: str = "VDD"
    gnd: str = "VSS"
    cap: float = 0.0            # fF (per bit)

@dataclass
class Arc:
    frm: str
    to: str
    ttype: str                  # combinational rising_edge falling_edge clear preset
    sense: str                  # positive_unate negative_unate non_unate
    d0: float                   # internal (pre-output-stage) delay, ps nominal
    when: str = ""
    rise: bool = True
    fall: bool = True

@dataclass
class Con:
    pin: str
    rel: str
    kind: str                   # setup_rising hold_rising recovery_rising removal_rising setup_falling hold_falling
    base: float                 # ps nominal
    when: str = ""

@dataclass
class Cell:
    name: str
    base: str
    vt: str
    drive: str
    family: str
    desc: str
    pins: List[Pin]
    funcs: Dict[str, str]
    nb: NB
    arcs: List[Arc] = field(default_factory=list)
    cons: List[Con] = field(default_factory=list)
    seq: Optional[dict] = None
    rows: int = 1
    sites: int = 0
    pg: list = field(default_factory=lambda: [("VDD", "primary_power", "VDD"), ("VSS", "primary_ground", "VSS")])
    attrs: dict = field(default_factory=dict)
    mpw: dict = field(default_factory=dict)       # pin -> (high_ps, low_ps)
    physical_only: bool = False
    vkind: str = "comb"                           # verilog model style
    vextra: dict = field(default_factory=dict)
    lib: str = "std"                              # std | pmk
    @property
    def area(self): return round(self.sites * CPP * self.rows * ROW_H * 1e-6, 6)
    @property
    def width_um(self): return self.sites * CPP / 1000.0
    @property
    def height_um(self): return self.rows * ROW_H / 1000.0
    def inputs(self):  return [p for p in self.pins if p.dir == "input"]
    def outputs(self): return [p for p in self.pins if p.dir == "output"]
    def pin(self, n):  return next(p for p in self.pins if p.name == n)
    def bits(self):
        return max([p.width for p in self.pins] + [1])

def dnum(drive):
    return 0.5 if drive == "X0P5" else float(drive[1:])
def dname(d):
    return "X0P5" if d == 0.5 else "X%d" % d
from tech import FINS_PER_DEV
def nfin_nf(d):
    return (max(2, (2 * FINS_PER_DEV) // 3), 1) if d < 1 else (FINS_PER_DEV, int(d))

def finalize(c: Cell, min_sites=None):
    nb = c.nb
    for p in c.pins:
        if p.dir == "input":
            key = p.name if p.width == 1 else p.name + "<0>"
            p.cap = round(max(nb.pin_cap(key), 0.05), 4)
            if p.width > 1:
                p.cap = round(max(nb.pin_cap(p.name + "<0>"), 0.05), 4)
    cols = nb.gate_columns()
    s = int(math.ceil(cols / float(c.rows))) + 2
    npins = sum(p.width for p in c.pins if p.dir in ("input", "output")) + len([1 for n, t, v in c.pg if n not in ("VDD", "VSS")])
    need = int(math.ceil(npins / float(c.rows))) + 1      # one M1 track per site, keep one spare
    c.sites = max(s, need, min_sites or 0, 2)
    # sizing record (used by verify/size_check.py and the databook):
    #  dev   = ceil(gate columns / rows) + 2  (interior gates = sites-1, plus one spare/diffusion-break column)
    #  pin   = ceil(signal + secondary-PG pins / rows) + 1  (one M1 track per site + one spare)
    #  fixed = explicit minimum (power-switch finger arrays)
    c.sizing = dict(rule="std", dev=s, pin=need, fixed=min_sites or 0, cols=cols)
    return c

def mk(base, vt, drive, family, desc, pins, funcs, nb, **kw):
    name = "%s_%s_%s" % (base, drive, vt)
    c = Cell(name, base, vt, drive, family, desc, pins, funcs, nb, **kw)
    return c

def ipins(names, role="data", **k): return [Pin(n, "input", role, **k) for n in names]
def opins(names, **k): return [Pin(n, "output", "data", **k) for n in names]

# ------------------------------------------------------------------ combinational
def output_stage_nf(d):
    """output inverter fingers & first stage fingers for buffered cells"""
    nfin, nf = nfin_nf(d)
    pre = max(1, int(round(nf / 4.0))) if nf > 1 else 1
    return nfin, nf, pre

def comb_arcs(c: Cell):
    ins = [p.name for p in c.inputs()]
    for o, f in c.funcs.items():
        for i in ins:
            if not bx.depends(f, i, ins): continue
            d0 = c.nb.path_delay(i, o) or 0.0
            c.arcs.append(Arc(i, o, "combinational", bx.unateness(f, i, ins), round(d0, 3)))
    return c

# --- complex-gate pull-down expressions (inputs) -----------------------------------
def aoi_expr(groups):
    """groups e.g. [2,1] -> AOI21: pd = p[s[A1,A2], B]; returns pd, names, liberty func"""
    letters = "ABCDE"; terms = []; names = []; fterms = []
    for gi, n in enumerate(groups):
        if n == 1:
            nm = [letters[gi]]
        else:
            nm = ["%s%d" % (letters[gi], k + 1) for k in range(n)]
        names += nm
        terms.append(nm[0] if n == 1 else ("s", nm))
        fterms.append(nm[0] if n == 1 else "(" + "&".join(nm) + ")")
    pd = ("p", terms)
    return pd, names, "(" + "|".join(fterms) + ")"

def oai_expr(groups):
    letters = "ABCDE"; terms = []; names = []; fterms = []
    for gi, n in enumerate(groups):
        nm = [letters[gi]] if n == 1 else ["%s%d" % (letters[gi], k + 1) for k in range(n)]
        names += nm
        terms.append(nm[0] if n == 1 else ("p", nm))
        fterms.append(nm[0] if n == 1 else "(" + "|".join(nm) + ")")
    return ("s", terms), names, "(" + "&".join(fterms) + ")"

COMPLEX = ["21", "211", "22", "221", "222", "31", "311", "32", "33"]

def build_comb(vt):
    cells = []
    def add(c): cells.append(comb_arcs(finalize(c)))
    # INV / BUF
    for d in [0.5, 1, 2, 3, 4, 6, 8, 12, 16]:
        nb = NB(vt); nfin, nf = nfin_nf(d); nb.inv("Y", "A", nf, nfin)
        add(mk("INV", vt, dname(d), "comb", "Inverter", ipins(["A"]) + opins(["Y"]), {"Y": "!A"}, nb))
    for d in [1, 2, 3, 4, 6, 8, 12, 16]:
        nb = NB(vt); nfin, nf, pre = output_stage_nf(d)
        nb.inv("n0", "A", pre, 3); nb.inv("Y", "n0", nf, nfin)
        add(mk("BUF", vt, dname(d), "comb", "Non-inverting buffer", ipins(["A"]) + opins(["Y"]), {"Y": "A"}, nb))
    # NAND/NOR/AND/OR 2..4
    for n in (2, 3, 4):
        ins = ["A%d" % (k + 1) for k in range(n)] if False else list("ABCD"[:n])
        for d in (1, 2, 4):
            nfin, nf = nfin_nf(d)
            nb = NB(vt); nb.nand("Y", ins, nf, nfin)
            add(mk("NAND%d" % n, vt, dname(d), "comb", "%d-input NAND" % n, ipins(ins) + opins(["Y"]),
                   {"Y": "!(" + "&".join(ins) + ")"}, nb))
            nb = NB(vt); nb.nor("Y", ins, nf, nfin)
            add(mk("NOR%d" % n, vt, dname(d), "comb", "%d-input NOR" % n, ipins(ins) + opins(["Y"]),
                   {"Y": "!(" + "|".join(ins) + ")"}, nb))
            nfin, nf, pre = output_stage_nf(d)
            nb = NB(vt); nb.nand("n0", ins, pre, 3); nb.inv("Y", "n0", nf, nfin)
            add(mk("AND%d" % n, vt, dname(d), "comb", "%d-input AND" % n, ipins(ins) + opins(["Y"]),
                   {"Y": "&".join(ins)}, nb))
            nb = NB(vt); nb.nor("n0", ins, pre, 3); nb.inv("Y", "n0", nf, nfin)
            add(mk("OR%d" % n, vt, dname(d), "comb", "%d-input OR" % n, ipins(ins) + opins(["Y"]),
                   {"Y": "|".join(ins)}, nb))
    # NAND2B / NOR2B (one inverted input)
    for d in (1, 2, 4):
        nfin, nf = nfin_nf(d)
        nb = NB(vt); nb.inv("anb", "AN", 1, 2); nb.nand("Y", ["anb", "B"], nf, nfin)
        add(mk("NAND2B", vt, dname(d), "comb", "2-input NAND, A inverted", ipins(["AN", "B"]) + opins(["Y"]),
               {"Y": "!(!AN&B)"}, nb))
        nb = NB(vt); nb.inv("anb", "AN", 1, 2); nb.nor("Y", ["anb", "B"], nf, nfin)
        add(mk("NOR2B", vt, dname(d), "comb", "2-input NOR, A inverted", ipins(["AN", "B"]) + opins(["Y"]),
               {"Y": "!(!AN|B)"}, nb))
    # XOR / XNOR
    for d in (1, 2, 4):
        nfin, nf = nfin_nf(d)
        for nm, inner, fn in (("XOR2", "xnor", "A^B"), ("XNOR2", "xor", "!(A^B)")):
            nb = NB(vt); nb.inv("ab", "A", 1, 2); nb.inv("bb", "B", 1, 2)
            if inner == "xnor":   # inner = !(A&!B | !A&B) = XNOR
                nb.gate("x", ("p", [("s", ["A", "bb"]), ("s", ["ab", "B"])]), 1, 3)
            else:
                nb.gate("x", ("p", [("s", ["A", "B"]), ("s", ["ab", "bb"])]), 1, 3)
            nb.inv("Y", "x", nf, nfin)
            add(mk(nm, vt, dname(d), "comb", "2-input %s" % nm[:-1], ipins(["A", "B"]) + opins(["Y"]), {"Y": fn}, nb))
    for d in (1, 2):
        nfin, nf = nfin_nf(d)
        for nm, fn in (("XOR3", "A^B^C"), ("XNOR3", "!(A^B^C)")):
            nb = NB(vt); nb.inv("ab", "A", 1, 2); nb.inv("bb", "B", 1, 2)
            nb.gate("x1", ("p", [("s", ["A", "bb"]), ("s", ["ab", "B"])]), 1, 3)   # xnor(A,B)
            nb.inv("x1b", "x1", 1, 2); nb.inv("cb", "C", 1, 2)
            if nm == "XOR3":   # Y = (A^B)^C ;  inner = xnor(x1b, C)
                nb.gate("x2", ("p", [("s", ["x1b", "cb"]), ("s", ["x1", "C"])]), 1, 3)
            else:
                nb.gate("x2", ("p", [("s", ["x1b", "C"]), ("s", ["x1", "cb"])]), 1, 3)
            nb.inv("Y", "x2", nf, nfin)
            add(mk(nm, vt, dname(d), "comb", "3-input %s" % nm[:-1], ipins(["A", "B", "C"]) + opins(["Y"]), {"Y": fn}, nb))
    # AOI / OAI / AO / OA complex gates
    for g in COMPLEX:
        groups = [int(ch) for ch in g]
        for d in (1, 2, 4):
            nfin, nf = nfin_nf(d)
            pd, names, f = aoi_expr(groups)
            nb = NB(vt); nb.gate("Y", pd, nf, nfin)
            add(mk("AOI" + g, vt, dname(d), "comb", "AND-OR-Invert %s" % g, ipins(names) + opins(["Y"]), {"Y": "!" + f}, nb))
            nb = NB(vt); nb.gate("n0", pd, 1, 3); _, onf, _ = output_stage_nf(d); nb.inv("Y", "n0", onf, nfin)
            add(mk("AO" + g, vt, dname(d), "comb", "AND-OR %s" % g, ipins(names) + opins(["Y"]), {"Y": f}, nb))
            pd, names, f = oai_expr(groups)
            nb = NB(vt); nb.gate("Y", pd, nf, nfin)
            add(mk("OAI" + g, vt, dname(d), "comb", "OR-AND-Invert %s" % g, ipins(names) + opins(["Y"]), {"Y": "!" + f}, nb))
            nb = NB(vt); nb.gate("n0", pd, 1, 3); nb.inv("Y", "n0", onf, nfin)
            add(mk("OA" + g, vt, dname(d), "comb", "OR-AND %s" % g, ipins(names) + opins(["Y"]), {"Y": f}, nb))
    # inverted-input complex gates  AOI2BB1: Y = !((!A1N & !A2N) | B) ; AOI2BB2: !((!A1N&!A2N)|(B1&B2))
    for d in (1, 2):
        nfin, nf = nfin_nf(d)
        nb = NB(vt); nb.nor("a", ["A1N", "A2N"], 1, 2); nb.gate("Y", ("p", ["a", "B"]), nf, nfin)
        add(mk("AOI2BB1", vt, dname(d), "comb", "AOI21 with inverted A inputs", ipins(["A1N", "A2N", "B"]) + opins(["Y"]),
               {"Y": "!((!A1N&!A2N)|B)"}, nb))
        nb = NB(vt); nb.nor("a", ["A1N", "A2N"], 1, 2); nb.gate("Y", ("p", ["a", ("s", ["B1", "B2"])]), nf, nfin)
        add(mk("AOI2BB2", vt, dname(d), "comb", "AOI22 with inverted A inputs", ipins(["A1N", "A2N", "B1", "B2"]) + opins(["Y"]),
               {"Y": "!((!A1N&!A2N)|(B1&B2))"}, nb))
        nb = NB(vt); nb.nand("a", ["A1N", "A2N"], 1, 2); nb.gate("Y", ("s", ["a", "B"]), nf, nfin)
        add(mk("OAI2BB1", vt, dname(d), "comb", "OAI21 with inverted A inputs", ipins(["A1N", "A2N", "B"]) + opins(["Y"]),
               {"Y": "!((!A1N|!A2N)&B)"}, nb))
        nb = NB(vt); nb.nand("a", ["A1N", "A2N"], 1, 2); nb.gate("Y", ("s", ["a", ("p", ["B1", "B2"])]), nf, nfin)
        add(mk("OAI2BB2", vt, dname(d), "comb", "OAI22 with inverted A inputs", ipins(["A1N", "A2N", "B1", "B2"]) + opins(["Y"]),
               {"Y": "!((!A1N|!A2N)&(B1|B2))"}, nb))
    # MUX
    for d in (1, 2, 4):
        nfin, nf = nfin_nf(d)
        nb = NB(vt); nb.inv("sb", "S", 1, 2)
        nb.gate("x", ("p", [("s", ["I0", "sb"]), ("s", ["I1", "S"])]), 1, 3); nb.inv("Y", "x", nf, nfin)
        add(mk("MUX2", vt, dname(d), "comb", "2:1 multiplexer", ipins(["I0", "I1", "S"]) + opins(["Y"]),
               {"Y": "(I0&!S)|(I1&S)"}, nb))
    for d in (1, 2):
        nfin, nf = nfin_nf(d)
        nb = NB(vt); nb.inv("sb", "S", 1, 2)
        nb.gate("Y", ("p", [("s", ["I0", "sb"]), ("s", ["I1", "S"])]), nf, nfin)
        add(mk("MXI2", vt, dname(d), "comb", "2:1 inverting multiplexer", ipins(["I0", "I1", "S"]) + opins(["Y"]),
               {"Y": "!((I0&!S)|(I1&S))"}, nb))
        nb = NB(vt); nb.inv("s0b", "S0", 1, 2); nb.inv("s1b", "S1", 1, 2)
        nb.gate("m0", ("p", [("s", ["I0", "s0b"]), ("s", ["I1", "S0"])]), 1, 3)
        nb.gate("m1", ("p", [("s", ["I2", "s0b"]), ("s", ["I3", "S0"])]), 1, 3)
        nb.gate("Y", ("p", [("s", ["m0", "s1b"]), ("s", ["m1", "S1"])]), nf, nfin)   # m0/m1 inverted -> Y = mux
        add(mk("MUX4", vt, dname(d), "comb", "4:1 multiplexer", ipins(["I0", "I1", "I2", "I3", "S0", "S1"]) + opins(["Y"]),
               {"Y": "(I0&!S0&!S1)|(I1&S0&!S1)|(I2&!S0&S1)|(I3&S0&S1)"}, nb))
    # arithmetic: HADD / FADD (mirror adder)
    for d in (1, 2, 4):
        nfin, nf, pre = output_stage_nf(d)
        nb = NB(vt); nb.inv("ab", "A", 1, 2); nb.inv("bb", "B", 1, 2)
        nb.gate("sx", ("p", [("s", ["A", "bb"]), ("s", ["ab", "B"])]), 1, 3)      # xnor
        nb.inv("S", "sx", nf, nfin)
        nb.nand("cx", ["A", "B"], 1, 3); nb.inv("CO", "cx", nf, nfin)
        add(mk("HADD", vt, dname(d), "arith", "Half adder (S=A^B, CO=A&B)", ipins(["A", "B"]) + opins(["CO", "S"]),
               {"S": "A^B", "CO": "A&B"}, nb))
        nb = NB(vt)
        nb.gate("cob", ("p", [("s", ["A", "B"]), ("s", ["CI", ("p", ["A", "B"])])]), pre, 3)
        nb.gate("sb", ("p", [("s", ["A", "B", "CI"]), ("s", ["cob", ("p", ["A", "B", "CI"])])]), pre, 3)
        nb.inv("CO", "cob", nf, nfin); nb.inv("S", "sb", nf, nfin)
        add(mk("FADD", vt, dname(d), "arith", "Full adder, mirror topology (S=A^B^CI, CO=maj)", ipins(["A", "B", "CI"]) + opins(["CO", "S"]),
               {"S": "A^B^CI", "CO": "(A&B)|(A&CI)|(B&CI)"}, nb))
    # TIE
    nb = NB(vt); nb.fet("n", "nt", "nt", "VSS", 1, 2); nb.fet("p", "Y", "nt", "VDD", 1, 2); nb.stages["Y"] = None
    c = finalize(mk("TIEHI", vt, "X1", "tie", "Tie-high", opins(["Y"]), {"Y": "1"}, nb)); c.attrs["dont_touch"] = True; cells.append(c)
    nb = NB(vt); nb.fet("p", "pt", "pt", "VDD", 1, 2); nb.fet("n", "Y", "pt", "VSS", 1, 2); nb.stages["Y"] = None
    c = finalize(mk("TIELO", vt, "X1", "tie", "Tie-low", opins(["Y"]), {"Y": "0"}, nb)); c.attrs["dont_touch"] = True; cells.append(c)
    # data delay cells (stacked inverter chains)
    for k, n in ((1, 4), (2, 6), (3, 8), (4, 12)):
        cells.append(delay_cell("DLY%d" % k, vt, n, "delay", "Data delay cell, %d stacked stages" % n))
    return cells

def delay_cell(base, vt, nstage, family, desc, drive=1):
    nb = NB(vt); prev = "A"
    for i in range(nstage):
        o = "Y" if i == nstage - 1 else "d%d" % i
        nfin, nf = nfin_nf(drive) if o == "Y" else (2, 1)
        if o == "Y" or i % 2 == 0:
            nb.inv(o, prev, nf, nfin)
        else:
            nb.gate(o, ("s", [prev, prev + "_"]) if False else prev, 1, 2)
        # make internal stages slow: extra series device (stack) with gate tied to input node
        prev = o
    # each internal stage gets a stacking device for delay -> long-L devices
    for dv in nb.devs:
        if dv.d != "Y" and dv.s != "Y": dv.l = 60
    c = finalize(mk(base, vt, dname(drive), family, desc, ipins(["A"]) + opins(["Y"]), {"Y": "A" if nstage % 2 == 0 else "!A"}, nb))
    comb_arcs(c)
    for a in c.arcs: a.d0 = round(6.5 * nstage * (1.0 if family == "delay" else 0.9), 2)
    return c

# ------------------------------------------------------------------ clock cells
def build_clock(vt):
    cells = []
    def add(c):
        c.attrs["is_clock_cell"] = True; cells.append(comb_arcs(finalize(c)))
    for d in (1, 2, 3, 4, 6, 8, 12, 16):
        nfin, nf = nfin_nf(d)
        nb = NB(vt); nb.inv("Y", "A", nf, nfin)
        add(mk("CKINV", vt, dname(d), "clock", "Balanced clock inverter", ipins(["A"]) + opins(["Y"]), {"Y": "!A"}, nb))
        nfin, nf, pre = output_stage_nf(d)
        nb = NB(vt); nb.inv("n0", "A", max(1, nf // 3), 3); nb.inv("Y", "n0", nf, nfin)
        add(mk("CKBUF", vt, dname(d), "clock", "Balanced clock buffer", ipins(["A"]) + opins(["Y"]), {"Y": "A"}, nb))
    for d in (1, 2, 4):
        nfin, nf = nfin_nf(d)
        nb = NB(vt); nb.inv("sb", "S", 1, 2)
        nb.gate("x", ("p", [("s", ["I0", "sb"]), ("s", ["I1", "S"])]), 1, 3); nb.inv("Y", "x", nf, nfin)
        add(mk("CKMUX2", vt, dname(d), "clock", "Glitch-balanced clock mux", ipins(["I0", "I1", "S"]) + opins(["Y"]),
               {"Y": "(I0&!S)|(I1&S)"}, nb))
    for d in (1, 2, 4):
        nfin, nf = nfin_nf(d)
        nb = NB(vt); nb.nand("n0", ["A", "B"], 1, 3); nb.inv("Y", "n0", nf, nfin)
        add(mk("CKAND2", vt, dname(d), "clock", "Clock AND2", ipins(["A", "B"]) + opins(["Y"]), {"Y": "A&B"}, nb))
        nb = NB(vt); nb.nand("Y", ["A", "B"], nf, nfin)
        add(mk("CKNAND2", vt, dname(d), "clock", "Clock NAND2", ipins(["A", "B"]) + opins(["Y"]), {"Y": "!(A&B)"}, nb))
        nb = NB(vt); nb.nor("n0", ["A", "B"], 1, 3); nb.inv("Y", "n0", nf, nfin)
        add(mk("CKOR2", vt, dname(d), "clock", "Clock OR2", ipins(["A", "B"]) + opins(["Y"]), {"Y": "A|B"}, nb))
        nb = NB(vt); nb.nor("Y", ["A", "B"], nf, nfin)
        add(mk("CKNOR2", vt, dname(d), "clock", "Clock NOR2", ipins(["A", "B"]) + opins(["Y"]), {"Y": "!(A|B)"}, nb))
        nb = NB(vt); nb.inv("ab", "A", 1, 2); nb.inv("bb", "B", 1, 2)
        nb.gate("x", ("p", [("s", ["A", "bb"]), ("s", ["ab", "B"])]), 1, 3); nb.inv("Y", "x", nf, nfin)
        add(mk("CKXOR2", vt, dname(d), "clock", "Clock XOR2", ipins(["A", "B"]) + opins(["Y"]), {"Y": "A^B"}, nb))
    for k, n in ((1, 4), (2, 6), (3, 8), (4, 12), (5, 16)):
        c = delay_cell("CKD%d" % k, vt, n, "clock", "Clock delay cell, %d balanced stages" % n, drive=2)
        c.attrs["is_clock_cell"] = True; cells.append(c)
    cells += build_icg(vt)
    return cells

# ------------------------------------------------------------------ sequential
def _clk(nb, ck, neg=False, sup=None):
    """returns (cki, ckb): cki follows active edge polarity"""
    nb.inv("ckb", ck, 1, 2, sup=sup); nb.inv("cki", "ckb", 1, 2, sup=sup)
    return ("ckb", "cki") if neg else ("cki", "ckb")

def ff_core(nb, din, cki, ckb, q, qn=None, rn=None, sn=None, nf=1, nfin=3, pfx="", slave_sup=None):
    """TG master-slave, positive edge relative to cki.  Reset dominant."""
    m1, m2, s1, s2 = pfx + "m1", pfx + "m2", pfx + "s1", pfx + "s2"
    nb.tg(din, m1, ckb, cki)                          # master transparent when cki=0
    rb = sb = None
    if sn and not rn:
        sb = pfx + "sb"; nb.inv(sb, sn, 1, 2)
        nb.nor(m2, [m1, sb], 1, 2)
    elif rn and sn:
        sb = pfx + "sb"; nb.inv(sb, sn, 1, 2)
        nb.gate(m2, ("s", [("p", [m1, sb]), rn]), 1, 2)
    elif rn:
        nb.nand(m2, [m1, rn], 1, 2)
    else:
        nb.inv(m2, m1, 1, 2)
    nb.cinv(m1, m2, cki, ckb)                          # master keeper
    nb.tg(m2, s1, cki, ckb, sup=slave_sup)            # slave transparent when cki=1
    if rn and sn:
        rb = pfx + "rb"; nb.inv(rb, rn, 1, 2, sup=slave_sup)
        nb.gate(s2, ("p", [("s", [s1, sn]), rb]), 1, 2, sup=slave_sup)
    elif rn:
        rb = pfx + "rb"; nb.inv(rb, rn, 1, 2, sup=slave_sup); nb.nor(s2, [s1, rb], 1, 2, sup=slave_sup)
    elif sn:
        nb.nand(s2, [s1, sn], 1, 2, sup=slave_sup)
    else:
        nb.inv(s2, s1, 1, 2, sup=slave_sup)
    nb.cinv(s1, s2, ckb, cki, sup=slave_sup)           # slave keeper
    nb.inv(q, s1, nf, nfin)
    if qn: nb.inv(qn, s2, nf, nfin)

def scan_mux(nb, d, si, se, out):
    nb.inv("seb", se, 1, 2)
    nb.gate("dmx", ("p", [("s", [d, "seb"]), ("s", [si, se])]), 1, 2)
    nb.inv(out, "dmx", 1, 2)

SEQ_TYPES = {
    # base: (rn, sn, scan, neg, sync_r, enable, qn)
    "DFF": (0, 0, 0, 0, 0, 0, 0), "DFFQN": (0, 0, 0, 0, 0, 0, 1), "DFFN": (0, 0, 0, 1, 0, 0, 0),
    "DFFR": (1, 0, 0, 0, 0, 0, 0), "DFFRQN": (1, 0, 0, 0, 0, 0, 1), "DFFS": (0, 1, 0, 0, 0, 0, 0),
    "DFFRS": (1, 1, 0, 0, 0, 0, 0), "DFFNR": (1, 0, 0, 1, 0, 0, 0), "DFFSYNR": (0, 0, 0, 0, 1, 0, 0),
    "EDFF": (0, 0, 0, 0, 0, 1, 0),
    "SDFF": (0, 0, 1, 0, 0, 0, 0), "SDFFQN": (0, 0, 1, 0, 0, 0, 1), "SDFFN": (0, 0, 1, 1, 0, 0, 0),
    "SDFFR": (1, 0, 1, 0, 0, 0, 0), "SDFFS": (0, 1, 1, 0, 0, 0, 0), "SDFFRS": (1, 1, 1, 0, 0, 0, 0),
    "SDFFSYNR": (0, 0, 1, 0, 1, 0, 0), "SEDFF": (0, 0, 1, 0, 0, 1, 0),
}

def seq_cell(base, vt, d, flags=None, family="seq"):
    rn, sn, scan, neg, syncr, en, qn = flags or SEQ_TYPES[base]
    nfin, nf = nfin_nf(d)
    nb = NB(vt)
    pins = ipins(["D"])
    if en: pins += ipins(["E"], "enable")
    if syncr: pins += ipins(["RN"], "data")
    if scan: pins += [Pin("SI", "input", "scan_in"), Pin("SE", "input", "scan_enable")]
    pins += [Pin("CK", "input", "clock")]
    if rn and not syncr: pins += [Pin("RN", "input", "reset")]
    if sn: pins += [Pin("SN", "input", "set")]
    pins += opins(["Q"] + (["QN"] if qn else []))
    din = "D"
    if en:
        nb.inv("eb", "E", 1, 2); nb.gate("emx", ("p", [("s", ["D", "E"]), ("s", ["Q", "eb"])]), 1, 2)
        nb.inv("de", "emx", 1, 2); din = "de"
    if syncr:
        nb.nand("srx", [din, "RN"], 1, 2); nb.inv("dr", "srx", 1, 2); din = "dr"
    if scan:
        scan_mux(nb, din, "SI", "SE", "ds"); din = "ds"
    cki, ckb = _clk(nb, "CK", neg)
    ff_core(nb, din, cki, ckb, "Q", "QN" if qn else None, "RN" if (rn and not syncr) else None,
            "SN" if sn else None, nf, nfin)
    ns = "D"
    if en: ns = "(D&E)|(IQ&!E)"
    if syncr: ns = "(%s)&RN" % ns if ns != "D" else "D&RN"
    seqd = dict(kind="ff", clocked_on="!CK" if neg else "CK", next_state=ns)
    if rn and not syncr: seqd["clear"] = "!RN"
    if sn: seqd["preset"] = "!SN"
    if rn and sn and not syncr: seqd["cpv1"] = "L"; seqd["cpv2"] = "H"
    if scan:
        seqd["scan_ns"] = "((%s)&!SE)|(SI&SE)" % ns
    funcs = {"Q": "IQ"}
    if qn: funcs["QN"] = "IQN"
    c = mk(base, vt, dname(d), family, _seq_desc(base, rn, sn, scan, neg, syncr, en, qn), pins, funcs, nb, seq=seqd, vkind="ff")
    finalize(c)
    edge = "falling_edge" if neg else "rising_edge"
    sfx = "falling" if neg else "rising"
    ckq = 16.0 + (1.5 if (rn or sn) else 0.0)
    for o in funcs:
        c.arcs.append(Arc("CK", o, edge, "non_unate", ckq + (2.5 if o == "QN" else 0)))
        if rn and not syncr:
            c.arcs.append(Arc("RN", o, "clear" if o == "Q" else "preset", "positive_unate" if o == "Q" else "negative_unate",
                              11.0, rise=(o == "QN"), fall=(o == "Q")))
        if sn:
            c.arcs.append(Arc("SN", o, "preset" if o == "Q" else "clear", "negative_unate" if o == "Q" else "positive_unate",
                              10.0, rise=(o == "Q"), fall=(o == "QN")))
    su = 9.0 + (6.0 if scan else 0) + (5.0 if en else 0) + (4.0 if syncr else 0)
    dpins = ["D"] + (["E"] if en else []) + (["RN"] if syncr else [])
    for p in dpins:
        c.cons += [Con(p, "CK", "setup_" + sfx, su, "!SE" if scan else ""), Con(p, "CK", "hold_" + sfx, 3.0, "!SE" if scan else "")]
    if scan:
        c.cons += [Con("SI", "CK", "setup_" + sfx, 14.0, "SE"), Con("SI", "CK", "hold_" + sfx, 3.5, "SE"),
                   Con("SE", "CK", "setup_" + sfx, 17.0), Con("SE", "CK", "hold_" + sfx, 4.0)]
    for p in (["RN"] if rn and not syncr else []) + (["SN"] if sn else []):
        c.cons += [Con(p, "CK", "recovery_" + sfx, 7.0), Con(p, "CK", "removal_" + sfx, 4.0)]
        c.mpw[p] = (None, 18.0)
    c.mpw["CK"] = (22.0, 22.0)
    return c

def _seq_desc(base, rn, sn, scan, neg, syncr, en, qn):
    s = ("Neg-edge " if neg else "Pos-edge ") + ("scan " if scan else "") + "D flip-flop"
    if en: s += ", load enable"
    if syncr: s += ", sync active-low reset"
    if rn and not syncr: s += ", async active-low reset"
    if sn: s += ", async active-low set"
    if qn: s += ", Q/QN"
    if scan: s += ", scan mux (SI/SE)"
    return s

def latch_cell(base, vt, d):
    neg = base.startswith("LATCHN")
    rn = "R" in base[5:] ; sn = base.endswith("S") or base.endswith("RS")
    nfin, nf = nfin_nf(d)
    nb = NB(vt); en = "EN" if neg else "E"
    pins = ipins(["D"]) + [Pin(en, "input", "clock")]
    if rn: pins.append(Pin("RN", "input", "reset"))
    if sn: pins.append(Pin("SN", "input", "set"))
    pins += opins(["Q"])
    # e=1 transparent
    if neg:
        nb.inv("ei", en, 1, 2); nb.inv("eb", "ei", 1, 2)   # ei=!EN active
        ea, eb = "ei", "eb"
    else:
        nb.inv("eb", en, 1, 2); nb.inv("ei", "eb", 1, 2); ea, eb = "ei", "eb"
    nb.tg("D", "m1", ea, eb)
    if rn and sn:
        nb.inv("sb", "SN", 1, 2); nb.gate("m2", ("s", [("p", ["m1", "sb"]), "RN"]), 1, 2)
    elif rn:
        nb.nand("m2", ["m1", "RN"], 1, 2)
    elif sn:
        nb.inv("sb", "SN", 1, 2); nb.nor("m2", ["m1", "sb"], 1, 2)
    else:
        nb.inv("m2", "m1", 1, 2)
    nb.cinv("m1", "m2", eb, ea)
    nb.inv("Q", "m2", nf, nfin)
    seqd = dict(kind="latch", enable=("!" + en) if neg else en, data_in="D")
    if rn: seqd["clear"] = "!RN"
    if sn: seqd["preset"] = "!SN"
    if rn and sn: seqd["cpv1"] = "L"; seqd["cpv2"] = "H"
    desc = ("Low" if neg else "High") + "-transparent D latch" + (", async reset" if rn else "") + (", async set" if sn else "")
    c = mk(base, vt, dname(d), "latch", desc, pins, {"Q": "IQ"}, nb, seq=seqd, vkind="latch")
    finalize(c)
    edge = "falling_edge" if neg else "rising_edge"
    c.arcs.append(Arc(en, "Q", edge, "non_unate", 12.0))
    c.arcs.append(Arc("D", "Q", "combinational", "positive_unate", 9.0))
    if rn: c.arcs.append(Arc("RN", "Q", "clear", "positive_unate", 9.0, rise=False))
    if sn: c.arcs.append(Arc("SN", "Q", "preset", "negative_unate", 9.0, fall=False))
    sfx = "rising" if neg else "falling"
    c.cons += [Con("D", en, "setup_" + sfx, 7.0), Con("D", en, "hold_" + sfx, 3.0)]
    c.mpw[en] = (20.0, 20.0) if not neg else (20.0, 20.0)
    return c

def build_seq(vt):
    cells = []
    for b in SEQ_TYPES:
        for d in (1, 2, 4):
            cells.append(seq_cell(b, vt, d))
    for b in ("LATCH", "LATCHN", "LATCHR", "LATCHS", "LATCHRS", "LATCHNR"):
        for d in (1, 2, 4):
            cells.append(latch_cell(b, vt, d))
    return cells

# ------------------------------------------------------------------ ICG
ICG_TYPES = {
    "ICGPRE":     ("latch_posedge_precontrol", 0, 1, 0),
    "ICGPOST":    ("latch_posedge_postcontrol", 0, 0, 0),
    "ICGPREOBS":  ("latch_posedge_precontrol_obs", 1, 1, 0),
    "ICGPOSTOBS": ("latch_posedge_postcontrol_obs", 1, 0, 0),
    "ICGNPRE":    ("latch_negedge_precontrol", 0, 1, 1),
    "ICGNPOST":   ("latch_negedge_postcontrol", 0, 0, 1),
}

def icg_cell(base, vt, d):
    ctype, obs, pre, neg = ICG_TYPES[base]
    nfin, nf = nfin_nf(d)
    nb = NB(vt)
    pins = [Pin("CK", "input", "clock"), Pin("E", "input", "enable"), Pin("SE", "input", "test")] + opins(["GCK"])
    if obs: pins.append(Pin("Q", "output", "data"))
    if pre:
        nb.nor("enb", ["E", "SE"], 1, 2); nb.inv("en", "enb", 1, 2); ld = "en"
    else:
        ld = "E"
    # latch transparent when CK low (posedge ICG) / CK high (negedge ICG)
    nb.inv("ckb", "CK", 1, 2)
    if neg: ea, eb = "CK", "ckb"
    else:   ea, eb = "ckb", "CK"
    nb.tg(ld, "l1", ea, eb); nb.inv("l2", "l1", 1, 2); nb.cinv("l1", "l2", eb, ea); nb.inv("lq", "l2", 1, 2)
    gen = "lq"
    if not pre:
        nb.nor("gx", ["lq", "SE"], 1, 2); nb.inv("ge", "gx", 1, 2); gen = "ge"
    if neg:   # GCK = CK | !gen
        nb.inv("genb", gen, 1, 2); nb.nor("gn", ["CK", "genb"] if False else ["ckb", gen], 1, 3)
        # gn = !(ckb | gen) ; GCK = !gn = ckb|gen ... implement GCK = CK | !gen:
        nb.devs = [dv for dv in nb.devs if dv.d != "gn" and dv.s != "gn"]
        nb.nand("gn", ["ckb", gen], max(1, nf // 2), 3)    # gn = !( !CK & gen ) = CK | !gen
        nb.inv("gnb", "gn", max(1, nf // 2), 3); nb.inv("GCK", "gnb", nf, nfin)
        sf = "CK|!IQ"
    else:
        nb.nand("gn", ["CK", gen], max(1, nf // 2), 3); nb.inv("GCK", "gn", nf, nfin)
        sf = "CK&IQ"
    if not pre: sf = sf.replace("IQ", "(IQ|SE)")
    if obs: nb.inv("Q", "l2", 1, 2)
    desc = "Integrated clock gate, %s edge, %s-control (SE %s latch)%s" % (
        "neg" if neg else "pos", "pre" if pre else "post", "before" if pre else "after", ", latch observe output Q" if obs else "")
    funcs = {"GCK": sf}
    if obs: funcs["Q"] = "IQ"
    c = mk(base, vt, dname(d), "icg", desc, pins, funcs, nb, vkind="icg",
           seq=dict(kind="icg", ctype=ctype, pre=pre, neg=neg, obs=obs))
    c.attrs["is_clock_cell"] = True
    finalize(c)
    c.arcs.append(Arc("CK", "GCK", "combinational", "positive_unate", 6.0))
    if obs: c.arcs.append(Arc("CK", "Q", "falling_edge" if not neg else "rising_edge", "non_unate", 11.0))
    sfx = "falling" if neg else "rising"
    c.cons += [Con("E", "CK", "setup_" + sfx, 12.0 if pre else 10.0), Con("E", "CK", "hold_" + sfx, 2.0),
               Con("SE", "CK", "setup_" + sfx, 12.0 if pre else 4.0), Con("SE", "CK", "hold_" + sfx, 2.0)]
    c.mpw["CK"] = (18.0, 18.0)
    return c

def build_icg(vt):
    out = []
    for b in ICG_TYPES:
        drs = (1, 2, 4, 8, 16) if b in ("ICGPRE", "ICGPOST") else (1, 2, 4)
        for d in drs: out.append(icg_cell(b, vt, d))
    return out

# ------------------------------------------------------------------ multi-bit
MB_TYPES = {"MBDFF": "DFF", "MBDFFR": "DFFR", "MBSDFF": "SDFF", "MBSDFFR": "SDFFR"}
MB_WIDTHS = (2, 4, 8, 16, 32)

def mb_cell(base, vt, n, d):
    ref = MB_TYPES[base]
    rn, sn, scan, neg, syncr, en, qn = SEQ_TYPES[ref]
    nfin, nf = nfin_nf(d)
    nb = NB(vt)
    rows = 1 if n <= 8 else (2 if n == 16 else 4)
    pins = [Pin("D", "input", "data", n)]
    if scan: pins += [Pin("SI", "input", "scan_in", n), Pin("SE", "input", "scan_enable")]
    pins += [Pin("CK", "input", "clock")]
    if rn: pins.append(Pin("RN", "input", "reset"))
    pins.append(Pin("Q", "output", "data", n))
    # shared clock & SE drivers (the multi-bit area/power advantage)
    nb.inv("ckb", "CK", max(1, n // 8), 3); nb.inv("cki", "ckb", max(1, n // 4), 3)
    if scan:
        nb.inv("se0", "SE", 1, 2); nb.inv("sei", "se0", max(1, n // 8), 2); nb.inv("seb", "sei", max(1, n // 8), 2)
    if rn: nb.inv("rbg", "RN", 1, 2); nb.inv("rng", "rbg", max(1, n // 8), 2)
    for b in range(n):
        p = "b%d_" % b; din = "D<%d>" % b
        if scan:
            nb.gate(p + "dmx", ("p", [("s", [din, "seb"]), ("s", ["SI<%d>" % b, "sei"])]), 1, 2)
            nb.inv(p + "ds", p + "dmx", 1, 2); din = p + "ds"
        ff_core(nb, din, "cki", "ckb", "Q<%d>" % b, None, "rng" if rn else None, None, nf, nfin, pfx=p)
    seqd = dict(kind="ff_bank", bits=n, clocked_on="CK", next_state="D")
    if rn: seqd["clear"] = "!RN"
    if scan: seqd["scan_ns"] = "(D&!SE)|(SI&SE)"
    desc = "%d-bit multi-bit %s (shared clock%s), %d-row" % (n, _seq_desc(ref, rn, sn, scan, neg, syncr, en, qn),
                                                         ", shared SE, per-bit SI" if scan else "", rows)
    c = mk("%s%d" % (base, n), vt, dname(d), "mbit", desc, pins, {"Q": "IQ"}, nb, seq=seqd, rows=rows, vkind="mbff")
    c.attrs["single_bit_degenerate"] = "%s_%s_%s" % (ref, dname(d), vt)
    finalize(c)
    ckq = 17.0 + 0.15 * n
    c.arcs.append(Arc("CK", "Q", "rising_edge", "non_unate", ckq))
    if rn: c.arcs.append(Arc("RN", "Q", "clear", "positive_unate", 12.0 + 0.1 * n, rise=False))
    su = 9.5 + (6.0 if scan else 0)
    c.cons += [Con("D", "CK", "setup_rising", su, "!SE" if scan else ""), Con("D", "CK", "hold_rising", 3.0, "!SE" if scan else "")]
    if scan:
        c.cons += [Con("SI", "CK", "setup_rising", 14.0, "SE"), Con("SI", "CK", "hold_rising", 3.5, "SE"),
                   Con("SE", "CK", "setup_rising", 18.0 + 0.1 * n), Con("SE", "CK", "hold_rising", 4.0)]
    if rn:
        c.cons += [Con("RN", "CK", "recovery_rising", 7.5), Con("RN", "CK", "removal_rising", 4.0)]
        c.mpw["RN"] = (None, 19.0)
    c.mpw["CK"] = (23.0, 23.0)
    return c

def build_mbit(vt):
    return [mb_cell(b, vt, n, d) for b in MB_TYPES for n in MB_WIDTHS for d in (1, 2)]

# ------------------------------------------------------------------ physical / gate-array
def decap_nb(vt, ncap):
    nb = NB(vt)
    nb.fet("p", "tlo", "thi", "VDD", 1, 2); nb.fet("n", "thi", "tlo", "VSS", 1, 2)  # cross-coupled tie
    # MOS caps
    for i in range(ncap):
        nb.fet("n", "VSS", "thi", "VSS", 1, 3, kind="cap"); nb.fet("p", "VDD", "tlo", "VDD", 1, 3, kind="cap")
    return nb

def phys(base, vt, sites, family, desc, nb=None, attrs=None, pins=None):
    c = mk(base, vt, "X1", family, desc, pins or [], {}, nb or NB(vt), physical_only=True, vkind="phys")
    c.sites = sites; c.attrs.update(attrs or {}); c.attrs.setdefault("dont_use", True); c.attrs.setdefault("dont_touch", True)
    c.sizing = dict(rule="fixed", dev=0, pin=0, fixed=sites, cols=0)
    return c

def build_phys(vt):
    out = []
    for n in (1, 2, 4, 8, 16, 32, 64):
        out.append(phys("FILL%d" % n, vt, n, "phys", "Filler, %d sites" % n, attrs={"is_filler_cell": True}))
    for n in (4, 8, 16, 32, 64):
        out.append(phys("DCAP%d" % n, vt, n, "phys", "Decoupling capacitor, %d sites (cross-coupled tie, ESD safe)" % n,
                        decap_nb(vt, max(1, n - 2)), {"is_decap_cell": True}))
    out.append(phys("WELLTAP", vt, 2, "phys", "Well/substrate tap (N-well->VDD, P-sub->VSS), place <= 25 um apart", attrs={"is_tap_cell": True}))
    c = phys("WELLTAPDH", vt, 2, "phys", "Double-row well tap (for rows next to multi-row cells)", attrs={"is_tap_cell": True}); c.rows = 2; out.append(c)
    out.append(phys("ENDCAPLEFT", vt, 2, "phys", "Row boundary cell, left row end (diffusion/implant termination)", attrs={"is_filler_cell": True}))
    out.append(phys("ENDCAPRIGHT", vt, 2, "phys", "Row boundary cell, right row end", attrs={"is_filler_cell": True}))
    for w in (1, 2, 4):
        out.append(phys("ENDCAPTOP%d" % w, vt, w, "phys", "Top-row boundary cell, %d site(s): fin/gate end termination above the core" % w, attrs={"is_filler_cell": True}))
        out.append(phys("ENDCAPBOTTOM%d" % w, vt, w, "phys", "Bottom-row boundary cell, %d site(s)" % w, attrs={"is_filler_cell": True}))
    for k, d in (("TL", "top-left"), ("TR", "top-right"), ("BL", "bottom-left"), ("BR", "bottom-right")):
        out.append(phys("ENDCAP" + k, vt, 2, "phys", "Core corner boundary cell (%s)" % d, attrs={"is_filler_cell": True}))
    nb = NB(vt); nb.extra.append("DA0 VSS A dio_n AREA=0.0012p"); nb.extra.append("DA1 A VDD dio_p AREA=0.0012p")
    c = phys("ANTENNA", vt, 2, "phys", "Antenna protection diode pair", nb,
             {"antenna_diode_type": "power_and_ground"}, pins=[Pin("A", "input", "data", cap=0.12)])
    c.physical_only = False; c.vkind = "antenna"; out.append(c)
    return out

GA_UNIT = 4   # gate-array base tile = 4 sites

def build_ga(vt):
    out = []
    for n in (1, 2, 4, 8, 16):
        nb = NB(vt)
        for i in range(n * (GA_UNIT - 1)):   # uncommitted, tied-off transistor pair on every device column of every tile
            nb.fet("n", "VSS", "VSS", "VSS", 1, FINS_PER_DEV, kind="ga"); nb.fet("p", "VDD", "VDD", "VDD", 1, FINS_PER_DEV, kind="ga")
        out.append(phys("GFILL%d" % n, vt, GA_UNIT * n, "ga", "Gate-array ECO base filler, %d tile(s) of %d sites" % (n, GA_UNIT), nb,
                        {"is_filler_cell": True}))
    for n in (1, 2, 4):
        c = phys("GDCAP%d" % n, vt, GA_UNIT * n, "ga", "Gate-array ECO decap, %d tile(s)" % n, decap_nb(vt, GA_UNIT * n - 2),
                 {"is_decap_cell": True}); out.append(c)
    # functional GA cells: same footprint grid, metal-only ECO programmable on GFILL
    ga_src = {c.base: c for c in build_comb(vt) + build_seq(vt) if c.drive == "X1"}
    for gname, src in (("GINV", "INV"), ("GBUF", "BUF"), ("GNAND2", "NAND2"), ("GNOR2", "NOR2"), ("GAND2", "AND2"),
                       ("GOR2", "OR2"), ("GXOR2", "XOR2"), ("GXNOR2", "XNOR2"), ("GMUX2", "MUX2"), ("GAOI21", "AOI21"),
                       ("GOAI21", "OAI21"), ("GAOI22", "AOI22"), ("GOAI22", "OAI22"), ("GNAND3", "NAND3"), ("GNOR3", "NOR3"),
                       ("GHADD", "HADD"), ("GFADD", "FADD"), ("GDFF", "DFF"), ("GDFFR", "DFFR"), ("GSDFF", "SDFF"),
                       ("GLATCH", "LATCH"), ("GTIEHI", "TIEHI"), ("GTIELO", "TIELO"), ("GDLY", "DLY2")):
        s = ga_src[src]
        c = Cell("%s_X1_%s" % (gname, vt), gname, vt, "X1", "ga", "Gate-array ECO " + s.desc, [Pin(p.name, p.dir, p.role, p.width) for p in s.pins],
                 dict(s.funcs), s.nb, arcs=[Arc(**a.__dict__) for a in s.arcs], cons=[Con(**k.__dict__) for k in s.cons],
                 seq=s.seq, mpw=dict(s.mpw), vkind=s.vkind, attrs={"dont_use": True})
        finalize(c)
        # GA sizing: smallest whole number of 4-site tiles that provides (a) enough device columns
        # (GA_UNIT-1 per tile, tile-boundary gates are dummies) for max(N, P) fingers and (b) one M1
        # pin track per signal pin plus one spare (one M1 track per site).
        nn = sum(d.nf for d in c.nb.devs if d.t == "n"); npp = sum(d.nf for d in c.nb.devs if d.t == "p")
        npin = sum(p.width for p in c.pins if p.dir in ("input", "output"))
        tiles = max(int(math.ceil(max(nn, npp) / float(GA_UNIT - 1))), int(math.ceil((npin + 1) / float(GA_UNIT))), 1)
        c.sites = tiles * GA_UNIT
        c.sizing = dict(rule="ga", dev=int(math.ceil(max(nn, npp) / float(GA_UNIT - 1))) * GA_UNIT,
                        pin=int(math.ceil((npin + 1) / float(GA_UNIT))) * GA_UNIT, fixed=GA_UNIT, cols=max(nn, npp))
        c.desc += " [GA: %d tile(s): %d of %d device columns used, %d pins]" % (tiles, max(nn, npp), tiles * (GA_UNIT - 1), npin)
        for a in c.arcs: a.d0 *= 1.12                                     # metal-programmed routing penalty
        out.append(c)
    # gate-array base: every interior gate column carries one N and one P finger (fixed FEOL);
    # columns not used by the function are tied off (N gate->VSS, P gate->VDD) by MOL/M1 programming.
    # tile boundaries (every GA_UNIT sites) are dummy gates, so each tile has GA_UNIT-1 device columns
    for c in out:
        if c.base.startswith("GDCAP"): continue
        nn = sum(d.nf for d in c.nb.devs if d.t == "n"); npp = sum(d.nf for d in c.nb.devs if d.t == "p")
        while max(nn, npp) > c.sites - c.sites // GA_UNIT: c.sites += GA_UNIT
        ncol = c.sites - c.sites // GA_UNIT
        for _ in range(max(0, ncol - nn)): c.nb.fet("n", "VSS", "VSS", "VSS", 1, FINS_PER_DEV, kind="ga")
        for _ in range(max(0, ncol - npp)): c.nb.fet("p", "VDD", "VDD", "VDD", 1, FINS_PER_DEV, kind="ga")
    return out

# ------------------------------------------------------------------ PMK
def build_pmk(vt):
    out = []
    PG_HDR = [("VDD", "primary_power", "VDD"), ("VVDD", "internal_power", "VVDD"), ("VSS", "primary_ground", "VSS")]
    PG_FTR = [("VDD", "primary_power", "VDD"), ("VSS", "primary_ground", "VSS"), ("VVSS", "internal_ground", "VVSS")]
    R_P1_SW, R_N1_SW = 5.1 * 0.55, 4.6 * 0.55   # kOhm per 3-fin finger in deep-linear region
    def add(c, ms=None):
        finalize(c, ms); c.lib = "pmk"; out.append(c); return c
    # ---- header / footer power switches -------------------------------------------
    # simple (single switch) : single-row X1 X2 X4, multi-row (MR) X4 X8 X16
    # mother-daughter (2S)   : weak trickle switch + strong main switch, X1 X2 X4 X8 (2-row)
    SIMPLE = [("", 1, 1), ("", 2, 1), ("", 4, 1), ("MR", 4, 2), ("MR", 8, 2), ("MR", 16, 4)]
    for sfx, d, rows in SIMPLE:
        nsw = 6 * d
        for hf in ("HDR", "FTR"):
            nb = NB(vt)
            if hf == "HDR":
                nb.fet("p", "VVDD", "SLEEP", "VDD", nsw, 3, b="VDD", kind="psw")
                nb.inv("sl1", "SLEEP", 1, 2); nb.inv("SLEEPOUT", "sl1", 1, 3)
                ron = R_P1_SW / nsw; pg = PG_HDR
            else:
                nb.inv("slb", "SLEEP", 1, 2)
                nb.fet("n", "VVSS", "slb", "VSS", nsw, 3, b="VSS", kind="psw")
                nb.inv("SLEEPOUT", "slb", 1, 3)
                ron = R_N1_SW / nsw; pg = PG_FTR
            c = mk(hf + "SW" + sfx, vt, dname(d), "pmk_psw",
                   "%s power switch, simple type (%s, %d fingers, Ron=%.0f ohm @TT), daisy-chain SLEEPOUT, %d-row" % (
                       "Header" if hf == "HDR" else "Footer", "PMOS" if hf == "HDR" else "NMOS", nsw, ron * 1000, rows),
                   [Pin("SLEEP", "input", "sleep"), Pin("SLEEPOUT", "output", "data")], {"SLEEPOUT": "SLEEP"}, nb, pg=pg,
                   rows=rows, vkind="hdr" if hf == "HDR" else "ftr", seq=dict(kind="switch", sw="SLEEP", ron=round(ron, 5)))
            c.arcs.append(Arc("SLEEP", "SLEEPOUT", "combinational", "positive_unate", 4.0 + 0.15 * d))
            c.attrs["switch_cell_type"] = "coarse_grain"; add(c, ms=nsw // rows + 2)
    for d in (1, 2, 4, 8):          # mother-daughter
        nweak, nstrong = max(1, d), 8 * d
        for hf in ("HDR", "FTR"):
            nb = NB(vt)
            if hf == "HDR":
                nb.fet("p", "VVDD", "SLEEPIN1", "VDD", nweak, 2, b="VDD", kind="psw")
                nb.fet("p", "VVDD", "SLEEPIN2", "VDD", nstrong, 3, b="VDD", kind="psw")
                nb.inv("a1", "SLEEPIN1", 1, 2); nb.inv("SLEEPOUT1", "a1", 1, 3)
                nb.inv("a2", "SLEEPIN2", 1, 2); nb.inv("SLEEPOUT2", "a2", 1, 3)
                ron = R_P1_SW / (nstrong + nweak * 2 / 3.0); pg = PG_HDR
            else:
                nb.inv("a1", "SLEEPIN1", 1, 2); nb.inv("a2", "SLEEPIN2", 1, 2)
                nb.fet("n", "VVSS", "a1", "VSS", nweak, 2, b="VSS", kind="psw")
                nb.fet("n", "VVSS", "a2", "VSS", nstrong, 3, b="VSS", kind="psw")
                nb.inv("SLEEPOUT1", "a1", 1, 3); nb.inv("SLEEPOUT2", "a2", 1, 3)
                ron = R_N1_SW / (nstrong + nweak * 2 / 3.0); pg = PG_FTR
            c = mk(hf + "SW2S", vt, dname(d), "pmk_psw",
                   "%s power switch, mother-daughter type (trickle %d + main %d fingers, Ron=%.0f ohm @TT), in-rush control, 2-row" % (
                       "Header" if hf == "HDR" else "Footer", nweak, nstrong, ron * 1000),
                   [Pin("SLEEPIN1", "input", "sleep"), Pin("SLEEPIN2", "input", "sleep"), Pin("SLEEPOUT1", "output"), Pin("SLEEPOUT2", "output")],
                   {"SLEEPOUT1": "SLEEPIN1", "SLEEPOUT2": "SLEEPIN2"}, nb, pg=pg, rows=2, vkind="hdr2" if hf == "HDR" else "ftr2",
                   seq=dict(kind="switch", sw="SLEEPIN1&SLEEPIN2", ron=round(ron, 5)))
            c.arcs += [Arc("SLEEPIN1", "SLEEPOUT1", "combinational", "positive_unate", 4.0),
                       Arc("SLEEPIN2", "SLEEPOUT2", "combinational", "positive_unate", 4.0 + 0.15 * d)]
            c.attrs["switch_cell_type"] = "coarse_grain"; add(c, ms=(nstrong + nweak) // 2 + 2)
    # ---- isolation: buffered (logic + built-in output buffer) and UB (unbuffered) ---
    ISO_PINS = lambda en: [Pin("A", "input"), Pin(en, "input", "iso"), Pin("Y", "output")]
    for d in (1, 2, 4, 8):
        nfin, nf = nfin_nf(d)
        for base, en, f, desc in (("ISOLO", "ISO", "A&!ISO", "clamp-0 (Y=A&!ISO)"), ("ISOHI", "ISO", "A|ISO", "clamp-1 (Y=A|ISO)"),
                                  ("ISOLON", "ISON", "A&ISON", "clamp-0, active-low enable (Y=A&ISON)")):
            nb = NB(vt)
            if base == "ISOLO": nb.inv("isb", "ISO", 1, 2); nb.nand("n0", ["A", "isb"], 1, 3)
            elif base == "ISOHI": nb.nor("n0", ["A", "ISO"], 1, 3)
            else: nb.nand("n0", ["A", "ISON"], 1, 3)
            nb.inv("Y", "n0", nf, nfin)
            c = mk(base, vt, dname(d), "pmk_iso", "Isolation %s, buffered (logic stage + built-in output buffer)" % desc,
                   ISO_PINS(en), {"Y": f}, nb); c.attrs["is_isolation_cell"] = True; comb_arcs(add(c))
            if d <= 4:   # unbuffered: logic stage drives Y directly
                nb = NB(vt); nb.inv("ab", "A", 1, 2)
                if base == "ISOLO": nb.nor("Y", ["ab", "ISO"], nf, nfin)
                elif base == "ISOHI": nb.inv("isb", "ISO", 1, 2); nb.nand("Y", ["ab", "isb"], nf, nfin)
                else: nb.inv("isb", "ISON", 1, 2); nb.nor("Y", ["ab", "isb"], nf, nfin)
                c = mk(base + "UB", vt, dname(d), "pmk_iso", "Isolation %s, unbuffered (logic stage drives output)" % desc,
                       ISO_PINS(en), {"Y": f}, nb); c.attrs["is_isolation_cell"] = True; comb_arcs(add(c))
        if d <= 4:
            nb = NB(vt); nb.inv("isb", "ISO", 1, 2); nb.inv("isi", "isb", 1, 2)
            nb.tg("A", "l1", "isb", "isi"); nb.inv("l2", "l1", 1, 2); nb.cinv("l1", "l2", "isi", "isb"); nb.inv("Y", "l2", nf, nfin)
            c = mk("ISOLAT", vt, dname(d), "pmk_iso", "Latch-based isolation (holds last value while ISO=1), buffered",
                   ISO_PINS("ISO"), {"Y": "IQ"}, nb, vkind="isolat", seq=dict(kind="latch", enable="!ISO", data_in="A"))
            c.attrs["is_isolation_cell"] = True; add(c)
            c.arcs += [Arc("A", "Y", "combinational", "positive_unate", 8.0), Arc("ISO", "Y", "falling_edge", "non_unate", 10.0)]
            c.cons += [Con("A", "ISO", "setup_rising", 6.0), Con("A", "ISO", "hold_rising", 3.0)]
    # ---- level shifters, plain and combined LVL+ISO, buffered and UB -----------------
    PG_LH = [("VDDL", "primary_power", "VDDL"), ("VDD", "primary_power", "VDD"), ("VSS", "primary_ground", "VSS")]
    PG_HL = [("VDDL", "primary_power", "VDDL"), ("VSS", "primary_ground", "VSS")]
    for d in (1, 2, 4):
        nfin, nf = nfin_nf(d)
        for kind in ("", "ISOLO", "ISOHI"):
            for ub in (False, True):
                # LH: input inverter on VDDL, DCVS core on VDD (x = !A, xb = A when enabled)
                nb = NB(vt); dcf = (2 * nf if ub else 2)
                nb.inv("ab", "A", 1, 2, sup="VDDL")
                if kind:
                    nb.inv("isb", "ISO", 1, 2)
                if kind == "ISOLO":
                    nb.fet("n", "x", "A", "nx", dcf, 3); nb.fet("n", "nx", "isb", "VSS", dcf, 3)
                    nb.fet("n", "xb", "ab", "VSS", dcf, 3); nb.fet("n", "xb", "ISO", "VSS", max(1, dcf // 2), 2)
                elif kind == "ISOHI":
                    nb.fet("n", "x", "A", "VSS", dcf, 3); nb.fet("n", "x", "ISO", "VSS", max(1, dcf // 2), 2)
                    nb.fet("n", "xb", "ab", "nx", dcf, 3); nb.fet("n", "nx", "isb", "VSS", dcf, 3)
                else:
                    nb.fet("n", "x", "A", "VSS", dcf, 3); nb.fet("n", "xb", "ab", "VSS", dcf, 3)
                nb.fet("p", "x", "xb", "VDD", 1, 2)
                nb.fet("p", "xb", "x", "VDD", 1 if not ub else max(1, nf // 2), 2)
                if ub:
                    # output taken straight from the DCVS node xb (= A)
                    nb.stages["xb"] = type(nb.stages.get("ab"))("xb", ["A"], 4.6 * 1.6 / dcf, 5.1 * 2.2 / max(1, nf // 2), 0.25 * dcf, "VDD")
                    for dv in nb.devs:
                        if dv.d == "xb": dv.d = "Y"
                        if dv.s == "xb": dv.s = "Y"
                        if dv.g == "xb": dv.g = "Y"
                    nb.stages["Y"] = nb.stages.pop("xb"); nb.stages["Y"].out = "Y"
                else:
                    nb.inv("Y", "x", nf, nfin)
                f = {"": "A", "ISOLO": "A&!ISO", "ISOHI": "A|ISO"}[kind]
                pins = [Pin("A", "input", "ls_data", pwr="VDDL")] + ([Pin("ISO", "input", "iso")] if kind else []) + [Pin("Y", "output")]
                c = mk("LVLLH" + kind + ("UB" if ub else ""), vt, dname(d), "pmk_lvl",
                       "Low-to-high level shifter (VDDL->VDD), DCVS, double-row, %s" % ("unbuffered (DCVS node drives Y)" if ub else "buffered output") +
                       (", combined isolation clamp-%s" % ("0" if kind == "ISOLO" else "1") if kind else ""),
                       pins, {"Y": f}, nb, pg=PG_LH, rows=2, vkind="comb")
                c.attrs["is_level_shifter"] = True; c.attrs["level_shifter_type"] = "LH"
                if kind: c.attrs["is_isolation_cell"] = True
                add(c)
                c.arcs.append(Arc("A", "Y", "combinational", "positive_unate", 16.0 if ub else 22.0))
                if kind: c.arcs.append(Arc("ISO", "Y", "combinational", "negative_unate" if kind == "ISOLO" else "positive_unate", 10.0 if ub else 14.0))
                # HL: single rail on VDDL
                if ub and not kind: continue       # plain HL is inherently a 2-stage buffer
                nb = NB(vt, vdd="VDDL")
                if not ub:
                    if kind == "ISOLO": nb.inv("isb", "ISO", 1, 2); nb.nand("n0", ["A", "isb"], 1, 3)
                    elif kind == "ISOHI": nb.nor("n0", ["A", "ISO"], 1, 3)
                    else: nb.inv("n0", "A", 1, 3)
                    nb.inv("Y", "n0", nf, nfin)
                else:
                    nb.inv("ab", "A", 1, 2)
                    if kind == "ISOLO": nb.nor("Y", ["ab", "ISO"], nf, nfin)
                    else: nb.inv("isb", "ISO", 1, 2); nb.nand("Y", ["ab", "isb"], nf, nfin)
                pins = [Pin("A", "input", "ls_data", pwr="VDDL")] + ([Pin("ISO", "input", "iso", pwr="VDDL")] if kind else []) + [Pin("Y", "output", pwr="VDDL")]
                c = mk("LVLHL" + kind + ("UB" if ub else ""), vt, dname(d), "pmk_lvl",
                       "High-to-low level shifter (VDD->VDDL), single rail, %s" % ("unbuffered" if ub else "buffered output") +
                       (", combined isolation clamp-%s" % ("0" if kind == "ISOLO" else "1") if kind else ""),
                       pins, {"Y": f}, nb, pg=PG_HL, vkind="comb")
                c.attrs["is_level_shifter"] = True; c.attrs["level_shifter_type"] = "HL"
                if kind: c.attrs["is_isolation_cell"] = True
                comb_arcs(add(c))
    # retention flops (live-slave on VDDR backup supply, NRET single-pin control)
    PG_RET = [("VDD", "primary_power", "VDD"), ("VDDR", "backup_power", "VDDR"), ("VSS", "primary_ground", "VSS")]
    for base, rn, scan in (("RETDFF", 0, 0), ("RETDFFR", 1, 0), ("RETSDFF", 0, 1), ("RETSDFFR", 1, 1)):
        for d in (1, 2):
            nfin, nf = nfin_nf(d)
            nb = NB(vt)
            pins = ipins(["D"])
            if scan: pins += [Pin("SI", "input", "scan_in"), Pin("SE", "input", "scan_enable")]
            pins += [Pin("CK", "input", "clock")]
            if rn: pins.append(Pin("RN", "input", "reset", pwr="VDDR"))
            pins += [Pin("NRET", "input", "retain", pwr="VDDR"), Pin("Q", "output")]
            din = "D"
            if scan: scan_mux(nb, "D", "SI", "SE", "ds"); din = "ds"
            nb.nand("ckg", ["CK", "NRET"], 1, 2, sup="VDDR")    # clock gated in retention (VDDR)
            nb.inv("cki", "ckg", 1, 2, sup="VDDR"); nb.inv("ckb", "cki", 1, 2, sup="VDDR")
            ff_core(nb, din, "cki", "ckb", "Q", None, "RN" if rn else None, None, nf, nfin, slave_sup="VDDR")
            seqd = dict(kind="ff", clocked_on="CK&NRET", next_state="D", retention=True)
            if rn: seqd["clear"] = "!RN"
            if scan: seqd["scan_ns"] = "(D&!SE)|(SI&SE)"
            c = mk(base, vt, dname(d), "pmk_ret", "Retention flop (live slave on VDDR, NRET=0 retains)" + (", async reset" if rn else "") + (", scan" if scan else ""),
                   pins, {"Q": "IQ"}, nb, seq=seqd, pg=PG_RET, vkind="ret", rows=1)
            c.attrs["retention_cell"] = base
            add(c)
            c.arcs.append(Arc("CK", "Q", "rising_edge", "non_unate", 18.0))
            if rn: c.arcs.append(Arc("RN", "Q", "clear", "positive_unate", 12.0, rise=False))
            c.cons += [Con("D", "CK", "setup_rising", 10.0 + (6 if scan else 0), "!SE" if scan else ""), Con("D", "CK", "hold_rising", 3.0, "!SE" if scan else ""),
                       Con("NRET", "CK", "setup_rising", 15.0), Con("NRET", "CK", "hold_rising", 5.0)]
            if scan: c.cons += [Con("SI", "CK", "setup_rising", 15.0, "SE"), Con("SI", "CK", "hold_rising", 3.5, "SE"),
                                Con("SE", "CK", "setup_rising", 18.0), Con("SE", "CK", "hold_rising", 4.0)]
            if rn: c.cons += [Con("RN", "CK", "recovery_rising", 8.0), Con("RN", "CK", "removal_rising", 4.0)]; c.mpw["RN"] = (None, 19.0)
            c.mpw["CK"] = (23.0, 23.0)
    # always-on cells on VDDB
    PG_AON = [("VDD", "primary_power", "VDD"), ("VDDB", "backup_power", "VDDB"), ("VSS", "primary_ground", "VSS")]
    for base, desc, f, mkfn in (("AONBUF", "Always-on buffer (VDDB)", "A", "buf"), ("AONINV", "Always-on inverter (VDDB)", "!A", "inv"),
                                ("AONCKBUF", "Always-on clock buffer (VDDB)", "A", "buf")):
        for d in (1, 2, 4, 8):
            nfin, nf, pre = output_stage_nf(d)
            nb = NB(vt, vdd="VDDB")
            if mkfn == "buf": nb.inv("n0", "A", pre, 3); nb.inv("Y", "n0", nf, nfin)
            else: nb.inv("Y", "A", nf, nfin)
            c = mk(base, vt, dname(d), "pmk_aon", desc, [Pin("A", "input", pwr="VDDB"), Pin("Y", "output", pwr="VDDB")], {"Y": f}, nb, pg=PG_AON)
            c.attrs["always_on"] = True
            if base == "AONCKBUF": c.attrs["is_clock_cell"] = True
            comb_arcs(add(c))
    for d in (1,):
        c = delay_cell("AONDLY", vt, 6, "pmk_aon", "Always-on delay cell (VDDB)")
        c.nb.vdd = "VDDB"
        for dv in c.nb.devs:
            if dv.s == "VDD": dv.s = "VDDB"
            if dv.b == "VDD": dv.b = "VDDB"
        for p in c.pins: p.pwr = "VDDB"
        c.pg = PG_AON; c.attrs["always_on"] = True; c.lib = "pmk"; out.append(c)
    for d in (1, 2):
        nfin, nf = nfin_nf(d)
        nb = NB(vt, vdd="VDDB"); nb.inv("eb", "E", 1, 2); nb.gate("emx", ("p", [("s", ["D", "E"]), ("s", ["Q", "eb"])]), 1, 2)
        nb.inv("de", "emx", 1, 2); cki, ckb = _clk(nb, "CK"); ff_core(nb, "de", cki, ckb, "Q", None, "RN", None, nf, nfin)
        c = mk("AONDFFR", vt, dname(d), "pmk_aon", "Always-on DFF with enable & async reset (VDDB)",
               [Pin("D", "input", pwr="VDDB"), Pin("E", "input", "enable", pwr="VDDB"), Pin("CK", "input", "clock", pwr="VDDB"), Pin("RN", "input", "reset", pwr="VDDB"), Pin("Q", "output", pwr="VDDB")],
               {"Q": "IQ"}, nb, pg=PG_AON, vkind="ff", seq=dict(kind="ff", clocked_on="CK", next_state="(D&E)|(IQ&!E)", clear="!RN"))
        c.attrs["always_on"] = True; add(c)
        c.arcs += [Arc("CK", "Q", "rising_edge", "non_unate", 17.0), Arc("RN", "Q", "clear", "positive_unate", 11.0, rise=False)]
        c.cons += [Con("D", "CK", "setup_rising", 14.0), Con("D", "CK", "hold_rising", 3.0), Con("E", "CK", "setup_rising", 14.0),
                   Con("E", "CK", "hold_rising", 3.0), Con("RN", "CK", "recovery_rising", 7.0), Con("RN", "CK", "removal_rising", 4.0)]
        c.mpw = {"CK": (22.0, 22.0), "RN": (None, 18.0)}
    # fix supply mapping for AON netlists built by helpers that assumed VDD
    for c in out:
        if c.family == "pmk_aon":
            for dv in c.nb.devs:
                if dv.s == "VDD": dv.s = "VDDB"
                if dv.d == "VDD": dv.d = "VDDB"
                if dv.b == "VDD": dv.b = "VDDB"
            for p in c.pins: p.pwr = "VDDB"
    return out


# ------------------------------------------------------------------ DFT cells
import re as _re
def rename_cell(c, base, pmap, desc=None):
    """rename pins of a built cell everywhere (netlist, funcs, seq, arcs, cons)"""
    def rn(x):
        if x is None: return x
        return _re.sub(r"\b(%s)\b" % "|".join(map(_re.escape, pmap)), lambda m: pmap[m.group(1)], x) if pmap else x
    for p in c.pins: p.name = pmap.get(p.name, p.name)
    for d in c.nb.devs: d.d, d.g, d.s, d.b = pmap.get(d.d, d.d), pmap.get(d.g, d.g), pmap.get(d.s, d.s), pmap.get(d.b, d.b)
    st = {}
    for k, v in c.nb.stages.items():
        if v is not None: v.out = pmap.get(v.out, v.out); v.ins = [pmap.get(i, i) for i in v.ins]
        st[pmap.get(k, k)] = v
    c.nb.stages = st
    c.funcs = {pmap.get(k, k): rn(v) for k, v in c.funcs.items()}
    if c.seq: c.seq = {k: (rn(v) if isinstance(v, str) else v) for k, v in c.seq.items()}
    for a in c.arcs: a.frm, a.to, a.when = pmap.get(a.frm, a.frm), pmap.get(a.to, a.to), rn(a.when)
    for k in c.cons: k.pin, k.rel, k.when = pmap.get(k.pin, k.pin), pmap.get(k.rel, k.rel), rn(k.when)
    c.mpw = {pmap.get(k, k): v for k, v in c.mpw.items()}
    c.base = base; c.name = "%s_%s_%s" % (base, c.drive, c.vt)
    if desc: c.desc = desc
    c.family = "dft"
    return c

def _two_stage_bsc(vt, d, base, names, desc):
    """shift/capture flop + update flop + mode mux (IEEE 1149.1 BC_1 / IEEE 1500 WBR style)"""
    PI, SI, SH, CAP, UPD, CK, MODE, PO, SO = names
    nfin, nf = nfin_nf(d)
    nb = NB(vt)
    pins = [Pin(PI, "input"), Pin(SI, "input", "scan_in"), Pin(SH, "input", "scan_enable")]
    if CAP: pins.append(Pin(CAP, "input", "enable"))
    pins += [Pin(CK, "input", "clock"), Pin(UPD, "input", "clock2"), Pin(MODE, "input", "test"), Pin(PO, "output"), Pin(SO, "output")]
    # capture/hold mux then shift mux
    cin = PI
    if CAP:
        nb.inv("capb", CAP, 1, 2); nb.gate("cmx", ("p", [("s", [PI, CAP]), ("s", [SO, "capb"])]), 1, 2); nb.inv("cd", "cmx", 1, 2); cin = "cd"
    scan_mux(nb, cin, SI, SH, "ds")
    nb.inv("ckb", CK, 1, 2); nb.inv("cki", "ckb", 1, 2)
    ff_core(nb, "ds", "cki", "ckb", SO, None, None, None, 1, 3, pfx="sc_")
    nb.inv("uckb", UPD, 1, 2); nb.inv("ucki", "uckb", 1, 2)
    ff_core(nb, SO, "ucki", "uckb", "uq", None, None, None, 1, 2, pfx="up_")
    nb.inv("mb", MODE, 1, 2)
    nb.gate("omx", ("p", [("s", ["uq", MODE]), ("s", [PI, "mb"])]), 1, 3); nb.inv(PO, "omx", nf, nfin)
    ns1 = ("(%s&%s)|(%s&%s&!%s)|(IQ1&!%s&!%s)" % (SI, SH, PI, CAP, SH, CAP, SH)) if CAP else ("(%s&%s)|(%s&!%s)" % (SI, SH, PI, SH))
    seq = dict(kind="ffs", groups=[("IQ1", "IQN1", CK, ns1), ("IQ2", "IQN2", UPD, "IQ1")])
    funcs = {PO: "(IQ2&%s)|(%s&!%s)" % (MODE, PI, MODE), SO: "IQ1"}
    c = mk(base, vt, dname(d), "dft", desc, pins, funcs, nb, seq=seq, vkind="bsc")
    finalize(c)
    c.vextra = dict(names=names)
    c.arcs += [Arc(PI, PO, "combinational", "positive_unate", 8.0), Arc(MODE, PO, "combinational", "non_unate", 8.0),
               Arc(CK, SO, "rising_edge", "non_unate", 16.0), Arc(UPD, PO, "rising_edge", "non_unate", 24.0)]
    for p in [PI, SI, SH] + ([CAP] if CAP else []):
        c.cons += [Con(p, CK, "setup_rising", 15.0), Con(p, CK, "hold_rising", 3.5)]
    c.mpw = {CK: (24.0, 24.0), UPD: (22.0, 22.0)}
    return c

def build_dft(vt):
    out = []
    for d in (1, 2, 4):
        out.append(rename_cell(latch_cell("LATCHN", vt, d), "LOCKUP", {"EN": "CK"},
                               "Scan lock-up latch, low-transparent (place after posedge chain segment)"))
        out.append(rename_cell(latch_cell("LATCH", vt, d), "LOCKUPP", {"E": "CK"},
                               "Scan lock-up latch, high-transparent (negedge domain crossing)"))
    for d in (1, 2):
        out.append(rename_cell(seq_cell("SDFF", vt, d), "TPOBS", {"D": "A", "Q": "SO"},
                               "Observe test point: dedicated scan flop capturing A (SO on scan chain)"))
        for kind in (0, 1):
            nfin, nf = nfin_nf(d)
            nb = NB(vt)
            scan_mux(nb, "SO", "SI", "SE", "ds")
            nb.inv("ckb", "CK", 1, 2); nb.inv("cki", "ckb", 1, 2)
            ff_core(nb, "ds", "cki", "ckb", "SO", None, None, None, 1, 2)
            nb.nand("tq", ["TE", "SO"], 1, 2)
            if kind == 0:
                nb.nand("yb", ["A", "tq"], 1, 3); nb.inv("Y", "yb", nf, nfin); f = "A&!(TE&IQ)"
            else:
                nb.inv("ab", "A", 1, 2); nb.nand("Y", ["ab", "tq"], nf, nfin); f = "A|(TE&IQ)"
            pins = [Pin("A", "input"), Pin("TE", "input", "test"), Pin("SI", "input", "scan_in"), Pin("SE", "input", "scan_enable"),
                    Pin("CK", "input", "clock"), Pin("Y", "output"), Pin("SO", "output")]
            c = mk("TPCTL%d" % kind, vt, dname(d), "dft",
                   "Control test point, force-%d when TE=1 and its scan flop holds 1 (flop holds in capture, loads SI in shift)" % kind,
                   pins, {"Y": f, "SO": "IQ"}, nb, seq=dict(kind="ff", clocked_on="CK", next_state="IQ", scan_ns="(SI&SE)|(IQ&!SE)"), vkind="tpctl")
            finalize(c)
            c.arcs += [Arc("A", "Y", "combinational", "positive_unate", 4.0),
                       Arc("TE", "Y", "combinational", "negative_unate" if kind == 0 else "positive_unate", 4.0),
                       Arc("CK", "Y", "rising_edge", "non_unate", 20.0), Arc("CK", "SO", "rising_edge", "non_unate", 16.0)]
            c.cons += [Con("SI", "CK", "setup_rising", 14.0), Con("SI", "CK", "hold_rising", 3.5),
                       Con("SE", "CK", "setup_rising", 17.0), Con("SE", "CK", "hold_rising", 4.0)]
            c.mpw = {"CK": (22.0, 22.0)}
            out.append(c)
        out.append(_two_stage_bsc(vt, d, "WBRCELL", ("CFI", "WSI", "SHIFTWR", "CAPTUREWR", "UPDATEWR", "WRCK", "WMODE", "CFO", "WSO"),
                                  "IEEE 1500 wrapper boundary cell (WBC): shift/capture flop on WRCK + update flop on UPDATEWR + mode mux"))
        out.append(_two_stage_bsc(vt, d, "BSCELL", ("PI", "TDI", "SHIFTDR", None, "UPDATEDR", "CLOCKDR", "MODE", "PO", "TDO"),
                                  "IEEE 1149.1 boundary-scan cell BC_1: capture/shift on CLOCKDR, update on UPDATEDR, MODE selects update stage"))
    return out

# ------------------------------------------------------------------ top
def build_std(vt):
    cells = build_comb(vt) + build_clock(vt) + build_seq(vt) + build_mbit(vt) + build_dft(vt) + build_ga(vt) + build_phys(vt)
    return cells

_cache = {}
def catalog(vt):
    if vt not in _cache:
        _cache[vt] = (build_std(vt), build_pmk(vt))
    return _cache[vt]

if __name__ == "__main__":
    from collections import Counter
    tot = 0
    for vt in VT_FLAVORS:
        s, p = catalog(vt)
        tot += len(s) + len(p)
        print(vt, "std", len(s), "pmk", len(p))
    s, p = catalog("SVT")
    print(Counter(c.family for c in s + p))
    print("total", tot)
    for n in ("INV_X1_SVT", "NAND2_X1_SVT", "FADD_X1_SVT", "SDFFRS_X1_SVT", "MBSDFFR32_X1_SVT", "ICGPREOBS_X1_SVT", "AOI222_X1_SVT"):
        c = next(c for c in s + p if c.name == n)
        print(n, c.sites, c.rows, c.area, [(pp.name, pp.cap) for pp in c.pins][:6], [(a.frm, a.to, a.sense, a.d0) for a in c.arcs][:4])
