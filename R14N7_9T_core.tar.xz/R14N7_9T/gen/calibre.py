"""Calibre SVRF rule decks generated from tech.RULES / tech.LAYERS:
DRC (FEOL/MOL/BEOL/pad/grid), metal density + fill, antenna, ERC, LVS (FinFET device
recognition with NFIN/L/NF properties, multi-Vt, SRAM, thick-ox IO, ESD diodes)."""
from tech import RULES, LAYERS, METALS, VIAS, PIN_DT, TEXT_DT, FILL_DT, BANNER, VT_FLAVORS

UM = lambda nm: "%.4f" % (nm / 1000.0)

def layer_defs():
    o = ["// ---------------- layer definitions (GDS layer;datatype -> SVRF) ----------------"]
    for n, ((l, d), desc) in LAYERS.items():
        o.append("LAYER MAP %-3d DATATYPE %d %d   LAYER %-9s %d   // %s" % (l, d, 1000 + l, n, 1000 + l, desc))
        if n in [m[0] for m in METALS] + ["AP"]:
            o.append("LAYER MAP %-3d DATATYPE %d %d   // %s pin purpose merged into drawing" % (l, PIN_DT, 1000 + l, n))
            o.append("LAYER MAP %-3d DATATYPE %d %d   LAYER %s_FILL %d" % (l, FILL_DT, 3000 + l, n, 3000 + l))
            o.append("LAYER MAP %-3d TEXTTYPE %d %d   LAYER %s_TXT %d" % (l, TEXT_DT, 2000 + l, n, 2000 + l))
            if n in ("M2", "M3"):
                o.append("LAYER MAP %-3d DATATYPE 21 %d   LAYER %s_C1 %d   // mask 1 colour" % (l, 4000 + l, n, 4000 + l))
                o.append("LAYER MAP %-3d DATATYPE 22 %d   LAYER %s_C2 %d   // mask 2 colour" % (l, 5000 + l, n, 5000 + l))
    o += ["",
          "// ---------------- derived layers ----------------",
          "VTANY   = (VT_HVT OR VT_LVT) OR VT_ULVT",
          "NACT    = ACTIVE AND NSELECT", "PACT    = ACTIVE AND PSELECT",
          "NSD     = NACT NOT GATE", "PSD     = PACT NOT GATE",
          "NGATE   = GATE AND NACT", "PGATE   = GATE AND PACT",
          "LGATE   = (GATE NOT THICKOX) NOT SRAMMK",
          "PSUB    = EXTENT NOT NWELL",
          "NTAP    = NACT AND NWELL", "PTAP    = PACT NOT NWELL",
          "NSDX    = NSD NOT NWELL", "PSDX    = PSD AND NWELL",
          "GATEPOLY = GATE NOT GCUT",
          "FINAUX  = FIN AND ACTIVE",
          "M1ALL   = M1 OR M1_FILL", "M2ALL = M2 OR M2_FILL", "M3ALL = M3 OR M3_FILL", "M4ALL = M4 OR M4_FILL",
          "M5ALL   = M5 OR M5_FILL", "M6ALL = M6 OR M6_FILL", "M7ALL = M7 OR M7_FILL", "M8ALL = M8 OR M8_FILL", "M9ALL = M9 OR M9_FILL", ""]
    return o

def header(kind, results):
    return ["// " + BANNER, "// R14N7 Calibre %s deck (SVRF). Generated from r14n7/gen/tech.py rule table." % kind,
            "// Set env: R14_GDS (layout file), R14_TOP (top cell)%s" % (", R14_CDL (source netlist)" if kind == "LVS" else ""),
            "", 'LAYOUT PATH "$R14_GDS"', 'LAYOUT PRIMARY "$R14_TOP"', "LAYOUT SYSTEM GDSII",
            "PRECISION 10000", "RESOLUTION 10", "FLAG OFFGRID YES", "FLAG ACUTE YES", "FLAG SKEW YES", "FLAG NONSIMPLE YES",
            'DRC RESULTS DATABASE "%s.results" ASCII' % results, 'DRC SUMMARY REPORT "%s.summary" HIER' % results,
            "DRC MAXIMUM RESULTS ALL", "DRC MAXIMUM VERTEX 4096", "DRC CHECK TEXT ALL", "DRC KEEP EMPTY NO", ""]

def lay(n, logic=True):
    if n == "VT_*": return "VTANY"
    if n == "GATE" and logic: return "LGATE"
    if n in ("NACT", "PACT"): return n
    return n

def drc_deck():
    o = header("DRC", "r14n7_drc") + layer_defs()
    o.append("// ================= rule checks =================")
    for r in RULES:
        if r.kind in ("density_min", "density_max", "antenna"): continue
        a = lay(r.layer); b = lay(r.other) if r.other else None
        body = []
        if r.kind == "width":
            if r.other == "THICKOX": body = ["INT (GATE AND THICKOX) < %s ABUT < 90 SINGULAR REGION" % UM(r.value)]
            else: body = ["INT %s < %s ABUT < 90 SINGULAR REGION" % (a, UM(r.value))]
        elif r.kind == "exact_width":
            body = ["X = RECTANGLE %s == %s BY >= %s ORTHOGONAL ONLY" % (a, UM(r.value), UM(r.value)),
                    "Y = RECTANGLE %s >= %s BY == %s ORTHOGONAL ONLY" % (a, UM(r.value), UM(r.value)),
                    "%s NOT (X OR Y)" % a]
        elif r.kind == "space":
            body = ["EXT %s %s < %s ABUT < 90 SINGULAR REGION" % (a, b, UM(r.value))] if b else \
                   ["EXT %s < %s ABUT < 90 SINGULAR REGION" % (a, UM(r.value))]
        elif r.kind == "pitch":
            w = {"FIN": 7, "GATE": 20}[r.layer]
            body = ["EXT %s > %s < %s OPPOSITE PARALLEL ONLY REGION   // off-pitch neighbours" % (a, UM(r.value - w), UM(2 * r.value - w))]
        elif r.kind == "enclosure":
            body = (["ENC %s %s < %s ABUT < 90 SINGULAR REGION" % (b, a, UM(r.value))] if r.value > 0 else []) + ["%s NOT %s" % (b, a)]
        elif r.kind == "extension":
            body = ["ENC ACTIVE GATE < %s ABUT < 90 OPPOSITE REGION   // gate end-cap beyond active" % UM(r.value)]
        elif r.kind == "overlap_forbid":
            if r.layer == "VT_*":
                body = ["(VT_HVT AND VT_LVT) OR ((VT_HVT AND VT_ULVT) OR (VT_LVT AND VT_ULVT))"]
            else:
                body = ["%s AND %s" % (a, b)]
        elif r.kind == "area":
            body = ["AREA %s < %s" % (a, "%.6f" % (r.value * 1e-6))]
        elif r.kind == "eol":
            w = next(m[3] for m in METALS if m[0] == r.layer)
            body = ["EOL = CONVEX EDGE %s ANGLE1 == 90 ANGLE2 == 90 WITH LENGTH <= %s" % (a, UM(w + 2)),
                    "EXT EOL %s < %s OPPOSITE REGION" % (a, UM(r.value))]
        elif r.kind == "samemask":
            body = ["// coloured layout: mask 1 = datatype 21, mask 2 = datatype 22 (uncoloured: run DFM decomposition first)",
                    "EXT %s_C1 < %s ABUT < 90 SINGULAR REGION" % (r.layer, UM(r.value)),
                    "EXT %s_C2 < %s ABUT < 90 SINGULAR REGION" % (r.layer, UM(r.value))]
        elif r.kind == "fin_keep":
            body = ["// informational: fin outside ACTIVE is removed by the fin-cut mask (no check)"]
        elif r.kind == "grid":
            body = ["OFFGRID %s 10 10" % n for n in LAYERS if n not in ("PRBNDRY",)][:1]
            o.append("%s { @ %s" % (r.rid, r.desc))
            for n in LAYERS:
                if n == "PRBNDRY": continue
                o.append("  OFFGRID %s 10 10" % n)
            o.append("}"); continue
        o.append("%s { @ %s" % (r.rid, r.desc))
        o += ["  " + x for x in body]
        o.append("}")
    # SRAM / IO specific extra rules
    o += ["", "// ---- SRAM marker: bitcell region uses relaxed (pushed) rules ----",
          "SRAM.GATE.1 { @ SRAM gate length must equal 20 nm", "  INT (GATE AND SRAMMK) < 0.0200 ABUT < 90 SINGULAR REGION", "}",
          "SRAM.ACT.1 { @ SRAM active min width 40 nm", "  INT (ACTIVE AND SRAMMK) < 0.0400 ABUT < 90 SINGULAR REGION", "}",
          "ROM.PGM.1 { @ ROMPGM marker must contain exactly the V0 code shapes", "  (V0 AND SRAMMK) NOT ROMPGM", "}",
          "LVL.MK.1 { @ Level-shifter cells must carry LVLMK and two NWELL islands", "  LVLMK NOT ENCLOSE NWELL == 2", "}",
          "PSW.MK.1 { @ Power-switch marker must cover the switch active", "  PSWMK NOT INTERACT ACTIVE", "}",
          "IO.TOX.1 { @ No thin-ox gate inside ESD marker", "  (GATE AND ESDMK) NOT THICKOX", "}"]
    return "\n".join(o) + "\n"

def density_deck():
    o = header("DENSITY / FILL", "r14n7_density") + layer_defs()
    for (m, d, p, w, s, t, off) in METALS:
        lo = next(r.value for r in RULES if r.rid == "%s.DEN.1" % m); hi = next(r.value for r in RULES if r.rid == "%s.DEN.2" % m)
        o += ["%s.DEN.1 { @ %s density < %d%% in 50x50 um window, step 25 um" % (m, m, lo * 100),
              "  DENSITY %sALL < %.2f WINDOW 50 STEP 25 BACKUP PRINT \"%s_density.log\" RDB \"%s_density.rdb\"" % (m, lo, m, m), "}",
              "%s.DEN.2 { @ %s density > %d%% in 50x50 um window, step 25 um" % (m, m, hi * 100),
              "  DENSITY %sALL > %.2f WINDOW 50 STEP 25 BACKUP" % (m, hi), "}"]
    o += ["", "// ---------------- dummy metal fill generation (run with -drc on a copy) ----------------",
          'DRC RESULTS DATABASE "r14n7_fill.gds" GDSII APPEND _FILL', ""]
    for (m, d, p, w, s, t, off) in METALS:
        num = 1000 + LAYERS[m][0][0] - 1000
        o += ["%s_FILL_GEN { @ generate %s dummy fill on track grid" % (m, m),
              "  AVOID = SIZE %s BY %s" % (m, UM(3 * s)),
              "  FILLAREA = (EXTENT NOT AVOID) NOT PRBNDRY_KEEPOUT" if False else "  FILLAREA = EXTENT NOT AVOID",
              "  RECTANGLES %s %s %s %s INSIDE OF LAYER FILLAREA" % (UM(w * 4) if d == "HORIZONTAL" else UM(w),
                                                                   UM(w) if d == "HORIZONTAL" else UM(w * 4), UM(p * 3), UM(p)), "}",
              "DRC CHECK MAP %s_FILL_GEN GDSII %d %d" % (m, LAYERS[m][0][0], FILL_DT)]
    return "\n".join(o) + "\n"

def antenna_deck():
    o = header("ANTENNA", "r14n7_antenna") + layer_defs() + connects(False)
    o += ["DIODE = (NSD OR PSD) AND DIODEMK", ""]
    prev = []
    for (m, d, p, w, s, t, off) in METALS:
        o += ["%s.ANT.1 { @ cumulative %s/gate area ratio > 1000 without protection diode" % (m, m),
              "  NET AREA RATIO GATE %s > 1000 ACCUMULATE [ AREA(%s) / AREA(GATE) ] RDB \"%s_ant.rdb\" GATE %s" % (m, m, m, m), "}",
              "%s.ANT.2 { @ cumulative %s/gate area ratio > 50000 with diode" % (m, m),
              "  NET AREA RATIO GATE %s DIODE > 50000 ACCUMULATE [ AREA(%s) / AREA(GATE) ] RDB \"%s_antd.rdb\" GATE %s" % (m, m, m, m), "}"]
    return "\n".join(o) + "\n"

def connects(with_text=True):
    o = ["// ---------------- connectivity ----------------",
         "CONNECT NSD PSD NTAP PTAP BY LISD" if False else "CONNECT LISD NSD PSD NTAP PTAP",
         "CONNECT GATEPOLY LIG", "CONNECT LISD M1 BY V0", "CONNECT LIG M1 BY V0",
         "CONNECT NWELL NTAP", "CONNECT PSUB PTAP"]
    for i in range(len(METALS) - 1):
        o.append("CONNECT %s %s BY %s" % (METALS[i][0], METALS[i + 1][0], VIAS[i + 1][0]))
    o.append("CONNECT M9 AP BY V9")
    if with_text:
        for m in [x[0] for x in METALS] + ["AP"]:
            o += ["TEXT LAYER %s_TXT" % m, "ATTACH %s_TXT %s" % (m, m)]
    return o + [""]

def lvs_deck():
    o = header("LVS", "r14n7_lvs")
    o = [x for x in o if not x.startswith("DRC ")]
    o += ['SOURCE PATH "$R14_CDL"', 'SOURCE PRIMARY "$R14_TOP"', "SOURCE SYSTEM SPICE",
          'LVS REPORT "r14n7_lvs.report"', "LVS REPORT OPTION S V", 'MASK SVDB DIRECTORY "svdb" QUERY XRC', "",
          'LVS POWER NAME "VDD" "VDDL" "VDDB" "VDDR" "VDDM" "VVDD" "IOVDD" "?VDD?"',
          'LVS GROUND NAME "VSS" "VVSS" "IOVSS" "?VSS?"',
          "LVS REDUCE PARALLEL MOS YES", "LVS REDUCE SERIES MOS NO", "LVS REDUCE SPLIT GATES YES",
          "LVS REDUCE PARALLEL DIODE YES", "LVS RECOGNIZE GATES ALL", "LVS FILTER UNUSED OPTION AB RC RG",
          "LVS CHECK PORT NAMES YES", "LVS ABORT ON SUPPLY ERROR YES", "LVS COMPARE CASE NO",
          "LVS ISOLATE SHORTS YES BY CELL", "LVS SPICE SCALE X PARAMETERS NO", 'LVS SPICE OPTION F',
          "LVS EXECUTE ERC YES", "VIRTUAL CONNECT COLON NO", "VIRTUAL CONNECT REPORT YES", ""]
    o += layer_defs() + connects(True)
    o.append("// ---------------- device recognition ----------------")
    vts = [("HVT", "AND VT_HVT"), ("SVT", "NOT VTANY"), ("LVT", "AND VT_LVT"), ("ULVT", "AND VT_ULVT")]
    for t, sd, bulk, g in (("n", "NSD", "PSUB", "NGATE"), ("p", "PSD", "NWELL", "PGATE")):
        for vt, expr in vts:
            model = VT_FLAVORS[vt][t + "model"]
            lname = "%sG_%s" % (t.upper(), vt)
            o += ["%s = ((%s %s) NOT THICKOX) NOT SRAMMK" % (lname, g, expr),
                  "DEVICE M%s(%s) %s GATEPOLY(G) %s(S) %s(D) %s(B) FINAUX" % ("N" if t == "n" else "P", model, lname, sd, sd, bulk),
                  "[", "  PROPERTY L, NFIN, NF",
                  "  L    = PERIMETER_COINCIDE(%s, %s) > 0 ? AREA(%s) / (PERIMETER_COINCIDE(%s, %s) / 2) : 0" % (lname, sd, lname, lname, sd),
                  "  NFIN = COUNT(FINAUX)", "  NF   = 1", "]"]
        for nm, expr in (("SRAM", "AND SRAMMK"), ("IO", "AND THICKOX")):
            model = "%smos_%s" % (t, nm.lower())
            lname = "%sG_%s" % (t.upper(), nm)
            o += ["%s = %s %s" % (lname, g, expr),
                  "DEVICE M%s(%s) %s GATEPOLY(G) %s(S) %s(D) %s(B) FINAUX" % ("N" if t == "n" else "P", model, lname, sd, sd, bulk),
                  "[", "  PROPERTY L, %s, NF" % ("W" if nm == "IO" else "NFIN"),
                  "  L = AREA(%s) / (PERIMETER_COINCIDE(%s, %s) / 2)" % (lname, lname, sd),
                  ("  W = PERIMETER_COINCIDE(%s, %s) / 2" % (lname, sd)) if nm == "IO" else "  NFIN = COUNT(FINAUX)", "  NF = 1", "]"]
    o += ["DNDIO = (NSD AND DIODEMK) NOT ESDMK", "DPDIO = (PSD AND DIODEMK) NOT ESDMK",
          "DNESD = (NSD AND DIODEMK) AND ESDMK", "DPESD = (PSD AND DIODEMK) AND ESDMK",
          "DEVICE D(dio_n) DNDIO PSUB(POS) DNDIO(NEG) [ PROPERTY A  A = AREA(DNDIO) ]",
          "DEVICE D(dio_p) DPDIO DPDIO(POS) NWELL(NEG) [ PROPERTY A  A = AREA(DPDIO) ]",
          "DEVICE D(dio_esd_n) DNESD PSUB(POS) DNESD(NEG) [ PROPERTY A  A = AREA(DNESD) ]",
          "DEVICE D(dio_esd_p) DPESD DPESD(POS) NWELL(NEG) [ PROPERTY A  A = AREA(DPESD) ]",
          "RESB = M1 AND RESMK", "DEVICE R(rm1) RESB M1(POS) M1(NEG) [ PROPERTY R  R = 12.8 * LENGTH(RESB) / WIDTH(RESB) ]", ""]
    o.append("// ---------------- property tracing ----------------")
    for vt in VT_FLAVORS.values():
        for m in (vt["nmodel"], vt["pmodel"]):
            o += ["TRACE PROPERTY M(%s) NFIN NFIN 0" % m, "TRACE PROPERTY M(%s) L L 1" % m]
    o += ["TRACE PROPERTY M(nmos_io) W W 2", "TRACE PROPERTY M(pmos_io) W W 2", "TRACE PROPERTY D(dio_esd_n) A A 5", ""]
    o += ["// hierarchical boxes: memory macros are compared as LVS BOX unless R14_MEM_FLAT is set",
          "#IFNDEF $R14_MEM_FLAT", 'LVS BOX "R14SRAM_SP_*" "R14RF_2P_*" "R14ROM_*"', "#ENDIF", ""]
    return "\n".join(o) + "\n"

def erc_deck():
    o = header("ERC", "r14n7_erc") + ["ERC RESULTS DATABASE \"r14n7_erc.results\"", "ERC SUMMARY REPORT \"r14n7_erc.summary\"",
                                       "ERC MAXIMUM RESULTS ALL", 'LVS POWER NAME "VDD" "VDDL" "VDDB" "VDDR" "VDDM" "VVDD" "IOVDD"',
                                       'LVS GROUND NAME "VSS" "VVSS" "IOVSS"', ""] + layer_defs() + connects(True)
    o += ["ERC.PATH.1 { @ Node has a path to ground but none to any power supply",
          "  PATHCHK GROUND && !POWER", "}",
          "ERC.PATH.2 { @ Node has a path to power but none to any ground",
          "  PATHCHK POWER && !GROUND", "}",
          "ERC.PATH.3 { @ Node with no path to power or ground (floating)",
          "  PATHCHK !POWER && !GROUND && !LABELED", "}",
          "ERC.FLOAT.1 { @ N-well island without an N-tap",
          "  NWELL NOT INTERACT NTAP", "}",
          "ERC.FLOAT.2 { @ Device gate not connected to any gate contact (floating gate)",
          "  (NGATE OR PGATE) NOT INTERACT (GATEPOLY INTERACT LIG)", "}",
          "ERC.WELL.1 { @ N-well tied to a ground net",
          "  NET NWELL \"VSS\" \"VVSS\" \"IOVSS\"", "}",
          "ERC.SUB.1 { @ P-substrate tie connected to a power net",
          "  NET PTAP \"VDD\" \"VDDL\" \"VDDB\" \"VDDR\" \"VVDD\" \"IOVDD\"", "}",
          "ERC.OX.1 { @ Thin-oxide gate connected directly to IOVDD (1.8 V) net",
          "  NET (LGATE AND (NGATE OR PGATE)) \"IOVDD\"", "}",
          "ERC.PSW.1 { @ Switched rail (VVDD/VVSS) shorted to a permanent rail",
          "  NET AREA RATIO M1 \"VVDD\" \"VDD\" > 0" if False else "  NET M1 \"VVDD\" \"VVSS\" INTERACT (NET M1 \"VDD\" \"VSS\")", "}",
          "ERC.GATE.1 { @ Gate tied directly to supply outside TIE/decap cells (use TIEHI/TIELO)",
          "  NET GATEPOLY \"VDD\" \"VSS\" NOT INTERACT (GAMK OR PSWMK)", "}"]
    return "\n".join(o) + "\n"
