"""R14N7 1.8 V general-purpose IO library (in-line, 40 um pitch, 120 um height).
Signal pads, core/IO supply pads, ESD rail clamps, power-on-control, pad fillers,
breaker, corner, bond pads.  Views: Verilog, Liberty (all corners, NLDM+LVF/CCS/ECSM),
LEF, GDS, SPICE/CDL (thick-oxide drivers/receivers, ESD diodes, RC-triggered BigFET)."""
import math
import gdstk
import charmodel as cm
import liberty as lb
from tech import CORNERS, BANNER, L, PIN_DT, TEXT_DT

IO_H = 120000; PITCH = 40000; CORNER = 120000
PG_IO = [("VDD", "primary_power", "VDD"), ("VSS", "primary_ground", "VSS"),
         ("IOVDD", "primary_power", "IOVDD"), ("IOVSS", "primary_ground", "IOVSS")]

class IOCell:
    def __init__(s, name, kind, desc, pins, width, cls, funcs=None, arcs=None, cons=None, ffs=None, nfunc=1, bs=False):
        s.name, s.kind, s.desc, s.pins, s.w, s.cls = name, kind, desc, pins, width, cls
        s.funcs = funcs or {}; s.arcs = arcs or []; s.cons = cons or []; s.ffs = ffs or []
        s.nfunc, s.bs = nfunc, bs
        s.h = CORNER if kind == "corner" else (IO_H if kind != "bondpad" else 64000)
        if kind == "bondpad": s.w = 64000
    @property
    def area(s): return s.w * s.h * 1e-6

def cells():
    C = []
    bid = [("PAD", "inout", "pad"), ("I", "input", "data"), ("OEN", "input", "data"), ("IE", "input", "data"),
           ("PU", "input", "data"), ("PD", "input", "data"), ("DS0", "input", "data"), ("DS1", "input", "data"),
           ("ST", "input", "data"), ("C", "output", "data")]
    C.append(IOCell("PBIDIR18", "bidir", "1.8V GPIO bidirectional: 4 drive strengths (DS1:DS0 = 2/4/8/12 mA), PU/PD 50k, Schmitt (ST), input enable (IE), active-low OE",
                    bid, PITCH, "PAD INOUT", {"PAD": "I", "C": "PAD&IE"},
                    [("I", "PAD", "combinational", "positive_unate", 420), ("OEN", "PAD", "three_state_enable", "negative_unate", 450),
                     ("OEN", "PAD", "three_state_disable", "positive_unate", 380), ("PAD", "C", "combinational", "positive_unate", 260),
                     ("IE", "C", "combinational", "positive_unate", 160)]))
    C.append(IOCell("PIN18", "in", "1.8V input-only pad with Schmitt option, PU/PD, IE",
                    [("PAD", "input", "pad"), ("IE", "input", "data"), ("PU", "input", "data"), ("PD", "input", "data"),
                     ("ST", "input", "data"), ("C", "output", "data")], PITCH, "PAD INPUT", {"C": "PAD&IE"},
                    [("PAD", "C", "combinational", "positive_unate", 250), ("IE", "C", "combinational", "positive_unate", 150)]))
    C.append(IOCell("POUT18", "out", "1.8V output-only pad, 4 drive strengths",
                    [("PAD", "output", "pad"), ("I", "input", "data"), ("OEN", "input", "data"), ("DS0", "input", "data"), ("DS1", "input", "data")],
                    PITCH, "PAD OUTPUT", {"PAD": "I"},
                    [("I", "PAD", "combinational", "positive_unate", 400), ("OEN", "PAD", "three_state_enable", "negative_unate", 440),
                     ("OEN", "PAD", "three_state_disable", "positive_unate", 370)]))
    C.append(IOCell("PANA18", "ana", "Analog pass-through pad, 50 ohm secondary ESD resistor, dual-diode",
                    [("PAD", "inout", "pad"), ("ANA", "inout", "data")], PITCH, "PAD INOUT"))
    for nm, d in (("PADVDD", "Core supply (VDD) pad, with local VDD-VSS rail clamp"),
                  ("PADVSS", "Core ground (VSS) pad"),
                  ("PADIOVDD", "IO supply (IOVDD, 1.8V) pad, with local IOVDD-IOVSS rail clamp"),
                  ("PADIOVSS", "IO ground (IOVSS) pad")):
        C.append(IOCell(nm, "power", d, [], PITCH, "PAD POWER"))
    C += bs_cells()
    C.append(IOCell("PCLAMPVDD", "clamp", "Stand-alone RC-triggered ESD rail clamp VDD-VSS (BigFET)", [], PITCH, "PAD POWER"))
    C.append(IOCell("PCLAMPIOVDD", "clamp", "Stand-alone RC-triggered ESD rail clamp IOVDD-IOVSS (thick-ox BigFET)", [], PITCH, "PAD POWER"))
    C.append(IOCell("PPOC", "poc", "Power-on-control: holds IO drivers tri-stated until core VDD valid",
                    [("POC", "output", "data")], PITCH, "PAD SPACER", {"POC": "0"}))
    for w in (1, 2, 5, 10, 20):
        C.append(IOCell("PFILL%d" % w, "fill", "Pad-ring filler %d um (continues all rings)" % w, [], w * 1000, "PAD SPACER"))
    C.append(IOCell("PBRK", "brk", "Ring breaker: cuts IOVDD/IOVSS (and VDD) rings, keeps ESD bus VSS continuous via anti-parallel diodes", [], 10000, "PAD SPACER"))
    C.append(IOCell("PCORNER", "corner", "Pad-ring corner (continues all rings)", [], CORNER, "ENDCAP TOPLEFT"))
    C.append(IOCell("BONDPAD60", "bondpad", "In-line wire-bond pad 60x60 um (AP + passivation opening 56x56)", [], 64000, "COVER BUMP"))
    C.append(IOCell("BONDPAD60STG", "bondpad", "Staggered-row wire-bond pad 60x60 um", [], 64000, "COVER BUMP"))
    return C

BS_PINS = [("BSI", "input", "bs"), ("SHIFTDR", "input", "bs"), ("CLOCKDR", "input", "bsclk"), ("UPDATEDR", "input", "bsclk"),
           ("MODE", "input", "bs"), ("BSO", "output", "bs")]

def _mux_expr(sig, n):
    if n == 1: return sig + "0"
    sel = lambda k: "%sSEL1&%sSEL0" % ("" if k & 2 else "!", "" if k & 1 else "!")
    return "|".join("(%s%d&%s)" % (sig, k, sel(k)) for k in range(4))

def bs_cells():
    """GPIO with N-way pin-mux and integrated IEEE 1149.1 boundary-scan register cells.
    BSR chain order: BSI -> input-capture (BC_4) -> output-enable control (BC_1) -> output data (BC_1) -> BSO"""
    out = []
    for name, n, kind in (("PGPIO18MUX4BS", 4, "bidir"), ("PBIDIR18BS", 1, "bidir"), ("PIN18BS", 1, "in")):
        pins = [("PAD", "inout" if kind == "bidir" else "input", "pad")]
        if kind == "bidir":
            pins += [("I%d" % k, "input", "data") for k in range(n)] + [("OEN%d" % k, "input", "data") for k in range(n)]
            if n > 1: pins += [("SEL0", "input", "data"), ("SEL1", "input", "data")]
            pins += [("DS0", "input", "data"), ("DS1", "input", "data")]
        pins += [("IE", "input", "data"), ("PU", "input", "data"), ("PD", "input", "data"), ("ST", "input", "data"), ("C", "output", "data")]
        pins += BS_PINS
        funcs = {"C": "PAD&IE", "BSO": "BS_OUT" if kind == "bidir" else "BS_IN"}
        ffs = [("BS_IN", "BS_IN_N", "CLOCKDR", "(BSI&SHIFTDR)|(PAD&!SHIFTDR)")]
        arcs = [("PAD", "C", "combinational", "positive_unate", 250), ("IE", "C", "combinational", "positive_unate", 150),
                ("CLOCKDR", "BSO", "rising_edge", "non_unate", 120)]
        if kind == "bidir":
            im, om = _mux_expr("I", n), _mux_expr("OEN", n)
            ffs += [("BS_OE", "BS_OE_N", "CLOCKDR", "(BS_IN&SHIFTDR)|((%s)&!SHIFTDR)" % om),
                    ("BS_OUT", "BS_OUT_N", "CLOCKDR", "(BS_OE&SHIFTDR)|((%s)&!SHIFTDR)" % im),
                    ("UP_OE", "UP_OE_N", "UPDATEDR", "BS_OE"), ("UP_OUT", "UP_OUT_N", "UPDATEDR", "BS_OUT")]
            funcs["PAD"] = "(UP_OUT&MODE)|((%s)&!MODE)" % im
            funcs["PAD_3S"] = "(UP_OE&MODE)|((%s)&!MODE)" % om
            arcs += [("I%d" % k, "PAD", "combinational", "positive_unate", 430) for k in range(n)]
            arcs += [("OEN%d" % k, "PAD", "three_state_enable", "negative_unate", 460) for k in range(n)]
            arcs += [("OEN%d" % k, "PAD", "three_state_disable", "positive_unate", 390) for k in range(n)]
            if n > 1: arcs += [("SEL%d" % k, "PAD", "combinational", "non_unate", 440) for k in range(2)]
            arcs += [("MODE", "PAD", "combinational", "non_unate", 440), ("UPDATEDR", "PAD", "rising_edge", "non_unate", 470)]
        cons = [(p, "CLOCKDR", "setup_rising", 60.0) for p in ("BSI", "SHIFTDR")] + [(p, "CLOCKDR", "hold_rising", 20.0) for p in ("BSI", "SHIFTDR")]
        d = ("1.8V GPIO, %s, with integrated IEEE 1149.1 boundary-scan cells (%s); BSI->BSO chain, EXTEST via MODE" % (
            ("4-way pin-mux (SEL1:SEL0 selects I/OEN function 0-3)" if n > 1 else "single function"),
            "BC_4 input + BC_1 control + BC_1 output" if kind == "bidir" else "BC_4 observe-only input"))
        out.append(IOCell(name, kind, d, pins, PITCH, "PAD INOUT" if kind == "bidir" else "PAD INPUT", funcs, arcs, cons, ffs, n, True))
    return out

def bsdl(cs):
    """BSDL boundary-register fragments for each BS-capable IO cell (to paste into a chip BSDL)"""
    o = ["-- " + BANNER, "-- R14N7 IO18 boundary-scan cell descriptions (IEEE 1149.1-2013 BSDL fragments)",
         "-- Per-pad BSR cells in chain order BSI -> BSO. Replace <n> by the cell number and <port> by the chip port.", ""]
    for c in cs:
        if not c.bs: continue
        o.append("-- %s : %s" % (c.name, c.desc))
        if c.kind == "bidir":
            o += ['  "<n>   (BC_4, <port>, input,   X),                         " &',
                  '  "<n+1> (BC_1, *,      control, 1),                         " &',
                  '  "<n+2> (BC_1, <port>, output3, X, <n+1>, 1, Z),           " &   -- OEN active-low: control=1 disables', ""]
        else:
            o += ['  "<n>   (BC_4, <port>, input,   X),                         " &', ""]
    return "\n".join(o) + "\n"

# ----------------------------------------------------------------- Verilog
def verilog(cs):
    o = ["// " + BANNER, "`timescale 1ps/1fs"]
    for c in cs:
        pn = [p[0] for p in c.pins]
        o.append("`celldefine")
        o.append("module %s (%s\n`ifdef R14_PG_PINS\n  %sVDD, VSS, IOVDD, IOVSS\n`endif\n);" % (c.name, ", ".join(pn), ", " if pn else ""))
        for n, d, r in c.pins: o.append("  %s %s;" % (d, n))
        o += ["`ifdef R14_PG_PINS", "  inout VDD, VSS, IOVDD, IOVSS;", "`endif"]
        if c.kind == "bidir":
            o += ["  bufif0 (PAD, I, OEN);", "  assign (pull1, pull0) PAD = (PU & ~PD) ? 1'b1 : ((PD & ~PU) ? 1'b0 : 1'bz);",
                  "  assign C = IE ? PAD : 1'b0;"]
        elif c.kind == "in":
            o += ["  assign C = IE ? PAD : 1'b0;"]
        elif c.kind == "out":
            o += ["  bufif0 (PAD, I, OEN);"]
        elif c.kind == "ana":
            o += ["  tran (PAD, ANA);"]
        elif c.kind == "poc":
            o += ["  assign POC = 1'b0;"]
        if c.bs:
            n = c.nfunc
            o.append("  reg BS_IN, BS_OE, BS_OUT, UP_OE, UP_OUT;")
            if c.kind == "bidir":
                if n > 1:
                    o += ["  wire [1:0] sel = {SEL1, SEL0};", "  wire im = sel == 2'd0 ? I0 : sel == 2'd1 ? I1 : sel == 2'd2 ? I2 : I3;",
                          "  wire om = sel == 2'd0 ? OEN0 : sel == 2'd1 ? OEN1 : sel == 2'd2 ? OEN2 : OEN3;"]
                else:
                    o += ["  wire im = I0;", "  wire om = OEN0;"]
                o += ["  wire pi = MODE ? UP_OUT : im;", "  wire po = MODE ? UP_OE : om;",
                      "  bufif0 (PAD, pi, po);", "  assign (pull1, pull0) PAD = (PU & ~PD) ? 1'b1 : ((PD & ~PU) ? 1'b0 : 1'bz);",
                      "  always @(posedge CLOCKDR) begin BS_IN <= SHIFTDR ? BSI : PAD; BS_OE <= SHIFTDR ? BS_IN : om; BS_OUT <= SHIFTDR ? BS_OE : im; end",
                      "  always @(posedge UPDATEDR) begin UP_OE <= BS_OE; UP_OUT <= BS_OUT; end",
                      "  assign BSO = BS_OUT;"]
            else:
                o += ["  always @(posedge CLOCKDR) BS_IN <= SHIFTDR ? BSI : PAD;", "  assign BSO = BS_IN;"]
            o += ["  assign C = IE ? PAD : 1'b0;"]
        if c.arcs and c.kind in ("bidir", "in", "out") and not c.bs:
            o.append("  specify")
            for (a, b, t, s, d) in c.arcs:
                o.append("    (%s => %s) = (0, 0);" % (a, b))
            o.append("  endspecify")
        o += ["endmodule", "`endcelldefine", ""]
    return "\n".join(o)

# ----------------------------------------------------------------- Liberty
PAD_LOADS = [500.0, 1000.0, 2500.0, 5000.0, 10000.0, 20000.0, 50000.0]   # fF
PAD_SLEWS = [20.0, 50.0, 100.0, 250.0, 500.0, 1000.0, 2000.0]

def write_lib(path, cs, corner, model):
    cn = corner.name; V = corner.vddio
    sm = 0.5 * (cm.rscale(cn, "HVT", "p", None) + cm.rscale(cn, "HVT", "n", None))
    Lx = []
    lb.lib_header("r14n7_io18_%s_%s" % (cn, model), corner, [("VDD", corner.vdd), ("VSS", 0.0), ("IOVDD", corner.vddio), ("IOVSS", 0.0)], Lx)
    Lx += ["  lu_table_template (pad_delay_7x7) {", "    variable_1 : input_net_transition;", "    variable_2 : total_output_net_capacitance;",
           '    index_1 ("%s");' % lb.row(PAD_SLEWS), '    index_2 ("%s");' % lb.row(PAD_LOADS), "  }"]
    sg = cm.sigma_rel(cn, "HVT", 60, 4.0)
    for c in cs:
        Lx += ["  cell (%s) {" % c.name, "    area : %.2f;" % c.area, "    pad_cell : true;" if c.kind not in ("fill", "corner", "bondpad", "brk") else "    dont_touch : true;",
               "    dont_use : true;", "    cell_leakage_power : %s;" % lb.F(1e5 * cm.leak_fin(cn, "HVT", "n") / 0.066 * (3 if c.kind in ("clamp", "power") else 1))]
        if c.kind in ("power",):
            Lx.append("    is_pad : true;" if False else "    pad_type : clock;" if False else "")
        for n, t, v in PG_IO: Lx.append("    pg_pin (%s) { voltage_name : %s; pg_type : %s; }" % (n, v, t))
        for (iq, iqn, ck, ns) in c.ffs:
            Lx.append('    ff (%s, %s) { clocked_on : "%s"; next_state : "%s"; }' % (iq, iqn, ck, ns))
        if c.kind == "bidir" or c.kind == "out": pass
        for n, d, r in c.pins:
            Lx += ["    pin (%s) {" % n, "      direction : %s;" % d]
            if r == "pad":
                Lx += ["      is_pad : true;", "      related_power_pin : IOVDD;", "      related_ground_pin : IOVSS;",
                       "      input_voltage : io_cmos;" if False else "      capacitance : %s;" % lb.F(2500.0),
                       "      max_transition : 2000;"]
                if d in ("output", "inout"):
                    Lx += ["      max_capacitance : 50000;", "      drive_current : 12;"]
                    if "PAD" in c.funcs: Lx += ['      function : "%s";' % c.funcs["PAD"], '      three_state : "%s";' % c.funcs.get("PAD_3S", "OEN")]
                if c.kind in ("bidir", "in"): Lx.append("      hysteresis : true;")
            else:
                Lx += ["      related_power_pin : VDD;", "      related_ground_pin : VSS;"]
                if d == "input":
                    Lx += ["      capacitance : %s;" % lb.F(1.2 * cm.cap_scale(cn)), "      max_transition : 320;"]
                    if r == "bsclk": Lx.append("      clock : true;")
                    if n == "BSI": Lx.append("      signal_type : test_scan_in;")
                    for (cp, rel, kind, base) in c.cons:
                        if cp != n: continue
                        Lx += ["      timing () {", '        related_pin : "%s";' % rel, "        timing_type : %s;" % kind]
                        for rf in ("rise", "fall"):
                            lb.tbl(Lx, 8, "%s_constraint" % rf, "constraint_template_5x5", cm.CSLEWS, cm.CSLEWS, cm.constraint_table(cn, "HVT", base, kind, rf == "rise"))
                        Lx.append("      }")
                else:
                    Lx.append("      max_capacitance : 50;")
                    if n in c.funcs: Lx.append('      function : "%s";' % c.funcs[n])
            for (a, b, t, s, d0) in c.arcs:
                if b != n: continue
                padout = (b == "PAD")
                st = lb.St(); st.rn, st.rp, st.cpar, st.fins, st.nstages = (0.022, 0.025, 200.0, 60, 4.0) if padout else (1.2, 1.3, 0.8, 6, 3.0)
                st.loads = PAD_LOADS if padout else cm.loads_for(4)
                slews = cm.SLEWS if not (a == "PAD") else PAD_SLEWS
                T = cm.delay_tables(cn, "HVT", st, d0 * (0.7 / 1.0), 0.05)
                Lx += ["      timing () {", '        related_pin : "%s";' % a, "        timing_sense : %s;" % s, "        timing_type : %s;" % t]
                tm = "pad_delay_7x7" if padout else "delay_template_7x7"
                for dn, tn, rise in (("cell_rise", "rise_transition", True), ("cell_fall", "fall_transition", False)):
                    if t == "three_state_disable" and False: continue
                    lb.tbl(Lx, 8, dn, tm, slews, st.loads, T[dn]); lb.tbl(Lx, 8, tn, tm, slews, st.loads, T[tn])
                    if model in ("nldm", "ccs"):
                        lb.tbl(Lx, 8, "ocv_sigma_" + dn, tm, slews, st.loads, [[v * sg for v in rr] for rr in T[dn]], extra=['sigma_type : "early_and_late";'])
                    if model == "ccs" and t == "combinational":
                        Lx.append("        output_current_%s () {" % ("rise" if rise else "fall"))
                        for si in cm.CCS_SI:
                            for li in cm.CCS_LI:
                                vv = V if padout else corner.vdd
                                ref, ts, vals = cm.ccs_vector(slews[si], T[dn][si][li], T[tn][si][li], st.loads[li], vv, rise)
                                Lx += ["          vector (ccs_template) {", "            reference_time : %s;" % lb.F(ref),
                                       '            index_1 ("%s"); index_2 ("%s");' % (lb.F(slews[si]), lb.F(st.loads[li])),
                                       '            index_3 ("%s");' % lb.row(ts), '            values ("%s");' % lb.row(vals), "          }"]
                        Lx.append("        }")
                    if model == "ecsm" and t == "combinational":
                        Lx.append("        ecsm_waveform_set (ecsm_%s) {" % ("rise" if rise else "fall"))
                        for si in cm.CCS_SI:
                            for li in cm.CCS_LI:
                                Lx += ["          ecsm_waveform (ecsm_template) {", '            index_1 ("%s"); index_2 ("%s");' % (lb.F(slews[si]), lb.F(st.loads[li])),
                                       '            index_3 ("%s");' % lb.row(cm.ECSM_V),
                                       '            values ("%s");' % lb.row(cm.ecsm_times(slews[si], T[dn][si][li], T[tn][si][li])), "          }"]
                        Lx.append("        }")
                Lx.append("      }")
            Lx.append("    }")
        Lx.append("  }")
    Lx.append("}")
    open(path, "w").write("\n".join(x for x in Lx if x != "") + "\n")

# ----------------------------------------------------------------- physical
RINGS = [("VSS", 60000, 66000), ("VDD", 68000, 74000), ("IOVSS", 80000, 88000), ("IOVDD", 90000, 98000)]   # y bands (nm)

def R(cell, lay, x0, y0, x1, y1, dt=None):
    l, d = L(lay); cell.add(gdstk.rectangle((x0 / 1e3, y0 / 1e3), (x1 / 1e3, y1 / 1e3), layer=l, datatype=d if dt is None else dt))

def core_pins(c):
    out = []; n = [p for p in c.pins if p[2] != "pad"]
    k = max(2, int((c.w - 4000) // 54 // (len(n) + 1))) if n else 1
    for i, (nm, d, r) in enumerate(n):
        x = 27 + 54 * (37 + (i + 1) * k)     # on M3 tracks
        out.append((nm, x - 12, 0, x + 12, 1080, "M3"))
    return out

def build_gds(path, cs):
    lib = gdstk.Library("r14n7_io18", unit=1e-6, precision=1e-10)
    for c in cs:
        g = lib.new_cell(c.name)
        R(g, "PRBNDRY", 0, 0, c.w, c.h)
        if c.kind == "bondpad":
            R(g, "AP", 0, 0, 64000, 64000); R(g, "PASSIV", 4000, 4000, 60000, 60000)
            R(g, "M9", 2000, 2000, 62000, 62000)
            for i in range(6):
                for j in range(6):
                    x = 6000 + 9000 * i; y = 6000 + 9000 * j; R(g, "V9", x, y, x + 2000, y + 2000)
            R(g, "AP", 0, 0, 64000, 64000, dt=PIN_DT)
            g.add(gdstk.Label("PAD", (32.0, 32.0), layer=L("AP")[0], texttype=TEXT_DT)); continue
        if c.kind == "corner":
            for nm, y0, y1 in RINGS:
                R(g, "M8", 0, y0, CORNER - y0 + 0 if False else y1, y1); R(g, "M9", y0, 0, y1, y1)
                g.add(gdstk.Label(nm, (y0 / 1e3, y0 / 1e3), layer=L("M8")[0], texttype=TEXT_DT))
            continue
        for nm, y0, y1 in RINGS:
            if c.kind == "brk" and nm in ("IOVDD", "IOVSS", "VDD"): continue
            R(g, "M8", 0, y0, c.w, y1); R(g, "M8", 0, y0, c.w, y1, dt=PIN_DT)
            g.add(gdstk.Label(nm, (c.w / 2e3, (y0 + y1) / 2e3), layer=L("M8")[0], texttype=TEXT_DT))
        if c.kind in ("fill", "brk"):
            if c.kind == "brk":
                R(g, "DIODEMK", 2000, 60000, 8000, 66000); R(g, "ACTIVE", 2000, 60000, 8000, 66000)
            continue
        # device regions: ESD diodes (top, pad side), output drivers, pre-drivers/level shifters (bottom, core side)
        R(g, "THICKOX", 1000, 20000, c.w - 1000, 118000)
        R(g, "NWELL", 1000, 100000, c.w - 1000, 118000)
        R(g, "ESDMK", 1000, 100000, c.w - 1000, 118000); R(g, "DIODEMK", 2000, 101000, c.w - 2000, 109000); R(g, "DIODEMK", 2000, 110000, c.w - 2000, 117000)
        R(g, "ACTIVE", 2000, 101000, c.w - 2000, 109000); R(g, "ACTIVE", 2000, 110000, c.w - 2000, 117000)
        R(g, "ACTIVE", 2000, 22000, c.w - 2000, 56000)
        for k in range(int((c.w - 6000) // 2000)):
            x = 3000 + 2000 * k; R(g, "GATE", x, 21000, x + 150, 57000)
        R(g, "NWELL", 1000, 1500, c.w - 1000, 9000); R(g, "ACTIVE", 2000, 2000, c.w - 2000, 18000)
        if c.pins and any(p[2] == "pad" for p in c.pins) or c.kind in ("power",):
            R(g, "M9", 4000, 100000, c.w - 4000, IO_H); R(g, "M9", 4000, 100000, c.w - 4000, IO_H, dt=PIN_DT)
            g.add(gdstk.Label("PAD", (c.w / 2e3, 110.0), layer=L("M9")[0], texttype=TEXT_DT))
        for (nm, x0, y0, x1, y1, lay) in core_pins(c):
            R(g, lay, x0, y0, x1, y1); R(g, lay, x0, y0, x1, y1, dt=PIN_DT)
            g.add(gdstk.Label(nm, ((x0 + x1) / 2e3, (y0 + y1) / 2e3), layer=L(lay)[0], texttype=TEXT_DT))
    lib.write_gds(path)

def write_lef(path, cs):
    o = ["# " + BANNER, "VERSION 5.8 ;", 'BUSBITCHARS "[]" ;', 'DIVIDERCHAR "/" ;', ""]
    for c in cs:
        site = "cornerSite" if c.kind == "corner" else "ioSite"
        o += ["MACRO %s" % c.name, "  CLASS %s ;" % c.cls, "  ORIGIN 0 0 ;", "  FOREIGN %s 0 0 ;" % c.name,
              "  SIZE %.3f BY %.3f ;" % (c.w / 1e3, c.h / 1e3), "  SYMMETRY X Y R90 ;"]
        if c.kind != "bondpad": o.append("  SITE %s ;" % site)
        dirs = {p[0]: p[1] for p in c.pins}
        for (nm, x0, y0, x1, y1, lay) in core_pins(c):
            o += ["  PIN %s" % nm, "    DIRECTION %s ;" % dirs[nm].upper(), "    USE SIGNAL ;", "    PORT", "      LAYER %s ;" % lay,
                  "        RECT %.3f %.3f %.3f %.3f ;" % (x0 / 1e3, y0 / 1e3, x1 / 1e3, y1 / 1e3), "    END", "  END %s" % nm]
        if c.kind == "bondpad":
            o += ["  PIN PAD", "    DIRECTION INOUT ;", "    USE SIGNAL ;", "    PORT", "      LAYER AP ;", "        RECT 0 0 64.000 64.000 ;", "    END", "  END PAD"]
        elif any(p[2] == "pad" for p in c.pins) or c.kind == "power":
            nm = "PAD"
            o += ["  PIN %s" % nm, "    DIRECTION %s ;" % (dirs.get("PAD", "inout").upper()), "    USE %s ;" % ("SIGNAL" if c.kind != "power" else ("GROUND" if "SS" in c.name else "POWER")),
                  "    PORT", "      LAYER M9 ;", "        RECT 4.000 100.000 %.3f 120.000 ;" % ((c.w - 4000) / 1e3), "    END", "  END %s" % nm]
        if c.kind not in ("bondpad",):
            for nm, y0, y1 in RINGS:
                if c.kind == "brk" and nm in ("IOVDD", "IOVSS", "VDD"): continue
                o += ["  PIN %s" % nm, "    DIRECTION INOUT ;", "    USE %s ;" % ("GROUND" if "SS" in nm else "POWER"), "    SHAPE RING ;", "    PORT", "      LAYER M8 ;",
                      "        RECT 0 %.3f %.3f %.3f ;" % (y0 / 1e3, (c.w if c.kind != "corner" else y1) / 1e3, y1 / 1e3), "    END", "  END %s" % nm]
            o += ["  OBS", "    LAYER M1 ;", "      RECT 0 1.200 %.3f %.3f ;" % (c.w / 1e3, c.h / 1e3), "    LAYER M2 ;", "      RECT 0 1.200 %.3f %.3f ;" % (c.w / 1e3, c.h / 1e3),
                  "    LAYER M3 ;", "      RECT 0 1.200 %.3f %.3f ;" % (c.w / 1e3, c.h / 1e3), "    LAYER M4 ;", "      RECT 0 0 %.3f %.3f ;" % (c.w / 1e3, c.h / 1e3), "  END"]
        o += ["END %s" % c.name, ""]
    o.append("END LIBRARY")
    open(path, "w").write("\n".join(o) + "\n")

def spice(cs):
    o = ["* " + BANNER, "* R14N7 IO18 netlists (thick-oxide nmos_io/pmos_io, ESD diodes dio_esd_*)", ""]
    clamp = lambda vh, vl, sfx: [
        "R%s_T %s trg%s 100k" % (sfx, vh, sfx), "C%s_T trg%s %s 1p" % (sfx, sfx, vl),
        "MP%s_1 i1%s trg%s %s %s pmos_io L=150n W=4u NF=4" % (sfx, sfx, sfx, vh, vh), "MN%s_1 i1%s trg%s %s %s nmos_io L=150n W=2u NF=2" % (sfx, sfx, sfx, vl, vl),
        "MP%s_2 i2%s i1%s %s %s pmos_io L=150n W=8u NF=8" % (sfx, sfx, sfx, vh, vh), "MN%s_2 i2%s i1%s %s %s nmos_io L=150n W=4u NF=4" % (sfx, sfx, sfx, vl, vl),
        "MP%s_3 g%s i2%s %s %s pmos_io L=150n W=24u NF=24" % (sfx, sfx, sfx, vh, vh), "MN%s_3 g%s i2%s %s %s nmos_io L=150n W=12u NF=12" % (sfx, sfx, sfx, vl, vl),
        "MBIG%s %s g%s %s %s nmos_io L=150n W=2000u NF=400" % (sfx, vh, sfx, vl, vl)]
    for c in cs:
        pn = [p[0] for p in c.pins]
        o.append(".SUBCKT %s %s VDD VSS IOVDD IOVSS" % (c.name, " ".join(pn)))
        o.append("* " + c.desc)
        if c.kind in ("bidir", "out") and not c.bs:
            o += ["* core->IO level shifter for I and OEN (DCVS, thick-ox core)",
                  "MLS0 ls_ib I VSS VSS nmos_io L=150n W=1u NF=1", "XLI I ib VDD VSS INV_X2_SVT", "MLS1 ls_i ib VSS VSS nmos_io L=150n W=1u NF=1",
                  "MLS2 ls_ib ls_i IOVDD IOVDD pmos_io L=150n W=0.4u NF=1", "MLS3 ls_i ls_ib IOVDD IOVDD pmos_io L=150n W=0.4u NF=1",
                  "MLO0 ls_oeb OEN VSS VSS nmos_io L=150n W=1u NF=1", "XLO OEN oenb VDD VSS INV_X2_SVT", "MLO1 ls_oe oenb VSS VSS nmos_io L=150n W=1u NF=1",
                  "MLO2 ls_oeb ls_oe IOVDD IOVDD pmos_io L=150n W=0.4u NF=1", "MLO3 ls_oe ls_oeb IOVDD IOVDD pmos_io L=150n W=0.4u NF=1",
                  "* pre-driver: pg = NAND(i, !oe), ng = NOR(i, oe)",
                  "MPA pg ls_i IOVDD IOVDD pmos_io L=150n W=6u NF=4", "MPB pg ls_oe IOVDD IOVDD pmos_io L=150n W=6u NF=4",
                  "MNA pg ls_i pga IOVSS nmos_io L=150n W=6u NF=4", "MNB pga ls_oe IOVSS IOVSS nmos_io L=150n W=6u NF=4",
                  "MPC ng ls_i ngc IOVDD pmos_io L=150n W=8u NF=4", "MPD ngc ls_oeb IOVDD IOVDD pmos_io L=150n W=8u NF=4",
                  "MNC ng ls_i IOVSS IOVSS nmos_io L=150n W=4u NF=2", "MND ng ls_oeb IOVSS IOVSS nmos_io L=150n W=4u NF=2"]
            for k, w in enumerate((40, 40, 80, 80)):
                en = ["IOVDD", "ds0h", "ds1h", "ds01h"][k]
                o += ["MOP%d PAD pg op%d IOVDD pmos_io L=150n W=%du NF=%d" % (k, k, w, w // 4), "MOE%d op%d %s_b IOVDD IOVDD pmos_io L=150n W=%du NF=%d" % (k, k, en, w * 2, w // 2),
                      "MON%d PAD ng on%d IOVSS nmos_io L=150n W=%du NF=%d" % (k, k, w // 2, w // 8), "MNE%d on%d %s IOVSS IOVSS nmos_io L=150n W=%du NF=%d" % (k, k, en, w, w // 4)]
            o += ["XDS0 DS0 ds0h_i VDD VSS BUF_X1_SVT", "RDS0 ds0h_i ds0h 1", "XDS1 DS1 ds1h_i VDD VSS BUF_X1_SVT", "RDS1 ds1h_i ds1h 1",
                  "XDS2 DS0 DS1 ds01h_i VDD VSS AND2_X1_SVT", "RDS2 ds01h_i ds01h 1",
                  "MIB0 IOVDD_b IOVDD IOVSS IOVSS nmos_io L=150n W=1u NF=1", "MIB1 ds0h_b ds0h IOVSS IOVSS nmos_io L=150n W=1u NF=1",
                  "MIB2 ds1h_b ds1h IOVSS IOVSS nmos_io L=150n W=1u NF=1", "MIB3 ds01h_b ds01h IOVSS IOVSS nmos_io L=150n W=1u NF=1"]
        if c.kind in ("bidir", "in", "ana", "out") and not c.bs:
            o += ["* primary ESD (dual diode) + secondary R + GGNMOS",
                  "DESP PAD IOVDD dio_esd_p AREA=40p", "DESN IOVSS PAD dio_esd_n AREA=40p",
                  "RSEC PAD padi %d" % (50 if c.kind == "ana" else 200),
                  "MGG padi IOVSS IOVSS IOVSS nmos_io L=150n W=20u NF=10", "DSEC IOVSS padi dio_n AREA=4p"]
        if c.kind in ("bidir", "in") and not c.bs:
            o += ["* receiver: Schmitt (ST) / CMOS input, IE gate, IO->core down-shift",
                  "MRP0 rx0 padi IOVDD IOVDD pmos_io L=150n W=2u NF=1", "MRN0 rx0 padi IOVSS IOVSS nmos_io L=150n W=1u NF=1",
                  "MHP rx0 rxb hy IOVDD pmos_io L=150n W=0.5u NF=1", "MHS hy ST IOVSS IOVSS nmos_io L=150n W=0.5u NF=1",
                  "MRP1 rxb rx0 IOVDD IOVDD pmos_io L=150n W=2u NF=1", "MRN1 rxb rx0 IOVSS IOVSS nmos_io L=150n W=1u NF=1",
                  "XDN rxb rxl VDD VSS INV_X2_SVT", "XIE rxl IE C VDD VSS AND2_X4_SVT",
                  "* weak pull-up / pull-down (~50k)", "MPU PAD pub IOVDD IOVDD pmos_io L=2u W=0.3u NF=1", "XPU PU pub VDD VSS INV_X1_SVT",
                  "MPDN PAD PD IOVSS IOVSS nmos_io L=4u W=0.3u NF=1"]
        if c.kind == "ana": o.append("RANA padi ANA 1")
        if c.bs:
            o.append("* boundary-scan register: capture/shift = SDFF (D=capture, SI=chain, SE=SHIFTDR, CK=CLOCKDR); update = DFF on UPDATEDR")
            if c.kind == "bidir":
                if c.nfunc > 1:
                    o += ["XMI I0 I1 I2 I3 SEL0 SEL1 im VDD VSS MUX4_X2_SVT", "XMO OEN0 OEN1 OEN2 OEN3 SEL0 SEL1 om VDD VSS MUX4_X2_SVT"]
                else:
                    o += ["RIM I0 im 1", "ROM OEN0 om 1"]
                o += ["XBSI cpad BSI SHIFTDR CLOCKDR bs_in VDD VSS SDFF_X1_SVT",
                      "XBSOE om bs_in SHIFTDR CLOCKDR bs_oe VDD VSS SDFF_X1_SVT",
                      "XBSO im bs_oe SHIFTDR CLOCKDR BSO VDD VSS SDFF_X1_SVT",
                      "XUPOE bs_oe UPDATEDR up_oe VDD VSS DFF_X1_SVT", "XUPO BSO UPDATEDR up_out VDD VSS DFF_X1_SVT",
                      "XMDI im up_out MODE pi VDD VSS MUX2_X2_SVT", "XMDO om up_oe MODE po VDD VSS MUX2_X2_SVT",
                      "XCAP PAD VDD cpad VDD VSS AND2_X1_SVT" if False else "XDRV PAD pi po VDD PU PD DS0 DS1 ST cpad VDD VSS IOVDD IOVSS PBIDIR18",
                      "XCE cpad IE C VDD VSS AND2_X2_SVT"]
            else:
                o += ["XRCV PAD VDD PU PD ST cpad VDD VSS IOVDD IOVSS PIN18",
                      "XBSI cpad BSI SHIFTDR CLOCKDR BSO VDD VSS SDFF_X1_SVT", "XCE cpad IE C VDD VSS AND2_X2_SVT"]
        if c.kind in ("power",) and c.name in ("PADVDD", "PADIOVDD"):
            vh, vl = ("VDD", "VSS") if c.name == "PADVDD" else ("IOVDD", "IOVSS"); o += clamp(vh, vl, "C")
        if c.kind == "clamp":
            vh, vl = ("VDD", "VSS") if c.name == "PCLAMPVDD" else ("IOVDD", "IOVSS"); o += clamp(vh, vl, "C")
        if c.kind == "power":
            o.append("* pad tied to rail: %s" % {"PADVDD": "VDD", "PADVSS": "VSS", "PADIOVDD": "IOVDD", "PADIOVSS": "IOVSS"}[c.name])
        if c.kind == "brk":
            o += ["DB0 VSS IOVSS dio_esd_n AREA=10p", "DB1 IOVSS VSS dio_esd_n AREA=10p"]
        if c.kind == "poc":
            o += ["MPC0 POC vdet IOVDD IOVDD pmos_io L=150n W=1u NF=1", "MNC0 POC vdet IOVSS IOVSS nmos_io L=150n W=1u NF=1",
                  "MDET vdet VDD IOVSS IOVSS nmos_io L=150n W=2u NF=1", "RDET IOVDD vdet 200k"]
        o += [".ENDS %s" % c.name, ""]
    return "\n".join(o) + "\n"
