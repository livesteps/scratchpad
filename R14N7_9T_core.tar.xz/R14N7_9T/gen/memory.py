"""R14N7 memory compiler: single-port SRAM, two-port register file, contact/V0-programmed ROM.
Views per instance: Verilog (behavioral), Liberty (NLDM+LVF / CCS / ECSM, all corners),
LEF abstract, GDS (bitcell-accurate arrays via references + periphery blocks), SPICE/CDL
(hierarchical, transistor-level bitcell/array/precharge/colmux/sense-amp/write-driver,
std-cell decoders & control)."""
import math, random, os
import gdstk
import charmodel as cm
from tech import CORNERS, BANNER, CPP, ROW_H, L, PIN_DT, TEXT_DT
import liberty as lb

BC_W, BC_H = 108, 216                 # 6T bitcell 0.108 x 0.216 um = 0.0233 um^2
ROMBC_W, ROMBC_H = 54, 108
DEC_W, IO_H, CTL_H, MARGIN = 6048, 4050, 1080, 540   # nm

SP = [(64, 32, 2), (128, 32, 2), (256, 32, 4), (256, 64, 4), (512, 32, 4), (512, 64, 4), (1024, 32, 8),
      (1024, 64, 8), (2048, 32, 8), (2048, 64, 8), (4096, 32, 16), (4096, 64, 16)]
RF2P = [(32, 32, 1), (64, 32, 2), (64, 64, 2), (128, 64, 2), (256, 32, 4)]
ROM = [(512, 32, 8), (1024, 32, 8), (2048, 64, 8), (4096, 32, 16)]

class Mem:
    def __init__(s, kind, words, bits, mux, data=None, code=None):
        s.kind, s.words, s.bits, s.mux = kind, words, bits, mux
        s.aw = int(math.log2(words)); s.rows = words // mux; s.cols = bits * mux
        pre = {"sp": "R14SRAM_SP", "rf": "R14RF_2P", "rom": "R14ROM"}[kind]
        s.name = "%s_%dx%dm%d" % (pre, words, bits, mux) + (("_" + code) if code else "")
        bw, bh = (ROMBC_W, ROMBC_H) if kind == "rom" else (BC_W, BC_H)
        s.arr_w = s.cols * bw; s.arr_h = s.rows * bh
        w = DEC_W + s.arr_w + 2 * MARGIN; h = IO_H + CTL_H + s.arr_h + 2 * MARGIN
        if kind == "rf": h += IO_H // 2
        npins = sum(p[2] for p in s.pins())
        w = max(w, (npins + 4) * 54 + 2 * MARGIN)
        s.w = int(math.ceil(w / 108.0)) * 108     # 2-site placement grid (M5 track alignment)
        s.h = int(math.ceil(h / float(ROW_H))) * ROW_H
        random.seed(__import__("zlib").crc32(s.name.encode()))
        s.data = (list(data) if data is not None else [random.getrandbits(bits) for _ in range(words)]) if kind == "rom" else None
        if s.data is not None: assert len(s.data) == words and all(0 <= v < (1 << bits) for v in s.data)
    @property
    def area(s): return s.w * s.h * 1e-6
    def fpins(s):
        """functional pins (name, dir, width, role)"""
        if s.kind == "sp":
            return [("CLK", "input", 1, "clock"), ("CEB", "input", 1, "ctl"), ("WEB", "input", 1, "ctl"),
                    ("A", "input", s.aw, "addr"), ("D", "input", s.bits, "data"), ("BWEB", "input", s.bits, "data"),
                    ("Q", "output", s.bits, "out")]
        if s.kind == "rf":
            return [("CLKA", "input", 1, "clock"), ("CEBA", "input", 1, "ctl"), ("AA", "input", s.aw, "addr"),
                    ("QA", "output", s.bits, "out"), ("CLKB", "input", 1, "clock"), ("CEBB", "input", 1, "ctl"),
                    ("AB", "input", s.aw, "addr"), ("D", "input", s.bits, "data"), ("BWEB", "input", s.bits, "data")]
        return [("CLK", "input", 1, "clock"), ("CEB", "input", 1, "ctl"), ("A", "input", s.aw, "addr"), ("Q", "output", s.bits, "out")]
    def bist_map(s):
        """functional input -> BIST twin (selected when TEN=1)"""
        return {p[0]: "T" + p[0] for p in s.fpins() if p[1] == "input" and p[3] != "clock"}
    def pins(s):
        tw = s.bist_map()
        out = list(s.fpins()) + [("TEN", "input", 1, "ctl")]
        for n, d, w, r in s.fpins():
            if n in tw: out.append((tw[n], d, w, r))
        return out
    pg = [("VDD", "primary_power", "VDD"), ("VDDM", "primary_power", "VDD"), ("VSS", "primary_ground", "VSS")]
    # nominal timing (ps) / energy (fJ) / leakage (pW)
    def tcq(s): return 95 + 0.22 * s.rows + 0.9 * s.mux + 0.15 * s.bits
    def tcyc(s): return s.tcq() * 1.35 + 40
    def e_read(s): return 0.45 * s.cols * 0.7 ** 2 * (0.5 + s.rows / 256.0) + 2.0 * s.bits + 120
    def e_write(s): return 1.25 * s.e_read()
    def leak(s, cname):
        r = cm.leak_fin(cname, "SVT", "n") / cm.leak_fin("tt_0p70v_25c", "SVT", "n")
        nb = s.words * s.bits
        per = 4.0 if s.kind == "rom" else 22.0
        return (nb * per + 30000 + 40 * s.cols) * r

def all_mems():
    return [Mem("sp", *c) for c in SP] + [Mem("rf", *c) for c in RF2P] + [Mem("rom", *c) for c in ROM]

# ------------------------------------------------------------------ Verilog
def verilog(m):
    o = ["`timescale 1ps/1fs", "`celldefine", "// %s" % BANNER, "// %s : %s, %d words x %d bits, column mux %d" % (m.name, m.kind, m.words, m.bits, m.mux)]
    ps = m.pins()
    o.append("module %s (%s\n`ifdef R14_PG_PINS\n  , VDD, VDDM, VSS\n`endif\n);" % (m.name, ", ".join(p[0] for p in ps)))
    for n, d, w, r in ps:
        o.append("  %s %s%s;" % (d, ("[%d:0] " % (w - 1)) if w > 1 else "", n))
    o += ["`ifdef R14_PG_PINS", "  inout VDD, VDDM, VSS;", "`endif"]
    o.append("  // ---- built-in BIST port: TEN=1 selects the T* inputs (memory BIST controller)")
    for n, tn in m.bist_map().items():
        w = [p[2] for p in m.fpins() if p[0] == n][0]
        o.append("  wire %s%s_i = TEN ? %s : %s;" % (("[%d:0] " % (w - 1)) if w > 1 else "", n, tn, n))
    o.append("  reg [%d:0] mem [0:%d];" % (m.bits - 1, m.words - 1))
    o.append("  reg notifier; integer i;")
    if m.kind == "sp":
        o += ["  reg [%d:0] Q_r;" % (m.bits - 1), "  assign Q = Q_r;",
              "  always @(posedge CLK) begin",
              "    if (CEB_i === 1'b0) begin",
              "      if (WEB_i === 1'b0) begin",
              "        if (^A_i === 1'bx) for (i = 0; i < %d; i = i + 1) mem[i] = {%d{1'bx}};" % (m.words, m.bits),
              "        else mem[A_i] = (mem[A_i] & BWEB_i) | (D_i & ~BWEB_i);",
              "      end else if (WEB_i === 1'b1) Q_r = (^A_i === 1'bx) ? {%d{1'bx}} : mem[A_i];" % m.bits,
              "      else Q_r = {%d{1'bx}};" % m.bits,
              "    end else if (CEB_i !== 1'b1) Q_r = {%d{1'bx}};" % m.bits,
              "  end",
              "  always @(notifier) Q_r = {%d{1'bx}};" % m.bits]
    elif m.kind == "rf":
        o += ["  reg [%d:0] QA_r;" % (m.bits - 1), "  assign QA = QA_r;",
              "  always @(posedge CLKA) if (CEBA_i === 1'b0) QA_r = (^AA_i === 1'bx) ? {%d{1'bx}} : mem[AA_i];" % m.bits,
              "  always @(posedge CLKB) if (CEBB_i === 1'b0) begin",
              "    if (^AB_i === 1'bx) for (i = 0; i < %d; i = i + 1) mem[i] = {%d{1'bx}};" % (m.words, m.bits),
              "    else mem[AB_i] = (mem[AB_i] & BWEB_i) | (D_i & ~BWEB_i);", "  end",
              "  always @(notifier) QA_r = {%d{1'bx}};" % m.bits]
    else:
        o += ['  initial $readmemh("%s.hex", mem);' % m.name,
              "  reg [%d:0] Q_r;" % (m.bits - 1), "  assign Q = Q_r;",
              "  always @(posedge CLK) if (CEB_i === 1'b0) Q_r = (^A_i === 1'bx) ? {%d{1'bx}} : mem[A_i];" % m.bits]
    o.append("  specify")
    ck = "CLKA" if m.kind == "rf" else "CLK"
    out = "QA" if m.kind == "rf" else "Q"
    o.append("    (posedge %s => (%s : %s)) = (0, 0);" % (ck, out, out))
    for n, d, w, r in ps:
        if d == "input" and r != "clock":
            nb_ = n[1:] if (n.startswith("T") and n[1:] in m.bist_map()) else n
            c2 = "CLKB" if (m.kind == "rf" and nb_ in ("CEBB", "AB", "D", "BWEB")) else ck
            for b in range(w):
                o.append("    $setuphold(posedge %s, %s%s, 0, 0, notifier);" % (c2, n, ("[%d]" % b) if w > 1 else ""))
    o.append("    $period(posedge %s, 0, notifier);" % ck)
    o.append("    $width(posedge %s, 0, 0, notifier); $width(negedge %s, 0, 0, notifier);" % (ck, ck))
    o += ["  endspecify", "endmodule", "`endcelldefine", ""]
    return "\n".join(o)

def hexfile(m):
    nd = (m.bits + 3) // 4
    return "\n".join(("%0" + str(nd) + "x") % v for v in m.data) + "\n"

# ------------------------------------------------------------------ Liberty
def lib_cell(L_, m, corner, model):
    cn = corner.name; V = corner.vdd
    sm = 0.5 * (cm.rscale(cn, "SVT", "p") + cm.rscale(cn, "SVT", "n"))
    sg = cm.sigma_rel(cn, "SVT", 12, 6.0)
    L_ += ["  cell (%s) {" % m.name, "    area : %.4f;" % m.area, "    is_memory_cell : true;" if False else "    dont_touch : true;",
           "    dont_use : true;", "    interface_timing : true;",
           "    memory () { type : %s; address_width : %d; word_width : %d; }" % ("rom" if m.kind == "rom" else "ram", m.aw, m.bits),
           "    cell_leakage_power : %s;" % lb.F(m.leak(cn))]
    for n, t, v in m.pg: L_.append("    pg_pin (%s) { voltage_name : VDD; pg_type : %s; }" % (n, t) if "power" in t else
                                   "    pg_pin (%s) { voltage_name : VSS; pg_type : %s; }" % (n, t))
    _b = lambda n: n[1:] if (n.startswith("T") and n[1:] in m.bist_map()) else n
    ck_of = lambda n: ("CLKB" if (m.kind == "rf" and _b(n) in ("CEBB", "AB", "D", "BWEB")) else ("CLKA" if m.kind == "rf" else "CLK"))
    loads = [5.0, 10.0, 20.0, 40.0, 80.0, 160.0, 320.0]
    for n, d, w, r in m.pins():
        hd = ("bus (%s) { bus_type : bus%d;" % (n, w)) if w > 1 else ("pin (%s) {" % n)
        L_.append("    " + hd)
        L_ += ["      direction : %s;" % d, "      related_power_pin : VDD;", "      related_ground_pin : VSS;"]
        if d == "input":
            cap = 2.5 if r == "clock" else 0.9
            L_.append("      capacitance : %s;" % lb.F(cap * cm.cap_scale(cn)))
            if r == "clock":
                L_ += ["      clock : true;", "      min_pulse_width_high : %s;" % lb.F(0.3 * m.tcyc() * sm),
                       "      min_pulse_width_low : %s;" % lb.F(0.3 * m.tcyc() * sm), "      min_period : %s;" % lb.F(m.tcyc() * sm)]
                L_.append("      internal_power () {"); L_.append("        related_pg_pin : VDD;")
                conds = [("!CEB&WEB", m.e_read()), ("!CEB&!WEB", m.e_write()), ("CEB", 40.0)] if m.kind == "sp" else \
                        ([("!CEBA", m.e_read()), ("CEBA", 30.0)] if n == "CLKA" else [("!CEBB", m.e_write()), ("CEBB", 30.0)]) if m.kind == "rf" else \
                        [("!CEB", m.e_read()), ("CEB", 30.0)]
                L_.pop(); L_.pop()
                for cond, e in conds:
                    L_ += ["      internal_power () {", '        when : "%s";' % cond, "        related_pg_pin : VDD;"]
                    lb.tbl(L_, 8, "rise_power", "passive_power_template_7x1", cm.SLEWS, None, [e * (V / 0.7) ** 2 * (1 + 0.0005 * s) for s in cm.SLEWS])
                    lb.tbl(L_, 8, "fall_power", "passive_power_template_7x1", cm.SLEWS, None, [0.05 * e * (V / 0.7) ** 2 for s in cm.SLEWS])
                    L_.append("      }")
            else:
                for kind, base in (("setup_rising", 28.0 if r == "addr" else 22.0), ("hold_rising", 12.0)):
                    L_ += ["      timing () {", '        related_pin : "%s";' % ck_of(n), "        timing_type : %s;" % kind]
                    for rf in ("rise", "fall"):
                        vals = cm.constraint_table(cn, "SVT", base, kind, rf == "rise")
                        lb.tbl(L_, 8, "%s_constraint" % rf, "constraint_template_5x5", cm.CSLEWS, cm.CSLEWS, vals)
                        if model in ("nldm", "ccs"):
                            lb.tbl(L_, 8, "ocv_sigma_%s_constraint" % rf, "constraint_template_5x5", cm.CSLEWS, cm.CSLEWS,
                                   [[abs(v) * sg + 0.5 for v in rr] for rr in vals], extra=['sigma_type : "early_and_late";'])
                    L_.append("      }")
        else:
            L_ += ["      max_capacitance : 320;", '      function : "";'.replace('function : "";', "")]
            L_.append("      timing () {")
            L_ += ['        related_pin : "%s";' % ("CLKA" if m.kind == "rf" else "CLK"), "        timing_type : rising_edge;", "        timing_sense : non_unate;"]
            st = lb.St(); st.rn, st.rp, st.cpar, st.fins, st.loads, st.nstages = 1.15, 1.25, 1.0, 12, loads, 6.0
            T = cm.delay_tables(cn, "SVT", st, m.tcq() - 6, 0.05)
            for dn, tn, rise in (("cell_rise", "rise_transition", True), ("cell_fall", "fall_transition", False)):
                lb.tbl(L_, 8, dn, "delay_template_7x7", cm.SLEWS, loads, T[dn])
                lb.tbl(L_, 8, tn, "delay_template_7x7", cm.SLEWS, loads, T[tn])
                if model in ("nldm", "ccs"):
                    lb.tbl(L_, 8, "ocv_sigma_" + dn, "delay_template_7x7", cm.SLEWS, loads, [[v * sg for v in rr] for rr in T[dn]], extra=['sigma_type : "early_and_late";'])
                    lb.tbl(L_, 8, "ocv_sigma_" + tn, "delay_template_7x7", cm.SLEWS, loads, [[v * sg * 1.2 for v in rr] for rr in T[tn]], extra=['sigma_type : "early_and_late";'])
                if model == "ccs":
                    L_.append("        output_current_%s () {" % ("rise" if rise else "fall"))
                    for si in cm.CCS_SI:
                        for li in cm.CCS_LI:
                            ref, ts, vals = cm.ccs_vector(cm.SLEWS[si], T[dn][si][li], T[tn][si][li], loads[li], V, rise)
                            L_ += ["          vector (ccs_template) {", "            reference_time : %s;" % lb.F(ref),
                                   '            index_1 ("%s"); index_2 ("%s");' % (lb.F(cm.SLEWS[si]), lb.F(loads[li])),
                                   '            index_3 ("%s");' % lb.row(ts), '            values ("%s");' % lb.row(vals), "          }"]
                    L_.append("        }")
                if model == "ecsm":
                    L_.append("        ecsm_waveform_set (ecsm_%s) {" % ("rise" if rise else "fall"))
                    for si in cm.CCS_SI:
                        for li in cm.CCS_LI:
                            L_ += ["          ecsm_waveform (ecsm_template) {",
                                   '            index_1 ("%s"); index_2 ("%s");' % (lb.F(cm.SLEWS[si]), lb.F(loads[li])),
                                   '            index_3 ("%s");' % lb.row(cm.ECSM_V),
                                   '            values ("%s");' % lb.row(cm.ecsm_times(cm.SLEWS[si], T[dn][si][li], T[tn][si][li])), "          }"]
                    L_.append("        }")
            L_.append("      }")
        L_.append("    }")
    L_.append("  }")

def write_lib(path, mems, corner, model):
    L_ = []
    widths = sorted(set(w for m in mems for (n, d, w, r) in m.pins() if w > 1))
    lb.lib_header("r14n7_mem_%s_%s" % (corner.name, model), corner, [("VDD", corner.vdd), ("VSS", 0.0)], L_, widths)
    for m in mems: lib_cell(L_, m, corner, model)
    L_.append("}")
    open(path, "w").write("\n".join(L_) + "\n")

# ------------------------------------------------------------------ LEF / GDS
def pin_layout(m):
    """bottom-edge M3 pins on M3 tracks (x = 27 + 54k nm); returns [(pinname, x0,y0,x1,y1, layer)]"""
    names = []
    for n, d, w, r in m.pins():
        names += ["%s[%d]" % (n, b) for b in range(w)] if w > 1 else [n]
    ntr = (m.w - 2 * MARGIN) // 54
    step = max(1, ntr // (len(names) + 1))
    if step < 2 and len(names) * 2 > ntr: step = 1
    out = []
    for i, n in enumerate(names):
        x = MARGIN + 27 + 54 * (step * (i + 1))
        x = (x - 27) // 54 * 54 + 27
        out.append((n, x - 12, 0, x + 12, 540, "M3"))
    return out

def power_straps(m):
    """vertical M5 straps on M5 tracks (x = 54 + 108k): VDD, VSS, VDDM repeating"""
    out = []; k = 0; x = 54 + 108 * 4
    names = ["VDD", "VSS", "VDDM", "VSS"]
    while x + 108 * 4 < m.w:
        out.append((names[k % 4], x - 24, MARGIN, x + 24, m.h - MARGIN, "M5")); k += 1; x += 108 * 6
    return out

def write_lef(path, mems):
    o = ["# " + BANNER, "VERSION 5.8 ;", 'BUSBITCHARS "[]" ;', 'DIVIDERCHAR "/" ;', ""]
    for m in mems:
        W, H = m.w / 1000.0, m.h / 1000.0
        o += ["MACRO %s" % m.name, "  CLASS BLOCK ;", "  ORIGIN 0 0 ;", "  FOREIGN %s 0 0 ;" % m.name,
              "  SIZE %.3f BY %.3f ;" % (W, H), "  SYMMETRY X Y R90 ;"]
        dirs = {}
        for n, d, w, r in m.pins():
            for b in range(w): dirs["%s[%d]" % (n, b) if w > 1 else n] = (d, r)
        for (n, x0, y0, x1, y1, lay) in pin_layout(m):
            d, r = dirs[n]
            o += ["  PIN %s" % n, "    DIRECTION %s ;" % d.upper(), "    USE %s ;" % ("CLOCK" if r == "clock" else "SIGNAL"),
                  "    ANTENNAGATEAREA 0.0060 LAYER %s ;" % lay if d == "input" else "    ANTENNADIFFAREA 0.0200 LAYER %s ;" % lay,
                  "    PORT", "      LAYER %s ;" % lay, "        RECT %.3f %.3f %.3f %.3f ;" % (x0 / 1e3, y0 / 1e3, x1 / 1e3, y1 / 1e3),
                  "    END", "  END %s" % n]
        st = power_straps(m)
        for pn in ("VDD", "VDDM", "VSS"):
            o += ["  PIN %s" % pn, "    DIRECTION INOUT ;", "    USE %s ;" % ("GROUND" if pn == "VSS" else "POWER"), "    PORT", "      LAYER M5 ;"]
            for (n, x0, y0, x1, y1, lay) in st:
                if n == pn: o.append("        RECT %.3f %.3f %.3f %.3f ;" % (x0 / 1e3, y0 / 1e3, x1 / 1e3, y1 / 1e3))
            o += ["    END", "  END %s" % pn]
        o += ["  OBS", "    LAYER M1 ;", "      RECT 0 0 %.3f %.3f ;" % (W, H), "    LAYER M2 ;", "      RECT 0 0 %.3f %.3f ;" % (W, H),
              "    LAYER M3 ;", "      RECT 0 0.600 %.3f %.3f ;" % (W, H), "    LAYER M4 ;", "      RECT 0 0 %.3f %.3f ;" % (W, H), "  END",
              "END %s" % m.name, ""]
    o.append("END LIBRARY")
    open(path, "w").write("\n".join(o) + "\n")

def R(cell, lay, x0, y0, x1, y1, dt=None):
    l, d = L(lay); cell.add(gdstk.rectangle((x0 / 1e3, y0 / 1e3), (x1 / 1e3, y1 / 1e3), layer=l, datatype=d if dt is None else dt))

def bitcell_6t(lib):
    c = lib.new_cell("R14_BC6T_HD")
    R(c, "PRBNDRY", 0, 0, BC_W, BC_H); R(c, "SRAMMK", 0, 0, BC_W, BC_H)
    R(c, "NWELL", 0, 81, BC_W, 135); R(c, "NSELECT", 0, 0, BC_W, 81); R(c, "NSELECT", 0, 135, BC_W, BC_H); R(c, "PSELECT", 0, 81, BC_W, 135)
    for k in range(8):
        y = 27 * k + 10; R(c, "FIN", 0, y, BC_W, y + 7)
    R(c, "ACTIVE", 8, 32, 100, 76); R(c, "ACTIVE", 8, 140, 100, 184); R(c, "ACTIVE", 8, 86, 100, 130)
    for x in (27, 81):
        R(c, "GATE", x - 10, 20, x + 10, 196)
    R(c, "GCUT", 0, 78, BC_W, 84); R(c, "GCUT", 0, 132, BC_W, 138)
    for x in (0, 54, 108):
        R(c, "LISD", max(x - 12, 0), 34, min(x + 12, BC_W), 74); R(c, "LISD", max(x - 12, 0), 142, min(x + 12, BC_W), 182)
    R(c, "M1", 18, 0, 36, BC_H); R(c, "M1", 72, 0, 90, BC_H)        # BL / BLB
    R(c, "M2", 0, 97, BC_W, 119)                                     # WL
    return c

def rom_cells(lib):
    """1T NOR-ROM bitcell 54 x 108 nm; code is set by V0 (drain->BL) + ROMPGM marker: present = bit 0"""
    out = {}
    for v in (0, 1):
        c = lib.new_cell("R14_ROMBC_%d" % v)
        R(c, "PRBNDRY", 0, 0, ROMBC_W, ROMBC_H); R(c, "SRAMMK", 0, 0, ROMBC_W, ROMBC_H); R(c, "NSELECT", 0, 0, ROMBC_W, ROMBC_H)
        for k in range(4):
            y = 27 * k + 10; R(c, "FIN", 0, y, ROMBC_W, y + 7)
        R(c, "ACTIVE", 0, 32, ROMBC_W, 76); R(c, "GATE", 3, 20, 23, 88)          # WL gate
        R(c, "LISD", 30, 34, 54, 74)                                               # drain trench contact
        if v == 0:
            R(c, "V0", 33, 45, 51, 63); R(c, "ROMPGM", 30, 40, 54, 68)           # programmed: drain contacted to BL
        R(c, "M1", 33, 0, 51, ROMBC_H)                                             # bitline
        out[v] = c
    return out

def block(lib, name, w, h, marker):
    c = lib.new_cell(name)
    R(c, "PRBNDRY", 0, 0, w, h)
    for lay in ("NWELL",):
        R(c, lay, 0, h // 2, w, h)
    R(c, "M1", 0, 0, w, h, dt=1); R(c, "M2", 0, 0, w, h, dt=1)       # periphery fill-level abstract (dt 1)
    if marker: R(c, marker, 0, 0, w, h)
    return c

def code_layer_gds(path, m):
    """mask-shop deliverable: only the ROM code layers (V0 + ROMPGM) in macro coordinates"""
    lib = gdstk.Library(m.name + "_CODE", unit=1e-6, precision=1e-10)
    c = lib.new_cell(m.name + "_CODE")
    R(c, "PRBNDRY", 0, 0, m.w, m.h)
    x0 = MARGIN + DEC_W; y0 = MARGIN + IO_H + CTL_H
    for r in range(m.rows):
        for col in range(m.cols):
            word = r * m.mux + (col % m.mux); bit = col // m.mux
            if not (m.data[word] >> bit) & 1:
                bx = x0 + col * ROMBC_W; by = y0 + r * ROMBC_H
                R(c, "V0", bx + 33, by + 45, bx + 51, by + 63); R(c, "ROMPGM", bx + 30, by + 40, bx + 54, by + 68)
    lib.write_gds(path)

def build_gds(path, mems):
    lib = gdstk.Library("r14n7_mem", unit=1e-6, precision=1e-10)
    bc = bitcell_6t(lib); rb = rom_cells(lib)
    for m in mems:
        top = lib.new_cell(m.name)
        R(top, "PRBNDRY", 0, 0, m.w, m.h)
        x0 = MARGIN + DEC_W; y0 = MARGIN + IO_H + CTL_H + (IO_H // 2 if m.kind == "rf" else 0)
        if m.kind == "rom":
            arr = lib.new_cell(m.name + "_ARRAY")
            for r in range(m.rows):
                for col in range(m.cols):
                    word = r * m.mux + (col % m.mux); bit = col // m.mux
                    v = (m.data[word] >> bit) & 1
                    arr.add(gdstk.Reference(rb[v], (col * ROMBC_W / 1e3, r * ROMBC_H / 1e3)))
            top.add(gdstk.Reference(arr, (x0 / 1e3, y0 / 1e3)))
        else:
            top.add(gdstk.Reference(bc, (x0 / 1e3, y0 / 1e3), columns=m.cols, rows=m.rows, spacing=(BC_W / 1e3, BC_H / 1e3)))
        dec = block(lib, m.name + "_XDEC", DEC_W, m.arr_h, None)
        top.add(gdstk.Reference(dec, (MARGIN / 1e3, y0 / 1e3)))
        io = block(lib, m.name + "_IO", m.arr_w, IO_H, None); top.add(gdstk.Reference(io, (x0 / 1e3, MARGIN / 1e3)))
        ctl = block(lib, m.name + "_CTRL", DEC_W, IO_H + CTL_H, None); top.add(gdstk.Reference(ctl, (MARGIN / 1e3, MARGIN / 1e3)))
        for (n, a, b, c_, d, lay) in pin_layout(m):
            R(top, lay, a, b, c_, d); R(top, lay, a, b, c_, d, dt=PIN_DT)
            top.add(gdstk.Label(n, ((a + c_) / 2e3, (b + d) / 2e3), layer=L(lay)[0], texttype=TEXT_DT))
        for (n, a, b, c_, d, lay) in power_straps(m):
            R(top, lay, a, b, c_, d); R(top, lay, a, b, c_, d, dt=PIN_DT)
            top.add(gdstk.Label(n, ((a + c_) / 2e3, (b + d) / 2e3), layer=L(lay)[0], texttype=TEXT_DT))
    lib.write_gds(path)

# ------------------------------------------------------------------ SPICE
BLOCKS = r"""
* ---- 6T high-density bitcell (SRAM-Vt devices) ----
.SUBCKT R14_BC6T_HD BL BLB WL VDDM VSS
MPU0 Q  QB VDDM VDDM pmos_sram L=20n NFIN=1 NF=1
MPD0 Q  QB VSS  VSS  nmos_sram L=20n NFIN=1 NF=1
MPU1 QB Q  VDDM VDDM pmos_sram L=20n NFIN=1 NF=1
MPD1 QB Q  VSS  VSS  nmos_sram L=20n NFIN=1 NF=1
MPG0 BL  WL Q  VSS nmos_sram L=20n NFIN=1 NF=1
MPG1 BLB WL QB VSS nmos_sram L=20n NFIN=1 NF=1
.ENDS R14_BC6T_HD
* ---- ROM bitcell, programmed (transistor to VSS) ----
.SUBCKT R14_ROMBC_0 BL WL VSS
MN0 BL WL VSS VSS nmos_rvt L=20n NFIN=1 NF=1
.ENDS R14_ROMBC_0
.SUBCKT R14_ROMBC_1 BL WL VSS
* unprogrammed: same transistor, drain not contacted to BL (no V0) -> floating drain node
MN0 DRN WL VSS VSS nmos_rvt L=20n NFIN=1 NF=1
.ENDS R14_ROMBC_1
* ---- bitline precharge / equalize (active-low PCHB) ----
.SUBCKT R14_PCH BL BLB PCHB VDDM
MP0 BL PCHB VDDM VDDM pmos_lvt L=20n NFIN=2 NF=1
MP1 BLB PCHB VDDM VDDM pmos_lvt L=20n NFIN=2 NF=1
MP2 BL PCHB BLB VDDM pmos_lvt L=20n NFIN=1 NF=1
.ENDS R14_PCH
* ---- column mux pass pair ----
.SUBCKT R14_CMUX BL BLB DL DLB SEL SELB VDD VSS
MN0 BL SEL DL VSS nmos_lvt L=20n NFIN=2 NF=1
MN1 BLB SEL DLB VSS nmos_lvt L=20n NFIN=2 NF=1
MP0 BL SELB DL VDD pmos_lvt L=20n NFIN=2 NF=1
MP1 BLB SELB DLB VDD pmos_lvt L=20n NFIN=2 NF=1
.ENDS R14_CMUX
* ---- latch-type sense amplifier ----
.SUBCKT R14_SA DL DLB SAE OUT VDD VSS
MP0 SO SOB VDD VDD pmos_rvt L=20n NFIN=2 NF=1
MP1 SOB SO VDD VDD pmos_rvt L=20n NFIN=2 NF=1
MN0 SO SOB X VSS nmos_rvt L=20n NFIN=3 NF=2
MN1 SOB SO X VSS nmos_rvt L=20n NFIN=3 NF=2
MNT X SAE VSS VSS nmos_rvt L=20n NFIN=3 NF=2
MI0 SO SAE DL VDD pmos_rvt L=20n NFIN=2 NF=1
MI1 SOB SAE DLB VDD pmos_rvt L=20n NFIN=2 NF=1
MP2 OUT SO VDD VDD pmos_rvt L=20n NFIN=3 NF=1
MN2 OUT SO VSS VSS nmos_rvt L=20n NFIN=3 NF=1
.ENDS R14_SA
* ---- write driver (WEN active high, BWEN active-low bit mask folded into WEN) ----
.SUBCKT R14_WD DIN WEN DL DLB VDD VSS
MN0 DL  DINB N0 VSS nmos_rvt L=20n NFIN=3 NF=2
MN1 N0  WEN  VSS VSS nmos_rvt L=20n NFIN=3 NF=2
MN2 DLB DIN  N1 VSS nmos_rvt L=20n NFIN=3 NF=2
MN3 N1  WEN  VSS VSS nmos_rvt L=20n NFIN=3 NF=2
MP0 DINB DIN VDD VDD pmos_rvt L=20n NFIN=2 NF=1
MN4 DINB DIN VSS VSS nmos_rvt L=20n NFIN=2 NF=1
.ENDS R14_WD
* ---- wordline driver ----
.SUBCKT R14_WLDRV IN WL VDD VSS
MP0 WL IN VDD VDD pmos_lvt L=20n NFIN=3 NF=2
MN0 WL IN VSS VSS nmos_lvt L=20n NFIN=3 NF=2
.ENDS R14_WLDRV
"""

def spice(m):
    """hierarchical netlist; std-cell instances refer to r14n7_std_svt.cdl"""
    o = ["* " + BANNER, "* %s  (%s %dx%d mux%d)  include r14n7_std_svt.cdl for std-cell masters" % (m.name, m.kind, m.words, m.bits, m.mux), BLOCKS]
    ra = int(math.log2(m.rows)); ca = m.aw - ra
    if m.kind == "rom":
        for r in range(m.rows):
            ports = " ".join("BL<%d>" % c for c in range(m.cols))
            o.append(".SUBCKT %s_ROW%d %s WL VSS" % (m.name, r, ports))
            for c in range(m.cols):
                word = r * m.mux + (c % m.mux); bit = c // m.mux
                o.append("XB%d BL<%d> WL VSS R14_ROMBC_%d" % (c, c, (m.data[word] >> bit) & 1))
            o.append(".ENDS")
    else:
        ports = " ".join("BL<%d> BLB<%d>" % (c, c) for c in range(m.cols))
        o.append(".SUBCKT %s_ROW %s WL VDDM VSS" % (m.name, ports))
        for c in range(m.cols): o.append("XB%d BL<%d> BLB<%d> WL VDDM VSS R14_BC6T_HD" % (c, c, c))
        o.append(".ENDS")
    # top
    pins = []
    for n, d, w, r in m.pins(): pins += ["%s<%d>" % (n, b) for b in range(w)] if w > 1 else [n]
    o.append(".SUBCKT %s %s VDD VDDM VSS" % (m.name, " ".join(pins)))
    o.append("*.PININFO " + " ".join("%s:%s" % (p, "O" if p.startswith("Q") else "I") for p in pins) + " VDD:P VDDM:P VSS:G")
    ck = "CLKA" if m.kind == "rf" else "CLK"; ab = "AA" if m.kind == "rf" else "A"; ce = "CEBA" if m.kind == "rf" else "CEB"
    # input registers + self-timed clock pulse
    for b in range(m.aw): o.append("XAR%d %s<%d> %s ai<%d> VDD VSS DFF_X1_SVT" % (b, ab, b, ck, b))
    o.append("XCER %s %s cei VDD VSS DFF_X1_SVT" % (ce, ck))
    o.append("XCKD %s ckd VDD VSS DLY3_X1_SVT" % ck)
    o.append("XCKI ckd ckdb VDD VSS INV_X2_SVT")
    o.append("XPLS %s ckdb ceib clkp VDD VSS AND3_X4_SVT" % ck)
    o.append("XCEI cei ceib VDD VSS INV_X1_SVT")
    o.append("XPCH clkp pchb VDD VSS INV_X8_SVT" if False else "XPCHB clkp pchb VDD VSS INV_X16_SVT")
    o.append("XSAED clkp saed VDD VSS DLY2_X1_SVT"); o.append("XSAE saed sae VDD VSS BUF_X8_SVT")
    # address predecode
    for b in range(m.aw): o.append("XAI%d ai<%d> aib<%d> VDD VSS INV_X2_SVT" % (b, b, b))
    for r in range(m.rows):
        lits = ["ai<%d>" % (ca + k) if (r >> k) & 1 else "aib<%d>" % (ca + k) for k in range(ra)] + ["clkp"]
        # AND tree from NAND4/NOR2 style: group 4 literals
        groups = [lits[i:i + 3] for i in range(0, len(lits), 3)]
        gouts = []
        for gi, g in enumerate(groups):
            gn = "rd%d_%d" % (r, gi)
            cell = {1: "INV_X1_SVT", 2: "NAND2_X1_SVT", 3: "NAND3_X1_SVT"}[len(g)]
            o.append("XRD%d_%d %s %s VDD VSS %s" % (r, gi, " ".join(g), gn, cell)); gouts.append(gn)
        if len(gouts) == 1:
            o.append("XRW%d %s wlb%d VDD VSS INV_X1_SVT" % (r, gouts[0], r))
        else:
            o.append("XRW%d %s wlp%d VDD VSS %s" % (r, " ".join(gouts), r, "NOR%d_X2_SVT" % len(gouts) if len(gouts) <= 4 else "NOR4_X2_SVT"))
            o.append("XRWB%d wlp%d wlb%d VDD VSS INV_X2_SVT" % (r, r, r))
        o.append("XWL%d wlb%d WL<%d> VDD VSS R14_WLDRV" % (r, r, r))
    # array
    for r in range(m.rows):
        if m.kind == "rom":
            o.append("XROW%d %s WL<%d> VSS %s_ROW%d" % (r, " ".join("BL<%d>" % c for c in range(m.cols)), r, m.name, r))
        else:
            o.append("XROW%d %s WL<%d> VDDM VSS %s_ROW" % (r, " ".join("BL<%d> BLB<%d>" % (c, c) for c in range(m.cols)), r, m.name))
    # column periphery
    for c in range(m.cols):
        if m.kind == "rom":
            o.append("MPR%d BL<%d> pchb VDD VDD pmos_lvt L=20n NFIN=1 NF=1" % (c, c))
        else:
            o.append("XPC%d BL<%d> BLB<%d> pchb VDDM R14_PCH" % (c, c, c))
    for k in range(m.mux):
        lits = ["ai<%d>" % j if (k >> j) & 1 else "aib<%d>" % j for j in range(ca)]
        if ca == 0: o.append("XCS%d VDD cs<%d> VDD VSS BUF_X2_SVT" % (k, k))
        else: o.append("XCS%d %s cs<%d> VDD VSS %s" % (k, " ".join(lits), k, {1: "BUF_X2_SVT", 2: "AND2_X2_SVT", 3: "AND3_X2_SVT", 4: "AND4_X2_SVT"}[ca]))
        o.append("XCSB%d cs<%d> csb<%d> VDD VSS INV_X2_SVT" % (k, k, k))
    for b in range(m.bits):
        for k in range(m.mux):
            c = b * m.mux + k
            if m.kind == "rom":
                o.append("MCM%d BL<%d> cs<%d> dl<%d> VSS nmos_lvt L=20n NFIN=2 NF=1" % (c, c, k, b))
            else:
                o.append("XCM%d BL<%d> BLB<%d> dl<%d> dlb<%d> cs<%d> csb<%d> VDD VSS R14_CMUX" % (c, c, c, b, b, k, k))
        q = "QA" if m.kind == "rf" else "Q"
        if m.kind == "rom":
            # precharged BL: programmed cell (bit=0) discharges BL -> Q=0; unprogrammed (bit=1) keeps BL high -> Q=1
            o.append("XQL%d dl<%d> sae %s<%d> VDD VSS LATCHN_X2_SVT" % (b, b, q, b))
        else:
            o.append("XSA%d dl<%d> dlb<%d> sae so<%d> VDD VSS R14_SA" % (b, b, b, b))
            o.append("XQL%d so<%d> saed %s<%d> VDD VSS LATCHN_X2_SVT" % (b, b, q, b))
        if m.kind in ("sp", "rf"):
            ckw = "CLKB" if m.kind == "rf" else "CLK"
            o.append("XDR%d D<%d> %s di<%d> VDD VSS DFF_X1_SVT" % (b, b, ckw, b))
            o.append("XBR%d BWEB<%d> %s bwi<%d> VDD VSS DFF_X1_SVT" % (b, b, ckw, b))
            o.append("XWE%d bwi<%d> wrp web_i wen<%d> VDD VSS NOR3_X2_SVT" % (b, b, b))
            o.append("XWD%d di<%d> wen<%d> dl<%d> dlb<%d> VDD VSS R14_WD" % (b, b, b, b, b))
    if m.kind == "sp":
        o.append("XWER WEB CLK web_i VDD VSS DFF_X1_SVT"); o.append("XWRP clkp wrp VDD VSS INV_X4_SVT")
    elif m.kind == "rf":
        o.append("XWER CEBB CLKB web_i VDD VSS DFF_X1_SVT"); o.append("XWRP CLKB wrp VDD VSS INV_X4_SVT")
    o.append(".ENDS %s" % m.name)
    # ---- BIST input muxes: every functional input token is re-routed through MUX2(I0=func, I1=test, S=TEN)
    tw = m.bist_map(); toks = {}
    for n, d, w, r in m.fpins():
        if n in tw:
            for b in range(w):
                f = ("%s<%d>" % (n, b)) if w > 1 else n
                toks[f] = (("%s<%d>" % (tw[n], b)) if w > 1 else tw[n])
    top = next(i for i, x in enumerate(o) if x.startswith(".SUBCKT %s " % m.name))
    for i in range(top + 2, len(o)):
        if o[i].startswith(("X", "M")):
            o[i] = " ".join(("bm_" + t) if t in toks else t for t in o[i].split())
    o[top + 2:top + 2] = ["XBM_%s %s %s TEN bm_%s VDD VSS MUX2_X1_SVT" % (f.replace("<", "_").replace(">", ""), f, t, f) for f, t in toks.items()]
    return "\n".join(o) + "\n"
