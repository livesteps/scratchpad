"""Verilog functional/timing-shell models (UDP-based sequentials, specify blocks with
SDF-annotatable IOPATHs and timing checks).  `define R14_PG_PINS for power-aware ports."""
import boolexpr as bx
from tech import BANNER

UDP = r"""// R14N7 user-defined primitives
`timescale 1ps/1fs
// Positive-edge D flip-flop, active-low clear (dominant) and preset, notifier -> X
primitive r14_udp_ff (Q, D, CP, RN, SN, NOTI);
  output Q; reg Q;
  input D, CP, RN, SN, NOTI;
  table
  //  D   CP    RN  SN  NOTI : Q : Q+
      ?   ?     0   ?   ?    : ? : 0 ;
      ?   ?     1   0   ?    : ? : 1 ;
      0  (01)   1   1   ?    : ? : 0 ;
      1  (01)   1   1   ?    : ? : 1 ;
      0  (x1)   1   1   ?    : 0 : 0 ;
      1  (x1)   1   1   ?    : 1 : 1 ;
      0  (0x)   1   1   ?    : 0 : 0 ;
      1  (0x)   1   1   ?    : 1 : 1 ;
      ?  (?0)   1   1   ?    : ? : - ;
      ?  (1x)   1   1   ?    : ? : - ;
      *   ?     1   1   ?    : ? : - ;
      ?   ?    (?1) 1   ?    : ? : - ;
      ?   ?     1  (?1) ?    : ? : - ;
      ?   0     x   1   ?    : 0 : 0 ;
      ?   1     x   1   ?    : 0 : 0 ;
      ?   0     1   x   ?    : 1 : 1 ;
      ?   1     1   x   ?    : 1 : 1 ;
      ?   ?     ?   ?   *    : ? : x ;
  endtable
endprimitive

// High-transparent D latch, active-low clear (dominant) and preset
primitive r14_udp_latch (Q, D, E, RN, SN, NOTI);
  output Q; reg Q;
  input D, E, RN, SN, NOTI;
  table
  //  D  E  RN SN NOTI : Q : Q+
      ?  ?  0  ?  ?    : ? : 0 ;
      ?  ?  1  0  ?    : ? : 1 ;
      0  1  1  1  ?    : ? : 0 ;
      1  1  1  1  ?    : ? : 1 ;
      ?  0  1  1  ?    : ? : - ;
      0  x  1  1  ?    : 0 : 0 ;
      1  x  1  1  ?    : 1 : 1 ;
      ?  ?  ?  ?  *    : ? : x ;
  endtable
endprimitive
"""

def vexpr(f, rename=None):
    n = bx.parse(f)
    s = bx.to_verilog(n)
    return s

def ports_decl(c):
    pns = [p.name for p in c.pins]
    pg = [n for n, t, v in c.pg]
    return pns, pg

def header(c):
    pns, pg = ports_decl(c)
    L = ["`celldefine", "module %s (%s" % (c.name, ", ".join(pns))]
    if pg:
        L[-1] += ("\n`ifdef R14_PG_PINS\n  %s%s\n`endif\n  );" % (", " if pns else "", ", ".join(pg)))
    else:
        L[-1] += ");"
    for p in c.pins:
        rng = "[%d:0] " % (p.width - 1) if p.width > 1 else ""
        L.append("  %s %s%s;" % (p.dir, rng, p.name))
    if pg:
        L.append("`ifdef R14_PG_PINS"); L.append("  inout %s;" % ", ".join(pg)); L.append("`endif")
    return L

def spec_comb(c):
    S = []
    for a in c.arcs:
        if a.ttype == "combinational":
            S.append("    (%s => %s) = (0, 0);" % (a.frm, a.to))
    return S

def spec_seq(c, edge="posedge"):
    S = []
    for a in c.arcs:
        if a.ttype in ("rising_edge", "falling_edge"):
            e = "posedge" if a.ttype == "rising_edge" else "negedge"
            S.append("    (%s *> %s) = (0, 0);" % (a.frm, a.to) if c.bits() > 1 else
                     "    (%s %s => (%s +: %s)) = (0, 0);" % (e, a.frm, a.to, next((x for x in ("D", "A", "PI", "CFI") if x in [p.name for p in c.pins]), a.frm)))
        elif a.ttype in ("clear", "preset"):
            S.append("    (%s *> %s) = (0, 0);" % (a.frm, a.to) if c.bits() > 1 else "    (%s => %s) = (0, 0);" % (a.frm, a.to))
        elif a.ttype == "combinational":
            S.append("    (%s => %s) = (0, 0);" % (a.frm, a.to))
    for k in c.cons:
        rel_e = "posedge" if k.kind.endswith("rising") else "negedge"
        cond = ""
        if k.when:
            cond = " &&& (%s == 1'b%d)" % (k.when.lstrip("!"), 0 if k.when.startswith("!") else 1)
        kt = k.kind.split("_")[0]
        if kt == "setup":
            pins = [k.pin] if c.pin(k.pin).width == 1 else ["%s[%d]" % (k.pin, b) for b in range(c.pin(k.pin).width)]
            for pn in pins:
                S.append("    $setuphold(%s %s%s, %s, 0, 0, notifier);" % (rel_e, k.rel, cond, pn))
        elif kt == "recovery":
            S.append("    $recrem(posedge %s, %s %s, 0, 0, notifier);" % (k.pin, rel_e, k.rel))
    for pn, (hi, lo) in c.mpw.items():
        if hi: S.append("    $width(posedge %s, 0, 0, notifier);" % pn)
        if lo: S.append("    $width(negedge %s, 0, 0, notifier);" % pn)
    return S

def model(c):
    L = header(c)
    names = [p.name for p in c.pins]
    sq = c.seq or {}
    body = []; spec = []
    vk = c.vkind
    if vk == "comb":
        for o, f in c.funcs.items():
            body.append("  assign %s = %s;" % (o, vexpr(f)))
        spec = spec_comb(c)
    elif vk in ("phys",):
        pass
    elif vk == "antenna":
        pass
    elif vk in ("ff", "ret"):
        body.append("  reg notifier;")
        din = "D" if "D" in names else "A"
        if "E" in names and c.family != "pmk_ret":
            body.append("  wire d_en = E ? D : IQ;"); din = "d_en"
        if "SYNR" in c.base:
            body.append("  wire d_sr = %s & RN;" % din); din = "d_sr"
        if "SI" in names:
            body.append("  wire d_sc = SE ? SI : %s;" % din); din = "d_sc"
        ck = "CK"
        if sq.get("clocked_on", "CK").startswith("!"):
            body.append("  wire ck_i = ~CK;"); ck = "ck_i"
        if vk == "ret":
            body.append("  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)"); ck = "ck_i"
        rn = "RN" if ("clear" in sq) else "1'b1"
        sn = "SN" if ("preset" in sq) else "1'b1"
        body.append("  wire IQ;")
        body.append("  r14_udp_ff u_ff (IQ, %s, %s, %s, %s, notifier);" % (din, ck, rn, sn))
        qn_ = [o for o, f in c.funcs.items() if f == "IQ"][0]
        if vk == "ret":
            body.append("`ifdef R14_PG_PINS")
            body.append("  assign %s = (VDD === 1'b1) ? IQ : 1'bx;" % qn_)
            body.append("`else"); body.append("  buf (%s, IQ);" % qn_); body.append("`endif")
        else:
            body.append("  buf (%s, IQ);" % qn_)
        for o, f in c.funcs.items():
            if f == "IQN": body.append("  not (%s, IQ);" % o)
        spec = spec_seq(c)
    elif vk == "latch":
        body.append("  reg notifier; wire IQ;")
        e = vexpr(sq["enable"])
        body.append("  r14_udp_latch u_l (IQ, D, %s, %s, %s, notifier);" % (e, "RN" if "RN" in names else "1'b1", "SN" if "SN" in names else "1'b1"))
        body.append("  buf (Q, IQ);")
        spec = spec_seq(c)
    elif vk == "tpctl":
        body += ["  reg notifier; wire IQ;", "  wire ds = SE ? SI : IQ;", "  r14_udp_ff u_ff (IQ, ds, CK, 1'b1, 1'b1, notifier);",
                 "  buf (SO, IQ);", "  assign Y = %s;" % vexpr(c.funcs["Y"])]
        spec = spec_seq(c)
    elif vk == "bsc":
        PI, SI, SH, CAP, UPD, CK, MODE, PO, SO = c.vextra["names"]
        body += ["  reg notifier; wire IQ1, IQ2;",
                 "  wire d1 = %s ? %s : %s;" % (SH, SI, ("(%s ? %s : IQ1)" % (CAP, PI)) if CAP else PI),
                 "  r14_udp_ff u_sc (IQ1, d1, %s, 1'b1, 1'b1, notifier);   // shift/capture stage" % CK,
                 "  r14_udp_ff u_up (IQ2, IQ1, %s, 1'b1, 1'b1, notifier);  // update stage" % UPD,
                 "  buf (%s, IQ1);" % SO, "  assign %s = %s ? IQ2 : %s;" % (PO, MODE, PI)]
        spec = spec_seq(c)
    elif vk == "isolat":
        body.append("  reg notifier; wire IQ;")
        body.append("  r14_udp_latch u_l (IQ, A, ~ISO, 1'b1, 1'b1, notifier);")
        body.append("  buf (Y, IQ);")
        spec = ["    (A => Y) = (0, 0);", "    (ISO => Y) = (0, 0);"]
    elif vk == "icg":
        body.append("  reg notifier; wire IQ;")
        ld = "(E | SE)" if sq["pre"] else "E"
        le = "CK" if sq["neg"] else "~CK"
        body.append("  r14_udp_latch u_l (IQ, %s, %s, 1'b1, 1'b1, notifier);" % (ld, le))
        g = "IQ" if sq["pre"] else "(IQ | SE)"
        body.append("  assign GCK = %s;" % ("CK | ~%s" % g if sq["neg"] else "CK & %s" % g))
        if sq["obs"]: body.append("  buf (Q, IQ);")
        spec = ["    (CK => GCK) = (0, 0);"]
        if sq["obs"]: spec.append("    (%s CK => (Q +: E)) = (0, 0);" % ("posedge" if sq["neg"] else "negedge"))
        e2 = "negedge" if sq["neg"] else "posedge"
        spec += ["    $setuphold(%s CK, E, 0, 0, notifier);" % e2, "    $setuphold(%s CK, SE, 0, 0, notifier);" % e2,
                 "    $width(posedge CK, 0, 0, notifier);", "    $width(negedge CK, 0, 0, notifier);"]
    elif vk == "mbff":
        n = c.bits()
        body.append("  reg notifier;")
        body.append("  wire [%d:0] IQ, din;" % (n - 1))
        body.append("  genvar i;")
        body.append("  generate for (i = 0; i < %d; i = i + 1) begin : g_bit" % n)
        dn = "(SE ? SI[i] : D[i])" if "SI" in names else "D[i]"
        body.append("    assign din[i] = %s;" % dn)
        body.append("    r14_udp_ff u_ff (IQ[i], din[i], CK, %s, 1'b1, notifier);" % ("RN" if "RN" in names else "1'b1"))
        body.append("  end endgenerate")
        body.append("  assign Q = IQ;")
        spec = spec_seq(c)
    elif vk in ("hdr", "ftr", "hdr2", "ftr2"):
        for o, f in c.funcs.items(): body.append("  assign %s = %s;" % (o, vexpr(f)))
        body.append("`ifdef R14_PG_PINS")
        if vk == "hdr": body.append("  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;")
        if vk == "hdr2": body.append("  assign VVDD = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VDD : 1'bz;")
        if vk == "ftr": body.append("  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;")
        if vk == "ftr2": body.append("  assign VVSS = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VSS : 1'bz;")
        body.append("`endif")
        spec = spec_comb(c)
    if spec:
        body.append("  specify"); body += spec; body.append("  endspecify")
    L += body
    L.append("endmodule"); L.append("`endcelldefine"); L.append("")
    return "\n".join(L)

def write(path, cells, what):
    with open(path, "w") as f:
        f.write("// %s\n// %s\n`timescale 1ps/1fs\n\n" % (BANNER, what))
        for c in cells:
            f.write(model(c) + "\n")

def write_udp(path):
    open(path, "w").write("// " + BANNER + "\n" + UDP)


# ------------------------------------------------------------------ V2LVS interface stubs
def v2lvs_stub(name, pins, pg):
    """port-only module (pins in CDL .SUBCKT order, PG pins as inout) for Calibre v2lvs -l"""
    ports = []; decl = []
    for (n, d, w) in pins:
        ports.append(n)
        decl.append("  %s %s%s;" % (d, ("[%d:0] " % (w - 1)) if w > 1 else "", n))
    ports += pg
    if pg: decl.append("  inout %s;" % ", ".join(pg))
    return "module %s (%s);\n%s\nendmodule\n" % (name, ", ".join(ports), "\n".join(decl))

def write_v2lvs(path, cells):
    with open(path, "w") as f:
        f.write("// %s\n// Calibre v2lvs interface library: port order == CDL .SUBCKT order (buses expand to <i>),\n"
                "// power/ground pins explicit.  Use with:  v2lvs -v top.v -l <this> -lsp <cells>.cdl -o top.sp\n\n" % BANNER)
        for c in cells:
            f.write(v2lvs_stub(c.name, [(p.name, p.dir, p.width) for p in c.pins], [n for n, t, vv in c.pg]))
