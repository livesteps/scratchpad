"""Analytic FinFET electrical model used to characterize every cell at every corner.
alpha-power drive law with temperature-dependent Vt and mobility (reproduces FinFET
temperature inversion at low VDD), subthreshold leakage with DIBL, Pelgrom-style
local variation for LVF/POCV/AOCV.  Calibrated to ASAP7-class magnitudes
(INV_X1_SVT FO4 ~ 10-12 ps @ TT 0.70 V 25C)."""
import math
from functools import lru_cache
from tech import VT_FLAVORS, PROC_SHIFT, NOMINAL, CORNER_BY_NAME
from netlist import R_N1, R_P1

ALPHA = 1.30
KVT = -0.0010      # V/K  (drive)
KVT_LEAK = -0.0005 # V/K  (effective, subthreshold)
MU_EXP = -0.80     # effective (velocity-saturated) mobility temperature exponent
N_SS = 1.25        # subthreshold slope factor
DIBL = 0.08        # V/V
ILEAK0 = 0.30      # nA per fin, SVT, TT, 0.70 V, 25C
IGATE0 = 0.02      # nA per fin gate leakage @0.7V
SIGMA0 = 0.030     # sigma/mu of an X1 (3-fin) single stage @ TT SVT

def _vt(corner, vt, t):
    f = VT_FLAVORS[vt]; v0 = f["vtn"] if t == "n" else f["vtp"]
    pr = corner.nproc if t == "n" else corner.pproc
    return v0 + PROC_SHIFT[pr][0] + KVT * (corner.temp - 25.0)

def _ion(corner, vt, t, vdd=None):
    vdd = corner.vdd if vdd is None else vdd
    f = VT_FLAVORS[vt]; pr = corner.nproc if t == "n" else corner.pproc
    mu = ((corner.temp + 273.15) / 298.15) ** MU_EXP * PROC_SHIFT[pr][1] * f["u"]
    return mu * max(vdd - _vt(corner, vt, t), 0.035) ** ALPHA

@lru_cache(maxsize=None)
def rscale(cname, vt, t, vdd=None):
    c = CORNER_BY_NAME[cname]; v = c.vdd if vdd is None else vdd
    return (v / _ion(c, vt, t, v)) / (NOMINAL.vdd / _ion(NOMINAL, "SVT", t))

@lru_cache(maxsize=None)
def leak_fin(cname, vt, t, vdd=None):
    """nA per fin off-current (+gate leak)"""
    c = CORNER_BY_NAME[cname]; v = c.vdd if vdd is None else vdd
    T = c.temp + 273.15; vth = 8.617e-5 * T
    vte = _vt(c, vt, t) + (KVT_LEAK - KVT) * (c.temp - 25.0) - DIBL * (v - 0.70)
    T0 = 298.15; vth0 = 8.617e-5 * T0
    ref = VT_FLAVORS["SVT"]["vtn" if t == "n" else "vtp"]
    sub = ILEAK0 * (T / T0) ** 2 * math.exp(-(vte - ref) / (N_SS * vth)) * \
          math.exp(-ref / (N_SS * vth) + ref / (N_SS * vth0)) * (1 - math.exp(-v / vth))
    return sub + IGATE0 * (v / 0.70) ** 3

@lru_cache(maxsize=None)
def sigma_rel(cname, vt, fins=3, stages=1.0):
    c = CORNER_BY_NAME[cname]
    vte = 0.5 * (_vt(c, vt, "n") + _vt(c, vt, "p"))
    od_nom = 0.70 - VT_FLAVORS["SVT"]["vtn"]
    od = max(c.vdd - vte, 0.06)
    r = SIGMA0 * math.sqrt(3.0 / max(fins, 1)) * (od_nom / od) ** 1.1 / math.sqrt(max(stages, 1.0))
    return min(r, 0.35)

def cap_scale(cname):
    c = CORNER_BY_NAME[cname]
    return 1.0 + 0.10 * (c.vdd - 0.70) / 0.70 + 0.0002 * (c.temp - 25)

# ---------------------------------------------------------------- table indices
SLEWS = [5.0, 10.0, 20.0, 40.0, 80.0, 160.0, 320.0]
from tech import FINS_PER_DEV as _FPD
LOAD_X1 = [round(x * _FPD / 3.0, 4) for x in (0.36, 0.72, 1.44, 2.88, 5.76, 11.52, 23.04)]
CSLEWS = [5.0, 15.0, 45.0, 135.0, 320.0]
from tech import FINS_PER_DEV
def loads_for(drive):
    m = max(drive, 0.5)
    return [round(l * m, 4) for l in LOAD_X1]

class OutStage:
    """electrical view of the stage that drives an output pin"""
    def __init__(self, rn, rp, cpar, fins, nstages):
        self.rn, self.rp, self.cpar, self.fins, self.nstages = rn, rp, cpar, fins, nstages

def delay_tables(cname, vt, st, d0, slew_k, seq=False, vdd_override=None, vt_out=None):
    """returns dict with cell_rise, cell_fall, rise_tr, fall_tr (7x7 lists), sigmas"""
    vo = vt_out or vt
    sr = rscale(cname, vo, "p", vdd_override); sf = rscale(cname, vo, "n", vdd_override)
    sm = 0.5 * (rscale(cname, vt, "p") + rscale(cname, vt, "n"))
    cs = cap_scale(cname)
    loads = st.loads
    T = {"cell_rise": [], "cell_fall": [], "rise_transition": [], "fall_transition": []}
    for s in SLEWS:
        r1, r2, r3, r4 = [], [], [], []
        for C in loads:
            Ct = C + st.cpar * cs
            nl = 1.0 + 0.0015 * s           # slew-load interaction
            kin = slew_k
            dr = d0 * sm + 0.69 * st.rp * sr * Ct * nl + kin * s + 0.4 * sm
            df = d0 * sm + 0.69 * st.rn * sf * Ct * nl + kin * s * 0.92 + 0.4 * sm
            pt = 0.10 if d0 > 0.5 else 0.22  # input-slew feed-through to output slew
            tr = 1.75 * st.rp * sr * Ct + pt * s + 1.2 * sm
            tf = 1.65 * st.rn * sf * Ct + pt * s * 0.95 + 1.1 * sm
            r1.append(dr); r2.append(df); r3.append(tr); r4.append(tf)
        T["cell_rise"].append(r1); T["cell_fall"].append(r2)
        T["rise_transition"].append(r3); T["fall_transition"].append(r4)
    sg = sigma_rel(cname, vt, st.fins, st.nstages)
    T["sig"] = sg
    return T

def constraint_table(cname, vt, base, kind, rise=True):
    sm = 0.5 * (rscale(cname, vt, "p") + rscale(cname, vt, "n"))
    out = []
    for rs in CSLEWS:          # related (clock) transition
        row = []
        for cs in CSLEWS:      # constrained pin transition
            if kind.startswith("setup") or kind.startswith("recovery"):
                v = base * sm + 0.22 * cs - 0.10 * rs + (1.0 if rise else 0.0)
            else:
                v = base * sm - 0.15 * cs + 0.12 * rs + (0.0 if rise else 0.6)
            row.append(v)
        out.append(row)
    return out

def energy_table(cname, st, cint, loads, vdd=None):
    """internal energy (fJ) per output transition, excludes load charge"""
    from tech import CORNER_BY_NAME as CB
    v = CB[cname].vdd if vdd is None else vdd
    out = []
    for s in SLEWS:
        row = []
        for C in loads:
            e = v * v * (0.5 * st.cpar + cint) + 0.0016 * s * v * v * st.fins / 3.0 + 0.002 * C * v * v
            row.append(e)
        out.append(row)
    return out

# ----------------------------------------------------------------- waveforms
CCS_SI = [0, 2, 4, 6]            # sub-grid of the 7x7 used for CCS / ECSM
CCS_LI = [0, 2, 4, 6]
CCS_NPT = 12
ECSM_V = [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95]
ATANH08 = math.atanh(0.8)

def ccs_vector(slew, delay, trans, C, vdd, rise):
    """output current vector (mA vs ps) for a tanh-shaped output transition"""
    ref = 0.625 * slew                    # input 50% crossing on a 10-90 ramp
    t50 = ref + delay
    w = max(trans, 0.2) / (2 * ATANH08)
    ts = [t50 + w * (-2.6 + 5.2 * k / (CCS_NPT - 1)) for k in range(CCS_NPT)]
    ts = [max(t, 0.0) for t in ts]
    amp = C * vdd / (2.0 * w)             # fF*V/ps = mA
    vals = [(-1 if rise else 1) * amp / math.cosh((t - t50) / w) ** 2 for t in ts]
    return ref, ts, vals

def ecsm_times(slew, delay, trans):
    w = max(trans, 0.2) / (2 * ATANH08)
    return [delay + w * math.atanh(2 * v - 1) for v in ECSM_V]
