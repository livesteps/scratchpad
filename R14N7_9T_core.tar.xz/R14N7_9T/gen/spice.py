"""SPICE / CDL netlists and the BSIM-CMG model library (r14n7.l)."""
import os, re
from tech import VT_FLAVORS, BANNER

ASAP = os.path.join(os.path.dirname(__file__), "asap7_models")
CORNER_FILES = {"TT": "7nm_TT_160803.pm", "SS": "7nm_SS_160803.pm", "FF": "7nm_FF_160803.pm"}

def _blocks(path):
    txt = open(path).read().splitlines()
    out = {}; cur = None
    for ln in txt:
        m = re.match(r"\.model\s+(\S+)\s+(nmos|pmos)", ln)
        if m:
            cur = m.group(1); out[cur] = [ln]; continue
        if cur and (ln.startswith("+") or ln.startswith("*")):
            out[cur].append(ln)
        elif cur and ln.strip() == "":
            continue
        else:
            cur = None
    return out

def _set(block, name, val):
    pat = re.compile(r"(\b%s\s*=\s*)([-+0-9.eE]+)" % name)
    done = False; out = []
    for ln in block:
        if not done and pat.search(ln):
            ln = pat.sub(lambda m: m.group(1) + val, ln, count=1); done = True
        out.append(ln)
    return out

def _get(block, name):
    for ln in block:
        m = re.search(r"\b%s\s*=\s*([-+0-9.eE]+)" % name, ln)
        if m: return float(m.group(1))
    return None

def _rename(block, new):
    b = list(block); b[0] = re.sub(r"\.model\s+\S+", ".model " + new, b[0]); return b

def corner_models(cor):
    """cor in TT SS FF SF FS -> list of lines"""
    nsrc = {"TT": "TT", "SS": "SS", "FF": "FF", "SF": "SS", "FS": "FF"}[cor]
    psrc = {"TT": "TT", "SS": "SS", "FF": "FF", "SF": "FF", "FS": "SS"}[cor]
    nb = _blocks(os.path.join(ASAP, CORNER_FILES[nsrc]))
    pb = _blocks(os.path.join(ASAP, CORNER_FILES[psrc]))
    L = []
    for nm in ("nmos_slvt", "nmos_lvt", "nmos_rvt", "nmos_sram"):
        L += nb[nm] + [""]
    for nm in ("pmos_slvt", "pmos_lvt", "pmos_rvt", "pmos_sram"):
        L += pb[nm] + [""]
    # synthetic HVT: workfunction shifted one more Vt step beyond RVT (ASAP7 step ~60 mV)
    h = _rename(nb["nmos_rvt"], "nmos_hvt"); h = _set(h, "phig", "%.4f" % (_get(nb["nmos_rvt"], "phig") + 0.062))
    h = _set(h, "u0", "%.4g" % (_get(nb["nmos_rvt"], "u0") * 0.93))
    L += ["* R14N7 synthetic HVT (derived from ASAP7 RVT: PHIG +62 meV, U0 x0.93)"] + h + [""]
    h = _rename(pb["pmos_rvt"], "pmos_hvt"); h = _set(h, "phig", "%.4f" % (_get(pb["pmos_rvt"], "phig") - 0.058))
    h = _set(h, "u0", "%.4g" % (_get(pb["pmos_rvt"], "u0") * 0.93))
    L += h + [""]
    # synthetic thick-oxide 1.8 V IO devices
    for t, src in (("n", nb["nmos_rvt"]), ("p", pb["pmos_rvt"])):
        b = _rename(src, "%smos_io" % t)
        b = _set(b, "eot", "3.2e-009"); b = _set(b, "toxp", "4.0e-009")
        ph = _get(src, "phig"); b = _set(b, "phig", "%.4f" % (ph + (0.11 if t == "n" else -0.11)))
        L += ["* R14N7 synthetic 1.8V thick-oxide IO device (EOT 3.2nm, Lmin 150nm)"] + b + [""]
    L += ["* ESD / antenna junction diodes (synthetic)",
          ".model dio_n d (is=2e-7 n=1.05 rs=40 cjo=1e-3 vj=0.8 m=0.4 bv=6 ibv=1e-6)",
          ".model dio_p d (is=2e-7 n=1.05 rs=45 cjo=1e-3 vj=0.8 m=0.4 bv=6 ibv=1e-6)",
          ".model dio_esd_n d (is=5e-6 n=1.03 rs=0.8 cjo=1e-2 vj=0.8 m=0.4 bv=7.5 ibv=1e-6)",
          ".model dio_esd_p d (is=5e-6 n=1.03 rs=0.9 cjo=1e-2 vj=0.8 m=0.4 bv=7.5 ibv=1e-6)", ""]
    return L

def write_model_lib(path):
    L = ["* " + BANNER,
         "* R14N7 BSIM-CMG (level=72, v107) model library.",
         "* Base cards: ASAP7 predictive PDK (c) 2020 L.T. Clark, V. Vashishtha, Arizona State Univ.,",
         "* BSD 3-Clause license (see LICENSE.ASAP7).  HVT/IO/diode cards are R14N7 synthetic derivatives.",
         "* Usage:  .lib 'r14n7.l' TT    (sections: TT SS FF SF FS)", ""]
    for cor in ("TT", "SS", "FF", "SF", "FS"):
        L += [".lib %s" % cor, "* ---- corner %s ----" % cor] + corner_models(cor) + [".endl %s" % cor, ""]
    open(path, "w").write("\n".join(L) + "\n")

def model_of(d):
    if d.kind == "io":
        return "nmos_io" if d.t == "n" else "pmos_io"
    if d.vt == "SRAM":
        return "nmos_sram" if d.t == "n" else "pmos_sram"
    f = VT_FLAVORS[d.vt]
    return f["nmodel"] if d.t == "n" else f["pmodel"]

def port_list(c):
    ps = []
    for p in c.pins:
        if p.width > 1: ps += ["%s<%d>" % (p.name, b) for b in range(p.width)]
        else: ps.append(p.name)
    return ps + [n for n, t, v in c.pg]

def subckt(c, cdl=False):
    ps = port_list(c)
    L = [".SUBCKT %s %s" % (c.name, " ".join(ps))]
    if cdl:
        info = []
        for p in c.pins:
            dch = {"input": "I", "output": "O", "inout": "B"}[p.dir]
            names = ["%s<%d>" % (p.name, b) for b in range(p.width)] if p.width > 1 else [p.name]
            info += ["%s:%s" % (n, dch) for n in names]
        info += ["%s:%s" % (n, "P" if "power" in t else "G") for n, t, v in c.pg]
        L.append("*.PININFO " + " ".join(info))
    L.append("* %s | %s | area %.5f um2 | %d site(s) x %d row(s)" % (c.desc, c.family, c.area, c.sites, c.rows))
    L += c.nb.spice_lines(model_of)
    L.append(".ENDS %s" % c.name); L.append("")
    return L

def write_netlists(path, cells, what, cdl=False):
    L = ["* " + BANNER, "* %s" % what,
         "* Device instance syntax: M<n> d g s b <model> L=<Lg> NFIN=<fins/finger> NF=<fingers>", ""]
    if cdl: L.insert(2, "*.BUSDELIMITER <\n*.SCALE METER\n*.EQUATION")
    for c in cells:
        L += subckt(c, cdl)
    open(path, "w").write("\n".join(L) + "\n")
