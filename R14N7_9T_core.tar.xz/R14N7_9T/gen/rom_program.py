#!/usr/bin/env python3
"""R14N7 mask-ROM programmer: builds a PRE-PROGRAMMED, code-specific ROM macro from a boot image.

  rom_program.py -i boot.hex -c 1024x32m8 [-f auto|ihex|srec|bin|readmemh] [-n BOOTROM] [--fill 00]
                 [--corners all|c1,c2] [--models nldm,ccs,ecsm] -o out_dir

Byte images (Intel HEX, S-record, binary) are packed little-endian into ROM words (bits/8 bytes per word);
readmemh files hold one word per line (optional @addr).  Every view is regenerated from the image:
GDS (V0/ROMPGM code layer per bit), code-layer-only GDS (mask shop), CDL, Verilog (image embedded),
Liberty (all corners), LEF, ATPG model, golden MISR signature, ROM-BIST testbenches.  Self-checks
(read-back, GDS/CDL code-bit counts, BIST pass + fault detection) run when iverilog is installed."""
import argparse, os, sys, re, zlib, json, subprocess, shutil, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import memory, dft, tech
from tech import CORNERS, CORNER_BY_NAME

# ------------------------------------------------------------------ image readers
def read_ihex(path):
    mem = {}; base = 0
    for ln, line in enumerate(open(path), 1):
        line = line.strip()
        if not line: continue
        if not line.startswith(":"): raise ValueError("%s:%d not an Intel HEX record" % (path, ln))
        raw = bytes.fromhex(line[1:])
        n, addr, typ, data = raw[0], (raw[1] << 8) | raw[2], raw[3], raw[4:4 + raw[0]]
        if (sum(raw) & 0xFF) != 0: raise ValueError("%s:%d checksum error" % (path, ln))
        if typ == 0:
            for i, b in enumerate(data): mem[base + addr + i] = b
        elif typ == 1: break
        elif typ == 2: base = ((data[0] << 8) | data[1]) << 4
        elif typ == 4: base = ((data[0] << 8) | data[1]) << 16
        elif typ in (3, 5): pass
    return mem

def read_srec(path):
    mem = {}
    for ln, line in enumerate(open(path), 1):
        line = line.strip()
        if not line or not line.startswith("S"): continue
        t = line[1]; raw = bytes.fromhex(line[2:])
        if (sum(raw) & 0xFF) != 0xFF: raise ValueError("%s:%d checksum error" % (path, ln))
        al = {"1": 2, "2": 3, "3": 4}.get(t)
        if al is None: continue
        addr = int.from_bytes(raw[1:1 + al], "big")
        for i, b in enumerate(raw[1 + al:-1]): mem[addr + i] = b
    return mem

def read_bin(path):
    return {i: b for i, b in enumerate(open(path, "rb").read())}

def read_readmemh(path, bits):
    words = {}; a = 0
    for line in open(path):
        line = re.sub(r"//.*", "", line).strip()
        for tok in line.split():
            if tok.startswith("@"): a = int(tok[1:], 16); continue
            words[a] = int(tok.replace("_", ""), 16); a += 1
    return words

def to_words(path, fmt, words, bits, fill):
    if fmt == "auto":
        head = open(path, "rb").read(64)
        fmt = "ihex" if head.startswith(b":") else "srec" if head.startswith(b"S0") or head.startswith(b"S1") else \
              "bin" if path.endswith(".bin") else "readmemh"
    nb = bits // 8
    fillw = int(fill, 16) & ((1 << bits) - 1) if len(fill) * 4 >= bits else int(fill * nb, 16)
    if fmt == "readmemh":
        w = read_readmemh(path, bits)
        if w and max(w) >= words: raise SystemExit("image word address 0x%X exceeds ROM depth %d" % (max(w), words))
        if any(v >> bits for v in w.values()): raise SystemExit("image word wider than %d bits" % bits)
        return [w.get(i, fillw) for i in range(words)], fmt, len(w) * nb
    mem = {"ihex": read_ihex, "srec": read_srec, "bin": read_bin}[fmt](path)
    if mem and max(mem) >= words * nb:
        raise SystemExit("image byte address 0x%X exceeds ROM size %d bytes (%dx%d)" % (max(mem), words * nb, words, bits))
    fb = fillw & 0xFF
    out = [int.from_bytes(bytes(mem.get(i * nb + k, fb) for k in range(nb)), "little") for i in range(words)]
    return out, fmt, len(mem)

# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-i", "--image", required=True); ap.add_argument("-c", "--config", required=True, help="WORDSxBITSmMUX, e.g. 1024x32m8")
    ap.add_argument("-f", "--format", default="auto", choices=["auto", "ihex", "srec", "bin", "readmemh"])
    ap.add_argument("-n", "--name", default="CODE"); ap.add_argument("--fill", default="00")
    ap.add_argument("--corners", default="all"); ap.add_argument("--models", default="nldm,ccs,ecsm")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    m_ = re.match(r"(\d+)x(\d+)m(\d+)$", a.config)
    if not m_: raise SystemExit("bad --config")
    words, bits, mux = map(int, m_.groups())
    if bits % 8 or words & (words - 1) or mux not in (1, 2, 4, 8, 16) or words // mux < 4:
        raise SystemExit("unsupported ROM configuration %s" % a.config)
    data, fmt, nbytes = to_words(a.image, a.format, words, bits, a.fill)
    crc = zlib.crc32(b"".join(v.to_bytes(bits // 8, "little") for v in data)) & 0xFFFFFFFF
    code = "%s_%08X" % (re.sub(r"[^A-Za-z0-9]", "", a.name).upper(), crc)
    m = memory.Mem("rom", words, bits, mux, data=data, code=code)
    out = os.path.abspath(a.out); os.makedirs(out, exist_ok=True)
    P = lambda *p: os.path.join(out, *p)
    for d in ("verilog", "lef", "gds", "spice", "atpg", "bist", "liberty"): os.makedirs(P(d), exist_ok=True)
    # Verilog with embedded image (no external file needed) + hex
    v = memory.verilog(m)
    init = ["  initial begin"] + ["    mem[%d] = %d'h%0*X;" % (i, bits, bits // 4, w) for i, w in enumerate(data)] + ["  end"]
    v = v.replace('  initial $readmemh("%s.hex", mem);' % m.name, "\n".join(init))
    open(P("verilog", m.name + ".v"), "w").write(v)
    open(P(m.name + ".hex"), "w").write(memory.hexfile(m))
    memory.write_lef(P("lef", m.name + ".lef"), [m])
    memory.build_gds(P("gds", m.name + ".gds"), [m])
    memory.code_layer_gds(P("gds", m.name + "_CODE.gds"), m)
    open(P("spice", m.name + ".cdl"), "w").write(memory.spice(m))
    open(P("atpg", m.name + ".atpglib"), "w").write(dft.mem_atpg(m))
    cns = [c.name for c in CORNERS] if a.corners == "all" else a.corners.split(",")
    for cn in cns:
        for md in a.models.split(","):
            memory.write_lib(P("liberty", "%s_%s_%s.lib" % (m.name, cn, md)), [m], CORNER_BY_NAME[cn], md)
    sig = dft.misr(m.data, bits) if bits in dft.POLY else None
    for fl in (0, 1):
        if sig is not None: open(P("bist", "tb_rombist_%s%s.v" % (m.name, "_fault" if fl else "")), "w").write(dft.tb_rom(m, fl))
    open(P("bist", "r14n7_mbist.v"), "w").write(dft.MBIST)
    # ---------------- self checks
    rep = {"macro": m.name, "config": a.config, "image": os.path.abspath(a.image), "format": fmt, "image_bytes": nbytes,
           "rom_bytes": words * bits // 8, "fill": a.fill, "crc32": "%08X" % crc, "misr_signature": ("%0*X" % (bits // 4, sig)) if sig is not None else None,
           "width_um": m.w / 1000.0, "height_um": m.h / 1000.0, "area_um2": round(m.area, 3), "variant": tech.VARIANT, "checks": {}}
    zeros = sum(bits - bin(w).count("1") for w in data)
    import gdstk
    code_lib = gdstk.read_gds(P("gds", m.name + "_CODE.gds"))
    pg = tech.L("ROMPGM")
    ngds = sum(len(c.get_polygons(layer=pg[0], datatype=pg[1], depth=0)) for c in code_lib.cells)
    full = gdstk.read_gds(P("gds", m.name + ".gds"))
    arr = next(c for c in full.cells if c.name == m.name + "_ARRAY")
    nref0 = sum(1 for r in arr.references if r.cell.name == "R14_ROMBC_0")
    ncdl = sum(1 for ln in open(P("spice", m.name + ".cdl")) if ln.startswith("XB") and ln.rstrip().endswith("R14_ROMBC_0"))
    rep["checks"]["programmed_bits_expected"] = zeros
    rep["checks"]["gds_code_layer_shapes"] = ngds
    rep["checks"]["gds_programmed_cells"] = nref0
    rep["checks"]["cdl_programmed_cells"] = ncdl
    ok = (zeros == ngds == nref0 == ncdl)
    if shutil.which("iverilog") and sig is not None:
        tmp = tempfile.mkdtemp()
        tb = ["`timescale 1ps/1fs", "module tb_readback;", "  reg clk = 0; always #500 clk = ~clk;", "  reg [%d:0] a = 0; wire [%d:0] q; integer i, err = 0;" % (m.aw - 1, bits - 1),
              "  reg [%d:0] exp [0:%d];" % (bits - 1, words - 1), '  initial $readmemh("%s", exp);' % P(m.name + ".hex"),
              "  %s u (.CLK(clk), .CEB(1'b0), .A(a), .Q(q), .TEN(1'b0), .TCEB(1'b1), .TA({%d{1'b0}}));" % (m.name, m.aw),
              "  initial begin for (i = 0; i < %d; i = i + 1) begin a = i; @(posedge clk); #10 if (q !== exp[i]) err = err + 1; end" % words,
              '    $display("READBACK words=%0d errors=%0d", ' + str(words) + ', err); $finish; end', "endmodule"]
        open(os.path.join(tmp, "tb.v"), "w").write("\n".join(tb) + "\n")
        r = subprocess.run("iverilog -g2005 -o %s/a.out %s %s/tb.v && vvp -n %s/a.out" % (tmp, P("verilog", m.name + ".v"), tmp, tmp),
                           shell=True, capture_output=True, text=True)
        mm = re.search(r"READBACK words=(\d+) errors=(\d+)", r.stdout)
        rep["checks"]["verilog_readback_errors"] = int(mm.group(2)) if mm else "sim-failed"
        ok = ok and mm is not None and mm.group(2) == "0"
        for fl in (0, 1):
            tbf = P("bist", "tb_rombist_%s%s.v" % (m.name, "_fault" if fl else ""))
            r = subprocess.run("cd %s && iverilog -g2005 -o b.out %s %s %s && vvp -n b.out" % (tmp, P("bist", "r14n7_mbist.v"), P("verilog", m.name + ".v"), tbf),
                               shell=True, capture_output=True, text=True)
            line = next((l for l in r.stdout.splitlines() if "ROMBIST" in l), "sim-failed")
            rep["checks"]["bist_%s" % ("fault_injected" if fl else "golden")] = line.strip()
            ok = ok and "-> PASS" in line
    rep["status"] = "PASS" if ok else "FAIL"
    json.dump(rep, open(P(m.name + "_report.json"), "w"), indent=2)
    print(json.dumps(rep, indent=2))
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()
