"""PDF databook of every R14N7 library cell: function, pins, truth tables, physical data
and characterized timing / power / leakage, generated from the same objects as the views."""
import itertools, os, sys, re
from collections import OrderedDict
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle,
                                PageBreak, KeepTogether, CondPageBreak)
from reportlab.platypus.tableofcontents import TableOfContents
import tech, cells as C, charmodel as cm, liberty as lb, memory, iolib, boolexpr as bx
from tech import CORNERS, CORNER_BY_NAME, VT_FLAVORS, BANNER

SS = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=SS["Heading1"], fontSize=16, spaceAfter=6, textColor=colors.HexColor("#1F3A5F"))
H2 = ParagraphStyle("H2", parent=SS["Heading2"], fontSize=12.5, spaceBefore=8, spaceAfter=4, textColor=colors.HexColor("#1F3A5F"))
H3 = ParagraphStyle("H3", parent=SS["Heading3"], fontSize=10.5, spaceBefore=6, spaceAfter=2)
BD = ParagraphStyle("BD", parent=SS["BodyText"], fontSize=8.6, leading=11)
SM = ParagraphStyle("SM", parent=BD, fontSize=7.4, leading=9)
MONO = ParagraphStyle("MONO", parent=BD, fontName="Courier", fontSize=7.6, leading=9.4)
TT = CORNER_BY_NAME["tt_0p70v_25c"]

class Doc(BaseDocTemplate):
    def __init__(s, fn):
        BaseDocTemplate.__init__(s, fn, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=16 * mm, bottomMargin=15 * mm,
                                 title="R14N7 Library Databook", author="R14N7 generator")
        fr = Frame(s.leftMargin, s.bottomMargin, s.width, s.height, id="f")
        s.addPageTemplates([PageTemplate(id="p", frames=[fr], onPage=s.deco)])
    def deco(s, canv, doc):
        canv.saveState(); canv.setFont("Helvetica", 7); canv.setFillColor(colors.grey)
        canv.drawString(15 * mm, 8 * mm, "R14N7 synthetic 7nm-class FinFET PDK v%s  -  predictive, not silicon-calibrated, not for manufacturing" % tech.PDK_VERSION)
        canv.drawRightString(A4[0] - 15 * mm, 8 * mm, "page %d" % doc.page); canv.restoreState()
    def afterFlowable(s, f):
        if isinstance(f, Paragraph) and f.style.name in ("H1", "H2"):
            s.notify("TOCEntry", (0 if f.style.name == "H1" else 1, f.getPlainText(), s.page))

def tbl(data, widths=None, hdr=1, fs=7.2, zebra=True):
    t = Table(data, colWidths=widths, repeatRows=hdr)
    st = [("FONT", (0, 0), (-1, -1), "Helvetica", fs), ("FONT", (0, 0), (-1, hdr - 1), "Helvetica-Bold", fs),
          ("BACKGROUND", (0, 0), (-1, hdr - 1), colors.HexColor("#DCE6F1")), ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#9AA9BB")),
          ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 1.2), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.2)]
    if zebra:
        for r in range(hdr, len(data)):
            if (r - hdr) % 2: st.append(("BACKGROUND", (0, r), (-1, r), colors.HexColor("#F4F7FA")))
    t.setStyle(TableStyle(st)); return t

def P(x, st=BD): return Paragraph(x, st)

# ------------------------------------------------------------------ characterization helpers
def arc_T(c, a, corner, slew_i=2, load_i=2):
    st = lb.out_stage(c, a.to, 0 if c.pin(a.to).width > 1 else None)
    st.nstages = 1.0 + a.d0 / 6.0
    slew_k = 0.12 if a.ttype != "combinational" or a.d0 > 0.5 else 0.30
    vo = corner.vddl if c.pin(a.to).pwr == "VDDL" else None
    T = cm.delay_tables(corner.name, c.vt, st, a.d0, slew_k, vdd_override=vo)
    r = lambda k: T[k][slew_i][load_i]
    return (r("cell_rise") if a.rise else None, r("cell_fall") if a.fall else None,
            r("rise_transition") if a.rise else None, r("fall_transition") if a.fall else None, st.loads[load_i], T["sig"])

def leak(c, corner=TT): return lb.cell_leakage(c, corner)
def f1(x): return "-" if x is None else ("%.1f" % x)
def f2(x): return "-" if x is None else ("%.2f" % x)
def fl(x):
    if x >= 1e6: return "%.2f uW" % (x / 1e6)
    if x >= 1e3: return "%.2f nW" % (x / 1e3)
    return "%.0f pW" % x

def worst_arc(c):
    best = None
    for a in c.arcs:
        if a.ttype in ("clear", "preset"): continue
        r, f, tr, tf, ld, sg = arc_T(c, a, TT)
        d = max(x for x in (r, f) if x is not None)
        if best is None or d > best[0]: best = (d, a, r, f, tr, tf, ld, sg)
    return best

def truth(c):
    ins = [p.name for p in c.inputs()]
    outs = [o for o in c.funcs]
    if not ins or len(ins) > 3 or c.seq: return None
    rows = [ins + outs]
    for v in itertools.product((0, 1), repeat=len(ins)):
        env = dict(zip(ins, v)); rows.append([str(x) for x in v] + [str(bx.ev(bx.parse(c.funcs[o]), env)) for o in outs])
    return rows

FAM_TITLE = OrderedDict([
    ("comb", "Combinational logic: INV/BUF/NAND/NOR/AND/OR/XOR/XNOR, AOI/OAI/AO/OA complex gates, MUX"),
    ("arith", "Arithmetic: half adder (HADD) and full adder (FADD)"),
    ("tie", "Tie cells"), ("delay", "Data delay cells (DLY)"),
    ("clock", "Clock cells: CKINV, CKBUF, CKMUX, clock gates logic, clock delay (CKD)"),
    ("icg", "Integrated clock gating (ICG): pre-/post-control, observability, neg-edge"),
    ("seq", "Flip-flops: DFF / reset / set / reset-set / sync-reset / enable / scan (SDFF)"),
    ("latch", "Latches"), ("mbit", "Multi-bit flip-flops (MBIT, 2-32 bit, multi-row)"),
    ("ga", "Gate-array ECO cells (GFILL, GDCAP, functional G* cells)"),
    ("phys", "Physical-only cells: fillers, decaps, taps, endcaps, antenna"),
    ("pmk_psw", "PMK: power switches (header/footer, simple and mother-daughter)"),
    ("pmk_iso", "PMK: isolation cells (buffered / unbuffered, clamp-0/1, latch)"),
    ("pmk_lvl", "PMK: level shifters and combined level-shifter + isolation"),
    ("pmk_ret", "PMK: retention flip-flops"), ("pmk_aon", "PMK: always-on cells"),
    ("dft", "DFT cells: lock-up latches, control/observe test points, IEEE 1500 WBR and IEEE 1149.1 boundary-scan cells"),
])

def cell_section(story, bases, allvt):
    """bases: OrderedDict base -> list of SVT cells (by drive)"""
    for base, cl in bases.items():
        c0 = cl[0]
        blk = [P("<b>%s</b> &nbsp; <font size=7.5 color='#555555'>%s</font>" % (base, c0.desc), H3)]
        fn = "; ".join("%s = %s" % (o, f) for o, f in c0.funcs.items()) if c0.funcs else "(no logic function)"
        if c0.seq and c0.seq.get("kind") in ("ff", "ff_bank", "latch"):
            sq = c0.seq
            fn += " &nbsp; | &nbsp; %s: %s" % (sq["kind"], ", ".join("%s=%s" % (k, v) for k, v in sq.items() if k in ("clocked_on", "next_state", "scan_ns", "enable", "data_in", "clear", "preset", "bits")))
        if c0.seq and c0.seq.get("kind") == "icg": fn += " &nbsp; | &nbsp; clock_gating_integrated_cell = %s" % c0.seq["ctype"]
        if c0.seq and c0.seq.get("kind") == "switch": fn += " &nbsp; | &nbsp; switch_function = %s" % c0.seq["sw"]
        blk.append(P("<b>Function:</b> <font face='Courier'>%s</font>" % fn.replace("&", "&amp;").replace("&amp;nbsp;", "&nbsp;"), SM))
        pins = ", ".join("%s%s (%s%s)" % (p.name, "[%d:0]" % (p.width - 1) if p.width > 1 else "", p.dir[:3],
                                        "" if p.role in ("data",) else "/" + p.role) for p in c0.pins)
        pg = ", ".join("%s:%s" % (n, t) for n, t, v in c0.pg)
        blk.append(P("<b>Pins:</b> %s &nbsp; <b>PG:</b> %s &nbsp; <b>Attrs:</b> %s" % (pins or "-", pg,
                     ", ".join(k for k, v in c0.attrs.items() if v is True) or "-"), SM))
        tt = truth(c0)
        row = []
        if tt and len(tt) <= 17:
            tw = [9 * mm] * len(tt[0])
            row.append(tbl(tt, tw, fs=6.4))
        hdr = ["Cell", "WxH (um)", "Area um2", "Cin max fF", "Worst arc", "tpLH ps", "tpHL ps", "tr/tf ps", "sig/mu",
               "Leak HVT", "Leak SVT", "Leak LVT", "Leak ULVT"]
        data = [hdr]
        for c in cl:
            w = worst_arc(c)
            cin = max([p.cap for p in c.inputs()] + [0])
            lk = [fl(leak(allvt[(vt, c.base, c.drive)])) if (vt, c.base, c.drive) in allvt else "-" for vt in VT_FLAVORS]
            if w:
                d, a, r, f, tr, tf, ld, sg = w
                data.append([c.name.replace("_SVT", ""), "%.3fx%.3f" % (c.width_um, c.height_um), "%.4f" % c.area, f2(cin),
                             "%s>%s" % (a.frm, a.to), f1(r), f1(f), "%s/%s" % (f1(tr), f1(tf)), "%.3f" % sg] + lk)
            else:
                data.append([c.name.replace("_SVT", ""), "%.3fx%.3f" % (c.width_um, c.height_um), "%.4f" % c.area, f2(cin), "-", "-", "-", "-", "-"] + lk)
        widths = [27 * mm, 17 * mm, 12 * mm, 11 * mm, 15 * mm, 10 * mm, 10 * mm, 15 * mm, 9 * mm, 13.5 * mm, 13.5 * mm, 13.5 * mm, 14.5 * mm]
        blk.append(tbl(data, widths, fs=6.3))
        # constraints for sequential
        if c0.cons or c0.mpw:
            cd = [["Constraint", "Pin", "Related", "TT SVT (ps)", "SS m40 SVT", "FF m40 SVT"]]
            for k in c0.cons:
                vals = [cm.constraint_table(cn, "SVT", k.base, k.kind, True)[2][2] for cn in ("tt_0p70v_25c", "ss_0p63v_m40c", "ff_0p77v_m40c")]
                cd.append([k.kind + (" (when %s)" % k.when if k.when else ""), k.pin, k.rel] + ["%.1f" % v for v in vals])
            for pn, (hi, lo) in c0.mpw.items():
                for lab, v in (("min_pulse_width_high", hi), ("min_pulse_width_low", lo)):
                    if v:
                        vals = [v * 0.5 * (cm.rscale(cn, "SVT", "p") + cm.rscale(cn, "SVT", "n")) for cn in ("tt_0p70v_25c", "ss_0p63v_m40c", "ff_0p77v_m40c")]
                        cd.append([lab, pn, "-"] + ["%.1f" % x for x in vals])
            blk.append(Spacer(1, 2)); blk.append(tbl(cd, [48 * mm, 14 * mm, 14 * mm, 20 * mm, 20 * mm, 20 * mm], fs=6.3))
        if row:
            blk.insert(3, row[0])
        blk.append(Spacer(1, 5))
        story.append(KeepTogether(blk))

def build(path, methodology_md=None, verify_txt=None, techspec_md=None, dft_md=None, images=None, sizes_csv=None):
    doc = Doc(path); story = []
    # ---- title
    story += [Spacer(1, 50 * mm), P("<font size=26 color='#1F3A5F'><b>R14N7</b></font>", BD), Spacer(1, 6 * mm),
              P("<font size=15>Synthetic 7nm-class FinFET PDK</font>", BD), Spacer(1, 3 * mm),
              P("<font size=13>Standard-cell, PMK, Memory and IO Library Databook</font>", BD), Spacer(1, 10 * mm),
              P("Version %s &nbsp;&nbsp; %s" % (tech.PDK_VERSION, tech.PDK_DATE), BD), Spacer(1, 30 * mm),
              P("<b>Important.</b> R14N7 is a <i>predictive / synthetic</i> PDK built from public ASAP7 predictive data (BSD-3) and an "
                "analytic FinFET characterization model. It is internally consistent and tool-loadable across all views, intended for "
                "flow development, methodology, architecture and HDL modelling, education and benchmarking. It is <b>not</b> calibrated "
                "to any foundry silicon and must not be used for manufacturing or sign-off of real silicon.", BD), PageBreak()]
    toc = TableOfContents(); toc.levelStyles = [ParagraphStyle("t0", fontSize=9.5, leading=12, leftIndent=0),
                                                ParagraphStyle("t1", fontSize=8, leading=10, leftIndent=12)]
    story += [P("Contents", H1), toc, PageBreak()]
    # ---- 1 technology
    story.append(P("1. Technology overview", H1))
    kv = [["Parameter", "Value"], ["Contacted poly pitch (CPP) / placement site width", "%d nm" % tech.CPP],
          ["Gate length (logic / IO)", "%d nm / 150 nm (thick-ox)" % tech.GATE_L], ["Fin pitch / fin width", "%d nm / %d nm" % (tech.FIN_P, tech.FIN_W)],
          ["Standard row height", "%d nm (10 fins, 6 M2 tracks @45 nm)" % tech.ROW_H], ["Fins per device finger", "3 (X0P5: 2)"],
          ["Metal stack", "M1-M9 + AP (RDL/pad), see table"], ["Nominal core VDD / low-voltage domain / IO", "0.70 V / 0.60 V / 1.80 V"],
          ["Device models", "BSIM-CMG level 72 (v107): ASAP7 SLVT/LVT/RVT/SRAM + synthetic HVT, IO, diodes"],
          ["GDS units", "user unit 1 um, database 0.1 nm; LEF DBU 4000/um; manufacturing grid 1 nm"]]
    story.append(tbl(kv, [70 * mm, 105 * mm], fs=7.5))
    story.append(P("Metal stack (routing grid-aligned: vertical pitches are multiples of CPP, horizontal pitches divide the row height).", H2))
    md = [["Layer", "Dir", "Pitch nm", "Width nm", "Space nm", "Track offset nm", "Rs ohm/sq"]]
    for (m, d, p, w, s, t, off) in tech.METALS: md.append([m, d[0], p, w, s, off, tech.METAL_RC[m][0]])
    story.append(tbl(md, [18 * mm, 12 * mm, 20 * mm, 20 * mm, 20 * mm, 26 * mm, 20 * mm], fs=7.2))
    story.append(P("Threshold-voltage flavours", H2))
    vd = [["Flavour", "|Vtn| / |Vtp| (V)", "NMOS / PMOS model", "Implant layer", "Leak/fin TT25 (nA)", "INV_X1 tp TT (ps)"]]
    inv = {vt: [c for c in C.catalog(vt)[0] if c.base == "INV" and c.drive == "X1"][0] for vt in VT_FLAVORS}
    for vt, f in VT_FLAVORS.items():
        w = worst_arc(inv[vt])
        vd.append([vt, "%.3f / %.3f" % (f["vtn"], f["vtp"]), "%s / %s" % (f["nmodel"], f["pmodel"]), f["implant"] or "(none)",
                   "%.3f" % cm.leak_fin("tt_0p70v_25c", vt, "n"), "%.1f" % w[0]])
    story.append(tbl(vd, [16 * mm, 28 * mm, 42 * mm, 24 * mm, 28 * mm, 28 * mm], fs=7.2))
    story.append(P("PVT corners (12 signoff corners)", H2))
    cd = [["Corner", "Process", "VDD", "VDDL", "IOVDD", "T (C)", "Role"]]
    for c in CORNERS: cd.append([c.name, c.proc.upper(), "%.2f" % c.vdd, "%.3f" % c.vddl, "%.2f" % c.vddio, "%g" % c.temp, c.role])
    story.append(tbl(cd, [30 * mm, 14 * mm, 12 * mm, 14 * mm, 14 * mm, 12 * mm, 80 * mm], fs=7))
    story.append(P("INV_X1 propagation delay (ps, slew 20 ps, load 1.44 fF) and leakage per corner and Vt. Note the FinFET "
                   "temperature inversion: at low VDD the cold corner (-40C) is slower than the hot corner.", BD))
    md = [["Corner"] + ["tp %s" % v for v in VT_FLAVORS] + ["leak %s" % v for v in VT_FLAVORS]]
    for c in CORNERS:
        md.append([c.name] + ["%.1f" % worst_arc_corner(inv[v], c) for v in VT_FLAVORS] + [fl(leak(inv[v], c)) for v in VT_FLAVORS])
    story.append(tbl(md, [30 * mm] + [17 * mm] * 4 + [19 * mm] * 4, fs=6.8))
    story.append(P("Naming convention", H2))
    story.append(P("<font face='Courier'>&lt;FUNCTION&gt;_X&lt;drive&gt;_&lt;VT&gt;</font> e.g. <font face='Courier'>NAND2_X2_LVT, SDFFRS_X1_HVT, "
                   "MBSDFFR16_X1_SVT, ICGPREOBS_X4_ULVT, LVLLHISOLOUB_X2_SVT, HDRSW2S_X4_SVT</font>. Drive X1 = one 3-fin finger "
                   "output stage; Xn = n fingers. Suffix <b>UB</b> = unbuffered PMK variant; <b>MR</b> = multi-row; <b>2S</b> = mother-daughter "
                   "(two-stage) switch; prefix <b>G</b> = gate-array ECO cell; <b>MB</b>n = n-bit multi-bit register. Libraries: "
                   "<font face='Courier'>r14n7_{std|pmk}_&lt;vt&gt;_&lt;corner&gt;_{nldm|ccs|ecsm}.lib</font>, "
                   "<font face='Courier'>r14n7_mem_&lt;corner&gt;_*.lib</font>, <font face='Courier'>r14n7_io18_&lt;corner&gt;_*.lib</font>.", BD))
    if techspec_md and os.path.exists(techspec_md):
        render_md(story, techspec_md, "1b. Technology and place-and-route grid specification")
    # ---- 2 contents summary
    story.append(PageBreak()); story.append(P("2. Library contents", H1))
    std, pmk = C.catalog("SVT")
    allvt = {}
    for vt in VT_FLAVORS:
        s_, p_ = C.catalog(vt)
        for c in s_ + p_: allvt[(vt, c.base, c.drive)] = c
    fam = OrderedDict()
    for c in std + pmk: fam.setdefault(c.family, []).append(c)
    sd = [["Family", "Base cells", "Cells / Vt", "Cells (4 Vt)", "Drive strengths"]]
    tot = 0
    for f, cl in fam.items():
        bases = OrderedDict((c.base, 1) for c in cl)
        drs = sorted(set(c.drive for c in cl), key=lambda d: C.dnum(d))
        sd.append([FAM_TITLE.get(f, f).split(":")[0], len(bases), len(cl), 4 * len(cl), ", ".join(drs)]); tot += len(cl)
    sd.append(["TOTAL (std + PMK)", "", tot, 4 * tot, ""])
    story.append(tbl(sd, [62 * mm, 18 * mm, 18 * mm, 20 * mm, 62 * mm], fs=7))
    ms = memory.all_mems(); ios = iolib.cells()
    story.append(P("Plus %d memory macros (single-port SRAM, two-port register file, ROM) and %d IO library cells. "
                   "Every cell exists in Verilog, Liberty (12 corners x NLDM+LVF / CCS / ECSM), AOCV and POCV side files, "
                   "SPICE + CDL, LEF and GDS. Base-cell lists by family:" % (len(ms), len(ios)), BD))
    for f, cl in fam.items():
        bases = list(OrderedDict((c.base, 1) for c in cl))
        story.append(P("<b>%s</b>: <font face='Courier' size=7>%s</font>" % (FAM_TITLE.get(f, f), ", ".join(bases)), SM))
    # ---- 3 characterization conditions
    story.append(P("3. Characterization conditions", H1))
    story.append(P("Timing thresholds: delay 50%% in / 50%% out, slew 10%%-90%%. Units: ps, fF, V, mA, pW, fJ (internal energy). "
                   "NLDM 7x7 tables, input slew index %s ps; load index scales with drive (X1: %s fF). Constraint tables 5x5 "
                   "(%s ps). CCS: output_current vectors on a 4x4 sub-grid with 12 time points plus receiver_capacitance (C1/C2 rise/fall). "
                   "ECSM: voltage-time waveforms (%s x VDD) on the same sub-grid. LVF: ocv_sigma_cell_rise/fall, "
                   "ocv_sigma_rise/fall_transition and ocv_sigma_*_constraint (early_and_late). Datasheet values below are at "
                   "TT 0.70 V 25C, SVT, input slew 20 ps, load = 3rd load index (1.44 fF x drive); leakage columns are per Vt flavour "
                   "at TT 25C. sig/mu = LVF local-variation sigma/mean of the listed arc." % (
                       ", ".join("%g" % s for s in cm.SLEWS), ", ".join("%g" % l for l in cm.LOAD_X1), ", ".join("%g" % s for s in cm.CSLEWS),
                       ", ".join("%g" % v for v in cm.ECSM_V)), BD))
    # ---- 4.. cell datasheets
    sec = 4
    for f in FAM_TITLE:
        if f not in fam: continue
        story.append(PageBreak()); story.append(P("%d. %s" % (sec, FAM_TITLE[f]), H1)); sec += 1
        bases = OrderedDict()
        for c in fam[f]: bases.setdefault(c.base, []).append(c)
        cell_section(story, bases, allvt)
    # ---- memories
    story.append(PageBreak()); story.append(P("%d. Memory compiler instances" % sec, H1)); sec += 1
    story.append(P("Single-port SRAM (R14SRAM_SP: CLK, CEB, WEB, A, D, BWEB bit-write mask, Q), two-port register file "
                   "(R14RF_2P: read port CLKA/CEBA/AA/QA, write port CLKB/CEBB/AB/D/BWEB) and V0-programmed NOR ROM (R14ROM: CLK, CEB, A, Q; "
                   "code in rom_code/*.hex). 6T HD bitcell 0.108 x 0.216 um (0.0233 um2) on SRAM-Vt devices; array supply VDDM. "
                   "All active-low controls; flow-through output latched until the next access. Values at TT 0.70 V 25C.", BD))
    md = [["Instance", "Type", "Words x bits", "Mux", "W x H (um)", "Area um2", "tCQ ps", "tCYC ps", "E_rd fJ", "E_wr fJ", "Leak TT25", "Leak FF125"]]
    for m in ms:
        md.append([m.name, m.kind.upper(), "%dx%d" % (m.words, m.bits), m.mux, "%.2fx%.2f" % (m.w / 1e3, m.h / 1e3), "%.0f" % m.area,
                   "%.0f" % m.tcq(), "%.0f" % m.tcyc(), "%.0f" % m.e_read(), "%.0f" % (m.e_write() if m.kind != "rom" else 0),
                   fl(m.leak("tt_0p70v_25c")), fl(m.leak("ff_0p77v_125c"))])
    story.append(tbl(md, [36 * mm, 10 * mm, 17 * mm, 8 * mm, 20 * mm, 13 * mm, 11 * mm, 12 * mm, 11 * mm, 11 * mm, 15 * mm, 16 * mm], fs=6.4))
    story.append(P("Memory corner scaling of tCQ (ps)", H2))
    md = [["Instance"] + [c.name.replace("_", " ") for c in CORNERS[::2]]]
    for m in ms[::3]:
        md.append([m.name] + ["%.0f" % (m.tcq() * 0.5 * (cm.rscale(c.name, "SVT", "p") + cm.rscale(c.name, "SVT", "n"))) for c in CORNERS[::2]])
    story.append(tbl(md, [40 * mm] + [23 * mm] * 6, fs=6.4))
    # ---- IO
    story.append(PageBreak()); story.append(P("%d. IO library (1.8 V, in-line 40 um x 120 um)" % sec, H1)); sec += 1
    io = [["Cell", "LEF class", "Size (um)", "Pins", "Description"]]
    for c in ios:
        io.append([c.name, c.cls, "%gx%g" % (c.w / 1e3, c.h / 1e3), ", ".join(p[0] for p in c.pins) or "-", P(c.desc, SM)])
    story.append(tbl(io, [24 * mm, 22 * mm, 16 * mm, 40 * mm, 78 * mm], fs=6.6))
    story.append(P("Rings (M8, abutting): VSS 60-66 um, VDD 68-74 um, IOVSS 80-88 um, IOVDD 90-98 um from the core edge. "
                   "PBRK cuts VDD/IOVDD/IOVSS and keeps VSS-IOVSS coupled through back-to-back ESD diodes. Pad pin on M9 (100-120 um) under "
                   "BONDPAD60 (AP 64x64 um, passivation opening 56x56 um). Typical I->PAD 12 mA drive into 10 pF at TT: ~%.0f ps." % (
                       420 * 0.7 + 0.69 * 0.025 * 10000), BD))
    if dft_md and os.path.exists(dft_md):
        render_md(story, dft_md, "%d. DFT: ATPG models, BIST and boundary scan" % sec); sec += 1
        sig = os.path.join(os.path.dirname(dft_md), "..", "memory", "rom_code", "r14n7_rom_signatures.txt")
        if os.path.exists(sig):
            story.append(P("Golden ROM MISR signatures", H2))
            for ln in open(sig).read().splitlines(): story.append(P(ln.replace(" ", "&nbsp;"), MONO))
    if sizes_csv and os.path.exists(sizes_csv):
        import csv, collections
        rows = list(csv.DictReader(open(sizes_csv)))
        story.append(PageBreak()); story.append(P("%d. Cell size check" % sec, H1)); sec += 1
        story.append(P("Every cell width is re-derived from its transistor netlist and pin list and compared with the delivered views. "
                       "<b>Standard rule:</b> sites = max(ceil(gate columns / rows) + 2, ceil(pins / rows) + 1, fixed minimum). Interior gates = sites - 1; "
                       "one column is kept as spare / diffusion break; one M1 track per site plus one spare. "
                       "<b>Gate-array rule:</b> whole 4-site tiles, 3 device columns per tile (tile-boundary gates are dummies), tiles = "
                       "max(ceil(max(N,P fingers)/3), ceil((pins+1)/4)). <b>Fixed:</b> physical cells and switch arrays by definition. "
                       "Also checked: site/row grid, LEF SIZE = GDS PR boundary = Liberty area, identical footprint across the 4 Vt flavours, "
                       "non-decreasing area with drive, memory 0.108 um x row grid with all pins on M3 tracks, IO on ioSite.", BD))
        fam = collections.OrderedDict()
        for r in rows:
            if r["vt"] not in ("SVT", "-"): continue
            fam.setdefault(r["family"], []).append(r)
        sd = [["Family", "Cells (SVT)", "PASS", "binding: devices", "pins", "fixed", "avg column use", "min-max sites"]]
        for f, rl in fam.items():
            b = collections.Counter(r["binding"] for r in rl)
            ut = [float(r["column_utilisation"]) for r in rl if r["column_utilisation"] not in ("", "0.00")]
            st = [int(r["sites"]) for r in rl if r["sites"]]
            sd.append([f, len(rl), sum(r["status"] == "PASS" for r in rl), b.get("devices", 0), b.get("pins", 0), b.get("fixed", 0),
                       ("%.0f%%" % (100 * sum(ut) / len(ut))) if ut else "-", ("%d-%d" % (min(st), max(st))) if st else "-"])
        story.append(tbl(sd, [24 * mm, 18 * mm, 14 * mm, 24 * mm, 14 * mm, 14 * mm, 24 * mm, 24 * mm], fs=7))
        story.append(P("Per-cell detail (SVT; identical for HVT/LVT/ULVT). Columns: derived minimum from devices / pins / fixed, binding constraint, "
                       "device columns used / available.", BD))
        dd = [["Cell", "Sites x rows", "W um", "dev", "pins", "fixed", "binding", "cols used/avail", "status"]]
        for r in rows:
            if r["vt"] != "SVT": continue
            dd.append([r["cell"].replace("_SVT", ""), "%s x %s" % (r["sites"], r["rows"]), r["width_um"], r["min_sites_devices"], r["min_sites_pins"],
                       r["min_sites_fixed"], r["binding"], "%s/%s" % (r["device_columns"], r["columns_available"]), r["status"]])
        story.append(tbl(dd, [36 * mm, 18 * mm, 15 * mm, 12 * mm, 12 * mm, 12 * mm, 18 * mm, 24 * mm, 14 * mm], fs=6.2))
    if images:
        from reportlab.platypus import Image as RLImage
        story.append(PageBreak()); story.append(P("%d. Layout snapshots" % sec, H1)); sec += 1
        for img, cap in images:
            if os.path.exists(img):
                from PIL import Image as PI
                w, h = PI.open(img).size; W_ = 180 * mm; story.append(RLImage(img, width=W_, height=W_ * h / w)); story.append(P(cap, SM)); story.append(Spacer(1, 6))
    # ---- appendices
    if methodology_md and os.path.exists(methodology_md):
        render_md(story, methodology_md, "%d. Methodology and flows" % sec); sec += 1
    if verify_txt and os.path.exists(verify_txt):
        story.append(PageBreak()); story.append(P("%d. Verification report" % sec, H1)); sec += 1
        for ln in open(verify_txt).read().splitlines():
            story.append(P(ln.replace("&", "&amp;").replace("<", "&lt;").replace(" ", "&nbsp;") or "&nbsp;", MONO))
    story.append(PageBreak()); story.append(P("%d. Layer map" % sec, H1))
    lm = [["Name", "GDS layer;dt", "Description"]] + [[n, "%d;%d" % ld, d] for n, (ld, d) in tech.LAYERS.items()]
    story.append(tbl(lm, [25 * mm, 25 * mm, 120 * mm], fs=7))
    story.append(P("Pin shapes use datatype %d, text labels texttype %d, dummy fill datatype %d on the same layer numbers." % (tech.PIN_DT, tech.TEXT_DT, tech.FILL_DT), BD))
    story.append(P("Design rules (summary, full list in tech/r14n7_rules.csv and calibre/r14n7_drc.svrf)", H2))
    rd = [["Rule", "Layer", "Kind", "Value", "Description"]] + [[r.rid, r.layer, r.kind, "%g" % r.value, P(r.desc, SM)] for r in tech.RULES]
    story.append(tbl(rd, [20 * mm, 18 * mm, 22 * mm, 14 * mm, 100 * mm], fs=6.5))
    doc.multiBuild(story)

def render_md(story, path, title):
    story.append(PageBreak()); story.append(P(title, H1))
    def inl(b):
        b = b.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        b = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", b)
        return re.sub(r"`(.+?)`", r"<font face='Courier'>\1</font>", b)
    for blk in open(path).read().split("\n\n"):
        b = blk.strip()
        if not b or b.startswith("# "): continue
        if b.startswith("```"):
            story.append(P(b.strip("`").replace("&", "&amp;").replace("<", "&lt;").replace("\n", "<br/>").replace(" ", "&nbsp;"), MONO)); continue
        if b.startswith("## "): story.append(P(b[3:], H2)); continue
        if b.startswith("|"):
            rows = [r.strip().strip("|").split("|") for r in b.splitlines() if not re.match(r"^\|[-| ]+\|$", r.strip())]
            n = len(rows[0])
            data = [[P(inl(x.strip()), SM) for x in r] for r in rows]
            if n == 3: w = [38 * mm, 42 * mm, 100 * mm]
            else: w = [180 * mm / n] * n if n < 8 else [12 * mm, 9 * mm, 14 * mm, 14 * mm, 14 * mm, 16 * mm, 20 * mm, 81 * mm]
            story.append(tbl(data, w, fs=6.6)); story.append(Spacer(1, 4)); continue
        story.append(P(inl(b).replace("\n- ", "<br/>&bull; ").replace("\n", " "), BD))

def worst_arc_corner(c, corner):
    best = 0
    for a in c.arcs:
        r, f, tr, tf, ld, sg = arc_T(c, a, corner)
        best = max(best, max(x for x in (r, f) if x is not None))
    return best

if __name__ == "__main__":
    a = sys.argv + [None] * 6
    build(a[1], a[2], a[3], a[4], a[5])
