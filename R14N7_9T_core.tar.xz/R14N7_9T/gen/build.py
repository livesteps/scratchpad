#!/usr/bin/env python3
"""R14N7 PDK build orchestrator.
   python3 gen/build.py --out <dir> [--vt HVT,SVT,LVT,ULVT] [--corners all|name,...] [--models nldm,ccs,ecsm] [--jobs N]"""
import argparse, os, sys, shutil, time, multiprocessing as mp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import subprocess, glob
import tech, cells, liberty, verilog, spice, layout, ocv, memory, iolib, calibre, dft, techspec
from tech import CORNERS, CORNER_BY_NAME, VT_FLAVORS

def mk(*p):
    d = os.path.join(*p); os.makedirs(d, exist_ok=True); return d

def lib_job(args):
    out, vt, cname, models = args
    corner = CORNER_BY_NAME[cname]
    std, pmk = cells.catalog(vt)
    cache = {}
    v = vt.lower()
    for grp, cl in (("std", std), ("pmk", pmk)):
        base = "stdcell" if grp == "std" else "pmk"
        for m in models:
            d = mk(out, base, vt, "liberty", m)
            libname = "%s_%s_%s_%s_%s" % (tech.LIBPFX, grp, v, cname, m)
            liberty.write_lib(os.path.join(d, libname + ".lib"), libname, cl, corner, m, cache)
        d = mk(out, base, vt, "ocv")
        ln = "%s_%s_%s_%s" % (tech.LIBPFX, grp, v, cname)
        ocv.write_aocv(os.path.join(d, ln + ".aocv"), cl, ln + "_nldm", corner)
        ocv.write_pocv(os.path.join(d, ln + ".pocv"), cl, ln + "_nldm", corner)
    return "%s %s" % (vt, cname)

def mem_io_job(args):
    out, cname, models = args
    corner = CORNER_BY_NAME[cname]
    ms = memory.all_mems(); ios = iolib.cells()
    for m in models:
        memory.write_lib(os.path.join(mk(out, "memory", "liberty", m), "%s_mem_%s_%s.lib" % (tech.LIBPFX, cname, m)), ms, corner, m)
        iolib.write_lib(os.path.join(mk(out, "io", "liberty", m), "%s_io18_%s_%s.lib" % (tech.LIBPFX, cname, m)), ios, corner, m)
    return "mem/io " + cname

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--vt", default=",".join(VT_FLAVORS))
    ap.add_argument("--corners", default="all")
    ap.add_argument("--models", default="nldm,ccs,ecsm")
    ap.add_argument("--jobs", type=int, default=max(1, os.cpu_count() or 1))
    ap.add_argument("--skip-libs", action="store_true")
    a = ap.parse_args()
    out = os.path.abspath(a.out); vts = a.vt.split(","); models = a.models.split(",")
    cns = [c.name for c in CORNERS] if a.corners == "all" else a.corners.split(",")
    t0 = time.time()
    here = os.path.dirname(os.path.abspath(__file__))
    # ---------------- tech
    d = mk(out, "tech")
    layout.write_techlef(os.path.join(d, "r14n7_tech.lef"))
    open(os.path.join(d, "libprefix"), "w").write(tech.LIBPFX + "\n")
    with open(os.path.join(d, "r14n7_layermap.txt"), "w") as f:
        f.write("# %s\n# name gds_layer gds_datatype description (pin purpose datatype %d, text %d, fill %d)\n" % (tech.BANNER, tech.PIN_DT, tech.TEXT_DT, tech.FILL_DT))
        for n, ((l, dt), desc) in tech.LAYERS.items(): f.write("%-10s %4d %3d  %s\n" % (n, l, dt, desc))
    with open(os.path.join(d, "r14n7_rules.csv"), "w") as f:
        f.write("rule_id,layer,kind,value_nm,other,description\n")
        for r in tech.RULES: f.write('%s,%s,%s,%g,%s,"%s"\n' % (r.rid, r.layer, r.kind, r.value, r.other, r.desc))
    with open(os.path.join(d, "r14n7_corners.csv"), "w") as f:
        f.write("corner,process,vdd,vddl,vddio,temp_c,role\n")
        for c in CORNERS: f.write("%s,%s,%.3f,%.3f,%.2f,%g,%s\n" % (c.name, c.proc, c.vdd, c.vddl, c.vddio, c.temp, c.role))
    # ---------------- models
    d = mk(out, "models", "spice")
    spice.write_model_lib(os.path.join(d, "r14n7.l"))
    shutil.copy(os.path.join(here, "asap7_models", "LICENSE.ASAP7"), d)
    # ---------------- std / pmk views per VT
    for vt in vts:
        std, pmk = cells.catalog(vt); v = vt.lower()
        for grp, cl, base in (("std", std, "stdcell"), ("pmk", pmk, "pmk")):
            nm = "%s_%s_%s" % (tech.LIBPFX, grp, v)
            verilog.write(os.path.join(mk(out, base, vt, "verilog"), nm + ".v"), cl, "%s %s library" % (grp, vt))
            verilog.write_udp(os.path.join(out, base, vt, "verilog", "r14n7_udp.v"))
            verilog.write_v2lvs(os.path.join(out, base, vt, "verilog", nm + "_v2lvs.v"), cl)
            spice.write_netlists(os.path.join(mk(out, base, vt, "spice"), nm + ".sp"), cl, "%s %s simulation netlists" % (grp, vt))
            spice.write_netlists(os.path.join(out, base, vt, "spice", nm + ".cdl"), cl, "%s %s LVS netlists" % (grp, vt), cdl=True)
            sh = layout.build_gds(os.path.join(mk(out, base, vt, "gds"), nm + ".gds"), cl, nm)
            layout.write_lef(os.path.join(mk(out, base, vt, "lef"), nm + ".lef"), cl, sh)
        print("views %s done (%.0fs)" % (vt, time.time() - t0), flush=True)
    # ---------------- memories / IO (non-liberty views)
    ms = memory.all_mems(); ios = iolib.cells()
    open(os.path.join(mk(out, "memory", "verilog"), "r14n7_mem.v"), "w").write("".join(memory.verilog(m) for m in ms))
    open(os.path.join(out, "memory", "verilog", "r14n7_mem_v2lvs.v"), "w").write("// " + tech.BANNER + "\n" + "".join(
        verilog.v2lvs_stub(m.name, [(p[0], p[1], p[2]) for p in m.pins()], ["VDD", "VDDM", "VSS"]) for m in ms))
    for m in ms:
        if m.kind == "rom": open(os.path.join(mk(out, "memory", "rom_code"), m.name + ".hex"), "w").write(memory.hexfile(m))
    open(os.path.join(mk(out, "memory", "spice"), "r14n7_mem.cdl"), "w").write("".join(memory.spice(m) for m in ms))
    memory.write_lef(os.path.join(mk(out, "memory", "lef"), "r14n7_mem.lef"), ms)
    memory.build_gds(os.path.join(mk(out, "memory", "gds"), "r14n7_mem.gds"), ms)
    with open(os.path.join(out, "memory", "r14n7_mem_list.csv"), "w") as f:
        f.write("name,type,words,bits,mux,width_um,height_um,area_um2,tcq_ps_tt,tcyc_ps_tt,e_read_fJ,e_write_fJ\n")
        for m in ms: f.write("%s,%s,%d,%d,%d,%.3f,%.3f,%.2f,%.1f,%.1f,%.0f,%.0f\n" % (m.name, m.kind, m.words, m.bits, m.mux, m.w / 1e3, m.h / 1e3, m.area, m.tcq(), m.tcyc(), m.e_read(), m.e_write()))
    open(os.path.join(mk(out, "io", "verilog"), "r14n7_io18.v"), "w").write(iolib.verilog(ios))
    open(os.path.join(out, "io", "verilog", "r14n7_io18_v2lvs.v"), "w").write("// " + tech.BANNER + "\n" + "".join(
        verilog.v2lvs_stub(c.name, [(p[0], p[1], 1) for p in c.pins], ["VDD", "VSS", "IOVDD", "IOVSS"]) for c in ios))
    open(os.path.join(mk(out, "io", "spice"), "r14n7_io18.cdl"), "w").write(iolib.spice(ios))
    iolib.write_lef(os.path.join(mk(out, "io", "lef"), "r14n7_io18.lef"), ios)
    iolib.build_gds(os.path.join(mk(out, "io", "gds"), "r14n7_io18.gds"), ios)
    # ---------------- calibre
    d = mk(out, "calibre")
    for fn, txt in (("r14n7_drc.svrf", calibre.drc_deck()), ("r14n7_lvs.svrf", calibre.lvs_deck()), ("r14n7_erc.svrf", calibre.erc_deck()),
                    ("r14n7_density.svrf", calibre.density_deck()), ("r14n7_antenna.svrf", calibre.antenna_deck())):
        open(os.path.join(d, fn), "w").write(txt)
    # ---------------- DFT
    d = mk(out, "dft")
    for vt in vts:
        std, pmk = cells.catalog(vt); v = vt.lower()
        for grp, cl in (("std", std), ("pmk", pmk)):
            dft.write_atpglib(os.path.join(mk(out, "dft", "atpg", "tessent"), "%s_%s_%s.atpglib" % (tech.LIBPFX, grp, v)), cl, "%s %s" % (grp, vt))
            open(os.path.join(mk(out, "dft", "atpg", "verilog"), "%s_%s_%s_atpg.v" % (tech.LIBPFX, grp, v)), "w").write(
                "// %s\n// ATPG/structural models (no timing)\n`timescale 1ps/1fs\n" % tech.BANNER + "".join(dft.atpg_verilog(c) for c in cl))
    open(os.path.join(out, "dft", "atpg", "tessent", "%s_mem.atpglib" % tech.LIBPFX), "w").write("// " + tech.BANNER + "\n" + "".join(dft.mem_atpg(m) for m in ms))
    open(os.path.join(out, "dft", "atpg", "tessent", "%s_io18.atpglib" % tech.LIBPFX), "w").write("// " + tech.BANNER + "\n" + "".join(dft.io_atpg(c) for c in ios))
    open(os.path.join(mk(out, "dft", "rtl"), "r14n7_mbist.v"), "w").write(dft.MBIST)
    open(os.path.join(out, "dft", "rtl", "r14n7_lbist.v"), "w").write(dft.LBIST)
    for m in ms:
        if m.kind == "sp":
            for fl in (0, 1): open(os.path.join(mk(out, "dft", "tb"), "tb_mbist_%s%s.v" % (m.name, "_fault" if fl else "")), "w").write(dft.tb_sram(m, fl))
        if m.kind == "rom":
            for fl in (0, 1): open(os.path.join(mk(out, "dft", "tb"), "tb_rombist_%s%s.v" % (m.name, "_fault" if fl else "")), "w").write(dft.tb_rom(m, fl))
    open(os.path.join(out, "memory", "rom_code", "r14n7_rom_signatures.txt"), "w").write(dft.rom_signatures(ms))
    open(os.path.join(out, "dft", "README.md"), "w").write(dft.README)
    open(os.path.join(mk(out, "io", "bsdl"), "r14n7_io18_bsr.bsdl"), "w").write(iolib.bsdl(ios))
    # ---------------- docs, flows, generator and verifier sources
    root = os.path.dirname(here)
    d = mk(out, "doc")
    open(os.path.join(d, "technology_and_grid.md"), "w").write(techspec.md())
    shutil.copy(os.path.join(root, "doc", "methodology.md"), d)
    for sub in ("flows", "verify"):
        if os.path.isdir(os.path.join(out, sub)): shutil.rmtree(os.path.join(out, sub))
        shutil.copytree(os.path.join(root, sub), os.path.join(out, sub), ignore=shutil.ignore_patterns("__pycache__"))
    if os.path.isdir(os.path.join(out, "gen")): shutil.rmtree(os.path.join(out, "gen"))
    shutil.copytree(here, os.path.join(out, "gen"), ignore=shutil.ignore_patterns("__pycache__"))
    open(os.path.join(out, "flows", "pnr", "r14n7_tracks_innovus.tcl"), "w").write(techspec.tracks_innovus())
    open(os.path.join(out, "flows", "pnr", "r14n7_tracks_icc2.tcl"), "w").write(techspec.tracks_icc2())
    print("non-liberty views done (%.0fs)" % (time.time() - t0), flush=True)
    if a.skip_libs: return
    jobs = [(out, vt, c, models) for vt in vts for c in cns] + [(out, c, models) for c in cns]
    with mp.Pool(a.jobs) as pool:
        for r in pool.imap_unordered(_dispatch, jobs):
            print("  lib", r, "(%.0fs)" % (time.time() - t0), flush=True)
    print("BUILD DONE in %.0fs -> %s" % (time.time() - t0, out))

def _dispatch(j):
    return lib_job(j) if len(j) == 4 else mem_io_job(j)

if __name__ == "__main__":
    main()
