"""DFT views: Tessent-style ATPG cell library, TestMAX-style ATPG Verilog, memory/IO ATPG models,
MBIST/ROM-BIST/LBIST RTL with self-checking testbenches, golden ROM signatures."""
import re
import boolexpr as bx
import verilog as vg
from tech import BANNER

# ------------------------------------------------------------------ Tessent-style ATPG library
class Emit:
    def __init__(s): s.k = 0; s.lines = []; s.interns = []
    def net(s): s.k += 1; n = "n%d" % s.k; s.interns.append(n); return n
    def prim(s, p, ins, out):
        s.k += 1; s.lines.append((out, "_%s g%d (%s, %s)" % (p, s.k, ", ".join(ins), out)))
    def expr(s, node, out=None, rename=None):
        rename = rename or {}
        k = node[0]
        if k == "v":
            v = rename.get(node[1], node[1])
            if out: s.prim("buf", [v], out); return out
            return v
        if k == "c":
            o = out or s.net(); s.prim("tie1" if node[1] else "tie0", [], o) if False else s.lines.append((o, "_tie%d g%d (%s)" % (node[1], s.k + 1, o))); s.k += 1; return o
        if k == "!":
            a = s.expr(node[1], rename=rename); o = out or s.net(); s.prim("inv", [a], o); return o
        a = s.expr(node[1], rename=rename); b = s.expr(node[2], rename=rename); o = out or s.net()
        s.prim({"&": "and", "|": "or", "^": "xor"}[k], [a, b], o); return o

def atpg_model(c, mem=False):
    if c.physical_only and not c.pins:
        return "model %s () (\n  // physical-only cell, no logic\n)\n" % c.name
    e = Emit(); pins = []
    for p in c.pins:
        pins += ["%s[%d]" % (p.name, b) for b in range(p.width - 1, -1, -1)] if p.width > 1 else [p.name]
    sq = c.seq or {}; vk = c.vkind
    outs = {}
    def ex(f, out=None, ren=None): return e.expr(bx.parse(f), out, ren)
    if sq.get("kind") == "ff" or vk in ("ff", "ret", "tpctl"):
        # data path
        ns = sq.get("scan_ns") if vk == "tpctl" else sq.get("next_state", "D")
        d = ex(ns.replace("IQ", "IQ_q"))
        if sq.get("scan_ns") and vk != "tpctl":
            d = e.net(); e.prim("mux", [ex(sq["next_state"].replace("IQ", "IQ_q")), "SI", "SE"], d) if False else None
            base = ex(sq["next_state"].replace("IQ", "IQ_q")); d = e.net(); e.prim("mux", [base, "SI", "SE"], d)
        ck = ex(sq.get("clocked_on", "CK"))
        st = ex(sq["preset"]) if "preset" in sq else ""
        rs = ex(sq["clear"]) if "clear" in sq else ""
        e.lines.append(("IQ_q", "_dff ff0 (%s, %s, %s, %s, IQ_q, IQN_q)" % (st, rs, ck, d)))
        e.interns += ["IQ_q", "IQN_q"]
        for o, f in c.funcs.items(): ex(f.replace("IQN", "IQN_q").replace("IQ", "IQ_q") if "IQ_q" not in f else f, o) if False else ex(re.sub(r"\bIQN\b", "IQN_q", re.sub(r"\bIQ\b", "IQ_q", f)), o)
    elif sq.get("kind") in ("latch",) or vk in ("latch", "isolat"):
        en = ex(sq["enable"]); d = ex(sq["data_in"])
        st = ex(sq["preset"]) if "preset" in sq else ""; rs = ex(sq["clear"]) if "clear" in sq else ""
        e.lines.append(("IQ_q", "_dlat l0 (%s, %s, %s, %s, IQ_q, IQN_q)" % (st, rs, en, d))); e.interns += ["IQ_q", "IQN_q"]
        for o, f in c.funcs.items(): ex(re.sub(r"\bIQ\b", "IQ_q", f), o)
    elif sq.get("kind") == "icg":
        en = ex("CK" if sq["neg"] else "!CK"); d = ex("E|SE" if sq["pre"] else "E")
        e.lines.append(("IQ_q", "_dlat l0 (, , %s, %s, IQ_q, )" % (en, d))); e.interns.append("IQ_q")
        for o, f in c.funcs.items(): ex(re.sub(r"\bIQ\b", "IQ_q", f), o)
    elif sq.get("kind") == "ff_bank":
        n = sq["bits"]
        for b in range(n):
            ren = {"D": "D[%d]" % b, "SI": "SI[%d]" % b}
            d = ex(sq.get("scan_ns", sq["next_state"]), ren=ren)
            rs = ex(sq["clear"]) if "clear" in sq else ""
            e.lines.append(("Q[%d]" % b, "_dff ff%d (, %s, CK, %s, Q[%d], )" % (b, rs, d, b)))
    elif sq.get("kind") == "ffs":
        for (iq, iqn, ck, ns) in sq["groups"]:
            d = ex(ns.replace("IQ1", "IQ1_q").replace("IQ2", "IQ2_q") if False else re.sub(r"\b(IQ\d)\b", r"\1_q", ns))
            e.lines.append((iq + "_q", "_dff %s (, , %s, %s, %s_q, )" % (iq.lower(), ck, d, iq))); e.interns.append(iq + "_q")
        for o, f in c.funcs.items(): ex(re.sub(r"\b(IQ\d)\b", r"\1_q", f), o)
    else:
        for o, f in c.funcs.items():
            ex(f, o)
    L = ["model %s (%s) (" % (c.name, ", ".join(pins))]
    if sq.get("scan_ns") and vk in ("ff", "ret", "mbff"):
        so = "Q" if "Q" in c.funcs else list(c.funcs)[0]
        ns_model = c.name.replace("SDFF", "DFF", 1) if c.base.startswith("SDFF") else ""
        L += ["  scan_definition (", "    type = mux_scan;", "    scan_in = SI;", "    scan_enable = SE;", "    scan_out = %s;" % so]
        if ns_model: L.append("    non_scan_model = %s;" % ns_model)
        L.append("  )")
    if c.family == "dft" and c.base in ("WBRCELL", "BSCELL"):
        L.append("  // boundary-scan / wrapper cell: shift path %s -> %s is a functional (non-ATPG-scan) chain" % (c.vextra["names"][1], c.vextra["names"][8]))
    if c.attrs.get("is_clock_cell") or c.vkind == "icg": L.append("  cell_type = clock_gating_or_clock;" if c.vkind == "icg" else "  // clock-network cell")
    ins = [p for p in c.pins if p.dir == "input"]
    for p in ins:
        attrs = []
        if p.role == "clock": attrs.append("clock = rise")
        if p.role == "scan_in": attrs.append("scan_in")
        if p.role == "scan_enable": attrs.append("scan_enable")
        nm = ("%s[%d:0]" % (p.name, p.width - 1)) if p.width > 1 else p.name
        L.append("  input (%s) (%s)" % (nm, "; ".join(attrs) + (";" if attrs else "")))
    if e.interns:
        L.append("  intern (%s) ()" % ", ".join(dict.fromkeys(e.interns)))
    for out, ln in e.lines:
        L.append("  primitive = %s;" % ln)
    for p in c.pins:
        if p.dir == "output":
            nm = ("%s[%d:0]" % (p.name, p.width - 1)) if p.width > 1 else p.name
            L.append("  output (%s) ()" % nm)
    L.append(")")
    return "\n".join(L) + "\n"

def write_atpglib(path, cells, what):
    with open(path, "w") as f:
        f.write("// %s\n// Tessent-style ATPG cell library: %s\n// primitives: _and _or _xor _inv _buf _mux(in0,in1,sel,out) "
                "_dff(set,reset,clk,data,q,qb) _dlat(set,reset,en,data,q,qb) _tie0/_tie1 _tsh(data,en,out) _cram\n\n" % (BANNER, what))
        for c in cells:
            f.write(atpg_model(c) + "\n")

def mem_atpg(m):
    """memory ATPG model with built-in BIST mux, _cram read/write ports"""
    aw, dw = m.aw, m.bits
    o = ["model %s (%s) (" % (m.name, ", ".join(p[0] for p in m.pins())), "  model_source = memory;",
         "  // TEN selects the T* (BIST) inputs; functional path otherwise"]
    for n, d, w, r in m.pins():
        o.append("  %s (%s) (%s)" % (d, n if w == 1 else "%s[%d:0]" % (n, w - 1), "clock = rise;" if r == "clock" else ""))
    tw = m.bist_map()
    for n, tn in tw.items():
        w = [p[2] for p in m.fpins() if p[0] == n][0]
        if w == 1: o.append("  intern (%s_i) (primitive = _mux (%s, %s, TEN, %s_i);)" % (n, n, tn, n))
        else: o.append("  intern (%s_i[%d:0]) (primitive = _mux (%s, %s, TEN, %s_i);)" % (n, w - 1, n, tn, n))
    o.append("  intern (Q_int) (")
    if m.kind == "sp":
        o += ["    array = %d : 0;" % (m.words - 1), "    data_size = %d;" % dw, "    address_size = %d;" % aw,
              "    primitive = _cram (, , _write {H, , } (CLK, ~WEB_i & ~CEB_i, A_i, D_i, ~BWEB_i),",
              "                            _read {, , , } (CLK, WEB_i & ~CEB_i, A_i, Q) );"]
    elif m.kind == "rf":
        o += ["    array = %d : 0;" % (m.words - 1), "    data_size = %d;" % dw, "    address_size = %d;" % aw,
              "    primitive = _cram (, , _write {H, , } (CLKB, ~CEBB_i, AB_i, D_i, ~BWEB_i),",
              "                            _read {, , , } (CLKA, ~CEBA_i, AA_i, QA) );"]
    else:
        o += ["    array = %d : 0;" % (m.words - 1), "    data_size = %d;" % dw, "    address_size = %d;" % aw,
              '    read_only; init_file = "%s.hex";' % m.name,
              "    primitive = _cram (, , _read {, , , } (CLK, ~CEB_i, A_i, Q) );"]
    o += ["  )", ")", ""]
    return "\n".join(o)

def io_atpg(c):
    pins = [p[0] for p in c.pins]
    o = ["model %s (%s) (" % (c.name, ", ".join(pins))]
    for n, d, r in c.pins:
        o.append("  %s (%s) (%s)" % (d, n, "clock = rise;" if r == "bsclk" else ""))
    if c.kind == "bidir":
        if c.bs:
            im = "I0" if c.nfunc == 1 else "im"; om = "OEN0" if c.nfunc == 1 else "om"
            if c.nfunc > 1:
                o += ["  intern (s0a, s0b, im, om) ()", "  primitive = _mux m0 (I0, I1, SEL0, s0a);", "  primitive = _mux m1 (I2, I3, SEL0, s0b);",
                      "  primitive = _mux m2 (s0a, s0b, SEL1, im);", "  primitive = _mux m3 (OEN0, OEN1, SEL0, oa);",
                      "  primitive = _mux m4 (OEN2, OEN3, SEL0, ob);", "  primitive = _mux m5 (oa, ob, SEL1, om);"]
            o += ["  intern (bs_in, bs_oe, bs_out, up_oe, up_out, d1, d2, d3, pi, po, oe) ()",
                  "  primitive = _mux c1 (PAD, BSI, SHIFTDR, d1);", "  primitive = _dff f1 (, , CLOCKDR, d1, bs_in, );",
                  "  primitive = _mux c2 (%s, bs_in, SHIFTDR, d2);" % om, "  primitive = _dff f2 (, , CLOCKDR, d2, bs_oe, );",
                  "  primitive = _mux c3 (%s, bs_oe, SHIFTDR, d3);" % im, "  primitive = _dff f3 (, , CLOCKDR, d3, bs_out, );",
                  "  primitive = _dff u1 (, , UPDATEDR, bs_oe, up_oe, );", "  primitive = _dff u2 (, , UPDATEDR, bs_out, up_out, );",
                  "  primitive = _mux md (%s, up_out, MODE, pi);" % im, "  primitive = _mux mo (%s, up_oe, MODE, po);" % om,
                  "  primitive = _inv io (po, oe);", "  primitive = _tsh t0 (pi, oe, PAD);", "  primitive = _buf b0 (bs_out, BSO);"]
        else:
            o += ["  intern (oe) ()", "  primitive = _inv i0 (OEN, oe);", "  primitive = _tsh t0 (I, oe, PAD);"]
        o.append("  primitive = _and a0 (PAD, IE, C);")
    elif c.kind == "in":
        o.append("  primitive = _and a0 (PAD, IE, C);")
        if c.bs: o += ["  intern (d1) ()", "  primitive = _mux c1 (PAD, BSI, SHIFTDR, d1);", "  primitive = _dff f1 (, , CLOCKDR, d1, BSO, );"]
    elif c.kind == "out":
        o += ["  intern (oe) ()", "  primitive = _inv i0 (OEN, oe);", "  primitive = _tsh t0 (I, oe, PAD);"]
    elif c.kind == "poc":
        o.append("  primitive = _tie0 t0 (POC);")
    o += [")", ""]
    return "\n".join(o)

def atpg_verilog(c):
    """TestMAX/structural ATPG Verilog: simulation model without specify/timing checks"""
    t = vg.model(c)
    t = re.sub(r"\n  specify.*?endspecify", "", t, flags=re.S)
    t = t.replace("reg notifier;", "supply0 notifier;").replace("reg notifier; wire", "supply0 notifier; wire")
    return t

# ------------------------------------------------------------------ golden ROM signature (must match RTL MISR)
POLY = {32: 0x04C11DB7, 64: 0x42F0E1EBA9EA3693}
def misr(words, dw):
    p = POLY[dw]; s = 0; mask = (1 << dw) - 1
    for w in words:
        fb = (s >> (dw - 1)) & 1
        s = (((s << 1) & mask) ^ (p if fb else 0)) ^ w
    return s

def rom_signatures(mems):
    out = ["# R14N7 ROM golden MISR signatures (MISR: s' = (s<<1) ^ (msb ? POLY : 0) ^ Q, s0 = 0, addresses 0..N-1 ascending)",
           "# POLY32 = 0x04C11DB7, POLY64 = 0x42F0E1EBA9EA3693", "# instance  words  bits  signature"]
    for m in mems:
        if m.kind == "rom":
            out.append("%s %d %d %0*X" % (m.name, m.words, m.bits, m.bits // 4, misr(m.data, m.bits)))
    return "\n".join(out) + "\n"

# ------------------------------------------------------------------ RTL
MBIST = r"""// R14N7 memory BIST controller: March C- on the built-in T* port of R14SRAM_SP_* macros.
// Elements: up(w0); up(r0,w1); up(r1,w0); down(r0,w1); down(r1,w0); up(r0)  -- run for each data background.
// Backgrounds: solid (0/1) and checkerboard-by-bit (0101.. / 1010..).  Read data is compared one cycle later.
`timescale 1ps/1fs
module r14n7_mbist_sp #(parameter AW = 8, DW = 32, WORDS = 256) (
  input  wire          clk, rst_n, start,
  output reg           done, fail,
  output reg  [AW-1:0] fail_addr,
  output reg  [3:0]    fail_elem,
  // to memory BIST port
  output reg           ten, tceb, tweb,
  output reg  [AW-1:0] ta,
  output reg  [DW-1:0] td, tbweb,
  input  wire [DW-1:0] q
);
  localparam IDLE = 0, RUN = 1, FIN = 2;
  reg [1:0]    st;
  reg [2:0]    elem;            // 0..5 March elements
  reg          bg;              // background 0 = solid, 1 = checkerboard
  reg          ph;              // phase inside a 2-op element (0 = first op, 1 = second op)
  reg [AW-1:0] addr;
  reg          chk; reg [DW-1:0] exp_d; reg [AW-1:0] chk_a;
  wire [DW-1:0] B = bg ? {(DW/2){2'b01}} : {DW{1'b0}};
  wire          down = (elem == 3) || (elem == 4);
  // op table: elem: 0 w0 | 1 r0 w1 | 2 r1 w0 | 3 r0 w1 | 4 r1 w0 | 5 r0
  wire two = (elem >= 1) && (elem <= 4);
  wire       op_rd  = (elem == 5) || (two && !ph);
  wire       op_val = (elem == 0) ? 1'b0 : (elem == 5) ? 1'b0 : (ph ? ((elem == 1 || elem == 3) ? 1'b1 : 1'b0)
                                                              : ((elem == 1 || elem == 3) ? 1'b0 : 1'b1));
  wire last_a = down ? (addr == 0) : (addr == WORDS - 1);
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= IDLE; done <= 0; fail <= 0; fail_addr <= 0; fail_elem <= 0; ten <= 0; tceb <= 1; tweb <= 1;
      ta <= 0; td <= 0; tbweb <= {DW{1'b1}}; elem <= 0; bg <= 0; ph <= 0; addr <= 0; chk <= 0;
    end else begin
      // compare read data issued in the previous cycle
      if (chk && (q !== exp_d) && !fail) begin fail <= 1; fail_addr <= chk_a; fail_elem <= {bg, elem}; end
      chk <= 0;
      case (st)
        IDLE: if (start) begin st <= RUN; ten <= 1; elem <= 0; bg <= 0; ph <= 0; addr <= 0; done <= 0; fail <= 0; end
        RUN: begin
          tceb <= 0; ta <= addr; tbweb <= {DW{1'b0}};
          if (op_rd) begin tweb <= 1; chk <= 1; exp_d <= op_val ? ~B : B; chk_a <= addr; end
          else       begin tweb <= 0; td <= op_val ? ~B : B; end
          if (two && !ph) ph <= 1;
          else begin
            ph <= 0;
            if (last_a) begin
              if (elem == 5) begin
                if (bg) st <= FIN; else begin bg <= 1; elem <= 0; addr <= 0; end
              end else begin
                elem <= elem + 1;
                addr <= ((elem + 1) == 3 || (elem + 1) == 4) ? WORDS - 1 : 0;
              end
            end else addr <= down ? addr - 1 : addr + 1;
          end
        end
        FIN: begin tceb <= 1; tweb <= 1; if (!chk) begin done <= 1; ten <= 0; st <= IDLE; end end
      endcase
    end
  end
endmodule

// ROM BIST: reads every address through the T* port and compacts Q into a MISR; compare with golden.
module r14n7_rombist #(parameter AW = 9, DW = 32, WORDS = 512, parameter [DW-1:0] POLY = 32'h04C11DB7,
                       parameter [DW-1:0] GOLDEN = 0) (
  input  wire          clk, rst_n, start,
  output reg           done, fail,
  output reg  [DW-1:0] sig,
  output reg           ten, tceb,
  output reg  [AW-1:0] ta,
  input  wire [DW-1:0] q
);
  reg run, cap; reg [AW:0] n;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin done <= 0; fail <= 0; sig <= 0; ten <= 0; tceb <= 1; ta <= 0; run <= 0; cap <= 0; n <= 0; end
    else begin
      if (cap) sig <= ({sig[DW-2:0], 1'b0} ^ (sig[DW-1] ? POLY : {DW{1'b0}})) ^ q;
      cap <= 0;
      if (start && !run && !done) begin run <= 1; ten <= 1; n <= 0; sig <= 0; end
      else if (run) begin
        if (n < WORDS) begin tceb <= 0; ta <= n[AW-1:0]; cap <= 1; n <= n + 1; end
        else begin tceb <= 1; run <= 0; end
      end else if (ten && !cap && !done && n == WORDS) begin done <= 1; ten <= 0; end
      if (done) fail <= (sig !== GOLDEN);
    end
  end
endmodule
"""

LBIST = r"""// R14N7 logic-BIST building blocks: Fibonacci PRPG (LFSR) with phase shifter tap-out and a MISR.
`timescale 1ps/1fs
module r14n7_prpg #(parameter W = 32, parameter [W-1:0] POLY = 32'h80200003, parameter [W-1:0] SEED = 32'h1) (
  input wire clk, rst_n, en, output reg [W-1:0] lfsr);
  always @(posedge clk or negedge rst_n)
    if (!rst_n) lfsr <= SEED;
    else if (en) lfsr <= {lfsr[W-2:0], ^(lfsr & POLY)};
endmodule

module r14n7_misr #(parameter W = 32, parameter [W-1:0] POLY = 32'h04C11DB7) (
  input wire clk, rst_n, en, input wire [W-1:0] d, output reg [W-1:0] sig);
  always @(posedge clk or negedge rst_n)
    if (!rst_n) sig <= 0;
    else if (en) sig <= ({sig[W-2:0], 1'b0} ^ (sig[W-1] ? POLY : {W{1'b0}})) ^ d;
endmodule

// STUMPS-style controller: N patterns, each shifted for CHAIN_LEN cycles (SE=1) then 1 capture (SE=0)
module r14n7_lbist_ctrl #(parameter CHAIN_LEN = 16, parameter NPAT = 1024) (
  input wire clk, rst_n, start, output reg se, output reg running, output reg done);
  reg [15:0] sh; reg [31:0] pat;
  always @(posedge clk or negedge rst_n)
    if (!rst_n) begin se <= 0; running <= 0; done <= 0; sh <= 0; pat <= 0; end
    else if (start && !running && !done) begin running <= 1; se <= 1; sh <= 0; pat <= 0; end
    else if (running) begin
      if (se) begin if (sh == CHAIN_LEN - 1) begin se <= 0; sh <= 0; end else sh <= sh + 1; end
      else begin pat <= pat + 1; if (pat == NPAT - 1) begin running <= 0; done <= 1; end else se <= 1; end
    end
endmodule
"""

def tb_sram(m, fault):
    return r"""`timescale 1ps/1fs
module tb_mbist_%(nm)s%(sfx)s;
  reg clk = 0, rst_n = 0, start = 0; always #500 clk = ~clk;
  wire done, fail, ten, tceb, tweb; wire [%(aw1)d:0] ta, fa; wire [3:0] fe; wire [%(dw1)d:0] td, tbweb, q;
  r14n7_mbist_sp #(.AW(%(aw)d), .DW(%(dw)d), .WORDS(%(w)d)) u_bist (.clk(clk), .rst_n(rst_n), .start(start), .done(done), .fail(fail),
      .fail_addr(fa), .fail_elem(fe), .ten(ten), .tceb(tceb), .tweb(tweb), .ta(ta), .td(td), .tbweb(tbweb), .q(q));
  %(nm)s u_mem (.CLK(clk), .CEB(1'b1), .WEB(1'b1), .A({%(aw)d{1'b0}}), .D({%(dw)d{1'b0}}), .BWEB({%(dw)d{1'b1}}), .Q(q),
      .TEN(ten), .TCEB(tceb), .TWEB(tweb), .TA(ta), .TD(td), .TBWEB(tbweb));
  %(inject)s
  initial begin
    #2200 rst_n = 1; #1000 start = 1; #1000 start = 0;
    wait (done);
    $display("MBIST %(nm)s %(what)s: done=%%b fail=%%b fail_addr=%%0d elem=%%0d -> %%s", done, fail, fa, fe,
             (fail == %(expfail)d) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #(%(tmo)d * 1000); $display("MBIST %(nm)s TIMEOUT"); $finish; end
endmodule
""" % dict(nm=m.name, sfx="_fault" if fault else "", aw=m.aw, aw1=m.aw - 1, dw=m.bits, dw1=m.bits - 1, w=m.words,
           what="stuck-at-1 injected at addr 5 bit 3" if fault else "fault-free", expfail=1 if fault else 0,
           tmo=m.words * 24 + 500,
           inject="always @(negedge clk) if (rst_n) u_mem.mem[5][3] = 1'b1;" if fault else "")

def tb_rom(m, fault):
    sig = misr(m.data, m.bits)
    return r"""`timescale 1ps/1fs
module tb_rombist_%(nm)s%(sfx)s;
  reg clk = 0, rst_n = 0, start = 0; always #500 clk = ~clk;
  wire done, fail, ten, tceb; wire [%(aw1)d:0] ta; wire [%(dw1)d:0] q, sig;
  r14n7_rombist #(.AW(%(aw)d), .DW(%(dw)d), .WORDS(%(w)d), .POLY(%(dw)d'h%(poly)X), .GOLDEN(%(dw)d'h%(gold)X)) u_bist (
      .clk(clk), .rst_n(rst_n), .start(start), .done(done), .fail(fail), .sig(sig), .ten(ten), .tceb(tceb), .ta(ta), .q(q));
  %(nm)s u_rom (.CLK(clk), .CEB(1'b1), .A({%(aw)d{1'b0}}), .Q(q), .TEN(ten), .TCEB(tceb), .TA(ta));
  initial begin
    #2200 %(inject)s rst_n = 1; #1000 start = 1; #1000 start = 0;
    wait (done); #2000;
    $display("ROMBIST %(nm)s %(what)s: signature=%%h golden=%(gold)X fail=%%b -> %%s", sig, fail, (fail == %(expfail)d) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #(%(tmo)d * 1000); $display("ROMBIST %(nm)s TIMEOUT"); $finish; end
endmodule
""" % dict(nm=m.name, sfx="_fault" if fault else "", aw=m.aw, aw1=m.aw - 1, dw=m.bits, dw1=m.bits - 1, w=m.words,
           poly=POLY[m.bits], gold=sig, what="code bit flipped at addr 7" if fault else "golden code", expfail=1 if fault else 0,
           tmo=m.words * 3 + 500, inject="u_rom.mem[7][0] = ~u_rom.mem[7][0];" if fault else "")

README = r"""# R14N7 DFT kit

## ATPG models

- `atpg/tessent/*.atpglib` are Tessent-style cell-library models for every std, PMK, DFT, memory and IO cell. They are built from primitives: `_and _or _xor _inv _buf _mux _dff _dlat _tsh _cram _tie0/1`.
- Scan cells carry a `scan_definition` block (mux_scan, SI/SE/Q, `non_scan_model` mapping SDFF*->DFF*).
- ICGs, retention cells (clock = CK&NRET), multi-bit cells (per-bit `_dff`) and the two-stage WBR/BSC cells are modelled at primitive level.
- `atpg/verilog/*.v` holds structural/UDP simulation models without specify blocks or notifiers. Use them for TestMAX/TetraMAX `read_netlist -library` and for fault simulation.
- Memories use `_cram` read/write ports behind the built-in BIST mux (TEN). ROMs are read-only and initialised from `memory/rom_code/<inst>.hex`.

## DFT library cells (all Vt, all views)

| Cell | Purpose |
|---|---|
| LOCKUP_X1/2/4 (low-transparent), LOCKUPP_X1/2/4 (high-transparent) | Scan lock-up latches between clock domains or edges |
| TPCTL0 / TPCTL1 | Control test points: force-0/force-1 when TE=1 and the cell's own scan flop holds 1. The flop holds in capture and loads SI in shift. |
| TPOBS | Observe test point: dedicated scan flop capturing net A |
| WBRCELL | IEEE 1500 wrapper boundary cell: CFI/CFO, WSI/WSO, SHIFTWR/CAPTUREWR on WRCK, UPDATEWR update stage, WMODE |
| BSCELL | IEEE 1149.1 BC_1 boundary-scan cell: PI/PO, TDI/TDO, SHIFTDR on CLOCKDR, UPDATEDR, MODE |
| SDFF*, MBSDFF* (2-32 bit, per-bit SI), RETSDFF*, ICGPRE/POST (+OBS) | Scan flops and DFT-aware clock gating (test-enable pre/post latch, observability pin Q) |

## Memory BIST

- Every SRAM/RF macro has a built-in BIST port: `TEN` selects TCEB/TWEB/TA/TD/TBWEB (RF: TCEBA/TAA/TCEBB/TAB/TD/TBWEB).
- Every ROM has TEN/TCEB/TA.
- `rtl/r14n7_mbist.v`:
  - `r14n7_mbist_sp` runs March C- with solid and checkerboard backgrounds and reports `fail_addr`/`fail_elem`.
  - `r14n7_rombist` compacts every ROM word into a MISR and compares it with the golden signature in `r14n7_rom_signatures.txt`. The generator computes those signatures with the same polynomial.
- `rtl/r14n7_lbist.v`: PRPG (LFSR), MISR and a STUMPS shift/capture controller for logic BIST.
- `tb/`: self-checking testbenches. Each memory is run once fault-free (must pass) and once with an injected stuck-at or ROM-code fault (must fail). Run them with `flows/verify/run_bist.sh`.

## IO boundary scan

`PGPIO18MUX4BS` (4-way pin-mux GPIO), `PBIDIR18BS` and `PIN18BS` contain IEEE 1149.1 BSR cells, chained BSI -> BC_4 input -> BC_1 control -> BC_1 output -> BSO. `io/bsdl/r14n7_io18_bsr.bsdl` has the BOUNDARY_REGISTER fragments to paste into a chip BSDL. Chain the pads' BSI/BSO through the ring and drive SHIFTDR/CLOCKDR/UPDATEDR/MODE from the TAP controller.
"""
