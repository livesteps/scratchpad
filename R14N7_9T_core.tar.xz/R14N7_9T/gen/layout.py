"""GDSII (gdstk) device-level FEOL + pin-level BEOL layouts, cell LEF and technology LEF.
Each transistor finger in the netlist is placed on a CPP gate column; fins/active/select/
well/Vt implant/gate/gate-cut/trench-contact/gate-contact are drawn on the R14N7 grid and
are DRC-clean against tech.RULES (checked by verify/drc_check.py).  Intra-cell M0/M1
wiring is NOT drawn (pins + rails only) -- see doc 'Physical views'."""
import math
import gdstk
from tech import (M1_P, M1_OFF, M2_P, CPP, ROW_H, FIN_P, FIN_W, GATE_L, M1_W, RAIL_W, L, PIN_DT, TEXT_DT, METALS, VIAS,
                  VT_FLAVORS, BANNER, SITE_NAME, SITE_W_UM, SITE_H_UM, METAL_RC)

NM = 1e-3   # nm -> um

def R(cell, lay, x0, y0, x1, y1, dt=None):
    l, d = L(lay)
    cell.add(gdstk.rectangle((x0 * NM, y0 * NM), (x1 * NM, y1 * NM), layer=l, datatype=d if dt is None else dt))

def T(cell, lay, txt, x, y):
    l, d = L(lay)
    cell.add(gdstk.Label(txt, (x * NM, y * NM), layer=l, texttype=TEXT_DT))

# row-local geometry, derived from the track variant (unflipped row: VSS at bottom)
from tech import FINS_PER_ROW, FINS_PER_DEV
def finlo(k): return FIN_P * k + (FIN_P - FIN_W) // 2
def finhi(k): return finlo(k) + FIN_W
N_ACT = (finlo(1) - 5, finhi(FINS_PER_DEV) + 5)
P_ACT = (finlo(FINS_PER_ROW - 1 - FINS_PER_DEV) - 5, finhi(FINS_PER_ROW - 2) + 5)
NW_Y = ROW_H // 2
GATE_Y = (N_ACT[0] - 15, P_ACT[1] + 15)
GCUT_Y = (NW_Y - 12, NW_Y + 12)
_mid = (N_ACT[0] + N_ACT[1]) // 2
LIG_Y = (_mid - 8, _mid + 8)            # gate contact over active (COAG)
PIN_Y = (69, ROW_H - 69)                # >= EOL space to rails, spans >= 3 M2 tracks

def row_y(r, y):
    """map row-local y to absolute y, rows alternate flip"""
    base = r * ROW_H
    return base + (y if r % 2 == 0 else ROW_H - y)

def ry(r, a, b):
    y0, y1 = row_y(r, a), row_y(r, b)
    return (min(y0, y1), max(y0, y1))

def rails(c):
    """[(name, y_center)] rails at every row boundary"""
    out = []
    for r in range(c.rows + 1):
        out.append(("VSS" if r % 2 == 0 else "VDD", r * ROW_H))
    return out

def pin_slots(c):
    W = c.sites * CPP
    return [M1_OFF + M1_P * j for j in range(c.sites)]     # one on-grid M1 track per site

def assign_columns(c):
    """place n and p fingers on gate columns, row by row"""
    cols = []   # per row: list of (gate_n, gate_p)
    ndev = [d for d in c.nb.devs if d.t == "n"]
    pdev = [d for d in c.nb.devs if d.t == "p"]
    nf = [d.g for d in ndev for _ in range(d.nf)]
    pf = [d.g for d in pdev for _ in range(d.nf)]
    ncol = max(len(nf), len(pf))
    per = int(math.ceil(ncol / float(c.rows))) if ncol else 0
    for r in range(c.rows):
        cl = []
        for k in range(per):
            i = r * per + k
            cl.append((nf[i] if i < len(nf) else None, pf[i] if i < len(pf) else None))
        cols.append(cl)
    return cols

def draw_cell(lib_cell, c):
    W = c.sites * CPP; H = c.rows * ROW_H
    g = lib_cell
    R(g, "PRBNDRY", 0, 0, W, H)
    vtimp = VT_FLAVORS.get(c.vt, {}).get("implant")
    if vtimp: R(g, vtimp, 0, 0, W, H)
    cols = assign_columns(c)
    has_dev = bool(c.nb.devs)
    for r in range(c.rows):
        # wells / selects
        a, b = ry(r, NW_Y, ROW_H); R(g, "NWELL", 0, a, W, b)
        a, b = ry(r, 0, NW_Y); R(g, "NSELECT", 0, a, W, b)
        a, b = ry(r, NW_Y, ROW_H); R(g, "PSELECT", 0, a, W, b)
        # fins (full width, FINS_PER_ROW per row)
        for k in range(FINS_PER_ROW):
            a, b = ry(r, finlo(k), finhi(k)); R(g, "FIN", 0, a, W, b)
        # active
        from cells import GA_UNIT
        tiles = [(t * GA_UNIT * CPP, (t + 1) * GA_UNIT * CPP) for t in range(c.sites // GA_UNIT)] if c.family == "ga" else [(0, W)]
        if has_dev and W >= 108:
            for (tx0, tx1) in tiles:
                for (ya, yb) in (N_ACT, P_ACT):
                    a, b = ry(r, ya, yb); R(g, "ACTIVE", tx0 + 27, a, tx1 - 27, b)
        # gates on every CPP boundary; edge gates are dummies centred on the boundary
        for i in range(c.sites + 1):
            x = i * CPP
            a, b = ry(r, *GATE_Y)
            R(g, "GATE", x - GATE_L // 2, a, x + GATE_L // 2, b)   # boundary dummies shared on abutment
        # device columns: gates at x = (k+1)*CPP
        if has_dev and W >= 108:
            cuts = []
            ga = c.family == "ga"
            from cells import GA_UNIT
            if ga:     # GA: fixed base, devices on every column except tile boundaries
                xs = [k * CPP for k in range(1, c.sites) if k % GA_UNIT]
                colset = [(None, None)] * len(xs)
            else:
                colset = cols[r]; xs = [(k + 1) * CPP for k in range(len(colset))]
            for x, (gn, gp) in zip(xs, colset):
                if x >= W: break
                if gn != gp or ga: cuts.append(x)
                a, b = ry(r, *LIG_Y); R(g, "LIG", x - 8, a, x + 8, b)
                if ga:
                    pm = (P_ACT[0] + P_ACT[1]) // 2
                    a, b = ry(r, pm - 8, pm + 8); R(g, "LIG", x - 8, a, x + 8, b)
            runs = []
            for x in cuts:
                if runs and x - runs[-1][1] <= (CPP if ga else 2 * CPP): runs[-1][1] = x
                else: runs.append([x, x])
            for x0, x1 in runs:
                a, b = ry(r, *GCUT_Y); R(g, "GCUT", x0 - 12, a, x1 + 12, b)
            # trench contacts between gates
            for i in range(c.sites):
                x = i * CPP + CPP // 2
                if not any(x - 12 >= tx0 + 27 and x + 12 <= tx1 - 27 for (tx0, tx1) in tiles): continue
                for (ya, yb) in (N_ACT, P_ACT):
                    a, b = ry(r, ya, yb); R(g, "LISD", x - 12, a, x + 12, b)
    # rails (M1, 54 wide, centred on row boundaries)
    for nm, y in rails(c):
        R(g, "M1", 0, y - RAIL_W // 2, W, y + RAIL_W // 2)
        R(g, "M1", 0, y - RAIL_W // 2, W, y + RAIL_W // 2, dt=PIN_DT)
        T(g, "M1", nm, W / 2.0, y)
    # markers
    if c.rows > 1: R(g, "MROWMK", 0, 0, W, H)
    if c.family == "pmk_lvl": R(g, "LVLMK", 0, 0, W, H)
    if c.family == "pmk_psw": R(g, "PSWMK", 0, 0, W, H)
    if c.family in ("pmk_aon", "pmk_ret"): R(g, "AONMK", 0, 0, W, H)
    if c.family == "ga": R(g, "GAMK", 0, 0, W, H)
    # signal + secondary PG pins on M1 tracks
    pins = []
    for p in c.pins:
        if p.width > 1: pins += ["%s[%d]" % (p.name, b) for b in range(p.width)]
        else: pins.append(p.name)
    pins += [n for n, t, v in c.pg if n not in ("VDD", "VSS")]
    slots = pin_slots(c)
    shapes = {}
    per_row = int(math.ceil(len(pins) / float(c.rows))) if pins else 0
    for i, pn in enumerate(pins):
        r = i // per_row if per_row else 0
        k = i - r * per_row
        if k >= len(slots): k = k % len(slots)
        x = slots[int(k * len(slots) / max(per_row, 1))] if per_row <= len(slots) else slots[k]
        y0, y1 = ry(r, *PIN_Y)
        R(g, "M1", x - M1_W // 2, y0, x + M1_W // 2, y1)
        R(g, "M1", x - M1_W // 2, y0, x + M1_W // 2, y1, dt=PIN_DT)
        T(g, "M1", pn, x, (y0 + y1) / 2.0)
        shapes[pn] = (x - M1_W // 2, y0, x + M1_W // 2, y1)
    return shapes

def build_gds(path, cells, libname):
    lib = gdstk.Library(libname, unit=1e-6, precision=1e-10)
    allshapes = {}
    for c in cells:
        g = lib.new_cell(c.name)
        allshapes[c.name] = draw_cell(g, c)
    lib.write_gds(path)
    return allshapes

# ---------------------------------------------------------------------- LEF
def lef_class(c):
    b = c.base
    if b.startswith(("FILL", "GFILL")): return "CORE SPACER"
    if b.startswith(("DCAP", "GDCAP")): return "CORE SPACER"
    if b.startswith("WELLTAP"): return "CORE WELLTAP"
    if b == "ENDCAPLEFT": return "ENDCAP PRE"
    if b == "ENDCAPRIGHT": return "ENDCAP POST"
    if b in ("ENDCAPTL", "ENDCAPTR", "ENDCAPBL", "ENDCAPBR"):
        return "ENDCAP " + {"TL": "TOPLEFT", "TR": "TOPRIGHT", "BL": "BOTTOMLEFT", "BR": "BOTTOMRIGHT"}[b[-2:]]
    if b.startswith(("ENDCAPTOP", "ENDCAPBOTTOM")): return "CORE SPACER"
    if b in ("TIEHI", "GTIEHI"): return "CORE TIEHIGH"
    if b in ("TIELO", "GTIELO"): return "CORE TIELOW"
    if b == "ANTENNA": return "CORE ANTENNACELL"
    return "CORE"

WFIN_UM = (2 * 32 + 6.5) / 1000.0   # effective fin width (2*Hfin + Tfin)

def write_lef(path, cells, shapes):
    o = ["# " + BANNER, "VERSION 5.8 ;", 'BUSBITCHARS "[]" ;', 'DIVIDERCHAR "/" ;', "",
         "PROPERTYDEFINITIONS", "  MACRO LEF58_EDGETYPE STRING ;", "  MACRO LEF58_CLASS STRING ;", "END PROPERTYDEFINITIONS", ""]
    for c in cells:
        W = c.width_um; H = c.height_um
        o += ["MACRO %s" % c.name, "  CLASS %s ;" % lef_class(c), "  ORIGIN 0 0 ;", "  FOREIGN %s 0 0 ;" % c.name,
              "  SIZE %.3f BY %.3f ;" % (W, H), "  SYMMETRY X Y ;", "  SITE %s ;" % SITE_NAME]
        et = "GAP" if c.base.startswith(("ENDCAPLEFT", "ENDCAPRIGHT")) else "DDB"
        o.append('  PROPERTY LEF58_EDGETYPE "EDGETYPE LEFT %s ; EDGETYPE RIGHT %s ;" ;' % (et, et))
        if c.base.startswith(("ENDCAPTOP", "ENDCAPBOTTOM")):
            o.append('  PROPERTY LEF58_CLASS "CLASS CORE ENDCAP %s ;" ;' % ("TOP" if "TOP" in c.base else "BOTTOM"))
        sh = shapes.get(c.name, {})
        for p in c.pins:
            names = ["%s[%d]" % (p.name, b) for b in range(p.width)] if p.width > 1 else [p.name]
            for n in names:
                if n not in sh: continue
                x0, y0, x1, y1 = sh[n]
                use = "CLOCK" if p.role == "clock" else "SIGNAL"
                o += ["  PIN %s" % n, "    DIRECTION %s ;" % p.dir.upper(), "    USE %s ;" % use]
                if p.dir == "input":
                    key = p.name if p.width == 1 else "%s<%d>" % (p.name, 0)
                    ga = sum(d.nfin * d.nf * d.l * 1e-3 * WFIN_UM for d in c.nb.devs if d.g in (p.name, key))
                    if ga: o.append("    ANTENNAGATEAREA %.6f LAYER M1 ;" % ga)
                else:
                    o.append("    ANTENNADIFFAREA %.6f LAYER M1 ;" % (0.002 * max(1, c.sites)))
                o += ["    PORT", "      LAYER M1 ;", "        RECT %.3f %.3f %.3f %.3f ;" % (x0 * NM, y0 * NM, x1 * NM, y1 * NM),
                      "    END", "  END %s" % n]
        for n, t, v in c.pg:
            use = "GROUND" if "ground" in t else "POWER"
            o += ["  PIN %s" % n, "    DIRECTION INOUT ;", "    USE %s ;" % use]
            if n in ("VDD", "VSS"):
                o.append("    SHAPE ABUTMENT ;"); o += ["    PORT", "      LAYER M1 ;"]
                for nm, y in rails(c):
                    if nm == n:
                        o.append("        RECT 0.000 %.3f %.3f %.3f ;" % ((y - RAIL_W / 2) * NM, W, (y + RAIL_W / 2) * NM))
                o += ["    END"]
            elif n in sh:
                x0, y0, x1, y1 = sh[n]
                o += ["    PORT", "      LAYER M1 ;", "        RECT %.3f %.3f %.3f %.3f ;" % (x0 * NM, y0 * NM, x1 * NM, y1 * NM), "    END"]
            o.append("  END %s" % n)
        o += ["  OBS", "    LAYER LISD ;", "      RECT 0.000 0.030 %.3f %.3f ;" % (W, H - 0.030), "  END", "END %s" % c.name, ""]
    o.append("END LIBRARY")
    open(path, "w").write("\n".join(o) + "\n")

# ---------------------------------------------------------------- technology LEF
from tech import FIN_P as _FP, FIN_W as _FW, ROW_H as _RH, VARIANT as _VAR, FINS_PER_ROW as _FROW, FINS_PER_DEV as _FDEV
MP_LAYERS = {"M2": 2, "M3": 2, "V1": 2}           # double-patterned (LELE) layers
# per-layer reliability (DC average current density, mA/um at 105C; AC RMS/peak)
JDC = {"M1": 1.6, "M2": 1.6, "M3": 1.6, "M4": 2.2, "M5": 2.2, "M6": 3.0, "M7": 3.0, "M8": 4.2, "M9": 4.2}
# DC limit per single cut (mA), written as mA/um^2 of cut area in the LEF
JCUT = {"V1": 0.10, "V2": 0.10, "V3": 0.12, "V4": 0.20, "V5": 0.20, "V6": 0.20, "V7": 0.30, "V8": 0.50, "V9": 40.0}  # mA per cut

def write_techlef(path):
    f3 = lambda nm: "%.4f" % (nm * NM)
    o = ["# " + BANNER, "# Technology LEF, %s variant: row %d nm, fin pitch %d nm, M2 pitch %d nm" % (_VAR, _RH, _FP, METALS[1][2]),
         "VERSION 5.8 ;", 'BUSBITCHARS "[]" ;', 'DIVIDERCHAR "/" ;', "",
         "PROPERTYDEFINITIONS",
         "  LAYER LEF58_TYPE STRING ;", "  LAYER LEF58_SPACING STRING ;", "  LAYER LEF58_EOLKEEPOUT STRING ;",
         "  LAYER LEF58_CORNERSPACING STRING ;", "  LAYER LEF58_MINSTEP STRING ;", "  LAYER LEF58_CUTCLASS STRING ;",
         "  LAYER LEF58_ENCLOSURE STRING ;", "  LAYER LEF58_RIGHTWAYONGRIDONLY STRING ;", "  LAYER LEF58_RECTONLY STRING ;",
         "  LAYER LEF58_WIDTHTABLE STRING ;", "  LAYER R14_FINFET STRING ;", "  LAYER R14_COLOR STRING ;",
         "  LIBRARY LEF58_CELLEDGESPACINGTABLE STRING ;", "  LIBRARY R14_FINGRID STRING ;",
         "  MACRO LEF58_EDGETYPE STRING ;", "  MACRO LEF58_CLASS STRING ;",
         "END PROPERTYDEFINITIONS", "",
         "UNITS", "  DATABASE MICRONS 4000 ;", "  CAPACITANCE PICOFARADS 1 ;", "  RESISTANCE OHMS 1 ;", "  CURRENT MILLIAMPS 1 ;", "END UNITS",
         "MANUFACTURINGGRID 0.001 ;", "",
         "# FinFET grid: fins on a global %d nm grid, %d fins per %d nm row, %d fins per device finger; CPP %d nm, Lg %d nm" % (_FP, _FROW, _RH, _FDEV, CPP, GATE_L),
         'PROPERTY R14_FINGRID "FINPITCH %s FINWIDTH %s FINOFFSET %s FINSPERROW %d FINSPERDEVICE %d CPP %s GATELENGTH %s ;" ;' % (
             f3(_FP), f3(_FW), f3((_FP - _FW) / 2.0 + _FW / 2.0), _FROW, _FDEV, f3(CPP), f3(GATE_L)),
         "# cell-edge spacing: Vt implant islands must be >= 1 CPP wide; DDB edges abut, GAP edges need 1 site filler",
         'PROPERTY LEF58_CELLEDGESPACINGTABLE "CELLEDGESPACINGTABLE NODEFAULT EDGETYPE DDB DDB 0.000 EDGETYPE DDB GAP %s EDGETYPE VTEDGE VTEDGE %s EXCEPTABUTTED ;" ;' % (f3(CPP), f3(CPP)),
         ""]
    # ---- sites
    sites = [("coreSite", "CORE", "Y", CPP, _RH, "standard 1-row placement site (1 CPP x 1 row)"),
             ("coreSite2R", "CORE", "X Y", CPP, 2 * _RH, "double-row site (multi-row cells: MB16, LVLLH, *MR, *2S)"),
             ("coreSite4R", "CORE", "X Y", CPP, 4 * _RH, "quad-row site (MB32, *MR16)"),
             ("gaSite", "CORE", "Y", 4 * CPP, _RH, "gate-array ECO tile (GFILL/GDCAP/G* cells snap to 4 sites)"),
             ("memSite", "CORE", "X Y", 2 * CPP, _RH, "memory-macro placement grid (keeps M3/M5 pins on-track)"),
             ("ioSite", "PAD", "R90", 1000, 120000, "pad-ring site"), ("cornerSite", "PAD", "X Y R90", 120000, 120000, "pad-ring corner site")]
    for n, cl, sym, w, h, d in sites:
        o += ["# %s" % d, "SITE %s" % n, "  CLASS %s ;" % cl, "  SYMMETRY %s ;" % sym, "  SIZE %s BY %s ;" % (f3(w), f3(h)), "END %s" % n, ""]
    # ---- FEOL masterslice layers (for completeness / extraction)
    o += ["LAYER FIN", "  TYPE MASTERSLICE ;", "  PROPERTY LEF58_TYPE \"TYPE FIN ;\" ;",
          '  PROPERTY R14_FINFET "PITCH %s WIDTH %s DIRECTION HORIZONTAL ;" ;' % (f3(_FP), f3(_FW)), "END FIN", "",
          "LAYER GATE", "  TYPE MASTERSLICE ;", '  PROPERTY R14_FINFET "PITCH %s WIDTH %s DIRECTION VERTICAL GATECUT 0.024 ;" ;' % (f3(CPP), f3(GATE_L)), "END GATE", "",
          "LAYER LISD", "  TYPE MASTERSLICE ;", "END LISD", "", "LAYER LIG", "  TYPE MASTERSLICE ;", "END LIG", "",
          "LAYER V0", "  TYPE CUT ;", "  SPACING 0.018 ;", "  WIDTH 0.018 ;", "END V0", ""]
    for i, (m, d, p, w, sp, t, off) in enumerate(METALS):
        rs, cap = METAL_RC[m]
        maxw = {"M1": 4, "M2": 4, "M3": 4}.get(m, 12) * w
        nmask = MP_LAYERS.get(m, 1)
        o += ["LAYER %s" % m, "  TYPE ROUTING ;", "  DIRECTION %s ;" % d, "  PITCH %s ;" % f3(p), "  OFFSET %s ;" % f3(off),
              "  WIDTH %s ;" % f3(w), "  MINWIDTH %s ;" % f3(w), "  MAXWIDTH %s ;" % f3(maxw)]
        if nmask > 1:
            same = 2 * p - w
            o += ["  MASK %d ;" % nmask, '  PROPERTY R14_COLOR "LELE MASKS 2 SAMEMASKSPACING %s DIFFMASKSPACING %s TRACKCOLORING ALTERNATE START 1 ;" ;' % (f3(same), f3(sp)),
                  '  PROPERTY LEF58_SPACING "SPACING %s SAMEMASK ;" ;' % f3(same)]
        o += ["  SPACING %s ;" % f3(sp),
              "  SPACING %s ENDOFLINE %s WITHIN %s ;" % (f3(sp + 6), f3(w + 2), f3(sp / 2.0)),
              "  # length/width-based spacing (parallel run length table)",
              "  SPACINGTABLE", "    PARALLELRUNLENGTH 0.000 %s %s %s" % (f3(4 * p), f3(10 * p), f3(40 * p)),
              "      WIDTH 0.000     %s %s %s %s" % (f3(sp), f3(sp), f3(sp), f3(sp)),
              "      WIDTH %s %s %s %s %s" % (f3(2 * w), f3(sp), f3(sp * 1.25), f3(sp * 1.5), f3(sp * 1.5)),
              "      WIDTH %s %s %s %s %s ;" % (f3(4 * w), f3(sp), f3(sp * 1.5), f3(sp * 2), f3(sp * 3)),
              '  PROPERTY LEF58_EOLKEEPOUT "EOLKEEPOUT %s EXTENSION %s %s %s ;" ;' % (f3(sp + 6), f3(w), f3(w / 2.0), f3(sp)),
              '  PROPERTY LEF58_CORNERSPACING "CORNERSPACING CONVEXCORNER EXCEPTEOL %s WIDTH 0.000 SPACING %s ;" ;' % (f3(w + 2), f3(sp)),
              '  PROPERTY LEF58_MINSTEP "MINSTEP %s MAXEDGES 1 ;" ;' % f3(w),
              '  PROPERTY LEF58_RIGHTWAYONGRIDONLY "RIGHTWAYONGRIDONLY ;" ;' if m in ("M1", "M2", "M3") else "",
              '  PROPERTY LEF58_RECTONLY "RECTONLY ;" ;' if m in ("M1", "M2", "M3") else "",
              "  AREA %s ;" % ("%.6f" % ((1000 if m == "M1" else 12 * w * w) * 1e-6)),
              "  MINENCLOSEDAREA %s ;" % ("%.6f" % (4 * w * w * 4e-6)),
              "  THICKNESS %s ;" % f3(t), "  HEIGHT %s ;" % f3(100 + 80 * i),
              "  RESISTANCE RPERSQ %.3f ;" % rs, "  CAPACITANCE CPERSQDIST %.6f ;" % (cap * 1e-3), "  EDGECAPACITANCE %.6f ;" % (cap * 2e-4),
              "  # metal density (fill) rules", "  MINIMUMDENSITY 15 ;", "  MAXIMUMDENSITY 85 ;", "  DENSITYCHECKWINDOW 50 50 ;", "  DENSITYCHECKSTEP 25 ;",
              "  FILLACTIVESPACING %s ;" % f3(3 * sp),
              "  # electromigration / reliability",
              "  DCCURRENTDENSITY AVERAGE", "    WIDTH %s %s %s ;" % (f3(w), f3(2 * w), f3(4 * w)),
              "    TABLEENTRIES %.3f %.3f %.3f ;" % (JDC[m], JDC[m] * 0.98, JDC[m] * 0.95),
              "  ACCURRENTDENSITY RMS", "    FREQUENCY 1000 ;", "    WIDTH %s %s %s ;" % (f3(w), f3(2 * w), f3(4 * w)),
              "    TABLEENTRIES", "      %.3f %.3f %.3f ;" % (3 * JDC[m], 3 * JDC[m] * 0.98, 3 * JDC[m] * 0.95),
              "  ACCURRENTDENSITY PEAK", "    FREQUENCY 1000 ;", "    WIDTH %s %s %s ;" % (f3(w), f3(2 * w), f3(4 * w)),
              "    TABLEENTRIES", "      %.3f %.3f %.3f ;" % (12 * JDC[m], 12 * JDC[m] * 0.98, 12 * JDC[m] * 0.95),
              "  ANTENNAMODEL OXIDE1 ;", "  ANTENNACUMAREARATIO 1000 ;", "  ANTENNACUMDIFFAREARATIO 50000 ;",
              "END %s" % m, ""]
        o = [x for x in o if x != ""] + [""] if False else o
        if i < len(METALS) - 1:
            v = VIAS[i + 1]; sz = v[3]; nm_ = v[0]
            o += ["LAYER %s" % nm_, "  TYPE CUT ;"] + (["  MASK 2 ;"] if nm_ in MP_LAYERS else []) + [
                  "  WIDTH %s ;" % f3(sz), "  SPACING %s ;" % f3(sz), "  SPACING %s ADJACENTCUTS 3 WITHIN %s ;" % (f3(1.3 * sz), f3(2 * sz)),
                  '  PROPERTY LEF58_CUTCLASS "CUTCLASS VSINGLE WIDTH %s ; CUTCLASS VBAR WIDTH %s LENGTH %s ;" ;' % (f3(sz), f3(sz), f3(2 * sz)),
                  '  PROPERTY LEF58_ENCLOSURE "ENCLOSURE CUTCLASS VSINGLE BELOW 0.000 0.005 ; ENCLOSURE CUTCLASS VSINGLE ABOVE 0.000 0.005 ;" ;',
                  "  RESISTANCE %.1f ;" % (40.0 / (i + 1)),
                  "  DCCURRENTDENSITY AVERAGE", "    CUTAREA %.6f ;" % ((sz * NM) ** 2), "    TABLEENTRIES %.1f ;" % (JCUT[nm_] / ((sz * NM) ** 2)),
                  "  ANTENNAAREARATIO 20 ;", "  ANTENNADIFFAREARATIO 1000 ;", "END %s" % nm_, ""]
    o += ["LAYER V9", "  TYPE CUT ;", "  SPACING 2.000 ;", "  WIDTH 2.000 ;", "  DCCURRENTDENSITY AVERAGE", "    CUTAREA 4.0 ;", "    TABLEENTRIES 10.0 ;", "END V9", "",
          "LAYER AP", "  TYPE ROUTING ;", "  DIRECTION HORIZONTAL ;", "  PITCH 4.000 ;", "  WIDTH 2.000 ;", "  MAXWIDTH 70.000 ;", "  SPACING 2.000 ;",
          "  RESISTANCE RPERSQ 0.021 ;", "  DCCURRENTDENSITY AVERAGE", "    WIDTH 2.000 10.000 ;", "    TABLEENTRIES 10.0 9.5 ;", "END AP", "",
          "LAYER OVERLAP", "  TYPE OVERLAP ;", "END OVERLAP", ""]
    for i in range(len(METALS) - 1):
        lo, hi = METALS[i], METALS[i + 1]; v = VIAS[i + 1]; sz = v[3] * NM
        e_lo = max(lo[3] * NM - sz, 0) / 2 + 0.005; e_hi = max(hi[3] * NM - sz, 0) / 2 + 0.005
        o += ["VIA %s_1x1 DEFAULT" % v[0], "  LAYER %s ;" % lo[0], "    RECT %.4f %.4f %.4f %.4f ;" % (-sz / 2 - e_lo, -sz / 2, sz / 2 + e_lo, sz / 2),
              "  LAYER %s ;" % v[0], "    RECT %.4f %.4f %.4f %.4f ;" % (-sz / 2, -sz / 2, sz / 2, sz / 2),
              "  LAYER %s ;" % hi[0], "    RECT %.4f %.4f %.4f %.4f ;" % (-sz / 2, -sz / 2 - e_hi, sz / 2, sz / 2 + e_hi),
              "END %s_1x1" % v[0], ""]
        o += ["VIARULE %s_GEN GENERATE" % v[0], "  LAYER %s ;" % lo[0], "    ENCLOSURE 0.000 0.005 ;",
              "  LAYER %s ;" % hi[0], "    ENCLOSURE 0.000 0.005 ;", "  LAYER %s ;" % v[0],
              "    RECT %.4f %.4f %.4f %.4f ;" % (-sz / 2, -sz / 2, sz / 2, sz / 2), "    SPACING %.3f BY %.3f ;" % (2 * sz, 2 * sz),
              "    RESISTANCE %.1f ;" % (40.0 / (i + 1)), "END %s_GEN" % v[0], ""]
    # non-default rules for clocks (2W2S) and power
    o += ["NONDEFAULTRULE NDR_2W2S", "  HARDSPACING ;"]
    for (m, d, p, w, sp, t, off) in METALS[1:7]:
        o += ["  LAYER %s" % m, "    WIDTH %s ;" % f3(2 * w), "    SPACING %s ;" % f3(2 * sp), "  END %s" % m]
    o += ["  MINCUTS V1 1 ;", "END NDR_2W2S", "", "END LIBRARY"]
    open(path, "w").write("\n".join(x for x in o if x is not None) + "\n")
