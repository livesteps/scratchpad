"""Tiny Liberty boolean-expression parser: ! & ^ | ( ) 0 1 identifiers (with [n]).
Precedence (high->low): !  &  ^  |   (Liberty: juxtaposition/space not supported)."""
import itertools, re

_tok = re.compile(r"\s*([A-Za-z_][A-Za-z0-9_]*(?:\[\d+\])?|[!&|^()]|[01])")

def tokenize(s):
    s = s.strip(); pos = 0; out = []
    while pos < len(s):
        m = _tok.match(s, pos)
        if not m:
            raise ValueError("bad expr %r at %d" % (s, pos))
        out.append(m.group(1)); pos = m.end()
    return out

class _P:
    def __init__(self, toks): self.t = toks; self.i = 0
    def peek(self): return self.t[self.i] if self.i < len(self.t) else None
    def eat(self, x=None):
        v = self.peek()
        if x is not None and v != x: raise ValueError("expected %s got %s" % (x, v))
        self.i += 1; return v
    def parse_or(self):
        n = self.parse_xor()
        while self.peek() == "|": self.eat(); n = ("|", n, self.parse_xor())
        return n
    def parse_xor(self):
        n = self.parse_and()
        while self.peek() == "^": self.eat(); n = ("^", n, self.parse_and())
        return n
    def parse_and(self):
        n = self.parse_not()
        while self.peek() == "&": self.eat(); n = ("&", n, self.parse_not())
        return n
    def parse_not(self):
        if self.peek() == "!": self.eat(); return ("!", self.parse_not())
        if self.peek() == "(":
            self.eat("("); n = self.parse_or(); self.eat(")"); return n
        v = self.eat()
        if v in ("0", "1"): return ("c", int(v))
        return ("v", v)

def parse(s):
    p = _P(tokenize(s)); n = p.parse_or()
    if p.peek() is not None: raise ValueError("trailing in %r" % s)
    return n

def ev(n, env):
    k = n[0]
    if k == "v": return env[n[1]]
    if k == "c": return n[1]
    if k == "!": return 1 - ev(n[1], env)
    a, b = ev(n[1], env), ev(n[2], env)
    return {"&": a & b, "|": a | b, "^": a ^ b}[k]

def variables(n, acc=None):
    if acc is None: acc = []
    if n[0] == "v":
        if n[1] not in acc: acc.append(n[1])
    elif n[0] == "!": variables(n[1], acc)
    elif n[0] in "&|^": variables(n[1], acc); variables(n[2], acc)
    return acc

def to_verilog(n):
    k = n[0]
    if k == "v": return n[1]
    if k == "c": return "1'b%d" % n[1]
    if k == "!": return "~" + _wrap(n[1])
    return "(%s %s %s)" % (to_verilog(n[1]), k, to_verilog(n[2]))
def _wrap(n):
    s = to_verilog(n)
    return s if n[0] in "vc" or s.startswith("(") else "(" + s + ")"

def unateness(expr, pin, allpins):
    """positive_unate / negative_unate / non_unate of expr wrt pin"""
    n = parse(expr) if isinstance(expr, str) else expr
    others = [p for p in allpins if p != pin]
    pos = neg = False
    for vals in itertools.product((0, 1), repeat=len(others)):
        env = dict(zip(others, vals))
        env[pin] = 0; y0 = ev(n, env)
        env[pin] = 1; y1 = ev(n, env)
        if y1 > y0: pos = True
        if y1 < y0: neg = True
    if pos and neg: return "non_unate"
    if neg: return "negative_unate"
    return "positive_unate"

def depends(expr, pin, allpins):
    n = parse(expr) if isinstance(expr, str) else expr
    others = [p for p in allpins if p != pin]
    for vals in itertools.product((0, 1), repeat=len(others)):
        env = dict(zip(others, vals)); env[pin] = 0; y0 = ev(n, env)
        env[pin] = 1
        if ev(n, env) != y0: return True
    return False

def when_string(pins, vals):
    return "&".join(p if v else "!" + p for p, v in zip(pins, vals))
