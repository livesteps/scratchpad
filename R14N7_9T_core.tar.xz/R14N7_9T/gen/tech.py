"""
R14N7 -- synthetic 7nm-class FinFET PDK : technology core
==========================================================
SYNTHETIC / PREDICTIVE.  NOT A FOUNDRY PDK.  NOT FOR TAPEOUT.

Geometry and device cards follow the public ASAP7 predictive PDK
(ASU/ARM, BSD-3) where they exist; everything else (HVT/IO devices,
rules, corners, electrical model) is synthesized here and is internally
self-consistent across every generated view.
All geometry in this file is in nanometres (nm) unless noted.
"""
import os
from collections import OrderedDict
from dataclasses import dataclass

PDK = "R14N7"
PDK_VERSION = "1.0.0"
PDK_DATE = "2026-11-27"
BANNER = ("R14N7 synthetic 7nm-class FinFET PDK v%s (%s-track variant) -- PREDICTIVE, NOT SILICON-"
          "CALIBRATED, NOT FOR MANUFACTURING" % (PDK_VERSION, os.environ.get("R14_TRACKS", "6")))

# ----------------------------------------------------------------- geometry
import os
# ----------------------------------------------------------------- track-height variant
# Select with env R14_TRACKS = 6 | 7 | 9 | 12 (default 6).  Row height must be an integer number
# of fin pitches AND of M2 pitches, otherwise flipped rows break the fin/track grid.
VARIANTS = {
    #     row  fin  finW  M2  fins/row fins/dev  M4/M6 pitch  M8 pitch
    6:  dict(row=270, fin=27, finw=7, m2=45, frow=10, fdev=3, m4=90, m8=135),
    7:  dict(row=252, fin=28, finw=8, m2=36, frow=9,  fdev=3, m4=84, m8=126),
    9:  dict(row=324, fin=27, finw=7, m2=36, frow=12, fdev=4, m4=81, m8=162),
    12: dict(row=432, fin=27, finw=7, m2=36, frow=16, fdev=6, m4=72, m8=144),
}
TRACKS = int(os.environ.get("R14_TRACKS", "6"))
_V = VARIANTS[TRACKS]
VARIANT = "%dT" % TRACKS
PDK_TAG = "R14N7_%s" % VARIANT
LIBPFX = "r14n7t%d" % TRACKS          # library-name prefix, e.g. r14n7t9_std_svt_tt_0p70v_25c_ccs

CPP        = 54      # contacted poly pitch (= placement site width), all variants
GATE_L     = 20      # drawn gate length
FIN_P      = _V["fin"]
FIN_W      = _V["finw"]
ROW_H      = _V["row"]
FINS_PER_ROW = _V["frow"]
FINS_PER_DEV = _V["fdev"]  # fins per finger for X1-and-up devices
M1_P       = 54      # M1 vertical track pitch (= CPP, tracks at site centres)
M1_OFF     = 27
M2_P       = _V["m2"]
M1_W       = 18
RAIL_W     = 54      # VDD/VSS rail width
SITE_NAME  = "coreSite"
SITE_W_UM  = CPP / 1000.0
SITE_H_UM  = ROW_H / 1000.0

def _h(p, frac=0.5):
    w = int(round(p * frac)); return w, p - w
_m2w, _m2s = (22, 23) if M2_P == 45 else (18, 18)
_m4w, _m4s = _h(_V["m4"]); _m8w, _m8s = _h(_V["m8"], 0.47)
# BEOL stack: name, direction, pitch, width, space, thickness, track offset (nm).
# Vertical pitches are multiples of CPP (54); horizontal pitches divide ROW_H exactly.
METALS = [
    ("M1", "VERTICAL",    54, 18, 36, 36, 27),
    ("M2", "HORIZONTAL",  M2_P, _m2w, _m2s, 36, 0),
    ("M3", "VERTICAL",    54, 24, 30, 36, 27),
    ("M4", "HORIZONTAL",  _V["m4"], _m4w, _m4s, 48, 0),
    ("M5", "VERTICAL",   108, 48, 60, 48, 54),
    ("M6", "HORIZONTAL",  _V["m4"], _m4w, _m4s, 64, 0),
    ("M7", "VERTICAL",   108, 48, 60, 64, 54),
    ("M8", "HORIZONTAL",  _V["m8"], _m8w, _m8s, 80, 0),
    ("M9", "VERTICAL",   216, 100, 116, 80, 108),
]
for _m in METALS:
    assert (_m[1] == "VERTICAL" and _m[2] % CPP == 0) or (_m[1] == "HORIZONTAL" and ROW_H % _m[2] == 0), _m
assert ROW_H % FIN_P == 0 and (FIN_P - FIN_W) % 2 == 0
# vias: name, below, above, size
VIAS = [("V0", "LISD", "M1", 18), ("V1", "M1", "M2", 18), ("V2", "M2", "M3", 18),
        ("V3", "M3", "M4", 22), ("V4", "M4", "M5", min(40, _m4w)), ("V5", "M5", "M6", min(40, _m4w)),
        ("V6", "M6", "M7", min(40, _m4w)), ("V7", "M7", "M8", 44), ("V8", "M8", "M9", 60),
        ("V9", "M9", "AP", 2000)]
# rough per-layer RC for techLEF (ohm/sq, aF/um area-ish, used only in LEF)
METAL_RC = {"M1": (12.8, 0.20), "M2": (12.8, 0.20), "M3": (12.8, 0.20),
            "M4": (7.5, 0.18), "M5": (7.5, 0.18), "M6": (4.2, 0.16),
            "M7": (4.2, 0.16), "M8": (2.6, 0.15), "M9": (2.6, 0.15)}

# ----------------------------------------------------------------- GDS layer map
LAYERS = OrderedDict([
    # name        (layer, datatype)   description
    ("NWELL",     ((1, 0),  "N-well")),
    ("FIN",       ((2, 0),  "Fin mandrel / fin")),
    ("ACTIVE",    ((3, 0),  "Active (fin keep) region")),
    ("NSELECT",   ((4, 0),  "N+ implant select")),
    ("PSELECT",   ((5, 0),  "P+ implant select")),
    ("GATE",      ((7, 0),  "Gate (poly / RMG)")),
    ("GCUT",      ((10, 0), "Gate cut")),
    ("SDB",       ((12, 0), "Single diffusion break")),
    ("LIG",       ((16, 0), "Local interconnect - gate (CB)")),
    ("LISD",      ((17, 0), "Local interconnect - S/D trench (CA)")),
    ("V0",        ((18, 0), "Via0 LI->M1")),
    ("M1",        ((19, 0), "Metal 1")),
    ("M2",        ((20, 0), "Metal 2")),
    ("V1",        ((21, 0), "Via1")),
    ("V2",        ((25, 0), "Via2")),
    ("M3",        ((30, 0), "Metal 3")),
    ("V3",        ((35, 0), "Via3")),
    ("M4",        ((40, 0), "Metal 4")),
    ("V4",        ((45, 0), "Via4")),
    ("M5",        ((50, 0), "Metal 5")),
    ("V5",        ((55, 0), "Via5")),
    ("M6",        ((60, 0), "Metal 6")),
    ("V6",        ((65, 0), "Via6")),
    ("M7",        ((70, 0), "Metal 7")),
    ("V7",        ((75, 0), "Via7")),
    ("M8",        ((80, 0), "Metal 8")),
    ("V8",        ((85, 0), "Via8")),
    ("M9",        ((90, 0), "Metal 9")),
    ("V9",        ((95, 0), "Via9 / RV")),
    ("AP",        ((96, 0), "Al pad / RDL")),
    ("PASSIV",    ((97, 0), "Passivation opening (bond pad)")),
    ("VT_HVT",    ((101, 0), "High-Vt implant")),
    ("VT_LVT",    ((102, 0), "Low-Vt implant")),
    ("VT_ULVT",   ((103, 0), "Ultra-low-Vt implant")),
    ("SRAMMK",    ((104, 0), "SRAM bitcell marker (relaxed rules)")),
    ("THICKOX",   ((105, 0), "Thick-oxide IO device (1.8V)")),
    ("ESDMK",     ((106, 0), "ESD device marker")),
    ("DIODEMK",   ((107, 0), "Diode marker")),
    ("RESMK",     ((108, 0), "Resistor marker")),
    ("ROMPGM",    ((109, 0), "ROM code (V0 program) marker")),
    ("MROWMK",    ((110, 0), "Multi-row-height cell marker")),
    ("LVLMK",     ((111, 0), "Level-shifter dual-supply marker")),
    ("PSWMK",     ((112, 0), "Power-switch marker")),
    ("AONMK",     ((113, 0), "Always-on / secondary-power marker")),
    ("GAMK",      ((114, 0), "Gate-array ECO base marker")),
    ("PRBNDRY",   ((235, 0), "Placement & route boundary")),
])
PIN_DT = 2      # pin purpose datatype (same layer number)
TEXT_DT = 10    # text label datatype
FILL_DT = 1     # dummy-fill datatype
def L(name):
    return LAYERS[name][0]

# ----------------------------------------------------------------- Vt flavours
# vt0 = |Vth| at 25C, long-channel-ish sat threshold used by analytic model (V)
# u   = relative mobility factor (lower-Vt cards in ASAP7 have higher u0)
VT_FLAVORS = OrderedDict([
    ("HVT",  dict(vtn=0.330, vtp=0.320, u=0.93, nmodel="nmos_hvt",  pmodel="pmos_hvt",
                  implant="VT_HVT",  tag="h")),
    ("SVT",  dict(vtn=0.270, vtp=0.262, u=1.00, nmodel="nmos_rvt",  pmodel="pmos_rvt",
                  implant=None,      tag="s")),
    ("LVT",  dict(vtn=0.215, vtp=0.208, u=1.06, nmodel="nmos_lvt",  pmodel="pmos_lvt",
                  implant="VT_LVT",  tag="l")),
    ("ULVT", dict(vtn=0.160, vtp=0.155, u=1.10, nmodel="nmos_slvt", pmodel="pmos_slvt",
                  implant="VT_ULVT", tag="u")),
])

# ----------------------------------------------------------------- PVT corners
# proc: (n-shift, p-shift) where s=slow, t=typ, f=fast.  vddl = low-voltage
# domain rail for level shifters (~0.86*VDD), vddio = IO rail, vddb = AON rail.
@dataclass
class Corner:
    name: str
    proc: str          # tt ss ff sf fs  (first letter = NMOS, second = PMOS)
    vdd: float
    temp: float
    role: str
    @property
    def vddl(self):  return round(self.vdd * 0.857, 3)
    @property
    def vddio(self):
        return {"ss": 1.62, "ff": 1.98}.get(self.proc, 1.80)
    @property
    def vddb(self):  return self.vdd
    @property
    def nproc(self): return {"tt": "t", "ss": "s", "ff": "f", "sf": "s", "fs": "f"}[self.proc]
    @property
    def pproc(self): return {"tt": "t", "ss": "s", "ff": "f", "sf": "f", "fs": "s"}[self.proc]
    @property
    def tag(self):
        v = ("%.2f" % self.vdd).replace(".", "p")
        t = ("m%d" % -self.temp) if self.temp < 0 else ("%d" % self.temp)
        return "%s_%sv_%sc" % (self.proc, v, t)

CORNERS = [
    Corner("ss_0p63v_m40c", "ss", 0.63, -40, "setup worst (slow_lowtemp: temp-inversion)"),
    Corner("ss_0p63v_0c",   "ss", 0.63,   0, "setup"),
    Corner("ss_0p63v_125c", "ss", 0.63, 125, "setup (slow_hightemp) / EM"),
    Corner("ss_0p54v_m40c", "ss", 0.54, -40, "low-voltage (DVFS/LV-domain) setup"),
    Corner("tt_0p70v_25c",  "tt", 0.70,  25, "typical / nominal"),
    Corner("tt_0p70v_85c",  "tt", 0.70,  85, "typical hot / power"),
    Corner("tt_0p60v_25c",  "tt", 0.60,  25, "typical low-voltage (DVFS)"),
    Corner("ff_0p77v_m40c", "ff", 0.77, -40, "hold (fast_lowtemp)"),
    Corner("ff_0p77v_0c",   "ff", 0.77,   0, "hold"),
    Corner("ff_0p77v_125c", "ff", 0.77, 125, "hold / leakage worst (fast_hightemp)"),
    Corner("sf_0p70v_25c",  "sf", 0.70,  25, "skew: slow-N / fast-P"),
    Corner("fs_0p70v_25c",  "fs", 0.70,  25, "skew: fast-N / slow-P"),
]
CORNER_BY_NAME = {c.name: c for c in CORNERS}
NOMINAL = CORNER_BY_NAME["tt_0p70v_25c"]

# process shifts used by the analytic model (dVt [V], mobility factor)
PROC_SHIFT = {"s": (+0.030, 0.92), "t": (0.0, 1.0), "f": (-0.030, 1.08)}

# ----------------------------------------------------------------- design rules
@dataclass
class Rule:
    rid: str
    layer: str
    kind: str        # width, space, exact_width, pitch, enclosure, extension, area,
                     # overlap_forbid, density_min, density_max, eol, notch, grid
    value: float     # nm (area nm^2, density fraction)
    other: str = ""  # second layer for enclosure/extension/overlap
    desc: str = ""

RULES = []
def _r(*a, **k): RULES.append(Rule(*a, **k))

# FEOL
_r("FIN.W.1",  "FIN", "exact_width", FIN_W, desc="Fin width must equal %d nm" % FIN_W)
_r("FIN.P.1",  "FIN", "pitch", FIN_P, desc="Fins on a %d nm vertical grid" % FIN_P)
_r("FIN.S.1",  "FIN", "space", FIN_P - FIN_W, desc="Fin-to-fin space")
_r("ACT.W.1",  "ACTIVE", "width", 2 * FIN_P - FIN_W, desc="Active min width (>= 2 fins)")
_r("ACT.S.1",  "ACTIVE", "space", 27, desc="Active to active space")
_r("ACT.FK.1", "ACTIVE", "fin_keep", 0, other="FIN", desc="Fin outside ACTIVE is removed (fin-cut); informational")
_r("NW.W.1",   "NWELL", "width", 108, desc="N-well min width")
_r("NW.S.1",   "NWELL", "space", 108, desc="N-well min space (different net)")
_r("NW.EN.1",  "NWELL", "enclosure", 13, other="PACT", desc="N-well enclosure of P-active")
_r("NW.S.2",   "NWELL", "space", 13, other="NACT", desc="N-well space to N-active")
_r("SEL.O.1",  "NSELECT", "overlap_forbid", 0, other="PSELECT", desc="NSELECT and PSELECT must not overlap")
_r("NSEL.EN.1","NSELECT", "enclosure", 10, other="NACT", desc="NSELECT enclosure of N-active")
_r("PSEL.EN.1","PSELECT", "enclosure", 10, other="PACT", desc="PSELECT enclosure of P-active")
_r("GATE.W.1", "GATE", "exact_width", GATE_L, desc="Gate length must equal %d nm (logic)" % GATE_L)
_r("GATE.P.1", "GATE", "pitch", CPP, desc="Gates on %d nm CPP grid" % CPP)
_r("GATE.S.1", "GATE", "space", CPP - GATE_L, desc="Gate to gate space")
_r("GATE.EX.1","GATE", "extension", 15, other="ACTIVE", desc="Gate end-cap past active")
_r("GCUT.W.1", "GCUT", "width", 24, desc="Gate-cut min width")
_r("GCUT.S.1", "GCUT", "space", 36, desc="Gate-cut min space")
_r("VT.W.1",   "VT_*", "width", CPP, desc="Vt implant min width = 1 CPP")
_r("VT.S.1",   "VT_*", "space", CPP, desc="Vt implant min space = 1 CPP (same flavour)")
_r("VT.O.1",   "VT_*", "overlap_forbid", 0, other="VT_*", desc="Different Vt implants must not overlap")
_r("SDB.W.1",  "SDB", "width", 30, desc="Single diffusion break width")
# MOL
_r("LISD.W.1", "LISD", "width", 24, desc="Trench contact width")
_r("LISD.S.1", "LISD", "space", 30, desc="Trench contact space (along fin)")
_r("LISD.S.2", "LISD", "space", 4, other="GATE", desc="Trench contact to gate space")
_r("LIG.W.1",  "LIG", "width", 16, desc="Gate contact width")
_r("LIG.S.1",  "LIG", "space", 38, desc="Gate contact space")
_r("V0.W.1",   "V0", "exact_width", 18, desc="V0 is an 18x18 square")
_r("V0.S.1",   "V0", "space", 18, desc="V0 to V0 space")
_r("V0.EN.1",  "M1", "enclosure", 0, other="V0", desc="M1 enclosure of V0 (side)")
# BEOL
for (m, d, p, w, s, t, off) in METALS:
    _r("%s.W.1" % m, m, "width", w, desc="%s min width" % m)
    _r("%s.S.1" % m, m, "space", s, desc="%s min space" % m)
    _r("%s.A.1" % m, m, "area", 4 * w * w * 3 if m != "M1" else 1000, desc="%s min area (nm^2)" % m)
    _r("%s.EOL.1" % m, m, "eol", s + 6, desc="%s end-of-line space" % m)
    _r("%s.DEN.1" % m, m, "density_min", 0.15, desc="%s min density, 50x50um window, 25um step" % m)
    _r("%s.DEN.2" % m, m, "density_max", 0.85, desc="%s max density, 50x50um window, 25um step" % m)
for (v, lo, hi, sz) in VIAS[1:]:
    _r("%s.W.1" % v, v, "exact_width", sz, desc="%s is square %d nm" % (v, sz))
    _r("%s.S.1" % v, v, "space", sz, desc="%s to %s space" % (v, v))
    if hi != "AP":
        _r("%s.EN.1" % v, hi, "enclosure", 0, other=v, desc="%s enclosure of %s" % (hi, v))
        _r("%s.EN.2" % v, lo, "enclosure", 0, other=v, desc="%s enclosure of %s" % (lo, v))
for _m in ("M2", "M3"):
    _p = next(x for x in METALS if x[0] == _m)
    _r("%s.SM.1" % _m, _m, "samemask", 2 * _p[2] - _p[3], desc="%s same-mask (colour) spacing, LELE double patterning" % _m)
    _r("%s.DM.1" % _m, _m, "space", _p[4], desc="%s different-mask spacing (= min space)" % _m)
_r("AP.W.1", "AP", "width", 2000, desc="Pad metal min width")
_r("AP.S.1", "AP", "space", 2000, desc="Pad metal min space")
_r("PAS.EN.1", "AP", "enclosure", 2000, other="PASSIV", desc="AP enclosure of passivation opening")
_r("PAS.W.1", "PASSIV", "width", 40000, desc="Bond-pad opening min width")
_r("TOX.EN.1", "THICKOX", "enclosure", 60, other="ACTIVE", desc="Thick-ox enclosure of IO active")
_r("TOX.GL.1", "GATE", "width", 150, other="THICKOX", desc="IO gate length >= 150 nm inside THICKOX")
_r("ANT.R.1", "M*", "antenna", 1000, desc="Cumulative metal/gate area ratio <= 1000 (no diode)")
_r("ANT.R.2", "M*", "antenna", 50000, desc="Cumulative metal/gate area ratio with diode")
_r("GRID.1",  "*", "grid", 1, desc="All shapes on 1 nm manufacturing grid")

RULE_BY_ID = {r.rid: r for r in RULES}

def header_lines(comment="//", what=""):
    return [comment + " " + BANNER,
            comment + " " + what,
            comment + " Generated %s by r14n7/gen.  Device cards derived from ASAP7 (BSD-3)." % PDK_DATE]
