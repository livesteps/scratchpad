"""Liberty writer: NLDM (+LVF sigma tables), CCS (NLDM + output_current + receiver cap),
ECSM (NLDM + ECSM voltage-time waveforms).  No noise tables (by request)."""
import itertools, math, os
import boolexpr as bx
import charmodel as cm
from tech import CORNER_BY_NAME, BANNER, PDK, PDK_VERSION
from cells import dnum

def F(x): return "%.5g" % x
def row(vals): return ", ".join(F(v) for v in vals)
def tbl(lines, ind, name, tmpl, i1, i2, vals, extra=None):
    p = " " * ind
    lines.append("%s%s (%s) {" % (p, name, tmpl))
    if extra: lines.extend(p + "  " + e for e in extra)
    lines.append('%s  index_1 ("%s");' % (p, row(i1)))
    if i2 is not None: lines.append('%s  index_2 ("%s");' % (p, row(i2)))
    if vals and isinstance(vals[0], list):
        lines.append("%s  values ( \\" % p)
        lines.append(", \\\n".join('%s    "%s"' % (p, row(r)) for r in vals) + " );")
    else:
        lines.append('%s  values ("%s");' % (p, row(vals)))
    lines.append("%s}" % p)

class St:
    pass

def out_stage(cell, opin, bit=None):
    key = opin if bit is None else "%s<%d>" % (opin, bit)
    s = cell.nb.stages.get(key)
    st = St()
    d = dnum(cell.drive)
    if s is None:
        st.rn, st.rp, st.cpar, st.fins = 6.0, 6.6, 0.3, 3
    else:
        st.rn, st.rp, st.cpar = s.rn, s.rp, s.cpar
        st.fins = sum(dv.nfin * dv.nf for dv in cell.nb.devs if dv.d == key and dv.t == "n") or 3
    st.loads = cm.loads_for(d if cell.family not in ("pmk_psw",) else 1)
    return st

def lib_header(name, corner, voltages, lines, mb_widths=()):
    c = corner
    L = lines
    L += ["/* %s */" % BANNER,
          "/* Library %s  corner %s (%s)  process=%s VDD=%.3fV T=%gC */" % (name, c.name, c.role, c.proc, c.vdd, c.temp),
          "/* Characterized with the R14N7 analytic FinFET model (see doc). */",
          "library (%s) {" % name,
          "  technology (cmos);", "  delay_model : table_lookup;",
          '  date : "2026-11-27";', '  revision : "%s";' % PDK_VERSION,
          '  comment : "%s";' % BANNER,
          '  time_unit : "1ps";', '  voltage_unit : "1V";', '  current_unit : "1mA";',
          '  pulling_resistance_unit : "1kohm";', '  leakage_power_unit : "1pW";',
          "  capacitive_load_unit (1, ff);",
          "  slew_upper_threshold_pct_rise : 90;", "  slew_lower_threshold_pct_rise : 10;",
          "  slew_upper_threshold_pct_fall : 90;", "  slew_lower_threshold_pct_fall : 10;",
          "  input_threshold_pct_rise : 50;", "  input_threshold_pct_fall : 50;",
          "  output_threshold_pct_rise : 50;", "  output_threshold_pct_fall : 50;",
          "  slew_derate_from_library : 1.0;",
          "  nom_process : 1;", "  nom_voltage : %.3f;" % c.vdd, "  nom_temperature : %g;" % c.temp,
          "  default_cell_leakage_power : 0;", "  default_fanout_load : 1;", "  default_inout_pin_cap : 0.5;",
          "  default_input_pin_cap : 0.5;", "  default_output_pin_cap : 0;", "  default_leakage_power_density : 0;",
          "  default_max_transition : 320;",
          "  in_place_swap_mode : match_footprint;",
          "  operating_conditions (%s) {" % c.name,
          "    process : %s;" % {"tt": "1", "ss": "1.2", "ff": "0.8", "sf": "1", "fs": "1"}[c.proc],
          "    voltage : %.3f;" % c.vdd, "    temperature : %g;" % c.temp, "    tree_type : balanced_tree;", "  }",
          "  default_operating_conditions : %s;" % c.name]
    for vn, vv in voltages:
        L.append("  voltage_map (%s, %.3f);" % (vn, vv))
    L += ["  lu_table_template (delay_template_7x7) {",
          "    variable_1 : input_net_transition;", "    variable_2 : total_output_net_capacitance;",
          '    index_1 ("%s");' % row(cm.SLEWS), '    index_2 ("%s");' % row(cm.LOAD_X1), "  }",
          "  lu_table_template (constraint_template_5x5) {",
          "    variable_1 : related_pin_transition;", "    variable_2 : constrained_pin_transition;",
          '    index_1 ("%s");' % row(cm.CSLEWS), '    index_2 ("%s");' % row(cm.CSLEWS), "  }",
          "  lu_table_template (recovery_template_5x5) {",
          "    variable_1 : related_pin_transition;", "    variable_2 : constrained_pin_transition;",
          '    index_1 ("%s");' % row(cm.CSLEWS), '    index_2 ("%s");' % row(cm.CSLEWS), "  }",
          "  power_lut_template (power_template_7x7) {",
          "    variable_1 : input_transition_time;", "    variable_2 : total_output_net_capacitance;",
          '    index_1 ("%s");' % row(cm.SLEWS), '    index_2 ("%s");' % row(cm.LOAD_X1), "  }",
          "  power_lut_template (passive_power_template_7x1) {",
          "    variable_1 : input_transition_time;", '    index_1 ("%s");' % row(cm.SLEWS), "  }",
          "  output_current_template (ccs_template) {",
          "    variable_1 : input_net_transition;", "    variable_2 : total_output_net_capacitance;",
          "    variable_3 : time;", "  }",
          "  lu_table_template (receiver_cap_template_7) {",
          "    variable_1 : input_net_transition;", '    index_1 ("%s");' % row(cm.SLEWS), "  }",
          "  lu_table_template (ecsm_template) {",
          "    variable_1 : input_net_transition;", "    variable_2 : total_output_net_capacitance;",
          "    variable_3 : normalized_voltage;", "  }"]
    for w in mb_widths:
        L += ["  type (bus%d) {" % w, "    base_type : array;", "    data_type : bit;",
              "    bit_width : %d;" % w, "    bit_from : %d;" % (w - 1), "    bit_to : 0;", "    downto : true;", "  }"]

def vmap_for(cells, corner):
    names = []
    for c in cells:
        for n, t, v in c.pg:
            if v not in names: names.append(v)
    val = {"VDD": corner.vdd, "VSS": 0.0, "VDDL": corner.vddl, "VDDB": corner.vddb, "VDDR": corner.vddb,
           "VVDD": corner.vdd, "VVSS": 0.0, "IOVDD": corner.vddio, "IOVSS": 0.0}
    return [(n, val[n]) for n in names]

def pin_volt(corner, pwr):
    return {"VDDL": corner.vddl}.get(pwr, corner.vdd)

# --------------------------------------------------------------------- cell
def write_cell(L, c, corner, model, cache):
    cn = corner.name; vt = c.vt; V = corner.vdd
    L.append("  cell (%s) {" % c.name)
    L.append("    area : %s;" % ("%.6f" % c.area).rstrip("0").rstrip("."))
    if not c.physical_only or c.base.startswith(("FILL", "GFILL", "DCAP", "GDCAP", "TAP", "END")):
        L.append('    cell_footprint : "%s";' % c.base)
    for k, v in sorted(c.attrs.items()):
        if k in ("is_clock_cell",):
            L.append("    is_clock_cell : true;"); continue
        if isinstance(v, bool): L.append("    %s : %s;" % (k, "true" if v else "false"))
        elif k in ("single_bit_degenerate", "retention_cell", "antenna_diode_type", "switch_cell_type", "level_shifter_type"):
            L.append("    %s : %s;" % (k, v if k != "retention_cell" else '"%s"' % v))
    if c.attrs.get("is_level_shifter"):
        L.append("    input_voltage_range (%.3f, %.3f);" % (corner.vddl * 0.9, corner.vdd * 1.1))
        L.append("    output_voltage_range (%.3f, %.3f);" % (corner.vddl * 0.9, corner.vdd * 1.1))
    if c.seq and c.seq.get("kind") == "icg":
        L.append('    clock_gating_integrated_cell : "%s";' % c.seq["ctype"])
    # leakage
    leak = cache.setdefault(("leak", c.name, cn), cell_leakage(c, corner))
    L.append("    cell_leakage_power : %s;" % F(leak))
    ins = [p.name for p in c.inputs() if p.width == 1]
    lk_pins = ins[:6] if c.family in ("comb", "arith", "clock", "pmk_iso", "pmk_lvl", "pmk_aon", "ga", "delay") else ins[:2]
    if lk_pins and not c.physical_only:
        for vals in itertools.product((0, 1), repeat=len(lk_pins)):
            h = sum(vals) / float(len(vals))
            v = leak * (0.72 + 0.56 * ((h * 7 + len(vals) * 0.13 + sum(i * x for i, x in enumerate(vals)) * 0.17) % 1.0))
            L.append('    leakage_power () { when : "%s"; value : %s; related_pg_pin : %s; }' % (bx.when_string(lk_pins, vals), F(v), c.pg[0][0]))
    # pg pins
    for n, t, v in c.pg:
        extra = ""
        if t == "internal_power":
            extra = ' direction : output; switch_function : "%s"; pg_function : "VDD";' % c.seq["sw"]
        elif t == "internal_ground":
            extra = ' direction : output; switch_function : "%s"; pg_function : "VSS";' % c.seq["sw"]
        if c.attrs.get("is_level_shifter") and n == "VDD": extra += " std_cell_main_rail : true;"
        L.append("    pg_pin (%s) { voltage_name : %s; pg_type : %s;%s }" % (n, v, t, extra))
    # sequential groups
    sq = c.seq or {}
    if sq.get("kind") == "ff":
        L.append('    ff (IQ, IQN) {'); L.append('      clocked_on : "%s";' % sq["clocked_on"])
        L.append('      next_state : "%s";' % (sq.get("scan_ns") or sq["next_state"]))
        if "clear" in sq: L.append('      clear : "%s";' % sq["clear"])
        if "preset" in sq: L.append('      preset : "%s";' % sq["preset"])
        if "cpv1" in sq: L.append("      clear_preset_var1 : %s;" % sq["cpv1"]); L.append("      clear_preset_var2 : %s;" % sq["cpv2"])
        L.append("    }")
    elif sq.get("kind") == "ffs":
        for (iq, iqn, ck, ns) in sq["groups"]:
            L.append('    ff (%s, %s) { clocked_on : "%s"; next_state : "%s"; }' % (iq, iqn, ck, ns))
    elif sq.get("kind") == "ff_bank":
        L.append('    ff_bank (IQ, IQN, %d) {' % sq["bits"]); L.append('      clocked_on : "%s";' % sq["clocked_on"])
        L.append('      next_state : "%s";' % (sq.get("scan_ns") or sq["next_state"]))
        if "clear" in sq: L.append('      clear : "%s";' % sq["clear"])
        L.append("    }")
    elif sq.get("kind") == "latch":
        L.append('    latch (IQ, IQN) {'); L.append('      enable : "%s";' % sq["enable"]); L.append('      data_in : "%s";' % sq["data_in"])
        if "clear" in sq: L.append('      clear : "%s";' % sq["clear"])
        if "preset" in sq: L.append('      preset : "%s";' % sq["preset"])
        if "cpv1" in sq: L.append("      clear_preset_var1 : %s;" % sq["cpv1"]); L.append("      clear_preset_var2 : %s;" % sq["cpv2"])
        L.append("    }")
    elif sq.get("kind") == "icg":
        neg = sq["neg"]; a, b = ("H", "L") if neg else ("L", "H")
        if sq["pre"]:
            L.append('    statetable ("CK E SE", "IQ") {')
            L.append('      table : "%s L L : - : L, %s L H : - : H, %s H L : - : H, %s H H : - : H, %s - - : - : N";' % (a, a, a, a, b))
        else:
            L.append('    statetable ("CK E", "IQ") {')
            L.append('      table : "%s L : - : L, %s H : - : H, %s - : - : N";' % (a, a, b))
        L.append("    }")
        L.append('    pin (IQ) { direction : internal; internal_node : "IQ"; }')
    if sq.get("scan_ns") and sq["kind"] in ("ff", "ff_bank"):
        write_test_cell(L, c)
    # pins
    for p in c.pins:
        write_pin(L, c, p, corner, model, cache)
    L.append("  }")

def write_test_cell(L, c):
    sq = c.seq
    L.append("    test_cell () {")
    for p in c.pins:
        if p.dir != "input": continue
        st = {"scan_in": " signal_type : test_scan_in;", "scan_enable": " signal_type : test_scan_enable;"}.get(p.role, "")
        if p.width > 1:
            L.append("      bus (%s) { bus_type : bus%d; direction : input;%s }" % (p.name, p.width, st))
        else:
            L.append("      pin (%s) { direction : input;%s }" % (p.name, st))
    if sq["kind"] == "ff_bank":
        L.append('      ff_bank (IQ, IQN, %d) { next_state : "%s"; clocked_on : "%s";%s }' % (
            sq["bits"], sq["next_state"], sq["clocked_on"], (' clear : "%s";' % sq["clear"]) if "clear" in sq else ""))
    else:
        L.append('      ff (IQ, IQN) { next_state : "%s"; clocked_on : "%s";%s%s }' % (
            sq["next_state"], sq["clocked_on"], (' clear : "%s";' % sq["clear"]) if "clear" in sq else "",
            (' preset : "%s";' % sq["preset"]) if "preset" in sq else ""))
    for p in c.outputs():
        f = c.funcs[p.name]
        if p.width > 1:
            L.append('      bus (%s) { bus_type : bus%d; direction : output; function : "%s"; signal_type : test_scan_out; }' % (p.name, p.width, f))
        else:
            L.append('      pin (%s) { direction : output; function : "%s"; signal_type : %s; }' % (
                p.name, f, "test_scan_out" if p.name == "Q" else "test_scan_out_inverted"))
    L.append("    }")

def cell_leakage(c, corner):
    nb = c.nb; cn = corner.name
    tot = 0.0
    for d in nb.devs:
        vsup = corner.vddl if (d.b == "VDDL" or d.s == "VDDL") else corner.vdd
        lf = cm.leak_fin(cn, d.vt, d.t, vsup)
        if d.kind == "psw":
            tot += lf * d.nfin * d.nf * 1.0 * vsup     # switch fully off-biased half the time
        elif d.kind in ("cap",):
            tot += cm.IGATE0 * 4 * d.nfin * (corner.vdd / 0.7) ** 3 * corner.vdd
        elif d.kind == "ga":
            tot += 0.5 * lf * d.nfin * d.nf * vsup
        else:
            series = 0.55 if (d.s not in ("VDD", "VSS", "VDDL", "VDDB", "VDDR") or d.d not in (d.s,)) else 1.0
            tot += 0.5 * lf * d.nfin * d.nf * vsup * series
    for x in nb.extra:
        tot += 0.02 * corner.vdd
    return tot * 1000.0   # nA*V = nW -> pW

def pin_caps(c, p, corner):
    cs = cm.cap_scale(corner.name)
    base = p.cap * cs
    if p.role == "clock": return base * 1.02, base * 0.98
    return base * 1.01, base * 0.99

def write_pin(L, c, p, corner, model, cache):
    cn = corner.name; V = pin_volt(corner, p.pwr)
    head = ("bus (%s)" % p.name) if p.width > 1 else ("pin (%s)" % p.name)
    L.append("    %s {" % head)
    if p.width > 1: L.append("      bus_type : bus%d;" % p.width)
    L.append("      direction : %s;" % p.dir)
    L.append("      related_power_pin : %s;" % p.pwr)
    L.append("      related_ground_pin : %s;" % p.gnd)
    sq = c.seq or {}
    if p.dir == "input":
        cr, cf = pin_caps(c, p, corner)
        L.append("      capacitance : %s;" % F(0.5 * (cr + cf)))
        L.append("      rise_capacitance : %s;" % F(cr)); L.append("      fall_capacitance : %s;" % F(cf))
        L.append("      max_transition : 320;")
        if p.role in ("clock", "clock2") and c.family not in ("comb",):
            L.append("      clock : true;")
        if sq.get("kind") == "icg":
            L.append("      %s : true;" % {"clock": "clock_gate_clock_pin", "enable": "clock_gate_enable_pin", "test": "clock_gate_test_pin"}[p.role])
        if c.attrs.get("is_isolation_cell"):
            if p.role == "iso": L.append("      isolation_cell_enable_pin : true;")
            elif p.role in ("data", "ls_data"): L.append("      isolation_cell_data_pin : true;")
        if c.attrs.get("is_level_shifter"):
            if p.role == "ls_data": L.append("      level_shifter_data_pin : true;")
            if p.role == "iso": L.append("      level_shifter_enable_pin : true;")
        if p.role == "sleep": L.append("      switch_pin : true;")
        if p.role == "retain": L.append('      retention_pin (save_restore, "1");')
        if c.attrs.get("always_on") or p.role in ("iso", "sleep", "retain"): L.append("      always_on : true;")
        if p.name in c.mpw:
            hi, lo = c.mpw[p.name]
            sm = 0.5 * (cm.rscale(cn, c.vt, "p") + cm.rscale(cn, c.vt, "n"))
            if hi: L.append("      min_pulse_width_high : %s;" % F(hi * sm))
            if lo: L.append("      min_pulse_width_low : %s;" % F(lo * sm))
            if p.role == "clock" and hi: L.append("      min_period : %s;" % F((hi + lo) * sm * 1.05))
        if model == "ccs" and not c.physical_only:
            L.append("      receiver_capacitance () {")
            for nm, cc in (("receiver_capacitance1_rise", cr * 0.97), ("receiver_capacitance1_fall", cf * 0.97),
                           ("receiver_capacitance2_rise", cr * 1.03), ("receiver_capacitance2_fall", cf * 1.03)):
                tbl(L, 8, nm, "receiver_cap_template_7", cm.SLEWS, None, [cc * (1 + 0.0002 * s) for s in cm.SLEWS])
            L.append("      }")
        if model == "ecsm" and not c.physical_only:
            L.append("      ecsm_capacitance_rise : %s;" % F(cr * 1.01)); L.append("      ecsm_capacitance_fall : %s;" % F(cf * 1.01))
        # constraints
        for k in c.cons:
            if k.pin != p.name: continue
            L.append("      timing () {")
            L.append('        related_pin : "%s";' % k.rel)
            L.append("        timing_type : %s;" % k.kind)
            if k.when: L.append('        sdf_cond : "%s";' % k.when.replace("!", "~") + "") if False else None
            if k.when: L.append('        when : "%s";' % k.when); L.append('        sdf_cond : "%s";' % (k.when.replace("!", "") + " == 1'b" + ("0" if k.when.startswith("!") else "1")))
            tmpl = "recovery_template_5x5" if k.kind.split("_")[0] in ("recovery", "removal") else "constraint_template_5x5"
            for rf in ("rise", "fall"):
                vals = constraint_table(cn, c.vt, k.base, k.kind, rf == "rise")
                tbl(L, 8, "%s_constraint" % rf, tmpl, cm.CSLEWS, cm.CSLEWS, vals)
                if model in ("nldm", "ccs"):
                    sg = cm.sigma_rel(cn, c.vt, 3, 2.0)
                    tbl(L, 8, "ocv_sigma_%s_constraint" % rf, tmpl, cm.CSLEWS, cm.CSLEWS,
                        [[abs(v) * sg + 0.3 * sg * 10 for v in r] for r in vals], extra=['sigma_type : "early_and_late";'])
            L.append("      }")
        # passive / clock pin internal power
        if not c.physical_only:
            cint = (0.35 * p.cap + (0.6 * c.bits() if p.role == "clock" and c.seq else 0.0))
            L.append("      internal_power () {")
            L.append("        related_pg_pin : %s;" % p.pwr)
            for rf in ("rise_power", "fall_power"):
                tbl(L, 8, rf, "passive_power_template_7x1", cm.SLEWS, None,
                    [V * V * cint * (1 + 0.001 * s) for s in cm.SLEWS])
            L.append("      }")
    else:
        f = c.funcs.get(p.name)
        if f and sq.get("kind") == "icg" and p.name == "GCK":
            L.append('      state_function : "%s";' % f); L.append("      clock_gate_out_pin : true;")
        elif f and sq.get("kind") == "icg" and p.name == "Q":
            L.append('      state_function : "%s";' % f); L.append("      clock_gate_obs_pin : true;")
        elif f:
            L.append('      function : "%s";' % f)
        L.append('      power_down_function : "!%s + %s";' % (p.pwr, p.gnd))
        st = out_stage(c, p.name, 0 if p.width > 1 else None)
        L.append("      max_capacitance : %s;" % F(st.loads[-1]))
        L.append("      max_transition : 320;")
        if c.attrs.get("is_clock_cell") and p.name in ("Y", "GCK"): pass
        for a in c.arcs:
            if a.to != p.name: continue
            write_arc(L, c, p, a, st, corner, model, cache)
        # internal power per related input
        cint = c.nb.internal_cap() * (0.25 if c.seq else 0.5) / max(1, len(c.outputs()))
        seen = set()
        for a in c.arcs:
            if a.to != p.name or a.frm in seen: continue
            seen.add(a.frm)
            L.append("      internal_power () {")
            L.append('        related_pin : "%s";' % a.frm)
            L.append("        related_pg_pin : %s;" % p.pwr)
            e = cm.energy_table(cn, st, cint / (c.bits() if c.bits() > 1 else 1), st.loads, V)
            tbl(L, 8, "rise_power", "power_template_7x7", cm.SLEWS, st.loads, e)
            tbl(L, 8, "fall_power", "power_template_7x7", cm.SLEWS, st.loads, [[x * 0.93 for x in r] for r in e])
            L.append("      }")
    L.append("    }")

def write_arc(L, c, p, a, st, corner, model, cache):
    cn = corner.name; V = pin_volt(corner, p.pwr)
    vdd_ov = corner.vddl if p.pwr == "VDDL" else None
    key = ("arc", c.name, a.frm, a.to, cn)
    T = cache.get(key)
    if T is None:
        slew_k = 0.12 if a.ttype != "combinational" or a.d0 > 0.5 else 0.30
        st.nstages = 1.0 + a.d0 / 6.0
        T = cm.delay_tables(cn, c.vt, st, a.d0, slew_k, vdd_override=vdd_ov)
        cache[key] = T
    L.append("      timing () {")
    L.append('        related_pin : "%s";' % a.frm)
    L.append("        timing_sense : %s;" % a.sense)
    L.append("        timing_type : %s;" % a.ttype)
    if a.when: L.append('        when : "%s";' % a.when)
    sg = T["sig"]
    parts = []
    if a.rise: parts += [("cell_rise", "rise_transition", True)]
    if a.fall: parts += [("cell_fall", "fall_transition", False)]
    for dn, tn, rise in parts:
        tbl(L, 8, dn, "delay_template_7x7", cm.SLEWS, st.loads, T[dn])
        tbl(L, 8, tn, "delay_template_7x7", cm.SLEWS, st.loads, T[tn])
        if model in ("nldm", "ccs"):
            tbl(L, 8, "ocv_sigma_" + dn, "delay_template_7x7", cm.SLEWS, st.loads,
                [[v * sg for v in r] for r in T[dn]], extra=['sigma_type : "early_and_late";'])
            tbl(L, 8, "ocv_sigma_" + tn, "delay_template_7x7", cm.SLEWS, st.loads,
                [[v * sg * 1.2 for v in r] for r in T[tn]], extra=['sigma_type : "early_and_late";'])
    if model == "ccs":
        for dn, tn, rise in parts:
            L.append("        output_current_%s () {" % ("rise" if rise else "fall"))
            for si in cm.CCS_SI:
                for li in cm.CCS_LI:
                    s = cm.SLEWS[si]; C = st.loads[li]
                    ref, ts, vals = cm.ccs_vector(s, T[dn][si][li], T[tn][si][li], C, V, rise)
                    L.append("          vector (ccs_template) {")
                    L.append("            reference_time : %s;" % F(ref))
                    L.append('            index_1 ("%s"); index_2 ("%s");' % (F(s), F(C)))
                    L.append('            index_3 ("%s");' % row(ts))
                    L.append('            values ("%s");' % row(vals))
                    L.append("          }")
            L.append("        }")
    if model == "ecsm":
        for dn, tn, rise in parts:
            L.append("        ecsm_waveform_set (ecsm_%s) {" % ("rise" if rise else "fall"))
            for si in cm.CCS_SI:
                for li in cm.CCS_LI:
                    s = cm.SLEWS[si]; C = st.loads[li]
                    times = cm.ecsm_times(s, T[dn][si][li], T[tn][si][li])
                    L.append("          ecsm_waveform (ecsm_template) {")
                    L.append('            index_1 ("%s"); index_2 ("%s");' % (F(s), F(C)))
                    L.append('            index_3 ("%s");' % row(cm.ECSM_V))
                    L.append('            values ("%s");' % row(times))
                    L.append("          }")
            L.append("        }")
    L.append("      }")

def write_lib(path, libname, cells, corner, model, cache):
    L = []
    mbw = sorted(set(p.width for c in cells for p in c.pins if p.width > 1))
    lib_header(libname, corner, vmap_for(cells, corner), L, mbw)
    for c in cells:
        write_cell(L, c, corner, model, cache)
    L.append("}")
    with open(path, "w") as f:
        f.write("\n".join(L) + "\n")

from charmodel import constraint_table   # noqa (used above)
