"""Transistor-netlist builder (static CMOS series/parallel networks, TGs, clocked inverters).
The same netlist is the single source for: SPICE subckt, pin capacitances, drive
resistances, leakage stacks, cell width (gate columns) and GDS device placement."""
from tech import VT_FLAVORS

# nominal (TT, 0.70 V, 25C, SVT) unit-device electricals for one 3-fin finger
R_N1 = 4.6        # kOhm, NMOS 3-fin finger, effective switching resistance
R_P1 = 5.1        # kOhm, PMOS
CG_FIN = 0.100    # fF gate cap per fin (per device)
CD_FIN = 0.055    # fF drain/source diffusion + MOL cap per fin
STACK_K = 0.60    # series-stack resistance increment per extra device

def dual(e):
    if isinstance(e, str): return e
    k, items = e
    return ("p" if k == "s" else "s", [dual(i) for i in items])

def depth(e):
    if isinstance(e, str): return 1
    k, items = e
    return sum(depth(i) for i in items) if k == "s" else max(depth(i) for i in items)

def leaves(e, acc=None):
    if acc is None: acc = []
    if isinstance(e, str):
        if e not in acc: acc.append(e)
    else:
        for i in e[1]: leaves(i, acc)
    return acc

class Dev:
    __slots__ = ("t", "d", "g", "s", "b", "nf", "nfin", "vt", "kind", "l")
    def __init__(s, t, d, g, src, b, nf, nfin, vt, kind="logic", l=20):
        s.t, s.d, s.g, s.s, s.b, s.nf, s.nfin, s.vt, s.kind, s.l = t, d, g, src, b, nf, nfin, vt, kind, l

class Stage:
    def __init__(s, out, ins, rn, rp, cpar, sup):
        s.out, s.ins, s.rn, s.rp, s.cpar, s.sup = out, ins, rn, rp, cpar, sup

class NB:
    def __init__(s, vt, vdd="VDD", vss="VSS"):
        s.vt = vt; s.devs = []; s.stages = {}; s.k = 0
        s.vdd = vdd; s.vss = vss
        s.extra = []          # extra raw SPICE lines (diodes, resistors, caps)
    def net(s, p="n"):
        s.k += 1; return "%s%d" % (p, s.k)
    def fet(s, t, d, g, src, nf=1, nfin=3, b=None, vt=None, kind="logic", l=20):
        if b is None: b = s.vss if t == "n" else s.vdd
        s.devs.append(Dev(t, d, g, src, b, nf, nfin, vt or s.vt, kind, l))
    def _netw(s, t, e, top, bot, nf, nfin, b, vt):
        if isinstance(e, str):
            s.fet(t, top, e, bot, nf, nfin, b, vt); return
        k, items = e
        if k == "p":
            for it in items: s._netw(t, it, top, bot, nf, nfin, b, vt)
        else:
            nodes = [top] + [s.net() for _ in items[:-1]] + [bot]
            for i, it in enumerate(items): s._netw(t, it, nodes[i], nodes[i + 1], nf, nfin, b, vt)
    def gate(s, out, pd, nf=1, nfin=3, sup=None, gnd=None, vt=None):
        sup = sup or s.vdd; gnd = gnd or s.vss
        s._netw("n", pd, out, gnd, nf, nfin, gnd, vt)
        s._netw("p", dual(pd), sup, out, nf, nfin, sup, vt)
        dn, dp = depth(pd), depth(dual(pd))
        f = 3.0 / nfin / nf
        rn = R_N1 * f * (1 + STACK_K * (dn - 1))
        rp = R_P1 * f * (1 + STACK_K * (dp - 1))
        # output diffusion: devices touching out
        npar = len([1 for d in s.devs[-50:] if d.d == out or d.s == out])
        cpar = CD_FIN * nfin * nf * max(2, npar) * 0.5
        s.stages[out] = Stage(out, leaves(pd), rn, rp, cpar, sup)
        return out
    # convenience
    def inv(s, out, a, nf=1, nfin=3, **k):   return s.gate(out, a, nf, nfin, **k)
    def nand(s, out, ins, nf=1, nfin=3, **k): return s.gate(out, ("s", list(ins)), nf, nfin, **k)
    def nor(s, out, ins, nf=1, nfin=3, **k):  return s.gate(out, ("p", list(ins)), nf, nfin, **k)
    def tg(s, a, b, gn, gp, nf=1, nfin=3, sup=None, gnd=None):
        s.fet("n", a, gn, b, nf, nfin, b=gnd or s.vss)
        s.fet("p", a, gp, b, nf, nfin, b=sup or s.vdd)
    def cinv(s, out, a, en, enb, nf=1, nfin=1, sup=None, gnd=None, l=40):
        """clocked (tristate) keeper inverter: drives !a when en=1 (weak: 1 fin, long L)"""
        sup = sup or s.vdd; gnd = gnd or s.vss
        x, y = s.net(), s.net()
        s.fet("p", x, a, sup, nf, nfin, b=sup, l=l); s.fet("p", out, enb, x, nf, nfin, b=sup, l=l)
        s.fet("n", out, en, y, nf, nfin, b=gnd, l=l); s.fet("n", y, a, gnd, nf, nfin, b=gnd, l=l)

    # --------------------------------------------------------------- metrics
    def pin_cap(s, pin):
        return sum(d.nfin * d.nf * CG_FIN * (d.l / 20.0) for d in s.devs if d.g == pin)
    def gate_columns(s):
        n = sum(d.nf for d in s.devs if d.t == "n" and d.kind != "cap")
        p = sum(d.nf for d in s.devs if d.t == "p" and d.kind != "cap")
        c = sum(d.nf for d in s.devs if d.kind == "cap")
        return max(n, p) + c // 2
    def fins_total(s):
        return sum(d.nf * d.nfin for d in s.devs)
    def internal_cap(s):
        """total switched internal capacitance estimate (fF) excluding external pins"""
        cg = sum(d.nfin * d.nf * CG_FIN for d in s.devs)
        cd = sum(d.nfin * d.nf * CD_FIN for d in s.devs)
        return 0.35 * cg + 0.5 * cd
    def off_fins(s):
        """average off-state fins between rails, crude: half of all fins leak, stacks reduce"""
        return 0.5 * s.fins_total()
    def stage_delay(s, st, cl):
        return 0.69 * 0.5 * (st.rn + st.rp) * (cl + st.cpar)
    def fanout_cap(s, node):
        return s.pin_cap(node) + (s.stages[node].cpar if node in s.stages else 0.0)
    def path_delay(s, src, dst):
        """longest static-stage path delay (ps, nominal) from src node to the input of
        the stage that drives dst (dst stage itself excluded: its load is external)."""
        memo = {}
        def arr(node, seen=()):
            if node == src: return 0.0
            if node in memo: return memo[node]
            st = s.stages.get(node)
            if st is None or node in seen: return None
            best = None
            for i in st.ins:
                a = arr(i, seen + (node,))
                if a is None: continue
                d = a + (s.stage_delay(st, s.pin_cap(node) + 0.0) if node != dst else 0.0)
                best = d if best is None or d > best else best
            memo[node] = best
            return best
        v = arr(dst)
        return v
    # --------------------------------------------------------------- SPICE
    def spice_lines(s, model_of):
        out = []
        for i, d in enumerate(s.devs):
            m = model_of(d)
            nm = "M%s%d" % ("N" if d.t == "n" else "P", i)
            if d.kind == "io":
                out.append("%s %s %s %s %s %s L=%dn W=%dn NF=%d" % (nm, d.d, d.g, d.s, d.b, m, d.l, d.nfin * 100, d.nf))
            else:
                out.append("%s %s %s %s %s %s L=%dn NFIN=%d NF=%d" % (nm, d.d, d.g, d.s, d.b, m, d.l, d.nfin, d.nf))
        return out + s.extra
