// R14N7 synthetic 7nm-class FinFET PDK v1.0.0 (9-track variant) -- PREDICTIVE, NOT SILICON-CALIBRATED, NOT FOR MANUFACTURING
// pmk LVT library
`timescale 1ps/1fs

`celldefine
module HDRSW_X1_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FTRSW_X1_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HDRSW_X2_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FTRSW_X2_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HDRSW_X4_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FTRSW_X4_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HDRSWMR_X4_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FTRSWMR_X4_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HDRSWMR_X8_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FTRSWMR_X8_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HDRSWMR_X16_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEP === 1'b0) ? VDD : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FTRSWMR_X16_LVT (SLEEP, SLEEPOUT
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEP;
  output SLEEPOUT;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT = SLEEP;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEP === 1'b0) ? VSS : 1'bz;
`endif
  specify
    (SLEEP => SLEEPOUT) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HDRSW2S_X1_LVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VDD : 1'bz;
`endif
  specify
    (SLEEPIN1 => SLEEPOUT1) = (0, 0);
    (SLEEPIN2 => SLEEPOUT2) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FTRSW2S_X1_LVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VSS : 1'bz;
`endif
  specify
    (SLEEPIN1 => SLEEPOUT1) = (0, 0);
    (SLEEPIN2 => SLEEPOUT2) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HDRSW2S_X2_LVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VDD : 1'bz;
`endif
  specify
    (SLEEPIN1 => SLEEPOUT1) = (0, 0);
    (SLEEPIN2 => SLEEPOUT2) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FTRSW2S_X2_LVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VSS : 1'bz;
`endif
  specify
    (SLEEPIN1 => SLEEPOUT1) = (0, 0);
    (SLEEPIN2 => SLEEPOUT2) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HDRSW2S_X4_LVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VDD : 1'bz;
`endif
  specify
    (SLEEPIN1 => SLEEPOUT1) = (0, 0);
    (SLEEPIN2 => SLEEPOUT2) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FTRSW2S_X4_LVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VSS : 1'bz;
`endif
  specify
    (SLEEPIN1 => SLEEPOUT1) = (0, 0);
    (SLEEPIN2 => SLEEPOUT2) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module HDRSW2S_X8_LVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VVDD, VSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VVDD, VSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVDD = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VDD : 1'bz;
`endif
  specify
    (SLEEPIN1 => SLEEPOUT1) = (0, 0);
    (SLEEPIN2 => SLEEPOUT2) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module FTRSW2S_X8_LVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2
`ifdef R14_PG_PINS
  , VDD, VSS, VVSS
`endif
  );
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
`ifdef R14_PG_PINS
  inout VDD, VSS, VVSS;
`endif
  assign SLEEPOUT1 = SLEEPIN1;
  assign SLEEPOUT2 = SLEEPIN2;
`ifdef R14_PG_PINS
  assign VVSS = (SLEEPIN1 === 1'b0 || SLEEPIN2 === 1'b0) ? VSS : 1'bz;
`endif
  specify
    (SLEEPIN1 => SLEEPOUT1) = (0, 0);
    (SLEEPIN2 => SLEEPOUT2) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLO_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLOUB_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOHI_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOHIUB_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLON_X1_LVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
  specify
    (A => Y) = (0, 0);
    (ISON => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLONUB_X1_LVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
  specify
    (A => Y) = (0, 0);
    (ISON => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLAT_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, A, ~ISO, 1'b1, 1'b1, notifier);
  buf (Y, IQ);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLO_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLOUB_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOHI_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOHIUB_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLON_X2_LVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
  specify
    (A => Y) = (0, 0);
    (ISON => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLONUB_X2_LVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
  specify
    (A => Y) = (0, 0);
    (ISON => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLAT_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, A, ~ISO, 1'b1, 1'b1, notifier);
  buf (Y, IQ);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLO_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLOUB_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOHI_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOHIUB_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLON_X4_LVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
  specify
    (A => Y) = (0, 0);
    (ISON => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLONUB_X4_LVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
  specify
    (A => Y) = (0, 0);
    (ISON => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLAT_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  reg notifier; wire IQ;
  r14_udp_latch u_l (IQ, A, ~ISO, 1'b1, 1'b1, notifier);
  buf (Y, IQ);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLO_X8_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOHI_X8_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module ISOLON_X8_LVT (A, ISON, Y
`ifdef R14_PG_PINS
  , VDD, VSS
`endif
  );
  input A;
  input ISON;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VSS;
`endif
  assign Y = (A & ISON);
  specify
    (A => Y) = (0, 0);
    (ISON => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLH_X1_LVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHL_X1_LVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHUB_X1_LVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOLO_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOLO_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOLOUB_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOLOUB_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOHI_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOHI_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOHIUB_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOHIUB_X1_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLH_X2_LVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHL_X2_LVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHUB_X2_LVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOLO_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOLO_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOLOUB_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOLOUB_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOHI_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOHI_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOHIUB_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOHIUB_X2_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLH_X4_LVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHL_X4_LVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHUB_X4_LVT (A, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOLO_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOLO_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOLOUB_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOLOUB_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A & ~ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOHI_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOHI_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLLHISOHIUB_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VDD, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VDD, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module LVLHLISOHIUB_X4_LVT (A, ISO, Y
`ifdef R14_PG_PINS
  , VDDL, VSS
`endif
  );
  input A;
  input ISO;
  output Y;
`ifdef R14_PG_PINS
  inout VDDL, VSS;
`endif
  assign Y = (A | ISO);
  specify
    (A => Y) = (0, 0);
    (ISO => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module RETDFF_X1_LVT (D, CK, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input CK;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  reg notifier;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, 1'b1, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, NRET, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module RETDFF_X2_LVT (D, CK, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input CK;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  reg notifier;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, 1'b1, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, NRET, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module RETDFFR_X1_LVT (D, CK, RN, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  reg notifier;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, RN, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, NRET, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module RETDFFR_X2_LVT (D, CK, RN, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input CK;
  input RN;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  reg notifier;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, D, ck_i, RN, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, NRET, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module RETSDFF_X1_LVT (D, SI, SE, CK, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, ck_i, 1'b1, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK, NRET, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module RETSDFF_X2_LVT (D, SI, SE, CK, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, ck_i, 1'b1, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK, NRET, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module RETSDFFR_X1_LVT (D, SI, SE, CK, RN, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, ck_i, RN, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK, NRET, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module RETSDFFR_X2_LVT (D, SI, SE, CK, RN, NRET, Q
`ifdef R14_PG_PINS
  , VDD, VDDR, VSS
`endif
  );
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input NRET;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDR, VSS;
`endif
  reg notifier;
  wire d_sc = SE ? SI : D;
  wire ck_i = CK & NRET;  // NRET=0: retain (clock blocked, slave on VDDR)
  wire IQ;
  r14_udp_ff u_ff (IQ, d_sc, ck_i, RN, 1'b1, notifier);
`ifdef R14_PG_PINS
  assign Q = (VDD === 1'b1) ? IQ : 1'bx;
`else
  buf (Q, IQ);
`endif
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK &&& (SE == 1'b0), D, 0, 0, notifier);
    $setuphold(posedge CK, NRET, 0, 0, notifier);
    $setuphold(posedge CK &&& (SE == 1'b1), SI, 0, 0, notifier);
    $setuphold(posedge CK, SE, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONBUF_X1_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONBUF_X2_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONBUF_X4_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONBUF_X8_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONINV_X1_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONINV_X2_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONINV_X4_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONINV_X8_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = ~A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONCKBUF_X1_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONCKBUF_X2_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONCKBUF_X4_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONCKBUF_X8_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONDLY_X1_LVT (A, Y
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input A;
  output Y;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  assign Y = A;
  specify
    (A => Y) = (0, 0);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONDFFR_X1_LVT (D, E, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input D;
  input E;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  reg notifier;
  wire d_en = E ? D : IQ;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_en, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

`celldefine
module AONDFFR_X2_LVT (D, E, CK, RN, Q
`ifdef R14_PG_PINS
  , VDD, VDDB, VSS
`endif
  );
  input D;
  input E;
  input CK;
  input RN;
  output Q;
`ifdef R14_PG_PINS
  inout VDD, VDDB, VSS;
`endif
  reg notifier;
  wire d_en = E ? D : IQ;
  wire IQ;
  r14_udp_ff u_ff (IQ, d_en, CK, RN, 1'b1, notifier);
  buf (Q, IQ);
  specify
    (posedge CK => (Q +: D)) = (0, 0);
    (RN => Q) = (0, 0);
    $setuphold(posedge CK, D, 0, 0, notifier);
    $setuphold(posedge CK, E, 0, 0, notifier);
    $recrem(posedge RN, posedge CK, 0, 0, notifier);
    $width(posedge CK, 0, 0, notifier);
    $width(negedge CK, 0, 0, notifier);
    $width(negedge RN, 0, 0, notifier);
  endspecify
endmodule
`endcelldefine

