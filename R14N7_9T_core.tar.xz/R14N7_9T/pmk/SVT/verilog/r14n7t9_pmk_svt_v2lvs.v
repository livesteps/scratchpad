// R14N7 synthetic 7nm-class FinFET PDK v1.0.0 (9-track variant) -- PREDICTIVE, NOT SILICON-CALIBRATED, NOT FOR MANUFACTURING
// Calibre v2lvs interface library: port order == CDL .SUBCKT order (buses expand to <i>),
// power/ground pins explicit.  Use with:  v2lvs -v top.v -l <this> -lsp <cells>.cdl -o top.sp

module HDRSW_X1_SVT (SLEEP, SLEEPOUT, VDD, VVDD, VSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VVDD, VSS;
endmodule
module FTRSW_X1_SVT (SLEEP, SLEEPOUT, VDD, VSS, VVSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VSS, VVSS;
endmodule
module HDRSW_X2_SVT (SLEEP, SLEEPOUT, VDD, VVDD, VSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VVDD, VSS;
endmodule
module FTRSW_X2_SVT (SLEEP, SLEEPOUT, VDD, VSS, VVSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VSS, VVSS;
endmodule
module HDRSW_X4_SVT (SLEEP, SLEEPOUT, VDD, VVDD, VSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VVDD, VSS;
endmodule
module FTRSW_X4_SVT (SLEEP, SLEEPOUT, VDD, VSS, VVSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VSS, VVSS;
endmodule
module HDRSWMR_X4_SVT (SLEEP, SLEEPOUT, VDD, VVDD, VSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VVDD, VSS;
endmodule
module FTRSWMR_X4_SVT (SLEEP, SLEEPOUT, VDD, VSS, VVSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VSS, VVSS;
endmodule
module HDRSWMR_X8_SVT (SLEEP, SLEEPOUT, VDD, VVDD, VSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VVDD, VSS;
endmodule
module FTRSWMR_X8_SVT (SLEEP, SLEEPOUT, VDD, VSS, VVSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VSS, VVSS;
endmodule
module HDRSWMR_X16_SVT (SLEEP, SLEEPOUT, VDD, VVDD, VSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VVDD, VSS;
endmodule
module FTRSWMR_X16_SVT (SLEEP, SLEEPOUT, VDD, VSS, VVSS);
  input SLEEP;
  output SLEEPOUT;
  inout VDD, VSS, VVSS;
endmodule
module HDRSW2S_X1_SVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2, VDD, VVDD, VSS);
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
  inout VDD, VVDD, VSS;
endmodule
module FTRSW2S_X1_SVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2, VDD, VSS, VVSS);
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
  inout VDD, VSS, VVSS;
endmodule
module HDRSW2S_X2_SVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2, VDD, VVDD, VSS);
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
  inout VDD, VVDD, VSS;
endmodule
module FTRSW2S_X2_SVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2, VDD, VSS, VVSS);
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
  inout VDD, VSS, VVSS;
endmodule
module HDRSW2S_X4_SVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2, VDD, VVDD, VSS);
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
  inout VDD, VVDD, VSS;
endmodule
module FTRSW2S_X4_SVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2, VDD, VSS, VVSS);
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
  inout VDD, VSS, VVSS;
endmodule
module HDRSW2S_X8_SVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2, VDD, VVDD, VSS);
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
  inout VDD, VVDD, VSS;
endmodule
module FTRSW2S_X8_SVT (SLEEPIN1, SLEEPIN2, SLEEPOUT1, SLEEPOUT2, VDD, VSS, VVSS);
  input SLEEPIN1;
  input SLEEPIN2;
  output SLEEPOUT1;
  output SLEEPOUT2;
  inout VDD, VSS, VVSS;
endmodule
module ISOLO_X1_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLOUB_X1_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOHI_X1_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOHIUB_X1_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLON_X1_SVT (A, ISON, Y, VDD, VSS);
  input A;
  input ISON;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLONUB_X1_SVT (A, ISON, Y, VDD, VSS);
  input A;
  input ISON;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLAT_X1_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLO_X2_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLOUB_X2_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOHI_X2_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOHIUB_X2_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLON_X2_SVT (A, ISON, Y, VDD, VSS);
  input A;
  input ISON;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLONUB_X2_SVT (A, ISON, Y, VDD, VSS);
  input A;
  input ISON;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLAT_X2_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLO_X4_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLOUB_X4_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOHI_X4_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOHIUB_X4_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLON_X4_SVT (A, ISON, Y, VDD, VSS);
  input A;
  input ISON;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLONUB_X4_SVT (A, ISON, Y, VDD, VSS);
  input A;
  input ISON;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLAT_X4_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLO_X8_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOHI_X8_SVT (A, ISO, Y, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDD, VSS;
endmodule
module ISOLON_X8_SVT (A, ISON, Y, VDD, VSS);
  input A;
  input ISON;
  output Y;
  inout VDD, VSS;
endmodule
module LVLLH_X1_SVT (A, Y, VDDL, VDD, VSS);
  input A;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHL_X1_SVT (A, Y, VDDL, VSS);
  input A;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHUB_X1_SVT (A, Y, VDDL, VDD, VSS);
  input A;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLLHISOLO_X1_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOLO_X1_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHISOLOUB_X1_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOLOUB_X1_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHISOHI_X1_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOHI_X1_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHISOHIUB_X1_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOHIUB_X1_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLH_X2_SVT (A, Y, VDDL, VDD, VSS);
  input A;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHL_X2_SVT (A, Y, VDDL, VSS);
  input A;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHUB_X2_SVT (A, Y, VDDL, VDD, VSS);
  input A;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLLHISOLO_X2_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOLO_X2_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHISOLOUB_X2_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOLOUB_X2_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHISOHI_X2_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOHI_X2_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHISOHIUB_X2_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOHIUB_X2_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLH_X4_SVT (A, Y, VDDL, VDD, VSS);
  input A;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHL_X4_SVT (A, Y, VDDL, VSS);
  input A;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHUB_X4_SVT (A, Y, VDDL, VDD, VSS);
  input A;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLLHISOLO_X4_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOLO_X4_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHISOLOUB_X4_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOLOUB_X4_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHISOHI_X4_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOHI_X4_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module LVLLHISOHIUB_X4_SVT (A, ISO, Y, VDDL, VDD, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VDD, VSS;
endmodule
module LVLHLISOHIUB_X4_SVT (A, ISO, Y, VDDL, VSS);
  input A;
  input ISO;
  output Y;
  inout VDDL, VSS;
endmodule
module RETDFF_X1_SVT (D, CK, NRET, Q, VDD, VDDR, VSS);
  input D;
  input CK;
  input NRET;
  output Q;
  inout VDD, VDDR, VSS;
endmodule
module RETDFF_X2_SVT (D, CK, NRET, Q, VDD, VDDR, VSS);
  input D;
  input CK;
  input NRET;
  output Q;
  inout VDD, VDDR, VSS;
endmodule
module RETDFFR_X1_SVT (D, CK, RN, NRET, Q, VDD, VDDR, VSS);
  input D;
  input CK;
  input RN;
  input NRET;
  output Q;
  inout VDD, VDDR, VSS;
endmodule
module RETDFFR_X2_SVT (D, CK, RN, NRET, Q, VDD, VDDR, VSS);
  input D;
  input CK;
  input RN;
  input NRET;
  output Q;
  inout VDD, VDDR, VSS;
endmodule
module RETSDFF_X1_SVT (D, SI, SE, CK, NRET, Q, VDD, VDDR, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input NRET;
  output Q;
  inout VDD, VDDR, VSS;
endmodule
module RETSDFF_X2_SVT (D, SI, SE, CK, NRET, Q, VDD, VDDR, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input NRET;
  output Q;
  inout VDD, VDDR, VSS;
endmodule
module RETSDFFR_X1_SVT (D, SI, SE, CK, RN, NRET, Q, VDD, VDDR, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input NRET;
  output Q;
  inout VDD, VDDR, VSS;
endmodule
module RETSDFFR_X2_SVT (D, SI, SE, CK, RN, NRET, Q, VDD, VDDR, VSS);
  input D;
  input SI;
  input SE;
  input CK;
  input RN;
  input NRET;
  output Q;
  inout VDD, VDDR, VSS;
endmodule
module AONBUF_X1_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONBUF_X2_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONBUF_X4_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONBUF_X8_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONINV_X1_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONINV_X2_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONINV_X4_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONINV_X8_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONCKBUF_X1_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONCKBUF_X2_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONCKBUF_X4_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONCKBUF_X8_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONDLY_X1_SVT (A, Y, VDD, VDDB, VSS);
  input A;
  output Y;
  inout VDD, VDDB, VSS;
endmodule
module AONDFFR_X1_SVT (D, E, CK, RN, Q, VDD, VDDB, VSS);
  input D;
  input E;
  input CK;
  input RN;
  output Q;
  inout VDD, VDDB, VSS;
endmodule
module AONDFFR_X2_SVT (D, E, CK, RN, Q, VDD, VDDB, VSS);
  input D;
  input E;
  input CK;
  input RN;
  output Q;
  inout VDD, VDDB, VSS;
endmodule
