* R14N7 synthetic 7nm-class FinFET PDK v1.0.0 (9-track variant) -- PREDICTIVE, NOT SILICON-CALIBRATED, NOT FOR MANUFACTURING
* pmk HVT simulation netlists
* Device instance syntax: M<n> d g s b <model> L=<Lg> NFIN=<fins/finger> NF=<fingers>

.SUBCKT HDRSW_X1_HVT SLEEP SLEEPOUT VDD VVDD VSS
* Header power switch, simple type (PMOS, 6 fingers, Ron=468 ohm @TT), daisy-chain SLEEPOUT, 1-row | pmk_psw | area 0.17496 um2 | 10 site(s) x 1 row(s)
MP0 VVDD SLEEP VDD VDD pmos_hvt L=20n NFIN=3 NF=6
MN1 sl1 SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP2 VDD SLEEP sl1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN3 SLEEPOUT sl1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD sl1 SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS HDRSW_X1_HVT

.SUBCKT FTRSW_X1_HVT SLEEP SLEEPOUT VDD VSS VVSS
* Footer power switch, simple type (NMOS, 6 fingers, Ron=422 ohm @TT), daisy-chain SLEEPOUT, 1-row | pmk_psw | area 0.17496 um2 | 10 site(s) x 1 row(s)
MN0 slb SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SLEEP slb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 VVSS slb VSS VSS nmos_hvt L=20n NFIN=3 NF=6
MN3 SLEEPOUT slb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD slb SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS FTRSW_X1_HVT

.SUBCKT HDRSW_X2_HVT SLEEP SLEEPOUT VDD VVDD VSS
* Header power switch, simple type (PMOS, 12 fingers, Ron=234 ohm @TT), daisy-chain SLEEPOUT, 1-row | pmk_psw | area 0.27994 um2 | 16 site(s) x 1 row(s)
MP0 VVDD SLEEP VDD VDD pmos_hvt L=20n NFIN=3 NF=12
MN1 sl1 SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP2 VDD SLEEP sl1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN3 SLEEPOUT sl1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD sl1 SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS HDRSW_X2_HVT

.SUBCKT FTRSW_X2_HVT SLEEP SLEEPOUT VDD VSS VVSS
* Footer power switch, simple type (NMOS, 12 fingers, Ron=211 ohm @TT), daisy-chain SLEEPOUT, 1-row | pmk_psw | area 0.27994 um2 | 16 site(s) x 1 row(s)
MN0 slb SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SLEEP slb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 VVSS slb VSS VSS nmos_hvt L=20n NFIN=3 NF=12
MN3 SLEEPOUT slb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD slb SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS FTRSW_X2_HVT

.SUBCKT HDRSW_X4_HVT SLEEP SLEEPOUT VDD VVDD VSS
* Header power switch, simple type (PMOS, 24 fingers, Ron=117 ohm @TT), daisy-chain SLEEPOUT, 1-row | pmk_psw | area 0.48989 um2 | 28 site(s) x 1 row(s)
MP0 VVDD SLEEP VDD VDD pmos_hvt L=20n NFIN=3 NF=24
MN1 sl1 SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP2 VDD SLEEP sl1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN3 SLEEPOUT sl1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD sl1 SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS HDRSW_X4_HVT

.SUBCKT FTRSW_X4_HVT SLEEP SLEEPOUT VDD VSS VVSS
* Footer power switch, simple type (NMOS, 24 fingers, Ron=105 ohm @TT), daisy-chain SLEEPOUT, 1-row | pmk_psw | area 0.48989 um2 | 28 site(s) x 1 row(s)
MN0 slb SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SLEEP slb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 VVSS slb VSS VSS nmos_hvt L=20n NFIN=3 NF=24
MN3 SLEEPOUT slb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD slb SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS FTRSW_X4_HVT

.SUBCKT HDRSWMR_X4_HVT SLEEP SLEEPOUT VDD VVDD VSS
* Header power switch, simple type (PMOS, 24 fingers, Ron=117 ohm @TT), daisy-chain SLEEPOUT, 2-row | pmk_psw | area 0.52488 um2 | 15 site(s) x 2 row(s)
MP0 VVDD SLEEP VDD VDD pmos_hvt L=20n NFIN=3 NF=24
MN1 sl1 SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP2 VDD SLEEP sl1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN3 SLEEPOUT sl1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD sl1 SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS HDRSWMR_X4_HVT

.SUBCKT FTRSWMR_X4_HVT SLEEP SLEEPOUT VDD VSS VVSS
* Footer power switch, simple type (NMOS, 24 fingers, Ron=105 ohm @TT), daisy-chain SLEEPOUT, 2-row | pmk_psw | area 0.52488 um2 | 15 site(s) x 2 row(s)
MN0 slb SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SLEEP slb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 VVSS slb VSS VSS nmos_hvt L=20n NFIN=3 NF=24
MN3 SLEEPOUT slb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD slb SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS FTRSWMR_X4_HVT

.SUBCKT HDRSWMR_X8_HVT SLEEP SLEEPOUT VDD VVDD VSS
* Header power switch, simple type (PMOS, 48 fingers, Ron=58 ohm @TT), daisy-chain SLEEPOUT, 2-row | pmk_psw | area 0.94478 um2 | 27 site(s) x 2 row(s)
MP0 VVDD SLEEP VDD VDD pmos_hvt L=20n NFIN=3 NF=48
MN1 sl1 SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP2 VDD SLEEP sl1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN3 SLEEPOUT sl1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD sl1 SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS HDRSWMR_X8_HVT

.SUBCKT FTRSWMR_X8_HVT SLEEP SLEEPOUT VDD VSS VVSS
* Footer power switch, simple type (NMOS, 48 fingers, Ron=53 ohm @TT), daisy-chain SLEEPOUT, 2-row | pmk_psw | area 0.94478 um2 | 27 site(s) x 2 row(s)
MN0 slb SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SLEEP slb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 VVSS slb VSS VSS nmos_hvt L=20n NFIN=3 NF=48
MN3 SLEEPOUT slb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD slb SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS FTRSWMR_X8_HVT

.SUBCKT HDRSWMR_X16_HVT SLEEP SLEEPOUT VDD VVDD VSS
* Header power switch, simple type (PMOS, 96 fingers, Ron=29 ohm @TT), daisy-chain SLEEPOUT, 4-row | pmk_psw | area 1.88957 um2 | 27 site(s) x 4 row(s)
MP0 VVDD SLEEP VDD VDD pmos_hvt L=20n NFIN=3 NF=96
MN1 sl1 SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP2 VDD SLEEP sl1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN3 SLEEPOUT sl1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD sl1 SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS HDRSWMR_X16_HVT

.SUBCKT FTRSWMR_X16_HVT SLEEP SLEEPOUT VDD VSS VVSS
* Footer power switch, simple type (NMOS, 96 fingers, Ron=26 ohm @TT), daisy-chain SLEEPOUT, 4-row | pmk_psw | area 1.88957 um2 | 27 site(s) x 4 row(s)
MN0 slb SLEEP VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SLEEP slb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 VVSS slb VSS VSS nmos_hvt L=20n NFIN=3 NF=96
MN3 SLEEPOUT slb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD slb SLEEPOUT VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS FTRSWMR_X16_HVT

.SUBCKT HDRSW2S_X1_HVT SLEEPIN1 SLEEPIN2 SLEEPOUT1 SLEEPOUT2 VDD VVDD VSS
* Header power switch, mother-daughter type (trickle 1 + main 8 fingers, Ron=324 ohm @TT), in-rush control, 2-row | pmk_psw | area 0.31493 um2 | 9 site(s) x 2 row(s)
MP0 VVDD SLEEPIN1 VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP1 VVDD SLEEPIN2 VDD VDD pmos_hvt L=20n NFIN=3 NF=8
MN2 a1 SLEEPIN1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD SLEEPIN1 a1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 SLEEPOUT1 a1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP5 VDD a1 SLEEPOUT1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN6 a2 SLEEPIN2 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP7 VDD SLEEPIN2 a2 VDD pmos_hvt L=20n NFIN=2 NF=1
MN8 SLEEPOUT2 a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 VDD a2 SLEEPOUT2 VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS HDRSW2S_X1_HVT

.SUBCKT FTRSW2S_X1_HVT SLEEPIN1 SLEEPIN2 SLEEPOUT1 SLEEPOUT2 VDD VSS VVSS
* Footer power switch, mother-daughter type (trickle 1 + main 8 fingers, Ron=292 ohm @TT), in-rush control, 2-row | pmk_psw | area 0.31493 um2 | 9 site(s) x 2 row(s)
MN0 a1 SLEEPIN1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SLEEPIN1 a1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 a2 SLEEPIN2 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD SLEEPIN2 a2 VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 VVSS a1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN5 VVSS a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=8
MN6 SLEEPOUT1 a1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP7 VDD a1 SLEEPOUT1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN8 SLEEPOUT2 a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 VDD a2 SLEEPOUT2 VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS FTRSW2S_X1_HVT

.SUBCKT HDRSW2S_X2_HVT SLEEPIN1 SLEEPIN2 SLEEPOUT1 SLEEPOUT2 VDD VVDD VSS
* Header power switch, mother-daughter type (trickle 2 + main 16 fingers, Ron=162 ohm @TT), in-rush control, 2-row | pmk_psw | area 0.45490 um2 | 13 site(s) x 2 row(s)
MP0 VVDD SLEEPIN1 VDD VDD pmos_hvt L=20n NFIN=2 NF=2
MP1 VVDD SLEEPIN2 VDD VDD pmos_hvt L=20n NFIN=3 NF=16
MN2 a1 SLEEPIN1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD SLEEPIN1 a1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 SLEEPOUT1 a1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP5 VDD a1 SLEEPOUT1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN6 a2 SLEEPIN2 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP7 VDD SLEEPIN2 a2 VDD pmos_hvt L=20n NFIN=2 NF=1
MN8 SLEEPOUT2 a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 VDD a2 SLEEPOUT2 VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS HDRSW2S_X2_HVT

.SUBCKT FTRSW2S_X2_HVT SLEEPIN1 SLEEPIN2 SLEEPOUT1 SLEEPOUT2 VDD VSS VVSS
* Footer power switch, mother-daughter type (trickle 2 + main 16 fingers, Ron=146 ohm @TT), in-rush control, 2-row | pmk_psw | area 0.45490 um2 | 13 site(s) x 2 row(s)
MN0 a1 SLEEPIN1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SLEEPIN1 a1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 a2 SLEEPIN2 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD SLEEPIN2 a2 VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 VVSS a1 VSS VSS nmos_hvt L=20n NFIN=2 NF=2
MN5 VVSS a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=16
MN6 SLEEPOUT1 a1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP7 VDD a1 SLEEPOUT1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN8 SLEEPOUT2 a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 VDD a2 SLEEPOUT2 VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS FTRSW2S_X2_HVT

.SUBCKT HDRSW2S_X4_HVT SLEEPIN1 SLEEPIN2 SLEEPOUT1 SLEEPOUT2 VDD VVDD VSS
* Header power switch, mother-daughter type (trickle 4 + main 32 fingers, Ron=81 ohm @TT), in-rush control, 2-row | pmk_psw | area 0.76982 um2 | 22 site(s) x 2 row(s)
MP0 VVDD SLEEPIN1 VDD VDD pmos_hvt L=20n NFIN=2 NF=4
MP1 VVDD SLEEPIN2 VDD VDD pmos_hvt L=20n NFIN=3 NF=32
MN2 a1 SLEEPIN1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD SLEEPIN1 a1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 SLEEPOUT1 a1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP5 VDD a1 SLEEPOUT1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN6 a2 SLEEPIN2 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP7 VDD SLEEPIN2 a2 VDD pmos_hvt L=20n NFIN=2 NF=1
MN8 SLEEPOUT2 a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 VDD a2 SLEEPOUT2 VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS HDRSW2S_X4_HVT

.SUBCKT FTRSW2S_X4_HVT SLEEPIN1 SLEEPIN2 SLEEPOUT1 SLEEPOUT2 VDD VSS VVSS
* Footer power switch, mother-daughter type (trickle 4 + main 32 fingers, Ron=73 ohm @TT), in-rush control, 2-row | pmk_psw | area 0.76982 um2 | 22 site(s) x 2 row(s)
MN0 a1 SLEEPIN1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SLEEPIN1 a1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 a2 SLEEPIN2 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD SLEEPIN2 a2 VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 VVSS a1 VSS VSS nmos_hvt L=20n NFIN=2 NF=4
MN5 VVSS a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=32
MN6 SLEEPOUT1 a1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP7 VDD a1 SLEEPOUT1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN8 SLEEPOUT2 a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 VDD a2 SLEEPOUT2 VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS FTRSW2S_X4_HVT

.SUBCKT HDRSW2S_X8_HVT SLEEPIN1 SLEEPIN2 SLEEPOUT1 SLEEPOUT2 VDD VVDD VSS
* Header power switch, mother-daughter type (trickle 8 + main 64 fingers, Ron=40 ohm @TT), in-rush control, 2-row | pmk_psw | area 1.39968 um2 | 40 site(s) x 2 row(s)
MP0 VVDD SLEEPIN1 VDD VDD pmos_hvt L=20n NFIN=2 NF=8
MP1 VVDD SLEEPIN2 VDD VDD pmos_hvt L=20n NFIN=3 NF=64
MN2 a1 SLEEPIN1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD SLEEPIN1 a1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 SLEEPOUT1 a1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP5 VDD a1 SLEEPOUT1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN6 a2 SLEEPIN2 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP7 VDD SLEEPIN2 a2 VDD pmos_hvt L=20n NFIN=2 NF=1
MN8 SLEEPOUT2 a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 VDD a2 SLEEPOUT2 VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS HDRSW2S_X8_HVT

.SUBCKT FTRSW2S_X8_HVT SLEEPIN1 SLEEPIN2 SLEEPOUT1 SLEEPOUT2 VDD VSS VVSS
* Footer power switch, mother-daughter type (trickle 8 + main 64 fingers, Ron=36 ohm @TT), in-rush control, 2-row | pmk_psw | area 1.39968 um2 | 40 site(s) x 2 row(s)
MN0 a1 SLEEPIN1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SLEEPIN1 a1 VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 a2 SLEEPIN2 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD SLEEPIN2 a2 VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 VVSS a1 VSS VSS nmos_hvt L=20n NFIN=2 NF=8
MN5 VVSS a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=64
MN6 SLEEPOUT1 a1 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP7 VDD a1 SLEEPOUT1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN8 SLEEPOUT2 a2 VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 VDD a2 SLEEPOUT2 VDD pmos_hvt L=20n NFIN=3 NF=1
.ENDS FTRSW2S_X8_HVT

.SUBCKT ISOLO_X1_HVT A ISO Y VDD VSS
* Isolation clamp-0 (Y=A&!ISO), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.10498 um2 | 6 site(s) x 1 row(s)
MN0 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 n0 A n1 VSS nmos_hvt L=20n NFIN=3 NF=1
MN3 n1 isb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD A n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MP5 VDD isb n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN6 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP7 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS ISOLO_X1_HVT

.SUBCKT ISOLOUB_X1_HVT A ISO Y VDD VSS
* Isolation clamp-0 (Y=A&!ISO), unbuffered (logic stage drives output) | pmk_iso | area 0.08748 um2 | 5 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD A ab VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 Y ab VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MN3 Y ISO VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP4 VDD ab n1 VDD pmos_hvt L=20n NFIN=4 NF=1
MP5 n1 ISO Y VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS ISOLOUB_X1_HVT

.SUBCKT ISOHI_X1_HVT A ISO Y VDD VSS
* Isolation clamp-1 (Y=A|ISO), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.08748 um2 | 5 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MN1 n0 ISO VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP2 VDD A n1 VDD pmos_hvt L=20n NFIN=3 NF=1
MP3 n1 ISO n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN4 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP5 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS ISOHI_X1_HVT

.SUBCKT ISOHIUB_X1_HVT A ISO Y VDD VSS
* Isolation clamp-1 (Y=A|ISO), unbuffered (logic stage drives output) | pmk_iso | area 0.10498 um2 | 6 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD A ab VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 Y ab n1 VSS nmos_hvt L=20n NFIN=4 NF=1
MN5 n1 isb VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP6 VDD ab Y VDD pmos_hvt L=20n NFIN=4 NF=1
MP7 VDD isb Y VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS ISOHIUB_X1_HVT

.SUBCKT ISOLON_X1_HVT A ISON Y VDD VSS
* Isolation clamp-0, active-low enable (Y=A&ISON), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.08748 um2 | 5 site(s) x 1 row(s)
MN0 n0 A n1 VSS nmos_hvt L=20n NFIN=3 NF=1
MN1 n1 ISON VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP2 VDD A n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MP3 VDD ISON n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN4 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP5 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS ISOLON_X1_HVT

.SUBCKT ISOLONUB_X1_HVT A ISON Y VDD VSS
* Isolation clamp-0, active-low enable (Y=A&ISON), unbuffered (logic stage drives output) | pmk_iso | area 0.10498 um2 | 6 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD A ab VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISON VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISON isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 Y ab VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MN5 Y isb VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP6 VDD ab n1 VDD pmos_hvt L=20n NFIN=4 NF=1
MP7 n1 isb Y VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS ISOLONUB_X1_HVT

.SUBCKT ISOLAT_X1_HVT A ISO Y VDD VSS
* Latch-based isolation (holds last value while ISO=1), buffered | pmk_iso | area 0.15746 um2 | 9 site(s) x 1 row(s)
MN0 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 isi isb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD isb isi VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 A isb l1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP5 A isi l1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN6 l2 l1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP7 VDD l1 l2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP8 n1 l2 VDD VDD pmos_hvt L=40n NFIN=1 NF=1
MP9 l1 isb n1 VDD pmos_hvt L=40n NFIN=1 NF=1
MN10 l1 isi n2 VSS nmos_hvt L=40n NFIN=1 NF=1
MN11 n2 l2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN12 Y l2 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP13 VDD l2 Y VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS ISOLAT_X1_HVT

.SUBCKT ISOLO_X2_HVT A ISO Y VDD VSS
* Isolation clamp-0 (Y=A&!ISO), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.12247 um2 | 7 site(s) x 1 row(s)
MN0 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 n0 A n1 VSS nmos_hvt L=20n NFIN=3 NF=1
MN3 n1 isb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD A n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MP5 VDD isb n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN6 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP7 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS ISOLO_X2_HVT

.SUBCKT ISOLOUB_X2_HVT A ISO Y VDD VSS
* Isolation clamp-0 (Y=A&!ISO), unbuffered (logic stage drives output) | pmk_iso | area 0.12247 um2 | 7 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD A ab VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 Y ab VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MN3 Y ISO VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP4 VDD ab n1 VDD pmos_hvt L=20n NFIN=4 NF=2
MP5 n1 ISO Y VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS ISOLOUB_X2_HVT

.SUBCKT ISOHI_X2_HVT A ISO Y VDD VSS
* Isolation clamp-1 (Y=A|ISO), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.10498 um2 | 6 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MN1 n0 ISO VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP2 VDD A n1 VDD pmos_hvt L=20n NFIN=3 NF=1
MP3 n1 ISO n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN4 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP5 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS ISOHI_X2_HVT

.SUBCKT ISOHIUB_X2_HVT A ISO Y VDD VSS
* Isolation clamp-1 (Y=A|ISO), unbuffered (logic stage drives output) | pmk_iso | area 0.13997 um2 | 8 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD A ab VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 Y ab n1 VSS nmos_hvt L=20n NFIN=4 NF=2
MN5 n1 isb VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP6 VDD ab Y VDD pmos_hvt L=20n NFIN=4 NF=2
MP7 VDD isb Y VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS ISOHIUB_X2_HVT

.SUBCKT ISOLON_X2_HVT A ISON Y VDD VSS
* Isolation clamp-0, active-low enable (Y=A&ISON), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.10498 um2 | 6 site(s) x 1 row(s)
MN0 n0 A n1 VSS nmos_hvt L=20n NFIN=3 NF=1
MN1 n1 ISON VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP2 VDD A n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MP3 VDD ISON n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN4 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP5 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS ISOLON_X2_HVT

.SUBCKT ISOLONUB_X2_HVT A ISON Y VDD VSS
* Isolation clamp-0, active-low enable (Y=A&ISON), unbuffered (logic stage drives output) | pmk_iso | area 0.13997 um2 | 8 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD A ab VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISON VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISON isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 Y ab VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MN5 Y isb VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP6 VDD ab n1 VDD pmos_hvt L=20n NFIN=4 NF=2
MP7 n1 isb Y VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS ISOLONUB_X2_HVT

.SUBCKT ISOLAT_X2_HVT A ISO Y VDD VSS
* Latch-based isolation (holds last value while ISO=1), buffered | pmk_iso | area 0.17496 um2 | 10 site(s) x 1 row(s)
MN0 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 isi isb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD isb isi VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 A isb l1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP5 A isi l1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN6 l2 l1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP7 VDD l1 l2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP8 n1 l2 VDD VDD pmos_hvt L=40n NFIN=1 NF=1
MP9 l1 isb n1 VDD pmos_hvt L=40n NFIN=1 NF=1
MN10 l1 isi n2 VSS nmos_hvt L=40n NFIN=1 NF=1
MN11 n2 l2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN12 Y l2 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP13 VDD l2 Y VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS ISOLAT_X2_HVT

.SUBCKT ISOLO_X4_HVT A ISO Y VDD VSS
* Isolation clamp-0 (Y=A&!ISO), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.15746 um2 | 9 site(s) x 1 row(s)
MN0 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 n0 A n1 VSS nmos_hvt L=20n NFIN=3 NF=1
MN3 n1 isb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD A n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MP5 VDD isb n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN6 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP7 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=4
.ENDS ISOLO_X4_HVT

.SUBCKT ISOLOUB_X4_HVT A ISO Y VDD VSS
* Isolation clamp-0 (Y=A&!ISO), unbuffered (logic stage drives output) | pmk_iso | area 0.19246 um2 | 11 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD A ab VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 Y ab VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MN3 Y ISO VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP4 VDD ab n1 VDD pmos_hvt L=20n NFIN=4 NF=4
MP5 n1 ISO Y VDD pmos_hvt L=20n NFIN=4 NF=4
.ENDS ISOLOUB_X4_HVT

.SUBCKT ISOHI_X4_HVT A ISO Y VDD VSS
* Isolation clamp-1 (Y=A|ISO), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.13997 um2 | 8 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MN1 n0 ISO VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP2 VDD A n1 VDD pmos_hvt L=20n NFIN=3 NF=1
MP3 n1 ISO n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN4 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP5 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=4
.ENDS ISOHI_X4_HVT

.SUBCKT ISOHIUB_X4_HVT A ISO Y VDD VSS
* Isolation clamp-1 (Y=A|ISO), unbuffered (logic stage drives output) | pmk_iso | area 0.20995 um2 | 12 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD A ab VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 Y ab n1 VSS nmos_hvt L=20n NFIN=4 NF=4
MN5 n1 isb VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP6 VDD ab Y VDD pmos_hvt L=20n NFIN=4 NF=4
MP7 VDD isb Y VDD pmos_hvt L=20n NFIN=4 NF=4
.ENDS ISOHIUB_X4_HVT

.SUBCKT ISOLON_X4_HVT A ISON Y VDD VSS
* Isolation clamp-0, active-low enable (Y=A&ISON), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.13997 um2 | 8 site(s) x 1 row(s)
MN0 n0 A n1 VSS nmos_hvt L=20n NFIN=3 NF=1
MN1 n1 ISON VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP2 VDD A n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MP3 VDD ISON n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN4 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP5 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=4
.ENDS ISOLON_X4_HVT

.SUBCKT ISOLONUB_X4_HVT A ISON Y VDD VSS
* Isolation clamp-0, active-low enable (Y=A&ISON), unbuffered (logic stage drives output) | pmk_iso | area 0.20995 um2 | 12 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD A ab VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISON VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISON isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 Y ab VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MN5 Y isb VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP6 VDD ab n1 VDD pmos_hvt L=20n NFIN=4 NF=4
MP7 n1 isb Y VDD pmos_hvt L=20n NFIN=4 NF=4
.ENDS ISOLONUB_X4_HVT

.SUBCKT ISOLAT_X4_HVT A ISO Y VDD VSS
* Latch-based isolation (holds last value while ISO=1), buffered | pmk_iso | area 0.20995 um2 | 12 site(s) x 1 row(s)
MN0 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 isi isb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD isb isi VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 A isb l1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP5 A isi l1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN6 l2 l1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP7 VDD l1 l2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP8 n1 l2 VDD VDD pmos_hvt L=40n NFIN=1 NF=1
MP9 l1 isb n1 VDD pmos_hvt L=40n NFIN=1 NF=1
MN10 l1 isi n2 VSS nmos_hvt L=40n NFIN=1 NF=1
MN11 n2 l2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN12 Y l2 VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP13 VDD l2 Y VDD pmos_hvt L=20n NFIN=4 NF=4
.ENDS ISOLAT_X4_HVT

.SUBCKT ISOLO_X8_HVT A ISO Y VDD VSS
* Isolation clamp-0 (Y=A&!ISO), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.22745 um2 | 13 site(s) x 1 row(s)
MN0 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 n0 A n1 VSS nmos_hvt L=20n NFIN=3 NF=1
MN3 n1 isb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDD A n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MP5 VDD isb n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN6 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=8
MP7 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=8
.ENDS ISOLO_X8_HVT

.SUBCKT ISOHI_X8_HVT A ISO Y VDD VSS
* Isolation clamp-1 (Y=A|ISO), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.20995 um2 | 12 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MN1 n0 ISO VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP2 VDD A n1 VDD pmos_hvt L=20n NFIN=3 NF=1
MP3 n1 ISO n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN4 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=8
MP5 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=8
.ENDS ISOHI_X8_HVT

.SUBCKT ISOLON_X8_HVT A ISON Y VDD VSS
* Isolation clamp-0, active-low enable (Y=A&ISON), buffered (logic stage + built-in output buffer) | pmk_iso | area 0.20995 um2 | 12 site(s) x 1 row(s)
MN0 n0 A n1 VSS nmos_hvt L=20n NFIN=3 NF=1
MN1 n1 ISON VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP2 VDD A n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MP3 VDD ISON n0 VDD pmos_hvt L=20n NFIN=3 NF=1
MN4 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=8
MP5 VDD n0 Y VDD pmos_hvt L=20n NFIN=4 NF=8
.ENDS ISOLON_X8_HVT

.SUBCKT LVLLH_X1_HVT A Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, buffered output | pmk_lvl | area 0.17496 um2 | 5 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN3 xb ab VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MP4 x xb VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP5 xb x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MN6 Y x VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP7 VDD x Y VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS LVLLH_X1_HVT

.SUBCKT LVLHL_X1_HVT A Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, buffered output | pmk_lvl | area 0.06998 um2 | 4 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP1 VDDL A n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MN2 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP3 VDDL n0 Y VDDL pmos_hvt L=20n NFIN=4 NF=1
.ENDS LVLHL_X1_HVT

.SUBCKT LVLLHUB_X1_HVT A Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, unbuffered (DCVS node drives Y) | pmk_lvl | area 0.17496 um2 | 5 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN3 Y ab VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MP4 x Y VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP5 Y x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
.ENDS LVLLHUB_X1_HVT

.SUBCKT LVLLHISOLO_X1_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, buffered output, combined isolation clamp-0 | pmk_lvl | area 0.24494 um2 | 7 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A nx VSS nmos_hvt L=20n NFIN=3 NF=2
MN5 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN6 xb ab VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN7 xb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP8 x xb VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 xb x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MN10 Y x VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP11 VDD x Y VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS LVLLHISOLO_X1_HVT

.SUBCKT LVLHLISOLO_X1_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, buffered output, combined isolation clamp-0 | pmk_lvl | area 0.10498 um2 | 6 site(s) x 1 row(s)
MN0 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL ISO isb VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 n0 A n1 VSS nmos_hvt L=20n NFIN=3 NF=1
MN3 n1 isb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDDL A n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MP5 VDDL isb n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MN6 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP7 VDDL n0 Y VDDL pmos_hvt L=20n NFIN=4 NF=1
.ENDS LVLHLISOLO_X1_HVT

.SUBCKT LVLLHISOLOUB_X1_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, unbuffered (DCVS node drives Y), combined isolation clamp-0 | pmk_lvl | area 0.24494 um2 | 7 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A nx VSS nmos_hvt L=20n NFIN=3 NF=2
MN5 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN6 Y ab VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN7 Y ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP8 x Y VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 Y x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
.ENDS LVLLHISOLOUB_X1_HVT

.SUBCKT LVLHLISOLOUB_X1_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, unbuffered, combined isolation clamp-0 | pmk_lvl | area 0.08748 um2 | 5 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 Y ab VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MN3 Y ISO VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP4 VDDL ab n1 VDDL pmos_hvt L=20n NFIN=4 NF=1
MP5 n1 ISO Y VDDL pmos_hvt L=20n NFIN=4 NF=1
.ENDS LVLHLISOLOUB_X1_HVT

.SUBCKT LVLLHISOHI_X1_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, buffered output, combined isolation clamp-1 | pmk_lvl | area 0.24494 um2 | 7 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN5 x ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN6 xb ab nx VSS nmos_hvt L=20n NFIN=3 NF=2
MN7 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MP8 x xb VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 xb x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MN10 Y x VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP11 VDD x Y VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS LVLLHISOHI_X1_HVT

.SUBCKT LVLHLISOHI_X1_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, buffered output, combined isolation clamp-1 | pmk_lvl | area 0.08748 um2 | 5 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MN1 n0 ISO VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP2 VDDL A n1 VDDL pmos_hvt L=20n NFIN=3 NF=1
MP3 n1 ISO n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MN4 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP5 VDDL n0 Y VDDL pmos_hvt L=20n NFIN=4 NF=1
.ENDS LVLHLISOHI_X1_HVT

.SUBCKT LVLLHISOHIUB_X1_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, unbuffered (DCVS node drives Y), combined isolation clamp-1 | pmk_lvl | area 0.24494 um2 | 7 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN5 x ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN6 Y ab nx VSS nmos_hvt L=20n NFIN=3 NF=2
MN7 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MP8 x Y VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 Y x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
.ENDS LVLLHISOHIUB_X1_HVT

.SUBCKT LVLHLISOHIUB_X1_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, unbuffered, combined isolation clamp-1 | pmk_lvl | area 0.10498 um2 | 6 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDDL ISO isb VDDL pmos_hvt L=20n NFIN=2 NF=1
MN4 Y ab n1 VSS nmos_hvt L=20n NFIN=4 NF=1
MN5 n1 isb VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP6 VDDL ab Y VDDL pmos_hvt L=20n NFIN=4 NF=1
MP7 VDDL isb Y VDDL pmos_hvt L=20n NFIN=4 NF=1
.ENDS LVLHLISOHIUB_X1_HVT

.SUBCKT LVLLH_X2_HVT A Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, buffered output | pmk_lvl | area 0.20995 um2 | 6 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN3 xb ab VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MP4 x xb VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP5 xb x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MN6 Y x VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP7 VDD x Y VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS LVLLH_X2_HVT

.SUBCKT LVLHL_X2_HVT A Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, buffered output | pmk_lvl | area 0.08748 um2 | 5 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP1 VDDL A n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MN2 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP3 VDDL n0 Y VDDL pmos_hvt L=20n NFIN=4 NF=2
.ENDS LVLHL_X2_HVT

.SUBCKT LVLLHUB_X2_HVT A Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, unbuffered (DCVS node drives Y) | pmk_lvl | area 0.24494 um2 | 7 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=4
MN3 Y ab VSS VSS nmos_hvt L=20n NFIN=3 NF=4
MP4 x Y VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP5 Y x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
.ENDS LVLLHUB_X2_HVT

.SUBCKT LVLLHISOLO_X2_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, buffered output, combined isolation clamp-0 | pmk_lvl | area 0.27994 um2 | 8 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A nx VSS nmos_hvt L=20n NFIN=3 NF=2
MN5 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN6 xb ab VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN7 xb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP8 x xb VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 xb x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MN10 Y x VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP11 VDD x Y VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS LVLLHISOLO_X2_HVT

.SUBCKT LVLHLISOLO_X2_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, buffered output, combined isolation clamp-0 | pmk_lvl | area 0.12247 um2 | 7 site(s) x 1 row(s)
MN0 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL ISO isb VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 n0 A n1 VSS nmos_hvt L=20n NFIN=3 NF=1
MN3 n1 isb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDDL A n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MP5 VDDL isb n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MN6 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP7 VDDL n0 Y VDDL pmos_hvt L=20n NFIN=4 NF=2
.ENDS LVLHLISOLO_X2_HVT

.SUBCKT LVLLHISOLOUB_X2_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, unbuffered (DCVS node drives Y), combined isolation clamp-0 | pmk_lvl | area 0.34992 um2 | 10 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A nx VSS nmos_hvt L=20n NFIN=3 NF=4
MN5 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=4
MN6 Y ab VSS VSS nmos_hvt L=20n NFIN=3 NF=4
MN7 Y ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=2
MP8 x Y VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 Y x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
.ENDS LVLLHISOLOUB_X2_HVT

.SUBCKT LVLHLISOLOUB_X2_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, unbuffered, combined isolation clamp-0 | pmk_lvl | area 0.12247 um2 | 7 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 Y ab VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MN3 Y ISO VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP4 VDDL ab n1 VDDL pmos_hvt L=20n NFIN=4 NF=2
MP5 n1 ISO Y VDDL pmos_hvt L=20n NFIN=4 NF=2
.ENDS LVLHLISOLOUB_X2_HVT

.SUBCKT LVLLHISOHI_X2_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, buffered output, combined isolation clamp-1 | pmk_lvl | area 0.27994 um2 | 8 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN5 x ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN6 xb ab nx VSS nmos_hvt L=20n NFIN=3 NF=2
MN7 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MP8 x xb VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 xb x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MN10 Y x VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP11 VDD x Y VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS LVLLHISOHI_X2_HVT

.SUBCKT LVLHLISOHI_X2_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, buffered output, combined isolation clamp-1 | pmk_lvl | area 0.10498 um2 | 6 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MN1 n0 ISO VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP2 VDDL A n1 VDDL pmos_hvt L=20n NFIN=3 NF=1
MP3 n1 ISO n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MN4 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP5 VDDL n0 Y VDDL pmos_hvt L=20n NFIN=4 NF=2
.ENDS LVLHLISOHI_X2_HVT

.SUBCKT LVLLHISOHIUB_X2_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, unbuffered (DCVS node drives Y), combined isolation clamp-1 | pmk_lvl | area 0.34992 um2 | 10 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=4
MN5 x ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=2
MN6 Y ab nx VSS nmos_hvt L=20n NFIN=3 NF=4
MN7 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=4
MP8 x Y VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 Y x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
.ENDS LVLLHISOHIUB_X2_HVT

.SUBCKT LVLHLISOHIUB_X2_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, unbuffered, combined isolation clamp-1 | pmk_lvl | area 0.13997 um2 | 8 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDDL ISO isb VDDL pmos_hvt L=20n NFIN=2 NF=1
MN4 Y ab n1 VSS nmos_hvt L=20n NFIN=4 NF=2
MN5 n1 isb VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP6 VDDL ab Y VDDL pmos_hvt L=20n NFIN=4 NF=2
MP7 VDDL isb Y VDDL pmos_hvt L=20n NFIN=4 NF=2
.ENDS LVLHLISOHIUB_X2_HVT

.SUBCKT LVLLH_X4_HVT A Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, buffered output | pmk_lvl | area 0.24494 um2 | 7 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN3 xb ab VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MP4 x xb VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP5 xb x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MN6 Y x VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP7 VDD x Y VDD pmos_hvt L=20n NFIN=4 NF=4
.ENDS LVLLH_X4_HVT

.SUBCKT LVLHL_X4_HVT A Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, buffered output | pmk_lvl | area 0.12247 um2 | 7 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP1 VDDL A n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MN2 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP3 VDDL n0 Y VDDL pmos_hvt L=20n NFIN=4 NF=4
.ENDS LVLHL_X4_HVT

.SUBCKT LVLLHUB_X4_HVT A Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, unbuffered (DCVS node drives Y) | pmk_lvl | area 0.38491 um2 | 11 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=8
MN3 Y ab VSS VSS nmos_hvt L=20n NFIN=3 NF=8
MP4 x Y VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP5 Y x VDD VDD pmos_hvt L=20n NFIN=2 NF=2
.ENDS LVLLHUB_X4_HVT

.SUBCKT LVLLHISOLO_X4_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, buffered output, combined isolation clamp-0 | pmk_lvl | area 0.31493 um2 | 9 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A nx VSS nmos_hvt L=20n NFIN=3 NF=2
MN5 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN6 xb ab VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN7 xb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP8 x xb VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 xb x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MN10 Y x VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP11 VDD x Y VDD pmos_hvt L=20n NFIN=4 NF=4
.ENDS LVLLHISOLO_X4_HVT

.SUBCKT LVLHLISOLO_X4_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, buffered output, combined isolation clamp-0 | pmk_lvl | area 0.15746 um2 | 9 site(s) x 1 row(s)
MN0 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL ISO isb VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 n0 A n1 VSS nmos_hvt L=20n NFIN=3 NF=1
MN3 n1 isb VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP4 VDDL A n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MP5 VDDL isb n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MN6 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP7 VDDL n0 Y VDDL pmos_hvt L=20n NFIN=4 NF=4
.ENDS LVLHLISOLO_X4_HVT

.SUBCKT LVLLHISOLOUB_X4_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, unbuffered (DCVS node drives Y), combined isolation clamp-0 | pmk_lvl | area 0.59486 um2 | 17 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A nx VSS nmos_hvt L=20n NFIN=3 NF=8
MN5 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=8
MN6 Y ab VSS VSS nmos_hvt L=20n NFIN=3 NF=8
MN7 Y ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=4
MP8 x Y VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 Y x VDD VDD pmos_hvt L=20n NFIN=2 NF=2
.ENDS LVLLHISOLOUB_X4_HVT

.SUBCKT LVLHLISOLOUB_X4_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, unbuffered, combined isolation clamp-0 | pmk_lvl | area 0.19246 um2 | 11 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 Y ab VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MN3 Y ISO VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP4 VDDL ab n1 VDDL pmos_hvt L=20n NFIN=4 NF=4
MP5 n1 ISO Y VDDL pmos_hvt L=20n NFIN=4 NF=4
.ENDS LVLHLISOLOUB_X4_HVT

.SUBCKT LVLLHISOHI_X4_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, buffered output, combined isolation clamp-1 | pmk_lvl | area 0.31493 um2 | 9 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MN5 x ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN6 xb ab nx VSS nmos_hvt L=20n NFIN=3 NF=2
MN7 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MP8 x xb VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 xb x VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MN10 Y x VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP11 VDD x Y VDD pmos_hvt L=20n NFIN=4 NF=4
.ENDS LVLLHISOHI_X4_HVT

.SUBCKT LVLHLISOHI_X4_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, buffered output, combined isolation clamp-1 | pmk_lvl | area 0.13997 um2 | 8 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MN1 n0 ISO VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP2 VDDL A n1 VDDL pmos_hvt L=20n NFIN=3 NF=1
MP3 n1 ISO n0 VDDL pmos_hvt L=20n NFIN=3 NF=1
MN4 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP5 VDDL n0 Y VDDL pmos_hvt L=20n NFIN=4 NF=4
.ENDS LVLHLISOHI_X4_HVT

.SUBCKT LVLLHISOHIUB_X4_HVT A ISO Y VDDL VDD VSS
* Low-to-high level shifter (VDDL->VDD), DCVS, double-row, unbuffered (DCVS node drives Y), combined isolation clamp-1 | pmk_lvl | area 0.59486 um2 | 17 site(s) x 2 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDD ISO isb VDD pmos_hvt L=20n NFIN=2 NF=1
MN4 x A VSS VSS nmos_hvt L=20n NFIN=3 NF=8
MN5 x ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=4
MN6 Y ab nx VSS nmos_hvt L=20n NFIN=3 NF=8
MN7 nx isb VSS VSS nmos_hvt L=20n NFIN=3 NF=8
MP8 x Y VDD VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 Y x VDD VDD pmos_hvt L=20n NFIN=2 NF=2
.ENDS LVLLHISOHIUB_X4_HVT

.SUBCKT LVLHLISOHIUB_X4_HVT A ISO Y VDDL VSS
* High-to-low level shifter (VDD->VDDL), single rail, unbuffered, combined isolation clamp-1 | pmk_lvl | area 0.20995 um2 | 12 site(s) x 1 row(s)
MN0 ab A VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDL A ab VDDL pmos_hvt L=20n NFIN=2 NF=1
MN2 isb ISO VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP3 VDDL ISO isb VDDL pmos_hvt L=20n NFIN=2 NF=1
MN4 Y ab n1 VSS nmos_hvt L=20n NFIN=4 NF=4
MN5 n1 isb VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP6 VDDL ab Y VDDL pmos_hvt L=20n NFIN=4 NF=4
MP7 VDDL isb Y VDDL pmos_hvt L=20n NFIN=4 NF=4
.ENDS LVLHLISOHIUB_X4_HVT

.SUBCKT RETDFF_X1_HVT D CK NRET Q VDD VDDR VSS
* Retention flop (live slave on VDDR, NRET=0 retains) | pmk_ret | area 0.26244 um2 | 15 site(s) x 1 row(s)
MN0 ckg CK n1 VSS nmos_hvt L=20n NFIN=2 NF=1
MN1 n1 NRET VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP2 VDDR CK ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MP3 VDDR NRET ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MN4 cki ckg VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP5 VDDR ckg cki VDDR pmos_hvt L=20n NFIN=2 NF=1
MN6 ckb cki VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP7 VDDR cki ckb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN8 D ckb m1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 D cki m1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN10 m2 m1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP11 VDD m1 m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP12 n2 m2 VDD VDD pmos_hvt L=40n NFIN=1 NF=1
MP13 m1 ckb n2 VDD pmos_hvt L=40n NFIN=1 NF=1
MN14 m1 cki n3 VSS nmos_hvt L=40n NFIN=1 NF=1
MN15 n3 m2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN16 m2 cki s1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP17 m2 ckb s1 VDDR pmos_hvt L=20n NFIN=3 NF=1
MN18 s2 s1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP19 VDDR s1 s2 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP20 n4 s2 VDDR VDDR pmos_hvt L=40n NFIN=1 NF=1
MP21 s1 cki n4 VDDR pmos_hvt L=40n NFIN=1 NF=1
MN22 s1 ckb n5 VSS nmos_hvt L=40n NFIN=1 NF=1
MN23 n5 s2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN24 Q s1 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP25 VDD s1 Q VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS RETDFF_X1_HVT

.SUBCKT RETDFF_X2_HVT D CK NRET Q VDD VDDR VSS
* Retention flop (live slave on VDDR, NRET=0 retains) | pmk_ret | area 0.27994 um2 | 16 site(s) x 1 row(s)
MN0 ckg CK n1 VSS nmos_hvt L=20n NFIN=2 NF=1
MN1 n1 NRET VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP2 VDDR CK ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MP3 VDDR NRET ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MN4 cki ckg VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP5 VDDR ckg cki VDDR pmos_hvt L=20n NFIN=2 NF=1
MN6 ckb cki VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP7 VDDR cki ckb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN8 D ckb m1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 D cki m1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN10 m2 m1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP11 VDD m1 m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP12 n2 m2 VDD VDD pmos_hvt L=40n NFIN=1 NF=1
MP13 m1 ckb n2 VDD pmos_hvt L=40n NFIN=1 NF=1
MN14 m1 cki n3 VSS nmos_hvt L=40n NFIN=1 NF=1
MN15 n3 m2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN16 m2 cki s1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP17 m2 ckb s1 VDDR pmos_hvt L=20n NFIN=3 NF=1
MN18 s2 s1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP19 VDDR s1 s2 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP20 n4 s2 VDDR VDDR pmos_hvt L=40n NFIN=1 NF=1
MP21 s1 cki n4 VDDR pmos_hvt L=40n NFIN=1 NF=1
MN22 s1 ckb n5 VSS nmos_hvt L=40n NFIN=1 NF=1
MN23 n5 s2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN24 Q s1 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP25 VDD s1 Q VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS RETDFF_X2_HVT

.SUBCKT RETDFFR_X1_HVT D CK RN NRET Q VDD VDDR VSS
* Retention flop (live slave on VDDR, NRET=0 retains), async reset | pmk_ret | area 0.31493 um2 | 18 site(s) x 1 row(s)
MN0 ckg CK n1 VSS nmos_hvt L=20n NFIN=2 NF=1
MN1 n1 NRET VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP2 VDDR CK ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MP3 VDDR NRET ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MN4 cki ckg VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP5 VDDR ckg cki VDDR pmos_hvt L=20n NFIN=2 NF=1
MN6 ckb cki VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP7 VDDR cki ckb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN8 D ckb m1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 D cki m1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN10 m2 m1 n2 VSS nmos_hvt L=20n NFIN=2 NF=1
MN11 n2 RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP12 VDD m1 m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP13 VDD RN m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP14 n3 m2 VDD VDD pmos_hvt L=40n NFIN=1 NF=1
MP15 m1 ckb n3 VDD pmos_hvt L=40n NFIN=1 NF=1
MN16 m1 cki n4 VSS nmos_hvt L=40n NFIN=1 NF=1
MN17 n4 m2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN18 m2 cki s1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP19 m2 ckb s1 VDDR pmos_hvt L=20n NFIN=3 NF=1
MN20 rb RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP21 VDDR RN rb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN22 s2 s1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN23 s2 rb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP24 VDDR s1 n5 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP25 n5 rb s2 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP26 n6 s2 VDDR VDDR pmos_hvt L=40n NFIN=1 NF=1
MP27 s1 cki n6 VDDR pmos_hvt L=40n NFIN=1 NF=1
MN28 s1 ckb n7 VSS nmos_hvt L=40n NFIN=1 NF=1
MN29 n7 s2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN30 Q s1 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP31 VDD s1 Q VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS RETDFFR_X1_HVT

.SUBCKT RETDFFR_X2_HVT D CK RN NRET Q VDD VDDR VSS
* Retention flop (live slave on VDDR, NRET=0 retains), async reset | pmk_ret | area 0.33242 um2 | 19 site(s) x 1 row(s)
MN0 ckg CK n1 VSS nmos_hvt L=20n NFIN=2 NF=1
MN1 n1 NRET VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP2 VDDR CK ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MP3 VDDR NRET ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MN4 cki ckg VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP5 VDDR ckg cki VDDR pmos_hvt L=20n NFIN=2 NF=1
MN6 ckb cki VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP7 VDDR cki ckb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN8 D ckb m1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP9 D cki m1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN10 m2 m1 n2 VSS nmos_hvt L=20n NFIN=2 NF=1
MN11 n2 RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP12 VDD m1 m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP13 VDD RN m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP14 n3 m2 VDD VDD pmos_hvt L=40n NFIN=1 NF=1
MP15 m1 ckb n3 VDD pmos_hvt L=40n NFIN=1 NF=1
MN16 m1 cki n4 VSS nmos_hvt L=40n NFIN=1 NF=1
MN17 n4 m2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN18 m2 cki s1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP19 m2 ckb s1 VDDR pmos_hvt L=20n NFIN=3 NF=1
MN20 rb RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP21 VDDR RN rb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN22 s2 s1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN23 s2 rb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP24 VDDR s1 n5 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP25 n5 rb s2 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP26 n6 s2 VDDR VDDR pmos_hvt L=40n NFIN=1 NF=1
MP27 s1 cki n6 VDDR pmos_hvt L=40n NFIN=1 NF=1
MN28 s1 ckb n7 VSS nmos_hvt L=40n NFIN=1 NF=1
MN29 n7 s2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN30 Q s1 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP31 VDD s1 Q VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS RETDFFR_X2_HVT

.SUBCKT RETSDFF_X1_HVT D SI SE CK NRET Q VDD VDDR VSS
* Retention flop (live slave on VDDR, NRET=0 retains), scan | pmk_ret | area 0.36742 um2 | 21 site(s) x 1 row(s)
MN0 seb SE VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SE seb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 dmx D n1 VSS nmos_hvt L=20n NFIN=2 NF=1
MN3 n1 seb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN4 dmx SI n2 VSS nmos_hvt L=20n NFIN=2 NF=1
MN5 n2 SE VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP6 VDD D n3 VDD pmos_hvt L=20n NFIN=2 NF=1
MP7 VDD seb n3 VDD pmos_hvt L=20n NFIN=2 NF=1
MP8 n3 SI dmx VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 n3 SE dmx VDD pmos_hvt L=20n NFIN=2 NF=1
MN10 ds dmx VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP11 VDD dmx ds VDD pmos_hvt L=20n NFIN=2 NF=1
MN12 ckg CK n4 VSS nmos_hvt L=20n NFIN=2 NF=1
MN13 n4 NRET VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP14 VDDR CK ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MP15 VDDR NRET ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MN16 cki ckg VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP17 VDDR ckg cki VDDR pmos_hvt L=20n NFIN=2 NF=1
MN18 ckb cki VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP19 VDDR cki ckb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN20 ds ckb m1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP21 ds cki m1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN22 m2 m1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP23 VDD m1 m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP24 n5 m2 VDD VDD pmos_hvt L=40n NFIN=1 NF=1
MP25 m1 ckb n5 VDD pmos_hvt L=40n NFIN=1 NF=1
MN26 m1 cki n6 VSS nmos_hvt L=40n NFIN=1 NF=1
MN27 n6 m2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN28 m2 cki s1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP29 m2 ckb s1 VDDR pmos_hvt L=20n NFIN=3 NF=1
MN30 s2 s1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP31 VDDR s1 s2 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP32 n7 s2 VDDR VDDR pmos_hvt L=40n NFIN=1 NF=1
MP33 s1 cki n7 VDDR pmos_hvt L=40n NFIN=1 NF=1
MN34 s1 ckb n8 VSS nmos_hvt L=40n NFIN=1 NF=1
MN35 n8 s2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN36 Q s1 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP37 VDD s1 Q VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS RETSDFF_X1_HVT

.SUBCKT RETSDFF_X2_HVT D SI SE CK NRET Q VDD VDDR VSS
* Retention flop (live slave on VDDR, NRET=0 retains), scan | pmk_ret | area 0.38491 um2 | 22 site(s) x 1 row(s)
MN0 seb SE VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SE seb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 dmx D n1 VSS nmos_hvt L=20n NFIN=2 NF=1
MN3 n1 seb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN4 dmx SI n2 VSS nmos_hvt L=20n NFIN=2 NF=1
MN5 n2 SE VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP6 VDD D n3 VDD pmos_hvt L=20n NFIN=2 NF=1
MP7 VDD seb n3 VDD pmos_hvt L=20n NFIN=2 NF=1
MP8 n3 SI dmx VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 n3 SE dmx VDD pmos_hvt L=20n NFIN=2 NF=1
MN10 ds dmx VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP11 VDD dmx ds VDD pmos_hvt L=20n NFIN=2 NF=1
MN12 ckg CK n4 VSS nmos_hvt L=20n NFIN=2 NF=1
MN13 n4 NRET VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP14 VDDR CK ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MP15 VDDR NRET ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MN16 cki ckg VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP17 VDDR ckg cki VDDR pmos_hvt L=20n NFIN=2 NF=1
MN18 ckb cki VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP19 VDDR cki ckb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN20 ds ckb m1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP21 ds cki m1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN22 m2 m1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP23 VDD m1 m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP24 n5 m2 VDD VDD pmos_hvt L=40n NFIN=1 NF=1
MP25 m1 ckb n5 VDD pmos_hvt L=40n NFIN=1 NF=1
MN26 m1 cki n6 VSS nmos_hvt L=40n NFIN=1 NF=1
MN27 n6 m2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN28 m2 cki s1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP29 m2 ckb s1 VDDR pmos_hvt L=20n NFIN=3 NF=1
MN30 s2 s1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP31 VDDR s1 s2 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP32 n7 s2 VDDR VDDR pmos_hvt L=40n NFIN=1 NF=1
MP33 s1 cki n7 VDDR pmos_hvt L=40n NFIN=1 NF=1
MN34 s1 ckb n8 VSS nmos_hvt L=40n NFIN=1 NF=1
MN35 n8 s2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN36 Q s1 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP37 VDD s1 Q VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS RETSDFF_X2_HVT

.SUBCKT RETSDFFR_X1_HVT D SI SE CK RN NRET Q VDD VDDR VSS
* Retention flop (live slave on VDDR, NRET=0 retains), async reset, scan | pmk_ret | area 0.41990 um2 | 24 site(s) x 1 row(s)
MN0 seb SE VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SE seb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 dmx D n1 VSS nmos_hvt L=20n NFIN=2 NF=1
MN3 n1 seb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN4 dmx SI n2 VSS nmos_hvt L=20n NFIN=2 NF=1
MN5 n2 SE VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP6 VDD D n3 VDD pmos_hvt L=20n NFIN=2 NF=1
MP7 VDD seb n3 VDD pmos_hvt L=20n NFIN=2 NF=1
MP8 n3 SI dmx VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 n3 SE dmx VDD pmos_hvt L=20n NFIN=2 NF=1
MN10 ds dmx VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP11 VDD dmx ds VDD pmos_hvt L=20n NFIN=2 NF=1
MN12 ckg CK n4 VSS nmos_hvt L=20n NFIN=2 NF=1
MN13 n4 NRET VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP14 VDDR CK ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MP15 VDDR NRET ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MN16 cki ckg VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP17 VDDR ckg cki VDDR pmos_hvt L=20n NFIN=2 NF=1
MN18 ckb cki VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP19 VDDR cki ckb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN20 ds ckb m1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP21 ds cki m1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN22 m2 m1 n5 VSS nmos_hvt L=20n NFIN=2 NF=1
MN23 n5 RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP24 VDD m1 m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP25 VDD RN m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP26 n6 m2 VDD VDD pmos_hvt L=40n NFIN=1 NF=1
MP27 m1 ckb n6 VDD pmos_hvt L=40n NFIN=1 NF=1
MN28 m1 cki n7 VSS nmos_hvt L=40n NFIN=1 NF=1
MN29 n7 m2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN30 m2 cki s1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP31 m2 ckb s1 VDDR pmos_hvt L=20n NFIN=3 NF=1
MN32 rb RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP33 VDDR RN rb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN34 s2 s1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN35 s2 rb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP36 VDDR s1 n8 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP37 n8 rb s2 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP38 n9 s2 VDDR VDDR pmos_hvt L=40n NFIN=1 NF=1
MP39 s1 cki n9 VDDR pmos_hvt L=40n NFIN=1 NF=1
MN40 s1 ckb n10 VSS nmos_hvt L=40n NFIN=1 NF=1
MN41 n10 s2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN42 Q s1 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP43 VDD s1 Q VDD pmos_hvt L=20n NFIN=4 NF=1
.ENDS RETSDFFR_X1_HVT

.SUBCKT RETSDFFR_X2_HVT D SI SE CK RN NRET Q VDD VDDR VSS
* Retention flop (live slave on VDDR, NRET=0 retains), async reset, scan | pmk_ret | area 0.43740 um2 | 25 site(s) x 1 row(s)
MN0 seb SE VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDD SE seb VDD pmos_hvt L=20n NFIN=2 NF=1
MN2 dmx D n1 VSS nmos_hvt L=20n NFIN=2 NF=1
MN3 n1 seb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN4 dmx SI n2 VSS nmos_hvt L=20n NFIN=2 NF=1
MN5 n2 SE VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP6 VDD D n3 VDD pmos_hvt L=20n NFIN=2 NF=1
MP7 VDD seb n3 VDD pmos_hvt L=20n NFIN=2 NF=1
MP8 n3 SI dmx VDD pmos_hvt L=20n NFIN=2 NF=1
MP9 n3 SE dmx VDD pmos_hvt L=20n NFIN=2 NF=1
MN10 ds dmx VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP11 VDD dmx ds VDD pmos_hvt L=20n NFIN=2 NF=1
MN12 ckg CK n4 VSS nmos_hvt L=20n NFIN=2 NF=1
MN13 n4 NRET VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP14 VDDR CK ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MP15 VDDR NRET ckg VDDR pmos_hvt L=20n NFIN=2 NF=1
MN16 cki ckg VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP17 VDDR ckg cki VDDR pmos_hvt L=20n NFIN=2 NF=1
MN18 ckb cki VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP19 VDDR cki ckb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN20 ds ckb m1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP21 ds cki m1 VDD pmos_hvt L=20n NFIN=3 NF=1
MN22 m2 m1 n5 VSS nmos_hvt L=20n NFIN=2 NF=1
MN23 n5 RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP24 VDD m1 m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP25 VDD RN m2 VDD pmos_hvt L=20n NFIN=2 NF=1
MP26 n6 m2 VDD VDD pmos_hvt L=40n NFIN=1 NF=1
MP27 m1 ckb n6 VDD pmos_hvt L=40n NFIN=1 NF=1
MN28 m1 cki n7 VSS nmos_hvt L=40n NFIN=1 NF=1
MN29 n7 m2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN30 m2 cki s1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP31 m2 ckb s1 VDDR pmos_hvt L=20n NFIN=3 NF=1
MN32 rb RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP33 VDDR RN rb VDDR pmos_hvt L=20n NFIN=2 NF=1
MN34 s2 s1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN35 s2 rb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP36 VDDR s1 n8 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP37 n8 rb s2 VDDR pmos_hvt L=20n NFIN=2 NF=1
MP38 n9 s2 VDDR VDDR pmos_hvt L=40n NFIN=1 NF=1
MP39 s1 cki n9 VDDR pmos_hvt L=40n NFIN=1 NF=1
MN40 s1 ckb n10 VSS nmos_hvt L=40n NFIN=1 NF=1
MN41 n10 s2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN42 Q s1 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP43 VDD s1 Q VDD pmos_hvt L=20n NFIN=4 NF=2
.ENDS RETSDFFR_X2_HVT

.SUBCKT AONBUF_X1_HVT A Y VDD VDDB VSS
* Always-on buffer (VDDB) | pmk_aon | area 0.06998 um2 | 4 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP1 VDDB A n0 VDDB pmos_hvt L=20n NFIN=3 NF=1
MN2 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP3 VDDB n0 Y VDDB pmos_hvt L=20n NFIN=4 NF=1
.ENDS AONBUF_X1_HVT

.SUBCKT AONBUF_X2_HVT A Y VDD VDDB VSS
* Always-on buffer (VDDB) | pmk_aon | area 0.08748 um2 | 5 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP1 VDDB A n0 VDDB pmos_hvt L=20n NFIN=3 NF=1
MN2 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP3 VDDB n0 Y VDDB pmos_hvt L=20n NFIN=4 NF=2
.ENDS AONBUF_X2_HVT

.SUBCKT AONBUF_X4_HVT A Y VDD VDDB VSS
* Always-on buffer (VDDB) | pmk_aon | area 0.12247 um2 | 7 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP1 VDDB A n0 VDDB pmos_hvt L=20n NFIN=3 NF=1
MN2 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP3 VDDB n0 Y VDDB pmos_hvt L=20n NFIN=4 NF=4
.ENDS AONBUF_X4_HVT

.SUBCKT AONBUF_X8_HVT A Y VDD VDDB VSS
* Always-on buffer (VDDB) | pmk_aon | area 0.20995 um2 | 12 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MP1 VDDB A n0 VDDB pmos_hvt L=20n NFIN=3 NF=2
MN2 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=8
MP3 VDDB n0 Y VDDB pmos_hvt L=20n NFIN=4 NF=8
.ENDS AONBUF_X8_HVT

.SUBCKT AONINV_X1_HVT A Y VDD VDDB VSS
* Always-on inverter (VDDB) | pmk_aon | area 0.06998 um2 | 4 site(s) x 1 row(s)
MN0 Y A VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP1 VDDB A Y VDDB pmos_hvt L=20n NFIN=4 NF=1
.ENDS AONINV_X1_HVT

.SUBCKT AONINV_X2_HVT A Y VDD VDDB VSS
* Always-on inverter (VDDB) | pmk_aon | area 0.06998 um2 | 4 site(s) x 1 row(s)
MN0 Y A VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP1 VDDB A Y VDDB pmos_hvt L=20n NFIN=4 NF=2
.ENDS AONINV_X2_HVT

.SUBCKT AONINV_X4_HVT A Y VDD VDDB VSS
* Always-on inverter (VDDB) | pmk_aon | area 0.10498 um2 | 6 site(s) x 1 row(s)
MN0 Y A VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP1 VDDB A Y VDDB pmos_hvt L=20n NFIN=4 NF=4
.ENDS AONINV_X4_HVT

.SUBCKT AONINV_X8_HVT A Y VDD VDDB VSS
* Always-on inverter (VDDB) | pmk_aon | area 0.17496 um2 | 10 site(s) x 1 row(s)
MN0 Y A VSS VSS nmos_hvt L=20n NFIN=4 NF=8
MP1 VDDB A Y VDDB pmos_hvt L=20n NFIN=4 NF=8
.ENDS AONINV_X8_HVT

.SUBCKT AONCKBUF_X1_HVT A Y VDD VDDB VSS
* Always-on clock buffer (VDDB) | pmk_aon | area 0.06998 um2 | 4 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP1 VDDB A n0 VDDB pmos_hvt L=20n NFIN=3 NF=1
MN2 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP3 VDDB n0 Y VDDB pmos_hvt L=20n NFIN=4 NF=1
.ENDS AONCKBUF_X1_HVT

.SUBCKT AONCKBUF_X2_HVT A Y VDD VDDB VSS
* Always-on clock buffer (VDDB) | pmk_aon | area 0.08748 um2 | 5 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP1 VDDB A n0 VDDB pmos_hvt L=20n NFIN=3 NF=1
MN2 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP3 VDDB n0 Y VDDB pmos_hvt L=20n NFIN=4 NF=2
.ENDS AONCKBUF_X2_HVT

.SUBCKT AONCKBUF_X4_HVT A Y VDD VDDB VSS
* Always-on clock buffer (VDDB) | pmk_aon | area 0.12247 um2 | 7 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=1
MP1 VDDB A n0 VDDB pmos_hvt L=20n NFIN=3 NF=1
MN2 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=4
MP3 VDDB n0 Y VDDB pmos_hvt L=20n NFIN=4 NF=4
.ENDS AONCKBUF_X4_HVT

.SUBCKT AONCKBUF_X8_HVT A Y VDD VDDB VSS
* Always-on clock buffer (VDDB) | pmk_aon | area 0.20995 um2 | 12 site(s) x 1 row(s)
MN0 n0 A VSS VSS nmos_hvt L=20n NFIN=3 NF=2
MP1 VDDB A n0 VDDB pmos_hvt L=20n NFIN=3 NF=2
MN2 Y n0 VSS VSS nmos_hvt L=20n NFIN=4 NF=8
MP3 VDDB n0 Y VDDB pmos_hvt L=20n NFIN=4 NF=8
.ENDS AONCKBUF_X8_HVT

.SUBCKT AONDLY_X1_HVT A Y VDD VDDB VSS
* Always-on delay cell (VDDB) | pmk_aon | area 0.13997 um2 | 8 site(s) x 1 row(s)
MN0 d0 A VSS VSS nmos_hvt L=60n NFIN=2 NF=1
MP1 VDDB A d0 VDDB pmos_hvt L=60n NFIN=2 NF=1
MN2 d1 d0 VSS VSS nmos_hvt L=60n NFIN=2 NF=1
MP3 VDDB d0 d1 VDDB pmos_hvt L=60n NFIN=2 NF=1
MN4 d2 d1 VSS VSS nmos_hvt L=60n NFIN=2 NF=1
MP5 VDDB d1 d2 VDDB pmos_hvt L=60n NFIN=2 NF=1
MN6 d3 d2 VSS VSS nmos_hvt L=60n NFIN=2 NF=1
MP7 VDDB d2 d3 VDDB pmos_hvt L=60n NFIN=2 NF=1
MN8 d4 d3 VSS VSS nmos_hvt L=60n NFIN=2 NF=1
MP9 VDDB d3 d4 VDDB pmos_hvt L=60n NFIN=2 NF=1
MN10 Y d4 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP11 VDDB d4 Y VDDB pmos_hvt L=20n NFIN=4 NF=1
.ENDS AONDLY_X1_HVT

.SUBCKT AONDFFR_X1_HVT D E CK RN Q VDD VDDB VSS
* Always-on DFF with enable & async reset (VDDB) | pmk_aon | area 0.38491 um2 | 22 site(s) x 1 row(s)
MN0 eb E VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDB E eb VDDB pmos_hvt L=20n NFIN=2 NF=1
MN2 emx D n1 VSS nmos_hvt L=20n NFIN=2 NF=1
MN3 n1 E VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN4 emx Q n2 VSS nmos_hvt L=20n NFIN=2 NF=1
MN5 n2 eb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP6 VDDB D n3 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP7 VDDB E n3 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP8 n3 Q emx VDDB pmos_hvt L=20n NFIN=2 NF=1
MP9 n3 eb emx VDDB pmos_hvt L=20n NFIN=2 NF=1
MN10 de emx VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP11 VDDB emx de VDDB pmos_hvt L=20n NFIN=2 NF=1
MN12 ckb CK VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP13 VDDB CK ckb VDDB pmos_hvt L=20n NFIN=2 NF=1
MN14 cki ckb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP15 VDDB ckb cki VDDB pmos_hvt L=20n NFIN=2 NF=1
MN16 de ckb m1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP17 de cki m1 VDDB pmos_hvt L=20n NFIN=3 NF=1
MN18 m2 m1 n4 VSS nmos_hvt L=20n NFIN=2 NF=1
MN19 n4 RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP20 VDDB m1 m2 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP21 VDDB RN m2 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP22 n5 m2 VDDB VDDB pmos_hvt L=40n NFIN=1 NF=1
MP23 m1 ckb n5 VDDB pmos_hvt L=40n NFIN=1 NF=1
MN24 m1 cki n6 VSS nmos_hvt L=40n NFIN=1 NF=1
MN25 n6 m2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN26 m2 cki s1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP27 m2 ckb s1 VDDB pmos_hvt L=20n NFIN=3 NF=1
MN28 rb RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP29 VDDB RN rb VDDB pmos_hvt L=20n NFIN=2 NF=1
MN30 s2 s1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN31 s2 rb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP32 VDDB s1 n7 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP33 n7 rb s2 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP34 n8 s2 VDDB VDDB pmos_hvt L=40n NFIN=1 NF=1
MP35 s1 cki n8 VDDB pmos_hvt L=40n NFIN=1 NF=1
MN36 s1 ckb n9 VSS nmos_hvt L=40n NFIN=1 NF=1
MN37 n9 s2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN38 Q s1 VSS VSS nmos_hvt L=20n NFIN=4 NF=1
MP39 VDDB s1 Q VDDB pmos_hvt L=20n NFIN=4 NF=1
.ENDS AONDFFR_X1_HVT

.SUBCKT AONDFFR_X2_HVT D E CK RN Q VDD VDDB VSS
* Always-on DFF with enable & async reset (VDDB) | pmk_aon | area 0.40241 um2 | 23 site(s) x 1 row(s)
MN0 eb E VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP1 VDDB E eb VDDB pmos_hvt L=20n NFIN=2 NF=1
MN2 emx D n1 VSS nmos_hvt L=20n NFIN=2 NF=1
MN3 n1 E VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN4 emx Q n2 VSS nmos_hvt L=20n NFIN=2 NF=1
MN5 n2 eb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP6 VDDB D n3 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP7 VDDB E n3 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP8 n3 Q emx VDDB pmos_hvt L=20n NFIN=2 NF=1
MP9 n3 eb emx VDDB pmos_hvt L=20n NFIN=2 NF=1
MN10 de emx VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP11 VDDB emx de VDDB pmos_hvt L=20n NFIN=2 NF=1
MN12 ckb CK VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP13 VDDB CK ckb VDDB pmos_hvt L=20n NFIN=2 NF=1
MN14 cki ckb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP15 VDDB ckb cki VDDB pmos_hvt L=20n NFIN=2 NF=1
MN16 de ckb m1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP17 de cki m1 VDDB pmos_hvt L=20n NFIN=3 NF=1
MN18 m2 m1 n4 VSS nmos_hvt L=20n NFIN=2 NF=1
MN19 n4 RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP20 VDDB m1 m2 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP21 VDDB RN m2 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP22 n5 m2 VDDB VDDB pmos_hvt L=40n NFIN=1 NF=1
MP23 m1 ckb n5 VDDB pmos_hvt L=40n NFIN=1 NF=1
MN24 m1 cki n6 VSS nmos_hvt L=40n NFIN=1 NF=1
MN25 n6 m2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN26 m2 cki s1 VSS nmos_hvt L=20n NFIN=3 NF=1
MP27 m2 ckb s1 VDDB pmos_hvt L=20n NFIN=3 NF=1
MN28 rb RN VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP29 VDDB RN rb VDDB pmos_hvt L=20n NFIN=2 NF=1
MN30 s2 s1 VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MN31 s2 rb VSS VSS nmos_hvt L=20n NFIN=2 NF=1
MP32 VDDB s1 n7 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP33 n7 rb s2 VDDB pmos_hvt L=20n NFIN=2 NF=1
MP34 n8 s2 VDDB VDDB pmos_hvt L=40n NFIN=1 NF=1
MP35 s1 cki n8 VDDB pmos_hvt L=40n NFIN=1 NF=1
MN36 s1 ckb n9 VSS nmos_hvt L=40n NFIN=1 NF=1
MN37 n9 s2 VSS VSS nmos_hvt L=40n NFIN=1 NF=1
MN38 Q s1 VSS VSS nmos_hvt L=20n NFIN=4 NF=2
MP39 VDDB s1 Q VDDB pmos_hvt L=20n NFIN=4 NF=2
.ENDS AONDFFR_X2_HVT

