// R14N7 synthetic 7nm-class FinFET PDK v1.0.0 (9-track variant) -- PREDICTIVE, NOT SILICON-CALIBRATED, NOT FOR MANUFACTURING
// R14N7 user-defined primitives
`timescale 1ps/1fs
// Positive-edge D flip-flop, active-low clear (dominant) and preset, notifier -> X
primitive r14_udp_ff (Q, D, CP, RN, SN, NOTI);
  output Q; reg Q;
  input D, CP, RN, SN, NOTI;
  table
  //  D   CP    RN  SN  NOTI : Q : Q+
      ?   ?     0   ?   ?    : ? : 0 ;
      ?   ?     1   0   ?    : ? : 1 ;
      0  (01)   1   1   ?    : ? : 0 ;
      1  (01)   1   1   ?    : ? : 1 ;
      0  (x1)   1   1   ?    : 0 : 0 ;
      1  (x1)   1   1   ?    : 1 : 1 ;
      0  (0x)   1   1   ?    : 0 : 0 ;
      1  (0x)   1   1   ?    : 1 : 1 ;
      ?  (?0)   1   1   ?    : ? : - ;
      ?  (1x)   1   1   ?    : ? : - ;
      *   ?     1   1   ?    : ? : - ;
      ?   ?    (?1) 1   ?    : ? : - ;
      ?   ?     1  (?1) ?    : ? : - ;
      ?   0     x   1   ?    : 0 : 0 ;
      ?   1     x   1   ?    : 0 : 0 ;
      ?   0     1   x   ?    : 1 : 1 ;
      ?   1     1   x   ?    : 1 : 1 ;
      ?   ?     ?   ?   *    : ? : x ;
  endtable
endprimitive

// High-transparent D latch, active-low clear (dominant) and preset
primitive r14_udp_latch (Q, D, E, RN, SN, NOTI);
  output Q; reg Q;
  input D, E, RN, SN, NOTI;
  table
  //  D  E  RN SN NOTI : Q : Q+
      ?  ?  0  ?  ?    : ? : 0 ;
      ?  ?  1  0  ?    : ? : 1 ;
      0  1  1  1  ?    : ? : 0 ;
      1  1  1  1  ?    : ? : 1 ;
      ?  0  1  1  ?    : ? : - ;
      0  x  1  1  ?    : 0 : 0 ;
      1  x  1  1  ?    : 1 : 1 ;
      ?  ?  ?  ?  *    : ? : x ;
  endtable
endprimitive
